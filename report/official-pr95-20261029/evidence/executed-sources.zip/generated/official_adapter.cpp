#define FLASH_CHROMA_ENABLE_OPENMP 0
#define FLASH_CHROMA_IMPLEMENTATION
#include "flash_chroma.hpp"
#define FC_C_STATIC
#define FC_C_IMPLEMENTATION
#include "flash_chroma_c.h"
#include <algorithm>
#include <memory>
#include <stdexcept>
// main.cpp -- 3D LUT color correction pipeline (port of Python/main.py)
//
// Algorithm-equivalent port:
//   - apply_lut_linear : 8-vertex trilinear interpolation
//   - apply_lut_nearest: nearest-neighbor LUT lookup
//   - apply_3d_lut     : chain 4 LUTs sequentially
//   - sparse_lut       : sample 256^3 full LUT into size^3 sparse LUT (/16 quant)
//   - color_dalta_calc : average euclidean deltaE (matches Python logic)
//
// Image input: raw RGB .bin files (768*1024*3 bytes, no header),
//             matching Python's np.fromfile(...).reshape(768,1024,3).
//
// Build:
//   g++ -O2 -std=c++17 -o lut3d main.cpp
//
// Usage:
//   ./lut3d <data_dir>
//     data_dir contains: image/1.bin ... image/100.bin, LUT/Test1.3DL

#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include <array>
#include <fstream>
#include <chrono>
#include <ctime>
#include <sys/stat.h>

namespace {

constexpr int IMG_H = 768;
constexpr int IMG_W = 1024;
constexpr int IMG_C = 3;
constexpr int MAX_IMAGES = 100;

// ------------------------------------------------------------------
// Image
// ------------------------------------------------------------------

struct Image {
    int H = 0, W = 0, C = 0;
    std::vector<uint8_t> data;

    uint8_t* ptr() { return data.data(); }
    const uint8_t* ptr() const { return data.data(); }
    size_t size() const { return (size_t)H * W * C; }
};

int clamp_i(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

double now_sec() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

// Load raw RGB .bin file: exactly H*W*C bytes, no header.
// Mirrors Python: np.fromfile(file, dtype=np.uint8).reshape(768,1024,3)
bool image_load_bin(const std::string& path, Image& out) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { std::fprintf(stderr, "cannot open %s\n", path.c_str()); return false; }
    std::streamsize sz = f.tellg();
    f.seekg(0, std::ios::beg);
    size_t n = (size_t)IMG_H * IMG_W * IMG_C;
    if ((size_t)sz != n) {
        std::fprintf(stderr, "%s: size %zd != %zu\n", path.c_str(), (ssize_t)sz, n);
        return false;
    }
    out.H = IMG_H; out.W = IMG_W; out.C = IMG_C;
    out.data.resize(n);
    if (!f.read(reinterpret_cast<char*>(out.data.data()), (std::streamsize)n)) {
        std::fprintf(stderr, "%s: read failed\n", path.c_str());
        return false;
    }
    return true;
}

// ------------------------------------------------------------------
// LUT
// ------------------------------------------------------------------

struct Lut3D {
    int size = 0;                  // N
    std::vector<uint8_t> data;     // size^3 * 3, indexed [r][g][b]
    const uint8_t* at(int r, int g, int b) const {
        return &data[(((size_t)r * size + g) * size + b) * 3];
    }
};

// Read .3DL file: 256^3 lines, each "R G B". Values are 0..4080 (16x scale);
// store raw 16-bit values so sparse_lut can do /16 like Python.
bool lut_read_3dl(const std::string& path, std::vector<uint16_t>& out) {
    std::ifstream f(path);
    if (!f) { std::fprintf(stderr, "cannot open LUT %s\n", path.c_str()); return false; }
    constexpr int N = 256;
    size_t total = (size_t)N * N * N * 3;
    out.resize(total);
    size_t idx = 0;
    std::string line;
    while (idx < total && std::getline(f, line)) {
        int r, g, b;
        if (std::sscanf(line.c_str(), "%d %d %d", &r, &g, &b) == 3) {
            out[idx++] = (uint16_t)r;
            out[idx++] = (uint16_t)g;
            out[idx++] = (uint16_t)b;
        }
    }
    if (idx != total) {
        std::fprintf(stderr, "LUT %s: read %zu of %zu values\n", path.c_str(), idx, total);
        return false;
    }
    return true;
}

// 模型只由 LUT 生成；不读取图片，不启用多线程。
std::array<std::vector<uint8_t>, 4> bridge_models;
fc::ModelBundle bridge_bundle;
fc::Runtime bridge_runtime;
std::unique_ptr<uint8_t[]> bridge_arena;
int bridge_stage = 0, bridge_ref_counter = 0, bridge_image_counter = 0;
int bridge_m() { const char* p=std::getenv("FC_M"); return p ? std::atoi(p) : 17; }
std::string bridge_dir() { const char* p=std::getenv("FC_OUT"); if(!p) throw std::runtime_error("未指定输出目录"); return p; }
void bridge_save(const std::vector<uint8_t>& data,const std::string& name) {
    std::ofstream f(bridge_dir()+"/"+name,std::ios::binary);
    if(!f.write(reinterpret_cast<const char*>(data.data()),data.size())) throw std::runtime_error("保存失败");
}
void bridge_u32(std::vector<uint8_t>& v,uint32_t x) { for(int i=0;i<4;++i)v.push_back(uint8_t(x>>(8*i))); }
void bridge_f32(std::vector<uint8_t>& v,float x) { uint32_t u;std::memcpy(&u,&x,4);bridge_u32(v,u); }
bool bridge_sparse(const std::vector<uint16_t>& raw,int m,Lut3D& out) {
    if(m!=17 && m!=33) return false;
    const double start=now_sec();
    std::vector<int> axis(m);
    for(int i=0;i<m;++i)axis[i]=i*(256/(m-1));
    axis.back()=255;
    out.size=m; out.data.resize(size_t(m)*m*m*3);
    for(int r=0;r<m;++r)for(int g=0;g<m;++g)for(int b=0;b<m;++b) {
        const size_t src=((size_t(axis[b])*256+axis[g])*256+axis[r])*3;
        const size_t dst=((size_t(r)*m+g)*m+b)*3;
        for(int c=0;c<3;++c)out.data[dst+c]=uint8_t(raw[src+2-c]/16);
    }
    auto& blob=bridge_models.at(bridge_stage);
    blob={'S','L','U','T'};bridge_u32(blob,1);bridge_u32(blob,m);bridge_u32(blob,0);
    for(int a=0;a<3;++a)for(int x:axis)bridge_f32(blob,float(x));
    std::vector<uint32_t> frac;
    for(int a=0;a<3;++a)for(int x=0;x<256;++x) {
        int j=0;while(j<m-2 && x>=axis[j+1])++j;
        blob.push_back(uint8_t(j));
        const uint32_t den=axis[j+1]-axis[j];
        frac.push_back((uint32_t(x-axis[j])*65536u+den/2)/den);
    }
    for(auto q:frac)bridge_u32(blob,q);
    blob.insert(blob.end(),out.data.begin(),out.data.end());
    bridge_bundle.models[bridge_stage]={blob.data(),blob.size()};
    bridge_save(blob,"stage-"+std::to_string(bridge_stage+1)+".slut");
    std::printf("BRIDGE_SAMPLE stage=%d m=%d ms=%.6f bytes=%zu\n",bridge_stage+1,m,(now_sec()-start)*1000,blob.size());
    if(++bridge_stage==4) {
        fc::RuntimeConfig cfg;cfg.backend=fc::Backend::Scalar;cfg.threads=1;
        fc::Requirements req;
        auto s=fc::Runtime::requirements(bridge_bundle,cfg,&req);
        if(s!=fc::Status::Ok)throw std::runtime_error("容量查询失败");
        bridge_arena.reset(req.arena_bytes ? new uint8_t[req.arena_bytes] : nullptr);
        s=fc::Runtime::prepare(bridge_bundle,cfg,{bridge_arena.get(),req.arena_bytes},&bridge_runtime);
        if(s!=fc::Status::Ok)throw std::runtime_error("模型准备失败");
    }
    return true;
}
bool bridge_apply(const Image& img,Image& out) {
    out.H=img.H;out.W=img.W;out.C=3;out.data.resize(img.data.size());
    const auto s=bridge_runtime.apply(img.ptr(),img.data.size(),size_t(img.W)*3,out.ptr(),out.data.size(),size_t(img.W)*3,img.W,img.H);
    return s==fc::Status::Ok;
}

// Port of sparse_lut().
bool lut_sparse(const std::vector<uint16_t>& lut256, int lut_size, Lut3D& out) {
    return bridge_sparse(lut256, lut_size, out);
}

bool lut_sparse_ref(const std::vector<uint16_t>& lut256, int lut_size, Lut3D& out) {
    std::vector<int> sample_step(lut_size);
    int step = 256 / (lut_size - 1);
    for (int i = 0; i < lut_size; i++) sample_step[i] = i * step;
    sample_step[lut_size - 1] = 255;

    size_t total = (size_t)lut_size * lut_size * lut_size * 3;
    out.size = lut_size;
    out.data.resize(total);

    for (int b = 0; b < lut_size; b++) {
        for (int g = 0; g < lut_size; g++) {
            for (int r = 0; r < lut_size; r++) {
                size_t idx = ((size_t)sample_step[b] * 256 * 256
                            + (size_t)sample_step[g] * 256
                            + (size_t)sample_step[r]) * 3;
                size_t oidx = (((size_t)r * lut_size + g) * lut_size + b) * 3;
                out.data[oidx + 0] = (uint8_t)(lut256[idx + 2] / 16);
                out.data[oidx + 1] = (uint8_t)(lut256[idx + 1] / 16);
                out.data[oidx + 2] = (uint8_t)(lut256[idx + 0] / 16);
            }
        }
    }
    return true;
}

// apply_lut_256
bool apply_lut256(const Image& img, const Lut3D& lut, Image& out) {
    int N = lut.size;
    int H = img.H, W = img.W;
    out.H = H; out.W = W; out.C = 3;
    out.data.resize((size_t)H * W * 3);

    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            const uint8_t* pin = &img.ptr()[((size_t)y * W + x) * 3];
            int ir = (uint8_t)clamp_i(pin[0], 0, 255);
            int ig = (uint8_t)clamp_i(pin[1], 0, 255);
            int ib = (uint8_t)clamp_i(pin[2], 0, 255);
            const uint8_t* src = lut.at(ir, ig, ib);
            uint8_t* o = &out.ptr()[((size_t)y * W + x) * 3];
            o[0] = (uint8_t)clamp_i(src[0], 0, 255);
            o[1] = (uint8_t)clamp_i(src[1], 0, 255);
            o[2] = (uint8_t)clamp_i(src[2], 0, 255);
        }
    }
    return true;
}

// Apply 4 LUTs sequentially.
bool apply_3d_lut(const Image& img,
                  const Lut3D& l1, const Lut3D& l2,
                  const Lut3D& l3, const Lut3D& l4,
                  Image& out) {
    return bridge_apply(img, out);
}

bool apply_3d_lut_ref(const Image& img,
                  const Lut3D& l1, const Lut3D& l2,
                  const Lut3D& l3, const Lut3D& l4,
                  Image& out) {
    Image tmp0, tmp1;
    const Image* cur = &img;
    Image* nxt = &tmp0;
    if (!apply_lut256(*cur, l1, *nxt)) return false;
    cur = nxt; nxt = &tmp1;
    if (!apply_lut256(*cur, l2, *nxt)) return false;
    cur = nxt; nxt = &tmp0;
    if (!apply_lut256(*cur, l3, *nxt)) return false;
    cur = nxt; nxt = &tmp1;
    if (!apply_lut256(*cur, l4, *nxt)) return false;
    out = std::move(tmp1);
    bridge_save(out.data, "reference-" + std::to_string(++bridge_ref_counter) + ".bin");
    return true;
}

// ------------------------------------------------------------------
// color_dalta_calc -- average euclidean deltaE (matches Python)
// ------------------------------------------------------------------

double color_dalta_calc(const Image& a, const Image& b) {
    if (a.H != b.H || a.W != b.W || a.C != b.C) {
        std::fprintf(stderr, "image size mismatch\n");
        return -1.0;
    }
    const uint8_t* pa = a.ptr();
    const uint8_t* pb = b.ptr();
    double sum = 0.0;
    size_t n = (size_t)a.H * a.W;
    for (size_t i = 0; i < n; i++) {
        int r  = pa[i * 3 + 0] - pb[i * 3 + 0];
        int g  = pa[i * 3 + 1] - pb[i * 3 + 1];
        int bb = pa[i * 3 + 2] - pb[i * 3 + 2];
        sum += std::sqrt((double)r * r + (double)g * g + (double)bb * bb);
    }
    return sum / ((double)a.H * a.W);
}

// ------------------------------------------------------------------
// helpers
// ------------------------------------------------------------------

bool file_exists(const std::string& p) {
    struct stat st;
    return stat(p.c_str(), &st) == 0;
}

void print_time_now(const char* tag) {
    std::time_t t = std::time(nullptr);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    std::printf("%s: %s\n", tag, buf);
}

} // namespace

int official_main(int argc, char** argv) {
    std::string data_dir = "../data";
    if (argc >= 2) data_dir = argv[1];

    auto join = [&](const std::string& sub) {
        return data_dir + "/" + sub;
    };

    print_time_now("Start Time");

    // Read LUTs (Python main.py uses Test1.3DL for all 4)
    std::vector<std::string> lut_paths = {
        join("LUT/Test1.3DL"),
        join("LUT/Test2.3DL"),
        join("LUT/Test3.3DL"),
        join("LUT/Test4.3DL"),
    };
    std::array<std::vector<uint16_t>, 4> luts_raw;
    for (int i = 0; i < 4; i++) {
        if (!lut_read_3dl(lut_paths[i], luts_raw[i])) return 1;
    }

    print_time_now("getLut Time");

    std::array<Lut3D, 4> lut256, lut17;
    for (int i = 0; i < 4; i++) {
        if (!lut_sparse_ref(luts_raw[i], 256, lut256[i])) return 1;
        if (!lut_sparse(luts_raw[i], bridge_m(),  lut17[i]))  return 1;
    }
    // free raw 16-bit LUTs
    for (int i = 0; i < 4; i++) std::vector<uint16_t>().swap(luts_raw[i]);

    print_time_now("SpareLut Time");

    std::vector<double> deltas, perfs;
    deltas.reserve(MAX_IMAGES);
    perfs.reserve(MAX_IMAGES);

    for (int i = 1; i <= 4; i++) {
        std::string path = data_dir + "/image/" + std::to_string(i) + ".bin";
        if (!file_exists(path)) {
            deltas.push_back(255);
            perfs.push_back(255);
            continue;
        }

        Image img;
        if (!image_load_bin(path, img)) {
            std::fprintf(stderr, "skip %s (load failed)\n", path.c_str());
            deltas.push_back(255);
            perfs.push_back(255);
            continue;
        }

        double t0 = now_sec();
        Image result17;
        if (!apply_3d_lut(img, lut17[0], lut17[1], lut17[2], lut17[3], result17)) {
            deltas.push_back(255);
            perfs.push_back(255);
            continue;
        }
        double t1 = now_sec();
        double cost = t1 - t0;

        Image result256;
        if (!apply_3d_lut_ref(img, lut256[0], lut256[1], lut256[2], lut256[3], result256)) {
            deltas.push_back(255);
            perfs.push_back(255);
            continue;
        }

        double delta1 = color_dalta_calc(img, result256);
        double delta2 = color_dalta_calc(result256, result17);
        std::printf("Img: %s TimeCost: %.6f, Delta: %.6f %.6f\n",
                    path.c_str(), cost, delta1, delta2);

        deltas.push_back(delta2);
        perfs.push_back(cost);
    }

    print_time_now("End Time");

    return 0;
}

// 扩展验证独立于官方首次调用计时，保留所有重复样本。
std::vector<uint8_t> read_bytes(const std::string& p) {
    std::ifstream f(p,std::ios::binary|std::ios::ate);
    if(!f)throw std::runtime_error("读取文件失败");
    const auto n=f.tellg();f.seekg(0);std::vector<uint8_t> v(static_cast<size_t>(n));
    if(!f.read(reinterpret_cast<char*>(v.data()),n))throw std::runtime_error("读取不完整");return v;
}
int extended(const std::string& data) {
    std::setvbuf(stdout,nullptr,_IONBF,0);
    std::array<fc_model,4> cm{};const fc_model* ptrs[4];fc_chain cc{};
    for(int i=0;i<4;++i) {
        bridge_models[i]=read_bytes(bridge_dir()+"/stage-"+std::to_string(i+1)+".slut");
        bridge_bundle.models[i]={bridge_models[i].data(),bridge_models[i].size()};
        if(fc_model_init(&cm[i],{bridge_models[i].data(),bridge_models[i].size()},{nullptr,0})!=FC_OK)return 2;
        ptrs[i]=&cm[i];
    }
    if(fc_chain_init(&cc,ptrs)!=FC_OK)return 3;
    std::array<Image,4> images, refs;
    for(int i=0;i<4;++i) {
        if(!image_load_bin(data+"/image/"+std::to_string(i+1)+".bin",images[i]))return 4;
        refs[i]=images[i];refs[i].data=read_bytes(bridge_dir()+"/reference-"+std::to_string(i+1)+".bin");
        if(refs[i].data.size()!=images[i].data.size())return 5;
    }
    const size_t total=size_t(256)*256*256;
    std::vector<uint8_t> inputs(total*3),expected(total*3),actual(total*3);
    for(size_t i=0;i<total;++i){inputs[i*3]=uint8_t(i>>16);inputs[i*3+1]=uint8_t(i>>8);inputs[i*3+2]=uint8_t(i);}
    if(fc_apply_rgb8(&cc,inputs.data(),inputs.size(),total*3,expected.data(),expected.size(),total*3,total,1)!=FC_OK)return 6;
    std::printf("FULL_DOMAIN_C99 pixels=%zu\n",total);
    struct Entry {int backend,rep;std::unique_ptr<fc::Runtime> run;std::unique_ptr<uint8_t[]> arena;};
    std::vector<Entry> entries;
    for(int rep=0;rep<4;++rep)for(int backend=1;backend<=2;++backend) {
        fc::RuntimeConfig cfg;cfg.backend=static_cast<fc::Backend>(backend);cfg.representation=static_cast<fc::Representation>(rep);cfg.threads=1;
        fc::Requirements q;auto s=fc::Runtime::requirements(bridge_bundle,cfg,&q);
        if(s!=fc::Status::Ok){std::printf("FAIL_REQUIRE backend=%d rep=%d status=%u\n",backend,rep,unsigned(s));return 7;}
        Entry e;e.backend=backend;e.rep=rep;e.run.reset(new fc::Runtime);
        const double start=now_sec();e.arena.reset(q.arena_bytes ? new uint8_t[q.arena_bytes] : nullptr);
        s=fc::Runtime::prepare(bridge_bundle,cfg,{e.arena.get(),q.arena_bytes},e.run.get());
        const double prep=(now_sec()-start)*1000;
        if(s==fc::Status::Capacity && (rep==1||rep==2)){std::printf("NOT_APPLICABLE backend=%d rep=%d status=10 prepare_ms=%.6f\n",backend,rep,prep);continue;}
        if(s!=fc::Status::Ok){std::printf("FAIL_PREPARE backend=%d rep=%d status=%u\n",backend,rep,unsigned(s));return 8;}
        if(e.run->apply(inputs.data(),inputs.size(),total*3,actual.data(),actual.size(),total*3,total,1)!=fc::Status::Ok)return 9;
        if(actual!=expected){std::printf("FAIL_DOMAIN backend=%d rep=%d\n",backend,rep);return 10;}
        std::printf("CONFIG backend=%d rep=%d prepare_ms=%.6f model=%zu arena=%zu persistent=%zu temporary=%zu palette=%u cache=%d full_domain_equal=1\n",backend,rep,prep,q.model_bytes,q.arena_bytes,q.persistent_bytes,q.temporary_bytes,unsigned(e.run->palette_entries()),int(e.run->prepared_with_suffix_cache()));
        entries.push_back(std::move(e));
    }
    // 正确性、误差和输出落盘均在重复计时之外。
    std::array<Image,4> outputs;
    for(int i=0;i<4;++i)outputs[i]=images[i];
    for(auto& e:entries)for(int i=0;i<4;++i) {
        auto& in=images[i];auto& out=outputs[i];
        if(e.run->apply(in.ptr(),in.data.size(),size_t(in.W)*3,out.ptr(),out.data.size(),size_t(out.W)*3,in.W,in.H)!=fc::Status::Ok)return 11;
        size_t mismatch=0;for(size_t j=0;j<in.data.size()/3;++j) {
            const size_t ix=(size_t(in.data[3*j])<<16)|(size_t(in.data[3*j+1])<<8)|in.data[3*j+2];
            for(int c=0;c<3;++c)mismatch+=out.data[3*j+c]!=expected[3*ix+c];
        }
        if(mismatch)return 12;
        std::vector<double> errors;errors.reserve(size_t(in.W)*in.H);double sum=0;
        for(size_t j=0;j<out.data.size();j+=3){double sq=0;for(int c=0;c<3;++c){int d=int(out.data[j+c])-int(refs[i].data[j+c]);sq+=d*d;}double d=std::sqrt(sq);errors.push_back(d);sum+=d;}
        std::sort(errors.begin(),errors.end());
        const double official=color_dalta_calc(refs[i],out);
        if(std::abs(official-sum/errors.size())>1e-10)return 13;
        std::printf("QUALITY backend=%d rep=%d image=%d mean=%.12f p99=%.12f max=%.12f mismatch=0\n",e.backend,e.rep,i+1,official,errors[size_t(std::ceil(.99*errors.size()))-1],errors.back());
        if(e.backend==1&&e.rep==0)bridge_save(out.data,"candidate-"+std::to_string(i+1)+".bin");
    }
    // 一次预热与 9 个交错周期；每轮包含全部四图，排除分配、读盘与验证。
    for(int cycle=-1;cycle<9;++cycle)for(size_t j=0;j<entries.size();++j) {
        auto& e=entries[cycle%2==0 ? entries.size()-1-j : j];double all=0;
        for(int i=0;i<4;++i){auto& in=images[i];auto& out=outputs[i];const double t=now_sec();auto s=e.run->apply(in.ptr(),in.data.size(),size_t(in.W)*3,out.ptr(),out.data.size(),size_t(out.W)*3,in.W,in.H);double ms=(now_sec()-t)*1000;if(s!=fc::Status::Ok)return 14;all+=ms;if(cycle>=0)std::printf("TIME cycle=%d backend=%d rep=%d image=%d ms=%.9f\n",cycle,e.backend,e.rep,i+1,ms);}
        if(cycle>=0)std::printf("BATCH cycle=%d backend=%d rep=%d ms=%.9f\n",cycle,e.backend,e.rep,all);
    }
    std::puts("COMPLETED=1");return 0;
}
int main(int argc,char**argv) {
    try {if(argc==3&&std::string(argv[2])=="--extended")return extended(argv[1]);return official_main(argc,argv);}
    catch(const std::exception& e){std::fprintf(stderr,"测试异常：%s\n",e.what());return 99;}
}
