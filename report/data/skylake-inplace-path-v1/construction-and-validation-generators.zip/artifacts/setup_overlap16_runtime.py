"""冻结46：在45上只把首输入改为G/B二字节加载，避开刚写过的下一R。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-overlap-runtime';out=ROOT/'experiments/skylake-overlap16-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_overlap','skylake_overlap16').replace('avx2_chain_overlap','avx2_chain_overlap16')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 45;','jshc_cc_revision(void) {return 46;')
    if p.name=='channel_avx2.cpp':
        assert s.count('uint32_t a,b,c,d;')==1 and s.count('std::memcpy(&a,p,4);std::memcpy(&b,p+3,4);')==1
        s=s.replace('uint32_t a,b,c,d;','uint16_t gb;uint32_t b,c,d;')
        s=s.replace('std::memcpy(&a,p,4);std::memcpy(&b,p+3,4);','std::memcpy(&gb,p+1,2);std::memcpy(&b,p+3,4);')
        s=s.replace('(a&0xffff00u)|carry','(uint32_t(gb)<<8)|carry')
        s=s.replace('// 四个像素先完整读取；每个32bit写的最高字节临时覆盖下一像素R。','// 首像素只读尚未写过的G/B两字节，不读取上一组覆盖过的R；其余输入先读后写。')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-overlap-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；修正45首加载与之前重叠写的单字节交叠',candidate='仅将组首4字节加载+掩码改为p+1的2字节G/B加载，再并入carry；原表、展开、预取、写入及分离NT不变',revisions={'reference':23,'candidate':46},cmake_project='experiments/skylake-overlap16-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_overlap16'])
plan['overlap16_policy']={'old_first_read_relative_to_group':[0,4],'previous_last_write_relative_to_group':[-3,1],'old_intersection_bytes':[0],'new_first_read_relative_to_group':[1,3],'new_intersection_bytes':[],'arithmetic':'code=(uint32(gb)<<8)|carry','choice':'只修正一类重叠加载，不扫描其他展开参数','hypothesis':'45实汇编保留4字节读后AND掩码，可能触发部分store forwarding代价；二字节读消除该地址交叠，计数与墙钟分别验证'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-overlap-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-overlap16-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结46，未构建或计时')
