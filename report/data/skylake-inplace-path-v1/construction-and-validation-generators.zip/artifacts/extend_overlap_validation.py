"""首次像素验收前补充45的carry边界和R每像素变化的完整色域次序；构建源不变。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];assert not (ROOT/'artifacts/skylake-overlap-linux-full-v1').exists()
path=ROOT/'scripts/verify_skylake_overlap_linux.py';s=path.read_text(encoding='utf-8')
before=hashlib.sha256(path.read_bytes()).hexdigest()
old="for n in plan['contract']['lengths']:";assert s.count(old)==1
s=s.replace(old,"for n in sorted(set(plan['contract']['lengths'])|{3,4,5,6,67,68,69}):")
at=s.index('            loaded = []')
s=s[:at]+'''            # 原RGB顺序的R在一平面内不变；另将R作为最快轴完整遍历，以覆盖carry状态变化。
            perm_counts={key:0 for key in ('apply_1','apply_4','to_1','to_4')}
            perm_hashes={key:hashlib.sha256() for key in perm_counts};perm_truth_hash=hashlib.sha256()
            rseq=bytes(range(256))*256;gseq=bytes(g for g in range(256) for r in range(256))
            d=libraries['candidate'];h=operators['candidate']['chain']
            for blue in range(0,256,4):
                source=bytearray(4*65536*3)
                for j,b in enumerate(range(blue,blue+4)):
                    start=j*65536*3;end=start+65536*3
                    source[start:end:3]=rseq;source[start+1:end:3]=gseq;source[start+2:end:3]=bytes([b])*65536
                source=bytes(source)
                expected=b''.join(cube[(r*65536+g*256+b)*3:(r*65536+g*256+b)*3+3] for b in range(blue,blue+4) for g in range(256) for r in range(256))
                perm_truth_hash.update(expected)
                for threads in (1,4):
                    outputs_perm={'apply_'+str(threads):apply(d,h,source,1,threads,3),'to_'+str(threads):apply_to(d,h,source,1,threads,1,3)}
                    for key,actual in outputs_perm.items():
                        if actual!=expected:raise AssertionError('R最快轴完整色域carry输出不同')
                        perm_counts[key]+=4*65536;perm_hashes[key].update(actual)
            perm_outputs={key:value.hexdigest() for key,value in perm_hashes.items()}
            assert all(n==2**24 for n in perm_counts.values()) and all(v==perm_truth_hash.hexdigest() for v in perm_outputs.values())
'''+s[at:]
s=s.replace("'full_input_chunk_pixels':262144", "'carry_permutation_domain_pixels':perm_counts,'carry_permutation_output_sha256':perm_outputs,'carry_permutation_expected_sha256':perm_truth_hash.hexdigest(),'full_input_chunk_pixels':262144")
compile(s,str(path),'exec');path.write_bytes(s.encode('utf-8'))
p=ROOT/'experiments/skylake-overlap-validation-v1.json';v=json.loads(p.read_text(encoding='utf-8'));v['source_sha256'][path.relative_to(ROOT).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
v['purpose']+='；首次像素调用前增补R最快轴完整色域四配置，逐像素变化R检验carry；额外长度3/4/5/6/67/68/69'
v['refined_before_first_native_validation']={'previous_unexecuted_script_sha256':before,'extra_lengths':[3,4,5,6,67,68,69],'extra_full_domain_order':'B外/G中/R内','extra_full_configurations':['candidate_chain_apply_1','candidate_chain_apply_4','candidate_chain_to_1','candidate_chain_to_4'],'previous_pixel_calls':0}
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('首次像素调用前冻结45增强验证，未修改构建或原生源')
