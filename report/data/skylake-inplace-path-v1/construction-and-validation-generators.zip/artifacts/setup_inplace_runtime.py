"""冻结43：只将in-place对齐主体改为普通写；分离输出仍沿用40非临时写。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-inplace-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_inplace').replace('avx2_chain_batchspan','avx2_chain_inplace')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 43;')
    if p.name=='channel_avx2.cpp':
        s=s.replace('inline __attribute__((always_inline)) void output_four_stream(', 'template<bool Stream> inline __attribute__((always_inline)) void output_four_stream(')
        oldstores='''  _mm256_stream_si256(reinterpret_cast<__m256i*>(p),s0);
  _mm256_stream_si256(reinterpret_cast<__m256i*>(p+32),s1);
  _mm256_stream_si256(reinterpret_cast<__m256i*>(p+64),s2);'''
        assert oldstores in s
        newstores='''  if constexpr(Stream) {
    _mm256_stream_si256(reinterpret_cast<__m256i*>(p),s0);
    _mm256_stream_si256(reinterpret_cast<__m256i*>(p+32),s1);
    _mm256_stream_si256(reinterpret_cast<__m256i*>(p+64),s2);
  } else {
    // 原地输入刚被读取，普通对齐写复用缓存行；不依赖非临时写发布。
    _mm256_store_si256(reinterpret_cast<__m256i*>(p),s0);
    _mm256_store_si256(reinterpret_cast<__m256i*>(p+32),s1);
    _mm256_store_si256(reinterpret_cast<__m256i*>(p+64),s2);
  }'''
        s=s.replace(oldstores,newstores).replace('inline __attribute__((always_inline)) void run(', 'template<bool Stream> inline __attribute__((always_inline)) void run(')
        s=s.replace('output_four_stream(destination','output_four_stream<Stream>(destination').replace('streamed=true;','streamed=Stream;')
        s=s.replace('if(streamed)_mm_sfence();','if constexpr(Stream) {if(streamed)_mm_sfence();}')
        s=s.replace('先读后写，主体输出恰好192字节即三条完整缓存行','先读后写，主体输出恰好192字节即三条完整缓存行；写法按入口静态选择')
        s=s.replace('{run(table,palette,data,data,pixels);}','{run<false>(table,palette,data,data,pixels);}')
        s=s.replace('{run(table,palette,source,destination,pixels);}','{run<true>(table,palette,source,destination,pixels);}')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；只研究in-place普通缓存写，分离输出沿用40非临时写',candidate='按入口静态实例化run<false/true>，in-place主体对齐store不需SFENCE；source→destination保留NT，输入NTA/65536块/表格式不变',revisions={'reference':23,'candidate':43},cmake_project='experiments/skylake-inplace-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_inplace'])
plan['inplace_policy']={'format':9,'table_bytes':2**24,'inplace_stores':'普通32字节对齐存储','outplace_stores':'保留40完整缓存行非临时存储及SFENCE','dispatch':'两个公开入口静态选择，不增加逐像素分支','choice':'一次固定入口差异，不扫描阈值','hypothesis':'原地输入行可能已持有且被读取，普通写避免非临时写失效/回写成本；须同场测量，不预判收益'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-inplace-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结43，未构建或计时')
