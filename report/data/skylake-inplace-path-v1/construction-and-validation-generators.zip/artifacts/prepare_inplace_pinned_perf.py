"""冻结43首次配对计时；与40同策略，入口静态选写法，参考仍为23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_batchspan_pinned_linux.py').read_text(encoding='utf-8').replace('比较40与23','比较43与23').replace('bench_skylake_batchspan_pinned_linux.py','bench_skylake_inplace_pinned_linux.py').replace('40首次计时','43首次计时').replace('65536工作块输出索引','65536块原地普通写及分离NT输出索引')
new='scripts/bench_skylake_inplace_pinned_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=json.loads((ROOT/'experiments/skylake-batchspan-linux-perf-v1.json').read_text(encoding='utf-8'))
for key,path in {'plan':'experiments/skylake-inplace-v1.json','build':'artifacts/skylake-inplace-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-inplace-linux-full-v1/results.json','validation':'experiments/skylake-inplace-validation-v1.json','benchmark_script':new}.items():p[key]=spec(path)
p['purpose']='43只按入口静态选择普通原地写或NT分离写；首次四核绑定直接对23，不扫描阈值'
dest=ROOT/'experiments/skylake-inplace-linux-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结43首次性能，未计时')
