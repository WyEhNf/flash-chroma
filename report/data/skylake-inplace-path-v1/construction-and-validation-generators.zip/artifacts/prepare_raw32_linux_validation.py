"""冻结44独立RGB32物理次序完整解码、大块全域、保护页及对齐验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_batchspan_linux.py').read_text(encoding='utf-8').replace('RGB24精确大工作块40','RGB24精确直接RGB32加载44')
s=s.replace("direct_state['format']!=9 or direct_state['entries']!=2**22 or direct_state['table_capacity_bytes']!=2**24","direct_state['format']!=12 or direct_state['entries']!=2**24 or direct_state['table_capacity_bytes']!=2**26")
s=s.replace("pages_state['bytes']!=2**24","pages_state['bytes']!=2**26").replace('words=(ct.c_uint32*(2**22))()','words=(ct.c_uint32*(2**24))()')
a=s.index('                    raw_table=ct.string_at(words,2**24)');b=s.index('                    guard=(ct.c_uint32*8)',a)
s=s[:a]+'''                    # 独立按R/G/B坐标读取物理RGB32；不借用构造器中RGB索引表达式。
                    for r in range(256):
                        expected=cube[r*65536*3:(r+1)*65536*3]
                        actual=bytearray(65536*3)
                        for g in range(256):
                            row=b''.join(int(words[r+256*g+65536*b]).to_bytes(4,'little') for b in range(256))
                            if any(row[3::4]):raise AssertionError('RGB32最高字节非零')
                            start=g*256*3
                            actual[start:start+768:3]=row[0::4];actual[start+1:start+768:3]=row[1::4];actual[start+2:start+768:3]=row[2::4]
                        if actual!=expected:raise AssertionError('独立RGB坐标解码RGB32全域不同')
                    del old_words
'''+s[b:]
s=s.replace("memory['reference']['chain']==24+2**24","memory['reference']['chain']==24+2**26")
new='scripts/verify_skylake_raw32_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v={'purpose':'44全16M独立RGB32解码、24组完整色域、四大块/保护页/全对齐；不计时','plan_sha256':sha('experiments/skylake-raw32-v1.json'),'source_sha256':{k:sha(k) for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-raw32-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结44验证器，未调用像素入口')
