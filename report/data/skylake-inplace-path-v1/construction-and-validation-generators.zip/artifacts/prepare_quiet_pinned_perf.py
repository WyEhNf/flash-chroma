"""在首轮前冻结新空闲协议：只比较原40及修正46各一次，完整保留全部旧协议结果。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_batchspan_pinned_linux.py').read_text(encoding='utf-8')
s=s.replace('标准库在同一Linux主机直接比较40与23','标准库按来宾空闲前置条件直接比较冻结候选与23')
s=s.replace('比较40与23','比较冻结候选与23')
s=s.replace('bench_skylake_batchspan_pinned_linux.py','bench_skylake_quiet_pinned_linux.py')
s=s.replace('from pinned_openmp_support import', 'from quiet_host_support import require_quiet\nfrom pinned_openmp_support import')
s=s.replace("'pinning_support','pinning_probe')", "'pinning_support','pinning_probe','quiet_support')")
s=s.replace("'scripts/pinned_openmp_support.py','scripts/paged_table_support.py'", "'scripts/pinned_openmp_support.py','scripts/quiet_host_support.py','scripts/paged_table_support.py'")
old='    workers=[]\n    for index in range(4):'
new="""    quiet=policy['quiet_protocol']
    require_quiet(quiet,policy['affinity_cpus'],args.output,'quiet-parent',quiet['minimum_parent_settle_seconds'])
    workers=[]
    for index in range(4):
        require_quiet(quiet,policy['affinity_cpus'],args.output,f'quiet-worker{index}',0)"""
assert old in s;s=s.replace(old,new)
s=s.replace('40首次计时，固定绑定只运行一次；34失败记录另外保存，不混算','新空闲协议首次计时，各固定候选只运行一次；旧协议及失败记录全部另存，不混算')
s=s.replace('同Linux/AMD同场比较40与23','同Linux/AMD同场比较策略中候选与23')
new='scripts/bench_skylake_quiet_pinned_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
quiet={'minimum_parent_settle_seconds':120,'minimum_pid1_age_seconds':180,'sample_interval_seconds':5,'consecutive_good_intervals':2,'busy_percent_max':10,'timeout_seconds':600,'cpus':[0,2,4,6],'global_cpu_mean_also_required':True,'iowait_is_nonidle':True,'between_workers':'每个worker前再检查两个连续5秒空闲间隔，父进程保持WSL存活','on_failure':'保留部分数据并停止，不自动重跑择优','environment_change':'不调服务/频率/大页/安全策略，不改变模型或运行时代码'}
for name,revision in [('batchspan',40),('overlap16',46)]:
    p=read('experiments/skylake-batchspan-linux-perf-v1.json')
    if revision==46:
        for key,path in {'plan':'experiments/skylake-overlap16-v1.json','build':'artifacts/skylake-overlap16-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-overlap16-linux-full-v1/results.json','validation':'experiments/skylake-overlap16-validation-v1.json'}.items():p[key]=spec(path)
    p['benchmark_script']=spec(new);p['quiet_support']=spec('scripts/quiet_host_support.py');p['quiet_protocol']=quiet
    p['purpose']=f'来宾空闲协议v1，固定修订{revision}直接对23；在读取新协议结果前预定仅40和46各一次，旧全部保留；46首次性能只执行新协议'
    p['protocol_revision']='guest-quiet-v1';dest=ROOT/f'experiments/skylake-{name}-quiet-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
selection={'purpose':__doc__,'variants':[40,46],'policy_paths':['experiments/skylake-batchspan-quiet-perf-v1.json','experiments/skylake-overlap16-quiet-perf-v1.json'],'reason':'只读进程快照观察到WSL命令间重新启动及启动服务CPU工作，旧协议原样保留；新协议预先冻结不选取最快运行','prior_unexecuted_proposal':[40,45],'selection_refinement_before_any_quiet_measurement':'45有已验证的组间首加载/上一写入单字节交叠及严重纯映射回退，改测修正46；原45所有旧协议数据保留。46不再执行旧协议计时。','new_native_calls':0,'new_performance_calls':0}
out=ROOT/'artifacts/skylake-quiet-protocol-v1';out.mkdir(exist_ok=False);(out/'selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结空闲协议，仅40和46各一次，未调用像素入口')
observation={'purpose':'转录首次45计时启动前只读ps快照中的来宾启动状态，不重启或复现系统启动','command':'ps -eo pid,stat,pcpu,etime,comm','observed_pid1_elapsed':'00:13','rows':[{'pid':1,'comm':'systemd','pcpu_since_start':27.7,'elapsed':'00:13'},{'pid':65,'comm':'systemd-journal','pcpu_since_start':9.4,'elapsed':'00:10'},{'pid':108,'comm':'systemd-udevd','pcpu_since_start':19.4,'elapsed':'00:09'},{'pid':188,'comm':'snapd','pcpu_since_start':10.7,'elapsed':'00:07'},{'pid':304,'comm':'unattended-upgr','pcpu_since_start':15.1,'elapsed':'00:07'},{'pid':493,'comm':'systemd','pcpu_since_start':51.4,'elapsed':'00:01'}],'limitation':'ps百分比为进程存活期间平均，快照在计时前，不能证明具体计时轮受到竞争；据此预先增加新协议前置条件，不删除或否定旧回执','new_native_calls':0,'new_performance_calls':0}
(out/'boot-observation.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
