"""首次隔离配置执行前完成静态检查，非本模式计时数组使用None，保留未执行草稿。"""
from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'artifacts/skylake-isolated-protocol-v1'
assert not (ROOT/'artifacts/skylake-batchspan-isolated-perf-v1').exists()
script=ROOT/'scripts/bench_skylake_isolated_pinned_linux.py';policy_path=ROOT/'experiments/skylake-batchspan-isolated-perf-v1.json'
shutil.copyfile(script,out/'preflight-unexecuted-source.txt');shutil.copyfile(policy_path,out/'preflight-unexecuted-policy.json')
s=script.read_text(encoding='utf-8').replace('prepare+copy_apply_seconds[0]', '(prepare+copy_apply_seconds[0] if copy_apply_seconds else None)').replace('prepare+apply_seconds[0]', '(prepare+apply_seconds[0] if apply_seconds else None)')
s=s.replace("'api_mode':args.api_mode,'pid':os.getpid(),'parent_pid':os.getppid()", "'api_mode':args.api_mode,'parent_pid':os.getppid(),'primary_library_isolated':True")
tree=ast.parse(s)
for node in ast.walk(tree):
    if isinstance(node,ast.Dict):
        keys=[k.value for k in node.keys if isinstance(k,ast.Constant) and isinstance(k.value,str)]
        assert len(keys)==len(set(keys)),'静态字典重复键'
assert 'for threads in (args.worker_threads,):' in s and 'for role in (args.worker_role,):' in s and 'modes=[args.api_mode]' in s
assert "libraries={args.worker_role:" in s and "'primary_library_isolated':True" in s
compile(s,str(script),'exec');script.write_bytes(s.encode('utf-8'))
p=json.loads(policy_path.read_text(encoding='utf-8'));p['benchmark_script']['sha256']=hashlib.sha256(script.read_bytes()).hexdigest()
p['preflight_refinement']='首次运行前检查并修正单模式下另外两类空数组的首轮统计，去掉重复pid键；未执行旧草稿，没有性能数据被覆盖'
policy_path.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'preflight.json').write_text(json.dumps({'pass':True,'purpose':__doc__,'benchmark_script_sha256':p['benchmark_script']['sha256'],'policy_sha256':hashlib.sha256(policy_path.read_bytes()).hexdigest(),'previous_native_calls':0,'previous_performance_calls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('隔离驱动首次执行前静态检查通过')
