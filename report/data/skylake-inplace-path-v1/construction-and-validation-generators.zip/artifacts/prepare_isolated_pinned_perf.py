"""冻结最终进程隔离协议：每个角色/线程/API模式一个新进程，既有混合协议全部保留。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_quiet_pinned_linux.py').read_text(encoding='utf-8');s=s[:s.index('\ndef main():')]
s=s.replace('标准库按来宾空闲前置条件直接比较冻结候选与23','标准库以独立配置进程、来宾空闲前置条件比较40与23')
s=s.replace("libraries={name:bind(checked(spec)) for name,spec in build['libraries'].items()}","libraries={args.worker_role:bind(checked(build['libraries'][args.worker_role]))}")
s=s.replace("for threads in policy['thread_orders'][index]:",'for threads in (args.worker_threads,):').replace("for role in policy['orders'][index]:",'for role in (args.worker_role,):')
a=s.index('                ct.memmove(work,source_pointer,n)');b=s.index('                apply_seconds=',a)
s=s[:a]+'''                expected=policy['expected_output_sha256']
                if args.api_mode=='legacy':
                    ct.memmove(work,source_pointer,n)
                    if d.jshc_cc_apply(handle,work,n,1,threads,error,len(error)):raise RuntimeError(error.value.decode())
                else:
                    if d.jshc_cc_apply_to(handle,source_pointer,work,n,1,threads,error,len(error)):raise RuntimeError(error.value.decode())
                warm=output_hash()
                if warm!=expected:raise AssertionError('独立模式预热完整输出不同')
'''+s[b:]
s=s.replace("modes=['legacy','outplace'] if (index+round_index)%2==0 else ['outplace','legacy']",'modes=[args.api_mode]')
s=s.replace('prepare+outplace_seconds[0]', '(prepare+outplace_seconds[0] if outplace_seconds else None)')
s=s.replace('prepare+copy_apply_seconds[0]', '(prepare+copy_apply_seconds[0] if copy_apply_seconds else None)')
s=s.replace('prepare+apply_seconds[0]', '(prepare+apply_seconds[0] if apply_seconds else None)')
s=s.replace("'order':policy['orders'][index]", "'order':[args.worker_role],'role':args.worker_role,'api_mode':args.api_mode,'parent_pid':os.getppid(),'primary_library_isolated':True")
s=s.replace("'thread_order':policy['thread_orders'][index]", "'thread_order':[args.worker_threads]")
s=s.replace("'libraries':build['libraries']", "'libraries':{args.worker_role:build['libraries'][args.worker_role]}")
s=s.replace("loaded([*build['libraries'].values(),policy['driver']])", "loaded([build['libraries'][args.worker_role],policy['driver']])")
at=s.index('    initial_team=pinned_probe')
s=s[:at]+'''    other='candidate' if args.worker_role=='reference' else 'reference'
    maps=Path('/proc/self/maps').read_text()
    if str(checked(build['libraries'][other])) in maps:raise ValueError('独立配置进程加载了另一角色的主库')
'''+s[at:]
s+='''
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--policy',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--worker-index',type=int);p.add_argument('--worker-role',choices=['reference','candidate'])
    p.add_argument('--worker-threads',type=int,choices=[1,4]);p.add_argument('--api-mode',choices=['legacy','outplace'])
    args=p.parse_args();policy=read(args.policy)
    for key in ('plan','build','full_acceptance','photos','driver','validation','benchmark_script','pinning_support','pinning_probe','quiet_support'):checked(policy[key])
    if args.output.exists():raise ValueError('不得覆盖或重试既有隔离性能输出')
    if args.worker_index is not None:
        if args.worker_role is None or args.worker_threads is None or args.api_mode is None:raise ValueError('子进程必须恰好指定一个角色、线程数和API模式')
        save(args.output,worker(args,policy));print('完成独立子配置',args.worker_index,args.worker_role,args.worker_threads,args.api_mode,flush=True);return
    assert policy['protocol_revision']=='isolated-config-v1' and policy['process_isolation']['dimensions']==['role','threads','api_mode']
    assert policy['orders']==[['reference','candidate'],['candidate','reference'],['candidate','reference'],['reference','candidate']] and policy['repeats']==5
    args.output.mkdir(parents=True)
    plan=read(checked(policy['plan']));names=[*plan['source_sha256'],'scripts/bench_skylake_isolated_pinned_linux.py','scripts/quiet_host_support.py','scripts/pinned_openmp_support.py','scripts/paged_table_support.py','scripts/outplace_support.py','scripts/skylake_server_support.py','scripts/verify_skylake_linux_stdlib.py',args.policy.resolve().relative_to(ROOT).as_posix()]
    sources={name:digest(ROOT/name) for name in sorted(set(names))}
    save(args.output/'run.json',{'purpose':__doc__,'policy':policy,'source_sha256':sources,'environment':environment(),'scope':'同Linux/AMD，32个串行独立配置进程，每配置5轮100图；不外推Skylake，不含I/O、分配、SHA，不混算旧协议'})
    with zipfile.ZipFile(args.output/'measured-source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in sources:z.write(ROOT/name,name)
    env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',OMP_PROC_BIND='TRUE',OMP_PLACES=places(policy['affinity_cpus']),OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1');env.pop('GOMP_CPU_AFFINITY',None)
    q=policy['quiet_protocol'];require_quiet(q,policy['affinity_cpus'],args.output,'quiet-parent',q['minimum_parent_settle_seconds'])
    pairs=[];children={};pids=[]
    for index in range(4):
        configs={};records=[]
        for threads in policy['thread_orders'][index]:
            for role in policy['orders'][index]:
                for mode in policy['mode_orders'][index]:
                    key=f'p{index}-t{threads}-{role}-{mode}';path=args.output/(key+'.json')
                    require_quiet(q,policy['affinity_cpus'],args.output,'quiet-'+key,0)
                    command=[sys.executable,'-u',str(Path(__file__).resolve()),'--policy',str(args.policy.resolve()),'--output',str(path.resolve()),'--worker-index',str(index),'--worker-role',role,'--worker-threads',str(threads),'--api-mode',mode]
                    proc=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True)
                    (args.output/(key+'.stdout.log')).write_text(proc.stdout,encoding='utf-8');(args.output/(key+'.stderr.log')).write_text(proc.stderr,encoding='utf-8')
                    if proc.returncode:raise RuntimeError('独立子配置失败，保留全部部分数据：'+proc.stderr)
                    child=read(path);assert len(child['records'])==1
                    configs[(threads,role,mode)]=child;children[key]=digest(path);pids.append(child['pid'])
                    print('完成独立配置',len(children),'/32',key,flush=True)
        for threads in (1,4):
            for role in ('reference','candidate'):
                legacy=configs[(threads,role,'legacy')]['records'][0];out=configs[(threads,role,'outplace')]['records'][0]
                assert legacy['model_accounting_bytes']==out['model_accounting_bytes'] and legacy['library_sha256']==out['library_sha256']
                records.append({'variant':role,'requested_threads':threads,'apply_seconds':legacy['apply_seconds'],'legacy_copy_apply_seconds':legacy['legacy_copy_apply_seconds'],'outplace_seconds':out['outplace_seconds'],'prepare_wall_seconds':out['prepare_wall_seconds'],'prepare_plus_first_100_outplace_seconds':out['prepare_plus_first_100_outplace_seconds'],'model_accounting_bytes':out['model_accounting_bytes'],'measurement_sources':{mode:{'file':f'p{index}-t{threads}-{role}-{mode}.json','sha256':children[f'p{index}-t{threads}-{role}-{mode}'],'pid':configs[(threads,role,mode)]['pid']} for mode in ('legacy','outplace')}})
        pair={'kind':'derived_pair_of_independent_configuration_processes','pair_index':index,'order':policy['orders'][index],'thread_order':policy['thread_orders'][index],'mode_order':policy['mode_orders'][index],'records':records}
        pairs.append(pair);save(args.output/f'pair{index}.json',pair)
    assert len(children)==32 and len(set(pids))==32
    paired=[];summary=[];failed=[];g=policy['adoption_gate']
    for threads in (1,4):
        matches=[{r['variant']:r for r in pair['records'] if r['requested_threads']==threads} for pair in pairs];row={'requested_threads':threads}
        for key,label in [('apply_seconds','apply'),('legacy_copy_apply_seconds','legacy_copy_apply'),('outplace_seconds','outplace')]:
            ratios=[statistics.median(m['candidate'][key])/statistics.median(m['reference'][key]) for m in matches]
            row['pair_'+label+'_ratios']=ratios;row['median_'+label+'_ratio']=statistics.median(ratios)
        prep=[m['candidate']['prepare_plus_first_100_outplace_seconds']/m['reference']['prepare_plus_first_100_outplace_seconds'] for m in matches];row['pair_prepare_plus_100_outplace_ratios']=prep;row['median_prepare_plus_100_outplace_ratio']=statistics.median(prep)
        if row['median_apply_ratio']>g['median_apply_ratio_max']:failed.append(f'{threads}线程纯映射未达3倍')
        if row['median_outplace_ratio']>g['median_outplace_ratio_max']:failed.append(f'{threads}线程真实输出未达3倍')
        if max(row['pair_apply_ratios'])>g['any_process_apply_ratio_max']:failed.append(f'{threads}线程某配对回退超限')
        if statistics.median(prep)>g['median_prepare_plus_100_ratio_max']:failed.append(f'{threads}线程准备加首组回退')
        paired.append(row)
        for role in ('reference','candidate'):
            summary.append({'variant':role,'requested_threads':threads,**{'median_'+label+'_ms_per_image':statistics.median(statistics.median(m[role][key])*10 for m in matches) for key,label in [('apply_seconds','apply'),('legacy_copy_apply_seconds','legacy_copy_apply'),('outplace_seconds','outplace')]},'prepare_wall_seconds':[m[role]['prepare_wall_seconds'] for m in matches],'model_accounting_bytes':matches[0][role]['model_accounting_bytes']})
    for name,digest_before in sources.items():assert digest(ROOT/name)==digest_before,name
    result={'measurement_completed':True,'accepted_on_this_host':not failed,'failed_gates':failed,'paired':paired,'summary':summary,'child_sha256':children,'pair_sha256':[digest(args.output/f'pair{i}.json') for i in range(4)],'independent_child_processes':32,'unique_pids':pids,'mode_rounds':{'legacy':80,'outplace':80},'frequency_and_temperature_controlled':False,'scope':'每角色、线程、API模式独立进程，只加载自己的主库，避免不同实现的分配/大页/加载状态在同进程延续；来宾空闲不等于宿主独占，实际Skylake未测'}
    save(args.output/'results.json',result);print('隔离协议完成',result['accepted_on_this_host'],paired,flush=True)
if __name__=='__main__':main()
'''
new='scripts/bench_skylake_isolated_pinned_linux.py';assert not (ROOT/new).exists();compile(s,new,'exec');(ROOT/new).write_bytes(s.encode('utf-8'))
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=read('experiments/skylake-batchspan-quiet-perf-v1.json');p['benchmark_script']=spec(new);p['protocol_revision']='isolated-config-v1';p['mode_orders']=[['legacy','outplace'],['outplace','legacy'],['legacy','outplace'],['outplace','legacy']]
p['process_isolation']={'dimensions':['role','threads','api_mode'],'primary_library_per_child':1,'children_per_series':32,'paired_replicates':4,'one_process_one_configuration':True,'quiet_before_every_child':True}
p['purpose']='最终确认协议：40与23每角色/线程/API模式隔离进程，全部旧混合协议保留；不以有利旧点结案'
p['completion_rule']={'first_and_one_confirmation_must_both_pass':True,'pooled_eight_pairs_must_pass':True,'confirmation_only_if_first_passes':True,'no_retiming_same_code_on_failure':True,'supersedes_unexecuted_mixed_confirmation':'experiments/skylake-batchspan-quiet-confirm-v1.json','reason':'46和40真实输出比值随A/B顺序变化明显，同进程可能有分配/大页/动态加载等状态延续；原因尚未专门证明，先以隔离消除可能串扰'}
dest=ROOT/'experiments/skylake-batchspan-isolated-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
out=ROOT/'artifacts/skylake-isolated-protocol-v1';out.mkdir(exist_ok=False);(out/'selection.json').write_text(json.dumps({'purpose':__doc__,'candidate_revision':40,'old_mixed_confirmation_executed':False,'final_adoption_requires_isolated_first_and_confirmation':True,'new_native_calls':0,'new_performance_calls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结独立配置协议及唯一最终确认规则，未调用像素入口')
