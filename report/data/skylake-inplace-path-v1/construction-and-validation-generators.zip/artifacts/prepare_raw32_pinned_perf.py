"""冻结44首次四进程计时，64MiB直接RGB32加载，参考仍为23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_batchspan_pinned_linux.py').read_text(encoding='utf-8').replace('比较40与23','比较44与23').replace('bench_skylake_batchspan_pinned_linux.py','bench_skylake_raw32_pinned_linux.py').replace('40首次计时','44首次计时').replace('16MiB精确小端输入NTA输出索引','64MiB精确小端RGB32直接输出')
s=s.replace("state['format']!=9", "state['format']!=12").replace("state['table_capacity_bytes']!=2**24", "state['table_capacity_bytes']!=2**26")
new='scripts/bench_skylake_raw32_pinned_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=json.loads((ROOT/'experiments/skylake-batchspan-linux-perf-v1.json').read_text(encoding='utf-8'))
for key,path in {'plan':'experiments/skylake-raw32-v1.json','build':'artifacts/skylake-raw32-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-raw32-linux-full-v1/results.json','validation':'experiments/skylake-raw32-validation-v1.json','benchmark_script':new}.items():p[key]=spec(path)
p['purpose']='44固定RGB32普通加载换容量；首次四核绑定直接对23，不扫描格式参数'
dest=ROOT/'experiments/skylake-raw32-linux-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结44首次性能，未计时')
