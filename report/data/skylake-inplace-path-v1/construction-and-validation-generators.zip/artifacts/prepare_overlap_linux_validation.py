"""冻结45覆盖carry和重叠写边界的完整域验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
new='scripts/verify_skylake_overlap_linux.py';s=(ROOT/'scripts/verify_skylake_batchspan_linux.py').read_text(encoding='utf-8').replace('RGB24精确大工作块40','RGB24精确重叠普通写45')
assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v={'purpose':'45全16M独立表解码、24组完整色域，全部64种对齐、保护页/大块边界；固定长度含4/5与64/65及前后值，不计时','plan_sha256':sha('experiments/skylake-overlap-v1.json'),'source_sha256':{k:sha(k) for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-overlap-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结45验证器，未调用像素入口')
