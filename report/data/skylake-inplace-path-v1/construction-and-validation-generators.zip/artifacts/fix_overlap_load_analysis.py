"""保留静态首版计数断言失败；尾部已有一次movzwl，改核对两版差值。"""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1];script=ROOT/'scripts/inspect_skylake_overlap_loads.py';out=ROOT/'artifacts/skylake-overlap-forwarding-v1';out.mkdir(exist_ok=False)
shutil.copyfile(script,out/'first-analysis-source.txt');old_sha=hashlib.sha256(script.read_bytes()).hexdigest()
s=script.read_text(encoding='utf-8').replace("old['first_function_movzwl_count']==0", "old['first_function_movzwl_count']==1").replace("new['first_function_movzwl_count']==17", "new['first_function_movzwl_count']-old['first_function_movzwl_count']==17")
compile(s,str(script),'exec');script.write_bytes(s.encode('utf-8'))
note={'purpose':__doc__,'exit_code':1,'first_script_sha256':old_sha,'observed_old':{'group_mask_ffff00':17,'movzwl_total':1},'observed_new':{'group_mask_ffff00':0,'movzwl_total':18},'reason':'整函数中精确标量尾部也有一次16位加载，首版把整函数movzwl计数误当成只有组首；实际差值17与16个展开组+一个短循环一致','runtime_or_benchmark_changes':False,'new_native_calls':0,'new_performance_calls':0}
(out/'first-analysis-failure.json').write_text(json.dumps(note,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('静态计数首版失败已保存，运行时不变')
