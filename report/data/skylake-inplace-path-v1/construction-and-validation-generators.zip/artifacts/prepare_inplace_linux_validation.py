"""冻结43普通原地写/NT分离写验证器，大块全域及全部64种对齐。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
new='scripts/verify_skylake_inplace_linux.py';s=(ROOT/'scripts/verify_skylake_batchspan_linux.py').read_text(encoding='utf-8').replace('RGB24精确大工作块40','RGB24精确原地普通写43')
assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v={'purpose':'43原地普通写及分离NT完整域、保护页、别名、全对齐；固定262144像素覆盖四大块，不计时','plan_sha256':sha('experiments/skylake-inplace-v1.json'),'source_sha256':{k:sha(k) for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-inplace-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结43验证，未调用像素入口')
