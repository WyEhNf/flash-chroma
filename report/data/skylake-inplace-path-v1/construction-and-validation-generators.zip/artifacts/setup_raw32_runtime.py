"""冻结44：在40上直接GPR读取RGB32，删除像素路径的ID→调色板依赖。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-raw32-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_raw32').replace('avx2_chain_batchspan','avx2_chain_raw32')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 44;')
        a=s.index('      // 四个输入ID');b=s.index('      info.temporary_peak_bytes+=h.direct_index.bytes();',a)
        s=s[:a]+'''      // 物理次序R低/G中/B高；每个输入直接保存精确RGB32，不经ID查palette。
      h.direct_index.allocate(size_t{1}<<24);
#if defined(_OPENMP)
#pragma omp parallel for schedule(static) num_threads(4)
#endif
      for(long long address=0;address<(1LL<<24);++address) {
        const size_t i=((size_t(address)&255u)<<16)|(size_t(address)&0xff00u)|(size_t(address)>>16);
        h.direct_index.data()[size_t(address)]=uint32_t(rgb[3*i])|(uint32_t(rgb[3*i+1])<<8)|(uint32_t(rgb[3*i+2])<<16);
      }
'''+s[b:]
        s=s.replace('uint32_t(!h.direct_index.empty()),9,0,','uint32_t(!h.direct_index.empty()),12,0,')
    if p.name=='channel_avx2.cpp':
        s=s.replace('// 精确全域字节索引：四包独立读取先行，按RGB24读取合法对齐词。','// 精确RGB32直表：每像素一次表读取，沿用40的输入提示和完整行输出。')
        s=s.replace('palette[reinterpret_cast<const uint8_t*>(table)[code]]','table[code]').replace('palette[reinterpret_cast<const uint8_t*>(table)[code&0xffffff]]','table[code&0xffffff]')
        s=s.replace('[table,palette](uint32_t code)','[table](uint32_t code)').replace('[table,palette,p](size_t offset)','[table,p](size_t offset)')
        for signature in ('__m256i read(', '__m256i read_wide(', 'void scalar_one('):
            a=s.index(signature);b=s.index('{',a);s=s[:b+1]+'\n  (void)palette;'+s[b+1:]
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；64MiB RGB32直接GPR加载，去掉依赖的palette读取',candidate='沿用40原地/分离NT、输入NTA和65536块；每输入code只查一个RGB32表词，额外48MiB容量换少一次依赖读取',revisions={'reference':23,'candidate':44},cmake_project='experiments/skylake-raw32-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_raw32'])
plan['raw32_policy']={'format':12,'entries':2**24,'table_bytes':2**26,'input_order':'R低/G中/B高','output_word':'R低/G中/B高/最高字节0','tail_guard_bytes':0,'model_accounting_delta_vs23':24+2**26,'choice':'一次固定RGB32普通加载，不扫描缓存提示或块长','hypothesis':'消除ID到palette依赖和每像素一次L1加载；较大表可能增加缓存/TLB代价，实测决定'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-raw32-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结44，未构建或计时')
