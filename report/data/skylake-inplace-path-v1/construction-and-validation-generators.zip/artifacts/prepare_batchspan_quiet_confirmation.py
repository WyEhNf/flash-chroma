"""冻结40独立确认：首次新协议通过后只确认一次，两个独立系列都须通过且池化门槛通过。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
first='artifacts/skylake-batchspan-quiet-perf-v1/results.json';audit='artifacts/skylake-batchspan-quiet-perf-v1/quiet-audit-v1.json'
assert read(first)['accepted_on_this_host'] and read(audit)['pass'] and read(audit)['accepted_on_this_host']
p=read('experiments/skylake-batchspan-quiet-perf-v1.json');p['confirmation_of']=spec(first);p['first_quiet_audit']=spec(audit)
p['purpose']='40新空闲协议独立确认；保留原始旧协议失败与首次新协议通过；一次ABBA确认，不选择最快，不在失败后反复确认'
p['confirmation_rule']={'execute_once':True,'order':'在预定46首次新协议性能结束之后','series_acceptance':'首次40与本次确认各自完整门槛均通过','pooled_acceptance':'8进程配对中位纯apply及真实输出1/4线程比≤1/3，任一纯apply进程比≤0.9，准备+首组中位比≤1','on_failure':'整体目标继续，不丢弃此次失败或重跑同代码择优','reason':'首次新协议40通过，而旧协议未达且进程间波动明显；新增独立确认用于完成审计，不以一次有利结果宣布完成'}
dest=ROOT/'experiments/skylake-batchspan-quiet-confirm-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结40一次独立确认及更强完成门槛，未计时')
