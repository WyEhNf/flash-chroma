"""冻结40/45配对计数，检验原地GPR重叠写，分离接口不计数。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/profile_skylake_sourcehint_pmu.py').read_text(encoding='utf-8').replace('37/38','40/45')
new='scripts/profile_skylake_overlap_pmu.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference40','batchspan',40),('overlap45','overlap',45)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-overlap-v1.json');p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference40','overlap45']},{'threads':4,'variants':['overlap45','reference40']}]
p['purpose']='40直接对45原地GPR重叠写的单次用户态计数；不替代ABBA速度，不跨画像相除'
dest=ROOT/'experiments/skylake-overlap-pmu-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结45配对计数，未调用候选')
