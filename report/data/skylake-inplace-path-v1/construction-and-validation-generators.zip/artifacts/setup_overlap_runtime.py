"""冻结45：16MiB字节表不变，原地GPR重叠写保存下一输入R，分离仍为40。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-overlap-runtime';out.mkdir(exist_ok=False)
helper='''namespace {
// 四个像素先完整读取；每个32bit写的最高字节临时覆盖下一像素R。
// d的最高字节在写入前保存为carry，下一组首输入以该字节复原。
inline __attribute__((always_inline)) uint8_t overlap_four(const uint8_t* table,const uint32_t* palette,uint8_t* p,uint8_t carry) {
  uint32_t a,b,c,d;
  std::memcpy(&a,p,4);std::memcpy(&b,p+3,4);std::memcpy(&c,p+6,4);std::memcpy(&d,p+9,4);
  const uint32_t v0=palette[table[(a&0xffff00u)|carry]],v1=palette[table[b&0xffffffu]];
  const uint32_t v2=palette[table[c&0xffffffu]],v3=palette[table[d&0xffffffu]];
  const uint8_t next=uint8_t(d>>24);
  std::memcpy(p,&v0,4);std::memcpy(p+3,&v1,4);std::memcpy(p+6,&v2,4);std::memcpy(p+9,&v3,4);
  return next;
}
template<size_t... I> inline __attribute__((always_inline)) uint8_t overlap_group(const uint8_t* table,const uint32_t* palette,uint8_t* p,uint8_t carry,std::index_sequence<I...>) {
  ((carry=overlap_four(table,palette,p+12*I,carry)),...);return carry;
}
inline __attribute__((always_inline)) void run_overlap(const uint32_t* words,const uint32_t* palette,uint8_t* data,size_t pixels) noexcept {
  if(!pixels)return;
  const uint8_t* table=reinterpret_cast<const uint8_t*>(words);uint8_t carry=data[0];size_t p=0;
  const size_t initial=pixels*3<1024?pixels*3:1024;
  for(size_t offset=0;offset<initial;offset+=64)_mm_prefetch(reinterpret_cast<const char*>(data+offset),_MM_HINT_NTA);
  // 至少剩一个像素，确保最后一次32bit写和下一R读取仍在本线程块中。
  for(;p+65<=pixels;p+=64) {
    if(p+406<=pixels) {
      const uint8_t* future=data+3*p+1024;
      _mm_prefetch(reinterpret_cast<const char*>(future),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+64),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+128),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+191),_MM_HINT_NTA);
    }
    carry=overlap_group(table,palette,data+3*p,carry,std::make_index_sequence<16>{});
  }
  for(;p+5<=pixels;p+=4)carry=overlap_four(table,palette,data+3*p,carry);
  // 第一尾像素R来自carry，其后普通三字节写不再覆盖下一输入。
  for(;p<pixels;++p) {
    const uint32_t code=uint32_t(carry)|(uint32_t(data[3*p+1])<<8)|(uint32_t(data[3*p+2])<<16);
    const uint32_t value=palette[table[code]];
    if(p+1<pixels)carry=data[3*p+3];
    data[3*p]=uint8_t(value);data[3*p+1]=uint8_t(value>>8);data[3*p+2]=uint8_t(value>>16);
  }
}
}
'''
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_overlap').replace('avx2_chain_batchspan','avx2_chain_overlap')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 45;')
    if p.name=='channel_avx2.cpp':
        s=s.replace('#include <cstring>','#include <cstring>\n#include <utility>')
        a=s.index('void avx2_chain_overlap(');s=s[:a]+helper+s[a:]
        s=s.replace('{run(table,palette,data,data,pixels);}','{run_overlap(table,palette,data,pixels);}')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；原地GPR重叠32bit写和输入R保存，分离输出保留40',candidate='4像素先读后写，每次32bit写覆盖下一R，由写前保存的carry复原；64像素静态展开，尾部精确三字节；仅原地入口改变',revisions={'reference':23,'candidate':45},cmake_project='experiments/skylake-overlap-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_overlap'])
plan['overlap_policy']={'format':9,'table_bytes':2**24,'group_pixels':4,'outer_pixels':64,'outer_min_remaining':65,'group_min_remaining':5,'tail_stores':'精确3字节，首像素R来自carry','same_thread_boundary':'任何4字节读/写不越过当前工作块，最后1至4像素走精确尾部','outplace':'40原NT代码，精确同址仍经公开apply分派新原地入口','isa':'原地主体为GPR及输入预取，由既有AVX2研究入口选择；分离仍使用AVX2','choice':'一次固定重叠写方案，无阈值扫描','hypothesis':'去掉原地向量组装/输出shuffle，增加重叠普通写及carry成本，需实测'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-overlap-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结45，未构建或计时')
