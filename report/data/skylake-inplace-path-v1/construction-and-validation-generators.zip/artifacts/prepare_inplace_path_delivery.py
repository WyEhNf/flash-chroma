"""准备43—46与新空闲协议的离线审计；不调用原生库或重新计时。"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'artifacts/skylake-inplace-path-delivery-v1'
s=(ROOT/'artifacts/skylake-cache-hints-delivery-v1/check_remote.py').read_text(encoding='utf-8')
s=s.replace('skylake-load-packing-delivery-v1/pre-create','skylake-cache-hints-delivery-v1/pre-create').replace('report/data/skylake-load-packing-v1/remote-check.json','report/data/skylake-cache-hints-v1/remote-check.json')
s=s.replace("'acaf2b2']","'acaf2b2','1c955ca']")
s=s.replace("'https://github.com/WyEhNf/flash-chroma/pull/48','status':'依赖acaf2b2检查点；完整正文已读，新接口4线程3.0283倍为旧阶段单项证据；常规CI成功不代替实验验收'","'https://github.com/WyEhNf/flash-chroma/pull/49','status':'依赖1c955ca检查点；完整正文与原发送文本核对，两项常规CI成功不代替实验验收；40/41新接口单项达标，整体仍未完成'")
s=s.replace('38—42均保留全部门槛与失败，不以新接口单项达标代替整体','43—46及新空闲协议保留全部门槛与负结果，不以新接口单项达标代替整体')
(HERE/'check_remote.py').write_bytes(s.encode('utf-8'));compile(s,'check_remote.py','exec')
s=(ROOT/'artifacts/skylake-cache-hints-delivery-v1/compare_refresh.py').read_text(encoding='utf-8').replace('新PR48','新PR49').replace('新增48','新增49').replace('包含48','包含49').replace('issues-48-','issues-49-').replace('pulls-48-','pulls-49-').replace("['p48']","['p49']").replace('42PR','43PR').replace('128组REST','131组REST').replace('report/data/skylake-cache-hints-v1','report/data/skylake-inplace-path-v1')
(HERE/'compare_refresh.py').write_bytes(s.encode('utf-8'));compile(s,'compare_refresh.py','exec')
s=(ROOT/'scripts/audit_skylake_cache_hints.py').read_text(encoding='utf-8').replace('38—42、失败容量断言与五组配对PMU画像','43—46、新空闲协议及四组配对PMU画像')
a=s.index('CASES=');b=s.index('\nEXPECTED=',a)
s=s[:a]+"CASES=[('inplace',43,'artifacts/skylake-inplace-linux-perf-v1'),('raw32',44,'artifacts/skylake-raw32-linux-perf-v1'),('overlap',45,'artifacts/skylake-overlap-linux-perf-v1'),('batchspan',40,'artifacts/skylake-batchspan-quiet-perf-v1'),('overlap16',46,'artifacts/skylake-overlap16-quiet-perf-v1')]"+s[b:]
s=s.replace('for name,revision,version in CASES:', 'for name,revision,folder_name in CASES:')
s=s.replace("folder=ROOT/f'artifacts/skylake-{name}-linux-perf-v{version}'", 'folder=ROOT/folder_name')
s=s.replace('payload=2**23 if revision==42 else 2**24', 'payload=2**26 if revision==44 else 2**24')
s=s.replace('if revision in (40,42):assert', 'if revision in (40,43,44,45,46):assert')
s=s.replace("        assert not result['accepted_on_this_host']", """        gate=policy['adoption_gate'];accepted=True
        for row in stats:
            original=next(x for x in result['paired'] if x['requested_threads']==row['requested_threads'])
            accepted=accepted and row['apply_ratio']<=gate['median_apply_ratio_max'] and row['outplace_ratio']<=gate['median_outplace_ratio_max'] and max(original['process_apply_ratios'])<=gate['any_process_apply_ratio_max'] and row['prepare_plus_100_outplace_ratio']<=gate['median_prepare_plus_100_ratio_max']
        assert result['accepted_on_this_host']==accepted
        if revision in (45,46):
            assert set(full['carry_permutation_domain_pixels'])=={'apply_1','apply_4','to_1','to_4'}
            assert all(x==2**24 for x in full['carry_permutation_domain_pixels'].values())
            assert all(x==full['carry_permutation_expected_sha256'] for x in full['carry_permutation_output_sha256'].values())
        if 'quiet_protocol' in policy:
            quiet=read(folder/'quiet-audit-v1.json');assert quiet['pass'] and quiet['accepted_on_this_host']==accepted and len(quiet['quiet_checks'])==5
            assert quiet['script_sha256']==sha(ROOT/'scripts/audit_skylake_quiet_perf.py')""")
s=s.replace("'paired':stats,'full_finite_comparisons'", "'accepted_on_this_host':accepted,'guest_quiet_protocol':'quiet_protocol' in policy,'paired':stats,'full_finite_comparisons'")
a=s.index('    failed=ROOT/');b=s.index('    pmustats=[]',a);s=s[:a]+s[b:]
s=s.replace("    for name,_,_ in CASES:\n        folder=ROOT/f'artifacts/skylake-{name}-pmu-v1'", "    for name,_,_ in CASES:\n        if name=='batchspan':continue\n        folder=ROOT/f'artifacts/skylake-{name}-pmu-v1'")
s=s.replace("'preserved_validation_failure':True,", "'preserved_negative_candidates':[43,44,45],")
s=s.replace("'threefold_goal_completed':False", "'threefold_local_gate_candidates':[x['revision'] for x in cases if x['accepted_on_this_host']],'threefold_goal_completed':False")
s=s.replace("print('38—42独立复核通过，完整模式轮次',2*rounds,'PMU画像',len(pmustats),'容量断言失败保留')", "print('原地路径阶段复核通过，完整模式轮次',2*rounds,'PMU画像',len(pmustats),'新协议与旧数据分别保留')")
s=s.replace("('overlap16',46,'artifacts/skylake-overlap16-quiet-perf-v1')]", "('overlap16',46,'artifacts/skylake-overlap16-quiet-perf-v1'),('batchspan',40,'artifacts/skylake-batchspan-quiet-confirm-v1')]")
s=s.replace('assert rounds==400','assert rounds==480')
s=s.replace('    a.output.write_text', "    confirmation=read(ROOT/'artifacts/skylake-threefold-confirmation-v1/results.json');assert confirmation['integrity_pass']\n    save.pop('threefold_goal_completed',None);save['threefold_local_gate_confirmed']=confirmation['threefold_confirmed'];save['confirmation']=confirmation\n    a.output.write_text")
new=ROOT/'scripts/audit_skylake_inplace_path.py';assert not new.exists();new.write_bytes(s.encode('utf-8'));compile(s,str(new),'exec')
print('原地路径阶段审计脚本已准备，未调用像素或性能入口')
