"""冻结45首次配对计时，原地重叠写GPR主体、分离仍40，参考23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_batchspan_pinned_linux.py').read_text(encoding='utf-8').replace('比较40与23','比较45与23').replace('bench_skylake_batchspan_pinned_linux.py','bench_skylake_overlap_pinned_linux.py').replace('40首次计时','45首次计时')
new='scripts/bench_skylake_overlap_pinned_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=json.loads((ROOT/'experiments/skylake-batchspan-linux-perf-v1.json').read_text(encoding='utf-8'))
for key,path in {'plan':'experiments/skylake-overlap-v1.json','build':'artifacts/skylake-overlap-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-overlap-linux-full-v1/results.json','validation':'experiments/skylake-overlap-validation-v1.json','benchmark_script':new}.items():p[key]=spec(path)
p['purpose']='45原地GPR重叠写；既有AVX2分派下原地主体为普通整数，分离仍40的AVX2 NT；首次四核绑定直接对23'
dest=ROOT/'experiments/skylake-overlap-linux-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结45首次性能，未计时')
