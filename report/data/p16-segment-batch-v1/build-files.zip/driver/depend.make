# Empty dependencies file for jshc_segment_driver.
# This may be replaced when dependencies are built.
