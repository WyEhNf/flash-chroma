file(REMOVE_RECURSE
  "CMakeFiles/jshc_segment_driver.dir/driver.cpp.obj"
  "CMakeFiles/jshc_segment_driver.dir/driver.cpp.obj.d"
  "libjshc_segment_driver.dll"
  "libjshc_segment_driver.dll.a"
  "libjshc_segment_driver.dll.manifest"
  "libjshc_segment_driver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_segment_driver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
