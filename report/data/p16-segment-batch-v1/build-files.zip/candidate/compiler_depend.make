# Empty compiler generated dependencies file for jshc_segment_batch.
# This may be replaced when dependencies are built.
