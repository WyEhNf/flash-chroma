"""固定2³输入、15bit基值头加八6bit残差及bit63例外tag的唯一离线证伪。"""
import datetime, hashlib, json, os, platform, sys, traceback
from pathlib import Path
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
N, BLOCKS = 1 << 24, 1 << 21
GATE = dict(exception_pool_bytes_max=2 << 20, exception_packet8_fraction_max=.05, any_image_exception_packet8_fraction_max=.20)
REASONS = ['base_R_outside_0_255', 'base_G_outside_0_255', 'base_B_outside_0_255', 'base_RGB_equals_ffffff',
           'delta_R_outside_0_7', 'delta_G_minus_R_outside_0_3', 'delta_B_minus_R_outside_0_1']

def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def save(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False); f.write('\n')

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def packed(rgb):
    a = rgb.astype(np.uint32)
    return a[..., 0] | (a[..., 1] << 8) | (a[..., 2] << 16)

def rgb_bytes(value): return np.stack((value & 255, (value >> 8) & 255, (value >> 16) & 255), axis=-1).astype(np.uint8)

def address(code):
    r, g, b = code & 255, (code >> 8) & 255, code >> 16
    return (r >> 1) | ((g >> 1) << 7) | ((b >> 1) << 14), (r & 1) | ((g & 1) << 1) | ((b & 1) << 2)

def inverse(q, k):
    r, g, b = ((q & 127) << 1) | (k & 1), (((q >> 7) & 127) << 1) | ((k >> 1) & 1), ((q >> 14) << 1) | ((k >> 2) & 1)
    return r | (g << 8) | (b << 16)

def analyze(p):
    assert p['script_sha256'] == sha(__file__) and p['gate'] == GATE and p['encoding']['delta_bits'] == [3, 2, 1]
    assert p['attempt_policy']['maximum_analysis_executions'] == 1
    assert sha(ROOT / p['prior_profile']['path']) == p['prior_profile']['sha256']
    for spec in p['inputs'].values():
        path = ROOT / spec['path']; assert path.stat().st_size == spec['bytes'] and sha(path) == spec['sha256']
    palette = np.unique(np.fromfile(ROOT / p['inputs']['cache_gold']['path'], dtype='<u4'))
    old = np.fromfile(ROOT / p['inputs']['old_palette_crosscheck']['path'], dtype='<u4')
    generation = read(ROOT / p['inputs']['cache_generation']['path'])
    assert len(palette) == 230 and np.all(palette <= 0xffffff) and len(old) == 256
    assert np.array_equal(old[:230], palette) and np.all(old[230:] == 0)
    assert generation['generation_completed'] and generation['gold_sha256'] == p['inputs']['cache_gold']['sha256']
    pr, pg, pb = (a.astype(np.int32) for a in (palette & 255, (palette >> 8) & 255, (palette >> 16) & 255))
    pdg, pdb = pg - pr, pb - pr
    minDG, minDB = int(pdg.min()), int(pdb.min())
    spanDG, spanDB = int(pdg.max()) - minDG, int(pdb.max()) - minDB
    assert spanDG <= 15 and spanDB <= 7
    encoding = dict(p['encoding'], global_minDG=minDG, global_minDB=minDB, global_spanDG=spanDG, global_spanDB=spanDB)
    cube = np.memmap(ROOT / p['inputs']['cube']['path'], dtype=np.uint8, mode='r', shape=(256, 256, 256, 3))
    words, pool_parts, pool_count = np.empty(BLOCKS, dtype='<u8'), [], 0
    reasons_hist = np.zeros(128, dtype=np.int64)
    spans = {name: np.zeros(511, dtype=np.int64) for name in ('R', 'G_minus_R', 'B_minus_R')}
    # 每个B粗片：cube的Rc,Rf,Gc,Gf,Bf转为Gc,Rc,Bf,Gf,Rf，确保R fine最低位。
    for bc in range(128):
        members = cube[:, :, 2 * bc:2 * bc + 2, :].reshape(128, 2, 128, 2, 2, 3).transpose(2, 0, 4, 3, 1, 5).reshape(16384, 8, 3)
        rr, gg, bb = (members[..., channel].astype(np.int32) for channel in range(3))
        dg, db = gg - rr, bb - rr
        br, bdg, bdb = rr.min(axis=1), dg.min(axis=1), db.min(axis=1)
        bg, bblue = br + bdg, br + bdb
        assert np.all((bdg >= minDG) & (bdg <= minDG + spanDG)) and np.all((bdb >= minDB) & (bdb <= minDB + spanDB))
        dr, ddg, ddb = rr - br[:, None], dg - bdg[:, None], db - bdb[:, None]
        reasons = [(br < 0) | (br > 255), (bg < 0) | (bg > 255), (bblue < 0) | (bblue > 255),
                   (br == 255) & (bg == 255) & (bblue == 255), np.any(dr > 7, axis=1), np.any(ddg > 3, axis=1), np.any(ddb > 1, axis=1)]
        mask = np.zeros(16384, dtype=np.uint8)
        for bit, failed in enumerate(reasons): mask |= failed.astype(np.uint8) << bit
        reasons_hist += np.bincount(mask, minlength=128)
        good, bad = mask == 0, mask != 0
        for name, delta in zip(spans, (dr, ddg, ddb)):
            assert int(delta.min()) >= 0; spans[name] += np.bincount(delta.max(axis=1), minlength=511)
        encoded = np.zeros(16384, dtype=np.uint64)
        base = br[good].astype(np.uint64) | ((bdg[good] - minDG).astype(np.uint64) << 8) | ((bdb[good] - minDB).astype(np.uint64) << 12)
        code6 = dr[good].astype(np.uint64) | (ddg[good].astype(np.uint64) << 3) | (ddb[good].astype(np.uint64) << 5)
        for k in range(8): base |= code6[:, k] << np.uint64(15 + 6 * k)
        encoded[good] = base
        count = int(bad.sum())
        if count:
            encoded[bad] = (np.uint64(1) << np.uint64(63)) | np.arange(pool_count, pool_count + count, dtype=np.uint64)
            pool_parts.append(packed(members[bad]).astype('<u4')); pool_count += count
        words[bc * 16384:(bc + 1) * 16384] = encoded
    pool = np.concatenate(pool_parts) if pool_parts else np.empty((0, 8), dtype='<u4')
    sentinel = (words >> np.uint64(63)) != 0
    assert words.nbytes == 16777216 and pool_count < (1 << 63)
    assert int(sentinel.sum()) == pool_count == int(reasons_hist[1:].sum()) and pool.nbytes == pool_count * 32
    assert np.array_equal(words[sentinel] & np.uint64(0x7fffffffffffffff), np.arange(pool_count, dtype=np.uint64))
    assert p['mathematical_bound']['exception_pool_lower_bytes'] <= pool.nbytes <= p['mathematical_bound']['exception_pool_upper_bytes']

    def decode(code):
        q, k = address(code); w = words[q]
        assert int(q.max()) < BLOCKS and int(k.max()) < 8
        bad = (w >> np.uint64(63)) != 0
        header = (w & np.uint64(0x7fff)).astype(np.int32)
        br, bdg, bdb = header & 255, ((header >> 8) & 15) + np.int32(minDG), ((header >> 12) & 7) + np.int32(minDB)
        d = ((w >> (np.uint64(15) + np.uint64(6) * k.astype(np.uint64))) & np.uint64(63)).astype(np.int32)
        signed_rgb = np.stack((br + (d & 7), br + bdg + (d & 7) + ((d >> 3) & 3), br + bdb + (d & 7) + ((d >> 5) & 1)), axis=-1)
        # int32真实通道先查上下界；异常tag的任意header不参与正常范围统计。
        normal_rgb = signed_rgb[~bad]
        carry = np.count_nonzero((normal_rgb < 0) | (normal_rgb > 255), axis=0).tolist()
        actual = np.empty((len(code), 3), dtype=np.uint8); actual[~bad] = normal_rgb.astype(np.uint8)
        if np.any(bad): actual[bad] = rgb_bytes(pool[(w[bad] & np.uint64(0x7fffffffffffffff)).astype(np.intp), k[bad]])
        return actual, bad, int(np.count_nonzero(inverse(q, k) != code)), carry

    full_bytes = full_pixels = full_inverse = 0
    full_carry, full_hash = np.zeros(3, dtype=np.int64), hashlib.sha256()
    g, b = np.repeat(np.arange(256, dtype=np.uint32), 256), np.tile(np.arange(256, dtype=np.uint32), 256)
    for r in range(256):
        actual, _, inv, carry = decode(np.uint32(r) | (g << 8) | (b << 16))
        delta = actual != cube[r].reshape(-1, 3)
        full_bytes += int(delta.sum()); full_pixels += int(np.any(delta, axis=1).sum()); full_inverse += inv
        full_carry += carry; full_hash.update(actual)
    manifest = read(ROOT / p['inputs']['manifest']['path']); assert len(manifest['images']) == 100
    photos = np.memmap(ROOT / p['inputs']['photos']['path'], dtype=np.uint8, mode='r', shape=(100, 786432, 3))
    rows, photo_hash, photo_hist, photo_carry = [], hashlib.sha256(), np.zeros(9, dtype=np.int64), np.zeros(3, dtype=np.int64)
    for index, pixels in enumerate(photos):
        meta = manifest['images'][index]; input_sha = hashlib.sha256(pixels).hexdigest()
        assert input_sha == meta['evaluation']['pixel_sha256']
        actual, bad, inv, carry = decode(packed(pixels))
        delta = actual != cube[pixels[:, 0], pixels[:, 1], pixels[:, 2]]
        hist = np.bincount(bad.reshape(-1, 8).sum(axis=1).astype(np.intp), minlength=9)
        photo_hist += hist; photo_carry += carry; photo_hash.update(actual)
        rows.append(dict(image_index=index, image_id=meta['id'], input_sha256=input_sha, decoded_output_sha256=hashlib.sha256(actual).hexdigest(),
            pixels=786432, packets8=98304, exception_pixels=int(bad.sum()), exception_packets8=int(hist[1:].sum()),
            exception_packet8_fraction=int(hist[1:].sum()) / 98304, exception_pixels_per_packet8_histogram=hist.tolist(),
            decoded_pixel_differences=int(np.any(delta, axis=1).sum()), decoded_byte_differences=int(delta.sum()), inverse_mismatches=inv, normal_channel_carry_violations=carry))
    worst = max(rows, key=lambda row: row['exception_packet8_fraction']); fraction = int(photo_hist[1:].sum()) / 9830400
    exact_full = full_bytes == full_pixels == full_inverse == int(full_carry.sum()) == 0 and full_hash.hexdigest() == p['inputs']['cube']['sha256']
    exact_photos = all(row[key] == 0 for row in rows for key in ('decoded_pixel_differences', 'decoded_byte_differences', 'inverse_mismatches')) and int(photo_carry.sum()) == 0 and photo_hash.hexdigest() == p['expected_photo_output_sha256']
    gate = dict(full_domain_exact=exact_full, photos_exact=exact_photos, exception_pool_bytes=pool.nbytes, exception_pool_pass=pool.nbytes <= GATE['exception_pool_bytes_max'],
                exception_packet8_fraction=fraction, exception_packets_pass=fraction <= GATE['exception_packet8_fraction_max'],
                any_image_exception_packet8_fraction=worst['exception_packet8_fraction'], per_image_pass=worst['exception_packet8_fraction'] <= GATE['any_image_exception_packet8_fraction_max'], limits=GATE)
    gate['passed'] = all(gate[key] for key in ('full_domain_exact', 'photos_exact', 'exception_pool_pass', 'exception_packets_pass', 'per_image_pass'))
    result = dict(purpose=__doc__, analysis_completed=True, script_sha256=sha(__file__), protocol_sha256=sha(OUT / 'protocol.json'),
        environment=dict(platform=platform.platform(), python=sys.version, executable=sys.executable, machine=platform.machine(), processor=platform.processor(), numpy=np.__version__, byteorder=sys.byteorder),
        inputs=p['inputs'], encoding=encoding, palette_crosscheck=dict(entries=230, direct_rgb=True), prior_profile=p['prior_profile'], mathematical_bound=p['mathematical_bound'],
        full_domain=dict(colors=N, blocks=BLOCKS, normal_blocks=int(reasons_hist[0]), exception_blocks=pool_count, exception_block_fraction=pool_count / BLOCKS,
            failure_reasons=REASONS, failure_reason_bitmask_histogram=reasons_hist.tolist(),
            failure_reason_counts_overlapping={name: sum(int(count) for code, count in enumerate(reasons_hist) if code & (1 << bit)) for bit, name in enumerate(REASONS)},
            span_histograms={name: hist.tolist() for name, hist in spans.items()}, decoded_pixel_differences=full_pixels, decoded_byte_differences=full_bytes,
            inverse_mismatches=full_inverse, normal_channel_carry_violations=full_carry.tolist(), decoded_output_sha256=full_hash.hexdigest(),
            main_table_bytes=words.nbytes, main_table_sha256=hashlib.sha256(words).hexdigest(), exception_pool_bytes=pool.nbytes,
            exception_pool_sha256=hashlib.sha256(pool).hexdigest(), total_payload_bytes=words.nbytes + pool.nbytes, sentinel_count=pool_count, pool_ordinals_contiguous=True),
        photos=dict(images=100, pixels=78643200, packets8=9830400, exception_pixels=sum(row['exception_pixels'] for row in rows), exception_packets8=int(photo_hist[1:].sum()),
            exception_packet8_fraction=fraction, exception_pixels_per_packet8_histogram=photo_hist.tolist(), decoded_output_sha256=photo_hash.hexdigest(),
            decoded_pixel_differences=sum(row['decoded_pixel_differences'] for row in rows), decoded_byte_differences=sum(row['decoded_byte_differences'] for row in rows),
            inverse_mismatches=sum(row['inverse_mismatches'] for row in rows), normal_channel_carry_violations=photo_carry.tolist(), worst_image_index=worst['image_index'],
            worst_image_id=worst['image_id'], worst_image_fraction=worst['exception_packet8_fraction'], images_over_gate=[row['image_index'] for row in rows if row['exception_packet8_fraction'] > .20]),
        per_image=rows, gate=gate, decision='离线通过，仅允许考虑原生；不是性能证据' if gate['passed'] else '唯一固定筛查失败，停止，不改位数/几何/门槛重跑',
        limitations=['新15bit基值头/八6bit/bit63tag编码；不是旧5bit格式改门槛，不重评旧RGB-5bit或ID-3bit失败。',
            '主表固定16MiB，块几何改变布局；未统计缓存行、硬件miss或声称性能收益。',
            '只从固定已验cube评估编码；未来运行时建表必须来自原模型，不得读取gold或照片。',
            '全域/百图仅离线编码重建；未运行候选、拟合、性能或实际Skylake。'],
        native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0, new_fits=0)
    save('analysis.json', result); return result

def main():
    sys.stdout.reconfigure(encoding='utf-8'); p = read(OUT / 'protocol.json')
    assert p['script_sha256'] == sha(__file__)
    save('execution-start.json', dict(started_utc=now(), pid=os.getpid(), argv=sys.argv, script_sha256=sha(__file__), protocol_sha256=sha(OUT / 'protocol.json'), maximum_analysis_executions=1, native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0))
    try: result = analyze(p)
    except BaseException as error:
        save('failure.json', dict(analysis_completed=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc()))
        save('exit.json', dict(ended_utc=now(), exit_code=1, analysis_completed=False, failure_sha256=sha(OUT / 'failure.json'), script_sha256=sha(__file__), protocol_sha256=sha(OUT / 'protocol.json'), native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0)); raise
    save('exit.json', dict(ended_utc=now(), exit_code=0, analysis_completed=True, gate_passed=result['gate']['passed'], analysis_sha256=sha(OUT / 'analysis.json'), script_sha256=sha(__file__), protocol_sha256=sha(OUT / 'protocol.json'), native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0))
    print(json.dumps(dict(gate=result['gate'], analysis_sha256=sha(OUT / 'analysis.json'), exit_sha256=sha(OUT / 'exit.json')), ensure_ascii=False), flush=True)

if __name__ == '__main__': main()
