
artifacts\skylake-axis-preweight-build-v1\CMakeFiles\jshc_skylake_axis_preweight.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
       7:	c5 f8 29 34 24       	vmovaps %xmm6,(%rsp)
       c:	c5 f8 29 7c 24 10    	vmovaps %xmm7,0x10(%rsp)
      12:	c5 78 29 44 24 20    	vmovaps %xmm8,0x20(%rsp)
      18:	c5 78 29 4c 24 30    	vmovaps %xmm9,0x30(%rsp)
      1e:	c5 78 29 54 24 40    	vmovaps %xmm10,0x40(%rsp)
      24:	c5 78 29 5c 24 50    	vmovaps %xmm11,0x50(%rsp)
      2a:	c5 78 29 64 24 60    	vmovaps %xmm12,0x60(%rsp)
      30:	c5 78 29 6c 24 70    	vmovaps %xmm13,0x70(%rsp)
      36:	c5 78 29 b4 24 80 00 	vmovaps %xmm14,0x80(%rsp)
      3d:	00 00 
      3f:	c5 78 29 bc 24 90 00 	vmovaps %xmm15,0x90(%rsp)
      46:	00 00 
      48:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      4c:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
      50:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
      54:	48 8b 01             	mov    (%rcx),%rax
      57:	c5 fd 6f 2a          	vmovdqa (%rdx),%ymm5
      5b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      5f:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      63:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
      69:	48 8b 41 08          	mov    0x8(%rcx),%rax
      6d:	c5 fd 6f 52 20       	vmovdqa 0x20(%rdx),%ymm2
      72:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      76:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
      7b:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
      80:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
      85:	c4 e2 75 90 3c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm7
      8b:	48 8b 41 10          	mov    0x10(%rcx),%rax
      8f:	c5 fd 6f 4a 40       	vmovdqa 0x40(%rdx),%ymm1
      94:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
      99:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
      9e:	c4 62 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm8
      a4:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
      a9:	48 8b 41 48          	mov    0x48(%rcx),%rax
      ad:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
      b2:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
      b7:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
      bc:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
      c0:	c4 c1 6d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm2
      c6:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      ca:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      cf:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
      d3:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
      d8:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
      dc:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
      e0:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
      e4:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
      ea:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
      ee:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      f2:	c5 3d db c1          	vpand  %ymm1,%ymm8,%ymm8
      f6:	c4 62 5d 3d d7       	vpmaxsd %ymm7,%ymm4,%ymm10
      fb:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
     101:	c5 c5 66 ec          	vpcmpgtd %ymm4,%ymm7,%ymm5
     105:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
     10a:	c4 62 5d 39 ef       	vpminsd %ymm7,%ymm4,%ymm13
     10f:	c5 5d fe ff          	vpaddd %ymm7,%ymm4,%ymm15
     113:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     117:	c4 42 15 39 e0       	vpminsd %ymm8,%ymm13,%ymm12
     11c:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
     121:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
     126:	c4 c3 25 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm11,%ymm5
     12c:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm5,%ymm5        # 135 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)+0x135>
     133:	ff ff 90 
     136:	c4 43 25 4c de 40    	vpblendvb %ymm4,%ymm14,%ymm11,%ymm11
     13c:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
     141:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm11,%ymm11        # 14a <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)+0x14a>
     148:	ff ff d0 
     14b:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     150:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
     154:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     159:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
     15e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     162:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     166:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
     16c:	c4 e2 5d 90 1c b0    	vpgatherdd %ymm4,(%rax,%ymm6,4),%ymm3
     172:	b8 00 80 00 00       	mov    $0x8000,%eax
     177:	c5 cd 72 d0 18       	vpsrld $0x18,%ymm0,%ymm6
     17c:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     181:	c5 55 db de          	vpand  %ymm6,%ymm5,%ymm11
     185:	c5 ed db e6          	vpand  %ymm6,%ymm2,%ymm4
     189:	c5 e5 db c6          	vpand  %ymm6,%ymm3,%ymm0
     18d:	c5 f5 db fe          	vpand  %ymm6,%ymm1,%ymm7
     191:	c5 bd 72 f4 10       	vpslld $0x10,%ymm4,%ymm8
     196:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
     19a:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     19e:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     1a3:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     1a8:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     1ad:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     1b2:	c5 15 db ee          	vpand  %ymm6,%ymm13,%ymm13
     1b6:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     1bb:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     1c0:	c5 25 db de          	vpand  %ymm6,%ymm11,%ymm11
     1c4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     1c9:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
     1cd:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
     1d1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     1d5:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     1d9:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     1de:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1e2:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     1e7:	c4 c1 3d 72 f3 10    	vpslld $0x10,%ymm11,%ymm8
     1ed:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     1f2:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     1f6:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     1fb:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     204:	c4 42 25 40 da       	vpmulld %ymm10,%ymm11,%ymm11
     209:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     20d:	c5 fd 7f 02          	vmovdqa %ymm0,(%rdx)
     211:	c5 fd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm0
     216:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     21b:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     21f:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     223:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     227:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
     22c:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     231:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     236:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     23b:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     240:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
     244:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     249:	c5 f5 72 f2 10       	vpslld $0x10,%ymm2,%ymm1
     24e:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     252:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     256:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     25a:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     25e:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     263:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     268:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
     26d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     271:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     276:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     27b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     27f:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     283:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     287:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     28c:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     291:	c5 f8 77             	vzeroupper
     294:	c5 f8 28 34 24       	vmovaps (%rsp),%xmm6
     299:	c5 f8 28 7c 24 10    	vmovaps 0x10(%rsp),%xmm7
     29f:	c5 78 28 44 24 20    	vmovaps 0x20(%rsp),%xmm8
     2a5:	c5 78 28 4c 24 30    	vmovaps 0x30(%rsp),%xmm9
     2ab:	c5 78 28 54 24 40    	vmovaps 0x40(%rsp),%xmm10
     2b1:	c5 78 28 5c 24 50    	vmovaps 0x50(%rsp),%xmm11
     2b7:	c5 78 28 64 24 60    	vmovaps 0x60(%rsp),%xmm12
     2bd:	c5 78 28 6c 24 70    	vmovaps 0x70(%rsp),%xmm13
     2c3:	c5 78 28 b4 24 80 00 	vmovaps 0x80(%rsp),%xmm14
     2ca:	00 00 
     2cc:	c5 78 28 bc 24 90 00 	vmovaps 0x90(%rsp),%xmm15
     2d3:	00 00 
     2d5:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
     2dc:	c3                   	ret
     2dd:	0f 1f 00             	nopl   (%rax)

00000000000002e0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     2e0:	41 57                	push   %r15
     2e2:	41 56                	push   %r14
     2e4:	57                   	push   %rdi
     2e5:	56                   	push   %rsi
     2e6:	53                   	push   %rbx
     2e7:	48 81 ec f0 03 00 00 	sub    $0x3f0,%rsp
     2ee:	c5 f8 29 b4 24 50 03 	vmovaps %xmm6,0x350(%rsp)
     2f5:	00 00 
     2f7:	c5 f8 29 bc 24 60 03 	vmovaps %xmm7,0x360(%rsp)
     2fe:	00 00 
     300:	c5 78 29 84 24 70 03 	vmovaps %xmm8,0x370(%rsp)
     307:	00 00 
     309:	c5 78 29 8c 24 80 03 	vmovaps %xmm9,0x380(%rsp)
     310:	00 00 
     312:	c5 78 29 94 24 90 03 	vmovaps %xmm10,0x390(%rsp)
     319:	00 00 
     31b:	c5 78 29 9c 24 a0 03 	vmovaps %xmm11,0x3a0(%rsp)
     322:	00 00 
     324:	c5 78 29 a4 24 b0 03 	vmovaps %xmm12,0x3b0(%rsp)
     32b:	00 00 
     32d:	c5 78 29 ac 24 c0 03 	vmovaps %xmm13,0x3c0(%rsp)
     334:	00 00 
     336:	c5 78 29 b4 24 d0 03 	vmovaps %xmm14,0x3d0(%rsp)
     33d:	00 00 
     33f:	c5 78 29 bc 24 e0 03 	vmovaps %xmm15,0x3e0(%rsp)
     346:	00 00 
     348:	49 89 ca             	mov    %rcx,%r10
     34b:	4c 89 c1             	mov    %r8,%rcx
     34e:	4c 8d 84 24 9f 02 00 	lea    0x29f(%rsp),%r8
     355:	00 
     356:	49 89 d3             	mov    %rdx,%r11
     359:	49 83 e0 e0          	and    $0xffffffffffffffe0,%r8
     35d:	48 83 fa 04          	cmp    $0x4,%rdx
     361:	0f 84 b2 0b 00 00    	je     f19 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc39>
     367:	4d 85 c9             	test   %r9,%r9
     36a:	0f 84 32 08 00 00    	je     ba2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c2>
     370:	49 ff c9             	dec    %r9
     373:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 3fb <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11b>
     37a:	00 
     37b:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     380:	49 c1 e9 03          	shr    $0x3,%r9
     384:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
     388:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
     38f:	00 00 
     391:	4f 8d 0c 5b          	lea    (%r11,%r11,2),%r9
     395:	c5 fd 6f 25 a0 00 00 	vmovdqa 0xa0(%rip),%ymm4        # 43d <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15d>
     39c:	00 
     39d:	4c 8d 44 c1 18       	lea    0x18(%rcx,%rax,8),%r8
     3a2:	b8 00 80 00 00       	mov    $0x8000,%eax
     3a7:	49 c1 e1 05          	shl    $0x5,%r9
     3ab:	c5 f9 6e e8          	vmovd  %eax,%xmm5
     3af:	c5 fe 7f a4 24 60 02 	vmovdqu %ymm4,0x260(%rsp)
     3b6:	00 00 
     3b8:	c4 c1 5d 72 d5 18    	vpsrld $0x18,%ymm13,%ymm4
     3be:	4d 01 d1             	add    %r10,%r9
     3c1:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     3c6:	c5 fe 7f ac 24 a0 00 	vmovdqu %ymm5,0xa0(%rsp)
     3cd:	00 00 
     3cf:	90                   	nop
     3d0:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
     3d4:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
     3d9:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     3df:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     3e5:	c4 e2 7d 00 84 24 40 	vpshufb 0x240(%rsp),%ymm0,%ymm0
     3ec:	02 00 00 
     3ef:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     3f4:	c5 fd db d4          	vpand  %ymm4,%ymm0,%ymm2
     3f8:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     3fc:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     401:	4d 85 db             	test   %r11,%r11
     404:	0f 84 06 0b 00 00    	je     f10 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc30>
     40a:	c4 c1 45 72 d5 10    	vpsrld $0x10,%ymm13,%ymm7
     410:	c5 7d 6f f9          	vmovdqa %ymm1,%ymm15
     414:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     418:	4c 89 d0             	mov    %r10,%rax
     41b:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
     422:	00 00 
     424:	c5 7d 6f e2          	vmovdqa %ymm2,%ymm12
     428:	e9 88 04 00 00       	jmp    8b5 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5d5>
     42d:	0f 1f 00             	nopl   (%rax)
     430:	c5 bd db 15 40 00 00 	vpand  0x40(%rip),%ymm8,%ymm2        # 478 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x198>
     437:	00 
     438:	c5 b5 db 1d 40 00 00 	vpand  0x40(%rip),%ymm9,%ymm3        # 480 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a0>
     43f:	00 
     440:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     445:	c4 c1 35 72 d1 11    	vpsrld $0x11,%ymm9,%ymm9
     44b:	c4 c1 3d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm8
     451:	c5 ad db 2d 40 00 00 	vpand  0x40(%rip),%ymm10,%ymm5        # 499 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b9>
     458:	00 
     459:	c4 e2 6d 3d fb       	vpmaxsd %ymm3,%ymm2,%ymm7
     45e:	c4 e2 6d 39 cb       	vpminsd %ymm3,%ymm2,%ymm1
     463:	c4 62 35 40 4c 24 40 	vpmulld 0x40(%rsp),%ymm9,%ymm9
     46a:	c4 c1 2d 72 d2 11    	vpsrld $0x11,%ymm10,%ymm10
     470:	c4 e2 45 3d f5       	vpmaxsd %ymm5,%ymm7,%ymm6
     475:	c4 62 75 39 dd       	vpminsd %ymm5,%ymm1,%ymm11
     47a:	c4 62 3d 40 44 24 20 	vpmulld 0x20(%rsp),%ymm8,%ymm8
     481:	c5 f5 66 cd          	vpcmpgtd %ymm5,%ymm1,%ymm1
     485:	c5 25 fe fe          	vpaddd %ymm6,%ymm11,%ymm15
     489:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     48e:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
     495:	00 00 
     497:	c4 41 7d 6f cd       	vmovdqa %ymm13,%ymm9
     49c:	c5 7e 7f bc 24 60 01 	vmovdqu %ymm15,0x160(%rsp)
     4a3:	00 00 
     4a5:	c4 41 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm15
     4aa:	c5 d5 66 ff          	vpcmpgtd %ymm7,%ymm5,%ymm7
     4ae:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
     4b4:	c4 c1 7d fe c7       	vpaddd %ymm15,%ymm0,%ymm0
     4b9:	c5 ed fe f3          	vpaddd %ymm3,%ymm2,%ymm6
     4bd:	c5 7e 7f bc 24 20 01 	vmovdqu %ymm15,0x120(%rsp)
     4c4:	00 00 
     4c6:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
     4ca:	c4 22 35 90 14 ba    	vpgatherdd %ymm9,(%rdx,%ymm15,4),%ymm10
     4d0:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
     4d7:	00 00 
     4d9:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
     4dd:	c4 c1 3d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm8
     4e3:	c5 2d db e4          	vpand  %ymm4,%ymm10,%ymm12
     4e7:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     4ed:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
     4f3:	c5 3d db c4          	vpand  %ymm4,%ymm8,%ymm8
     4f7:	c5 7e 7f 84 24 80 01 	vmovdqu %ymm8,0x180(%rsp)
     4fe:	00 00 
     500:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     506:	c5 3d fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm8,%ymm8
     50d:	00 00 
     50f:	c5 7e 7f 84 24 a0 01 	vmovdqu %ymm8,0x1a0(%rsp)
     516:	00 00 
     518:	c4 62 0d 90 04 82    	vpgatherdd %ymm14,(%rdx,%ymm0,4),%ymm8
     51e:	c5 ed 66 c3          	vpcmpgtd %ymm3,%ymm2,%ymm0
     522:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     528:	c4 e3 0d 4c 44 24 40 	vpblendvb %ymm0,0x40(%rsp),%ymm14,%ymm0
     52f:	00 
     530:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     535:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm0,%ymm0        # 53e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x25e>
     53c:	ff ff 10 
     53f:	c5 b5 fa c0          	vpsubd %ymm0,%ymm9,%ymm0
     543:	c5 3d db cc          	vpand  %ymm4,%ymm8,%ymm9
     547:	c4 e2 0d 90 0c 82    	vpgatherdd %ymm14,(%rdx,%ymm0,4),%ymm1
     54d:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     553:	c5 fe 7f 8c 24 00 02 	vmovdqu %ymm1,0x200(%rsp)
     55a:	00 00 
     55c:	c5 dd db c1          	vpand  %ymm1,%ymm4,%ymm0
     560:	c5 e5 66 ca          	vpcmpgtd %ymm2,%ymm3,%ymm1
     564:	c5 35 fa c8          	vpsubd %ymm0,%ymm9,%ymm9
     568:	c4 62 35 40 8c 24 80 	vpmulld 0x80(%rsp),%ymm9,%ymm9
     56f:	00 00 00 
     572:	c4 e3 0d 4c 4c 24 40 	vpblendvb %ymm1,0x40(%rsp),%ymm14,%ymm1
     579:	10 
     57a:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     57f:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm1,%ymm1        # 588 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2a8>
     586:	ff ff 70 
     589:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
     58e:	c5 7e 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm15
     595:	00 00 
     597:	c4 e2 0d 90 3c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm7
     59d:	c5 2d db f4          	vpand  %ymm4,%ymm10,%ymm14
     5a1:	c4 c1 2d 72 f6 10    	vpslld $0x10,%ymm14,%ymm10
     5a7:	c5 7e 7f b4 24 c0 01 	vmovdqu %ymm14,0x1c0(%rsp)
     5ae:	00 00 
     5b0:	c5 c5 db cc          	vpand  %ymm4,%ymm7,%ymm1
     5b4:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     5b9:	c4 41 2d fe f7       	vpaddd %ymm15,%ymm10,%ymm14
     5be:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     5c2:	c5 7e 7f b4 24 e0 01 	vmovdqu %ymm14,0x1e0(%rsp)
     5c9:	00 00 
     5cb:	c5 cd fa b4 24 60 01 	vpsubd 0x160(%rsp),%ymm6,%ymm6
     5d2:	00 00 
     5d4:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     5d9:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     5dd:	c4 e2 75 40 4c 24 60 	vpmulld 0x60(%rsp),%ymm1,%ymm1
     5e4:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
     5e9:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     5ee:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     5f3:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     5f7:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
     5fc:	c4 c1 7d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm0
     602:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     608:	c5 7d db d4          	vpand  %ymm4,%ymm0,%ymm10
     60c:	c5 bd db cc          	vpand  %ymm4,%ymm8,%ymm1
     610:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
     617:	00 00 
     619:	0f 85 31 08 00 00    	jne    e50 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb70>
     61f:	48 8b 58 28          	mov    0x28(%rax),%rbx
     623:	c5 fe 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm6
     62a:	00 00 
     62c:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     630:	48 8b 70 18          	mov    0x18(%rax),%rsi
     634:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
     638:	c4 62 45 90 0c b3    	vpgatherdd %ymm7,(%rbx,%ymm6,4),%ymm9
     63e:	c5 fe 6f b4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm6
     645:	00 00 
     647:	48 8b 58 20          	mov    0x20(%rax),%rbx
     64b:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     64f:	c4 e2 45 90 0c b3    	vpgatherdd %ymm7,(%rbx,%ymm6,4),%ymm1
     655:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     65c:	00 00 
     65e:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     662:	c4 e2 45 90 04 b6    	vpgatherdd %ymm7,(%rsi,%ymm6,4),%ymm0
     668:	0f 84 a2 05 00 00    	je     c10 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x930>
     66e:	c5 cd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm6
     673:	c5 bd 72 e1 10       	vpsrad $0x10,%ymm1,%ymm8
     678:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     67e:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
     683:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     687:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     68b:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     690:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     695:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
     69a:	c4 c1 4d fe f8       	vpaddd %ymm8,%ymm6,%ymm7
     69f:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     6a6:	00 00 
     6a8:	c4 c1 45 72 e1 10    	vpsrad $0x10,%ymm9,%ymm7
     6ae:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
     6b4:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     6b8:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
     6be:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
     6c3:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
     6c7:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     6cb:	c5 b5 fe ed          	vpaddd %ymm5,%ymm9,%ymm5
     6cf:	c5 55 fe f1          	vpaddd %ymm1,%ymm5,%ymm14
     6d3:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
     6d8:	c5 f5 66 d8          	vpcmpgtd %ymm0,%ymm1,%ymm3
     6dc:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     6e2:	c4 c1 55 66 d1       	vpcmpgtd %ymm9,%ymm5,%ymm2
     6e7:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
     6ed:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
     6f2:	c4 c3 25 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm11,%ymm3
     6f8:	c4 63 65 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm11        # 701 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x421>
     6ff:	ff ff 20 
     702:	c4 e2 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm2
     707:	c4 e2 6d 39 dd       	vpminsd %ymm5,%ymm2,%ymm3
     70c:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
     710:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     715:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
     71b:	c5 a5 fe 9c 24 20 01 	vpaddd 0x120(%rsp),%ymm11,%ymm3
     722:	00 00 
     724:	c5 ed 66 d5          	vpcmpgtd %ymm5,%ymm2,%ymm2
     728:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     72c:	c4 62 05 90 1c 9a    	vpgatherdd %ymm15,(%rdx,%ymm3,4),%ymm11
     732:	c5 7e 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm15
     738:	c4 c3 05 4c ce 10    	vpblendvb %ymm1,%ymm14,%ymm15,%ymm1
     73e:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
     743:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
     749:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm1,%ymm1        # 752 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x472>
     750:	ff ff 20 
     753:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
     75a:	00 00 
     75c:	c5 ed fa c9          	vpsubd %ymm1,%ymm2,%ymm1
     760:	c4 c1 6d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm2
     766:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     76b:	c4 e2 05 90 1c 8a    	vpgatherdd %ymm15,(%rdx,%ymm1,4),%ymm3
     771:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
     777:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
     77b:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     780:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     785:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     789:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     78d:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
     791:	c5 ed fa 94 24 c0 01 	vpsubd 0x1c0(%rsp),%ymm2,%ymm2
     798:	00 00 
     79a:	c5 ad fa db          	vpsubd %ymm3,%ymm10,%ymm3
     79e:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     7a3:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     7a9:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
     7ae:	c5 bd 66 ce          	vpcmpgtd %ymm6,%ymm8,%ymm1
     7b2:	c5 7d 6f f5          	vmovdqa %ymm5,%ymm14
     7b6:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
     7bb:	c4 e3 2d 4c cd 10    	vpblendvb %ymm1,%ymm5,%ymm10,%ymm1
     7c1:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     7c5:	c4 c2 4d 39 d8       	vpminsd %ymm8,%ymm6,%ymm3
     7ca:	c5 ed fe 94 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm2,%ymm2
     7d1:	00 00 
     7d3:	c4 e2 65 39 ef       	vpminsd %ymm7,%ymm3,%ymm5
     7d8:	c5 e5 66 df          	vpcmpgtd %ymm7,%ymm3,%ymm3
     7dc:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     7e0:	c4 c2 4d 3d d0       	vpmaxsd %ymm8,%ymm6,%ymm2
     7e5:	c4 c1 4d 66 f0       	vpcmpgtd %ymm8,%ymm6,%ymm6
     7ea:	c5 b5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm9
     7ef:	c5 c5 66 c2          	vpcmpgtd %ymm2,%ymm7,%ymm0
     7f3:	c4 e2 6d 3d d7       	vpmaxsd %ymm7,%ymm2,%ymm2
     7f8:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
     7fc:	c4 41 7d 6f f9       	vmovdqa %ymm9,%ymm15
     801:	c4 c3 2d 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm10,%ymm6
     807:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm1,%ymm1        # 810 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x530>
     80e:	ff ff 00 
     811:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 81a <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x53a>
     818:	ff ff 30 
     81b:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
     822:	00 00 
     824:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
     82b:	00 00 
     82d:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     831:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
     838:	00 00 
     83a:	c4 e2 25 90 04 8a    	vpgatherdd %ymm11,(%rdx,%ymm1,4),%ymm0
     840:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     845:	c4 e2 25 90 0c b2    	vpgatherdd %ymm11,(%rdx,%ymm6,4),%ymm1
     84b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     850:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     854:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     859:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     85d:	c5 e5 fe ff          	vpaddd %ymm7,%ymm3,%ymm7
     861:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     865:	c5 f5 fa d8          	vpsubd %ymm0,%ymm1,%ymm3
     869:	c5 fd fa 84 24 80 01 	vpsubd 0x180(%rsp),%ymm0,%ymm0
     870:	00 00 
     872:	c4 e2 45 40 db       	vpmulld %ymm3,%ymm7,%ymm3
     877:	c5 fe 6f bc 24 60 01 	vmovdqu 0x160(%rsp),%ymm7
     87e:	00 00 
     880:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
     885:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
     889:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     88e:	c5 fd fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm0,%ymm0
     895:	00 00 
     897:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     89b:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     89f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     8a4:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     8a8:	48 83 c0 60          	add    $0x60,%rax
     8ac:	49 39 c1             	cmp    %rax,%r9
     8af:	0f 84 9a 02 00 00    	je     b4f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x86f>
     8b5:	48 8b 10             	mov    (%rax),%rdx
     8b8:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
     8bf:	00 00 
     8c1:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     8c5:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     8c9:	8b 58 54             	mov    0x54(%rax),%ebx
     8cc:	8b 70 50             	mov    0x50(%rax),%esi
     8cf:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
     8d3:	c4 22 45 90 04 a2    	vpgatherdd %ymm7,(%rdx,%ymm12,4),%ymm8
     8d9:	48 8b 50 08          	mov    0x8(%rax),%rdx
     8dd:	c5 7e 7f bc 24 e0 00 	vmovdqu %ymm15,0xe0(%rsp)
     8e4:	00 00 
     8e6:	80 78 5a 00          	cmpb   $0x0,0x5a(%rax)
     8ea:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
     8ee:	c4 22 65 90 0c ba    	vpgatherdd %ymm3,(%rdx,%ymm15,4),%ymm9
     8f4:	48 8b 50 10          	mov    0x10(%rax),%rdx
     8f8:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
     8ff:	00 00 
     901:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     906:	c4 62 6d 90 14 aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm10
     90c:	c5 f9 6e d6          	vmovd  %esi,%xmm2
     910:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
     914:	48 8b 50 48          	mov    0x48(%rax),%rdx
     918:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     91d:	c5 f9 6e c6          	vmovd  %esi,%xmm0
     921:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     927:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     92d:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     932:	0f 84 f8 fa ff ff    	je     430 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x150>
     938:	c4 c1 65 72 d2 10    	vpsrld $0x10,%ymm10,%ymm3
     93e:	c4 c1 6d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm2
     944:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     948:	48 83 c0 60          	add    $0x60,%rax
     94c:	c4 c1 75 72 d0 10    	vpsrld $0x10,%ymm8,%ymm1
     952:	c5 05 76 fc          	vpcmpeqd %ymm4,%ymm15,%ymm15
     956:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     95a:	c5 fe 6f 9c 24 20 02 	vmovdqu 0x220(%rsp),%ymm3
     961:	00 00 
     963:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     967:	c5 9d 76 cc          	vpcmpeqd %ymm4,%ymm12,%ymm1
     96b:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
     971:	c5 d5 76 ec          	vpcmpeqd %ymm4,%ymm5,%ymm5
     975:	c5 3d db c3          	vpand  %ymm3,%ymm8,%ymm8
     979:	c5 35 db cb          	vpand  %ymm3,%ymm9,%ymm9
     97d:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
     982:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     986:	c5 2d db d3          	vpand  %ymm3,%ymm10,%ymm10
     98a:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
     990:	c5 3d fa c1          	vpsubd %ymm1,%ymm8,%ymm8
     994:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     998:	c4 e2 45 90 0c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm1
     99e:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
     9a2:	c4 62 65 90 34 82    	vpgatherdd %ymm3,(%rdx,%ymm0,4),%ymm14
     9a8:	c4 c2 3d 3d f1       	vpmaxsd %ymm9,%ymm8,%ymm6
     9ad:	c4 c1 35 66 d8       	vpcmpgtd %ymm8,%ymm9,%ymm3
     9b2:	c5 ad 66 fe          	vpcmpgtd %ymm6,%ymm10,%ymm7
     9b6:	c4 42 3d 39 d9       	vpminsd %ymm9,%ymm8,%ymm11
     9bb:	c4 c2 4d 3d f2       	vpmaxsd %ymm10,%ymm6,%ymm6
     9c0:	c4 c1 3d fe e9       	vpaddd %ymm9,%ymm8,%ymm5
     9c5:	c4 41 3d 66 c1       	vpcmpgtd %ymm9,%ymm8,%ymm8
     9ca:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
     9cf:	c4 41 5d db ce       	vpand  %ymm14,%ymm4,%ymm9
     9d4:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
     9da:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 9e3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x703>
     9e1:	ff ff 70 
     9e4:	c4 c2 25 39 fa       	vpminsd %ymm10,%ymm11,%ymm7
     9e9:	c5 4d fe e7          	vpaddd %ymm7,%ymm6,%ymm12
     9ed:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     9f1:	c4 41 25 66 da       	vpcmpgtd %ymm10,%ymm11,%ymm11
     9f6:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     9fb:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
     a00:	c4 e2 1d 90 1c 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm3
     a06:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
     a0c:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
     a11:	c4 43 6d 4c c7 80    	vpblendvb %ymm8,%ymm15,%ymm2,%ymm8
     a17:	c5 7e 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm15
     a1e:	00 00 
     a20:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm8,%ymm8        # a29 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x749>
     a27:	ff ff b0 
     a2a:	c5 65 db dc          	vpand  %ymm4,%ymm3,%ymm11
     a2e:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
     a33:	c4 e2 1d 90 14 82    	vpgatherdd %ymm12,(%rdx,%ymm0,4),%ymm2
     a39:	c5 f5 db c4          	vpand  %ymm4,%ymm1,%ymm0
     a3d:	c5 6d db c4          	vpand  %ymm4,%ymm2,%ymm8
     a41:	c5 ad 72 f0 10       	vpslld $0x10,%ymm0,%ymm10
     a46:	c5 a5 fa c0          	vpsubd %ymm0,%ymm11,%ymm0
     a4a:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
     a4f:	c4 41 3d fa c3       	vpsubd %ymm11,%ymm8,%ymm8
     a54:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     a59:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
     a5e:	c4 62 3d 40 c5       	vpmulld %ymm5,%ymm8,%ymm8
     a63:	c4 41 2d fe d7       	vpaddd %ymm15,%ymm10,%ymm10
     a68:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     a6d:	c5 b5 fe c0          	vpaddd %ymm0,%ymm9,%ymm0
     a71:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     a76:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     a7b:	c4 c1 35 72 d6 08    	vpsrld $0x8,%ymm14,%ymm9
     a81:	c5 2d db d4          	vpand  %ymm4,%ymm10,%ymm10
     a85:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
     a8a:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
     a8f:	c5 35 db cc          	vpand  %ymm4,%ymm9,%ymm9
     a93:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
     a98:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     a9d:	c5 3d db c4          	vpand  %ymm4,%ymm8,%ymm8
     aa1:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     aa5:	c4 c1 25 72 f0 10    	vpslld $0x10,%ymm8,%ymm11
     aab:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
     ab0:	c5 35 fa c8          	vpsubd %ymm0,%ymm9,%ymm9
     ab4:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
     ab9:	c4 62 3d 40 c6       	vpmulld %ymm6,%ymm8,%ymm8
     abe:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
     ac3:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     ac8:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     acd:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
     ad1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ad6:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     adb:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ae0:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     ae4:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     ae8:	c4 41 35 fe c8       	vpaddd %ymm8,%ymm9,%ymm9
     aed:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     af2:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
     af7:	c5 35 fe c8          	vpaddd %ymm0,%ymm9,%ymm9
     afb:	c4 c1 7d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm0
     b01:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     b06:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     b0a:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     b10:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
     b14:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     b18:	c4 41 7d 6f f9       	vmovdqa %ymm9,%ymm15
     b1d:	c4 e2 7d 40 ff       	vpmulld %ymm7,%ymm0,%ymm7
     b22:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
     b27:	c5 e5 fa c1          	vpsubd %ymm1,%ymm3,%ymm0
     b2b:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     b30:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
     b35:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     b39:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     b3d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     b42:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     b46:	49 39 c1             	cmp    %rax,%r9
     b49:	0f 85 66 fd ff ff    	jne    8b5 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5d5>
     b4f:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
     b53:	c4 c1 75 72 f1 08    	vpslld $0x8,%ymm9,%ymm1
     b59:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     b5e:	48 83 c1 18          	add    $0x18,%rcx
     b62:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
     b66:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     b6a:	c4 e2 7d 00 84 24 60 	vpshufb 0x260(%rsp),%ymm0,%ymm0
     b71:	02 00 00 
     b74:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     b78:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     b7e:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     b83:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     b88:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     b8c:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
     b91:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
     b96:	49 39 c8             	cmp    %rcx,%r8
     b99:	0f 85 31 f8 ff ff    	jne    3d0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf0>
     b9f:	c5 f8 77             	vzeroupper
     ba2:	c5 f8 28 b4 24 50 03 	vmovaps 0x350(%rsp),%xmm6
     ba9:	00 00 
     bab:	c5 f8 28 bc 24 60 03 	vmovaps 0x360(%rsp),%xmm7
     bb2:	00 00 
     bb4:	c5 78 28 84 24 70 03 	vmovaps 0x370(%rsp),%xmm8
     bbb:	00 00 
     bbd:	c5 78 28 8c 24 80 03 	vmovaps 0x380(%rsp),%xmm9
     bc4:	00 00 
     bc6:	c5 78 28 94 24 90 03 	vmovaps 0x390(%rsp),%xmm10
     bcd:	00 00 
     bcf:	c5 78 28 9c 24 a0 03 	vmovaps 0x3a0(%rsp),%xmm11
     bd6:	00 00 
     bd8:	c5 78 28 a4 24 b0 03 	vmovaps 0x3b0(%rsp),%xmm12
     bdf:	00 00 
     be1:	c5 78 28 ac 24 c0 03 	vmovaps 0x3c0(%rsp),%xmm13
     be8:	00 00 
     bea:	c5 78 28 b4 24 d0 03 	vmovaps 0x3d0(%rsp),%xmm14
     bf1:	00 00 
     bf3:	c5 78 28 bc 24 e0 03 	vmovaps 0x3e0(%rsp),%xmm15
     bfa:	00 00 
     bfc:	48 81 c4 f0 03 00 00 	add    $0x3f0,%rsp
     c03:	5b                   	pop    %rbx
     c04:	5e                   	pop    %rsi
     c05:	5f                   	pop    %rdi
     c06:	41 5e                	pop    %r14
     c08:	41 5f                	pop    %r15
     c0a:	c3                   	ret
     c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     c10:	c5 f5 db 0d 40 00 00 	vpand  0x40(%rip),%ymm1,%ymm1        # c58 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x978>
     c17:	00 
     c18:	c5 fd db 05 40 00 00 	vpand  0x40(%rip),%ymm0,%ymm0        # c60 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x980>
     c1f:	00 
     c20:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     c25:	c5 b5 db 15 40 00 00 	vpand  0x40(%rip),%ymm9,%ymm2        # c6d <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x98d>
     c2c:	00 
     c2d:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
     c33:	c4 e2 7d 3d f9       	vpmaxsd %ymm1,%ymm0,%ymm7
     c38:	c5 f5 66 e8          	vpcmpgtd %ymm0,%ymm1,%ymm5
     c3c:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     c42:	48 8b 58 40          	mov    0x40(%rax),%rbx
     c46:	c5 ed 66 df          	vpcmpgtd %ymm7,%ymm2,%ymm3
     c4a:	c4 e2 45 3d fa       	vpmaxsd %ymm2,%ymm7,%ymm7
     c4f:	c4 c3 4d 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm6,%ymm5
     c55:	c4 e2 7d 39 f1       	vpminsd %ymm1,%ymm0,%ymm6
     c5a:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm5,%ymm5        # c63 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x983>
     c61:	ff ff 30 
     c64:	c4 62 4d 39 c2       	vpminsd %ymm2,%ymm6,%ymm8
     c69:	c5 d5 fe ac 24 20 01 	vpaddd 0x120(%rsp),%ymm5,%ymm5
     c70:	00 00 
     c72:	c5 cd 66 f2          	vpcmpgtd %ymm2,%ymm6,%ymm6
     c76:	c4 e2 25 90 1c aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm3
     c7c:	c5 fd 66 e9          	vpcmpgtd %ymm1,%ymm0,%ymm5
     c80:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     c86:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     c8a:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     c8f:	c5 fd fe ca          	vpaddd %ymm2,%ymm0,%ymm1
     c93:	c4 c1 45 fe c0       	vpaddd %ymm8,%ymm7,%ymm0
     c98:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     c9c:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
     ca0:	c4 c3 25 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm11,%ymm5
     ca6:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     cab:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm5,%ymm5        # cb4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9d4>
     cb2:	ff ff 60 
     cb5:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
     cbc:	00 00 
     cbe:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
     cc2:	c4 e2 25 90 34 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm6
     cc8:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     ccc:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
     cd3:	00 00 
     cd5:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     cda:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
     cde:	c5 cd fa cb          	vpsubd %ymm3,%ymm6,%ymm1
     ce2:	c5 e5 fa 9c 24 c0 01 	vpsubd 0x1c0(%rsp),%ymm3,%ymm3
     ce9:	00 00 
     ceb:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     cf0:	c5 ad fa ce          	vpsubd %ymm6,%ymm10,%ymm1
     cf4:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     cfa:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     cff:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     d04:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     d08:	c5 fe 6f 8c 24 00 01 	vmovdqu 0x100(%rsp),%ymm1
     d0f:	00 00 
     d11:	c5 e5 fe 9c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm3,%ymm3
     d18:	00 00 
     d1a:	c4 e2 55 90 14 8b    	vpgatherdd %ymm5,(%rbx,%ymm1,4),%ymm2
     d20:	48 8b 58 38          	mov    0x38(%rax),%rbx
     d24:	c5 fe 6f 8c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm1
     d2b:	00 00 
     d2d:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     d31:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     d35:	c5 ed db 15 40 00 00 	vpand  0x40(%rip),%ymm2,%ymm2        # d7d <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa9d>
     d3c:	00 
     d3d:	c4 e2 55 90 1c 8b    	vpgatherdd %ymm5,(%rbx,%ymm1,4),%ymm3
     d43:	48 8b 58 30          	mov    0x30(%rax),%rbx
     d47:	c5 b5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm9
     d4c:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     d50:	c5 e5 db 1d 40 00 00 	vpand  0x40(%rip),%ymm3,%ymm3        # d98 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xab8>
     d57:	00 
     d58:	c4 41 7d 6f f9       	vmovdqa %ymm9,%ymm15
     d5d:	c4 a2 55 90 0c 9b    	vpgatherdd %ymm5,(%rbx,%ymm11,4),%ymm1
     d63:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     d68:	c5 f5 db 0d 40 00 00 	vpand  0x40(%rip),%ymm1,%ymm1        # db0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xad0>
     d6f:	00 
     d70:	c4 e2 75 3d f3       	vpmaxsd %ymm3,%ymm1,%ymm6
     d75:	c5 e5 66 e9          	vpcmpgtd %ymm1,%ymm3,%ymm5
     d79:	c4 e2 75 39 fb       	vpminsd %ymm3,%ymm1,%ymm7
     d7e:	c5 ed 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm0
     d82:	c4 62 45 39 c2       	vpminsd %ymm2,%ymm7,%ymm8
     d87:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     d8c:	c5 c5 66 fa          	vpcmpgtd %ymm2,%ymm7,%ymm7
     d90:	c4 c3 2d 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm10,%ymm5
     d96:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm5,%ymm5        # d9f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xabf>
     d9d:	ff ff 00 
     da0:	c5 d5 fe ac 24 20 01 	vpaddd 0x120(%rsp),%ymm5,%ymm5
     da7:	00 00 
     da9:	c4 e2 25 90 04 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm0
     daf:	c5 f5 66 eb          	vpcmpgtd %ymm3,%ymm1,%ymm5
     db3:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     db8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     dbd:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     dc1:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     dc5:	c4 c3 2d 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm10,%ymm5
     dcb:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm5,%ymm5        # dd4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xaf4>
     dd2:	ff ff 70 
     dd5:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
     ddc:	00 00 
     dde:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     de2:	c4 e2 25 90 3c aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm7
     de8:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
     ded:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     df2:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     df6:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
     dfd:	00 00 
     dff:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
     e03:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
     e07:	c5 c5 fa d0          	vpsubd %ymm0,%ymm7,%ymm2
     e0b:	c5 fd fa 84 24 80 01 	vpsubd 0x180(%rsp),%ymm0,%ymm0
     e12:	00 00 
     e14:	c4 e2 75 40 d2       	vpmulld %ymm2,%ymm1,%ymm2
     e19:	c5 d5 fa cf          	vpsubd %ymm7,%ymm5,%ymm1
     e1d:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     e22:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     e27:	c5 fd fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm0,%ymm0
     e2e:	00 00 
     e30:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     e34:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     e38:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     e3d:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     e41:	e9 62 fa ff ff       	jmp    8a8 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
     e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     e4d:	00 00 00 
     e50:	c5 fe 6f ac 24 00 02 	vmovdqu 0x200(%rsp),%ymm5
     e57:	00 00 
     e59:	c5 fd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm0
     e5e:	c5 fe 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm2
     e65:	00 00 
     e67:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     e6c:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     e70:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
     e76:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
     e7a:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
     e7f:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     e83:	c5 2d fa c9          	vpsubd %ymm1,%ymm10,%ymm9
     e87:	c5 f5 fa c8          	vpsubd %ymm0,%ymm1,%ymm1
     e8b:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     e90:	c4 62 35 40 ca       	vpmulld %ymm2,%ymm9,%ymm9
     e95:	c5 fd fa 84 24 c0 01 	vpsubd 0x1c0(%rsp),%ymm0,%ymm0
     e9c:	00 00 
     e9e:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     ea3:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
     ea7:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
     eac:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
     eb3:	00 00 
     eb5:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     eb9:	c4 c1 7d fe c6       	vpaddd %ymm14,%ymm0,%ymm0
     ebe:	c5 35 fe c8          	vpaddd %ymm0,%ymm9,%ymm9
     ec2:	c5 d5 fa c1          	vpsubd %ymm1,%ymm5,%ymm0
     ec6:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
     ecb:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     ed1:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
     ed5:	c5 c5 fa bc 24 80 01 	vpsubd 0x180(%rsp),%ymm7,%ymm7
     edc:	00 00 
     ede:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     ee3:	c4 41 7d 6f f9       	vmovdqa %ymm9,%ymm15
     ee8:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
     eed:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     ef1:	c5 c5 fe bc 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm7,%ymm7
     ef8:	00 00 
     efa:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     efe:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f03:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     f07:	e9 9c f9 ff ff       	jmp    8a8 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
     f0c:	0f 1f 40 00          	nopl   0x0(%rax)
     f10:	c5 7d 6f c9          	vmovdqa %ymm1,%ymm9
     f14:	e9 3a fc ff ff       	jmp    b53 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x873>
     f19:	41 80 7a 58 00       	cmpb   $0x0,0x58(%r10)
     f1e:	0f 85 43 f4 ff ff    	jne    367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f24:	41 80 ba b8 00 00 00 	cmpb   $0x0,0xb8(%r10)
     f2b:	00 
     f2c:	0f 84 35 f4 ff ff    	je     367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f32:	41 80 ba 18 01 00 00 	cmpb   $0x0,0x118(%r10)
     f39:	00 
     f3a:	0f 84 27 f4 ff ff    	je     367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f40:	41 80 ba 78 01 00 00 	cmpb   $0x0,0x178(%r10)
     f47:	00 
     f48:	0f 84 19 f4 ff ff    	je     367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f4e:	41 80 ba ba 00 00 00 	cmpb   $0x0,0xba(%r10)
     f55:	00 
     f56:	41 0f b6 82 1a 01 00 	movzbl 0x11a(%r10),%eax
     f5d:	00 
     f5e:	0f 84 4c 0c 00 00    	je     1bb0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18d0>
     f64:	84 c0                	test   %al,%al
     f66:	0f 84 fb f3 ff ff    	je     367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f6c:	41 80 ba 7a 01 00 00 	cmpb   $0x0,0x17a(%r10)
     f73:	00 
     f74:	0f 84 ed f3 ff ff    	je     367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
     f7a:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
     f7f:	0f 85 09 12 00 00    	jne    218e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1eae>
     f85:	4d 85 c9             	test   %r9,%r9
     f88:	0f 84 14 fc ff ff    	je     ba2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c2>
     f8e:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     f92:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 101a <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd3a>
     f99:	00 
     f9a:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
     f9f:	48 c1 e8 03          	shr    $0x3,%rax
     fa3:	c4 c1 15 72 d4 18    	vpsrld $0x18,%ymm12,%ymm13
     fa9:	48 6b c0 18          	imul   $0x18,%rax,%rax
     fad:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
     fb4:	00 00 
     fb6:	c5 fd 6f 25 a0 00 00 	vmovdqa 0xa0(%rip),%ymm4        # 105e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd7e>
     fbd:	00 
     fbe:	c5 fe 7f a4 24 60 02 	vmovdqu %ymm4,0x260(%rsp)
     fc5:	00 00 
     fc7:	4c 8d 5c 01 18       	lea    0x18(%rcx,%rax,1),%r11
     fcc:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
     fd0:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
     fd5:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
     fd9:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     fde:	49 8b 02             	mov    (%r10),%rax
     fe1:	45 8b 42 54          	mov    0x54(%r10),%r8d
     fe5:	48 83 c1 18          	add    $0x18,%rcx
     fe9:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     fef:	41 8b 52 50          	mov    0x50(%r10),%edx
     ff3:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     ff9:	c4 c1 79 6e f8       	vmovd  %r8d,%xmm7
     ffe:	c4 e2 7d 00 84 24 40 	vpshufb 0x240(%rsp),%ymm0,%ymm0
    1005:	02 00 00 
    1008:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    100c:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1011:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
    1016:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    101b:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1020:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    1026:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
    102b:	41 8d 54 10 01       	lea    0x1(%r8,%rdx,1),%edx
    1030:	c4 e2 6d 90 04 a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm0
    1036:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    103b:	49 8b 42 08          	mov    0x8(%r10),%rax
    103f:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1043:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    1049:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    104e:	c5 fd db 05 40 00 00 	vpand  0x40(%rip),%ymm0,%ymm0        # 1096 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdb6>
    1055:	00 
    1056:	c4 e2 6d 90 34 a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm6
    105c:	49 8b 42 10          	mov    0x10(%r10),%rax
    1060:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    1065:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1069:	c4 a2 6d 90 24 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm4
    106f:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1074:	49 8b 42 48          	mov    0x48(%r10),%rax
    1078:	c5 cd db 35 40 00 00 	vpand  0x40(%rip),%ymm6,%ymm6        # 10c0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde0>
    107f:	00 
    1080:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1085:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    108a:	c5 dd db 25 40 00 00 	vpand  0x40(%rip),%ymm4,%ymm4        # 10d2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdf2>
    1091:	00 
    1092:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    1097:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    109b:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    109f:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    10a3:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    10a7:	c4 62 65 90 34 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm14
    10ad:	c5 f9 6e da          	vmovd  %edx,%xmm3
    10b1:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    10b6:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    10ba:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    10c0:	c4 62 2d 90 3c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm15
    10c6:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    10cb:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
    10d2:	00 00 
    10d4:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm5,%ymm5        # 10dd <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdfd>
    10db:	ff ff a0 
    10de:	c4 62 3d 3d d4       	vpmaxsd %ymm4,%ymm8,%ymm10
    10e3:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    10e8:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    10ef:	00 00 
    10f1:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    10f5:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    10fa:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    10ff:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
    1105:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    1109:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    110d:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    1111:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    1117:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm5,%ymm5        # 1120 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe40>
    111e:	ff ff 80 
    1121:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    1126:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    112a:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    1130:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
    1136:	c4 c1 05 db ed       	vpand  %ymm13,%ymm15,%ymm5
    113b:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
    1142:	00 00 
    1144:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    1149:	c5 15 db 74 24 60    	vpand  0x60(%rsp),%ymm13,%ymm14
    114f:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1153:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    1158:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    115c:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    1160:	c4 c1 3d 72 f6 10    	vpslld $0x10,%ymm14,%ymm8
    1166:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    116b:	c5 bd fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm0        # 1193 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xeb3>
    1172:	00 
    1173:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
    1178:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    117f:	00 00 00 
    1182:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    1186:	c5 95 db a4 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm4
    118d:	00 00 
    118f:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1194:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    1199:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    119e:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    11a2:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    11a8:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    11ac:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    11b2:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    11b7:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    11be:	00 00 
    11c0:	c4 a2 2d 90 34 9a    	vpgatherdd %ymm10,(%rdx,%ymm11,4),%ymm6
    11c6:	49 8b 52 20          	mov    0x20(%r10),%rdx
    11ca:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    11cf:	c5 cd db 35 40 00 00 	vpand  0x40(%rip),%ymm6,%ymm6        # 1217 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf37>
    11d6:	00 
    11d7:	c4 62 2d 90 04 a2    	vpgatherdd %ymm10,(%rdx,%ymm4,4),%ymm8
    11dd:	49 8b 52 18          	mov    0x18(%r10),%rdx
    11e1:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    11e6:	c5 3d db 05 40 00 00 	vpand  0x40(%rip),%ymm8,%ymm8        # 122e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf4e>
    11ed:	00 
    11ee:	c4 e2 2d 90 24 aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm4
    11f4:	c5 dd db 25 40 00 00 	vpand  0x40(%rip),%ymm4,%ymm4        # 123c <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf5c>
    11fb:	00 
    11fc:	c4 c2 5d 3d e8       	vpmaxsd %ymm8,%ymm4,%ymm5
    1201:	c5 bd 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm0
    1205:	c5 4d 66 d5          	vpcmpgtd %ymm5,%ymm6,%ymm10
    1209:	c4 62 55 3d ce       	vpmaxsd %ymm6,%ymm5,%ymm9
    120e:	c4 c2 5d 39 e8       	vpminsd %ymm8,%ymm4,%ymm5
    1213:	c4 62 55 39 f6       	vpminsd %ymm6,%ymm5,%ymm14
    1218:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    121c:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    1222:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    1229:	00 00 
    122b:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm0,%ymm0        # 1234 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf54>
    1232:	ff ff a0 
    1235:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    123a:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    123e:	c4 62 2d 90 34 80    	vpgatherdd %ymm10,(%rax,%ymm0,4),%ymm14
    1244:	c4 c1 5d 66 c0       	vpcmpgtd %ymm8,%ymm4,%ymm0
    1249:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    124e:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    1254:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 125d <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf7d>
    125b:	ff ff 50 
    125e:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1262:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1266:	c4 62 55 90 14 80    	vpgatherdd %ymm5,(%rax,%ymm0,4),%ymm10
    126c:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
    1272:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
    1278:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    127f:	00 00 
    1281:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    1287:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    128c:	c4 41 0d fe f1       	vpaddd %ymm9,%ymm14,%ymm14
    1291:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    1296:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    129b:	c4 41 7d db fd       	vpand  %ymm13,%ymm0,%ymm15
    12a0:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    12a5:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    12ac:	00 00 
    12ae:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    12b2:	c5 ad fa f5          	vpsubd %ymm5,%ymm10,%ymm6
    12b6:	c4 e2 5d 40 f6       	vpmulld %ymm6,%ymm4,%ymm6
    12bb:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    12c0:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    12c5:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    12ca:	c5 fe 7f 84 24 e0 00 	vmovdqu %ymm0,0xe0(%rsp)
    12d1:	00 00 
    12d3:	c4 c1 7d 72 f7 10    	vpslld $0x10,%ymm15,%ymm0
    12d9:	c5 fd fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm0,%ymm0        # 1301 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1021>
    12e0:	00 
    12e1:	c5 95 db a4 24 e0 00 	vpand  0xe0(%rsp),%ymm13,%ymm4
    12e8:	00 00 
    12ea:	49 8b 52 40          	mov    0x40(%r10),%rdx
    12ee:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    12f4:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    12f9:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    12fe:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    1305:	00 00 
    1307:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    130b:	c4 e2 5d 40 a4 24 a0 	vpmulld 0xa0(%rsp),%ymm4,%ymm4
    1312:	00 00 00 
    1315:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1319:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    131d:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    1323:	c5 d5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm5
    1328:	c4 a2 2d 90 04 9a    	vpgatherdd %ymm10,(%rdx,%ymm11,4),%ymm0
    132e:	49 8b 52 38          	mov    0x38(%r10),%rdx
    1332:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    1337:	c5 fd db 05 40 00 00 	vpand  0x40(%rip),%ymm0,%ymm0        # 137f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x109f>
    133e:	00 
    133f:	c4 e2 2d 90 34 a2    	vpgatherdd %ymm10,(%rdx,%ymm4,4),%ymm6
    1345:	49 8b 52 30          	mov    0x30(%r10),%rdx
    1349:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    134e:	c5 cd db 35 40 00 00 	vpand  0x40(%rip),%ymm6,%ymm6        # 1396 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10b6>
    1355:	00 
    1356:	c4 a2 2d 90 24 b2    	vpgatherdd %ymm10,(%rdx,%ymm14,4),%ymm4
    135c:	c5 dd db 25 40 00 00 	vpand  0x40(%rip),%ymm4,%ymm4        # 13a4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10c4>
    1363:	00 
    1364:	c4 62 5d 3d c6       	vpmaxsd %ymm6,%ymm4,%ymm8
    1369:	c5 4d 66 d4          	vpcmpgtd %ymm4,%ymm6,%ymm10
    136d:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    1372:	c4 62 3d 3d d8       	vpmaxsd %ymm0,%ymm8,%ymm11
    1377:	c4 62 5d 39 c6       	vpminsd %ymm6,%ymm4,%ymm8
    137c:	c4 63 75 4c d7 a0    	vpblendvb %ymm10,%ymm7,%ymm1,%ymm10
    1382:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm10,%ymm10        # 138b <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10ab>
    1389:	ff ff 90 
    138c:	c4 62 3d 39 c8       	vpminsd %ymm0,%ymm8,%ymm9
    1391:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1396:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
    139a:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    139f:	c4 62 2d 90 34 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm14
    13a5:	c5 dd 66 d6          	vpcmpgtd %ymm6,%ymm4,%ymm2
    13a9:	c4 41 25 fe d1       	vpaddd %ymm9,%ymm11,%ymm10
    13ae:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    13b2:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    13b7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    13bb:	c4 e3 75 4c cf 20    	vpblendvb %ymm2,%ymm7,%ymm1,%ymm1
    13c1:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    13c5:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm1,%ymm1        # 13ce <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10ee>
    13cc:	ff ff 80 
    13cf:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    13d3:	c4 c1 75 72 d6 10    	vpsrld $0x10,%ymm14,%ymm1
    13d9:	c4 e2 6d 90 3c 98    	vpgatherdd %ymm2,(%rax,%ymm3,4),%ymm7
    13df:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    13e5:	c4 c1 65 72 d7 10    	vpsrld $0x10,%ymm15,%ymm3
    13eb:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    13f0:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    13f5:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    13fa:	49 8b 42 60          	mov    0x60(%r10),%rax
    13fe:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1403:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    1408:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    140d:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    1411:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    1415:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    141a:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    141f:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1423:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1428:	c5 bd 72 f2 10       	vpslld $0x10,%ymm2,%ymm8
    142d:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    1434:	00 00 
    1436:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    143a:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 1462 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1182>
    1441:	00 
    1442:	c4 a2 5d 90 14 98    	vpgatherdd %ymm4,(%rax,%ymm11,4),%ymm2
    1448:	49 8b 42 68          	mov    0x68(%r10),%rax
    144c:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    1450:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    1455:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
    1459:	c4 e2 5d 90 1c a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm3
    145f:	49 8b 42 70          	mov    0x70(%r10),%rax
    1463:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    1467:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    146b:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    1470:	45 8b 8a b0 00 00 00 	mov    0xb0(%r10),%r9d
    1477:	45 8b 82 b4 00 00 00 	mov    0xb4(%r10),%r8d
    147e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1483:	c4 c1 55 76 ed       	vpcmpeqd %ymm13,%ymm5,%ymm5
    1488:	c5 e5 db 1d c0 00 00 	vpand  0xc0(%rip),%ymm3,%ymm3        # 1550 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1270>
    148f:	00 
    1490:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
    1496:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    149b:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    14a0:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    14a7:	c5 c5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm7
    14ac:	c4 c1 7d 76 c5       	vpcmpeqd %ymm13,%ymm0,%ymm0
    14b1:	c5 ed db 15 c0 00 00 	vpand  0xc0(%rip),%ymm2,%ymm2        # 1579 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1299>
    14b8:	00 
    14b9:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    14bd:	c5 f5 db 0d c0 00 00 	vpand  0xc0(%rip),%ymm1,%ymm1        # 1585 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x12a5>
    14c4:	00 
    14c5:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    14c9:	c5 cd fe f4          	vpaddd %ymm4,%ymm6,%ymm6
    14cd:	c4 c1 15 76 e3       	vpcmpeqd %ymm11,%ymm13,%ymm4
    14d2:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    14d6:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    14db:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    14df:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
    14e4:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
    14e8:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    14ed:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    14f1:	c5 f5 fa e0          	vpsubd %ymm0,%ymm1,%ymm4
    14f5:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
    14fb:	c4 62 6d 3d cb       	vpmaxsd %ymm3,%ymm2,%ymm9
    1500:	c5 65 66 d2          	vpcmpgtd %ymm2,%ymm3,%ymm10
    1504:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1508:	c4 e2 55 90 04 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm0
    150e:	c4 41 5d 66 c1       	vpcmpgtd %ymm9,%ymm4,%ymm8
    1513:	c5 6d fe fb          	vpaddd %ymm3,%ymm2,%ymm15
    1517:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    151d:	c4 62 6d 39 f3       	vpminsd %ymm3,%ymm2,%ymm14
    1522:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
    1527:	c4 62 35 3d cc       	vpmaxsd %ymm4,%ymm9,%ymm9
    152c:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    1530:	c4 62 0d 39 dc       	vpminsd %ymm4,%ymm14,%ymm11
    1535:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    153a:	c5 0d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm14
    153e:	c4 63 55 4c 54 24 20 	vpblendvb %ymm10,0x20(%rsp),%ymm5,%ymm10
    1545:	a0 
    1546:	c4 c1 75 db dd       	vpand  %ymm13,%ymm1,%ymm3
    154b:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm10,%ymm10        # 1554 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1274>
    1552:	ff ff 80 
    1555:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    155a:	c4 e3 55 4c 54 24 20 	vpblendvb %ymm2,0x20(%rsp),%ymm5,%ymm2
    1561:	20 
    1562:	c4 41 5d fa c0       	vpsubd %ymm8,%ymm4,%ymm8
    1567:	c4 41 4d fe d2       	vpaddd %ymm10,%ymm6,%ymm10
    156c:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm2,%ymm2        # 1575 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1295>
    1573:	ff ff e0 
    1576:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    157b:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    157f:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
    1583:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    1588:	c4 e2 5d 90 2c b8    	vpgatherdd %ymm4,(%rax,%ymm7,4),%ymm5
    158e:	c4 a2 05 90 34 90    	vpgatherdd %ymm15,(%rax,%ymm10,4),%ymm6
    1594:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
    1599:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    15a0:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
    15a5:	c5 c5 72 f3 10       	vpslld $0x10,%ymm3,%ymm7
    15aa:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    15af:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    15b3:	c5 ad fa db          	vpsubd %ymm3,%ymm10,%ymm3
    15b7:	c5 8d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm14
    15bc:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
    15c1:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    15c6:	c5 c5 fe 3d 20 00 00 	vpaddd 0x20(%rip),%ymm7,%ymm7        # 15ee <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130e>
    15cd:	00 
    15ce:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    15d3:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    15d8:	c4 41 0d db f5       	vpand  %ymm13,%ymm14,%ymm14
    15dd:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    15e2:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    15e7:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    15eb:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    15ef:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
    15f4:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    15f8:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    15fd:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    1602:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1607:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
    160c:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    1611:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1616:	c5 8d fa ff          	vpsubd %ymm7,%ymm14,%ymm7
    161a:	c5 2d fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm10,%ymm10        # 1642 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1362>
    1621:	00 
    1622:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1627:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    162c:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1630:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1635:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    163a:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    163f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1644:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1649:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    164e:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1652:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1656:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    165b:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    165f:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    1664:	c4 c1 75 db d5       	vpand  %ymm13,%ymm1,%ymm2
    1669:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    166e:	c5 d5 72 f2 10       	vpslld $0x10,%ymm2,%ymm5
    1673:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    1677:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    167c:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1681:	c5 d5 fe 2d 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm5        # 16a9 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13c9>
    1688:	00 
    1689:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    168d:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1691:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    1696:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    169b:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    169f:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    16a3:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    16a7:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
    16ad:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    16b4:	c4 c1 65 76 dd       	vpcmpeqd %ymm13,%ymm3,%ymm3
    16b9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    16bd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    16c2:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    16c8:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    16cf:	c4 c1 5d 76 e5       	vpcmpeqd %ymm13,%ymm4,%ymm4
    16d4:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    16d8:	c5 cd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm6
    16dd:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
    16e3:	45 8b 8a 10 01 00 00 	mov    0x110(%r10),%r9d
    16ea:	45 8b 82 14 01 00 00 	mov    0x114(%r10),%r8d
    16f1:	c5 c5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm7
    16f6:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
    16fb:	c4 c1 7d 76 c5       	vpcmpeqd %ymm13,%ymm0,%ymm0
    1700:	c5 ed db 15 c0 00 00 	vpand  0xc0(%rip),%ymm2,%ymm2        # 17c8 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14e8>
    1707:	00 
    1708:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    170f:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    1714:	c5 f5 db 0d c0 00 00 	vpand  0xc0(%rip),%ymm1,%ymm1        # 17dc <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14fc>
    171b:	00 
    171c:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
    1721:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    1725:	c5 d5 db 1d c0 00 00 	vpand  0xc0(%rip),%ymm5,%ymm3        # 17ed <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x150d>
    172c:	00 
    172d:	c5 79 6e c2          	vmovd  %edx,%xmm8
    1731:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1735:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1739:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    173e:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    1742:	c5 3d fe c6          	vpaddd %ymm6,%ymm8,%ymm8
    1746:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
    174b:	c5 f5 fa e0          	vpsubd %ymm0,%ymm1,%ymm4
    174f:	c4 62 6d 3d d3       	vpmaxsd %ymm3,%ymm2,%ymm10
    1754:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
    175a:	c5 e5 66 fa          	vpcmpgtd %ymm2,%ymm3,%ymm7
    175e:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1762:	c5 6d fe fb          	vpaddd %ymm3,%ymm2,%ymm15
    1766:	c4 a2 55 90 04 80    	vpgatherdd %ymm5,(%rax,%ymm8,4),%ymm0
    176c:	c4 41 5d 66 ca       	vpcmpgtd %ymm10,%ymm4,%ymm9
    1771:	c4 62 6d 39 f3       	vpminsd %ymm3,%ymm2,%ymm14
    1776:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
    177b:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    177f:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    1784:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    178a:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    178f:	c4 62 0d 39 dc       	vpminsd %ymm4,%ymm14,%ymm11
    1794:	c4 62 2d 3d d4       	vpmaxsd %ymm4,%ymm10,%ymm10
    1799:	c5 0d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm14
    179d:	c4 e3 55 4c 7c 24 20 	vpblendvb %ymm7,0x20(%rsp),%ymm5,%ymm7
    17a4:	70 
    17a5:	c4 c1 75 db dd       	vpand  %ymm13,%ymm1,%ymm3
    17aa:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # 17b3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d3>
    17b1:	ff ff 90 
    17b4:	c4 e3 55 4c 54 24 20 	vpblendvb %ymm2,0x20(%rsp),%ymm5,%ymm2
    17bb:	20 
    17bc:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    17c1:	c4 41 5d fa c9       	vpsubd %ymm9,%ymm4,%ymm9
    17c6:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    17ca:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    17ce:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm2,%ymm2        # 17d7 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14f7>
    17d5:	ff ff e0 
    17d8:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    17dd:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    17e2:	c5 3d fa c2          	vpsubd %ymm2,%ymm8,%ymm8
    17e6:	c4 e2 05 90 3c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm7
    17ec:	c5 cd 72 f3 10       	vpslld $0x10,%ymm3,%ymm6
    17f1:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    17f6:	c4 a2 5d 90 2c 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm5
    17fc:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    1803:	c4 41 45 db c5       	vpand  %ymm13,%ymm7,%ymm8
    1808:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    180d:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
    1812:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1816:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
    181a:	c4 41 0d db f5       	vpand  %ymm13,%ymm14,%ymm14
    181f:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    1824:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    1829:	c5 cd fe 35 20 00 00 	vpaddd 0x20(%rip),%ymm6,%ymm6        # 1851 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1571>
    1830:	00 
    1831:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1836:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    183b:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    183f:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1843:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    1848:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    184c:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    1851:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    1856:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    185b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1860:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1865:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    186a:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    186f:	c5 8d fa f6          	vpsubd %ymm6,%ymm14,%ymm6
    1873:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1877:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    187c:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1881:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1886:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    188b:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 18b3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15d3>
    1892:	00 
    1893:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1898:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    189d:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    18a2:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    18a7:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    18ab:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    18b0:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    18b4:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    18b9:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    18bd:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    18c2:	c4 c1 75 db d5       	vpand  %ymm13,%ymm1,%ymm2
    18c7:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    18cc:	c5 d5 72 f2 10       	vpslld $0x10,%ymm2,%ymm5
    18d1:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    18d5:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    18da:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    18df:	c5 d5 fe 2d 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm5        # 1907 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1627>
    18e6:	00 
    18e7:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    18eb:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    18ef:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    18f4:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    18f9:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    18fd:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1901:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1905:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
    190b:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    1912:	c4 c1 65 76 dd       	vpcmpeqd %ymm13,%ymm3,%ymm3
    1917:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    191b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1920:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    1926:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    192d:	c4 c1 5d 76 e5       	vpcmpeqd %ymm13,%ymm4,%ymm4
    1932:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1936:	c5 cd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm6
    193b:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
    1941:	45 8b 8a 70 01 00 00 	mov    0x170(%r10),%r9d
    1948:	45 8b 82 74 01 00 00 	mov    0x174(%r10),%r8d
    194f:	c5 c5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm7
    1954:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
    1959:	c4 c1 7d 76 c5       	vpcmpeqd %ymm13,%ymm0,%ymm0
    195e:	c5 ed db 15 c0 00 00 	vpand  0xc0(%rip),%ymm2,%ymm2        # 1a26 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1746>
    1965:	00 
    1966:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    196d:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    1972:	c5 f5 db 0d c0 00 00 	vpand  0xc0(%rip),%ymm1,%ymm1        # 1a3a <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x175a>
    1979:	00 
    197a:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
    197f:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    1983:	c5 d5 db 1d c0 00 00 	vpand  0xc0(%rip),%ymm5,%ymm3        # 1a4b <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x176b>
    198a:	00 
    198b:	c5 79 6e c2          	vmovd  %edx,%xmm8
    198f:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1993:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1997:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    199c:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    19a0:	c5 3d fe c6          	vpaddd %ymm6,%ymm8,%ymm8
    19a4:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
    19a9:	c5 f5 fa e0          	vpsubd %ymm0,%ymm1,%ymm4
    19ad:	c4 62 6d 3d d3       	vpmaxsd %ymm3,%ymm2,%ymm10
    19b2:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
    19b8:	c5 e5 66 fa          	vpcmpgtd %ymm2,%ymm3,%ymm7
    19bc:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    19c0:	c5 6d fe fb          	vpaddd %ymm3,%ymm2,%ymm15
    19c4:	c4 a2 55 90 04 80    	vpgatherdd %ymm5,(%rax,%ymm8,4),%ymm0
    19ca:	c4 41 5d 66 ca       	vpcmpgtd %ymm10,%ymm4,%ymm9
    19cf:	c4 62 6d 39 f3       	vpminsd %ymm3,%ymm2,%ymm14
    19d4:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    19d9:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    19dd:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
    19e2:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    19e8:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    19ed:	c4 62 0d 39 dc       	vpminsd %ymm4,%ymm14,%ymm11
    19f2:	c4 62 2d 3d d4       	vpmaxsd %ymm4,%ymm10,%ymm10
    19f7:	c5 0d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm14
    19fb:	c4 e3 55 4c 7c 24 20 	vpblendvb %ymm7,0x20(%rsp),%ymm5,%ymm7
    1a02:	70 
    1a03:	c4 c1 75 db dd       	vpand  %ymm13,%ymm1,%ymm3
    1a08:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # 1a11 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1731>
    1a0f:	ff ff 90 
    1a12:	c4 e3 55 4c 54 24 20 	vpblendvb %ymm2,0x20(%rsp),%ymm5,%ymm2
    1a19:	20 
    1a1a:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    1a1f:	c4 41 5d fa c9       	vpsubd %ymm9,%ymm4,%ymm9
    1a24:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1a28:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1a2c:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm2,%ymm2        # 1a35 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1755>
    1a33:	ff ff e0 
    1a36:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    1a3b:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    1a40:	c5 3d fa c2          	vpsubd %ymm2,%ymm8,%ymm8
    1a44:	c4 e2 05 90 3c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm7
    1a4a:	c5 cd 72 f3 10       	vpslld $0x10,%ymm3,%ymm6
    1a4f:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    1a54:	c4 a2 55 90 24 80    	vpgatherdd %ymm5,(%rax,%ymm8,4),%ymm4
    1a5a:	c4 c1 5d db d5       	vpand  %ymm13,%ymm4,%ymm2
    1a5f:	c4 41 45 db c5       	vpand  %ymm13,%ymm7,%ymm8
    1a64:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    1a69:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1a6d:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
    1a71:	c4 41 0d db f5       	vpand  %ymm13,%ymm14,%ymm14
    1a76:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    1a7b:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1a80:	c5 cd fe 35 20 00 00 	vpaddd 0x20(%rip),%ymm6,%ymm6        # 1aa8 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17c8>
    1a87:	00 
    1a88:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1a8d:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1a92:	c5 d5 fe db          	vpaddd %ymm3,%ymm5,%ymm3
    1a96:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1a9a:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    1a9f:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1aa3:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    1aa8:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1aad:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
    1ab2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1ab7:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1abc:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    1ac1:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1ac6:	c5 8d fa f6          	vpsubd %ymm6,%ymm14,%ymm6
    1aca:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1ace:	c4 c1 6d fa d6       	vpsubd %ymm14,%ymm2,%ymm2
    1ad3:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1ad8:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1add:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1ae2:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 1b0a <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x182a>
    1ae9:	00 
    1aea:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1aef:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1af4:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1af9:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1afd:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1b02:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    1b07:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    1b0b:	c4 c1 75 db ed       	vpand  %ymm13,%ymm1,%ymm5
    1b10:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1b15:	c5 f5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm1
    1b1a:	c5 dd 72 f5 10       	vpslld $0x10,%ymm5,%ymm4
    1b1f:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    1b23:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1b28:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1b2d:	c5 dd fe 25 20 00 00 	vpaddd 0x20(%rip),%ymm4,%ymm4        # 1b55 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1875>
    1b34:	00 
    1b35:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1b39:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1b3d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1b42:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1b47:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    1b4c:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    1b51:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1b55:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1b59:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1b5d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1b62:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    1b67:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    1b6b:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    1b6f:	c4 e2 7d 00 84 24 60 	vpshufb 0x260(%rsp),%ymm0,%ymm0
    1b76:	02 00 00 
    1b79:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1b7d:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1b83:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1b88:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1b8d:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1b91:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
    1b96:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
    1b9b:	49 39 cb             	cmp    %rcx,%r11
    1b9e:	0f 85 28 f4 ff ff    	jne    fcc <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcec>
    1ba4:	e9 f6 ef ff ff       	jmp    b9f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8bf>
    1ba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1bb0:	84 c0                	test   %al,%al
    1bb2:	0f 85 af e7 ff ff    	jne    367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
    1bb8:	41 80 ba 7a 01 00 00 	cmpb   $0x0,0x17a(%r10)
    1bbf:	00 
    1bc0:	0f 85 a1 e7 ff ff    	jne    367 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x87>
    1bc6:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
    1bcb:	49 8d 5a 60          	lea    0x60(%r10),%rbx
    1bcf:	0f 84 22 12 00 00    	je     2df7 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2b17>
    1bd5:	4d 85 c9             	test   %r9,%r9
    1bd8:	0f 84 c4 ef ff ff    	je     ba2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c2>
    1bde:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 1c66 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1986>
    1be5:	00 
    1be6:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    1bea:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    1bef:	49 89 df             	mov    %rbx,%r15
    1bf2:	48 c1 e8 03          	shr    $0x3,%rax
    1bf6:	49 89 cb             	mov    %rcx,%r11
    1bf9:	45 31 c9             	xor    %r9d,%r9d
    1bfc:	4c 89 c3             	mov    %r8,%rbx
    1bff:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
    1c06:	00 00 
    1c08:	c5 fd 6f 25 a0 00 00 	vmovdqa 0xa0(%rip),%ymm4        # 1cb0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19d0>
    1c0f:	00 
    1c10:	49 8d 50 60          	lea    0x60(%r8),%rdx
    1c14:	4c 8d 70 01          	lea    0x1(%rax),%r14
    1c18:	c4 c1 35 72 d3 18    	vpsrld $0x18,%ymm11,%ymm9
    1c1e:	c5 fe 7f a4 24 60 02 	vmovdqu %ymm4,0x260(%rsp)
    1c25:	00 00 
    1c27:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    1c2c:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    1c32:	4c 89 8c 24 40 01 00 	mov    %r9,0x140(%rsp)
    1c39:	00 
    1c3a:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1c3e:	49 8b 02             	mov    (%r10),%rax
    1c41:	41 8b 4a 50          	mov    0x50(%r10),%ecx
    1c45:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1c4b:	c4 42 7d 58 52 54    	vpbroadcastd 0x54(%r10),%ymm10
    1c51:	45 8b 42 54          	mov    0x54(%r10),%r8d
    1c55:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1c5b:	c4 e2 7d 00 84 24 40 	vpshufb 0x240(%rsp),%ymm0,%ymm0
    1c62:	02 00 00 
    1c65:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    1c6a:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1c6f:	c4 c1 7d db d9       	vpand  %ymm9,%ymm0,%ymm3
    1c74:	c4 e2 5d 90 3c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm7
    1c7a:	49 8b 42 08          	mov    0x8(%r10),%rax
    1c7e:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    1c83:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1c87:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    1c8c:	c4 a2 5d 90 14 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm2
    1c92:	49 8b 42 10          	mov    0x10(%r10),%rax
    1c96:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1c9a:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
    1c9f:	c4 e2 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm0
    1ca5:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1caa:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    1cae:	49 8b 42 48          	mov    0x48(%r10),%rax
    1cb2:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1cb7:	c5 9d 72 d0 11       	vpsrld $0x11,%ymm0,%ymm12
    1cbc:	41 8d 4c 08 01       	lea    0x1(%r8,%rcx,1),%ecx
    1cc1:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
    1cc6:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1cca:	c4 c1 4d 72 d3 0f    	vpsrld $0xf,%ymm11,%ymm6
    1cd0:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
    1cd4:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
    1cd8:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
    1cdc:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1ce1:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1ce5:	c4 62 4d 90 34 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm14
    1ceb:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    1cef:	49 8b 4a 18          	mov    0x18(%r10),%rcx
    1cf3:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1cf8:	c5 4d fe e5          	vpaddd %ymm5,%ymm6,%ymm12
    1cfc:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d00:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    1d06:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1d0b:	c4 22 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm13,4),%ymm12
    1d11:	c4 c1 15 72 d3 1f    	vpsrld $0x1f,%ymm11,%ymm13
    1d17:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d1b:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    1d21:	c4 62 4d 90 3c 99    	vpgatherdd %ymm6,(%rcx,%ymm3,4),%ymm15
    1d27:	49 8b 4a 20          	mov    0x20(%r10),%rcx
    1d2b:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d2f:	c4 a2 4d 90 1c 81    	vpgatherdd %ymm6,(%rcx,%ymm8,4),%ymm3
    1d35:	49 8b 4a 28          	mov    0x28(%r10),%rcx
    1d39:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d3d:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    1d44:	00 00 
    1d46:	c4 e2 4d 90 1c 89    	vpgatherdd %ymm6,(%rcx,%ymm1,4),%ymm3
    1d4c:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
    1d50:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d54:	4c 89 f9             	mov    %r15,%rcx
    1d57:	c5 fe 7f 9c 24 e0 00 	vmovdqu %ymm3,0xe0(%rsp)
    1d5e:	00 00 
    1d60:	c4 e2 45 3d da       	vpmaxsd %ymm2,%ymm7,%ymm3
    1d65:	c5 7d 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm8
    1d69:	c4 c3 5d 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm4,%ymm1
    1d6f:	c4 c3 75 4c cd 80    	vpblendvb %ymm8,%ymm13,%ymm1,%ymm1
    1d75:	c4 62 65 3d c0       	vpmaxsd %ymm0,%ymm3,%ymm8
    1d7a:	c4 e2 45 39 da       	vpminsd %ymm2,%ymm7,%ymm3
    1d7f:	c5 7e 7f 84 24 00 01 	vmovdqu %ymm8,0x100(%rsp)
    1d86:	00 00 
    1d88:	c4 62 65 39 c0       	vpminsd %ymm0,%ymm3,%ymm8
    1d8d:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    1d91:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    1d95:	c5 7e 7f 84 24 a0 00 	vmovdqu %ymm8,0xa0(%rsp)
    1d9c:	00 00 
    1d9e:	c4 62 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm12
    1da4:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
    1da8:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1dac:	c4 c3 5d 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm4,%ymm1
    1db2:	c4 c3 75 4c cd 30    	vpblendvb %ymm3,%ymm13,%ymm1,%ymm1
    1db8:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1dbe:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    1dc2:	c4 c1 1d db d9       	vpand  %ymm9,%ymm12,%ymm3
    1dc7:	c4 62 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm8
    1dcd:	c5 7e 7f 74 24 40    	vmovdqu %ymm14,0x40(%rsp)
    1dd3:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    1dda:	00 00 
    1ddc:	c5 b5 db 4c 24 40    	vpand  0x40(%rsp),%ymm9,%ymm1
    1de2:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    1de7:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
    1dee:	00 00 
    1df0:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    1df7:	00 00 
    1df9:	c5 f5 72 f6 10       	vpslld $0x10,%ymm6,%ymm1
    1dfe:	c5 fe 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm6
    1e05:	00 00 
    1e07:	c5 f5 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm1,%ymm1        # 1e2f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b4f>
    1e0e:	00 
    1e0f:	c5 0d fe e6          	vpaddd %ymm6,%ymm14,%ymm12
    1e13:	c5 45 fe f2          	vpaddd %ymm2,%ymm7,%ymm14
    1e17:	c4 41 7d fa e4       	vpsubd %ymm12,%ymm0,%ymm12
    1e1c:	c4 41 1d fe f6       	vpaddd %ymm14,%ymm12,%ymm14
    1e21:	c5 3d fa e3          	vpsubd %ymm3,%ymm8,%ymm12
    1e25:	c4 42 0d 40 e4       	vpmulld %ymm12,%ymm14,%ymm12
    1e2a:	c5 e5 fa 9c 24 80 00 	vpsubd 0x80(%rsp),%ymm3,%ymm3
    1e31:	00 00 
    1e33:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    1e3a:	00 00 
    1e3c:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    1e41:	c5 9d fe c9          	vpaddd %ymm1,%ymm12,%ymm1
    1e45:	c5 35 db 64 24 60    	vpand  0x60(%rsp),%ymm9,%ymm12
    1e4b:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    1e50:	c4 c1 1d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm12
    1e56:	c4 62 3d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm8,%ymm8
    1e5d:	00 00 00 
    1e60:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    1e64:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    1e68:	c5 fe 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm3
    1e6f:	00 00 
    1e71:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1e76:	c4 c1 3d 72 e7 10    	vpsrad $0x10,%ymm15,%ymm8
    1e7c:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    1e80:	c5 cd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm6
    1e85:	c4 c1 3d fe cc       	vpaddd %ymm12,%ymm8,%ymm1
    1e8a:	c5 fe 7f b4 24 00 01 	vmovdqu %ymm6,0x100(%rsp)
    1e91:	00 00 
    1e93:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
    1e9a:	00 00 
    1e9c:	c5 f5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm1
    1ea1:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    1ea6:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1eab:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1eaf:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    1eb3:	c4 c1 7d 72 f6 10    	vpslld $0x10,%ymm14,%ymm0
    1eb9:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    1ebe:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1ec2:	c5 e5 fe d0          	vpaddd %ymm0,%ymm3,%ymm2
    1ec6:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    1ecd:	00 00 
    1ecf:	c4 c1 6d 72 f7 10    	vpslld $0x10,%ymm15,%ymm2
    1ed5:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    1eda:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1ede:	c4 62 6d 3d f0       	vpmaxsd %ymm0,%ymm2,%ymm14
    1ee3:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
    1ee7:	c4 41 65 66 fe       	vpcmpgtd %ymm14,%ymm3,%ymm15
    1eec:	c4 c3 5d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm4,%ymm7
    1ef2:	c4 c3 45 4c fd f0    	vpblendvb %ymm15,%ymm13,%ymm7,%ymm7
    1ef8:	c4 62 0d 3d fb       	vpmaxsd %ymm3,%ymm14,%ymm15
    1efd:	c4 62 6d 39 f0       	vpminsd %ymm0,%ymm2,%ymm14
    1f02:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    1f06:	c4 e2 0d 39 f3       	vpminsd %ymm3,%ymm14,%ymm6
    1f0b:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
    1f12:	00 00 
    1f14:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    1f18:	c5 0d 66 f3          	vpcmpgtd %ymm3,%ymm14,%ymm14
    1f1c:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1f22:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1f29:	00 00 
    1f2b:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1f2f:	c4 62 4d 90 3c b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm15
    1f35:	c4 c3 5d 4c c2 00    	vpblendvb %ymm0,%ymm10,%ymm4,%ymm0
    1f3b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1f3f:	c4 c3 7d 4c c5 e0    	vpblendvb %ymm14,%ymm13,%ymm0,%ymm0
    1f45:	c4 41 7d 6f f3       	vmovdqa %ymm11,%ymm14
    1f4a:	c5 e5 fa d8          	vpsubd %ymm0,%ymm3,%ymm3
    1f4e:	c4 e2 0d 90 04 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm0
    1f54:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
    1f5a:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    1f5f:	c4 c1 65 72 d6 08    	vpsrld $0x8,%ymm14,%ymm3
    1f65:	c4 41 7d db f1       	vpand  %ymm9,%ymm0,%ymm14
    1f6a:	c4 41 65 db f9       	vpand  %ymm9,%ymm3,%ymm15
    1f6f:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    1f74:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    1f7a:	c5 fe 6f b4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm6
    1f81:	00 00 
    1f83:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    1f88:	c5 cd fe 84 24 80 00 	vpaddd 0x80(%rsp),%ymm6,%ymm0
    1f8f:	00 00 
    1f91:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
    1f96:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    1f9d:	00 00 
    1f9f:	c4 c1 45 72 f7 10    	vpslld $0x10,%ymm15,%ymm7
    1fa5:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    1fa9:	c5 8d fa d3          	vpsubd %ymm3,%ymm14,%ymm2
    1fad:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
    1fb4:	00 00 
    1fb6:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    1fbb:	c4 e2 65 40 9c 24 80 	vpmulld 0x80(%rsp),%ymm3,%ymm3
    1fc2:	00 00 00 
    1fc5:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1fca:	c5 c5 fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm7,%ymm2        # 1ff2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d12>
    1fd1:	00 
    1fd2:	c4 c2 3d 39 fc       	vpminsd %ymm12,%ymm8,%ymm7
    1fd7:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    1fdb:	c5 b5 db 84 24 20 01 	vpand  0x120(%rsp),%ymm9,%ymm0
    1fe2:	00 00 
    1fe4:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
    1fe9:	c4 62 45 39 f1       	vpminsd %ymm1,%ymm7,%ymm14
    1fee:	c5 c5 66 f9          	vpcmpgtd %ymm1,%ymm7,%ymm7
    1ff2:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    1ff7:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1ffb:	c4 c2 3d 3d dc       	vpmaxsd %ymm12,%ymm8,%ymm3
    2000:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    2004:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
    2008:	c4 e2 65 3d d9       	vpmaxsd %ymm1,%ymm3,%ymm3
    200d:	c5 85 72 d2 10       	vpsrld $0x10,%ymm2,%ymm15
    2012:	c4 c1 1d 66 d0       	vpcmpgtd %ymm8,%ymm12,%ymm2
    2017:	c4 41 3d 66 c4       	vpcmpgtd %ymm12,%ymm8,%ymm8
    201c:	c4 c3 5d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm4,%ymm2
    2022:	c4 c3 6d 4c d5 00    	vpblendvb %ymm0,%ymm13,%ymm2,%ymm2
    2028:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    202c:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2030:	c4 e2 55 90 04 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm0
    2036:	c4 c3 5d 4c d2 80    	vpblendvb %ymm8,%ymm10,%ymm4,%ymm2
    203c:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    2042:	c4 c3 6d 4c d5 70    	vpblendvb %ymm7,%ymm13,%ymm2,%ymm2
    2048:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    204d:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    2053:	c5 dd fa f2          	vpsubd %ymm2,%ymm4,%ymm6
    2057:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    205b:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    2061:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    2067:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    206c:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    2071:	c5 7d 7f bb 80 00 00 	vmovdqa %ymm15,0x80(%rbx)
    2078:	00 
    2079:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    207e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2083:	c4 c1 65 fe c6       	vpaddd %ymm14,%ymm3,%ymm0
    2088:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    208c:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    2091:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    2096:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
    209d:	00 00 
    209f:	c5 d5 fa ca          	vpsubd %ymm2,%ymm5,%ymm1
    20a3:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    20a8:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    20ac:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    20b1:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    20b6:	c5 c5 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm7,%ymm1        # 20de <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1dfe>
    20bd:	00 
    20be:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    20c2:	c4 c1 4d db c9       	vpand  %ymm9,%ymm6,%ymm1
    20c7:	c5 fe 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm6
    20ce:	00 00 
    20d0:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    20d4:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    20d9:	c5 fd 7f 73 60       	vmovdqa %ymm6,0x60(%rbx)
    20de:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    20e2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    20e6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    20eb:	c5 fd 7f 83 a0 00 00 	vmovdqa %ymm0,0xa0(%rbx)
    20f2:	00 
    20f3:	c5 f8 77             	vzeroupper
    20f6:	e8 05 df ff ff       	call   0 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)>
    20fb:	49 8d 8a c0 00 00 00 	lea    0xc0(%r10),%rcx
    2102:	49 83 c3 18          	add    $0x18,%r11
    2106:	e8 f5 de ff ff       	call   0 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)>
    210b:	49 8d 8a 20 01 00 00 	lea    0x120(%r10),%rcx
    2112:	e8 e9 de ff ff       	call   0 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)>
    2117:	c5 fd 6f 8b a0 00 00 	vmovdqa 0xa0(%rbx),%ymm1
    211e:	00 
    211f:	c5 fd 6f 83 80 00 00 	vmovdqa 0x80(%rbx),%ymm0
    2126:	00 
    2127:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    212c:	4c 8b 8c 24 40 01 00 	mov    0x140(%rsp),%r9
    2133:	00 
    2134:	c5 7d 6f 0d 60 00 00 	vmovdqa 0x60(%rip),%ymm9        # 219c <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ebc>
    213b:	00 
    213c:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    2141:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    2146:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    214a:	49 ff c1             	inc    %r9
    214d:	c5 fd eb 43 60       	vpor   0x60(%rbx),%ymm0,%ymm0
    2152:	c4 e2 7d 00 84 24 60 	vpshufb 0x260(%rsp),%ymm0,%ymm0
    2159:	02 00 00 
    215c:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2160:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2166:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    216b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2170:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2174:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    217a:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    2180:	4d 39 ce             	cmp    %r9,%r14
    2183:	0f 85 9e fa ff ff    	jne    1c27 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1947>
    2189:	e9 11 ea ff ff       	jmp    b9f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8bf>
    218e:	4d 85 c9             	test   %r9,%r9
    2191:	0f 84 0b ea ff ff    	je     ba2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c2>
    2197:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 221f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f3f>
    219e:	00 
    219f:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    21a3:	48 c1 e8 03          	shr    $0x3,%rax
    21a7:	48 6b c0 18          	imul   $0x18,%rax,%rax
    21ab:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
    21b2:	00 00 
    21b4:	c5 fd 6f 25 a0 00 00 	vmovdqa 0xa0(%rip),%ymm4        # 225c <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f7c>
    21bb:	00 
    21bc:	c5 fe 7f a4 24 60 02 	vmovdqu %ymm4,0x260(%rsp)
    21c3:	00 00 
    21c5:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    21c9:	4c 8d 5c 01 18       	lea    0x18(%rcx,%rax,1),%r11
    21ce:	c5 a5 72 d4 18       	vpsrld $0x18,%ymm4,%ymm11
    21d3:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
    21d7:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
    21dc:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    21e0:	48 83 c1 18          	add    $0x18,%rcx
    21e4:	49 8b 02             	mov    (%r10),%rax
    21e7:	c5 fd 6f fa          	vmovdqa %ymm2,%ymm7
    21eb:	45 8b 42 54          	mov    0x54(%r10),%r8d
    21ef:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    21f5:	41 8b 52 50          	mov    0x50(%r10),%edx
    21f9:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    21ff:	c4 41 79 6e c0       	vmovd  %r8d,%xmm8
    2204:	c4 e2 7d 00 84 24 40 	vpshufb 0x240(%rsp),%ymm0,%ymm0
    220b:	02 00 00 
    220e:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2212:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    2217:	c4 41 7d db cb       	vpand  %ymm11,%ymm0,%ymm9
    221c:	c5 9d 72 d0 08       	vpsrld $0x8,%ymm0,%ymm12
    2221:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2226:	c4 a2 6d 90 24 88    	vpgatherdd %ymm2,(%rax,%ymm9,4),%ymm4
    222c:	49 8b 42 08          	mov    0x8(%r10),%rax
    2230:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    2235:	c5 fd 6f d7          	vmovdqa %ymm7,%ymm2
    2239:	c5 ad 72 d0 10       	vpsrld $0x10,%ymm0,%ymm10
    223e:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    2243:	41 8d 54 10 01       	lea    0x1(%r8,%rdx,1),%edx
    2248:	c4 a2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm12,4),%ymm5
    224e:	49 8b 42 10          	mov    0x10(%r10),%rax
    2252:	c5 fd 6f fa          	vmovdqa %ymm2,%ymm7
    2256:	c5 dd db 25 40 00 00 	vpand  0x40(%rip),%ymm4,%ymm4        # 229e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fbe>
    225d:	00 
    225e:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    2263:	c4 a2 6d 90 34 90    	vpgatherdd %ymm2,(%rax,%ymm10,4),%ymm6
    2269:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    226e:	49 8b 42 48          	mov    0x48(%r10),%rax
    2272:	c5 d5 db 2d 40 00 00 	vpand  0x40(%rip),%ymm5,%ymm5        # 22ba <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fda>
    2279:	00 
    227a:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    227f:	c5 e5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm3
    2284:	c5 cd db 35 40 00 00 	vpand  0x40(%rip),%ymm6,%ymm6        # 22cc <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fec>
    228b:	00 
    228c:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    2290:	c5 fd 6f c7          	vmovdqa %ymm7,%ymm0
    2294:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    2298:	c5 fd 6f df          	vmovdqa %ymm7,%ymm3
    229c:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    22a0:	c4 e2 65 90 3c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm7
    22a6:	c5 f9 6e da          	vmovd  %edx,%xmm3
    22aa:	49 8b 52 18          	mov    0x18(%r10),%rdx
    22ae:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    22b3:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    22b8:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    22bc:	c4 62 7d 90 3c 98    	vpgatherdd %ymm0,(%rax,%ymm3,4),%ymm15
    22c2:	c5 7e 7f 7c 24 20    	vmovdqu %ymm15,0x20(%rsp)
    22c8:	c4 22 0d 90 3c 8a    	vpgatherdd %ymm14,(%rdx,%ymm9,4),%ymm15
    22ce:	49 8b 52 20          	mov    0x20(%r10),%rdx
    22d2:	c5 55 66 cc          	vpcmpgtd %ymm4,%ymm5,%ymm9
    22d6:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    22db:	c4 a2 0d 90 04 a2    	vpgatherdd %ymm14,(%rdx,%ymm12,4),%ymm0
    22e1:	49 8b 52 28          	mov    0x28(%r10),%rdx
    22e5:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
    22ea:	c4 43 75 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm1,%ymm9
    22f0:	c4 22 1d 90 34 92    	vpgatherdd %ymm12,(%rdx,%ymm10,4),%ymm14
    22f6:	c4 62 5d 3d d5       	vpmaxsd %ymm5,%ymm4,%ymm10
    22fb:	c4 41 4d 66 e2       	vpcmpgtd %ymm10,%ymm6,%ymm12
    2300:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    2307:	00 00 
    2309:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm9,%ymm9        # 2312 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2032>
    2310:	ff ff c0 
    2313:	c4 62 2d 3d e6       	vpmaxsd %ymm6,%ymm10,%ymm12
    2318:	c4 62 5d 39 d5       	vpminsd %ymm5,%ymm4,%ymm10
    231d:	c4 62 2d 39 f6       	vpminsd %ymm6,%ymm10,%ymm14
    2322:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    2328:	c4 41 6d fe c9       	vpaddd %ymm9,%ymm2,%ymm9
    232d:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
    2332:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    2339:	00 00 
    233b:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    2340:	c5 2d 66 d6          	vpcmpgtd %ymm6,%ymm10,%ymm10
    2344:	c4 22 0d 90 2c 88    	vpgatherdd %ymm14,(%rax,%ymm9,4),%ymm13
    234a:	c5 5d 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm9
    234e:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    2355:	00 00 
    2357:	c4 43 75 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm1,%ymm9
    235d:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm9,%ymm9        # 2366 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2086>
    2364:	ff ff a0 
    2367:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    236c:	c4 41 65 fa c9       	vpsubd %ymm9,%ymm3,%ymm9
    2371:	c4 22 2d 90 24 88    	vpgatherdd %ymm10,(%rax,%ymm9,4),%ymm12
    2377:	c4 41 15 db d3       	vpand  %ymm11,%ymm13,%ymm10
    237c:	c5 0d fe 6c 24 60    	vpaddd 0x60(%rsp),%ymm14,%ymm13
    2382:	c4 41 45 db cb       	vpand  %ymm11,%ymm7,%ymm9
    2387:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    238b:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    2390:	c4 41 4d fa ed       	vpsubd %ymm13,%ymm6,%ymm13
    2395:	c5 7e 7f 4c 24 40    	vmovdqu %ymm9,0x40(%rsp)
    239b:	c4 41 15 fe f6       	vpaddd %ymm14,%ymm13,%ymm14
    23a0:	c4 41 1d fa ea       	vpsubd %ymm10,%ymm12,%ymm13
    23a5:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
    23ab:	c4 42 0d 40 ed       	vpmulld %ymm13,%ymm14,%ymm13
    23b0:	c5 2d fa 54 24 40    	vpsubd 0x40(%rsp),%ymm10,%ymm10
    23b6:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    23bc:	c5 35 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm9        # 23e4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2104>
    23c3:	00 
    23c4:	c4 62 2d 40 54 24 60 	vpmulld 0x60(%rsp),%ymm10,%ymm10
    23cb:	c4 41 15 fe c9       	vpaddd %ymm9,%ymm13,%ymm9
    23d0:	c5 25 db 6c 24 20    	vpand  0x20(%rsp),%ymm11,%ymm13
    23d6:	c4 41 15 fa e4       	vpsubd %ymm12,%ymm13,%ymm12
    23db:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    23e2:	00 00 
    23e4:	c4 62 1d 40 a4 24 80 	vpmulld 0x80(%rsp),%ymm12,%ymm12
    23eb:	00 00 00 
    23ee:	c4 41 1d fe e2       	vpaddd %ymm10,%ymm12,%ymm12
    23f3:	c4 c1 2d 72 e7 10    	vpsrad $0x10,%ymm15,%ymm10
    23f9:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    23fe:	c5 2d fe d4          	vpaddd %ymm4,%ymm10,%ymm10
    2402:	c4 c1 1d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm12
    2408:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
    240f:	00 00 
    2411:	c5 9d 72 e0 10       	vpsrad $0x10,%ymm0,%ymm12
    2416:	c5 1d fe e5          	vpaddd %ymm5,%ymm12,%ymm12
    241a:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
    241f:	c5 7e 7f 8c 24 80 00 	vmovdqu %ymm9,0x80(%rsp)
    2426:	00 00 
    2428:	c4 c1 35 72 e5 10    	vpsrad $0x10,%ymm13,%ymm9
    242e:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    2434:	c4 c1 15 72 e5 10    	vpsrad $0x10,%ymm13,%ymm13
    243a:	c5 35 fe ce          	vpaddd %ymm6,%ymm9,%ymm9
    243e:	c5 95 fe f6          	vpaddd %ymm6,%ymm13,%ymm6
    2442:	c5 95 72 f0 10       	vpslld $0x10,%ymm0,%ymm13
    2447:	c4 c1 15 72 e5 10    	vpsrad $0x10,%ymm13,%ymm13
    244d:	c5 95 fe ed          	vpaddd %ymm5,%ymm13,%ymm5
    2451:	c4 c1 15 72 f7 10    	vpslld $0x10,%ymm15,%ymm13
    2457:	c4 c1 15 72 e5 10    	vpsrad $0x10,%ymm13,%ymm13
    245d:	c5 cd fe c5          	vpaddd %ymm5,%ymm6,%ymm0
    2461:	c5 95 fe e4          	vpaddd %ymm4,%ymm13,%ymm4
    2465:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
    246b:	c4 62 5d 3d f5       	vpmaxsd %ymm5,%ymm4,%ymm14
    2470:	c5 55 66 ec          	vpcmpgtd %ymm4,%ymm5,%ymm13
    2474:	c4 41 4d 66 fe       	vpcmpgtd %ymm14,%ymm6,%ymm15
    2479:	c4 e2 0d 3d c6       	vpmaxsd %ymm6,%ymm14,%ymm0
    247e:	c4 62 5d 39 f5       	vpminsd %ymm5,%ymm4,%ymm14
    2483:	c5 dd 66 ed          	vpcmpgtd %ymm5,%ymm4,%ymm5
    2487:	c5 fe 7f 84 24 a0 00 	vmovdqu %ymm0,0xa0(%rsp)
    248e:	00 00 
    2490:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    2494:	c4 43 75 4c e8 d0    	vpblendvb %ymm13,%ymm8,%ymm1,%ymm13
    249a:	c4 63 15 4c 2d ff ff 	vpblendvb %ymm15,-0x1(%rip),%ymm13,%ymm13        # 24a3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x21c3>
    24a1:	ff ff f0 
    24a4:	c4 62 0d 39 fe       	vpminsd %ymm6,%ymm14,%ymm15
    24a9:	c5 0d 66 f6          	vpcmpgtd %ymm6,%ymm14,%ymm14
    24ad:	c4 c3 75 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm1,%ymm5
    24b3:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
    24b9:	c4 41 6d fe ed       	vpaddd %ymm13,%ymm2,%ymm13
    24be:	c4 22 7d 90 3c a8    	vpgatherdd %ymm0,(%rax,%ymm13,4),%ymm15
    24c4:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    24c8:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm5,%ymm5        # 24d1 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x21f1>
    24cf:	ff ff e0 
    24d2:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    24d7:	c5 e5 fa f5          	vpsubd %ymm5,%ymm3,%ymm6
    24db:	c4 41 0d db f3       	vpand  %ymm11,%ymm14,%ymm14
    24e0:	c4 e2 7d 90 2c b0    	vpgatherdd %ymm0,(%rax,%ymm6,4),%ymm5
    24e6:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    24ec:	c4 c1 4d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm6
    24f2:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    24f8:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    24fd:	c4 c1 4d db f3       	vpand  %ymm11,%ymm6,%ymm6
    2502:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    2507:	c5 7e 7f ac 24 e0 00 	vmovdqu %ymm13,0xe0(%rsp)
    250e:	00 00 
    2510:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
    2517:	00 00 
    2519:	c4 41 55 db eb       	vpand  %ymm11,%ymm5,%ymm13
    251e:	c4 c1 55 72 f6 10    	vpslld $0x10,%ymm14,%ymm5
    2524:	45 8b 8a b0 00 00 00 	mov    0xb0(%r10),%r9d
    252b:	45 8b 82 b4 00 00 00 	mov    0xb4(%r10),%r8d
    2532:	c5 05 fe f8          	vpaddd %ymm0,%ymm15,%ymm15
    2536:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    253b:	c5 15 fa fe          	vpsubd %ymm6,%ymm13,%ymm15
    253f:	c5 dd fe 64 24 60    	vpaddd 0x60(%rsp),%ymm4,%ymm4
    2545:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    254a:	c4 41 1d 66 f2       	vpcmpgtd %ymm10,%ymm12,%ymm14
    254f:	c4 e2 4d 40 f0       	vpmulld %ymm0,%ymm6,%ymm6
    2554:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    2559:	c4 42 5d 40 ff       	vpmulld %ymm15,%ymm4,%ymm15
    255e:	c5 d5 fe 25 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm4        # 2586 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x22a6>
    2565:	00 
    2566:	c5 a5 db ac 24 e0 00 	vpand  0xe0(%rsp),%ymm11,%ymm5
    256d:	00 00 
    256f:	c4 43 75 4c f0 e0    	vpblendvb %ymm14,%ymm8,%ymm1,%ymm14
    2575:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    257a:	c4 e2 55 40 6c 24 40 	vpmulld 0x40(%rsp),%ymm5,%ymm5
    2581:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    2585:	c5 85 fe e4          	vpaddd %ymm4,%ymm15,%ymm4
    2589:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    258d:	c4 c2 2d 3d ec       	vpmaxsd %ymm12,%ymm10,%ymm5
    2592:	c5 b5 66 f5          	vpcmpgtd %ymm5,%ymm9,%ymm6
    2596:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    259b:	c4 c2 55 3d e9       	vpmaxsd %ymm9,%ymm5,%ymm5
    25a0:	c4 63 0d 4c 35 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm14,%ymm14        # 25a9 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x22c9>
    25a7:	ff ff 60 
    25aa:	c4 c2 2d 39 f4       	vpminsd %ymm12,%ymm10,%ymm6
    25af:	c4 41 2d 66 d4       	vpcmpgtd %ymm12,%ymm10,%ymm10
    25b4:	c4 42 4d 39 e9       	vpminsd %ymm9,%ymm6,%ymm13
    25b9:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    25be:	c4 c1 4d 66 f1       	vpcmpgtd %ymm9,%ymm6,%ymm6
    25c3:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    25c8:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    25cc:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    25d1:	c4 c3 75 4c c8 a0    	vpblendvb %ymm10,%ymm8,%ymm1,%ymm1
    25d7:	c4 62 7d 90 3c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm15
    25dd:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    25e3:	c4 c1 55 fe c5       	vpaddd %ymm13,%ymm5,%ymm0
    25e8:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 25f1 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2311>
    25ef:	ff ff 60 
    25f2:	c5 b5 fa c0          	vpsubd %ymm0,%ymm9,%ymm0
    25f6:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
    25fb:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    25ff:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2604:	c5 fd fe 84 24 80 00 	vpaddd 0x80(%rsp),%ymm0,%ymm0
    260b:	00 00 
    260d:	c4 e2 0d 90 34 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm6
    2613:	c4 c1 75 72 d7 10    	vpsrld $0x10,%ymm15,%ymm1
    2619:	c4 c1 6d db d3       	vpand  %ymm11,%ymm2,%ymm2
    261e:	49 8b 42 60          	mov    0x60(%r10),%rax
    2622:	c5 e5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm3
    2627:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    262c:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    2631:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2636:	c4 c1 4d db f3       	vpand  %ymm11,%ymm6,%ymm6
    263b:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    2640:	c5 4d fa c1          	vpsubd %ymm1,%ymm6,%ymm8
    2644:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    2648:	c5 c5 72 f3 10       	vpslld $0x10,%ymm3,%ymm7
    264d:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    2651:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    2656:	c5 c5 fe 3d 20 00 00 	vpaddd 0x20(%rip),%ymm7,%ymm7        # 267e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x239e>
    265d:	00 
    265e:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    2665:	00 00 
    2667:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    266c:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    2671:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    2675:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    2679:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    267d:	c5 fd 6f d5          	vmovdqa %ymm5,%ymm2
    2681:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2685:	c4 a2 1d 90 0c a8    	vpgatherdd %ymm12,(%rax,%ymm13,4),%ymm1
    268b:	49 8b 42 68          	mov    0x68(%r10),%rax
    268f:	c5 7d 6f e5          	vmovdqa %ymm5,%ymm12
    2693:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2698:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    269d:	c5 f5 db 0d c0 00 00 	vpand  0xc0(%rip),%ymm1,%ymm1        # 2765 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2485>
    26a4:	00 
    26a5:	c4 e2 1d 90 34 a0    	vpgatherdd %ymm12,(%rax,%ymm4,4),%ymm6
    26ab:	49 8b 42 70          	mov    0x70(%r10),%rax
    26af:	c4 c1 5d 76 e3       	vpcmpeqd %ymm11,%ymm4,%ymm4
    26b4:	c5 7d 6f e5          	vmovdqa %ymm5,%ymm12
    26b8:	c4 e2 6d 90 2c 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm5
    26be:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
    26c3:	c5 cd db 35 c0 00 00 	vpand  0xc0(%rip),%ymm6,%ymm6        # 278b <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x24ab>
    26ca:	00 
    26cb:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    26d2:	c5 c5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm7
    26d7:	c4 c1 7d 76 c3       	vpcmpeqd %ymm11,%ymm0,%ymm0
    26dc:	c5 d5 db 2d c0 00 00 	vpand  0xc0(%rip),%ymm5,%ymm5        # 27a4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x24c4>
    26e3:	00 
    26e4:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    26e8:	c4 c1 25 76 fd       	vpcmpeqd %ymm13,%ymm11,%ymm7
    26ed:	c5 4d fa cc          	vpsubd %ymm4,%ymm6,%ymm9
    26f1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    26f5:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    26f9:	c4 41 79 6e e8       	vmovd  %r8d,%xmm13
    26fe:	c5 55 fa f0          	vpsubd %ymm0,%ymm5,%ymm14
    2702:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    2707:	c5 f5 fa df          	vpsubd %ymm7,%ymm1,%ymm3
    270b:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    270f:	c4 e2 1d 90 3c 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm7
    2715:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    271a:	c5 7d 6f e4          	vmovdqa %ymm4,%ymm12
    271e:	c4 41 65 fe c1       	vpaddd %ymm9,%ymm3,%ymm8
    2723:	c5 f5 fe ea          	vpaddd %ymm2,%ymm1,%ymm5
    2727:	c5 35 66 fb          	vpcmpgtd %ymm3,%ymm9,%ymm15
    272b:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    2731:	c4 e2 5d 90 04 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm0
    2737:	c4 c2 65 3d e9       	vpmaxsd %ymm9,%ymm3,%ymm5
    273c:	45 8b 8a 10 01 00 00 	mov    0x110(%r10),%r9d
    2743:	c5 8d 66 cd          	vpcmpgtd %ymm5,%ymm14,%ymm1
    2747:	c4 c2 55 3d ee       	vpmaxsd %ymm14,%ymm5,%ymm5
    274c:	45 8b 82 14 01 00 00 	mov    0x114(%r10),%r8d
    2753:	c4 43 2d 4c fd f0    	vpblendvb %ymm15,%ymm13,%ymm10,%ymm15
    2759:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    275e:	c4 63 05 4c 3d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm15,%ymm15        # 2767 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2487>
    2765:	ff ff 10 
    2768:	c4 c2 65 39 c9       	vpminsd %ymm9,%ymm3,%ymm1
    276d:	c4 c2 75 39 f6       	vpminsd %ymm14,%ymm1,%ymm6
    2772:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
    2777:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    277c:	c5 d5 fe e6          	vpaddd %ymm6,%ymm5,%ymm4
    2780:	c5 8d fa e4          	vpsubd %ymm4,%ymm14,%ymm4
    2784:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    2789:	c4 62 1d 90 04 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm8
    278f:	c4 c1 75 66 d6       	vpcmpgtd %ymm14,%ymm1,%ymm2
    2794:	c4 c1 65 66 c9       	vpcmpgtd %ymm9,%ymm3,%ymm1
    2799:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    279f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    27a4:	c4 41 3d db e3       	vpand  %ymm11,%ymm8,%ymm12
    27a9:	c4 c3 2d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm10,%ymm1
    27af:	c4 c1 15 72 d0 08    	vpsrld $0x8,%ymm8,%ymm13
    27b5:	c4 41 45 db d3       	vpand  %ymm11,%ymm7,%ymm10
    27ba:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm1,%ymm1        # 27c3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x24e3>
    27c1:	ff ff 20 
    27c4:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
    27ca:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    27cf:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    27d3:	c4 62 2d 40 d5       	vpmulld %ymm5,%ymm10,%ymm10
    27d8:	c5 35 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm9        # 2800 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2520>
    27df:	00 
    27e0:	c4 e2 05 90 14 88    	vpgatherdd %ymm15,(%rax,%ymm1,4),%ymm2
    27e6:	c4 c1 7d db cb       	vpand  %ymm11,%ymm0,%ymm1
    27eb:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    27f0:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    27f7:	c4 c1 6d db db       	vpand  %ymm11,%ymm2,%ymm3
    27fc:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2802:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    2806:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    280b:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    2810:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    2815:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    281a:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    281f:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2824:	c4 c1 45 db fb       	vpand  %ymm11,%ymm7,%ymm7
    2829:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
    282e:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2833:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    2838:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    283c:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    2842:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2847:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    284c:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    2851:	c4 41 15 fa e4       	vpsubd %ymm12,%ymm13,%ymm12
    2856:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    285b:	c4 62 1d 40 e5       	vpmulld %ymm5,%ymm12,%ymm12
    2860:	c5 2d fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm10,%ymm10        # 2888 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x25a8>
    2867:	00 
    2868:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    286d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2872:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
    2876:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    287b:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    2880:	c4 c1 6d db d3       	vpand  %ymm11,%ymm2,%ymm2
    2885:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    288a:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    288f:	c4 41 79 6e e8       	vmovd  %r8d,%xmm13
    2894:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    2898:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    289d:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    28a2:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    28a7:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    28ac:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    28b1:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
    28b6:	c5 b5 fe c9          	vpaddd %ymm1,%ymm9,%ymm1
    28ba:	c4 41 3d db cb       	vpand  %ymm11,%ymm8,%ymm9
    28bf:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    28c4:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    28c9:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    28cd:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    28d2:	c4 e2 45 40 ed       	vpmulld %ymm5,%ymm7,%ymm5
    28d7:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    28dc:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 2904 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2624>
    28e3:	00 
    28e4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    28e9:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    28ed:	c4 e2 1d 90 2c 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm5
    28f3:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    28fa:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    28ff:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2904:	c4 c1 65 76 db       	vpcmpeqd %ymm11,%ymm3,%ymm3
    2909:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    290d:	c4 e2 1d 90 24 88    	vpgatherdd %ymm12,(%rax,%ymm1,4),%ymm4
    2913:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    291a:	c4 c1 75 76 cb       	vpcmpeqd %ymm11,%ymm1,%ymm1
    291f:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    2923:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2928:	c5 cd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm6
    292d:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2932:	c4 62 6d 90 34 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm14
    2938:	c5 ed 72 d4 10       	vpsrld $0x10,%ymm4,%ymm2
    293d:	c5 dd db 25 c0 00 00 	vpand  0xc0(%rip),%ymm4,%ymm4        # 2a05 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2725>
    2944:	00 
    2945:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    294c:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
    2952:	c5 d5 db 2d c0 00 00 	vpand  0xc0(%rip),%ymm5,%ymm5        # 2a1a <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x273a>
    2959:	00 
    295a:	c5 0d db 35 c0 00 00 	vpand  0xc0(%rip),%ymm14,%ymm14        # 2a22 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2742>
    2961:	00 
    2962:	c5 5d fa c9          	vpsubd %ymm1,%ymm4,%ymm9
    2966:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    296a:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    296e:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    2972:	c4 c1 7d 76 c3       	vpcmpeqd %ymm11,%ymm0,%ymm0
    2977:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    297c:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    2980:	c5 f5 fe ea          	vpaddd %ymm2,%ymm1,%ymm5
    2984:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    2988:	c4 e2 1d 90 3c 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm7
    298e:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    2994:	c5 7d 6f e4          	vmovdqa %ymm4,%ymm12
    2998:	c4 41 65 fe c1       	vpaddd %ymm9,%ymm3,%ymm8
    299d:	c5 0d fa f0          	vpsubd %ymm0,%ymm14,%ymm14
    29a1:	c5 35 66 fb          	vpcmpgtd %ymm3,%ymm9,%ymm15
    29a5:	c4 e2 5d 90 04 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm0
    29ab:	c4 c2 65 3d e9       	vpmaxsd %ymm9,%ymm3,%ymm5
    29b0:	c5 8d 66 cd          	vpcmpgtd %ymm5,%ymm14,%ymm1
    29b4:	c4 c2 55 3d ee       	vpmaxsd %ymm14,%ymm5,%ymm5
    29b9:	c4 43 2d 4c fd f0    	vpblendvb %ymm15,%ymm13,%ymm10,%ymm15
    29bf:	c4 63 05 4c 3d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm15,%ymm15        # 29c8 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x26e8>
    29c6:	ff ff 10 
    29c9:	c4 c2 65 39 c9       	vpminsd %ymm9,%ymm3,%ymm1
    29ce:	45 8b 8a 70 01 00 00 	mov    0x170(%r10),%r9d
    29d5:	45 8b 82 74 01 00 00 	mov    0x174(%r10),%r8d
    29dc:	c4 c2 75 39 f6       	vpminsd %ymm14,%ymm1,%ymm6
    29e1:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
    29e6:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    29eb:	c5 d5 fe e6          	vpaddd %ymm6,%ymm5,%ymm4
    29ef:	43 8d 54 01 01       	lea    0x1(%r9,%r8,1),%edx
    29f4:	c5 8d fa e4          	vpsubd %ymm4,%ymm14,%ymm4
    29f8:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    29fd:	c4 62 1d 90 04 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm8
    2a03:	c4 c1 75 66 d6       	vpcmpgtd %ymm14,%ymm1,%ymm2
    2a08:	c4 c1 65 66 c9       	vpcmpgtd %ymm9,%ymm3,%ymm1
    2a0d:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2a13:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    2a18:	c4 41 3d db e3       	vpand  %ymm11,%ymm8,%ymm12
    2a1d:	c4 c3 2d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm10,%ymm1
    2a23:	c4 c1 15 72 d0 08    	vpsrld $0x8,%ymm8,%ymm13
    2a29:	c4 41 45 db d3       	vpand  %ymm11,%ymm7,%ymm10
    2a2e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm1,%ymm1        # 2a37 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2757>
    2a35:	ff ff 20 
    2a38:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
    2a3e:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    2a43:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    2a47:	c4 62 2d 40 d5       	vpmulld %ymm5,%ymm10,%ymm10
    2a4c:	c5 35 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm9        # 2a74 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2794>
    2a53:	00 
    2a54:	c4 e2 05 90 14 88    	vpgatherdd %ymm15,(%rax,%ymm1,4),%ymm2
    2a5a:	c4 c1 7d db cb       	vpand  %ymm11,%ymm0,%ymm1
    2a5f:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    2a64:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    2a6b:	c4 c1 6d db db       	vpand  %ymm11,%ymm2,%ymm3
    2a70:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2a76:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    2a7a:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    2a7f:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    2a84:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    2a89:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    2a8e:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    2a93:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2a98:	c4 c1 45 db fb       	vpand  %ymm11,%ymm7,%ymm7
    2a9d:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
    2aa2:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2aa7:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    2aac:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2ab0:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    2ab6:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2abb:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    2ac0:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    2ac5:	c4 41 15 fa e4       	vpsubd %ymm12,%ymm13,%ymm12
    2aca:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    2acf:	c4 62 1d 40 e5       	vpmulld %ymm5,%ymm12,%ymm12
    2ad4:	c5 2d fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm10,%ymm10        # 2afc <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x281c>
    2adb:	00 
    2adc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2ae1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2ae6:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
    2aea:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    2aef:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    2af4:	c4 c1 6d db d3       	vpand  %ymm11,%ymm2,%ymm2
    2af9:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    2afe:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    2b03:	c4 41 79 6e e8       	vmovd  %r8d,%xmm13
    2b08:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    2b0c:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    2b11:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    2b16:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    2b1b:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2b20:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2b25:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
    2b2a:	c5 b5 fe c9          	vpaddd %ymm1,%ymm9,%ymm1
    2b2e:	c4 41 3d db cb       	vpand  %ymm11,%ymm8,%ymm9
    2b33:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    2b38:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    2b3d:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    2b41:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    2b46:	c4 e2 45 40 ed       	vpmulld %ymm5,%ymm7,%ymm5
    2b4b:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    2b50:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 2b78 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2898>
    2b57:	00 
    2b58:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b5d:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2b61:	c4 e2 1d 90 2c 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm5
    2b67:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    2b6e:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2b73:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2b78:	c4 c1 65 76 db       	vpcmpeqd %ymm11,%ymm3,%ymm3
    2b7d:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2b81:	c4 e2 1d 90 24 88    	vpgatherdd %ymm12,(%rax,%ymm1,4),%ymm4
    2b87:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    2b8e:	c4 c1 75 76 cb       	vpcmpeqd %ymm11,%ymm1,%ymm1
    2b93:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    2b97:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2b9c:	c5 cd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm6
    2ba1:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2ba6:	c4 62 6d 90 34 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm14
    2bac:	c5 ed 72 d4 10       	vpsrld $0x10,%ymm4,%ymm2
    2bb1:	c5 dd db 25 c0 00 00 	vpand  0xc0(%rip),%ymm4,%ymm4        # 2c79 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2999>
    2bb8:	00 
    2bb9:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    2bc0:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
    2bc6:	c5 d5 db 2d c0 00 00 	vpand  0xc0(%rip),%ymm5,%ymm5        # 2c8e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x29ae>
    2bcd:	00 
    2bce:	c5 0d db 35 c0 00 00 	vpand  0xc0(%rip),%ymm14,%ymm14        # 2c96 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x29b6>
    2bd5:	00 
    2bd6:	c5 5d fa c9          	vpsubd %ymm1,%ymm4,%ymm9
    2bda:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    2bde:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2be2:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    2be6:	c4 c1 7d 76 c3       	vpcmpeqd %ymm11,%ymm0,%ymm0
    2beb:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2bf0:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    2bf4:	c5 f5 fe ea          	vpaddd %ymm2,%ymm1,%ymm5
    2bf8:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    2bfc:	c4 e2 1d 90 3c 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm7
    2c02:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    2c08:	c5 7d 6f e4          	vmovdqa %ymm4,%ymm12
    2c0c:	c4 41 65 fe c1       	vpaddd %ymm9,%ymm3,%ymm8
    2c11:	c5 0d fa f0          	vpsubd %ymm0,%ymm14,%ymm14
    2c15:	c5 35 66 fb          	vpcmpgtd %ymm3,%ymm9,%ymm15
    2c19:	c4 e2 5d 90 04 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm0
    2c1f:	c4 c2 65 3d e9       	vpmaxsd %ymm9,%ymm3,%ymm5
    2c24:	c5 8d 66 cd          	vpcmpgtd %ymm5,%ymm14,%ymm1
    2c28:	c4 c2 55 3d ee       	vpmaxsd %ymm14,%ymm5,%ymm5
    2c2d:	c4 43 2d 4c fd f0    	vpblendvb %ymm15,%ymm13,%ymm10,%ymm15
    2c33:	c4 63 05 4c 3d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm15,%ymm15        # 2c3c <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x295c>
    2c3a:	ff ff 10 
    2c3d:	c4 c2 65 39 c9       	vpminsd %ymm9,%ymm3,%ymm1
    2c42:	c4 c2 75 39 f6       	vpminsd %ymm14,%ymm1,%ymm6
    2c47:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
    2c4c:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    2c51:	c5 d5 fe e6          	vpaddd %ymm6,%ymm5,%ymm4
    2c55:	c5 8d fa e4          	vpsubd %ymm4,%ymm14,%ymm4
    2c59:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    2c5e:	c4 62 1d 90 04 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm8
    2c64:	c4 c1 75 66 d6       	vpcmpgtd %ymm14,%ymm1,%ymm2
    2c69:	c4 c1 65 66 c9       	vpcmpgtd %ymm9,%ymm3,%ymm1
    2c6e:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2c74:	c4 41 3d db e3       	vpand  %ymm11,%ymm8,%ymm12
    2c79:	c4 c3 2d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm10,%ymm1
    2c7f:	c4 c1 15 72 d0 08    	vpsrld $0x8,%ymm8,%ymm13
    2c85:	c4 41 45 db d3       	vpand  %ymm11,%ymm7,%ymm10
    2c8a:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm1,%ymm1        # 2c93 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x29b3>
    2c91:	ff ff 20 
    2c94:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
    2c9a:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    2c9f:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    2ca3:	c4 c1 7d db db       	vpand  %ymm11,%ymm0,%ymm3
    2ca8:	c5 35 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm9        # 2cd0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x29f0>
    2caf:	00 
    2cb0:	c4 e2 05 90 14 88    	vpgatherdd %ymm15,(%rax,%ymm1,4),%ymm2
    2cb6:	c4 62 2d 40 d5       	vpmulld %ymm5,%ymm10,%ymm10
    2cbb:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    2cc0:	c4 c1 6d db cb       	vpand  %ymm11,%ymm2,%ymm1
    2cc5:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2ccb:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2ccf:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    2cd4:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    2cd9:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    2cde:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    2ce3:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    2ce8:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2ced:	c4 c1 45 db fb       	vpand  %ymm11,%ymm7,%ymm7
    2cf2:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    2cf7:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    2cfc:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    2d01:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    2d05:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    2d0a:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2d0f:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    2d15:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    2d1a:	c4 41 15 fa e4       	vpsubd %ymm12,%ymm13,%ymm12
    2d1f:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
    2d23:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    2d28:	c4 62 1d 40 e5       	vpmulld %ymm5,%ymm12,%ymm12
    2d2d:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    2d32:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    2d37:	c5 2d fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm10,%ymm10        # 2d5f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2a7f>
    2d3e:	00 
    2d3f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2d44:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2d49:	c4 c1 6d db d3       	vpand  %ymm11,%ymm2,%ymm2
    2d4e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2d53:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    2d58:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    2d5c:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    2d61:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    2d66:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2d6b:	c5 b5 fe c9          	vpaddd %ymm1,%ymm9,%ymm1
    2d6f:	c4 41 3d db cb       	vpand  %ymm11,%ymm8,%ymm9
    2d74:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    2d79:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    2d7e:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    2d82:	c4 e2 45 40 ed       	vpmulld %ymm5,%ymm7,%ymm5
    2d87:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    2d8c:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 2db4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ad4>
    2d93:	00 
    2d94:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2d99:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    2d9e:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2da3:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2da7:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2dab:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2db0:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    2db5:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    2db9:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    2dbd:	c4 e2 7d 00 84 24 60 	vpshufb 0x260(%rsp),%ymm0,%ymm0
    2dc4:	02 00 00 
    2dc7:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2dcb:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2dd1:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2dd6:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2ddb:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2ddf:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
    2de4:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
    2de9:	49 39 cb             	cmp    %rcx,%r11
    2dec:	0f 85 e1 f3 ff ff    	jne    21d3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ef3>
    2df2:	e9 a8 dd ff ff       	jmp    b9f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8bf>
    2df7:	4d 85 c9             	test   %r9,%r9
    2dfa:	0f 84 a2 dd ff ff    	je     ba2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c2>
    2e00:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 2e88 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ba8>
    2e07:	00 
    2e08:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    2e0c:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    2e10:	48 89 de             	mov    %rbx,%rsi
    2e13:	48 c1 e8 03          	shr    $0x3,%rax
    2e17:	45 31 c9             	xor    %r9d,%r9d
    2e1a:	48 89 cb             	mov    %rcx,%rbx
    2e1d:	4d 89 c3             	mov    %r8,%r11
    2e20:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
    2e27:	00 00 
    2e29:	c5 fd 6f 25 a0 00 00 	vmovdqa 0xa0(%rip),%ymm4        # 2ed1 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2bf1>
    2e30:	00 
    2e31:	48 8d 78 01          	lea    0x1(%rax),%rdi
    2e35:	c5 9d 72 d6 18       	vpsrld $0x18,%ymm6,%ymm12
    2e3a:	c5 fe 7f a4 24 60 02 	vmovdqu %ymm4,0x260(%rsp)
    2e41:	00 00 
    2e43:	c5 fa 6f 03          	vmovdqu (%rbx),%xmm0
    2e47:	c5 fa 7e 4b 10       	vmovq  0x10(%rbx),%xmm1
    2e4c:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
    2e53:	00 
    2e54:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    2e58:	49 8b 02             	mov    (%r10),%rax
    2e5b:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    2e5f:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    2e63:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    2e67:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2e6d:	41 8b 52 50          	mov    0x50(%r10),%edx
    2e71:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2e77:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    2e7b:	c4 e2 7d 00 84 24 40 	vpshufb 0x240(%rsp),%ymm0,%ymm0
    2e82:	02 00 00 
    2e85:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    2e8a:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2e8f:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    2e94:	c4 41 7d db ec       	vpand  %ymm12,%ymm0,%ymm13
    2e99:	c5 7e 7f 6c 24 20    	vmovdqu %ymm13,0x20(%rsp)
    2e9f:	c4 a2 65 90 14 a8    	vpgatherdd %ymm3,(%rax,%ymm13,4),%ymm2
    2ea5:	c4 c1 75 db dc       	vpand  %ymm12,%ymm1,%ymm3
    2eaa:	49 8b 42 08          	mov    0x8(%r10),%rax
    2eae:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2eb2:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    2eb8:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2ebd:	c5 fd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm0
    2ec2:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2ec6:	c4 62 45 90 0c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm9
    2ecc:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    2ed1:	49 8b 42 10          	mov    0x10(%r10),%rax
    2ed5:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
    2edc:	00 00 
    2ede:	c4 c1 65 72 d1 11    	vpsrld $0x11,%ymm9,%ymm3
    2ee4:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    2ee8:	48 89 f1             	mov    %rsi,%rcx
    2eeb:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2ef0:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    2ef6:	49 8b 42 48          	mov    0x48(%r10),%rax
    2efa:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    2efe:	c5 dd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm4
    2f03:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    2f07:	c5 fd 72 d6 0f       	vpsrld $0xf,%ymm6,%ymm0
    2f0c:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    2f10:	c5 35 db c8          	vpand  %ymm0,%ymm9,%ymm9
    2f14:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    2f18:	c4 62 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm14
    2f1e:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    2f22:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    2f26:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2f2b:	c5 35 66 c2          	vpcmpgtd %ymm2,%ymm9,%ymm8
    2f2f:	c5 c5 fe fb          	vpaddd %ymm3,%ymm7,%ymm7
    2f33:	c4 62 05 90 1c b8    	vpgatherdd %ymm15,(%rax,%ymm7,4),%ymm11
    2f39:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
    2f40:	00 00 
    2f42:	c4 42 6d 3d d9       	vpmaxsd %ymm9,%ymm2,%ymm11
    2f47:	c4 43 75 4c c2 80    	vpblendvb %ymm8,%ymm10,%ymm1,%ymm8
    2f4d:	c4 41 55 66 eb       	vpcmpgtd %ymm11,%ymm5,%ymm13
    2f52:	c4 62 25 3d fd       	vpmaxsd %ymm5,%ymm11,%ymm15
    2f57:	c4 42 6d 39 d9       	vpminsd %ymm9,%ymm2,%ymm11
    2f5c:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
    2f63:	00 00 
    2f65:	c4 e2 25 39 e5       	vpminsd %ymm5,%ymm11,%ymm4
    2f6a:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    2f6e:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm8,%ymm8        # 2f77 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2c97>
    2f75:	ff ff d0 
    2f78:	c5 7d 6f ee          	vmovdqa %ymm6,%ymm13
    2f7c:	c4 41 65 fe c0       	vpaddd %ymm8,%ymm3,%ymm8
    2f81:	c4 22 15 90 3c 80    	vpgatherdd %ymm13,(%rax,%ymm8,4),%ymm15
    2f87:	c4 41 6d 66 c1       	vpcmpgtd %ymm9,%ymm2,%ymm8
    2f8c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    2f91:	c4 43 75 4c c2 80    	vpblendvb %ymm8,%ymm10,%ymm1,%ymm8
    2f97:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm8,%ymm8        # 2fa0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2cc0>
    2f9e:	ff ff b0 
    2fa1:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    2fa5:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    2faa:	c4 22 25 90 2c 80    	vpgatherdd %ymm11,(%rax,%ymm8,4),%ymm13
    2fb0:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
    2fb6:	c4 41 05 db c4       	vpand  %ymm12,%ymm15,%ymm8
    2fbb:	c5 1d db 74 24 60    	vpand  0x60(%rsp),%ymm12,%ymm14
    2fc1:	c5 5d fe bc 24 c0 00 	vpaddd 0xc0(%rsp),%ymm4,%ymm15
    2fc8:	00 00 
    2fca:	c4 41 15 db ec       	vpand  %ymm12,%ymm13,%ymm13
    2fcf:	49 8b 52 28          	mov    0x28(%r10),%rdx
    2fd3:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    2fd8:	c4 c1 25 72 f6 10    	vpslld $0x10,%ymm14,%ymm11
    2fde:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    2fe2:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    2fe6:	c4 c1 15 fa e8       	vpsubd %ymm8,%ymm13,%ymm5
    2feb:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    2ff0:	c5 a5 fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm11,%ymm2        # 3018 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d38>
    2ff7:	00 
    2ff8:	c4 41 3d fa c6       	vpsubd %ymm14,%ymm8,%ymm8
    2ffd:	c4 62 3d 40 84 24 c0 	vpmulld 0xc0(%rsp),%ymm8,%ymm8
    3004:	00 00 00 
    3007:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    300b:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    300f:	c5 9d db ac 24 80 00 	vpand  0x80(%rsp),%ymm12,%ymm5
    3016:	00 00 
    3018:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    301d:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    3023:	c4 e2 55 40 ec       	vpmulld %ymm4,%ymm5,%ymm5
    3028:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    302d:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3031:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    3038:	00 00 
    303a:	c5 b5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm9
    303f:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    3045:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    304c:	00 00 
    304e:	c4 62 25 90 04 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm8
    3054:	49 8b 52 20          	mov    0x20(%r10),%rdx
    3058:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    305c:	c4 62 05 90 1c 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm11
    3062:	49 8b 52 18          	mov    0x18(%r10),%rdx
    3066:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    306a:	c5 25 db d8          	vpand  %ymm0,%ymm11,%ymm11
    306e:	c4 a2 05 90 14 aa    	vpgatherdd %ymm15,(%rdx,%ymm13,4),%ymm2
    3074:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    3078:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    307c:	c4 42 6d 3d cb       	vpmaxsd %ymm11,%ymm2,%ymm9
    3081:	c5 a5 66 ea          	vpcmpgtd %ymm2,%ymm11,%ymm5
    3085:	c4 41 3d 66 e9       	vpcmpgtd %ymm9,%ymm8,%ymm13
    308a:	c4 c2 35 3d e0       	vpmaxsd %ymm8,%ymm9,%ymm4
    308f:	c4 42 6d 39 cb       	vpminsd %ymm11,%ymm2,%ymm9
    3094:	c4 42 35 39 f0       	vpminsd %ymm8,%ymm9,%ymm14
    3099:	c4 41 35 66 c8       	vpcmpgtd %ymm8,%ymm9,%ymm9
    309e:	c4 c3 75 4c ea 50    	vpblendvb %ymm5,%ymm10,%ymm1,%ymm5
    30a4:	c5 7e 7f b4 24 c0 00 	vmovdqu %ymm14,0xc0(%rsp)
    30ab:	00 00 
    30ad:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm5,%ymm5        # 30b6 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2dd6>
    30b4:	ff ff d0 
    30b7:	c5 e5 fe ed          	vpaddd %ymm5,%ymm3,%ymm5
    30bb:	c4 62 05 90 34 a8    	vpgatherdd %ymm15,(%rax,%ymm5,4),%ymm14
    30c1:	c4 c1 6d 66 eb       	vpcmpgtd %ymm11,%ymm2,%ymm5
    30c6:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    30ca:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    30cf:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    30d3:	c4 c3 75 4c ea 50    	vpblendvb %ymm5,%ymm10,%ymm1,%ymm5
    30d9:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm5,%ymm5        # 30e2 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2e02>
    30e0:	ff ff 90 
    30e3:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    30e7:	c4 62 05 90 0c a8    	vpgatherdd %ymm15,(%rax,%ymm5,4),%ymm9
    30ed:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
    30f3:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    30f9:	c4 c1 55 72 d7 08    	vpsrld $0x8,%ymm15,%ymm5
    30ff:	c4 41 55 db fc       	vpand  %ymm12,%ymm5,%ymm15
    3104:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
    310a:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    3111:	00 00 
    3113:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    3118:	c4 c1 15 72 d6 08    	vpsrld $0x8,%ymm14,%ymm13
    311e:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    3125:	00 00 
    3127:	c5 7e 7f ac 24 00 01 	vmovdqu %ymm13,0x100(%rsp)
    312e:	00 00 
    3130:	c4 41 35 db ec       	vpand  %ymm12,%ymm9,%ymm13
    3135:	c4 c1 35 72 f7 10    	vpslld $0x10,%ymm15,%ymm9
    313b:	c5 0d fe f4          	vpaddd %ymm4,%ymm14,%ymm14
    313f:	c4 41 3d fa c6       	vpsubd %ymm14,%ymm8,%ymm8
    3144:	c5 bd fe d2          	vpaddd %ymm2,%ymm8,%ymm2
    3148:	c5 15 fa c5          	vpsubd %ymm5,%ymm13,%ymm8
    314c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3151:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    3156:	c5 35 fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm8        # 317e <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2e9e>
    315d:	00 
    315e:	c4 e2 55 40 ec       	vpmulld %ymm4,%ymm5,%ymm5
    3163:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3167:	c4 41 6d fe c0       	vpaddd %ymm8,%ymm2,%ymm8
    316c:	c5 9d db 94 24 00 01 	vpand  0x100(%rsp),%ymm12,%ymm2
    3173:	00 00 
    3175:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    317a:	c4 e2 6d 40 94 24 c0 	vpmulld 0xc0(%rsp),%ymm2,%ymm2
    3181:	00 00 00 
    3184:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3188:	c5 3d fe c2          	vpaddd %ymm2,%ymm8,%ymm8
    318c:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    3192:	c5 7e 7f 84 24 c0 00 	vmovdqu %ymm8,0xc0(%rsp)
    3199:	00 00 
    319b:	49 8b 52 40          	mov    0x40(%r10),%rdx
    319f:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    31a6:	00 00 
    31a8:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    31ae:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    31b4:	c4 62 25 90 04 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm8
    31ba:	49 8b 52 38          	mov    0x38(%r10),%rdx
    31be:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    31c2:	c4 e2 5d 90 2c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm5
    31c8:	49 8b 52 30          	mov    0x30(%r10),%rdx
    31cc:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    31d0:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    31d4:	c4 a2 5d 90 14 aa    	vpgatherdd %ymm4,(%rdx,%ymm13,4),%ymm2
    31da:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    31de:	4c 89 da             	mov    %r11,%rdx
    31e1:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    31e5:	c4 62 6d 3d cd       	vpmaxsd %ymm5,%ymm2,%ymm9
    31ea:	c5 55 66 ea          	vpcmpgtd %ymm2,%ymm5,%ymm13
    31ee:	c4 41 3d 66 d9       	vpcmpgtd %ymm9,%ymm8,%ymm11
    31f3:	c4 42 35 3d f0       	vpmaxsd %ymm8,%ymm9,%ymm14
    31f8:	c4 62 6d 39 cd       	vpminsd %ymm5,%ymm2,%ymm9
    31fd:	c4 43 75 4c ea d0    	vpblendvb %ymm13,%ymm10,%ymm1,%ymm13
    3203:	c4 63 15 4c 2d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm13,%ymm13        # 320c <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f2c>
    320a:	ff ff b0 
    320d:	c4 42 35 39 d8       	vpminsd %ymm8,%ymm9,%ymm11
    3212:	c4 c1 65 fe dd       	vpaddd %ymm13,%ymm3,%ymm3
    3217:	c4 41 35 66 c8       	vpcmpgtd %ymm8,%ymm9,%ymm9
    321c:	c4 62 5d 90 3c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm15
    3222:	c5 ed 66 dd          	vpcmpgtd %ymm5,%ymm2,%ymm3
    3226:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    322a:	c4 c1 05 72 d7 10    	vpsrld $0x10,%ymm15,%ymm15
    3230:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3234:	c4 c3 75 4c ca 30    	vpblendvb %ymm3,%ymm10,%ymm1,%ymm1
    323a:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 3243 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f63>
    3241:	ff ff 90 
    3244:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    3248:	c4 e2 5d 90 1c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm3
    324e:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    3254:	c4 c1 0d fe cb       	vpaddd %ymm11,%ymm14,%ymm1
    3259:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    325e:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    3262:	c5 7e 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm8
    3269:	00 00 
    326b:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    3270:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    3277:	00 00 
    3279:	c4 41 65 db cc       	vpand  %ymm12,%ymm3,%ymm9
    327e:	c4 c1 05 db dc       	vpand  %ymm12,%ymm15,%ymm3
    3283:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3287:	c5 b5 fa d3          	vpsubd %ymm3,%ymm9,%ymm2
    328b:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
    3290:	c4 41 7d 7f 43 20    	vmovdqa %ymm8,0x20(%r11)
    3296:	c5 95 72 d4 10       	vpsrld $0x10,%ymm4,%ymm13
    329b:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    32a0:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    32a4:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    32a9:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
    32ae:	c4 c1 15 db d4       	vpand  %ymm12,%ymm13,%ymm2
    32b3:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    32b8:	c5 2d fe 15 20 00 00 	vpaddd 0x20(%rip),%ymm10,%ymm10        # 32e0 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3000>
    32bf:	00 
    32c0:	c5 7e 6f 8c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm9
    32c7:	00 00 
    32c9:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    32ce:	c4 41 7d 7f 0b       	vmovdqa %ymm9,(%r11)
    32d3:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    32d8:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    32dc:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    32e0:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    32e5:	c4 c1 7d 7f 4b 40    	vmovdqa %ymm1,0x40(%r11)
    32eb:	c5 f8 77             	vzeroupper
    32ee:	e8 0d cd ff ff       	call   0 <void jshc_axis_preweight::(anonymous namespace)::transform<true, false, false>(jshc_axis_preweight::View const&, jshc_axis_preweight::(anonymous namespace)::Rgb&)>
    32f3:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    32f7:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    32fe:	c4 c1 7d 6f 0b       	vmovdqa (%r11),%ymm1
    3303:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3307:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    330e:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    3312:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    3319:	c5 fd 6f 05 40 00 00 	vmovdqa 0x40(%rip),%ymm0        # 3361 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3081>
    3320:	00 
    3321:	48 83 c3 18          	add    $0x18,%rbx
    3325:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
    332b:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    3332:	c4 c1 7d 6f 4b 20    	vmovdqa 0x20(%r11),%ymm1
    3338:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    333c:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3340:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
    3345:	c5 79 6e c2          	vmovd  %edx,%xmm8
    3349:	c4 e2 5d 90 1c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm3
    334f:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    3356:	c4 c1 7d 6f 4b 40    	vmovdqa 0x40(%r11),%ymm1
    335c:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3360:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3365:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    336a:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    336e:	c4 e2 5d 90 2c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm5
    3374:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    3379:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    3380:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3384:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
    3389:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    338e:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3392:	c5 b5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm9
    3397:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    339b:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    339f:	c5 6d fe fb          	vpaddd %ymm3,%ymm2,%ymm15
    33a3:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    33a7:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    33ab:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    33b0:	c5 65 66 ca          	vpcmpgtd %ymm2,%ymm3,%ymm9
    33b4:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    33b9:	c4 62 5d 90 24 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm12
    33bf:	c5 c5 fe e1          	vpaddd %ymm1,%ymm7,%ymm4
    33c3:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    33c9:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
    33cd:	c4 e2 25 90 24 b8    	vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm4
    33d3:	c4 e2 6d 3d fb       	vpmaxsd %ymm3,%ymm2,%ymm7
    33d8:	c4 62 6d 39 db       	vpminsd %ymm3,%ymm2,%ymm11
    33dd:	c5 55 66 d7          	vpcmpgtd %ymm7,%ymm5,%ymm10
    33e1:	c4 43 3d 4c cd 90    	vpblendvb %ymm9,%ymm13,%ymm8,%ymm9
    33e7:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    33ec:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    33f2:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    33f6:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    33fc:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    3400:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm9,%ymm9        # 3409 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3129>
    3407:	ff ff a0 
    340a:	c4 62 25 39 d5       	vpminsd %ymm5,%ymm11,%ymm10
    340f:	c4 41 45 fe f2       	vpaddd %ymm10,%ymm7,%ymm14
    3414:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    3418:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    341d:	c4 41 55 fa f6       	vpsubd %ymm14,%ymm5,%ymm14
    3422:	c4 41 0d fe ff       	vpaddd %ymm15,%ymm14,%ymm15
    3427:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    342b:	c4 62 0d 90 0c 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm9
    3431:	c4 c3 3d 4c cd 20    	vpblendvb %ymm2,%ymm13,%ymm8,%ymm1
    3437:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    343c:	c5 7d 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm12        # 34a4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31c4>
    3443:	00 
    3444:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm1,%ymm1        # 344d <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x316d>
    344b:	ff ff b0 
    344e:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    3452:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    3458:	c4 41 35 db dc       	vpand  %ymm12,%ymm9,%ymm11
    345d:	c4 41 1d db c6       	vpand  %ymm14,%ymm12,%ymm8
    3462:	c4 e2 65 90 14 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm2
    3468:	c4 c1 55 72 f0 10    	vpslld $0x10,%ymm8,%ymm5
    346e:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    3473:	c4 c1 6d db dc       	vpand  %ymm12,%ymm2,%ymm3
    3478:	c5 9d db cc          	vpand  %ymm4,%ymm12,%ymm1
    347c:	c5 d5 fe 2d 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm5        # 34a4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31c4>
    3483:	00 
    3484:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    3488:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    348d:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    3492:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3497:	c4 c2 65 40 df       	vpmulld %ymm15,%ymm3,%ymm3
    349c:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    34a1:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    34a5:	c4 c1 3d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm8
    34ab:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    34af:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
    34b4:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
    34b9:	c5 95 72 d1 10       	vpsrld $0x10,%ymm1,%ymm13
    34be:	c5 e5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm3
    34c3:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    34c8:	c4 c1 75 72 d6 08    	vpsrld $0x8,%ymm14,%ymm1
    34ce:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    34d3:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    34d8:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    34dd:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    34e1:	c4 c1 65 fa d8       	vpsubd %ymm8,%ymm3,%ymm3
    34e6:	c5 a5 72 f1 10       	vpslld $0x10,%ymm1,%ymm11
    34eb:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    34ef:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    34f4:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    34f9:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    34fe:	c5 25 fe 1d 20 00 00 	vpaddd 0x20(%rip),%ymm11,%ymm11        # 3526 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3246>
    3505:	00 
    3506:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    350d:	c4 c2 65 40 df       	vpmulld %ymm15,%ymm3,%ymm3
    3512:	c4 c1 3d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm8
    3518:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    351f:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    3526:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
    352b:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    352f:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
    3534:	c5 79 6e d9          	vmovd  %ecx,%xmm11
    3538:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    353c:	c4 c1 65 72 d6 10    	vpsrld $0x10,%ymm14,%ymm3
    3542:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    3547:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
    354c:	c5 f5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm1
    3551:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    3556:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    355b:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
    3560:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
    3564:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    3568:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    356d:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    3572:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3577:	c4 c2 6d 40 d7       	vpmulld %ymm15,%ymm2,%ymm2
    357c:	c5 35 fe 0d 20 00 00 	vpaddd 0x20(%rip),%ymm9,%ymm9        # 35a4 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x32c4>
    3583:	00 
    3584:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3588:	c5 79 6e c2          	vmovd  %edx,%xmm8
    358c:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3590:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    3595:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    359a:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    359e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    35a2:	c4 a2 5d 90 14 a8    	vpgatherdd %ymm4,(%rax,%ymm13,4),%ymm2
    35a8:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    35af:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    35b3:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    35b8:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
    35bd:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    35c1:	c4 e2 5d 90 1c a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm3
    35c7:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    35ce:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
    35d3:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    35d7:	c4 e2 5d 90 2c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm5
    35dd:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    35e2:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    35e9:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    35ed:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    35f2:	c5 b5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm9
    35f7:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    35fb:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    35ff:	c5 6d fe fb          	vpaddd %ymm3,%ymm2,%ymm15
    3603:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    3607:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    360b:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    3610:	c5 65 66 ca          	vpcmpgtd %ymm2,%ymm3,%ymm9
    3614:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    3619:	c4 e2 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm0
    361f:	c5 c5 fe e1          	vpaddd %ymm1,%ymm7,%ymm4
    3623:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    3627:	c4 62 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm13
    362d:	c4 e2 6d 3d fb       	vpmaxsd %ymm3,%ymm2,%ymm7
    3632:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    3638:	c4 62 6d 39 db       	vpminsd %ymm3,%ymm2,%ymm11
    363d:	c5 55 66 d7          	vpcmpgtd %ymm7,%ymm5,%ymm10
    3641:	c4 63 3d 4c 4c 24 20 	vpblendvb %ymm9,0x20(%rsp),%ymm8,%ymm9
    3648:	90 
    3649:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    364e:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    3652:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm9,%ymm9        # 365b <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x337b>
    3659:	ff ff a0 
    365c:	c4 62 25 39 d5       	vpminsd %ymm5,%ymm11,%ymm10
    3661:	c4 41 45 fe f2       	vpaddd %ymm10,%ymm7,%ymm14
    3666:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    366a:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    366f:	c4 41 55 fa f6       	vpsubd %ymm14,%ymm5,%ymm14
    3674:	c4 41 0d fe ff       	vpaddd %ymm15,%ymm14,%ymm15
    3679:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    367d:	c4 62 0d 90 0c 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm9
    3683:	c4 e3 3d 4c 4c 24 20 	vpblendvb %ymm2,0x20(%rsp),%ymm8,%ymm1
    368a:	20 
    368b:	c4 c1 7d db d4       	vpand  %ymm12,%ymm0,%ymm2
    3690:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm1,%ymm1        # 3699 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x33b9>
    3697:	ff ff b0 
    369a:	c5 d5 72 f2 10       	vpslld $0x10,%ymm2,%ymm5
    369f:	c4 41 35 db c4       	vpand  %ymm12,%ymm9,%ymm8
    36a4:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    36a8:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    36ac:	c5 bd fa d2          	vpsubd %ymm2,%ymm8,%ymm2
    36b0:	c4 e2 5d 90 1c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm3
    36b6:	c4 c1 15 db e4       	vpand  %ymm12,%ymm13,%ymm4
    36bb:	c5 d5 fe 2d 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm5        # 36e3 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3403>
    36c2:	00 
    36c3:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    36c8:	c4 c1 25 72 d1 08    	vpsrld $0x8,%ymm9,%ymm11
    36ce:	c4 c1 65 db cc       	vpand  %ymm12,%ymm3,%ymm1
    36d3:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    36d7:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    36dc:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    36e1:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    36e6:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
    36eb:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    36ef:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    36f3:	c5 dd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm4
    36f8:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    36fc:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    3701:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    3706:	c4 c1 75 72 d5 08    	vpsrld $0x8,%ymm13,%ymm1
    370c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3711:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    3716:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    371b:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    3720:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    3724:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    3728:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    372d:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    3732:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3737:	c4 c2 5d 40 e7       	vpmulld %ymm15,%ymm4,%ymm4
    373c:	c5 3d fe 05 20 00 00 	vpaddd 0x20(%rip),%ymm8,%ymm8        # 3764 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3484>
    3743:	00 
    3744:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3749:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    374e:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    3753:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    3758:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    375c:	c4 c1 3d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm8
    3762:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3766:	c4 c1 7d db e4       	vpand  %ymm12,%ymm0,%ymm4
    376b:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
    3770:	c4 c1 7d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm0
    3776:	c5 d5 72 f4 10       	vpslld $0x10,%ymm4,%ymm5
    377b:	c5 bd fa e4          	vpsubd %ymm4,%ymm8,%ymm4
    377f:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    3784:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    3789:	c5 d5 fe 2d 20 00 00 	vpaddd 0x20(%rip),%ymm5,%ymm5        # 37b1 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x34d1>
    3790:	00 
    3791:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    3795:	c4 c1 65 fa d8       	vpsubd %ymm8,%ymm3,%ymm3
    379a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    379f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    37a4:	c4 c2 65 40 df       	vpmulld %ymm15,%ymm3,%ymm3
    37a9:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    37ae:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    37b2:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    37b6:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    37ba:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    37bf:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    37c4:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    37c8:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    37cc:	c4 e2 7d 00 84 24 60 	vpshufb 0x260(%rsp),%ymm0,%ymm0
    37d3:	02 00 00 
    37d6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    37da:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    37e0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    37e5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    37ea:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    37ee:	c5 fa 7f 4b e8       	vmovdqu %xmm1,-0x18(%rbx)
    37f3:	c5 f9 d6 43 f8       	vmovq  %xmm0,-0x8(%rbx)
    37f8:	4c 8b 8c 24 20 01 00 	mov    0x120(%rsp),%r9
    37ff:	00 
    3800:	49 ff c1             	inc    %r9
    3803:	4c 39 cf             	cmp    %r9,%rdi
    3806:	0f 85 37 f6 ff ff    	jne    2e43 <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2b63>
    380c:	e9 8e d3 ff ff       	jmp    b9f <jshc_axis_preweight::avx2_chain(jshc_axis_preweight::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8bf>
    3811:	90                   	nop
    3812:	90                   	nop
    3813:	90                   	nop
    3814:	90                   	nop
    3815:	90                   	nop
    3816:	90                   	nop
    3817:	90                   	nop
    3818:	90                   	nop
    3819:	90                   	nop
    381a:	90                   	nop
    381b:	90                   	nop
    381c:	90                   	nop
    381d:	90                   	nop
    381e:	90                   	nop
    381f:	90                   	nop
