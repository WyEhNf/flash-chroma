# Empty dependencies file for jshc_skylake_pair48.
# This may be replaced when dependencies are built.
