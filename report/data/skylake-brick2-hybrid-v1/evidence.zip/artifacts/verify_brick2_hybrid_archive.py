"""独立核对84归档原字节、原始计时数组、A/A与三倍判定；不加载原生库。"""
from pathlib import Path
import hashlib
import json
import math
import statistics as st
import zipfile
ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/'report/data/skylake-brick2-hybrid-v1'
def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def near(a,b):assert math.isclose(a,b,rel_tol=1e-13,abs_tol=1e-15),(a,b)
m=read(HERE/'manifest.json')
for x in m['files']:
    raw=(HERE/x['path']).read_bytes();assert len(raw)==x['bytes'] and digest(raw)==x['sha256']
assert digest((HERE/'evidence.zip').read_bytes())==m['evidence_sha256']
with zipfile.ZipFile(HERE/'evidence.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist())=={x['path'] for x in m['entries']}
    for x in m['entries']:
        raw=z.read(x['path']);assert len(raw)==x['bytes'] and digest(raw)==x['sha256'],x['path']
    def get(p):return json.loads(z.read(p))
    prefix='artifacts/skylake-brick2-hybrid-long-perf-v1/'
    result=get(prefix+'results.json')
    policy=get('experiments/skylake-brick2-hybrid-long-perf-v1.json')
    full=get('artifacts/skylake-brick2-hybrid-linux-full-v1/results.json')
    assert full['pass'] and full['byte_mismatches']==0 and full['sentinel_mismatches']==0
    assert full['hybrid_validation']['independently_checked_blocks']==2**21
    assert full['hybrid_validation']['negative_checks']==9
    workers=[get(prefix+f'worker{i}.json') for i in range(4)]
    expected='f3c0d9078bbcf069f33060a45021a28985b70c9616493ba9bea1ac2027858528'
    sample_count=inner_control=inner_compare=0
    for i,w in enumerate(workers):
        assert w['measurement_completed'] and w['worker_index']==i
        assert digest(z.read(prefix+f'worker{i}.json'))==result['worker_sha256'][i]
        assert w['order']==policy['orders'][i] and w['thread_order']==policy['thread_orders'][i]
        assert w['control_order']==policy['control_orders'][i]
        assert len(w['batches'])==12
        for b in w['batches']:
            raw=z.read(prefix+b['path']);assert digest(raw)==b['sha256']
            v=json.loads(raw);sample_count+=1
            assert v['native_return_code']==0 and v['source_unchanged'] and v['sentinels_unchanged']
            assert v['batch_final_output_sha256']==v['warmup_output_sha256']==expected
            n=policy['inner_repeats'][str(v['requested_threads'])]
            if v['purpose']=='control':inner_control+=n
            else:inner_compare+=n
            for key in ('apply_seconds','legacy_copy_apply_seconds','outplace_seconds'):
                a=v[key]
                if a:
                    assert len(a)==n and all(math.isfinite(t) and t>0 for t in a)
                    near(st.mean(a),v['mean_'+key])
        for phase in ('before','after'):
            s=w['handles']['candidate'][phase]
            assert s['brick2_hybrid_enabled']==1 and s['hybrid_info']['format']==22
            for key in ('paged_info','hybrid_paged_info'):
                pg=s[key]
                assert pg['bytes']==pg['smaps']['mapping_bytes']==2**24
                assert pg['aligned_2m'] and pg['fully_huge']
    assert (sample_count,inner_control,inner_compare)==(48,640,1280)
    paired=[];control_valid=True;gate_valid=True
    for t in (1,4):
        calculated=dict(apply=[],legacy=[],outplace=[],prepare=[]);controls=[]
        for w in workers:
            records={v['variant']:v for v in w['records'] if v['requested_threads']==t}
            c,r=records['candidate'],records['reference']
            for key,dest in (('apply_seconds','apply'),('legacy_copy_apply_seconds','legacy'),('outplace_seconds','outplace')):
                for v in (c,r):near(st.mean(v[key]),v['mean_'+key])
                calculated[dest].append(st.mean(c[key])/st.mean(r[key]))
            for v in (c,r):near(v['prepare_wall_seconds']+v['outplace_seconds'][0],v['prepare_plus_first_100_outplace_seconds'])
            calculated['prepare'].append((c['prepare_wall_seconds']+c['outplace_seconds'][0])/(r['prepare_wall_seconds']+r['outplace_seconds'][0]))
            ab={v['label']:v for v in w['control_records'] if v['requested_threads']==t}
            assert ab['A']['library_sha256']==ab['B']['library_sha256']==m['candidate_sha256']
            assert ab['A']['handle_address']==ab['B']['handle_address']==c['handle_address']
            controls.append(st.mean(ab['B']['apply_seconds'])/st.mean(ab['A']['apply_seconds']))
        published=next(v for v in result['paired'] if v['requested_threads']==t)
        for key,field in (('apply','process_apply_ratios'),('legacy','process_legacy_copy_apply_ratios'),('outplace','process_outplace_ratios'),('prepare','process_prepare_plus_100_outplace_ratios')):
            for a,b in zip(calculated[key],published[field]):near(a,b)
        near(st.median(calculated['apply']),published['median_apply_ratio'])
        near(st.median(calculated['outplace']),published['median_outplace_ratio'])
        near(st.median(calculated['prepare']),published['median_prepare_plus_100_outplace_ratio'])
        cr=next(v for v in result['controls'] if v['requested_threads']==t)
        for a,b in zip(controls,cr['process_mean_apply_ratios_B_over_A']):near(a,b)
        valid=1/1.1<=st.median(controls)<=1.1 and all(.8<=x<=1.25 for x in controls)
        assert cr['control_valid']==valid
        control_valid=control_valid and valid
        passed=st.median(calculated['apply'])<=1/3 and st.median(calculated['outplace'])<=1/3 and st.median(calculated['prepare'])<=1 and all(x<=.9 for x in calculated['apply'])
        gate_valid=gate_valid and passed
        paired.append(dict(threads=t,apply_speedup=1/st.median(calculated['apply']),
            outplace_speedup=1/st.median(calculated['outplace']),prepare_ratio=st.median(calculated['prepare']),control_valid=valid))
    assert result['measurement_control_valid']==control_valid
    assert result['accepted_on_this_host']==(control_valid and gate_valid)
answer=dict(passed=True,purpose=__doc__,environment='Python标准库静态归档验证；实际宿主见执行日志',
    evidence_sha256=m['evidence_sha256'],entries=len(m['entries']),sample_count=sample_count,
    control_inner_rounds=inner_control,comparison_inner_rounds=inner_compare,paired=paired,
    accepted_on_this_host=result['accepted_on_this_host'],native_calls=0,performance_calls=0)
with (HERE/'archive-audit.json').open('x',encoding='utf-8') as f:json.dump(answer,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(answer,ensure_ascii=False))
