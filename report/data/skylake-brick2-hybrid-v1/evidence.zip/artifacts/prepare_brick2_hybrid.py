"""冻结84独立混合候选与完整验证胶水；不执行编译、像素或性能。"""
from pathlib import Path
import hashlib
import json
ROOT=Path(__file__).resolve().parents[1]

def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def put(p,s):
    with (ROOT/p).open('x',encoding='utf-8',newline='') as f:f.write(s)
def save(p,v):put(p,json.dumps(v,ensure_ascii=False,indent=2)+'\n')

old=read('experiments/skylake-input256-ordered-v1.json')
plan={k:old[k] for k in ('schema','fixed_inputs','suffix_models','contract','screen','hardware','acceptance_invariants')}
plan.update(purpose='修订84独立混合候选：2³正常块15bit基值与6bit残差恢复RGB，异常八像素包回退既有精确ID调色板',
    base_commit='2de21f8bce4a7e4b5ed3ec4aaa1750698f076769',
    candidate='仅有效多workers原地使用新AVX2 TU；单workers和true outplace保持79 pair48/linear',
    cmake_project='experiments/skylake-brick2-hybrid-runtime',
    cmake_targets=['jshc_skylake_reference','jshc_skylake_brick2_hybrid'],
    revisions={'reference':23,'candidate':84})
plan['required_static_checks']=[
    '首次编译前冻结全部源；只有一次构建和静态筛查，失败停止该修订',
    '原linear及两个pair48对象.text逐字节等79；reference23库SHA保持原身份',
    '新normal循环含控制及共享输出最多128条宏指令，最多18次load（8主表、2输入、最多8常量）；按实际控制流计数，RIP折叠常量允许并单列',
    '新normal热路径无stackspill/load，八次普通u64主表读取，不使用gather/BMI/EVEX/NT；函数序言保存寄存器单列，异常路径与尾部不当normal',
    '新输入load16+load8精确覆盖24B，先得到所有索引/结果后精确store16+store8；所有像素包和尾部不越界',
    '构造只读实际模型direct/palette，不读取照片/gold；无异常池；新增表资源与准备成本计入',
    '静态通过后才进行独立新表解码与24配置完整RGB8、有限/guard/负面/64真实对齐夹具，之后才按原A/A/quiet/ABBA协议性能验收']
plan['static_budget_basis']='128条包括coarse/fine算术、8索引提取与主表load、跨宽度拼接、两次VPSRLVQ、RGB恢复与精确24B输出；18载荷含允许的最多8次RIP常量折叠。是事前工程筛查，不是微操作数或性能预测。'
plan['format']=dict(id=22,main_bytes=2**24,blocks=2**21,block_input_pixels=8,
    header_bits=15,residual_bits=6,exception_tag_bit=63,exception_pool_bytes=0,
    coarse='(R>>1)|((G>>1)<<7)|((B>>1)<<14)',fine='(R&1)|((G&1)<<1)|((B&1)<<2)',
    header='minR|((minDG-globalDGmin)<<8)|((minDB-globalDBmin)<<12)',
    residual='dR|(dDG<<3)|(dDB<<5)',bad_word='1ULL<<63',
    scope='原纯pool格式照片门槛失败保留；本混合格式是独立候选，没有将旧失败改通过')
plan['risks']=['额外16MiB常驻表及准备成本；旧ID表也保留',
    '固定百图14.782206%包回退，最差46.474202%；比例不代表速度',
    '重排端口、寄存器压力、分支、双表缓存及WB写入可能使实际性能失败',
    '本机Zen4/WSL2不能证明Skylake实际性能；通用AVX2，无AVX512']

verify=(ROOT/'scripts/verify_skylake_input256_ordered_linux.py').read_text(encoding='utf-8')
verify=verify.replace('input256_ordered','brick2_hybrid').replace('input256-ordered','brick2-hybrid')
verify=verify.replace('83固定读写顺序的单YMM输入','84正常块RGB解码与异常包精确回退')
verify=verify.replace('进入单YMM输入路径','进入混合解码路径')
verify=verify.replace('from outplace_support import apply_to,reject_to','from outplace_support import apply_to,reject_to\nfrom brick2_hybrid_support import verify_model')
verify=verify.replace('                    del words\n','                    del words\n                    hybrid_validation=verify_model(d,operators[name])\n')
assert verify.count('hybrid_validation=verify_model')==1
# 新增Handle元数据的确定大小由源布局核验；不是用实测差值放宽资源检查。
verify=verify.replace("==24\n","==104\n").replace('==24+2**24','==104+2*2**24')
verify=verify.replace("'model_accounting_bytes': memory,","'model_accounting_bytes': memory,'hybrid_validation':hybrid_validation,")
put('scripts/verify_skylake_brick2_hybrid_linux.py',verify)

sources={k:v for k,v in old['source_sha256'].items() if not k.startswith('experiments/skylake-input256-ordered-runtime/')}
for p in (ROOT/plan['cmake_project']).rglob('*'):
    if p.is_file():sources[p.relative_to(ROOT).as_posix()]=sha(p.relative_to(ROOT))
for p in ('scripts/brick2_hybrid_support.py','scripts/verify_skylake_brick2_hybrid_linux.py'):
    sources[p]=sha(p)
for p in sources:assert sources[p]==sha(p),p
plan['source_sha256']=dict(sorted(sources.items()))
save('experiments/skylake-brick2-hybrid-v1.json',plan)
pre=ROOT/'artifacts/skylake-brick2-hybrid-preflight-v1';pre.mkdir(exist_ok=False)
save('artifacts/skylake-brick2-hybrid-preflight-v1/freeze.json',dict(
    purpose=__doc__,plan_sha256=sha('experiments/skylake-brick2-hybrid-v1.json'),
    sources=len(sources),compiler_calls=0,pixel_calls=0,performance_calls=0,
    static_budget_frozen_before_first_compile=True))
print(json.dumps(dict(plan_sha256=sha('experiments/skylake-brick2-hybrid-v1.json'),sources=len(sources)),ensure_ascii=False))
