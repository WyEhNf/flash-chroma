# Empty dependencies file for jshc_skylake_brick2_hybrid.
# This may be replaced when dependencies are built.
