file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/link.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/andn_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/andn_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/andn_outplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/andn_outplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/hybrid_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/hybrid_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_brick2_hybrid.dir/outplace_bench.cpp.o.d"
  "libjshc_skylake_brick2_hybrid.pdb"
  "libjshc_skylake_brick2_hybrid.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_brick2_hybrid.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
