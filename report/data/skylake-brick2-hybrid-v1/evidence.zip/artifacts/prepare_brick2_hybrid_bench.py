"""生成84长批次入口；保留原计时/门槛，额外核对混合表完整THP。"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'scripts/bench_skylake_andn_normal_long_linux.py').read_text(encoding='utf-8')
new=source.replace('冻结80对23','冻结84对23').replace("'candidate': 80","'candidate': 84").replace('新候选80','新候选84').replace('仅新80对23','仅新84对23')
new=new.replace('andn_normal','brick2_hybrid').replace('andn-normal','brick2-hybrid')
new=new.replace('from paged_table_support import direct_info, paged_info',
    'from paged_table_support import direct_info, paged_info\nfrom brick2_hybrid_support import hybrid_info, hybrid_paged_info')
old="            state['brick2_hybrid_enabled']=int(feature(h))\n"
add="            state['hybrid_info']=hybrid_info(d,h)\n            state['hybrid_paged_info']=hybrid_paged_info(d,h)\n"
assert new.count(old)==1
new=new.replace(old,old+add)
old="            failed = [key for key, passed in checks.items() if not passed]\n"
add="""            hi,hp=state['hybrid_info'],state['hybrid_paged_info']
            checks.update(hybrid_enabled=hi['enabled']==1,hybrid_format=hi['format']==22,
                hybrid_entries=hi['entries']==2**21,hybrid_capacity=hi['table_capacity_bytes']==2**24,
                hybrid_bytes=hp['bytes']==2**24,hybrid_exact_vma=hp['smaps']['mapping_bytes']==2**24,
                hybrid_aligned=hp['aligned_2m'],hybrid_fully_huge=hp['fully_huge'])
"""
assert new.count(old)==1
new=new.replace(old,add+old)
assert "'comparison_inner_rounds': 1280" in new
with (ROOT/'scripts/bench_skylake_brick2_hybrid_long_linux.py').open('x',encoding='utf-8',newline='') as f:f.write(new)
print('84长批次入口已生成，未执行候选。')
