"""按原字节归档84唯一构建、静态、完整域和首次性能，保留所有失败记录。"""
from pathlib import Path
import hashlib
import json
import zipfile
ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/'report/data/skylake-brick2-hybrid-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
plan=ROOT/'experiments/skylake-brick2-hybrid-v1.json'
build=ROOT/'artifacts/skylake-brick2-hybrid-linux-build-v1/build.json'
full=ROOT/'artifacts/skylake-brick2-hybrid-linux-full-v1/results.json'
perf=ROOT/'artifacts/skylake-brick2-hybrid-long-perf-v1/results.json'
assert read(full)['pass'] and read(perf)['measurement_completed']
for p,s in read(plan)['source_sha256'].items():assert sha(ROOT/p)==s,p
assert read(build)['plan_sha256']==sha(plan)
assert read(full)['build_sha256']==read(perf)['build_sha256']==sha(build)
assert read(perf)['full_acceptance_sha256']==sha(full)
paths=[]
for folder in ROOT.glob('artifacts/skylake-brick2-hybrid-*'):
    if folder.is_file():paths.append(folder)
    else:paths.extend(p for p in folder.rglob('*') if p.is_file())
for name in ('prepare_brick2_hybrid.py','prepare_brick2_hybrid_bench.py','prepare_brick2_hybrid_perf.py','archive_brick2_hybrid.py','verify_brick2_hybrid_archive.py'):
    paths.append(ROOT/'artifacts'/name)
paths.append(ROOT/'artifacts/skylake-input256-ordered-static-v1/single_support.py')
for name in ('skylake-brick2-hybrid-v1.json','skylake-brick2-hybrid-validation-v1.json','skylake-brick2-hybrid-long-perf-v1.json'):
    paths.append(ROOT/'experiments'/name)
paths=sorted(set(paths))
HERE.mkdir(exist_ok=False)
entries=[]
with zipfile.ZipFile(HERE/'evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in paths:
        name=p.relative_to(ROOT).as_posix();z.write(p,name)
        entries.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
for name,p in dict(build=build,full=full,performance=perf,
    static=ROOT/'artifacts/skylake-brick2-hybrid-static-v1/results-v2.json',
    independent_static=ROOT/'artifacts/skylake-brick2-hybrid-static-v1/independent_results.json').items():
    (HERE/(name+'.json')).write_bytes(p.read_bytes())
manifest=dict(purpose=__doc__,source_commit='2de21f8bce4a7e4b5ed3ec4aaa1750698f076769',
    branch='codex/skylake-brick2-hybrid-20261023',plan_sha256=sha(plan),build_sha256=sha(build),
    evidence_sha256=sha(HERE/'evidence.zip'),entries=entries,
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(HERE.iterdir()) if p.is_file()],
    baseline23_sha256=read(build)['libraries']['reference']['sha256'],
    candidate_sha256=read(build)['libraries']['candidate']['sha256'],
    scope='归档保留唯一构建及全部首轮样本；不重跑数值或性能。大输入及模型仍按固定SHA从既有档案恢复。')
(HERE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(paths),evidence_sha256=manifest['evidence_sha256'],
    manifest_sha256=sha(HERE/'manifest.json')),ensure_ascii=False))
