"""独立读取ELF和重新反汇编修订84；仅静态检查，不加载候选或执行像素。"""
import hashlib, json, platform, re, struct, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
BUILD=ROOT/'artifacts/skylake-brick2-hybrid-linux-build-v1'
OBJ=BUILD/'CMakeFiles/jshc_skylake_brick2_hybrid.dir'
OLD=ROOT/'artifacts/skylake-pair48-linux-build-v1'
PINNED={'plan':'12ff96e745e743217442d9650f87db35845829e2bded47def80444a62d285ac2',
 'build':'61a9008660a7f824aae91a095f66ceb1fe5e0ee26190ae96c249cd04fcd4c872',
 'candidate':'f37d116d32f2bcdd2595dc79d341d64419fc421b5b8fb95f8aeab47ebb48ea24',
 'reference':'b547cd18aa80d686b39a1c969d8006c04aafb2828ea541bc15cf96ce516dee1e'}

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,name):
 data=subprocess.check_output(['objdump','-drwC','--insn-width=15',str(p)],text=True)
 with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:f.write(data)
 return data

class Elf:
 def __init__(self,path):
  self.raw=Path(path).read_bytes(); h=struct.unpack_from('<16sHHIQQQIHHHHHH',self.raw)
  assert h[0][:6]==b'\x7fELF\x02\x01' and h[2]==62
  self.sections=[dict(zip(('name_id','type','flags','address','offset','size','link','info','align','entsize'),
    struct.unpack_from('<IIQQQQIIQQ',self.raw,h[6]+i*h[11]))) for i in range(h[12])]
  names=self.data(self.sections[h[13]])
  for i,s in enumerate(self.sections):s['name']=names[s['name_id']:].split(b'\0',1)[0].decode();s['index']=i
  self.by_name={s['name']:s for s in self.sections}
 def data(self,s):return self.raw[s['offset']:s['offset']+s['size']]
 def section(self,name):return self.data(self.by_name[name])
 def rip_constant(self,ins):
  text_index=self.by_name['.text']['index'];hits=[]
  for rel in self.sections:
   if rel['type']!=4 or rel['info']!=text_index:continue
   for at in range(rel['offset'],rel['offset']+rel['size'],rel['entsize']):
    offset,info,addend=struct.unpack_from('<QQq',self.raw,at)
    if not ins['address']<=offset<ins['address']+len(ins['bytes']):continue
    symbols=self.sections[rel['link']];sym=struct.unpack_from('<IBBHQQ',self.raw,symbols['offset']+(info>>32)*symbols['entsize'])
    assert (info&0xffffffff)==2 and 0<sym[3]<len(self.sections)
    target=self.sections[sym[3]];start=sym[4]+addend+ins['address']+len(ins['bytes'])-offset
    width=4 if ins['mnemonic']=='vpbroadcastd' else 32
    hits.append(dict(section=target['name'],offset=start,bytes=self.data(target)[start:start+width]))
  assert len(hits)==1,(ins,hits)
  return hits[0]

def instructions(text):
 rows=[];section='';function=''
 for line in text.splitlines():
  if line.startswith('Disassembly of section '):section=line.removeprefix('Disassembly of section ').rstrip(':')
  f=re.match(r'^\s*[0-9a-f]+ <(.+)>:$',line)
  if f:function=f[1]
  m=re.match(r'^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2}\s+)+)\s*([a-z][a-z0-9_.]*)\s*(.*)$',line)
  if not m:continue
  operand=m[4].split('\t',1)[0].split('#',1)[0].strip()
  rows.append(dict(address=int(m[1],16),bytes=bytes.fromhex(m[2]),mnemonic=m[3],operands=operand,line=line,section=section,function=function))
 return rows

def operands(s):
 out=[];start=depth=0
 for i,c in enumerate(s):
  if c=='(':depth+=1
  elif c==')':depth-=1
  elif c==',' and depth==0:out.append(s[start:i]);start=i+1
 out.append(s[start:]);return out

def memory(row):
 # 控制转移的符号签名含括号，不是内存；逐操作数判断，包含vpinsrq第二个内存参数。
 if row['mnemonic'].startswith(('j','call','ret','nop')) or row['mnemonic'] in ('lea','cs','data16'):return []
 return [(i,x) for i,x in enumerate(operands(row['operands'])) if re.search(r'\([^)]*%[^)]*\)',x)]

def branch(row):return int(re.match(r'^([0-9a-f]+)\b',row['operands'])[1],16)
def forbidden(rows,bmi=True):
 names={'andn','andnl','andnq','bextr','blsi','blsmsk','blsr','bzhi','mulx','pdep','pext','rorx','sarx','shlx','shrx','tzcnt','lzcnt'} if bmi else set()
 return [hex(r['address'])+':'+r['mnemonic'] for r in rows if r['mnemonic'] in names or 'gather' in r['mnemonic'] or 'movnt' in r['mnemonic'] or r['bytes'][0]==0x62 or re.search(r'%(zmm|k[0-7])',r['operands'])]

def main():
 assert sha(ROOT/'experiments/skylake-brick2-hybrid-v1.json')==PINNED['plan']
 assert sha(BUILD/'build.json')==PINNED['build']
 assert sha(BUILD/'libjshc_skylake_brick2_hybrid.so')==PINNED['candidate']
 assert sha(BUILD/'libjshc_skylake_reference.so')==PINNED['reference']
 build=json.loads((BUILD/'build.json').read_text());plan=json.loads((ROOT/'experiments/skylake-brick2-hybrid-v1.json').read_text())
 for path,digest in build['source_sha256'].items():assert sha(ROOT/path)==digest,path
 elf=Elf(OBJ/'hybrid_inplace/channel_avx2.cpp.o')
 text=dump(OBJ/'hybrid_inplace/channel_avx2.cpp.o','independent_hybrid.asm.txt')
 rows=[r for r in instructions(text) if r['section']=='.text'];table={r['address']:r for r in rows}
 for row in rows:assert elf.section('.text')[row['address']:row['address']+len(row['bytes'])]==row['bytes']
 # 每轮从输入到正常分支再到共用输出及回边；不按源码行或连续地址窗口遗漏控制流。
 pc=0x184;normal=[];seen=set();conditional={0x245:0xa8,0x17b:0x350}
 while pc not in seen:
  seen.add(pc);r=table[pc];normal.append(r);op=r['mnemonic']
  if op=='jmp':pc=branch(r)
  elif op.startswith('j'):
   assert pc in conditional and branch(r)==conditional[pc];pc+=len(r['bytes'])
  else:assert not op.startswith(('call','ret'));pc+=len(r['bytes'])
 assert pc==0x184 and len(normal)<=128
 assert table[0x341]['mnemonic']=='jmp' and branch(table[0x341])==0x148
 mem=[(r,i,x) for r in normal for i,x in memory(r)]
 stores=[r for r,i,x in mem if i==len(operands(r['operands']))-1]
 loads=[r for r,i,x in mem if i!=len(operands(r['operands']))-1]
 assert len(loads)<=18 and len(stores)==2
 main_load=[r for r in loads if '%rdi,' in r['operands']]
 input_load=[r for r in loads if '(%rax)' in r['operands']]
 constant_load=[r for r in loads if '%rip' in r['operands']]
 assert len(main_load)==8 and all(',8)' in r['operands'] for r in main_load)
 assert [r['address'] for r in input_load]==[0x184,0x188] and len(constant_load)<=8
 assert len(loads)==len(main_load)+len(input_load)+len(constant_load)
 assert not any('%rsp' in r['operands'] or '%rbp' in r['operands'] for r in normal)
 assert not forbidden(rows) and not any(r['mnemonic'].startswith('prefetch') for r in rows)
 assert table[0x184]['operands']=='(%rax),%xmm0' and table[0x188]['operands']=='0x10(%rax),%xmm12'
 assert table[0x151]['operands']=='$0x18,%rax'
 assert [(r['address'],r['operands']) for r in stores]==[(0x16e,'%xmm0,-0x8(%rax)'),(0x173,'%xmm12,-0x18(%rax)')]
 # 独立解析ELF重定位和常量池，核对输入/输出字节标签、细位权重和跨宽度拼接。
 expected={0x37:bytes([0,1,2,255,3,4,5,255,6,7,8,255,9,10,11,255]*2),
  0x3f:bytes([0,1,2,4,5,6,8,9,10,12,13,14,255,255,255,255]*2),
  0x4e:bytes([6,12,24,0]*8),0x56:struct.pack('<8I',0,2,4,6,0,2,4,6),
  0x63:bytes([0,0,0,255,4,4,4,255,8,8,8,255,12,12,12,255]*2),0x24b:struct.pack('<I',0x010101)}
 constants={}
 for at,value in expected.items():
  found=elf.rip_constant(table[at]);assert found['bytes']==value,(hex(at),found,value)
  constants[hex(at)]=dict(section=found['section'],offset=found['offset'],hex=value.hex())
 fallback=[r for r in rows if 0xa8<=r['address']<0x148]
 fallback_id=[r for r in fallback if any('%rsi,' in x for _,x in memory(r))]
 fallback_palette=[r for r in fallback if any('%rdx,' in x for _,x in memory(r))]
 assert len(fallback_id)==len(fallback_palette)==8
 assert max(r['address'] for r in fallback_id[:4])<min(r['address'] for r in fallback_palette[:4])
 assert max(r['address'] for r in fallback_id[4:])<min(r['address'] for r in fallback_palette[4:])
 assert all(r['address']>=0x184 for r in main_load) and branch(table[0x245])==0xa8
 retained={}
 for relative in ('channel_avx2.cpp.o','andn_inplace/channel_avx2.cpp.o','andn_outplace/channel_avx2.cpp.o'):
  matches=list((OLD/'CMakeFiles').glob('*/'+relative));assert len(matches)==1,(relative,matches)
  new_e,old_e=Elf(OBJ/relative),Elf(matches[0]);assert new_e.section('.text')==old_e.section('.text')
  retained[relative]=dict(reference=str(matches[0].relative_to(ROOT)),text_bytes=len(new_e.section('.text')),text_sha256=hashlib.sha256(new_e.section('.text')).hexdigest())
 runtime_text=dump(OBJ/'channel_runtime.cpp.o','independent_runtime.asm.txt');runtime=instructions(runtime_text)
 assert not forbidden(runtime) and not any(r['mnemonic'].startswith('v') for r in runtime)
 dispatch=[r for r in runtime if 'avx2_chain_brick2_hybrid' in r['line']]
 assert len(dispatch)==1
 dispatch_fn=dispatch[0]['function'];fn=[r for r in runtime if r['function']==dispatch_fn and r['section']==dispatch[0]['section']]
 dindex=fn.index(dispatch[0]);window=fn[max(0,dindex-28):dindex+3]
 assert '::apply(' in dispatch_fn and '_omp_fn' in dispatch_fn
 assert not any('input256_ordered' in r['line'] for r in runtime)
 assert any('avx2_chain_pair48(' in r['line'] for r in fn) and any('avx2_chain_adaptive_linear(' in r['line'] for r in fn)
 compile_json=BUILD/'compile_commands.json';assert sha(compile_json)==build['compile_commands_sha256']
 commands=json.loads(compile_json.read_text());selected={}
 for command in commands:
  path=command['file']
  if '/experiments/skylake-brick2-hybrid-runtime/' not in path:continue
  relative=path.split('/experiments/skylake-brick2-hybrid-runtime/',1)[1]
  selected[relative]=command['command']
 assert '-mavx2' in selected['hybrid_inplace/channel_avx2.cpp'] and '-mbmi' not in selected['hybrid_inplace/channel_avx2.cpp']
 assert '-mavx2' not in selected['channel_runtime.cpp'] and '-mbmi' not in selected['channel_runtime.cpp']
 for path in ('andn_inplace/channel_avx2.cpp','andn_outplace/channel_avx2.cpp'):assert '-mbmi' in selected[path]
 result=dict(purpose=__doc__,passed=True,environment=dict(platform=platform.platform(),python=sys.version),
  checker_sha256=sha(__file__),identities=PINNED,source_hashes_verified=len(build['source_sha256']),
  hybrid_object_sha256=sha(OBJ/'hybrid_inplace/channel_avx2.cpp.o'),normal=dict(instructions=len(normal),instruction_limit=128,
   addresses=[hex(r['address']) for r in normal],loads=len(loads),load_limit=18,main_word_loads=len(main_load),input_loads=2,rip_loads=len(constant_load),
   memory_load_addresses=[hex(r['address']) for r in loads],hot_stack_accesses=0,branch_to_fallback='0x245 -> 0xa8',rejoin='0x341 -> 0x148',
   loop_end='0x181 -> 0x184',exit='0x17b -> 0x350',input_bytes=24,output_bytes=24,
   prologue_stack_save='0x2f保存data，0x350退出时恢复；均不在normal热循环'),
  constants=constants,fallback=dict(id_loads=8,palette_loads=8,four_ids_before_palette=True,all_input_before_store=True),
  retained_text_equal_revision79=retained,runtime_isa_clean=True,dispatch_function=dispatch_fn,
  dispatch_window=[r['line'] for r in window],compiler_isa_isolation=True,
  native_pixel_calls=0,performance_calls=0,new_compilations=0,
  limitations=['本次只验证静态对象和来源，不替代完整RGB8、运行时分派或性能验证。',
   '指令数是按完整normal控制流的宏指令数；load按所有内存源操作数计一次，包含RIP常量，不是微操作或缓存miss。'])
 with (OUT/'independent_results.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
 print(json.dumps(dict(passed=True,instructions=len(normal),loads=len(loads),main_word_loads=8,hot_stack=0,result_sha256=sha(OUT/'independent_results.json')),ensure_ascii=False))

if __name__=='__main__':main()
