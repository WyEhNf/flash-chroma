"""修订84对象静态筛查，按实际normal控制流计数；不加载或执行候选。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BUILD=ROOT/'artifacts/skylake-brick2-hybrid-linux-build-v1'
OBJ=BUILD/'CMakeFiles/jshc_skylake_brick2_hybrid.dir'
OLD=ROOT/'artifacts/skylake-pair48-linux-build-v1/CMakeFiles/jshc_skylake_pair48.dir'
HELPER=ROOT/'artifacts/skylake-input256-ordered-static-v1/single_support.py'
s=importlib.util.spec_from_file_location('frozen_helper',HELPER);h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,name):
    t=subprocess.check_output(['objdump','-d','--insn-width=15','-C',str(p)],text=True,encoding='utf-8')
    path=HERE/name
    if path.exists():assert path.read_text(encoding='utf-8').split('Disassembly of section .text:',1)[1]==t.split('Disassembly of section .text:',1)[1]
    else:path.write_text(t,encoding='utf-8')
    return h.read_ops(path)
obj=OBJ/'hybrid_inplace/channel_avx2.cpp.o'
ops=dump(obj,'hybrid.asm.txt')
raw=h.text_section(obj)
assert all(raw[o['offset']:o['offset']+len(o['bytes'])]==bytes.fromhex(' '.join(o['bytes'])) for o in ops)
# 184..341读取/正常恢复，341跳148；148..181输出和回边，181顺接184。
normal=[o for o in ops if 0x184<=o['offset']<=0x341]+[o for o in ops if 0x148<=o['offset']<=0x181]
def at(a):return next(o for o in ops if o['offset']==a)
assert at(0x245)['mnemonic']=='jne' and at(0x245)['operands'].startswith('a8 ')
assert at(0x341)['mnemonic']=='jmp' and at(0x341)['operands'].startswith('148 ')
assert at(0x17b)['mnemonic']=='jb' and at(0x17b)['operands'].startswith('350 ')
loads=[o for o in normal if any(re.search(r'\([^)]*%',v) for v in h.operands(o['operands'])[:-1]) and o['mnemonic'] not in ('lea','nop','nopl','nopw','cs')]
stores=[o for o in normal if '(' in h.operands(o['operands'])[-1] and o['mnemonic'].startswith('vmov')]
main=[o for o in loads if '(%rdi,' in o['operands']]
constants=[o for o in loads if '(%rip)' in o['operands']]
stack=[o for o in normal if '%rsp' in o['operands'] or '%rbp' in o['operands']]
forbidden=[o for o in ops if h.forbidden(o,'linear') or o['mnemonic'] in ('vmovntdq','sfence')]
retained=[]
for name in ('channel_avx2.cpp.o','andn_inplace/channel_avx2.cpp.o','andn_outplace/channel_avx2.cpp.o'):
    new,old=h.text_section(OBJ/name),h.text_section(OLD/name)
    retained.append(dict(path=name,equal_to79=new==old,text_sha256=hashlib.sha256(new).hexdigest()))
runtime=dump(OBJ/'channel_runtime.cpp.o','runtime.asm.txt')
runtime_bad=[o for o in runtime if o['bytes'][0]=='62' or 'gather' in o['mnemonic'] or o['mnemonic']=='andn' or '%ymm' in o['operands'] or '%zmm' in o['operands']]
checks=dict(normal_instructions_le128=len(normal)<=128,normal_loads_le18=len(loads)<=18,
    normal_no_stack=not stack,eight_main_qword_loads=len(main)==8,
    exact_input24=[at(x)['mnemonic'] for x in (0x184,0x188)]==['vmovdqu','vmovq'],
    exact_output24=[at(x)['mnemonic'] for x in (0x16e,0x173)]==['vmovq','vmovdqu'],
    all_reads_before_output=max(o['offset'] for o in loads)<=0x24b,
    no_forbidden=not forbidden,retained_text=all(x['equal_to79'] for x in retained),runtime_generic=not runtime_bad,
    baseline23_identity=read(BUILD/'build.json')['libraries']['reference']['sha256']=='b547cd18aa80d686b39a1c969d8006c04aafb2828ea541bc15cf96ce516dee1e')
result=dict(accepted=all(checks.values()),purpose=__doc__,checks=checks,
    plan_sha256=sha(ROOT/'experiments/skylake-brick2-hybrid-v1.json'),build_sha256=sha(BUILD/'build.json'),
    checker_sha256=sha(Path(__file__)),helper=dict(path=HELPER.relative_to(ROOT).as_posix(),sha256=sha(HELPER)),
    object_sha256=sha(obj),text_sha256=hashlib.sha256(raw).hexdigest(),normal_instructions=len(normal),
    normal_loads=len(loads),normal_rip_loads=constants,normal_stack_references=stack,normal_main_loads=main,
    normal_stores=stores,retained=retained,forbidden=forbidden,runtime_forbidden=runtime_bad,
    control_flow='184..341正常分支→148..181公共写入/回边→184；245异常跳a8，17b退出350',
    io_proof='rax为当前24B源。读取[rax,rax+16)和[rax+16,rax+24)；输出时rax先+24，先写[-8,0)再写[-24,-8)，并集恰24B。所有查表先于共享输出。',
    prologue_stack='2f保存data指针至rsp-8，仅350循环退出后读取；保存寄存器push/pop在循环外，不作为normal热路径spill',
    pixel_calls=0,performance_calls=0)
with (HERE/'results-v2.json').open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(dict(accepted=result['accepted'],checks=checks,instructions=len(normal),loads=len(loads)),ensure_ascii=False))
assert result['accepted']
