"""84静态及完整RGB8通过后冻结首次性能协议；不执行计时。"""
import copy
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
def spec(p):return dict(path=p,sha256=sha(p))
def save(p,v):
    with (ROOT/p).open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
plan='experiments/skylake-brick2-hybrid-v1.json'
build='artifacts/skylake-brick2-hybrid-linux-build-v1/build.json'
static='artifacts/skylake-brick2-hybrid-static-v1/results-v2.json'
independent='artifacts/skylake-brick2-hybrid-static-v1/independent_results.json'
full='artifacts/skylake-brick2-hybrid-linux-full-v1/results.json'
st,ind,r=read(static),read(independent),read(full)
assert st['accepted'] and ind['accepted'] and r['pass']
assert all(v['plan_sha256']==sha(plan) and v['build_sha256']==sha(build) for v in (st,ind,r))
assert r['brick2_hybrid_enabled']=={'single':0,'chain':1}
assert r['brick2_hybrid_inplace_alignment_comparisons']==64
assert r['brick2_hybrid_inplace_actual_offsets']==list(range(64))
assert r['brick2_hybrid_inplace_alignment_pixels']==65793
assert r['model_accounting_bytes']['candidate']==dict(single=272939,chain=44823940)
assert r['hybrid_validation']['independently_checked_blocks']==2**21
validation='experiments/skylake-brick2-hybrid-validation-v1.json'
save(validation,dict(purpose='84独立对象静态与完整RGB8/ABI/边界及全部2³词独立解码身份，不计性能',
    plan_sha256=sha(plan),source_sha256={p:sha(p) for p in ('scripts/verify_skylake_brick2_hybrid_linux.py',
        'scripts/brick2_hybrid_support.py','scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')},
    full_result=spec(full),static_result=spec(static),independent_static_result=spec(independent)))
old=read('experiments/skylake-andn-normal-long-perf-v1.json');policy=copy.deepcopy(old)
policy['purpose']='84独立RGB混合解码对23受控长批次；完整保留三倍/A/A/ABBA/唯一条件确认规则'
for k,p in dict(plan=plan,build=build,full_acceptance=full,validation=validation,
    benchmark_script='scripts/bench_skylake_brick2_hybrid_long_linux.py').items():policy[k]=spec(p)
policy['limits']=['仅新84，不重评旧失败或跨场拼接成绩',
    '原16MiB ID表和新16MiB混合词表均在计时前后核对精确VMA/对齐/全THP',
    '多workers原地混合解码，单workers及true outplace保留79；同候选全部路径本场验收',
    '原16/64内轮、ABBA/A/A、批内均值及四配对中位；48批末SHA非每内轮SHA',
    '首次全部通过才唯一确认，失败停止不重试择优；原门槛不变',
    '新增构造与prepare计入准备+首100图；不外推Skylake实机或官方资源预算']
policy['confirmation']['output']='artifacts/skylake-brick2-hybrid-long-confirm-v1'
left,right=copy.deepcopy(old),copy.deepcopy(policy)
for k in ('purpose','plan','build','full_acceptance','validation','benchmark_script','limits'):left.pop(k);right.pop(k)
left['confirmation'].pop('output');right['confirmation'].pop('output');assert left==right
save('experiments/skylake-brick2-hybrid-long-perf-v1.json',policy)
save('artifacts/skylake-brick2-hybrid-preflight-v1/performance-protocol-audit.json',dict(
    purpose=__doc__,pass_check=True,old_policy=spec('experiments/skylake-andn-normal-long-perf-v1.json'),
    new_policy=spec('experiments/skylake-brick2-hybrid-long-perf-v1.json'),
    all_gates_controls_orders_repeats_quiet_affinity_confirmation_unchanged=True,
    new_additional_diagnostic='新混合表完整THP/VMA与资格只读诊断，不计入原生批内时间',native_calls=0))
print(json.dumps(dict(validation_sha256=sha(validation),policy_sha256=sha('experiments/skylake-brick2-hybrid-long-perf-v1.json')),ensure_ascii=False))
