"""固定可分离RGB8节点与idx，解析校准单调Q16轴坐标；不扩大本轮边界。"""
from __future__ import annotations

import numpy as np
from . import io


def rounding_interval(left: int, right: int, target: int) -> tuple[int, int]:
    """返回half-up输出恰为target的整数frac闭区间，先限制到0..ONE。"""
    left, right, target = int(left), int(right), int(target)
    if not all(0 <= value <= 255 for value in (left, right, target)):
        raise ValueError("舍入区间仅接受RGB8节点和标签")
    slope = right-left
    if slope == 0:
        return (0, io.ONE) if left == target else (1, 0)
    lower = (target-left)*io.ONE-io.ONE//2
    upper = (target+1-left)*io.ONE-io.ONE//2-1
    if slope > 0:
        lo, hi = -((-lower)//slope), upper//slope
    else:
        lo, hi = -((upper)//(-slope)), (-lower)//(-slope)
    return max(0, lo), min(io.ONE, hi)


def diagonal_node_curves(model):
    """检查整个m³节点，拒绝近似可分离或通道置换的模型。"""
    io.validate_sparse(model, competition=True)
    curves = np.stack((model.nodes[:, 0, 0, 0], model.nodes[0, :, 0, 1],
                       model.nodes[0, 0, :, 2]), axis=1)
    for axis in range(3):
        shape = [1, 1, 1]
        shape[axis] = model.m
        if not np.array_equal(model.nodes[..., axis],
                              np.broadcast_to(curves[:, axis].reshape(shape), (model.m,)*3)):
            raise ValueError("本阶段只接受节点完整验证为同轴可分离的模型")
    return curves


def evaluate_curve(nodes, idx, fraction):
    n, i, f = (np.asarray(value, dtype=np.int64) for value in (nodes, idx, fraction))
    return ((n[i]*(io.ONE-f)+n[i+1]*f+io.ONE//2) >> io.Q).astype(np.uint8)


def static_bounds(idx, original, maximum_shift):
    """静态中点隔开相邻有效坐标区间，任意独立选择均非降；首尾固定。"""
    i, f = np.asarray(idx, np.int64), np.asarray(original, np.int64)
    q = i*io.ONE+f
    if np.any(np.diff(q, axis=1) < 0):
        raise ValueError("原有效坐标不单调")
    lower = np.maximum(0, f-maximum_shift)
    upper = np.minimum(io.ONE, f+maximum_shift)
    lower[:, 1:] = np.maximum(lower[:, 1:], (q[:, :-1]+q[:, 1:]+1)//2-i[:, 1:]*io.ONE)
    upper[:, :-1] = np.minimum(upper[:, :-1], (q[:, :-1]+q[:, 1:])//2-i[:, :-1]*io.ONE)
    lower[:, [0, 255]], upper[:, [0, 255]] = f[:, [0, 255]], f[:, [0, 255]]
    if (np.any(lower > f) or np.any(upper < f)
            or np.any((i*io.ONE+upper)[:, :-1] > (i*io.ONE+lower)[:, 1:])):
        raise AssertionError("静态边界没有包含原坐标或不能保证联合单调")
    return lower, upper


def calibrate(model, targets, *, maximum_shift=4096):
    """固定本轮约束下逐码最小绝对误差；不声称其他节点/网格族最优。"""
    source = np.asarray(targets)
    if (source.dtype != np.uint8 or source.shape != (256, 3)
            or not isinstance(maximum_shift, int) or isinstance(maximum_shift, bool)
            or not 0 <= maximum_shift <= io.ONE):
        raise ValueError("需要三条完整RGB8原表曲线和合法总偏移")
    nodes = diagonal_node_curves(model)
    idx, original = model.tables()
    lower, upper = static_bounds(idx, original, maximum_shift)
    wide_lower, wide_upper = static_bounds(idx, original, io.ONE)
    fraction = original.astype(np.int64).copy()
    rows, reasons = [], {}
    for axis in range(3):
        for code in range(256):
            index, before = int(idx[axis, code]), int(original[axis, code])
            a, b, target = int(nodes[index, axis]), int(nodes[index+1, axis]), int(source[code, axis])
            target_lo, target_hi = rounding_interval(a, b, target)
            lo, hi = int(lower[axis, code]), int(upper[axis, code])
            exact_lo, exact_hi = max(lo, target_lo), min(hi, target_hi)
            wide_lo = max(int(wide_lower[axis, code]), target_lo)
            wide_hi = min(int(wide_upper[axis, code]), target_hi)
            reason = None
            if target_lo > target_hi:
                reason = "fixed_nodes_or_cell_unreachable"
            elif wide_lo > wide_hi:
                reason = "fixed_endpoint" if code in (0, 255) else "static_midpoint"
            elif exact_lo > exact_hi:
                reason = "maximum_shift"
            necessary = None if wide_lo > wide_hi else max(wide_lo-before, before-wide_hi, 0)
            unconstrained_shift = (None if target_lo > target_hi else
                                   max(target_lo-before, before-target_hi, 0))
            # 合法fraction整数步进最多改变255/65536，输出不会跳过整数码值。
            out_lo = (a*(io.ONE-lo)+b*lo+io.ONE//2) >> io.Q
            out_hi = (a*(io.ONE-hi)+b*hi+io.ONE//2) >> io.Q
            reachable_target = min(max(target, min(out_lo, out_hi)), max(out_lo, out_hi))
            choice_lo, choice_hi = rounding_interval(a, b, reachable_target)
            choice_lo, choice_hi = max(lo, choice_lo), min(hi, choice_hi)
            if choice_lo > choice_hi:
                raise AssertionError("最接近可达码值却没有合法整数坐标")
            chosen = min(max(before, choice_lo), choice_hi)
            fraction[axis, code] = chosen
            after = (a*(io.ONE-chosen)+b*chosen+io.ONE//2) >> io.Q
            old_output = (a*(io.ONE-before)+b*before+io.ONE//2) >> io.Q
            if abs(after-target) > abs(old_output-target):
                raise AssertionError("区间内最小误差不应比原坐标差")
            if reason:
                reasons[reason] = reasons.get(reason, 0)+1
            rows.append({"axis": axis, "input": code, "cell": index, "left": a, "right": b,
                "target": target, "old_fraction": before, "fraction": chosen,
                "lower": lo, "upper": hi, "target_interval": [target_lo, target_hi],
                "exact_feasible": exact_lo <= exact_hi, "reason": reason,
                "minimum_shift_with_static_bounds": necessary,
                "minimum_shift_without_static_bounds": unconstrained_shift,
                "old_output": old_output, "output": after, "error": after-target})
    candidate = io.SparseLut(model.grid.copy(), model.nodes.copy(), idx.copy(), fraction.astype(np.uint32))
    io.validate_sparse(candidate, competition=True)
    if np.any(np.diff(idx.astype(np.int64)*io.ONE+fraction, axis=1) < 0):
        raise AssertionError("最终有效坐标不单调")
    report = {"maximum_shift": maximum_shift, "code_count": 768,
        "changed_coordinates": int(np.count_nonzero(fraction != original)),
        "remaining_code_errors": sum(row["error"] != 0 for row in rows),
        "baseline_code_errors": sum(row["old_output"] != row["target"] for row in rows),
        "infeasible_reasons": reasons,
        "largest_actual_shift": int(np.abs(fraction-original.astype(np.int64)).max()),
        "all_exact": all(row["error"] == 0 for row in rows),
        "scope": "固定节点/idx、首尾、静态中点及总偏移的逐码最小误差；未改变或放宽约束；非其他网格/节点族最优",
        "rows": rows}
    return candidate, report


def cube_metrics(output_curves, source_curves):
    """独立轴误差直方图作卷积，解析得到完整RGB域统计，不映射三维模型。"""
    difference = np.asarray(output_curves, np.int64)-np.asarray(source_curves, np.int64)
    if difference.shape != (256, 3):
        raise ValueError("需要三条256码值曲线")
    hist = np.array([1], np.int64)
    for axis in range(3):
        values, counts = np.unique(difference[:, axis]**2, return_counts=True)
        updated = np.zeros(len(hist)+int(values[-1]), np.int64)
        for value, count in zip(values, counts):
            updated[int(value):int(value)+len(hist)] += hist*int(count)
        hist = updated
    n = int(hist.sum())
    if n != 256**3:
        raise AssertionError("解析完整域频数不守恒")
    root = np.sqrt(np.arange(len(hist), dtype=np.float64))
    cumulative = np.cumsum(hist)
    rank = .99*(n-1)
    lo, hi = int(np.floor(rank)), int(np.ceil(rank))
    lower, upper = root[np.searchsorted(cumulative, [lo, hi], side="right")]
    return {"n": n, "mean": float(hist@root/n),
        "rms": float(np.sqrt(hist@np.arange(len(hist), dtype=np.int64)/n)),
        "p99": float(lower+(rank-lo)*(upper-lower)),
        "max": float(root[np.flatnonzero(hist)[-1]])}
