"""本阶段封存：复用既有模型对象，绑定实际修复构建和全部原始轮次。"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
assembled = ROOT / 'artifacts/header-perf-assembled-20261028'
output = ROOT / 'report/data/p16-header-performance-20261028'
model = ROOT / 'data/p16-frontier/models/manifest.json'
build = ROOT / 'artifacts/single-header-perf-build'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

if output.exists():
    raise FileExistsError('拒绝覆盖已有阶段证据')
raw = read(assembled / 'results.json')
quality = read(ROOT / 'artifacts/header-perf-quality-20261028.json')
regression = read(ROOT / 'artifacts/header-perf-regression-20261028/results.json')
receipt = read(build / 'libflash_chroma_bridge.dll.build.json')
assert raw['completed'] and quality['passed'] and regression['completed']
assert raw['library']['sha256'] == quality['library']['sha256'] == receipt['library_sha256']
assert regression['plan']['libraries']['fixed']['sha256'] == receipt['library_sha256']
assert sha(ROOT / 'include/flash_chroma.hpp') == receipt['headers']['include/flash_chroma.hpp']
assert len(raw['records']) == 20
output.mkdir(parents=True)
catalog = read(assembled / 'catalog.json')
for row in catalog['models'].values():
    row['manifest'] = Path(os.path.relpath(model, output)).as_posix()
    row['manifest_sha256'] = sha(model)
for row in catalog['candidates']:
    row['evidence'] = 'results.json#' + row['evidence'].rsplit('#', 1)[1]
write(output / 'catalog.json', catalog)
shutil.copyfile(assembled / 'results.json', output / 'results.json')
shutil.copyfile(ROOT / 'artifacts/header-perf-quality-20261028.json', output / 'quality.json')
shutil.copyfile(ROOT / 'artifacts/header-perf-regression-20261028/results.json', output / 'regression.json')
shutil.copyfile(ROOT / 'artifacts/header-perf-coordination-20261028.json', output / 'coordination.json')
shutil.copyfile(ROOT / 'artifacts/header-perf-related-20261028.json', output / 'coordination-related.json')
write(output / 'regression-summary.json', {
    'completed': True, 'formal_calls': regression['formal_calls'],
    'warmup_calls': regression['plan']['warmup_calls'],
    'aa_pass': sum(r['summary']['all_cycles_within_aa_bounds'] for r in regression['records'] if r['versions'][0] == r['versions'][1]),
    'aa_total': sum(r['versions'][0] == r['versions'][1] for r in regression['records']),
    'qualification': regression['qualification'],
    'limitations': '仅本机场次；A/A失败保留；1T旧prepare仍4T；首批旧模型读盘/新模型已读；无目标机和官方分数。'})
for source, name in [
    (build / 'test.log', 'host-ctest.log'),
    (build / 'Testing/Temporary/LastTest.log', 'host-ctest-details.log'),
    (ROOT / 'artifacts/single-header-perf-scalar-build/test.log', 'scalar-ctest.log'),
    (ROOT / 'artifacts/header-perf-python-tests.log', 'python-tests.log'),
    (ROOT / 'artifacts/header-perf-regression-tests.log', 'regression-tests.log'),
    (ROOT / 'artifacts/header-perf-freestanding.json', 'freestanding.json'),
    (build / 'libflash_chroma_bridge.dll.build.json', 'build-receipt.json')]:
    shutil.copyfile(source, output / name)
before = subprocess.check_output(['git', 'show', 'aad1871:include/flash_chroma.hpp'], cwd=ROOT)
before_receipt = read(ROOT / 'artifacts/single-header-build/libflash_chroma_bridge.dll.build.json')
# Git保存LF；既有构建使用相同LF交付字节。
assert hashlib.sha256(before).hexdigest() == before_receipt['headers']['include/flash_chroma.hpp']
with zipfile.ZipFile(output / 'raw-evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(assembled.rglob('*')):
        if path.is_file():
            archive.write(path, 'measurement/' + path.relative_to(assembled).as_posix())
    for folder, prefix in [
        (ROOT / 'artifacts/header-perf-regression-20261028', 'regression'),
        (ROOT / 'artifacts/perf-cause-20261028', 'diagnosis')]:
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.jsonl', '.py', '.hpp', '.inc', '.txt'):
                archive.write(path, prefix + '/' + path.relative_to(folder).as_posix())
    for directory, prefix in [(build, 'build'), (ROOT / 'artifacts/single-header-perf-scalar-build', 'scalar-build')]:
        for name in ('compile_commands.json', 'CMakeCache.txt', 'build.log', 'libflash_chroma_bridge.dll.build.json'):
            path = directory / name
            if path.exists():
                archive.write(path, prefix + '/' + name)
    for name in ('scripts/bench_flash_chroma_regression.py', 'scripts/verify_flash_chroma.py',
                 'scripts/generate_flash_chroma_header.py', 'tests/single_header_direct_contract.cpp',
                 'tests/single_header_prepare_contract.cpp', 'tests/test_flash_chroma_regression.py',
                 'single_header/CMakeLists.txt', 'scripts/p16_unified_support.py', 'scripts/p16_submission.py'):
        archive.write(ROOT / name, 'validation-sources/' + name)
    archive.writestr('before/include/flash_chroma.hpp', before)
    archive.write(ROOT / 'artifacts/single-header-build/libflash_chroma_bridge.dll.build.json', 'before/build-receipt.json')
    archive.write(ROOT / 'report/data/p16-score-candidate-20261027/build-receipt.json', 'old/build-receipt.json')
    archive.write(__file__, 'archive_header_perf.py')
members = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(output.iterdir()) if p.is_file()}
write(output / 'manifest.json', {'members': members, 'model_manifest_sha256': sha(model),
    'implementation_commit': '271e10f', 'models_scope': '复用已有7套内容寻址资产；本轮实测5套，不重复发布模型。',
    'scope': '全部20配置、三方640正式调用及40预热、正确性/编译来源；所有A/A失败及诊断原值保留。'})
print('封存完成：', output)
