"""将新目录的真实三种请求转换为C++记录，比较C++/Python选择。"""
from pathlib import Path
import json
import re
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import p16_frontier as frontier
ROOT = Path(__file__).resolve().parents[1]
folder = ROOT / 'report/data/p16-header-performance-20261028'
catalog_path = folder / 'catalog.json'
catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
old = json.loads((ROOT / 'report/data/p16-frontier-header-20261027/catalog.json').read_text(encoding='utf-8'))
source = (ROOT / 'artifacts/catalog-selection-parity.cpp').read_text(encoding='utf-8')
assert len(catalog['candidates']) == len(old['candidates']) == 40
for i, row in enumerate(catalog['candidates']):
    assert row['id'] == old['candidates'][i]['id'] and row['config'] == old['candidates'][i]['config']
    prefix = f'c[{i}].'
    changes = {'context': json.dumps(row['context'])}
    changes.update({key: repr(row['metrics'][key]) + ('ULL' if key.endswith('_bytes') else '') for key in row['metrics']})
    for key, value in row['verified'].items():
        changes[('time_stable' if key == 'time_stable' else key + '_verified')] = str(value).lower()
    for key, value in changes.items():
        source, n = re.subn(re.escape(prefix + key) + r'=[^;]*;', prefix + key + '=' + value + ';', source)
        assert n == 1, (i, key, n)
context = next(key for key, row in catalog['contexts'].items() if row['timing_scope'].startswith('preloaded'))
source, n = re.subn(r'r.context="[^"]*";', 'r.context=' + json.dumps(context) + ';', source)
assert n == 3
cpp = ROOT / 'artifacts/header-perf-selection.cpp'
exe = ROOT / 'artifacts/header-perf-selection.exe'
cpp.write_text(source, encoding='utf-8')
subprocess.run(['E:/mingw64/bin/g++.exe', '-std=c++17', '-O2', '-fopenmp', '-Iinclude', str(cpp), '-o', str(exe)], cwd=ROOT, check=True)
actual = subprocess.check_output([str(exe)], cwd=ROOT, text=True).splitlines()
requests = [dict(goal='fastest', max_error=1.1, max_runtime_bytes=512 * 1024**2, max_workspace_bytes=40 * 1024**2),
            dict(goal='balanced', weights=(.85, .60, .25)), dict(goal='compact', ignore_time=True)]
results = [frontier.tradeoff(catalog, context=context, **request) for request in requests]
assert all(row['status'] == 'ok' for row in results)
expected = [row['selected']['id'] for row in results]
assert actual == expected, (actual, expected)
chosen = results[0]
chosen['catalog_sha256'] = frontier.digest(catalog_path)
frontier.save_new(folder / 'selected-fastest.json', chosen)
frontier.save_new(folder / 'cpp-selection-parity.json', {'passed': True, 'requests': requests, 'python': expected, 'cpp': actual,
    'context': context, 'catalog_sha256': frontier.digest(catalog_path), 'source_sha256': frontier.digest(cpp),
    'environment': 'Windows AMD64 MinGW G++15.2 C++17 -O2 -fopenmp，实际当前头',
    'scope': '新目录三种真实请求的选择一致；性能不在此重新测量。'})
print('三种请求C++/Python一致：', actual)
