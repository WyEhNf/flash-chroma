"""原始DLL与局部消融DLL的固定单线程配对；不作生产修复。"""
from pathlib import Path
import sys, os, time, statistics, ctypes as ct, json
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import numpy as np
from PIL import Image
import flash_chroma_support as s
OUT=Path(__file__).resolve().parent
s.native.setup(cpus='0,2,4,6')

class CppLibrary(s.Library):
    def __init__(self,path):
        self.path=Path(path);self.sha256=s.digest(path)
        self.dll=ct.CDLL(str(path));self.build_receipt=None
        d=self.dll;d.fc_bridge_capabilities.argtypes=[];d.fc_bridge_capabilities.restype=ct.c_uint32
        d.fc_bridge_create.argtypes=[ct.POINTER(s.Bytes),ct.POINTER(s.Bytes),ct.POINTER(s.Config),ct.POINTER(ct.c_void_p),ct.POINTER(s.Info)]
        d.fc_bridge_create.restype=ct.c_int
        d.fc_bridge_apply.argtypes=[ct.c_void_p,s.U8,ct.c_size_t,ct.c_size_t,s.U8,ct.c_size_t,ct.c_size_t,ct.c_size_t,ct.c_size_t]
        d.fc_bridge_apply.restype=ct.c_int
        d.fc_bridge_destroy.argtypes=[ct.c_void_p];d.fc_bridge_destroy.restype=None
        self.capabilities=int(d.fc_bridge_capabilities())

libs={'original':CppLibrary(ROOT/'artifacts/single-header-build/libflash_chroma_bridge.dll')}
for name in ['rebuild','tune','scalar_lookup']:libs[name]=CppLibrary(OUT/name/'diagnostic.dll')
_,models=s.load_models(ROOT/'data/p16-frontier/models/manifest.json',['default','max_first'])
previous=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
prior=json.loads((ROOT/'report/data/p16-frontier-header-20261027/results.json').read_text(encoding='utf-8'))
frames=np.empty((100,768,1024,3),np.uint8)
for i,row in enumerate(prior['images']):
    assert s.digest(row['path'])==row['sha256']
    with Image.open(row['path']) as image:frames[i]=np.asarray(image)
    assert s.sha(frames[i])==row['pixel_sha256']
assert s.sha(frames)==prior['source_pixels_sha256']
target=np.empty_like(frames);target.fill(173)
src,dst=frames.reshape(-1,3),target.reshape(-1,3)
pairs=[['rebuild','rebuild'],['tune','tune'],['scalar_lookup','scalar_lookup'],
       ['original','rebuild'],['rebuild','tune'],['rebuild','scalar_lookup']]
plan={'purpose':'区分重编译布局、mtune和向量gather/标量查表实现对热映射的影响',
      'pairs':pairs,'cycles':4,'threads':1,'profiles':['default','max_first'],
      'aa_bounds':[.9,1.1],'libraries':{n:{'path':str(l.path),'sha256':l.sha256} for n,l in libs.items()},
      'environment':s.native.environment(),'script_sha256':s.digest(__file__),
      'variants':json.loads((OUT/'variants.json').read_text(encoding='utf-8')),
      'scope':'预加载百图单次FFI，排除读取/准备/哈希；各DLL仅调用C++桥，不需要C99桥',
      'source_sha256':s.sha(frames)}
if (OUT/'ablate-plan.json').exists():raise FileExistsError('拒绝覆盖')
s.write_json(OUT/'ablate-plan.json',plan)
records=[]
for name in plan['profiles']:
    config=s.configuration('direct_u8' if name=='default' else 'direct_u16','avx2',1)
    for versions in pairs:
        handles=[]
        try:
            for v in versions:
                h=libs[v].create(models[name],config);handles.append(h)
                h.apply(src,dst);assert s.sha(target)==previous['gold'][name]
            cycles=[];a=[];b=[];ratios=[]
            for ci in range(plan['cycles']):
                order='ABBA' if ci%2==0 else 'BAAB';trials=[];samples=[[],[]]
                for role in order:
                    idx=0 if role=='A' else 1
                    elapsed=handles[idx].apply(src,dst);actual=s.sha(target)
                    assert actual==previous['gold'][name]
                    samples[idx].append(elapsed)
                    trials.append({'role':role,'variant':versions[idx],'ms':elapsed,'sha256':actual})
                a.extend(samples[0]);b.extend(samples[1]);ratios.append(statistics.mean(samples[1])/statistics.mean(samples[0]))
                cycles.append({'index':ci,'order':order,'trials':trials})
            rec={'profile':name,'pair':versions,'cycles':cycles,'summary':{'a_median_ms':statistics.median(a),
                'b_median_ms':statistics.median(b),'ratios_b_over_a':ratios,
                'ratio_median':statistics.median(ratios),'aa_all_cycles_pass':all(.9<=r<=1.1 for r in ratios)}}
            records.append(rec);s.write_json(OUT/'ablate-partial.json',{'completed':False,'records':records})
            print(json.dumps({k:rec[k] for k in ['profile','pair','summary']},ensure_ascii=False),flush=True)
        finally:
            for h in handles:h.close()
assert s.sha(frames)==plan['source_sha256']
s.write_json(OUT/'ablate-results.json',{'completed':True,'plan':plan,'records':records,
    'notes':['全部原始周期保留，不补轮或剔除','只对本机百图/单线程归因；未运行诊断变体的完整域/短尾合同，禁止直接发布']})
print('消融诊断完成',flush=True)
