"""从原始周期生成诊断摘要；区分A/A资格和A/B数值。"""
from pathlib import Path
import json, statistics, ctypes as ct, sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import flash_chroma_support as s
import p16_unified_support as old
data=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
ablate=json.loads((OUT/'ablate-results.json').read_text(encoding='utf-8'))
summary={'hot':[],'first':[],'ablation':[],'notes':[
    '本机Windows11/Ryzen9 8945HX/GCC15.2 Release -O3，亲和0/2/4/6，未锁频',
    '所有周期固定四次ABBA/BAAB，保留失败周期；每次输出SHA均与此前验证结果一致',
    'A/B比例本身不适用0.9..1.1门槛；资格由对应两侧A/A控制决定',
    '局部读取替换同时改变输入code构造和查表组织，不能独立量化纯gather或纯拆装贡献',
    '普通写入保留；未独立测量64像素展开、预取与NT写入的贡献',
    '诊断变体未通过完整域/短尾合同，不能直接作为交付修复；生产源码未修改']}
for row in data['hot_records']:
    if row['pair']!='old_new':continue
    controls={v:next(x for x in data['hot_records'] if x['profile']==row['profile'] and x['threads']==row['threads'] and x['pair']==v+'_'+v)['summary']
              for v in ['old','new']}
    summary['hot'].append({'profile':row['profile'],'threads':row['threads'],**row['summary'],
        'controls':controls,'aa_qualified':all(c['all_cycles_within_aa'] for c in controls.values())})
for row in data['first_records']:
    trials=[t for c in row['cycles'] for t in c['trials']]
    summary['first'].append({'profile':row['profile'],**row['summary'],
        'median_create_ms':{v:statistics.median(t['create_ms'] for t in trials if t['version']==v) for v in ['old','new']},
        'qualified':False,'note':'没有首批A/A控制，只作描述；旧含模型读取，新模型预读'})
for row in ablate['records']:
    if row['pair'][0]==row['pair'][1]:continue
    controls={v:next((x['summary'] for x in ablate['records'] if x['profile']==row['profile'] and x['pair']==[v,v]),None) for v in row['pair']}
    summary['ablation'].append({'profile':row['profile'],'pair':row['pair'],**row['summary'],
        'controls':controls,'aa_qualified':all(c is not None and c['aa_all_cycles_pass'] for c in controls.values())})
old.setup(cpus='0,2,4,6')
library=old.Library(Path(data['plan']['old_library']['path']))
library.dll.jshc_cc_andn_normal_enabled.argtypes=[ct.c_void_p]
library.dll.jshc_cc_andn_normal_enabled.restype=ct.c_uint32
manifest_path=ROOT/'data/p16-frontier/models/manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
summary['old_runtime_diagnostics']={}
for name in ['default','max_first']:
    row=manifest['profiles'][name]
    def resolve(r):return dict(r,path=str(manifest_path.parent/r['path'])) if r else None
    model={'models':[resolve(r) for r in row['models']],'sidecars':[resolve(r) for r in row['sidecars']]}
    with library.create(model) as chain:
        summary['old_runtime_diagnostics'][name]={'andn_u8_export_flag':int(library.dll.jshc_cc_andn_normal_enabled(chain.handle)),
            'export_scope':'该导出同时要求u8 direct_index非空；u16返回0不表示CPU缺少BMI。构造器在同一CPU每次检测相同BMI条件。',
            'direct_state':old.diagnostics(chain)}
summary['production_tree_status']='git status --short为空；仅artifacts忽略目录增加诊断脚本/构建/证据'
s.write_json(OUT/'summary.json',summary)
for row in summary['hot']:print(row['profile'],row['threads'],row['a_median_ms'],row['b_median_ms'],row['ratio_median'],row['aa_qualified'])
for row in summary['first']:print('prepare',row['profile'],row['median_create_ms'])
for row in summary['ablation']:print('ablation',row['profile'],row['pair'],row['a_median_ms'],row['b_median_ms'],row['aa_qualified'])
print('旧u8分派导出', {k:v['andn_u8_export_flag'] for k,v in summary['old_runtime_diagnostics'].items()})
