"""只在诊断目录复制头文件，隔离查表方式及编译调优差异。"""
from pathlib import Path
import json, subprocess, hashlib
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
source=(ROOT/'include/flash_chroma.hpp').read_text(encoding='utf-8')
bridge=(ROOT/'single_header/bridge.cpp').read_text(encoding='utf-8')
start=source.index('FC_AVX2 inline void direct8(')
end=source.index('\n#endif',start)
original=source[start:end].replace('void direct8(','void direct8_original(',1)
variant=r'''
FC_AVX2 inline void direct8(const std::uint8_t* table,const std::uint32_t* palette,Representation rep,
    const std::uint8_t* src,std::uint8_t* dst,std::size_t n) noexcept {
    if(rep==Representation::DirectRGB24) {direct8_original(table,palette,rep,src,dst,n);return;}
    const __m256i mask=_mm256_set1_epi32(255);
    for(std::size_t i=0;i<n;i+=8) {
        const auto* p=src+3*i;
        std::uint32_t c0,c1,c2,c3,c4,c5,c6;
        std::memcpy(&c0,p,4);std::memcpy(&c1,p+3,4);std::memcpy(&c2,p+6,4);std::memcpy(&c3,p+9,4);
        std::memcpy(&c4,p+12,4);std::memcpy(&c5,p+15,4);std::memcpy(&c6,p+18,4);
        const auto c7=std::uint32_t(p[21])|(std::uint32_t(p[22])<<8)|(std::uint32_t(p[23])<<16);
        const auto* wide=reinterpret_cast<const std::uint16_t*>(table);
        const std::uint32_t i0=rep==Representation::DirectU8?table[c0&0xffffff]:wide[c0&0xffffff];
        const std::uint32_t i1=rep==Representation::DirectU8?table[c1&0xffffff]:wide[c1&0xffffff];
        const std::uint32_t i2=rep==Representation::DirectU8?table[c2&0xffffff]:wide[c2&0xffffff];
        const std::uint32_t i3=rep==Representation::DirectU8?table[c3&0xffffff]:wide[c3&0xffffff];
        const std::uint32_t i4=rep==Representation::DirectU8?table[c4&0xffffff]:wide[c4&0xffffff];
        const std::uint32_t i5=rep==Representation::DirectU8?table[c5&0xffffff]:wide[c5&0xffffff];
        const std::uint32_t i6=rep==Representation::DirectU8?table[c6&0xffffff]:wide[c6&0xffffff];
        const std::uint32_t i7=rep==Representation::DirectU8?table[c7]:wide[c7];
        const __m256i value=_mm256_setr_epi32(palette[i0],palette[i1],palette[i2],palette[i3],palette[i4],palette[i5],palette[i6],palette[i7]);
        Rgb rgb;rgb.r=_mm256_and_si256(value,mask);rgb.g=_mm256_and_si256(_mm256_srli_epi32(value,8),mask);rgb.b=_mm256_srli_epi32(value,16);
        store8(dst+3*i,rgb);
    }
}
'''
records=[]
for name,header,flags in [('rebuild',source,[]),('tune',source,['-mtune=skylake']),
                           ('scalar_lookup',source[:start]+original+variant+source[end:],[])]:
    directory=OUT/name
    directory.mkdir(exist_ok=False)
    (directory/'flash_chroma.hpp').write_text(header,encoding='utf-8')
    (directory/'bridge.cpp').write_text(bridge,encoding='utf-8')
    command=['E:/mingw64/bin/g++.exe','-O3','-DNDEBUG','-std=c++17','-shared','-fopenmp',
             '-DFLASH_CHROMA_ENABLE_OPENMP=1','-I'+str(directory),*flags,
             str(directory/'bridge.cpp'),'-o',str(directory/'diagnostic.dll')]
    subprocess.run(command,check=True)
    def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
    records.append({'name':name,'command':command,'header_sha256':digest(directory/'flash_chroma.hpp'),
                    'bridge_sha256':digest(directory/'bridge.cpp'),'library_sha256':digest(directory/'diagnostic.dll')})
    print('完成诊断构建：'+name,flush=True)
(OUT/'variants.json').write_text(json.dumps({'purpose':'仅作性能原因消融，无生产代码变更',
    'source_header_sha256':hashlib.sha256((ROOT/'include/flash_chroma.hpp').read_bytes()).hexdigest(),
    'records':records},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
