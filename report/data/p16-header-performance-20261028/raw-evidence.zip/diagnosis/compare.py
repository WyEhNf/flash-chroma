"""同场比较既有新旧DLL；仅生成诊断证据，不改生产代码。"""
from pathlib import Path
import sys, os, json, statistics, time, hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import numpy as np
from PIL import Image
import flash_chroma_support as new
import p16_unified_support as old

OUT=Path(__file__).resolve().parent
old.setup(cpus='0,2,4,6')
legacy=old.Library(Path('F:/Hackathon/worktrees/p16-unified-avx512-20261026/artifacts/p16-score-cpu-build/libjshc_unified.dll'))
modern=new.Library(ROOT/'artifacts/single-header-build/libflash_chroma_bridge.dll')
manifest_path=ROOT/'data/p16-frontier/models/manifest.json'
manifest,models=new.load_models(manifest_path,['default','max_first'])
prior=json.loads((ROOT/'report/data/p16-frontier-header-20261027/results.json').read_text(encoding='utf-8'))
frames=np.empty((100,768,1024,3),np.uint8)
for i,row in enumerate(prior['images']):
    assert new.digest(row['path'])==row['sha256']
    with Image.open(row['path']) as image: frames[i]=np.asarray(image)
    assert new.sha(frames[i])==row['pixel_sha256']
assert new.sha(frames)==prior['source_pixels_sha256']
target=np.empty_like(frames);target.fill(173)
source=frames.reshape(-1,3);destination=target.reshape(-1,3)
plan={'purpose':'区分新旧热循环退化、线程敏感性、准备成本与跨场波动；不修改源码',
      'environment':old.environment(), 'thread_environment':{k:os.environ.get(k) for k in
        ['OMP_NUM_THREADS','OMP_WAIT_POLICY','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']},
      'old_library':legacy.record(),'new_library':modern.record(),
      'old_build_receipt_sha256':new.digest(ROOT/'report/data/p16-score-candidate-20261027/build-receipt.json'),
      'manifest_sha256':new.digest(manifest_path),'source_sha256':new.sha(frames),
      'profiles':['default','max_first'],'threads':[1,4], 'cycles':4,
      'orders':['ABBA','BAAB'],'pairs':['old_old','new_new','old_new'],
      'aa_time_ratio_bounds':[0.9,1.1], 'first_cycles':4,
      'first_threads':4,'first_scope':'旧含模型读取；新模型已读；两者含arena分配、准备与首次映射，故不是纯准备算法公平比值',
      'hot_scope':'同一预加载百图、分离输出、AVX2、整个百图单次FFI；不含哈希/准备/分配/解码',
      'script_sha256':new.digest(__file__)}
if (OUT/'plan.json').exists(): raise FileExistsError('拒绝覆盖计划')
new.write_json(OUT/'plan.json',plan)

def row_for(name):
    row=models[name].profile
    def resolve(r):
        if r is None:return None
        return dict(r,path=str((manifest_path.parent/r['path']).resolve()))
    return {'models':[resolve(r) for r in row['models']], 'sidecars':[resolve(r) for r in row['sidecars']]}

def create(name,version,threads):
    if version=='old': return legacy.create(row_for(name))
    rep='direct_u8' if name=='default' else 'direct_u16'
    return modern.create(models[name],new.configuration(rep,'avx2',threads))

def apply(engine,version,threads):
    if version=='old': return engine.apply(frames,target,'avx2',threads)[0]*1000
    return engine.apply(source,destination)

def summarize(cycles):
    ratios=[];a=[];b=[]
    for c in cycles:
        av=[t['milliseconds'] for t in c['trials'] if t['role']=='A']
        bv=[t['milliseconds'] for t in c['trials'] if t['role']=='B']
        a.extend(av);b.extend(bv);ratios.append(statistics.mean(bv)/statistics.mean(av))
    return {'a_median_ms':statistics.median(a),'b_median_ms':statistics.median(b),
        'cycle_ratios_b_over_a':ratios,'ratio_median':statistics.median(ratios),
        'all_cycles_within_aa':all(.9<=r<=1.1 for r in ratios)}

records=[];first_records=[];gold={}
for name in plan['profiles']:
    for threads in plan['threads']:
        for versions in [('old','old'),('new','new'),('old','new')]:
            pair='_'.join(versions);handles=[]
            try:
                for v in versions:
                    h=create(name,v,threads);handles.append(h);apply(h,v,threads)
                    actual=new.sha(target)
                    if name in gold:assert actual==gold[name]
                    else:gold[name]=actual
                cycles=[]
                for ci in range(plan['cycles']):
                    order='ABBA' if ci%2==0 else 'BAAB';trials=[]
                    for role in order:
                        idx=0 if role=='A' else 1
                        ms=apply(handles[idx],versions[idx],threads)
                        actual=new.sha(target);assert actual==gold[name]
                        trials.append({'role':role,'version':versions[idx],'milliseconds':ms,'sha256':actual})
                    cycles.append({'index':ci,'order':order,'trials':trials})
                rec={'profile':name,'threads':threads,'pair':pair,'cycles':cycles,'summary':summarize(cycles),
                     'state':{'old':old.diagnostics(handles[0]) if versions[0]=='old' else None,
                              'new':handles[1].info if versions[1]=='new' else None}}
                records.append(rec)
                new.write_json(OUT/'partial.json',{'completed':False,'hot_records':records,'first_records':first_records})
                print(json.dumps({k:rec[k] for k in ['profile','threads','pair','summary']},ensure_ascii=False),flush=True)
            finally:
                for h in handles:h.close()
    cycles=[]
    for ci in range(plan['first_cycles']):
        order='ABBA' if ci%2==0 else 'BAAB';trials=[]
        for role in order:
            version='old' if role=='A' else 'new';begin=time.perf_counter_ns()
            h=create(name,version,4);ready=time.perf_counter_ns()
            try:
                ms=apply(h,version,4);end=time.perf_counter_ns()
                actual=new.sha(target);assert actual==gold[name]
                trials.append({'role':role,'version':version,'milliseconds':(end-begin)/1e6,
                    'create_ms':(ready-begin)/1e6,'apply_ms':ms,'sha256':actual})
            finally:h.close()
        cycles.append({'index':ci,'order':order,'trials':trials})
    rec={'profile':name,'threads':4,'pair':'old_new','cycles':cycles,'summary':summarize(cycles)}
    first_records.append(rec);print(json.dumps({'first':name,'summary':rec['summary']},ensure_ascii=False),flush=True)
    new.write_json(OUT/'partial.json',{'completed':False,'hot_records':records,'first_records':first_records})

assert new.sha(frames)==plan['source_sha256']
new.write_json(OUT/'results.json',{'completed':True,'plan':plan,'gold':gold,
    'hot_records':records,'first_records':first_records,
    'notes':['单场诊断、不锁频；全部原始值保留，失败不补轮；无跨机外推',
             '每次热/首批输出均核对SHA；没有新增完整域或独立密集LUT精度测试']})
print('同场诊断完成',flush=True)
