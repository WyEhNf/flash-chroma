"""组合两个已冻结实验，保留旧实现不改写；本脚本只生成独立新候选，不加载原生库。"""
from pathlib import Path
ROOT=Path.cwd();out=ROOT/'experiments/skylake-delta-cache-runtime'
if out.exists():raise ValueError('不覆盖新候选')
out.mkdir()
def read(name):return (ROOT/name).read_text(encoding='utf-8')
def write(name,text):(out/name).write_text(text,encoding='utf-8')
delta=read('experiments/skylake-delta16-runtime/channel_runtime.cpp')
cache=read('experiments/skylake-suffix-cache-runtime/channel_runtime.cpp')
prepare=cache[cache.index('void prepare_cache('):cache.index('void apply(')]
diagnostics=cache[cache.index('int jshc_cc_get_cache_info('):cache.index('int jshc_cc_apply(')]
delta=delta.replace('#include "channel_views.hpp"','#include "channel_views.hpp"\n#include "suffix_cache.hpp"')
delta=delta.replace('  bool extended = false;', '  std::vector<uint32_t> cache;\n  jshc_delta16::SuffixCacheView cache_view;\n  jshc_cc_cache_info cache_info{};\n  bool extended = false;')
delta=delta.replace('void apply(Handle& h,',prepare.replace('jshc_channel','jshc_delta16')+'void apply(Handle& h,')
delta=delta.replace('if (!h.extended) {','if (!h.extended && (kernel==0 || !h.cache_info.enabled)) {')
delta=delta.replace('      jshc_delta16::avx2_chain(h.views.data(),h.views.size(),data,vectorized);',
 '      if(h.cache_info.enabled)jshc_delta16::avx2_chain_cached(h.views.data(),h.cache_view,data,vectorized);\n      else jshc_delta16::avx2_chain(h.views.data(),h.views.size(),data,vectorized);')
delta=delta.replace('uint32_t jshc_cc_revision(void) {return 5;}','uint32_t jshc_cc_revision(void) {return 6;}')
delta=delta.replace('    *output=h.release();','    prepare_cache(*h);\n    *output=h.release();')
delta=delta.replace('  return bytes;','  bytes+=h.cache.capacity()*sizeof(uint32_t);\n  return bytes;')
delta=delta.replace('int jshc_cc_apply(',diagnostics+'int jshc_cc_apply(')
delta=delta.replace('jshc_delta16','jshc_delta16_cache')
delta='// 只组合无损坐标差编码与既有有界缓存；以已有缓存为参考，预算/余量和逐级RGB8保持。\n'+delta
write('channel_runtime.cpp',delta)
write('channel_views.hpp',read('experiments/skylake-delta16-runtime/channel_views.hpp').replace('jshc_delta16','jshc_delta16_cache'))
write('suffix_cache.hpp',read('experiments/skylake-suffix-cache-runtime/suffix_cache.hpp').replace('jshc_channel','jshc_delta16_cache'))
avx=read('experiments/skylake-delta16-runtime/channel_avx2.cpp')
oldavx=read('experiments/skylake-suffix-cache-runtime/channel_avx2.cpp')
cached=oldavx[oldavx.index('template<bool FirstShared,bool SuffixShared>'):oldavx.index('\n}\nvoid avx2_chain_cached')]
cached=cached.replace('template<bool FirstShared,bool SuffixShared>','template<bool FirstShared,bool SuffixShared,bool FirstDelta16=false>')
cached=cached.replace('transform<FirstShared>(chain[0],rgb)','transform<FirstShared,FirstDelta16>(chain[0],rgb)')
cached=cached.replace('if(chain[s].shared)transform<true>(chain[s],rgb);else transform<false>(chain[s],rgb);',
 'if(chain[s].shared)transform<true>(chain[s],rgb);\n        else if(chain[s].delta16)transform<false,true>(chain[s],rgb);\n        else transform<false>(chain[s],rgb);')
dispatch=oldavx[oldavx.index('void avx2_chain_cached('):oldavx.index('void avx2_chain(')]
dispatch=dispatch.replace('  } else {\n    if(suffix_shared)',
 '  } else if(chain[0].delta16) {\n    if(suffix_shared)cached<false,true,true>(chain,cache,data,pixels);else cached<false,false,true>(chain,cache,data,pixels);\n  } else {\n    if(suffix_shared)')
avx=avx.replace('#include "channel_views.hpp"','#include "channel_views.hpp"\n#include "suffix_cache.hpp"')
avx=avx.replace('template<bool Delta16>\nvoid fixed_four',cached+'\ntemplate<bool Delta16>\nvoid fixed_four')
avx=avx.replace('void avx2_chain(',dispatch+'void avx2_chain(')
avx=avx.replace('jshc_delta16','jshc_delta16_cache')
write('channel_avx2.cpp',avx)
cmake=read('experiments/skylake-common.cmake')
cmake=cmake.replace('"${JSHC_ROOT}/experiments/channel-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/channel-runtime-specialized/channel_avx2.cpp"',
 '"${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp"')
cmake=cmake.replace('"${JSHC_ROOT}/experiments/channel-runtime-specialized/channel_avx2.cpp"',
 '"${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp"')
cmake='''cmake_minimum_required(VERSION 3.24)
project(jshc_skylake_delta_cache LANGUAGES CXX C)
set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_delta_cache)
set(SKYLAKE_RUNTIME_SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/channel_runtime.cpp")
'''+cmake
# 本独立骨架位于子目录，根目录改为显式两级；旧common保持原字节以保护旧计划。
cmake=cmake.replace('get_filename_component(JSHC_ROOT "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)',
 'get_filename_component(JSHC_ROOT "${CMAKE_CURRENT_LIST_DIR}/../.." ABSOLUTE)')
write('CMakeLists.txt',cmake)
print('独立组合源代码生成完成；没有数值或性能调用')
