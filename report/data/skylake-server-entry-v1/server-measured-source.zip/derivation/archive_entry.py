import json,hashlib,shutil,zipfile
from pathlib import Path
ROOT=Path.cwd();here=Path(__file__).resolve().parent
old=ROOT/'artifacts/skylake-server-bundle-v1';new=ROOT/'artifacts/skylake-server-bundle-v2'
run=old/'artifacts/linux-check-v1';out=ROOT/'report/data/skylake-server-entry-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if out.exists():raise ValueError('不覆盖服务器入口归档')
assert read(run/'results.json')['pass'] and read(here/'equality.json')['pass']
out.mkdir()
for name in ('run.json','policy.json','results.json','contract.json','backend-build-command.json','driver-configure.json',
 'driver-build.json','full-command.json','contract-command.json'):
 shutil.copyfile(run/name,out/('linux-'+name))
for name in ('run.json','results.json','measured-source.zip'):shutil.copyfile(run/'full'/name,out/('full-'+name))
for name in ('build.json','build-log.json','compile_commands.json','measured-source.zip'):
 shutil.copyfile(run/'backend'/name,out/('backend-'+name))
for name in ('equality.json','final-bundle.json'):shutil.copyfile(here/name,out/name)
for folder,prefix in ((old,'initial'),(new,'final')):
 shutil.copyfile(folder/'bundle-manifest.json',out/(prefix+'-bundle-manifest.json'))
with zipfile.ZipFile(out/'server-measured-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder,prefix in ((old,'initial'),(new,'final')):
  for name in read(folder/'bundle-manifest.json')['source_sha256']:
   z.write(folder/name,prefix+'/'+name)
  z.write(folder/'SERVER_README.md',prefix+'/SERVER_README.md')
  z.write(folder/'server-inputs/fixtures/manifest.json',prefix+'/fixture-manifest.json')
 for name in ('finalize_bundle.py','archive_entry.py'):z.write(here/name,'derivation/'+name)
with zipfile.ZipFile(out/'linux-binaries-and-abi-objects.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,s in read(run/'backend/build.json')['libraries'].items():
  z.write(ROOT/Path(s['path'].replace('/mnt/f/Hackathon/projects/16-lut-color/','')),'backend/'+Path(s['path']).name)
 for folder,prefix in ((run/'driver','initial'),(here,'final')):
  for name in ('libjshc_server_driver.so','CMakeFiles/jshc_server_driver.dir/driver.cpp.o'):
   z.write(folder/name,prefix+'/'+Path(name).name)
save(out/'archive-receipt.json',{'purpose':'保存既有Linux正确性、固定输入身份及ABI对象相等证据，不再运行像素、拟合或性能。',
 'linux_result_sha256':sha(run/'results.json'),'final_manifest_sha256':sha(new/'bundle-manifest.json'),
 'local_zip_path':str(Path(str(new)+'.zip')),'local_zip_sha256':sha(Path(str(new)+'.zip')),
 'raw_streams_committed':False,'new_native_calls':0,'new_fits':0,'new_performance_calls':0})
save(out/'manifest.json',{'purpose':'服务器入口与Linux编码验证的原始证据；原始照片/全色域流只在本地338MB字节包。',
 'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()},
 'scope':'标准库入口/ABI/有限及完整字节正确性；正式性能分支未在WSL执行，没有Skylake结果。'})
print('归档完成',len(list(out.iterdir())))
