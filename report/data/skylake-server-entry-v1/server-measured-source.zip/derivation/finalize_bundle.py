import json,hashlib,shutil,zipfile,subprocess
from pathlib import Path
ROOT=Path.cwd();old=ROOT/'artifacts/skylake-server-bundle-v1';out=ROOT/'artifacts/skylake-server-bundle-v2'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if out.exists():raise ValueError('不覆盖冻结字节包')
m=read(old/'bundle-manifest.json');proof=read(ROOT/'artifacts/skylake-server-driver-abi-v2/equality.json')
assert proof['pass'] and all(x['byte_equal'] for x in proof['files'])
out.mkdir()
for name,s in m['files'].items():
 src=old/name;assert sha(src)==s['sha256'] and src.stat().st_size==s['bytes']
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
changed=[]
for name in ('experiments/skylake-server-driver/driver.cpp','experiments/skylake-server-driver/driver.h'):
 shutil.copyfile(ROOT/name,out/name);m['source_sha256'][name]=sha(ROOT/name);changed.append(name)
shutil.copyfile(ROOT/'artifacts/skylake-server-driver-abi-v2/equality.json',out/'server-inputs/driver-abi-equality.json')
m['bundle_revision']=2
m['revision_reason']='回调句柄由const void*改为原ABI的void*，加入编译期类型相等检查；对象和共享库与已验v1逐字节相同，复用相同机器码正确性，不重新生成/拟合/映射或计时。'
m['prior_bundle_manifest_sha256']=sha(old/'bundle-manifest.json')
m['source_tree_status']=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
m['files']={p.relative_to(out).as_posix():{'path':p.relative_to(out).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}
 for p in sorted(out.rglob('*')) if p.is_file()}
save(out/'bundle-manifest.json',m)
with zipfile.ZipFile(str(out)+'.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
save(ROOT/'artifacts/skylake-server-driver-abi-v2/final-bundle.json',{
 'purpose':'固定最终回调声明与原字节包；无新的像素/拟合/计时调用',
 'manifest_sha256':sha(out/'bundle-manifest.json'),'zip_sha256':sha(Path(str(out)+'.zip')),
 'zip_bytes':Path(str(out)+'.zip').stat().st_size,'changed_source_files':changed,
 'files':len(m['files']),'bytes':sum(s['bytes'] for s in m['files'].values()),'reused_machine_code':proof})
print(json.dumps({'bundle_manifest_sha256':sha(out/'bundle-manifest.json'),'files':len(m['files']),
 'zip_bytes':Path(str(out)+'.zip').stat().st_size},ensure_ascii=False))
