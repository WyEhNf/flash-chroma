# Skylake服务器固定测试包

本包保存已经冻结的a399四级模型、100张1024×768 RGB8照片像素、完整整数预期及差值边界夹具。照片来源与限制保存在assets/photos/manifest.json，沿用原素材用途限制，不声明新许可。原始照片像素与完整RGB流只留在本地传输包，不加入Git。

Linux x86_64需要Python 3.11及以上标准库、CMake 3.24及以上、GNU C/C++编译器和OpenMP；无需NumPy、SciPy、Numba或Pillow。进入本目录后执行：

```sh
python3 scripts/run_skylake_server.py --bundle bundle-manifest.json --output artifacts/server-run-v1 --compiler /usr/bin/g++ --c-compiler /usr/bin/gcc --measure
```

省略--measure只做集中正确性和计时器契约，不运行正式性能比较。可用--cpus 0,2,4,6明确指定同L3/NUMA的4个不同物理核；默认根据当前允许集合选择，不修改系统设置。--expected-cpu必须与/proc/cpuinfo的model name原文一致，仅作SKU核对，微架构与实际服务器身份仍须结合硬件说明确认。

入口先校验全部包字节，再在该机器独立构建两库与计时器，执行int16边界/回退/偏移/尾部合同、单级/四级完整256³、100图及原生计时器契约。只有全部通过才执行一次固定AB/BA/BA/AB四进程比较。记录整批100图与100次逐图调用，1/4线程、每配置5轮，排除IO/解码/拟合/准备；创建成本另列。实际库/编译器/CPU/微码/GDS/团队落点均记录。没有自动关闭安全缓解、改频或安装依赖。

输出目录必须全新；失败保留日志，不自动重试或调参。整批毫秒/图是吞吐摊销，逐图原生调用区间才可描述该协议下的单图延迟；两者都不是文件IO端到端。新入口包含公开C ABI调用成本，与旧内部bench绝对时间不混用。AMD/WSL协议验证不代表Skylake成绩，官方数据/Threshold及侧表许可仍未获得。
