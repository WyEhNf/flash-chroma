
artifacts\skylake-compact-cache-build-v1\CMakeFiles\jshc_skylake_reference.dir\F_\Hackathon\projects\16-lut-color\experiments\skylake-r-contiguous-runtime\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)>:
       0:	57                   	push   %rdi
       1:	56                   	push   %rsi
       2:	53                   	push   %rbx
       3:	48 81 ec 40 03 00 00 	sub    $0x340,%rsp
       a:	c5 f8 29 b4 24 a0 02 	vmovaps %xmm6,0x2a0(%rsp)
      11:	00 00 
      13:	c5 f8 29 bc 24 b0 02 	vmovaps %xmm7,0x2b0(%rsp)
      1a:	00 00 
      1c:	c5 78 29 84 24 c0 02 	vmovaps %xmm8,0x2c0(%rsp)
      23:	00 00 
      25:	c5 78 29 8c 24 d0 02 	vmovaps %xmm9,0x2d0(%rsp)
      2c:	00 00 
      2e:	c5 78 29 94 24 e0 02 	vmovaps %xmm10,0x2e0(%rsp)
      35:	00 00 
      37:	c5 78 29 9c 24 f0 02 	vmovaps %xmm11,0x2f0(%rsp)
      3e:	00 00 
      40:	c5 78 29 a4 24 00 03 	vmovaps %xmm12,0x300(%rsp)
      47:	00 00 
      49:	c5 78 29 ac 24 10 03 	vmovaps %xmm13,0x310(%rsp)
      50:	00 00 
      52:	c5 78 29 b4 24 20 03 	vmovaps %xmm14,0x320(%rsp)
      59:	00 00 
      5b:	c5 78 29 bc 24 30 03 	vmovaps %xmm15,0x330(%rsp)
      62:	00 00 
      64:	48 89 c8             	mov    %rcx,%rax
      67:	48 89 d1             	mov    %rdx,%rcx
      6a:	8b 52 0c             	mov    0xc(%rdx),%edx
      6d:	44 8b 59 08          	mov    0x8(%rcx),%r11d
      71:	41 89 d2             	mov    %edx,%r10d
      74:	c4 c1 79 6e fb       	vmovd  %r11d,%xmm7
      79:	45 29 da             	sub    %r11d,%r10d
      7c:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      81:	41 ff c2             	inc    %r10d
      84:	80 b8 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rax)
      8b:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
      91:	c5 f9 6e fa          	vmovd  %edx,%xmm7
      95:	0f b6 50 58          	movzbl 0x58(%rax),%edx
      99:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      9e:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
      a4:	c4 e2 7d 58 79 10    	vpbroadcastd 0x10(%rcx),%ymm7
      aa:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
      b1:	00 00 
      b3:	c4 e2 7d 58 79 14    	vpbroadcastd 0x14(%rcx),%ymm7
      b9:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
      c0:	00 00 
      c2:	c4 e2 7d 58 79 18    	vpbroadcastd 0x18(%rcx),%ymm7
      c8:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
      cf:	00 00 
      d1:	c4 e2 7d 58 79 1c    	vpbroadcastd 0x1c(%rcx),%ymm7
      d7:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
      de:	00 00 
      e0:	0f 84 ca 0a 00 00    	je     bb0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb0>
      e6:	80 b8 18 01 00 00 00 	cmpb   $0x0,0x118(%rax)
      ed:	0f 84 bd 0a 00 00    	je     bb0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb0>
      f3:	44 0f b6 98 78 01 00 	movzbl 0x178(%rax),%r11d
      fa:	00 
      fb:	84 d2                	test   %dl,%dl
      fd:	0f 84 5d 20 00 00    	je     2160 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2160>
     103:	45 84 db             	test   %r11b,%r11b
     106:	0f 84 ac 0a 00 00    	je     bb8 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb8>
     10c:	4d 85 c9             	test   %r9,%r9
     10f:	0f 84 db 1a 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
     115:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 11d <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x11d>
     11c:	00 
     11d:	49 ff c9             	dec    %r9
     120:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     125:	49 c1 e9 03          	shr    $0x3,%r9
     129:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
     12f:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     133:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     13a:	00 00 
     13c:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 184 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x184>
     143:	00 
     144:	49 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%rbx
     149:	ba 00 80 00 00       	mov    $0x8000,%edx
     14e:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     155:	00 00 
     157:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     15b:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     160:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     165:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
     16a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     16f:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
     176:	00 00 
     178:	e9 a5 00 00 00       	jmp    222 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x222>
     17d:	0f 1f 00             	nopl   (%rax)
     180:	8b 51 20             	mov    0x20(%rcx),%edx
     183:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     188:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     18d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     191:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     196:	c4 e2 4d 40 b4 24 40 	vpmulld 0x140(%rsp),%ymm6,%ymm6
     19d:	01 00 00 
     1a0:	41 0f af d2          	imul   %r10d,%edx
     1a4:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     1a8:	48 8b 11             	mov    (%rcx),%rdx
     1ab:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     1b0:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
     1b5:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     1b9:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     1bd:	c4 e2 45 90 0c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm1
     1c3:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     1c8:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     1cc:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     1d0:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     1d5:	c5 e5 72 f1 10       	vpslld $0x10,%ymm1,%ymm3
     1da:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
     1df:	49 83 c0 18          	add    $0x18,%r8
     1e3:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
     1e7:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     1eb:	c4 e2 75 00 8c 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm1
     1f2:	01 00 00 
     1f5:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
     1f9:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     1ff:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     204:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     209:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     20d:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
     213:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     219:	49 39 d8             	cmp    %rbx,%r8
     21c:	0f 84 ce 19 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
     222:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     227:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
     22d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     231:	48 8b 10             	mov    (%rax),%rdx
     234:	44 8b 58 54          	mov    0x54(%rax),%r11d
     238:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
     23e:	44 8b 48 50          	mov    0x50(%rax),%r9d
     242:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
     248:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
     24d:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
     254:	01 00 00 
     257:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     25c:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     261:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
     266:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
     26b:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     26f:	c4 e2 45 90 24 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm4
     275:	48 8b 50 08          	mov    0x8(%rax),%rdx
     279:	c5 e5 db c8          	vpand  %ymm0,%ymm3,%ymm1
     27d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     281:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     285:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     28a:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
     28f:	c4 e2 45 90 34 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm6
     295:	48 8b 50 10          	mov    0x10(%rax),%rdx
     299:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     29e:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     2a3:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     2a8:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     2ad:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 315 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x315>
     2b4:	00 
     2b5:	c4 e2 65 90 3c 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm7
     2bb:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     2c0:	48 8b 50 48          	mov    0x48(%rax),%rdx
     2c4:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 32c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32c>
     2cb:	00 
     2cc:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     2d1:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     2d6:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 33e <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33e>
     2dd:	00 
     2de:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     2e3:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     2e8:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     2ed:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     2f1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     2f5:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     2f9:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     2fd:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     303:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     307:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     30d:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     311:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     317:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     31b:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     320:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     324:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     329:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     32d:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     331:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     337:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 360 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x360>
     33e:	00 00 80 
     341:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     346:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     34c:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     351:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     356:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     35c:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 385 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x385>
     363:	00 00 c0 
     366:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     36a:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     36f:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     374:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     378:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     37c:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     382:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
     388:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     38c:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
     390:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
     394:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     399:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     39d:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     3a1:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     3a6:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     3ab:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     3b0:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     3b5:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     3ba:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     3bf:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     3c4:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     3c8:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     3cc:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     3d0:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     3d4:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     3da:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     3de:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     3e3:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     3e7:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
     3ec:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     3f1:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     3f5:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     3f9:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     3fd:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     402:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     407:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     40c:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
     410:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     415:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     41a:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     41e:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     423:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     428:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     42c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     431:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     435:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     439:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     43e:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     443:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     447:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     44c:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     450:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
     456:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     45d:	00 00 
     45f:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
     466:	00 00 
     468:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     46c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     471:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     477:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     47c:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     480:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     485:	c5 1d 66 c2          	vpcmpgtd %ymm2,%ymm12,%ymm8
     489:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     48e:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     492:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     496:	c5 d5 fa f2          	vpsubd %ymm2,%ymm5,%ymm6
     49a:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     49e:	c5 8d 66 fe          	vpcmpgtd %ymm6,%ymm14,%ymm7
     4a2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     4a7:	c5 f5 fa da          	vpsubd %ymm2,%ymm1,%ymm3
     4ab:	c5 a5 66 e3          	vpcmpgtd %ymm3,%ymm11,%ymm4
     4af:	c5 c5 eb e4          	vpor   %ymm4,%ymm7,%ymm4
     4b3:	c5 e5 66 bc 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm3,%ymm7
     4ba:	00 00 
     4bc:	c5 dd eb e7          	vpor   %ymm7,%ymm4,%ymm4
     4c0:	c5 ed 66 7c 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm7
     4c6:	c5 bd eb ff          	vpor   %ymm7,%ymm8,%ymm7
     4ca:	c5 4d 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm6,%ymm8
     4d1:	00 00 
     4d3:	c4 c1 45 eb f8       	vpor   %ymm8,%ymm7,%ymm7
     4d8:	c5 dd eb e7          	vpor   %ymm7,%ymm4,%ymm4
     4dc:	c5 fd d7 d4          	vpmovmskb %ymm4,%edx
     4e0:	85 d2                	test   %edx,%edx
     4e2:	0f 84 98 fc ff ff    	je     180 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x180>
     4e8:	48 8b 50 60          	mov    0x60(%rax),%rdx
     4ec:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     4f0:	44 8b 98 b4 00 00 00 	mov    0xb4(%rax),%r11d
     4f7:	44 8b 88 b0 00 00 00 	mov    0xb0(%rax),%r9d
     4fe:	c4 e2 45 90 24 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm4
     504:	48 8b 50 68          	mov    0x68(%rax),%rdx
     508:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     50c:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
     511:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     516:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     51c:	48 8b 50 70          	mov    0x70(%rax),%rdx
     520:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     524:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     529:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 591 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x591>
     530:	00 
     531:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     537:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     53c:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     541:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     548:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     54d:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     552:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
     557:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     55c:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     561:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     566:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     56b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 5d3 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5d3>
     572:	00 
     573:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 5db <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5db>
     57a:	00 
     57b:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     580:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     585:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     58a:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     58e:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     592:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     596:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     59a:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     5a0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     5a4:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     5aa:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     5ae:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     5b4:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     5b8:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     5bd:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     5c1:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     5c6:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     5ca:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     5ce:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     5d4:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 5fd <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5fd>
     5db:	00 00 80 
     5de:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     5e3:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     5e9:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     5ee:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     5f3:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     5f9:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 622 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x622>
     600:	00 00 c0 
     603:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     607:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     60c:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     611:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     615:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     619:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     61f:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     625:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     629:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     62d:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
     634:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     638:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     63d:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     641:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     645:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     64a:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     64f:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     654:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     659:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     65e:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     663:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     668:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     66c:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     670:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     674:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     678:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     67e:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     682:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     687:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     68b:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     690:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     695:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     699:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     69d:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     6a1:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     6a6:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     6ab:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6b0:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     6b4:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     6b9:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     6be:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     6c2:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     6c7:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     6cc:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     6d0:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     6d5:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     6d9:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     6dd:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     6e2:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     6e7:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     6eb:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     6f0:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     6f4:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     6f9:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     6ff:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     703:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     708:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     70c:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     711:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     716:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     71a:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     71e:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     722:	c4 e2 4d 90 24 aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm4
     728:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
     72f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     733:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     737:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
     73d:	44 8b 98 14 01 00 00 	mov    0x114(%rax),%r11d
     744:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
     74b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     750:	44 8b 88 10 01 00 00 	mov    0x110(%rax),%r9d
     757:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     75b:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     760:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 7c8 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c8>
     767:	00 
     768:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     76e:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     773:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
     778:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
     77f:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     784:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     789:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
     78e:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     793:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     798:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     79d:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     7a2:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     7a7:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     7ac:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 814 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x814>
     7b3:	00 
     7b4:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 81c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x81c>
     7bb:	00 
     7bc:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     7c1:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     7c6:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     7cb:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     7cf:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     7d3:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7d7:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     7db:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     7e1:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7e5:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     7eb:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     7ef:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     7f5:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     7f9:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     7fe:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     802:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     807:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     80b:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     80f:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     815:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 83e <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x83e>
     81c:	00 00 80 
     81f:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     824:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     82a:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     82f:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     834:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     83a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 863 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x863>
     841:	00 00 c0 
     844:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     848:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     84d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     852:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     856:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     85a:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     860:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     866:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     86a:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     86e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
     875:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     879:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     87e:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     882:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     886:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     88b:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     890:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     895:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     89a:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     89f:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     8a4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     8a9:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     8ad:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     8b1:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     8b5:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     8b9:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     8bf:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     8c3:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     8c8:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     8cc:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     8d1:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     8d6:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     8da:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     8de:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     8e2:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     8e7:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     8ec:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8f1:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     8f5:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     8fa:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     8ff:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     903:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     908:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     90d:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     911:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     916:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     91a:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     91e:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     923:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     928:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     92c:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     931:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     935:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     93a:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     940:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     944:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     949:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     94d:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     952:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     957:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     95b:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     95f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     963:	c4 e2 4d 90 24 aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm4
     969:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
     970:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     974:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     978:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
     97e:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
     985:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     98a:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     98e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     993:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     999:	44 8b 98 74 01 00 00 	mov    0x174(%rax),%r11d
     9a0:	44 8b 88 70 01 00 00 	mov    0x170(%rax),%r9d
     9a7:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     9ac:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     9b1:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
     9b8:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # a20 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa20>
     9bf:	00 
     9c0:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     9c5:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
     9ca:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
     9cf:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     9d4:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     9d9:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     9de:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     9e3:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     9e8:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     9ed:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # a55 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa55>
     9f4:	00 
     9f5:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # a5d <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa5d>
     9fc:	00 
     9fd:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     a02:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     a07:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     a0c:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     a10:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a14:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a18:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     a1c:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     a22:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a26:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     a2c:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     a30:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     a36:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     a3a:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     a3f:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     a43:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     a48:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     a4c:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     a52:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # a7b <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa7b>
     a59:	00 00 80 
     a5c:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     a61:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     a67:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     a6c:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     a71:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     a77:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # aa0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaa0>
     a7e:	00 00 c0 
     a81:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a85:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     a8a:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     a8f:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     a93:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     a97:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a9b:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     aa1:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     aa7:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     aab:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
     aaf:	c5 cd db d0          	vpand  %ymm0,%ymm6,%ymm2
     ab3:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     ab8:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     abc:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     ac0:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     ac5:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     aca:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     acf:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     ad4:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     ad9:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     ade:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ae3:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     ae7:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     aeb:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     aef:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     af3:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     af9:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
     afd:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
     b02:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     b06:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     b0b:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     b10:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     b14:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     b18:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     b1c:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     b21:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     b26:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     b2b:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     b2f:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     b34:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     b39:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     b3d:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     b42:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b47:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     b4b:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     b50:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     b54:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
     b58:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     b5d:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     b62:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     b66:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     b6b:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     b6f:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
     b75:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     b79:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b7e:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     b83:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     b87:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     b8c:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     b91:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     b95:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     b99:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     b9d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ba2:	e9 2e f6 ff ff       	jmp    1d5 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d5>
     ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     bae:	00 00 
     bb0:	84 d2                	test   %dl,%dl
     bb2:	0f 84 f8 06 00 00    	je     12b0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12b0>
     bb8:	4d 85 c9             	test   %r9,%r9
     bbb:	0f 84 2f 10 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
     bc1:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # bc9 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbc9>
     bc8:	00 
     bc9:	49 ff c9             	dec    %r9
     bcc:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     bd1:	48 8d b0 80 01 00 00 	lea    0x180(%rax),%rsi
     bd8:	49 c1 e9 03          	shr    $0x3,%r9
     bdc:	c4 c1 35 72 d7 18    	vpsrld $0x18,%ymm15,%ymm9
     be2:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     be6:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     bed:	00 00 
     bef:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # c37 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc37>
     bf6:	00 
     bf7:	49 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%rbx
     bfc:	ba 00 80 00 00       	mov    $0x8000,%edx
     c01:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     c08:	00 00 
     c0a:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     c0e:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     c13:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
     c1a:	00 00 
     c1c:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
     c21:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     c26:	c5 fe 7f bc 24 40 02 	vmovdqu %ymm7,0x240(%rsp)
     c2d:	00 00 
     c2f:	e9 a8 00 00 00       	jmp    cdc <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcdc>
     c34:	0f 1f 40 00          	nopl   0x0(%rax)
     c38:	8b 51 20             	mov    0x20(%rcx),%edx
     c3b:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
     c40:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
     c45:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     c49:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     c4e:	c4 e2 55 40 ac 24 40 	vpmulld 0x240(%rsp),%ymm5,%ymm5
     c55:	02 00 00 
     c58:	41 0f af d2          	imul   %r10d,%edx
     c5c:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     c60:	48 8b 11             	mov    (%rcx),%rdx
     c63:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     c68:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     c6d:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     c71:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     c75:	c4 e2 45 90 0c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm1
     c7b:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
     c80:	c4 c1 75 db d1       	vpand  %ymm9,%ymm1,%ymm2
     c85:	c4 c1 7d db f9       	vpand  %ymm9,%ymm0,%ymm7
     c8a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     c8f:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     c94:	c5 fd 72 f7 08       	vpslld $0x8,%ymm7,%ymm0
     c99:	49 83 c0 18          	add    $0x18,%r8
     c9d:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     ca1:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     ca5:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
     cac:	01 00 00 
     caf:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     cb3:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     cb9:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     cbe:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     cc3:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     cc7:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     ccd:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     cd3:	4c 39 c3             	cmp    %r8,%rbx
     cd6:	0f 84 14 0f 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
     cdc:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     ce1:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     ce7:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     ceb:	48 8b 10             	mov    (%rax),%rdx
     cee:	44 8b 58 54          	mov    0x54(%rax),%r11d
     cf2:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     cf8:	44 8b 48 50          	mov    0x50(%rax),%r9d
     cfc:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     d02:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
     d07:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
     d0e:	01 00 00 
     d11:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
     d16:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     d1b:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     d20:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     d25:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
     d2a:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
     d30:	48 8b 50 08          	mov    0x8(%rax),%rdx
     d34:	c4 c1 6d db c1       	vpand  %ymm9,%ymm2,%ymm0
     d39:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d3d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     d42:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
     d47:	c4 e2 45 90 2c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm5
     d4d:	48 8b 50 10          	mov    0x10(%rax),%rdx
     d51:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d55:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     d5a:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     d5f:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     d64:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # dcc <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdcc>
     d6b:	00 
     d6c:	c4 e2 45 90 34 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm6
     d72:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     d77:	48 8b 50 48          	mov    0x48(%rax),%rdx
     d7b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # de3 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xde3>
     d82:	00 
     d83:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     d88:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
     d8d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d91:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     d96:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # dfe <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdfe>
     d9d:	00 
     d9e:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     da3:	c4 62 65 39 e5       	vpminsd %ymm5,%ymm3,%ymm12
     da8:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
     dad:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
     db1:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     db5:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     db9:	c5 ad fe d1          	vpaddd %ymm1,%ymm10,%ymm2
     dbd:	c4 62 45 90 34 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm14
     dc3:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     dc7:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     dcc:	c5 65 fe d5          	vpaddd %ymm5,%ymm3,%ymm10
     dd0:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
     dd6:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     dda:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     ddf:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     de3:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     de8:	c4 c1 0d db e9       	vpand  %ymm9,%ymm14,%ymm5
     ded:	c4 c3 5d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm4,%ymm2
     df3:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # e1c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe1c>
     dfa:	00 00 70 
     dfd:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
     e02:	c4 c3 5d 4c e5 30    	vpblendvb %ymm3,%ymm13,%ymm4,%ymm4
     e08:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
     e0f:	00 00 
     e11:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     e15:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     e1a:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm4,%ymm4        # e43 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe43>
     e21:	00 00 c0 
     e24:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     e28:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     e2d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     e32:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     e36:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     e3a:	c4 e2 2d 90 14 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm2
     e40:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
     e46:	c4 41 6d db d1       	vpand  %ymm9,%ymm2,%ymm10
     e4b:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
     e50:	c4 c1 65 db e1       	vpand  %ymm9,%ymm3,%ymm4
     e55:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     e5a:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     e5e:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     e62:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     e67:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     e6c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     e71:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     e76:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     e7b:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
     e80:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e85:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
     e8a:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     e8f:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     e93:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     e97:	c4 c1 4d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm6
     e9d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     ea1:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     ea6:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
     eab:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
     eb0:	c5 9d 72 f6 10       	vpslld $0x10,%ymm6,%ymm12
     eb5:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
     eba:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
     ebf:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     ec3:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     ec8:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     ecd:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ed2:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     ed6:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     edb:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     ee0:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
     ee5:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     eea:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     eef:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
     ef4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ef9:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     efd:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     f01:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     f06:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     f0b:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     f0f:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     f14:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     f18:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
     f1e:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     f25:	00 00 
     f27:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
     f2e:	00 00 
     f30:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
     f35:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     f3a:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     f40:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     f45:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     f49:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     f4e:	c5 9d 66 f9          	vpcmpgtd %ymm1,%ymm12,%ymm7
     f52:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     f57:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     f5b:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     f5f:	c5 dd fa e9          	vpsubd %ymm1,%ymm4,%ymm5
     f63:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     f67:	c5 8d 66 f5          	vpcmpgtd %ymm5,%ymm14,%ymm6
     f6b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f70:	c5 fd fa d1          	vpsubd %ymm1,%ymm0,%ymm2
     f74:	c5 a5 66 da          	vpcmpgtd %ymm2,%ymm11,%ymm3
     f78:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
     f7c:	c5 ed 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm2,%ymm6
     f83:	00 00 
     f85:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
     f89:	c5 f5 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm1,%ymm6
     f8f:	c5 c5 eb f6          	vpor   %ymm6,%ymm7,%ymm6
     f93:	c5 d5 66 bc 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm5,%ymm7
     f9a:	00 00 
     f9c:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
     fa0:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
     fa4:	c5 fd d7 d3          	vpmovmskb %ymm3,%edx
     fa8:	85 d2                	test   %edx,%edx
     faa:	0f 84 88 fc ff ff    	je     c38 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc38>
     fb0:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
     fb7:	00 00 
     fb9:	48 8d 50 60          	lea    0x60(%rax),%rdx
     fbd:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     fc3:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
     fc8:	4c 8b 0a             	mov    (%rdx),%r9
     fcb:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
     fd2:	00 00 
     fd4:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     fd8:	8b 7a 54             	mov    0x54(%rdx),%edi
     fdb:	44 8b 5a 50          	mov    0x50(%rdx),%r11d
     fdf:	c4 c2 4d 90 3c a1    	vpgatherdd %ymm6,(%r9,%ymm4,4),%ymm7
     fe5:	4c 8b 4a 08          	mov    0x8(%rdx),%r9
     fe9:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     fef:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     ff3:	c5 c5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm3        # 105b <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x105b>
     ffa:	00 
     ffb:	c5 c5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm7
    1000:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
    1005:	c4 c2 4d 90 14 a1    	vpgatherdd %ymm6,(%r9,%ymm4,4),%ymm2
    100b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    100f:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    1014:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1018:	c5 ed db 05 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm0        # 1080 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1080>
    101f:	00 
    1020:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1025:	46 8d 5c 1f 01       	lea    0x1(%rdi,%r11,1),%r11d
    102a:	c5 ed 72 d2 11       	vpsrld $0x11,%ymm2,%ymm2
    102f:	c4 e2 45 40 f9       	vpmulld %ymm1,%ymm7,%ymm7
    1034:	c4 42 4d 90 04 a1    	vpgatherdd %ymm6,(%r9,%ymm4,4),%ymm8
    103a:	4c 8b 4a 48          	mov    0x48(%rdx),%r9
    103e:	c5 3d db 15 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm10        # 10a6 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10a6>
    1045:	00 
    1046:	c4 e2 7d 3d eb       	vpmaxsd %ymm3,%ymm0,%ymm5
    104b:	c4 e2 7d 39 e3       	vpminsd %ymm3,%ymm0,%ymm4
    1050:	c4 c1 3d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm8
    1056:	c4 42 55 3d da       	vpmaxsd %ymm10,%ymm5,%ymm11
    105b:	c4 42 5d 39 e2       	vpminsd %ymm10,%ymm4,%ymm12
    1060:	c5 ad 66 ed          	vpcmpgtd %ymm5,%ymm10,%ymm5
    1064:	c4 c1 25 fe f4       	vpaddd %ymm12,%ymm11,%ymm6
    1069:	c4 c1 5d 66 e2       	vpcmpgtd %ymm10,%ymm4,%ymm4
    106e:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    1075:	00 00 
    1077:	c5 f9 6e f7          	vmovd  %edi,%xmm6
    107b:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1080:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    1085:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1089:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    108d:	c4 41 6d fe f0       	vpaddd %ymm8,%ymm2,%ymm14
    1092:	c4 c1 79 6e d3       	vmovd  %r11d,%xmm2
    1097:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    109c:	c5 7e 7f b4 24 c0 01 	vmovdqu %ymm14,0x1c0(%rsp)
    10a3:	00 00 
    10a5:	c4 41 6d fe ee       	vpaddd %ymm14,%ymm2,%ymm13
    10aa:	c4 02 45 90 04 b1    	vpgatherdd %ymm7,(%r9,%ymm14,4),%ymm8
    10b0:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    10b4:	c5 7e 7f ac 24 e0 01 	vmovdqu %ymm13,0x1e0(%rsp)
    10bb:	00 00 
    10bd:	c4 82 6d 90 3c a9    	vpgatherdd %ymm2,(%r9,%ymm13,4),%ymm7
    10c3:	c5 fd 66 d3          	vpcmpgtd %ymm3,%ymm0,%ymm2
    10c7:	c4 e3 75 4c d6 20    	vpblendvb %ymm2,%ymm6,%ymm1,%ymm2
    10cd:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm2,%ymm2        # 10f6 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10f6>
    10d4:	00 00 50 
    10d7:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    10dc:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    10e1:	c4 c2 0d 90 2c 91    	vpgatherdd %ymm14,(%r9,%ymm2,4),%ymm5
    10e7:	c5 e5 66 d0          	vpcmpgtd %ymm0,%ymm3,%ymm2
    10eb:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    10f0:	c5 fe 7f ac 24 60 01 	vmovdqu %ymm5,0x160(%rsp)
    10f7:	00 00 
    10f9:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    10fe:	c4 c1 3d db e9       	vpand  %ymm9,%ymm8,%ymm5
    1103:	c5 ad 72 f5 10       	vpslld $0x10,%ymm5,%ymm10
    1108:	c4 e3 75 4c d6 20    	vpblendvb %ymm2,%ymm6,%ymm1,%ymm2
    110e:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 1137 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1137>
    1115:	00 00 40 
    1118:	c5 95 fa d2          	vpsubd %ymm2,%ymm13,%ymm2
    111c:	c4 c2 0d 90 24 91    	vpgatherdd %ymm14,(%r9,%ymm2,4),%ymm4
    1122:	c5 35 db ac 24 60 01 	vpand  0x160(%rsp),%ymm9,%ymm13
    1129:	00 00 
    112b:	c5 fd fa 84 24 a0 01 	vpsubd 0x1a0(%rsp),%ymm0,%ymm0
    1132:	00 00 
    1134:	c4 c1 5d db d1       	vpand  %ymm9,%ymm4,%ymm2
    1139:	c5 7e 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm14
    1140:	00 00 
    1142:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    1146:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    114a:	c4 c1 45 db d9       	vpand  %ymm9,%ymm7,%ymm3
    114f:	c5 95 fa ed          	vpsubd %ymm5,%ymm13,%ymm5
    1153:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    1157:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    115c:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1161:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    1166:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    116b:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1170:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1175:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    1179:	c4 c1 55 72 d0 08    	vpsrld $0x8,%ymm8,%ymm5
    117f:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1185:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1189:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    118e:	c5 ed 72 d7 08       	vpsrld $0x8,%ymm7,%ymm2
    1193:	c4 41 3d db e9       	vpand  %ymm9,%ymm8,%ymm13
    1198:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    119d:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    11a2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    11a7:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    11ac:	c4 41 45 db c1       	vpand  %ymm9,%ymm7,%ymm8
    11b1:	c4 c1 45 72 f5 10    	vpslld $0x10,%ymm13,%ymm7
    11b7:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
    11be:	00 00 
    11c0:	c4 41 45 fe f6       	vpaddd %ymm14,%ymm7,%ymm14
    11c5:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    11ca:	c5 7e 7f 84 24 20 02 	vmovdqu %ymm8,0x220(%rsp)
    11d1:	00 00 
    11d3:	c5 7e 7f b4 24 00 02 	vmovdqu %ymm14,0x200(%rsp)
    11da:	00 00 
    11dc:	c4 c1 65 fe fa       	vpaddd %ymm10,%ymm3,%ymm7
    11e1:	0f 84 f9 0c 00 00    	je     1ee0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ee0>
    11e7:	c5 fe 6f b4 24 60 01 	vmovdqu 0x160(%rsp),%ymm6
    11ee:	00 00 
    11f0:	c5 e5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm3
    11f5:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    11fa:	48 83 c2 60          	add    $0x60,%rdx
    11fe:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    1203:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1208:	c5 f5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm1
    120d:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    1211:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1216:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    121b:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    121f:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1223:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    1228:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    122d:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1231:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1235:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1239:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    123e:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    1242:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    1247:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    124c:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1251:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1255:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    125a:	c5 fd 6f fa          	vmovdqa %ymm2,%ymm7
    125e:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
    1263:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1268:	c5 e5 fe c4          	vpaddd %ymm4,%ymm3,%ymm0
    126c:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    1271:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1275:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    127a:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    127e:	48 39 f2             	cmp    %rsi,%rdx
    1281:	0f 84 c5 0e 00 00    	je     214c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x214c>
    1287:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    128e:	00 00 
    1290:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    1296:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    129b:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    12a2:	00 00 
    12a4:	e9 1f fd ff ff       	jmp    fc8 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xfc8>
    12a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    12b0:	4d 85 c9             	test   %r9,%r9
    12b3:	0f 84 37 09 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
    12b9:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 12c1 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12c1>
    12c0:	00 
    12c1:	49 ff c9             	dec    %r9
    12c4:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    12c9:	48 8d b0 80 01 00 00 	lea    0x180(%rax),%rsi
    12d0:	49 c1 e9 03          	shr    $0x3,%r9
    12d4:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    12da:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    12de:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    12e5:	00 00 
    12e7:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 132f <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x132f>
    12ee:	00 
    12ef:	49 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%rbx
    12f4:	ba 00 80 00 00       	mov    $0x8000,%edx
    12f9:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    1300:	00 00 
    1302:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    1306:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    130b:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    1312:	00 00 
    1314:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
    1319:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    131e:	c5 fe 7f bc 24 80 02 	vmovdqu %ymm7,0x280(%rsp)
    1325:	00 00 
    1327:	e9 a8 00 00 00       	jmp    13d4 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x13d4>
    132c:	0f 1f 40 00          	nopl   0x0(%rax)
    1330:	8b 51 20             	mov    0x20(%rcx),%edx
    1333:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    1338:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    133c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1340:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    1345:	c4 e2 65 40 9c 24 80 	vpmulld 0x280(%rsp),%ymm3,%ymm3
    134c:	02 00 00 
    134f:	41 0f af d2          	imul   %r10d,%edx
    1353:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1357:	48 8b 11             	mov    (%rcx),%rdx
    135a:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    135f:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    1364:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1368:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    136c:	c4 e2 45 90 0c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm1
    1372:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    1377:	c4 c1 75 db d7       	vpand  %ymm15,%ymm1,%ymm2
    137c:	c4 41 7d db df       	vpand  %ymm15,%ymm0,%ymm11
    1381:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1386:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    138b:	c4 c1 7d 72 f3 08    	vpslld $0x8,%ymm11,%ymm0
    1391:	49 83 c0 18          	add    $0x18,%r8
    1395:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1399:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    139d:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    13a4:	01 00 00 
    13a7:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    13ab:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    13b1:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    13b6:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    13bb:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    13bf:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    13c5:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    13cb:	4c 39 c3             	cmp    %r8,%rbx
    13ce:	0f 84 1c 08 00 00    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
    13d4:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    13d9:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    13df:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    13e3:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    13e8:	48 8b 10             	mov    (%rax),%rdx
    13eb:	44 8b 58 54          	mov    0x54(%rax),%r11d
    13ef:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    13f5:	44 8b 48 50          	mov    0x50(%rax),%r9d
    13f9:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    13ff:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    1406:	01 00 00 
    1409:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    140e:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    1413:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    1418:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    141e:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    1422:	c4 e2 5d 90 14 b2    	vpgatherdd %ymm4,(%rdx,%ymm6,4),%ymm2
    1428:	c4 c1 75 db e7       	vpand  %ymm15,%ymm1,%ymm4
    142d:	48 8b 50 08          	mov    0x8(%rax),%rdx
    1431:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    1435:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    143c:	00 00 
    143e:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    1444:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1448:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    144f:	00 00 
    1451:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    1456:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    145b:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    1460:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
    1465:	c4 e2 7d 90 1c ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm3
    146b:	c4 c1 79 6e fb       	vmovd  %r11d,%xmm7
    1470:	48 8b 50 48          	mov    0x48(%rax),%rdx
    1474:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 14dc <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14dc>
    147b:	00 
    147c:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    1481:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1486:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 14ee <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14ee>
    148d:	00 
    148e:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    1493:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    1498:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    149d:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1505 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1505>
    14a4:	00 
    14a5:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    14aa:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    14af:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    14b3:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    14b7:	c5 7d fe e6          	vpaddd %ymm6,%ymm0,%ymm12
    14bb:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    14bf:	c4 22 7d 90 1c a2    	vpgatherdd %ymm0,(%rdx,%ymm12,4),%ymm11
    14c5:	c4 c1 79 6e c1       	vmovd  %r9d,%xmm0
    14ca:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    14cf:	c4 c1 7d fe f4       	vpaddd %ymm12,%ymm0,%ymm6
    14d4:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    14d9:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    14df:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    14e4:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    14e9:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    14ed:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    14f1:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    14f5:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    14fa:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    1500:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 1529 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1529>
    1507:	00 00 40 
    150a:	c5 9d fe c0          	vpaddd %ymm0,%ymm12,%ymm0
    150e:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    1514:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    1518:	c5 7e 6f 0c 24       	vmovdqu (%rsp),%ymm9
    151d:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1521:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1526:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    152c:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 1555 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1555>
    1533:	00 00 80 
    1536:	c5 b5 fa c0          	vpsubd %ymm0,%ymm9,%ymm0
    153a:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    153f:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    1545:	c5 7e 7f 9c 24 60 01 	vmovdqu %ymm11,0x160(%rsp)
    154c:	00 00 
    154e:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    1553:	4c 8b 48 28          	mov    0x28(%rax),%r9
    1557:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    155c:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    1561:	c5 05 db 8c 24 60 01 	vpand  0x160(%rsp),%ymm15,%ymm9
    1568:	00 00 
    156a:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    1571:	00 00 
    1573:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    1577:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    157b:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    1580:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    1585:	c4 c1 05 db d5       	vpand  %ymm13,%ymm15,%ymm2
    158a:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    158f:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    1594:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    159a:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    159f:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    15a4:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    15a9:	c5 fd fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm0,%ymm0
    15b0:	00 00 
    15b2:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    15b7:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    15bb:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    15c1:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    15c5:	c5 fe 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm4
    15cc:	00 00 
    15ce:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    15d2:	c4 c2 35 90 34 a1    	vpgatherdd %ymm9,(%r9,%ymm4,4),%ymm6
    15d8:	4c 8b 48 20          	mov    0x20(%rax),%r9
    15dc:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    15e1:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    15e6:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 164e <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x164e>
    15ed:	00 
    15ee:	c4 42 35 90 04 a9    	vpgatherdd %ymm9,(%r9,%ymm5,4),%ymm8
    15f4:	4c 8b 48 18          	mov    0x18(%rax),%r9
    15f8:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1660 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1660>
    15ff:	00 
    1600:	c4 c2 2d 90 14 99    	vpgatherdd %ymm10,(%r9,%ymm3,4),%ymm2
    1606:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 166e <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x166e>
    160d:	00 
    160e:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    1613:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    1617:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    161c:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    1621:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    1626:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    162b:	c5 7e 7f 8c 24 e0 01 	vmovdqu %ymm9,0x1e0(%rsp)
    1632:	00 00 
    1634:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    1638:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    163e:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 1667 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1667>
    1645:	00 00 30 
    1648:	c5 9d fe e4          	vpaddd %ymm4,%ymm12,%ymm4
    164c:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    1652:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    1657:	c5 7e 6f 9c 24 60 01 	vmovdqu 0x160(%rsp),%ymm11
    165e:	00 00 
    1660:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1665:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    166a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    166f:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    1675:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    167b:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1680:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 16a9 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16a9>
    1687:	00 00 50 
    168a:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
    168f:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    1693:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    1697:	c4 62 55 90 0c a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm9
    169d:	c5 7e 7f ac 24 c0 01 	vmovdqu %ymm13,0x1c0(%rsp)
    16a4:	00 00 
    16a6:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    16ac:	c5 2d fe ac 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm10,%ymm13
    16b3:	00 00 
    16b5:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    16bb:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    16c1:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    16c6:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    16cb:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
    16d0:	c5 dd fe a4 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm4,%ymm4
    16d7:	00 00 
    16d9:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    16dd:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    16e1:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    16e6:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    16eb:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    16f0:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    16f5:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    16fa:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    1701:	01 00 00 
    1704:	4c 8b 48 40          	mov    0x40(%rax),%r9
    1708:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
    170f:	00 00 
    1711:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    1715:	c5 fe 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm6
    171c:	00 00 
    171e:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    1722:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1728:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    172c:	c4 c2 15 90 2c b1    	vpgatherdd %ymm13,(%r9,%ymm6,4),%ymm5
    1732:	4c 8b 48 38          	mov    0x38(%rax),%r9
    1736:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    173b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 17a3 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    1742:	00 
    1743:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1748:	c4 c2 15 90 34 91    	vpgatherdd %ymm13,(%r9,%ymm2,4),%ymm6
    174e:	4c 8b 48 30          	mov    0x30(%rax),%r9
    1752:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    1757:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 17bf <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17bf>
    175e:	00 
    175f:	c4 c2 15 90 14 99    	vpgatherdd %ymm13,(%r9,%ymm3,4),%ymm2
    1765:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    176a:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 17d2 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17d2>
    1771:	00 
    1772:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    1777:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    177b:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    1780:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    1785:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    178a:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    178f:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    1793:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    1799:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 17c2 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17c2>
    17a0:	00 00 30 
    17a3:	c4 41 1d fe c0       	vpaddd %ymm8,%ymm12,%ymm8
    17a8:	c5 7e 6f a4 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm12
    17af:	00 00 
    17b1:	c4 a2 15 90 1c 82    	vpgatherdd %ymm13,(%rdx,%ymm8,4),%ymm3
    17b7:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    17bb:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    17c0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    17c5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    17c9:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    17ce:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    17d4:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    17d9:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 1802 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1802>
    17e0:	00 00 a0 
    17e3:	c4 c1 2d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm10
    17e9:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    17ee:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    17f2:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    17f7:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    17fc:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    1802:	c4 e2 15 90 3c 8a    	vpgatherdd %ymm13,(%rdx,%ymm1,4),%ymm7
    1808:	c5 fe 6f 8c 24 60 01 	vmovdqu 0x160(%rsp),%ymm1
    180f:	00 00 
    1811:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    1815:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    181a:	c5 9d 66 f0          	vpcmpgtd %ymm0,%ymm12,%ymm6
    181e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1823:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1828:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    182d:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    1831:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    1835:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    183c:	00 00 
    183e:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    1843:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    1848:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    184c:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    1853:	00 00 
    1855:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    185a:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    185f:	c5 3d fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm8,%ymm8
    1866:	00 00 
    1868:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    186d:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    1871:	c5 dd fa d8          	vpsubd %ymm0,%ymm4,%ymm3
    1875:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    187a:	c5 c5 66 eb          	vpcmpgtd %ymm3,%ymm7,%ymm5
    187e:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1884:	c5 bd fa c8          	vpsubd %ymm0,%ymm8,%ymm1
    1888:	c5 a5 66 d1          	vpcmpgtd %ymm1,%ymm11,%ymm2
    188c:	c5 d5 eb d2          	vpor   %ymm2,%ymm5,%ymm2
    1890:	c5 f5 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm1,%ymm5
    1897:	00 00 
    1899:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    189d:	c5 fd 66 6c 24 60    	vpcmpgtd 0x60(%rsp),%ymm0,%ymm5
    18a3:	c5 cd eb ed          	vpor   %ymm5,%ymm6,%ymm5
    18a7:	c5 e5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm6
    18ae:	00 00 
    18b0:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    18b4:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    18b8:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    18bc:	85 d2                	test   %edx,%edx
    18be:	0f 84 6c fa ff ff    	je     1330 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1330>
    18c4:	c5 fe 7f 84 24 60 01 	vmovdqu %ymm0,0x160(%rsp)
    18cb:	00 00 
    18cd:	48 8d 50 60          	lea    0x60(%rax),%rdx
    18d1:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    18d8:	00 00 
    18da:	c5 7e 7f 44 24 20    	vmovdqu %ymm8,0x20(%rsp)
    18e0:	4c 8b 0a             	mov    (%rdx),%r9
    18e3:	c5 fe 6f b4 24 60 01 	vmovdqu 0x160(%rsp),%ymm6
    18ea:	00 00 
    18ec:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    18f0:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    18f6:	8b 7a 54             	mov    0x54(%rdx),%edi
    18f9:	c4 c2 45 90 24 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm4
    18ff:	4c 8b 4a 08          	mov    0x8(%rdx),%r9
    1903:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
    190a:	00 00 
    190c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1910:	c5 dd db 2d 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm5        # 1978 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1978>
    1917:	00 
    1918:	44 8b 5a 50          	mov    0x50(%rdx),%r11d
    191c:	c5 dd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm4
    1921:	c4 c2 45 90 0c b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm1
    1927:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    192b:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    192f:	c5 75 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm9        # 1997 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1997>
    1936:	00 
    1937:	c5 f5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm1
    193c:	c4 41 79 6e db       	vmovd  %r11d,%xmm11
    1941:	c4 c2 4d 90 3c 99    	vpgatherdd %ymm6,(%r9,%ymm3,4),%ymm7
    1947:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    194c:	4c 8b 4a 48          	mov    0x48(%rdx),%r9
    1950:	46 8d 5c 1f 01       	lea    0x1(%rdi,%r11,1),%r11d
    1955:	c5 c5 db 05 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm0        # 19bd <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x19bd>
    195c:	00 
    195d:	c4 e2 35 3d d5       	vpmaxsd %ymm5,%ymm9,%ymm2
    1962:	c4 e2 35 39 f5       	vpminsd %ymm5,%ymm9,%ymm6
    1967:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    196c:	c5 c5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm7
    1971:	c4 e2 6d 3d d8       	vpmaxsd %ymm0,%ymm2,%ymm3
    1976:	c4 62 4d 39 d0       	vpminsd %ymm0,%ymm6,%ymm10
    197b:	c5 fd 66 d2          	vpcmpgtd %ymm2,%ymm0,%ymm2
    197f:	c5 2d fe e3          	vpaddd %ymm3,%ymm10,%ymm12
    1983:	c5 cd 66 f0          	vpcmpgtd %ymm0,%ymm6,%ymm6
    1987:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    198c:	c5 7e 7f a4 24 00 02 	vmovdqu %ymm12,0x200(%rsp)
    1993:	00 00 
    1995:	c5 79 6e e7          	vmovd  %edi,%xmm12
    1999:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    199e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    19a3:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    19a7:	c5 f5 fe ff          	vpaddd %ymm7,%ymm1,%ymm7
    19ab:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    19af:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
    19b6:	00 00 
    19b8:	c4 c2 75 90 24 b9    	vpgatherdd %ymm1,(%r9,%ymm7,4),%ymm4
    19be:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
    19c3:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    19c8:	c5 75 fe ef          	vpaddd %ymm7,%ymm1,%ymm13
    19cc:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    19d0:	c5 7e 7f ac 24 40 02 	vmovdqu %ymm13,0x240(%rsp)
    19d7:	00 00 
    19d9:	c4 02 75 90 04 a9    	vpgatherdd %ymm1,(%r9,%ymm13,4),%ymm8
    19df:	c5 7e 7f 1c 24       	vmovdqu %ymm11,(%rsp)
    19e4:	c5 b5 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm1
    19e8:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
    19ed:	c4 c3 25 4c cc 10    	vpblendvb %ymm1,%ymm12,%ymm11,%ymm1
    19f3:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 1a1c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a1c>
    19fa:	00 00 20 
    19fd:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    1a01:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1a05:	c4 c2 6d 90 3c 89    	vpgatherdd %ymm2,(%r9,%ymm1,4),%ymm7
    1a0b:	c4 c1 55 66 c9       	vpcmpgtd %ymm9,%ymm5,%ymm1
    1a10:	c4 c1 5d db d7       	vpand  %ymm15,%ymm4,%ymm2
    1a15:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    1a1c:	00 00 
    1a1e:	c5 85 db bc 24 c0 01 	vpand  0x1c0(%rsp),%ymm15,%ymm7
    1a25:	00 00 
    1a27:	c5 fe 7f 9c 24 e0 01 	vmovdqu %ymm3,0x1e0(%rsp)
    1a2e:	00 00 
    1a30:	c5 d5 fa ac 24 00 02 	vpsubd 0x200(%rsp),%ymm5,%ymm5
    1a37:	00 00 
    1a39:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    1a3d:	c5 45 fa da          	vpsubd %ymm2,%ymm7,%ymm11
    1a41:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    1a45:	c4 c1 3d db ef       	vpand  %ymm15,%ymm8,%ymm5
    1a4a:	c4 62 25 40 db       	vpmulld %ymm3,%ymm11,%ymm11
    1a4f:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    1a54:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    1a59:	c4 c3 65 4c cc 10    	vpblendvb %ymm1,%ymm12,%ymm3,%ymm1
    1a5f:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm1,%ymm1        # 1a88 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a88>
    1a66:	00 00 60 
    1a69:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    1a6d:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    1a72:	c4 c2 15 90 34 89    	vpgatherdd %ymm13,(%r9,%ymm1,4),%ymm6
    1a78:	c5 95 72 d4 10       	vpsrld $0x10,%ymm4,%ymm13
    1a7d:	c4 c1 4d db cf       	vpand  %ymm15,%ymm6,%ymm1
    1a82:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    1a87:	c4 c1 15 db df       	vpand  %ymm15,%ymm13,%ymm3
    1a8c:	c5 f5 fa ff          	vpsubd %ymm7,%ymm1,%ymm7
    1a90:	c5 d5 fa e9          	vpsubd %ymm1,%ymm5,%ymm5
    1a94:	c5 fe 7f 9c 24 80 01 	vmovdqu %ymm3,0x180(%rsp)
    1a9b:	00 00 
    1a9d:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    1aa4:	00 00 
    1aa6:	c4 e2 45 40 f8       	vpmulld %ymm0,%ymm7,%ymm7
    1aab:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1ab0:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    1ab7:	00 00 
    1ab9:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1abe:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1ac2:	c4 c1 75 72 d0 08    	vpsrld $0x8,%ymm8,%ymm1
    1ac8:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    1ace:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1ad4:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1ad9:	c5 15 fe eb          	vpaddd %ymm3,%ymm13,%ymm13
    1add:	c5 7e 7f ac 24 60 02 	vmovdqu %ymm13,0x260(%rsp)
    1ae4:	00 00 
    1ae6:	c4 41 3d db ef       	vpand  %ymm15,%ymm8,%ymm13
    1aeb:	c5 c5 fe d2          	vpaddd %ymm2,%ymm7,%ymm2
    1aef:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    1af4:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    1af9:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1afd:	c5 c5 fe fb          	vpaddd %ymm3,%ymm7,%ymm7
    1b01:	c5 d5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm5
    1b06:	c5 fe 7f ac 24 00 02 	vmovdqu %ymm5,0x200(%rsp)
    1b0d:	00 00 
    1b0f:	0f 84 4b 01 00 00    	je     1c60 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c60>
    1b15:	c5 7e 6f a4 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm12
    1b1c:	00 00 
    1b1e:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
    1b23:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1b28:	48 83 c2 60          	add    $0x60,%rdx
    1b2c:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1b31:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1b36:	c4 c1 65 72 d4 08    	vpsrld $0x8,%ymm12,%ymm3
    1b3c:	c5 f5 fa d5          	vpsubd %ymm5,%ymm1,%ymm2
    1b40:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1b45:	c4 c1 75 72 d4 10    	vpsrld $0x10,%ymm12,%ymm1
    1b4b:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1b50:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    1b54:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    1b58:	c5 fe 6f a4 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm4
    1b5f:	00 00 
    1b61:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1b66:	c4 e2 55 40 e8       	vpmulld %ymm0,%ymm5,%ymm5
    1b6b:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    1b70:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1b74:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    1b78:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1b7c:	c5 95 fa de          	vpsubd %ymm6,%ymm13,%ymm3
    1b80:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1b85:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1b8a:	c5 cd fa f1          	vpsubd %ymm1,%ymm6,%ymm6
    1b8e:	c5 f5 fa 8c 24 80 01 	vpsubd 0x180(%rsp),%ymm1,%ymm1
    1b95:	00 00 
    1b97:	c4 e2 4d 40 f0       	vpmulld %ymm0,%ymm6,%ymm6
    1b9c:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    1ba0:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    1ba5:	c5 e5 fe c6          	vpaddd %ymm6,%ymm3,%ymm0
    1ba9:	c5 f5 fe 8c 24 60 02 	vpaddd 0x260(%rsp),%ymm1,%ymm1
    1bb0:	00 00 
    1bb2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1bb6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1bbb:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1bbf:	48 39 f2             	cmp    %rsi,%rdx
    1bc2:	0f 84 00 03 00 00    	je     1ec8 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ec8>
    1bc8:	c5 fe 6f bc 24 00 02 	vmovdqu 0x200(%rsp),%ymm7
    1bcf:	00 00 
    1bd1:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    1bd8:	00 00 
    1bda:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1be0:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    1be7:	00 00 
    1be9:	e9 f2 fc ff ff       	jmp    18e0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18e0>
    1bee:	66 90                	xchg   %ax,%ax
    1bf0:	c5 f8 77             	vzeroupper
    1bf3:	c5 f8 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm6
    1bfa:	00 00 
    1bfc:	c5 f8 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm7
    1c03:	00 00 
    1c05:	c5 78 28 84 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm8
    1c0c:	00 00 
    1c0e:	c5 78 28 8c 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm9
    1c15:	00 00 
    1c17:	c5 78 28 94 24 e0 02 	vmovaps 0x2e0(%rsp),%xmm10
    1c1e:	00 00 
    1c20:	c5 78 28 9c 24 f0 02 	vmovaps 0x2f0(%rsp),%xmm11
    1c27:	00 00 
    1c29:	c5 78 28 a4 24 00 03 	vmovaps 0x300(%rsp),%xmm12
    1c30:	00 00 
    1c32:	c5 78 28 ac 24 10 03 	vmovaps 0x310(%rsp),%xmm13
    1c39:	00 00 
    1c3b:	c5 78 28 b4 24 20 03 	vmovaps 0x320(%rsp),%xmm14
    1c42:	00 00 
    1c44:	c5 78 28 bc 24 30 03 	vmovaps 0x330(%rsp),%xmm15
    1c4b:	00 00 
    1c4d:	48 81 c4 40 03 00 00 	add    $0x340,%rsp
    1c54:	5b                   	pop    %rbx
    1c55:	5e                   	pop    %rsi
    1c56:	5f                   	pop    %rdi
    1c57:	c3                   	ret
    1c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1c5f:	00 
    1c60:	4c 8b 5a 28          	mov    0x28(%rdx),%r11
    1c64:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    1c6a:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    1c6e:	48 83 c2 60          	add    $0x60,%rdx
    1c72:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
    1c79:	00 00 
    1c7b:	c5 7e 6f 9c 24 60 01 	vmovdqu 0x160(%rsp),%ymm11
    1c82:	00 00 
    1c84:	c4 c2 4d 90 2c 83    	vpgatherdd %ymm6,(%r11,%ymm0,4),%ymm5
    1c8a:	4c 8b 5a c0          	mov    -0x40(%rdx),%r11
    1c8e:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    1c92:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    1c97:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1cff <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cff>
    1c9e:	00 
    1c9f:	c4 c2 7d 90 34 93    	vpgatherdd %ymm0,(%r11,%ymm2,4),%ymm6
    1ca5:	4c 8b 5a b8          	mov    -0x48(%rdx),%r11
    1ca9:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    1cad:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1d15 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d15>
    1cb4:	00 
    1cb5:	c4 82 6d 90 04 9b    	vpgatherdd %ymm2,(%r11,%ymm11,4),%ymm0
    1cbb:	4c 8b 5a e0          	mov    -0x20(%rdx),%r11
    1cbf:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1d27 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d27>
    1cc6:	00 
    1cc7:	c4 62 7d 3d d6       	vpmaxsd %ymm6,%ymm0,%ymm10
    1ccc:	c5 4d 66 c0          	vpcmpgtd %ymm0,%ymm6,%ymm8
    1cd0:	c4 62 7d 39 ce       	vpminsd %ymm6,%ymm0,%ymm9
    1cd5:	c4 c1 55 66 d2       	vpcmpgtd %ymm10,%ymm5,%ymm2
    1cda:	c4 62 35 39 dd       	vpminsd %ymm5,%ymm9,%ymm11
    1cdf:	c4 62 2d 3d d5       	vpmaxsd %ymm5,%ymm10,%ymm10
    1ce4:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    1ce8:	c4 43 65 4c c4 80    	vpblendvb %ymm8,%ymm12,%ymm3,%ymm8
    1cee:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1cf2:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm8,%ymm8        # 1d1b <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d1b>
    1cf9:	00 00 20 
    1cfc:	c5 3d fe 84 24 20 02 	vpaddd 0x220(%rsp),%ymm8,%ymm8
    1d03:	00 00 
    1d05:	c4 82 65 90 14 81    	vpgatherdd %ymm3,(%r9,%ymm8,4),%ymm2
    1d0b:	c5 7d 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm8
    1d0f:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    1d14:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1d18:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    1d1d:	c4 43 65 4c c4 80    	vpblendvb %ymm8,%ymm12,%ymm3,%ymm8
    1d23:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1d27:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm8,%ymm8        # 1d50 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d50>
    1d2e:	00 00 90 
    1d31:	c5 7e 6f 8c 24 40 02 	vmovdqu 0x240(%rsp),%ymm9
    1d38:	00 00 
    1d3a:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
    1d3f:	c4 02 65 90 0c 81    	vpgatherdd %ymm3,(%r9,%ymm8,4),%ymm9
    1d45:	c4 41 6d db c7       	vpand  %ymm15,%ymm2,%ymm8
    1d4a:	c4 c1 2d fe d3       	vpaddd %ymm11,%ymm10,%ymm2
    1d4f:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    1d55:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1d59:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    1d5e:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    1d62:	c4 c1 35 fa d0       	vpsubd %ymm8,%ymm9,%ymm2
    1d67:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    1d6c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1d71:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1d76:	c5 3d fa c4          	vpsubd %ymm4,%ymm8,%ymm8
    1d7a:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    1d80:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    1d85:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1d89:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    1d8d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1d91:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    1d96:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    1d9b:	c4 c2 45 90 04 a3    	vpgatherdd %ymm7,(%r11,%ymm4,4),%ymm0
    1da1:	4c 8b 5a d8          	mov    -0x28(%rdx),%r11
    1da5:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    1dac:	00 00 
    1dae:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1db2:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1e1a <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e1a>
    1db9:	00 
    1dba:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    1dbe:	c4 c2 45 90 2c a3    	vpgatherdd %ymm7,(%r11,%ymm4,4),%ymm5
    1dc4:	c5 fe 6f 9c 24 60 01 	vmovdqu 0x160(%rsp),%ymm3
    1dcb:	00 00 
    1dcd:	4c 8b 5a d0          	mov    -0x30(%rdx),%r11
    1dd1:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1dd5:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1e3d <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e3d>
    1ddc:	00 
    1ddd:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
    1de2:	c4 c2 45 90 24 9b    	vpgatherdd %ymm7,(%r11,%ymm3,4),%ymm4
    1de8:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1dec:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1e54 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e54>
    1df3:	00 
    1df4:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
    1df9:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    1dfd:	c4 62 5d 39 c5       	vpminsd %ymm5,%ymm4,%ymm8
    1e02:	c5 fd 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm1
    1e06:	c4 62 3d 39 c8       	vpminsd %ymm0,%ymm8,%ymm9
    1e0b:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
    1e10:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
    1e14:	c4 c3 2d 4c f4 60    	vpblendvb %ymm6,%ymm12,%ymm10,%ymm6
    1e1a:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm6,%ymm6        # 1e43 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e43>
    1e21:	00 00 10 
    1e24:	c5 cd fe b4 24 20 02 	vpaddd 0x220(%rsp),%ymm6,%ymm6
    1e2b:	00 00 
    1e2d:	c4 c2 65 90 0c b1    	vpgatherdd %ymm3,(%r9,%ymm6,4),%ymm1
    1e33:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    1e37:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1e3b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1e40:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1e45:	c4 c3 2d 4c dc 60    	vpblendvb %ymm6,%ymm12,%ymm10,%ymm3
    1e4b:	c5 fe 6f b4 24 40 02 	vmovdqu 0x240(%rsp),%ymm6
    1e52:	00 00 
    1e54:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    1e59:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 1e82 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e82>
    1e60:	00 00 80 
    1e63:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    1e67:	c4 c2 1d 90 34 99    	vpgatherdd %ymm12,(%r9,%ymm3,4),%ymm6
    1e6d:	c4 c1 45 fe d9       	vpaddd %ymm9,%ymm7,%ymm3
    1e72:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1e77:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1e7b:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1e80:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1e84:	c5 cd fa d9          	vpsubd %ymm1,%ymm6,%ymm3
    1e88:	c5 f5 fa 8c 24 80 01 	vpsubd 0x180(%rsp),%ymm1,%ymm1
    1e8f:	00 00 
    1e91:	c5 15 fa ee          	vpsubd %ymm6,%ymm13,%ymm13
    1e95:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    1e9a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1e9f:	c4 42 15 40 e9       	vpmulld %ymm9,%ymm13,%ymm13
    1ea4:	c5 f5 fe 8c 24 60 02 	vpaddd 0x260(%rsp),%ymm1,%ymm1
    1eab:	00 00 
    1ead:	c4 c1 7d fe c5       	vpaddd %ymm13,%ymm0,%ymm0
    1eb2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1eb6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1ebb:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1ebf:	48 39 d6             	cmp    %rdx,%rsi
    1ec2:	0f 85 00 fd ff ff    	jne    1bc8 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bc8>
    1ec8:	c5 fe 6f 94 24 00 02 	vmovdqu 0x200(%rsp),%ymm2
    1ecf:	00 00 
    1ed1:	e9 b0 f4 ff ff       	jmp    1386 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1386>
    1ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1edd:	00 00 00 
    1ee0:	4c 8b 5a 28          	mov    0x28(%rdx),%r11
    1ee4:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
    1ee9:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1eed:	48 83 c2 60          	add    $0x60,%rdx
    1ef1:	c5 7e 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm14
    1ef8:	00 00 
    1efa:	c4 c2 65 90 24 83    	vpgatherdd %ymm3,(%r11,%ymm0,4),%ymm4
    1f00:	4c 8b 5a c0          	mov    -0x40(%rdx),%r11
    1f04:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    1f0a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1f0e:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1f76 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f76>
    1f15:	00 
    1f16:	c4 42 65 90 04 83    	vpgatherdd %ymm3,(%r11,%ymm0,4),%ymm8
    1f1c:	4c 8b 5a b8          	mov    -0x48(%rdx),%r11
    1f20:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1f24:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1f8c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f8c>
    1f2b:	00 
    1f2c:	c4 82 65 90 04 b3    	vpgatherdd %ymm3,(%r11,%ymm14,4),%ymm0
    1f32:	4c 8b 5a e0          	mov    -0x20(%rdx),%r11
    1f36:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1f9e <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f9e>
    1f3d:	00 
    1f3e:	c4 42 7d 3d e0       	vpmaxsd %ymm8,%ymm0,%ymm12
    1f43:	c5 3d 66 d0          	vpcmpgtd %ymm0,%ymm8,%ymm10
    1f47:	c4 42 7d 39 d8       	vpminsd %ymm8,%ymm0,%ymm11
    1f4c:	c4 c1 5d 66 dc       	vpcmpgtd %ymm12,%ymm4,%ymm3
    1f51:	c4 62 25 39 f4       	vpminsd %ymm4,%ymm11,%ymm14
    1f56:	c4 62 1d 3d e4       	vpmaxsd %ymm4,%ymm12,%ymm12
    1f5b:	c5 7e 7f b4 24 60 01 	vmovdqu %ymm14,0x160(%rsp)
    1f62:	00 00 
    1f64:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1f69:	c5 25 66 dc          	vpcmpgtd %ymm4,%ymm11,%ymm11
    1f6d:	c4 63 75 4c d6 a0    	vpblendvb %ymm10,%ymm6,%ymm1,%ymm10
    1f73:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm10,%ymm10        # 1f9c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f9c>
    1f7a:	00 00 30 
    1f7d:	c5 2d fe 94 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm10,%ymm10
    1f84:	00 00 
    1f86:	c4 82 0d 90 1c 91    	vpgatherdd %ymm14,(%r9,%ymm10,4),%ymm3
    1f8c:	c4 41 7d 66 d0       	vpcmpgtd %ymm8,%ymm0,%ymm10
    1f91:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1f96:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    1f9b:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    1fa0:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    1fa5:	c4 63 75 4c d6 a0    	vpblendvb %ymm10,%ymm6,%ymm1,%ymm10
    1fab:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm10,%ymm10        # 1fd4 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1fd4>
    1fb2:	00 00 b0 
    1fb5:	c5 7e 6f 9c 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm11
    1fbc:	00 00 
    1fbe:	c4 41 25 fa d2       	vpsubd %ymm10,%ymm11,%ymm10
    1fc3:	c4 02 0d 90 1c 91    	vpgatherdd %ymm14,(%r9,%ymm10,4),%ymm11
    1fc9:	c5 7e 6f b4 24 60 01 	vmovdqu 0x160(%rsp),%ymm14
    1fd0:	00 00 
    1fd2:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    1fd8:	c4 41 1d fe d6       	vpaddd %ymm14,%ymm12,%ymm10
    1fdd:	c4 41 25 db d9       	vpand  %ymm9,%ymm11,%ymm11
    1fe2:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1fe7:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1fec:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    1ff0:	c5 a5 fa e3          	vpsubd %ymm3,%ymm11,%ymm4
    1ff4:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1ff9:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    1ffd:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2002:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    2006:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    200b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    200f:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    2013:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2017:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    201c:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    2021:	c4 c2 5d 90 04 9b    	vpgatherdd %ymm4,(%r11,%ymm3,4),%ymm0
    2027:	4c 8b 5a d8          	mov    -0x28(%rdx),%r11
    202b:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2031:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    2035:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 209d <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x209d>
    203c:	00 
    203d:	c5 fd 6f fa          	vmovdqa %ymm2,%ymm7
    2041:	c4 c2 5d 90 2c 9b    	vpgatherdd %ymm4,(%r11,%ymm3,4),%ymm5
    2047:	c5 7e 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm14
    204e:	00 00 
    2050:	4c 8b 5a d0          	mov    -0x30(%rdx),%r11
    2054:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    2058:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 20c0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20c0>
    205f:	00 
    2060:	c4 82 65 90 24 b3    	vpgatherdd %ymm3,(%r11,%ymm14,4),%ymm4
    2066:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    206b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 20d3 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20d3>
    2072:	00 
    2073:	c4 62 5d 3d d5       	vpmaxsd %ymm5,%ymm4,%ymm10
    2078:	c5 55 66 c4          	vpcmpgtd %ymm4,%ymm5,%ymm8
    207c:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    2081:	c4 c1 7d 66 da       	vpcmpgtd %ymm10,%ymm0,%ymm3
    2086:	c4 62 25 39 e0       	vpminsd %ymm0,%ymm11,%ymm12
    208b:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    2090:	c5 25 66 d8          	vpcmpgtd %ymm0,%ymm11,%ymm11
    2094:	c4 63 75 4c c6 80    	vpblendvb %ymm8,%ymm6,%ymm1,%ymm8
    209a:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 20c3 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20c3>
    20a1:	00 00 30 
    20a4:	c5 3d fe 84 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm8,%ymm8
    20ab:	00 00 
    20ad:	c4 82 0d 90 1c 81    	vpgatherdd %ymm14,(%r9,%ymm8,4),%ymm3
    20b3:	c5 5d 66 c5          	vpcmpgtd %ymm5,%ymm4,%ymm8
    20b7:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    20bc:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    20c0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    20c5:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    20ca:	c4 e3 75 4c ce 80    	vpblendvb %ymm8,%ymm6,%ymm1,%ymm1
    20d0:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 20f9 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20f9>
    20d7:	00 00 b0 
    20da:	c5 7e 6f 9c 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm11
    20e1:	00 00 
    20e3:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    20e7:	c4 c2 0d 90 34 89    	vpgatherdd %ymm14,(%r9,%ymm1,4),%ymm6
    20ed:	c4 c1 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm1
    20f2:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    20f6:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    20fb:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    2100:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2104:	c5 fe 6f a4 24 20 02 	vmovdqu 0x220(%rsp),%ymm4
    210b:	00 00 
    210d:	c5 cd fa cb          	vpsubd %ymm3,%ymm6,%ymm1
    2111:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    2116:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    211b:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2120:	c5 dd fa ce          	vpsubd %ymm6,%ymm4,%ymm1
    2124:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2129:	c5 e5 fe 9c 24 00 02 	vpaddd 0x200(%rsp),%ymm3,%ymm3
    2130:	00 00 
    2132:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2136:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    213a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    213f:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    2143:	48 39 d6             	cmp    %rdx,%rsi
    2146:	0f 85 3b f1 ff ff    	jne    1287 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1287>
    214c:	c5 fe 6f 94 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm2
    2153:	00 00 
    2155:	e9 35 eb ff ff       	jmp    c8f <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc8f>
    215a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2160:	45 84 db             	test   %r11b,%r11b
    2163:	0f 84 47 f1 ff ff    	je     12b0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12b0>
    2169:	4d 85 c9             	test   %r9,%r9
    216c:	0f 84 7e fa ff ff    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
    2172:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 217a <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x217a>
    2179:	00 
    217a:	49 ff c9             	dec    %r9
    217d:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    2182:	49 c1 e9 03          	shr    $0x3,%r9
    2186:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    218c:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    2190:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    2197:	00 00 
    2199:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 21e1 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21e1>
    21a0:	00 
    21a1:	49 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%rbx
    21a6:	ba 00 80 00 00       	mov    $0x8000,%edx
    21ab:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    21b2:	00 00 
    21b4:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    21b8:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    21bd:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    21c2:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
    21c7:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    21cc:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
    21d3:	00 00 
    21d5:	e9 a9 00 00 00       	jmp    2283 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2283>
    21da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    21e0:	8b 51 20             	mov    0x20(%rcx),%edx
    21e3:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    21e8:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    21ec:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    21f0:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    21f5:	c4 e2 65 40 9c 24 00 	vpmulld 0x200(%rsp),%ymm3,%ymm3
    21fc:	02 00 00 
    21ff:	41 0f af d2          	imul   %r10d,%edx
    2203:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    2207:	48 8b 11             	mov    (%rcx),%rdx
    220a:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    220f:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    2214:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2218:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    221c:	c4 e2 45 90 04 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm0
    2222:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2227:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    222c:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2231:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2236:	c5 ed 72 f0 10       	vpslld $0x10,%ymm0,%ymm2
    223b:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    2240:	49 83 c0 18          	add    $0x18,%r8
    2244:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2248:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    224c:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    2253:	01 00 00 
    2256:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    225a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2260:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2265:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    226a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    226e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2274:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    227a:	4c 39 c3             	cmp    %r8,%rbx
    227d:	0f 84 6d f9 ff ff    	je     1bf0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf0>
    2283:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    2288:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    228e:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    2292:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2297:	48 8b 10             	mov    (%rax),%rdx
    229a:	44 8b 58 54          	mov    0x54(%rax),%r11d
    229e:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    22a4:	44 8b 48 50          	mov    0x50(%rax),%r9d
    22a8:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    22ae:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    22b5:	01 00 00 
    22b8:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    22bd:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    22c2:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    22c7:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
    22ce:	00 00 
    22d0:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    22d4:	c4 e2 5d 90 14 b2    	vpgatherdd %ymm4,(%rdx,%ymm6,4),%ymm2
    22da:	c4 c1 75 db e7       	vpand  %ymm15,%ymm1,%ymm4
    22df:	48 8b 50 08          	mov    0x8(%rax),%rdx
    22e3:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    22e8:	c5 fe 7f a4 24 60 01 	vmovdqu %ymm4,0x160(%rsp)
    22ef:	00 00 
    22f1:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    22f6:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
    22fb:	c4 e2 7d 90 2c a2    	vpgatherdd %ymm0,(%rdx,%ymm4,4),%ymm5
    2301:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2305:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    230c:	00 00 
    230e:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2312:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    2317:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 237f <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x237f>
    231e:	00 
    231f:	c4 e2 7d 90 1c ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm3
    2325:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    232a:	c4 c1 79 6e fb       	vmovd  %r11d,%xmm7
    232f:	48 8b 50 48          	mov    0x48(%rax),%rdx
    2333:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2338:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    233d:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 23a5 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23a5>
    2344:	00 
    2345:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    234a:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    234f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 23b7 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23b7>
    2356:	00 
    2357:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    235c:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    2361:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    2365:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2369:	c5 7d fe e6          	vpaddd %ymm6,%ymm0,%ymm12
    236d:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2371:	c4 22 7d 90 1c a2    	vpgatherdd %ymm0,(%rdx,%ymm12,4),%ymm11
    2377:	c4 c1 79 6e c1       	vmovd  %r9d,%xmm0
    237c:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    2381:	c4 c1 7d fe f4       	vpaddd %ymm12,%ymm0,%ymm6
    2386:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    238c:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    2392:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    2397:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    239c:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    23a0:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    23a4:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    23a8:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    23ad:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    23b3:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 23dc <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23dc>
    23ba:	00 00 40 
    23bd:	c5 9d fe c0          	vpaddd %ymm0,%ymm12,%ymm0
    23c1:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    23c7:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    23cb:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    23d1:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    23d5:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    23da:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    23e0:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 2409 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2409>
    23e7:	00 00 80 
    23ea:	c5 b5 fa c0          	vpsubd %ymm0,%ymm9,%ymm0
    23ee:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    23f3:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    23f9:	c5 7e 7f 9c 24 80 01 	vmovdqu %ymm11,0x180(%rsp)
    2400:	00 00 
    2402:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    2407:	4c 8b 48 28          	mov    0x28(%rax),%r9
    240b:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    2410:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    2415:	c5 05 db 8c 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm9
    241c:	00 00 
    241e:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    2425:	00 00 
    2427:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    242b:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    242f:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    2434:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    2439:	c4 c1 05 db d5       	vpand  %ymm13,%ymm15,%ymm2
    243e:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    2443:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    2448:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    244e:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    2453:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    2458:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    245d:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    2462:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    2466:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    246d:	00 00 
    246f:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2473:	c5 fe 6f a4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm4
    247a:	00 00 
    247c:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2480:	c4 c2 35 90 34 a1    	vpgatherdd %ymm9,(%r9,%ymm4,4),%ymm6
    2486:	4c 8b 48 20          	mov    0x20(%rax),%r9
    248a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    248f:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2494:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 24fc <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24fc>
    249b:	00 
    249c:	c4 42 35 90 04 a9    	vpgatherdd %ymm9,(%r9,%ymm5,4),%ymm8
    24a2:	4c 8b 48 18          	mov    0x18(%rax),%r9
    24a6:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    24ab:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 2513 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2513>
    24b2:	00 
    24b3:	c4 c2 35 90 14 99    	vpgatherdd %ymm9,(%r9,%ymm3,4),%ymm2
    24b9:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2521 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2521>
    24c0:	00 
    24c1:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    24c6:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    24ca:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    24cf:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    24d4:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    24d9:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    24de:	c5 7e 7f 8c 24 e0 01 	vmovdqu %ymm9,0x1e0(%rsp)
    24e5:	00 00 
    24e7:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    24eb:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    24f1:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 251a <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x251a>
    24f8:	00 00 30 
    24fb:	c5 9d fe e4          	vpaddd %ymm4,%ymm12,%ymm4
    24ff:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    2505:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    250a:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    2511:	00 00 
    2513:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2518:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    251d:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2522:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    2528:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    252e:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    2533:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 255c <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x255c>
    253a:	00 00 50 
    253d:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2543:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2547:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    254b:	c4 62 55 90 0c a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm9
    2551:	c5 7e 7f ac 24 c0 01 	vmovdqu %ymm13,0x1c0(%rsp)
    2558:	00 00 
    255a:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    2560:	c5 2d fe ac 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm10,%ymm13
    2567:	00 00 
    2569:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    256f:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    2575:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    257a:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    257f:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
    2584:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    2589:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    258d:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2591:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    2596:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    259b:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    25a0:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    25a5:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    25aa:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    25b1:	01 00 00 
    25b4:	4c 8b 48 40          	mov    0x40(%rax),%r9
    25b8:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    25bf:	00 00 
    25c1:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    25c5:	c5 fe 6f b4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm6
    25cc:	00 00 
    25ce:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    25d2:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    25d9:	00 00 
    25db:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    25df:	c4 c2 15 90 2c b1    	vpgatherdd %ymm13,(%r9,%ymm6,4),%ymm5
    25e5:	4c 8b 48 38          	mov    0x38(%rax),%r9
    25e9:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    25ee:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2656 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2656>
    25f5:	00 
    25f6:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    25fb:	c4 c2 15 90 34 91    	vpgatherdd %ymm13,(%r9,%ymm2,4),%ymm6
    2601:	4c 8b 48 30          	mov    0x30(%rax),%r9
    2605:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    260a:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2672 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2672>
    2611:	00 
    2612:	c4 c2 15 90 14 99    	vpgatherdd %ymm13,(%r9,%ymm3,4),%ymm2
    2618:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    261d:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2685 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2685>
    2624:	00 
    2625:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    262a:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    262e:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    2633:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    2638:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    263d:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    2642:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    2646:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    264c:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 2675 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2675>
    2653:	00 00 30 
    2656:	c4 41 1d fe c0       	vpaddd %ymm8,%ymm12,%ymm8
    265b:	c5 7e 6f a4 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm12
    2662:	00 00 
    2664:	c4 a2 15 90 1c 82    	vpgatherdd %ymm13,(%rdx,%ymm8,4),%ymm3
    266a:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    266e:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    2673:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2678:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    267c:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2681:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    2687:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    268d:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 26b6 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26b6>
    2694:	00 00 a0 
    2697:	c4 c1 2d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm10
    269d:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    26a2:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    26a6:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    26ab:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    26b0:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    26b6:	c4 e2 15 90 3c 8a    	vpgatherdd %ymm13,(%rdx,%ymm1,4),%ymm7
    26bc:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    26c3:	00 00 
    26c5:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    26c9:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    26ce:	c5 9d 66 f0          	vpcmpgtd %ymm0,%ymm12,%ymm6
    26d2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    26d7:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    26dc:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    26e1:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    26e5:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    26e9:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    26f0:	00 00 
    26f2:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    26f7:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    26fc:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2700:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    2707:	00 00 
    2709:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    270e:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    2713:	c5 3d fe 04 24       	vpaddd (%rsp),%ymm8,%ymm8
    2718:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    271d:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    2721:	c5 dd fa d8          	vpsubd %ymm0,%ymm4,%ymm3
    2725:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    272a:	c5 c5 66 eb          	vpcmpgtd %ymm3,%ymm7,%ymm5
    272e:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2734:	c5 bd fa c8          	vpsubd %ymm0,%ymm8,%ymm1
    2738:	c5 a5 66 d1          	vpcmpgtd %ymm1,%ymm11,%ymm2
    273c:	c5 d5 eb d2          	vpor   %ymm2,%ymm5,%ymm2
    2740:	c5 f5 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm1,%ymm5
    2747:	00 00 
    2749:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    274d:	c5 fd 66 6c 24 60    	vpcmpgtd 0x60(%rsp),%ymm0,%ymm5
    2753:	c5 cd eb ed          	vpor   %ymm5,%ymm6,%ymm5
    2757:	c5 e5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm6
    275e:	00 00 
    2760:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    2764:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    2768:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    276c:	85 d2                	test   %edx,%edx
    276e:	0f 84 6c fa ff ff    	je     21e0 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21e0>
    2774:	48 8b 50 60          	mov    0x60(%rax),%rdx
    2778:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    277c:	44 8b 98 b4 00 00 00 	mov    0xb4(%rax),%r11d
    2783:	44 8b 88 b0 00 00 00 	mov    0xb0(%rax),%r9d
    278a:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
    2790:	48 8b 50 68          	mov    0x68(%rax),%rdx
    2794:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2798:	c4 41 79 6e e3       	vmovd  %r11d,%xmm12
    279d:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    27a2:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    27a7:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 280f <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x280f>
    27ae:	00 
    27af:	c4 e2 45 90 2c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm5
    27b5:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    27ba:	48 8b 50 70          	mov    0x70(%rax),%rdx
    27be:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    27c2:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    27c7:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    27cc:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
    27d1:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    27d6:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    27db:	c4 a2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm8,4),%ymm6
    27e1:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    27e8:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    27ed:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    27f2:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 285a <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x285a>
    27f9:	00 
    27fa:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    27ff:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2803:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 286b <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x286b>
    280a:	00 
    280b:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2810:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2815:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    281a:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    281e:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2822:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2826:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    282a:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2830:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2834:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    283a:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    283e:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2844:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2848:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    284d:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2851:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2856:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    285c:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2862:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 288b <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x288b>
    2869:	00 00 70 
    286c:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2872:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2877:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    287c:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 28a5 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x28a5>
    2883:	00 00 b0 
    2886:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    288a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    288e:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2893:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2897:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    289c:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    28a0:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    28a6:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    28ab:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    28b1:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    28b6:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    28bb:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    28c2:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    28c7:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    28cc:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    28d0:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    28d4:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    28d9:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    28de:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    28e3:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    28e8:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    28ed:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    28f2:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    28f7:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    28fc:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2901:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2905:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2909:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    290f:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    2913:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    2918:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    291d:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    2922:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2927:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    292c:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2931:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2935:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    293a:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    293f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2944:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    2948:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    294d:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2952:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2957:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    295c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2961:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2966:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    296b:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    296f:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2973:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2978:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    297d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2981:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2985:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    298a:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    298e:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    2993:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    2999:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    299e:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    29a3:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    29a7:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    29ac:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    29b1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    29b5:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    29b9:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    29bf:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    29c6:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    29ca:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    29ce:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    29d4:	44 8b 98 14 01 00 00 	mov    0x114(%rax),%r11d
    29db:	44 8b 88 10 01 00 00 	mov    0x110(%rax),%r9d
    29e2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    29e7:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    29ee:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    29f2:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    29f7:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2a5f <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a5f>
    29fe:	00 
    29ff:	c4 41 79 6e e3       	vmovd  %r11d,%xmm12
    2a04:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    2a09:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
    2a0e:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2a14:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2a19:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2a1e:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2a25:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2a2a:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2a2f:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    2a34:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2a39:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    2a3e:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2a43:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2aab <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2aab>
    2a4a:	00 
    2a4b:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2a4f:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2ab7 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ab7>
    2a56:	00 
    2a57:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2a5c:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2a61:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    2a66:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2a6a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2a6e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2a72:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2a76:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2a7c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2a80:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2a86:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2a8a:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2a90:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2a94:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2a99:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2a9d:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2aa2:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2aa8:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2aae:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2ad7 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ad7>
    2ab5:	00 00 70 
    2ab8:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2abe:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2ac3:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2ac8:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2af1 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2af1>
    2acf:	00 00 b0 
    2ad2:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2ad6:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2ada:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2adf:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2ae3:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2ae8:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2aec:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2af2:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    2af7:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    2afd:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2b02:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2b07:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    2b0e:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    2b13:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2b18:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2b1c:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    2b20:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2b25:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2b2a:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2b2f:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2b34:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2b39:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2b3e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2b43:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2b48:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2b4d:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2b51:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2b55:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2b5b:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    2b5f:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    2b64:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2b69:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    2b6e:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2b73:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2b78:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2b7d:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2b81:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2b86:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2b8b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b90:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    2b94:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2b99:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2b9e:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2ba3:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2ba8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2bad:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2bb2:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2bb7:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2bbb:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2bbf:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2bc4:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2bc9:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2bcd:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2bd1:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2bd6:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2bda:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    2bdf:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    2be5:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2bea:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    2bef:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    2bf3:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2bf8:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    2bfd:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2c01:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2c05:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    2c0b:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2c12:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c16:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2c1a:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2c20:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    2c27:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2c2c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c30:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2c35:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2c3b:	44 8b 98 74 01 00 00 	mov    0x174(%rax),%r11d
    2c42:	44 8b 88 70 01 00 00 	mov    0x170(%rax),%r9d
    2c49:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2c4e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    2c53:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    2c5a:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2cc2 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cc2>
    2c61:	00 
    2c62:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c66:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    2c6b:	c4 41 79 6e e3       	vmovd  %r11d,%xmm12
    2c70:	47 8d 4c 0b 01       	lea    0x1(%r11,%r9,1),%r9d
    2c75:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2c7a:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2c7f:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    2c84:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2c89:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2c8e:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2c93:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2cfb <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cfb>
    2c9a:	00 
    2c9b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2d03 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d03>
    2ca2:	00 
    2ca3:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2ca8:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2cad:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    2cb2:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2cb6:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2cba:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2cbe:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2cc2:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2cc8:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2ccc:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2cd2:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2cd6:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2cdc:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2ce0:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2ce5:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2ce9:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2cee:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2cf4:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2cfa:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2d23 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d23>
    2d01:	00 00 70 
    2d04:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2d0a:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2d0f:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2d14:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2d18:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2d41 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d41>
    2d1f:	00 00 b0 
    2d22:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2d26:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2d2b:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2d2f:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2d34:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2d38:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2d3e:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    2d43:	c4 e2 4d 90 2c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm5
    2d49:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2d4e:	c4 c1 15 db e7       	vpand  %ymm15,%ymm13,%ymm4
    2d53:	c4 c1 55 db cf       	vpand  %ymm15,%ymm5,%ymm1
    2d58:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    2d5d:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
    2d61:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2d65:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    2d6a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2d6f:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2d74:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2d79:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2d7e:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2d83:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2d88:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2d8d:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2d92:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2d96:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    2d9a:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2da0:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    2da4:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    2da9:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2dae:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2db3:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2db8:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2dbd:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2dc2:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2dc6:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2dcb:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2dd0:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    2dd5:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    2dd9:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    2dde:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    2de3:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2de8:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2ded:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2df2:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2df7:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2dfc:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    2e00:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    2e04:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2e09:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2e0e:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2e12:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    2e17:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2e1b:	c4 c1 5d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm4
    2e21:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2e26:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2e2b:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    2e30:	c5 ed fa e4          	vpsubd %ymm4,%ymm2,%ymm4
    2e34:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2e39:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2e3e:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    2e42:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2e46:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2e4a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2e4f:	e9 e2 f3 ff ff       	jmp    2236 <jshc_r_contiguous::avx2_chain_cached(jshc_r_contiguous::View const*, jshc_r_contiguous::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2236>
    2e54:	90                   	nop
    2e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2e5c:	00 00 00 00 

0000000000002e60 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    2e60:	57                   	push   %rdi
    2e61:	56                   	push   %rsi
    2e62:	53                   	push   %rbx
    2e63:	48 81 ec 80 02 00 00 	sub    $0x280,%rsp
    2e6a:	c5 f8 29 b4 24 e0 01 	vmovaps %xmm6,0x1e0(%rsp)
    2e71:	00 00 
    2e73:	c5 f8 29 bc 24 f0 01 	vmovaps %xmm7,0x1f0(%rsp)
    2e7a:	00 00 
    2e7c:	c5 78 29 84 24 00 02 	vmovaps %xmm8,0x200(%rsp)
    2e83:	00 00 
    2e85:	c5 78 29 8c 24 10 02 	vmovaps %xmm9,0x210(%rsp)
    2e8c:	00 00 
    2e8e:	c5 78 29 94 24 20 02 	vmovaps %xmm10,0x220(%rsp)
    2e95:	00 00 
    2e97:	c5 78 29 9c 24 30 02 	vmovaps %xmm11,0x230(%rsp)
    2e9e:	00 00 
    2ea0:	c5 78 29 a4 24 40 02 	vmovaps %xmm12,0x240(%rsp)
    2ea7:	00 00 
    2ea9:	c5 78 29 ac 24 50 02 	vmovaps %xmm13,0x250(%rsp)
    2eb0:	00 00 
    2eb2:	c5 78 29 b4 24 60 02 	vmovaps %xmm14,0x260(%rsp)
    2eb9:	00 00 
    2ebb:	c5 78 29 bc 24 70 02 	vmovaps %xmm15,0x270(%rsp)
    2ec2:	00 00 
    2ec4:	49 89 d3             	mov    %rdx,%r11
    2ec7:	48 83 fa 04          	cmp    $0x4,%rdx
    2ecb:	0f 84 0a 07 00 00    	je     35db <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x77b>
    2ed1:	4d 85 c9             	test   %r9,%r9
    2ed4:	0f 84 8c 06 00 00    	je     3566 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
    2eda:	c5 fd 6f 1d 00 00 00 	vmovdqa 0x0(%rip),%ymm3        # 2ee2 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x82>
    2ee1:	00 
    2ee2:	49 ff c9             	dec    %r9
    2ee5:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
    2ee9:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    2eee:	49 c1 e9 03          	shr    $0x3,%r9
    2ef2:	49 c1 e2 05          	shl    $0x5,%r10
    2ef6:	c4 c1 35 72 d2 18    	vpsrld $0x18,%ymm10,%ymm9
    2efc:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    2f00:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
    2f07:	00 00 
    2f09:	c5 fd 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm3        # 2f51 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf1>
    2f10:	00 
    2f11:	49 01 ca             	add    %rcx,%r10
    2f14:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    2f19:	b8 00 80 00 00       	mov    $0x8000,%eax
    2f1e:	c5 fe 7f 9c 24 c0 01 	vmovdqu %ymm3,0x1c0(%rsp)
    2f25:	00 00 
    2f27:	c5 f9 6e d8          	vmovd  %eax,%xmm3
    2f2b:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2f30:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
    2f35:	0f 1f 00             	nopl   (%rax)
    2f38:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    2f3d:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    2f43:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2f49:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2f4f:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
    2f56:	01 00 00 
    2f59:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    2f5e:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
    2f63:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    2f68:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2f6d:	4d 85 db             	test   %r11,%r11
    2f70:	0f 84 5a 06 00 00    	je     35d0 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x770>
    2f76:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
    2f7d:	00 00 
    2f7f:	48 89 c8             	mov    %rcx,%rax
    2f82:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    2f89:	00 00 
    2f8b:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    2f92:	00 00 
    2f94:	e9 d6 00 00 00       	jmp    306f <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20f>
    2f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2fa0:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    2fa7:	00 00 
    2fa9:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
    2fae:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2fb3:	48 83 c0 60          	add    $0x60,%rax
    2fb7:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    2fbc:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    2fc1:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    2fc6:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    2fcb:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    2fcf:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    2fd3:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    2fd8:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    2fdd:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
    2fe3:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    2fe8:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2fec:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    2ff3:	00 00 
    2ff5:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2ff9:	c5 ed 72 d7 10       	vpsrld $0x10,%ymm7,%ymm2
    2ffe:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    3003:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3008:	c5 9d fa da          	vpsubd %ymm2,%ymm12,%ymm3
    300c:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    3010:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
    3016:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    301b:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    3020:	c5 dd fa 64 24 60    	vpsubd 0x60(%rsp),%ymm4,%ymm4
    3026:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    302b:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    302f:	c5 dd fe a4 24 40 01 	vpaddd 0x140(%rsp),%ymm4,%ymm4
    3036:	00 00 
    3038:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    303c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3041:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
    3045:	4c 39 d0             	cmp    %r10,%rax
    3048:	0f 84 bc 04 00 00    	je     350a <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6aa>
    304e:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    3054:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    305b:	00 00 
    305d:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    3064:	00 00 
    3066:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    306d:	00 00 
    306f:	48 8b 70 08          	mov    0x8(%rax),%rsi
    3073:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
    307a:	00 00 
    307c:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3080:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    3085:	8b 58 54             	mov    0x54(%rax),%ebx
    3088:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    308f:	00 00 
    3091:	c4 e2 5d 90 1c be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm3
    3097:	48 8b 30             	mov    (%rax),%rsi
    309a:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    30a1:	00 00 
    30a3:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    30a7:	c5 79 6e eb          	vmovd  %ebx,%xmm13
    30ab:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    30b0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    30b4:	48 8b 50 48          	mov    0x48(%rax),%rdx
    30b8:	c4 e2 5d 90 04 be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm0
    30be:	8b 70 50             	mov    0x50(%rax),%esi
    30c1:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    30c6:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    30ca:	c5 d5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm5
    30cf:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    30d4:	c4 e2 5d 90 14 b7    	vpgatherdd %ymm4,(%rdi,%ymm6,4),%ymm2
    30da:	c5 79 6e f6          	vmovd  %esi,%xmm14
    30de:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    30e3:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    30e7:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    30ec:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3154 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f4>
    30f3:	00 
    30f4:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 315c <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2fc>
    30fb:	00 
    30fc:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
    3101:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 3169 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x309>
    3108:	00 
    3109:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    310d:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3111:	c4 e2 65 39 e8       	vpminsd %ymm0,%ymm3,%ymm5
    3116:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
    311a:	c4 62 55 39 da       	vpminsd %ymm2,%ymm5,%ymm11
    311f:	c5 d5 66 ea          	vpcmpgtd %ymm2,%ymm5,%ymm5
    3123:	c4 a2 45 90 0c ba    	vpgatherdd %ymm7,(%rdx,%ymm15,4),%ymm1
    3129:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    312e:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    3134:	c4 e2 65 3d e0       	vpmaxsd %ymm0,%ymm3,%ymm4
    3139:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    313f:	c4 62 5d 3d c2       	vpmaxsd %ymm2,%ymm4,%ymm8
    3144:	c5 ed 66 e4          	vpcmpgtd %ymm4,%ymm2,%ymm4
    3148:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    314d:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
    3152:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    3159:	00 00 
    315b:	c5 fe 7f b4 24 60 01 	vmovdqu %ymm6,0x160(%rsp)
    3162:	00 00 
    3164:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    3169:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    316e:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
    3173:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
    3179:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    317f:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
    3184:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    3189:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    318d:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
    3194:	00 00 
    3196:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    319b:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
    31a1:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
    31a7:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    31ac:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    31b0:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    31b7:	00 00 
    31b9:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    31bd:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    31c2:	c4 c1 75 fe ff       	vpaddd %ymm15,%ymm1,%ymm7
    31c7:	c5 fd 66 cb          	vpcmpgtd %ymm3,%ymm0,%ymm1
    31cb:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    31d2:	00 00 
    31d4:	c4 e2 1d 90 34 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm6
    31da:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    31df:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
    31e6:	00 00 
    31e8:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    31ec:	c4 c3 0d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm14,%ymm1
    31f2:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm1,%ymm1        # 321b <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3bb>
    31f9:	00 00 50 
    31fc:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    3200:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
    3205:	c4 e2 1d 90 2c 8a    	vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm5
    320b:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    3210:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
    3217:	00 00 
    3219:	c5 e5 66 e8          	vpcmpgtd %ymm0,%ymm3,%ymm5
    321d:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3221:	c5 b5 db 8c 24 e0 00 	vpand  0xe0(%rsp),%ymm9,%ymm1
    3228:	00 00 
    322a:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    322e:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    3235:	00 00 
    3237:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    323d:	c5 c5 fa f9          	vpsubd %ymm1,%ymm7,%ymm7
    3241:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 326a <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x40a>
    3248:	00 00 40 
    324b:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    3250:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    3254:	c4 e2 1d 90 24 aa    	vpgatherdd %ymm12,(%rdx,%ymm5,4),%ymm4
    325a:	c5 6d fe 24 24       	vpaddd (%rsp),%ymm2,%ymm12
    325f:	c4 c1 5d db e9       	vpand  %ymm9,%ymm4,%ymm5
    3264:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    3268:	c5 d5 fa 6c 24 20    	vpsubd 0x20(%rsp),%ymm5,%ymm5
    326e:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
    3273:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3278:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    327d:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    3281:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3285:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    328a:	c5 f5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm1
    328f:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3294:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    329a:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    329f:	c4 41 4d db e1       	vpand  %ymm9,%ymm6,%ymm12
    32a4:	0f 85 f6 fc ff ff    	jne    2fa0 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
    32aa:	48 8b 58 28          	mov    0x28(%rax),%rbx
    32ae:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    32b5:	00 00 
    32b7:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    32bb:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    32bf:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    32c6:	00 00 
    32c8:	c4 41 7d 6f da       	vmovdqa %ymm10,%ymm11
    32cd:	48 83 c0 60          	add    $0x60,%rax
    32d1:	c4 e2 5d 90 1c 83    	vpgatherdd %ymm4,(%rbx,%ymm0,4),%ymm3
    32d7:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
    32db:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
    32e2:	00 00 
    32e4:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 334c <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ec>
    32eb:	00 
    32ec:	c4 e2 4d 90 24 83    	vpgatherdd %ymm6,(%rbx,%ymm0,4),%ymm4
    32f2:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
    32f6:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    32fa:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3362 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x502>
    3301:	00 
    3302:	c4 e2 4d 90 04 bb    	vpgatherdd %ymm6,(%rbx,%ymm7,4),%ymm0
    3308:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
    330c:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3374 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
    3313:	00 
    3314:	c4 e2 7d 3d fc       	vpmaxsd %ymm4,%ymm0,%ymm7
    3319:	c5 dd 66 e8          	vpcmpgtd %ymm0,%ymm4,%ymm5
    331d:	c4 e2 7d 39 f4       	vpminsd %ymm4,%ymm0,%ymm6
    3322:	c5 e5 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm2
    3326:	c4 62 4d 39 c3       	vpminsd %ymm3,%ymm6,%ymm8
    332b:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    3330:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
    3334:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    333a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 3363 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x503>
    3341:	00 00 20 
    3344:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    3348:	c4 e2 25 90 14 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm2
    334e:	c5 fd 66 ec          	vpcmpgtd %ymm4,%ymm0,%ymm5
    3352:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    3359:	00 00 
    335b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    335f:	c5 fe 7f 94 24 e0 00 	vmovdqu %ymm2,0xe0(%rsp)
    3366:	00 00 
    3368:	c5 7d 7f d2          	vmovdqa %ymm10,%ymm2
    336c:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    3373:	00 00 
    3375:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    337b:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 33a4 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x544>
    3382:	00 00 60 
    3385:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    3389:	c4 e2 6d 90 34 aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm6
    338f:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
    3396:	00 00 
    3398:	c4 c1 45 fe e8       	vpaddd %ymm8,%ymm7,%ymm5
    339d:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    33a2:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    33a6:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    33ab:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    33b0:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    33b4:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    33b9:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    33bd:	c5 cd fa da          	vpsubd %ymm2,%ymm6,%ymm3
    33c1:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
    33c7:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    33cc:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    33d1:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    33d5:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    33da:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    33de:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    33e5:	00 00 
    33e7:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    33eb:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    33f0:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
    33f6:	c4 e2 65 90 04 a3    	vpgatherdd %ymm3,(%rbx,%ymm4,4),%ymm0
    33fc:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    3400:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3468 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x608>
    3407:	00 
    3408:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
    340c:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    3413:	00 00 
    3415:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    341c:	00 00 
    341e:	48 8b 78 d0          	mov    -0x30(%rax),%rdi
    3422:	c4 e2 65 90 24 b3    	vpgatherdd %ymm3,(%rbx,%ymm6,4),%ymm4
    3428:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    342c:	c4 e2 4d 90 1c bf    	vpgatherdd %ymm6,(%rdi,%ymm7,4),%ymm3
    3432:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 349a <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
    3439:	00 
    343a:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 34a2 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x642>
    3441:	00 
    3442:	c4 e2 65 3d f4       	vpmaxsd %ymm4,%ymm3,%ymm6
    3447:	c5 dd 66 eb          	vpcmpgtd %ymm3,%ymm4,%ymm5
    344b:	c4 e2 65 39 fc       	vpminsd %ymm4,%ymm3,%ymm7
    3450:	c5 fd 66 d6          	vpcmpgtd %ymm6,%ymm0,%ymm2
    3454:	c4 62 45 39 c0       	vpminsd %ymm0,%ymm7,%ymm8
    3459:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
    345e:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
    3462:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    3468:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 3491 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x631>
    346f:	00 00 20 
    3472:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    3476:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    347b:	c4 e2 05 90 14 aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm2
    3481:	c5 e5 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm5
    3485:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    348a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    348f:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3493:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    3498:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    349e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 34c7 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x667>
    34a5:	00 00 70 
    34a8:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    34ac:	c4 e2 05 90 3c aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm7
    34b2:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
    34b7:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    34bc:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    34c0:	c4 c1 45 db f9       	vpand  %ymm9,%ymm7,%ymm7
    34c5:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    34c9:	c5 c5 fa da          	vpsubd %ymm2,%ymm7,%ymm3
    34cd:	c5 ed fa 54 24 60    	vpsubd 0x60(%rsp),%ymm2,%ymm2
    34d3:	c5 1d fa e7          	vpsubd %ymm7,%ymm12,%ymm12
    34d7:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    34dc:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    34e1:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    34e6:	c5 ed fe 94 24 40 01 	vpaddd 0x140(%rsp),%ymm2,%ymm2
    34ed:	00 00 
    34ef:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
    34f4:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    34f8:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    34fd:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
    3501:	49 39 c2             	cmp    %rax,%r10
    3504:	0f 85 44 fb ff ff    	jne    304e <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ee>
    350a:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    3510:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    3516:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    351b:	49 83 c0 18          	add    $0x18,%r8
    351f:	c5 ed 72 f3 08       	vpslld $0x8,%ymm3,%ymm2
    3524:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    3528:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    352c:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    3533:	01 00 00 
    3536:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    353a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    3540:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    3545:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    354a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    354e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    3554:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    355a:	4d 39 c1             	cmp    %r8,%r9
    355d:	0f 85 d5 f9 ff ff    	jne    2f38 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
    3563:	c5 f8 77             	vzeroupper
    3566:	c5 f8 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm6
    356d:	00 00 
    356f:	c5 f8 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm7
    3576:	00 00 
    3578:	c5 78 28 84 24 00 02 	vmovaps 0x200(%rsp),%xmm8
    357f:	00 00 
    3581:	c5 78 28 8c 24 10 02 	vmovaps 0x210(%rsp),%xmm9
    3588:	00 00 
    358a:	c5 78 28 94 24 20 02 	vmovaps 0x220(%rsp),%xmm10
    3591:	00 00 
    3593:	c5 78 28 9c 24 30 02 	vmovaps 0x230(%rsp),%xmm11
    359a:	00 00 
    359c:	c5 78 28 a4 24 40 02 	vmovaps 0x240(%rsp),%xmm12
    35a3:	00 00 
    35a5:	c5 78 28 ac 24 50 02 	vmovaps 0x250(%rsp),%xmm13
    35ac:	00 00 
    35ae:	c5 78 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm14
    35b5:	00 00 
    35b7:	c5 78 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm15
    35be:	00 00 
    35c0:	48 81 c4 80 02 00 00 	add    $0x280,%rsp
    35c7:	5b                   	pop    %rbx
    35c8:	5e                   	pop    %rsi
    35c9:	5f                   	pop    %rdi
    35ca:	c3                   	ret
    35cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    35d0:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    35d6:	e9 35 ff ff ff       	jmp    3510 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6b0>
    35db:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    35df:	0f 85 ec f8 ff ff    	jne    2ed1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    35e5:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    35ec:	0f 84 df f8 ff ff    	je     2ed1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    35f2:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    35f9:	0f 84 d2 f8 ff ff    	je     2ed1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    35ff:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    3606:	0f 84 c5 f8 ff ff    	je     2ed1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    360c:	4d 85 c9             	test   %r9,%r9
    360f:	0f 84 51 ff ff ff    	je     3566 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
    3615:	c5 fd 6f 25 00 00 00 	vmovdqa 0x0(%rip),%ymm4        # 361d <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7bd>
    361c:	00 
    361d:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    3621:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    3626:	48 c1 e8 03          	shr    $0x3,%rax
    362a:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
    3630:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    3634:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
    363b:	00 00 
    363d:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # 3685 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x825>
    3644:	00 
    3645:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    364a:	b8 00 80 00 00       	mov    $0x8000,%eax
    364f:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    3656:	00 00 
    3658:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    365c:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3661:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
    3666:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    366b:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    3671:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3675:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    367a:	48 8b 01             	mov    (%rcx),%rax
    367d:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    3681:	49 83 c0 18          	add    $0x18,%r8
    3685:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    368b:	8b 51 50             	mov    0x50(%rcx),%edx
    368e:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    3694:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    3699:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
    36a0:	01 00 00 
    36a3:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    36a7:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    36ac:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
    36b1:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    36b6:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    36bb:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    36c1:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    36c6:	c4 c1 35 db f6       	vpand  %ymm14,%ymm9,%ymm6
    36cb:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    36d0:	c4 e2 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm0
    36d6:	48 8b 41 08          	mov    0x8(%rcx),%rax
    36da:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    36e0:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    36e4:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    36e8:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
    36ee:	48 8b 41 10          	mov    0x10(%rcx),%rax
    36f2:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    36f6:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    36fb:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3763 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x903>
    3702:	00 
    3703:	c4 a2 65 90 24 a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm4
    3709:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    370e:	48 8b 41 48          	mov    0x48(%rcx),%rax
    3712:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 377a <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x91a>
    3719:	00 
    371a:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    371f:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3724:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    3729:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3791 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x931>
    3730:	00 
    3731:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    3736:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    373b:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    373f:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3743:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3747:	c4 62 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm13
    374d:	c5 f9 6e da          	vmovd  %edx,%xmm3
    3751:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    3756:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    375a:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
    3760:	c4 62 3d 3d fc       	vpmaxsd %ymm4,%ymm8,%ymm15
    3765:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    376a:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    3771:	00 00 
    3773:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    3777:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    377c:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    3783:	00 00 
    3785:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    3789:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    378f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # 37b8 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x958>
    3796:	00 00 a0 
    3799:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    379e:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    37a2:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
    37a8:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    37ac:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    37b0:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    37b6:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # 37df <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x97f>
    37bd:	00 00 80 
    37c0:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    37c5:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    37c9:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    37cf:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
    37d5:	c4 c1 05 db ee       	vpand  %ymm14,%ymm15,%ymm5
    37da:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
    37e1:	00 00 
    37e3:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    37e8:	c5 0d db 6c 24 60    	vpand  0x60(%rsp),%ymm14,%ymm13
    37ee:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    37f2:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    37f7:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    37fd:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    3801:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    3805:	c4 c1 3d 72 f5 10    	vpslld $0x10,%ymm13,%ymm8
    380b:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    3810:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    3815:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    381a:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    3821:	00 00 00 
    3824:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    3829:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    382d:	c5 8d db a4 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm4
    3834:	00 00 
    3836:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    383b:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3840:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    3845:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    3849:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    384d:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3853:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3858:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    385f:	00 00 
    3861:	c4 a2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm5
    3867:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    386b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 38d3 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa73>
    3872:	00 
    3873:	c4 62 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm8
    3879:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    387d:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    3882:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 38ea <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa8a>
    3889:	00 
    388a:	c4 e2 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm0
    3890:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 38f8 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa98>
    3897:	00 
    3898:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    389d:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    38a1:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    38a5:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    38aa:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    38af:	c4 62 4d 39 ed       	vpminsd %ymm5,%ymm6,%ymm13
    38b4:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    38b8:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    38be:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    38c5:	00 00 
    38c7:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # 38f0 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa90>
    38ce:	00 00 a0 
    38d1:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    38d6:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    38da:	c4 62 2d 90 2c a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm13
    38e0:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    38e5:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    38ea:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    38ef:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    38f4:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    38fa:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 3923 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xac3>
    3901:	00 00 60 
    3904:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    3908:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    390e:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
    3914:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    3919:	c4 c1 5d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm4
    391f:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    3926:	00 00 
    3928:	c4 41 5d db fe       	vpand  %ymm14,%ymm4,%ymm15
    392d:	c4 c1 5d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm4
    3933:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    393a:	00 00 
    393c:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    3942:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    3947:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
    394c:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    3953:	00 00 
    3955:	c4 41 4d db d6       	vpand  %ymm14,%ymm6,%ymm10
    395a:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    395f:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
    3965:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    3969:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    396d:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    3972:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    3977:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    397c:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3981:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    3985:	c5 8d db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm14,%ymm0
    398c:	00 00 
    398e:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3992:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    3998:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    399d:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    39a4:	00 00 00 
    39a7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    39ab:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    39af:	c4 a2 3d 90 04 a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm0
    39b5:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    39b9:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    39be:	c5 95 72 d5 10       	vpsrld $0x10,%ymm5,%ymm13
    39c3:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3a2b <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbcb>
    39ca:	00 
    39cb:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    39d0:	c4 e2 3d 90 2c b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm5
    39d6:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    39da:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    39e0:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    39e5:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3a4d <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbed>
    39ec:	00 
    39ed:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    39f3:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3a5b <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbfb>
    39fa:	00 
    39fb:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3a00:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    3a04:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    3a09:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    3a0e:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    3a14:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 3a3d <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbdd>
    3a1b:	00 00 90 
    3a1e:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    3a23:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    3a27:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    3a2c:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    3a30:	c4 e2 1d 90 14 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm2
    3a36:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    3a3a:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    3a3e:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    3a44:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3a48:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # 3a71 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc11>
    3a4f:	00 00 90 
    3a52:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    3a57:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    3a5b:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    3a60:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    3a65:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    3a6b:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3a70:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    3a76:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3a7a:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    3a7f:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    3a86:	00 00 
    3a88:	48 8b 41 60          	mov    0x60(%rcx),%rax
    3a8c:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
    3a91:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3a96:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    3a9a:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3a9f:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    3aa4:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    3aa9:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    3aae:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    3ab2:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    3ab9:	00 00 
    3abb:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    3ac0:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    3ac5:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    3ac9:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3ace:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    3ad2:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    3ad6:	c4 e2 4d 90 24 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm4
    3adc:	48 8b 41 68          	mov    0x68(%rcx),%rax
    3ae0:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3ae4:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3ae9:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3aed:	c4 a2 65 90 2c a8    	vpgatherdd %ymm3,(%rax,%ymm13,4),%ymm5
    3af3:	48 8b 41 70          	mov    0x70(%rcx),%rax
    3af7:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    3afe:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3b02:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    3b08:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3b0d:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3b11:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3b16:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3b1b:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    3b22:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    3b26:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3b2b:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3b30:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3b34:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3b39:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3ba1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd41>
    3b40:	00 
    3b41:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3b46:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3b4c:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3b51:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    3b58:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3b5c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3b61:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3b66:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3bce <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd6e>
    3b6d:	00 
    3b6e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3bd6 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd76>
    3b75:	00 
    3b76:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3b7b:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    3b80:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    3b85:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    3b89:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    3b8d:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    3b91:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3b95:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3b99:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3b9e:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    3ba4:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    3ba8:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    3bae:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    3bb4:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    3bb8:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    3bbd:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    3bc1:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    3bc6:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    3bcb:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    3bd1:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 3bfa <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd9a>
    3bd8:	00 00 70 
    3bdb:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    3be0:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    3be4:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3be8:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    3bed:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    3bf2:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    3bf8:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    3bfe:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3c04:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    3c09:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 3c32 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdd2>
    3c10:	00 00 c0 
    3c13:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    3c18:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    3c1d:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    3c21:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    3c25:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    3c2a:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    3c30:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3c35:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3c3a:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    3c41:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3c46:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    3c4b:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    3c4f:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    3c53:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3c58:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3c5d:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    3c62:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3c67:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    3c6c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3c71:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3c75:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    3c7a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3c7e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    3c83:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    3c88:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3c8d:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    3c93:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    3c98:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    3c9d:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    3ca2:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    3ca7:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    3cac:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3cb1:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    3cb5:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3cba:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3cbf:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    3cc4:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    3cc9:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    3cce:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3cd3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3cd8:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3cdd:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3ce2:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    3ce7:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3ceb:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3cf0:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    3cf5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3cfa:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    3cff:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3d04:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    3d09:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    3d0d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    3d11:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    3d15:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3d1a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    3d1f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3d24:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    3d29:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3d2d:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    3d31:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d35:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3d39:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3d3f:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    3d46:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d4a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3d4e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3d53:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    3d59:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    3d60:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d64:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3d69:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3d6f:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    3d75:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3d7a:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    3d81:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3d86:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3d8b:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d8f:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3d93:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3d98:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3e00 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfa0>
    3d9f:	00 
    3da0:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    3da7:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3dac:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3e14 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb4>
    3db3:	00 
    3db4:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3e1c <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfbc>
    3dbb:	00 
    3dbc:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3dc1:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3dc6:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    3dcb:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    3dd0:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    3dd4:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    3dd8:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    3ddc:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3de0:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    3de6:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3dea:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3def:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    3df5:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    3df9:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    3dff:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    3e05:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    3e09:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    3e0e:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    3e12:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    3e17:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    3e1c:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    3e22:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 3e4b <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfeb>
    3e29:	00 00 70 
    3e2c:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    3e31:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    3e35:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3e39:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    3e3e:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    3e43:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    3e49:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    3e4f:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3e55:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    3e5a:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 3e83 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1023>
    3e61:	00 00 c0 
    3e64:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    3e69:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    3e6e:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    3e72:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    3e76:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    3e7b:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    3e81:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3e86:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3e8b:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    3e92:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3e97:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    3e9c:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    3ea0:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    3ea4:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3ea9:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3eae:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    3eb3:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3eb8:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    3ebd:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3ec2:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3ec6:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    3ecb:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3ecf:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    3ed4:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    3ed9:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3ede:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    3ee4:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    3ee9:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    3eee:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    3ef3:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    3ef8:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    3efd:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3f02:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    3f06:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3f0b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3f10:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    3f15:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    3f1a:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    3f1f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3f24:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3f29:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3f2e:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3f33:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3f37:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3f3c:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    3f41:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3f46:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3f4a:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3f4f:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    3f54:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3f59:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    3f5e:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3f63:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    3f68:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    3f6c:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    3f70:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    3f74:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3f79:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    3f7e:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3f83:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    3f88:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3f8c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    3f90:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3f94:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3f98:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3f9e:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    3fa5:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3fa9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3fad:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3fb2:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    3fb8:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    3fbf:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3fc3:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3fc8:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 4030 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d0>
    3fcf:	00 
    3fd0:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3fd6:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3fdb:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 4043 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11e3>
    3fe2:	00 
    3fe3:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3fe8:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3fed:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3ff1:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3ff6:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 405e <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11fe>
    3ffd:	00 
    3ffe:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    4005:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    400a:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    400f:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    4013:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    4018:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    401c:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    4020:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4024:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    4028:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    402d:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    4033:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    4037:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    403d:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    4043:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    4047:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    404c:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    4050:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4055:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    405b:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 4084 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1224>
    4062:	00 00 70 
    4065:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    406a:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    406e:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4072:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    4077:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    407c:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    4081:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    4087:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    408d:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    4093:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    4098:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 40c1 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1261>
    409f:	00 00 c0 
    40a2:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    40a7:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    40ac:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    40b0:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    40b4:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
    40b9:	c4 e2 5d 90 2c 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm5
    40bf:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    40c4:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    40c9:	c4 c1 55 db d6       	vpand  %ymm14,%ymm5,%ymm2
    40ce:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    40d3:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    40d7:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    40db:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    40e0:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    40e5:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    40ea:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    40ef:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    40f4:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    40f9:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    40fd:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    4102:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    4106:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    410b:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    4110:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    4115:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    411b:	c5 8d db f6          	vpand  %ymm6,%ymm14,%ymm6
    411f:	c5 8d db d2          	vpand  %ymm2,%ymm14,%ymm2
    4123:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    4128:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    412d:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    4132:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4137:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    413b:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    4140:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4145:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    414a:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    414f:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    4154:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    4159:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    415e:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    4163:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    4167:	c4 c1 75 db f6       	vpand  %ymm14,%ymm1,%ymm6
    416c:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4171:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4176:	c4 c1 65 db ee       	vpand  %ymm14,%ymm3,%ymm5
    417b:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    4180:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    4185:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    4189:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    418d:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    4191:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    4196:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    419b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    41a0:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    41a5:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    41aa:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    41ae:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    41b2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    41b6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    41bb:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    41c0:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    41c4:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    41c8:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    41cf:	01 00 00 
    41d2:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    41d6:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    41dc:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    41e1:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    41e6:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    41ea:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    41f0:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    41f6:	4d 39 c2             	cmp    %r8,%r10
    41f9:	0f 85 67 f4 ff ff    	jne    3666 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x806>
    41ff:	e9 5f f3 ff ff       	jmp    3563 <jshc_r_contiguous::avx2_chain(jshc_r_contiguous::View const*, unsigned long long, unsigned char*, unsigned long long)+0x703>
    4204:	90                   	nop
    4205:	90                   	nop
    4206:	90                   	nop
    4207:	90                   	nop
    4208:	90                   	nop
    4209:	90                   	nop
    420a:	90                   	nop
    420b:	90                   	nop
    420c:	90                   	nop
    420d:	90                   	nop
    420e:	90                   	nop
    420f:	90                   	nop
