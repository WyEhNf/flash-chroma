
artifacts\skylake-compact-cache-build-v1\CMakeFiles\jshc_skylake_compact_cache.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
       0:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
       7:	c5 f8 29 b4 24 80 01 	vmovaps %xmm6,0x180(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 90 01 	vmovaps %xmm7,0x190(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 a0 01 	vmovaps %xmm8,0x1a0(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 b0 01 	vmovaps %xmm9,0x1b0(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 c0 01 	vmovaps %xmm10,0x1c0(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 d0 01 	vmovaps %xmm11,0x1d0(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 e0 01 	vmovaps %xmm12,0x1e0(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 f0 01 	vmovaps %xmm13,0x1f0(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 00 02 	vmovaps %xmm14,0x200(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 10 02 	vmovaps %xmm15,0x210(%rsp)
      5f:	00 00 
      61:	48 89 c8             	mov    %rcx,%rax
      64:	49 89 d2             	mov    %rdx,%r10
      67:	4d 85 c9             	test   %r9,%r9
      6a:	0f 84 2b 0b 00 00    	je     b9b <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb9b>
      70:	c4 c2 7d 58 42 28    	vpbroadcastd 0x28(%r10),%ymm0
      76:	49 ff c9             	dec    %r9
      79:	8b 52 24             	mov    0x24(%rdx),%edx
      7c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      81:	49 c1 e9 03          	shr    $0x3,%r9
      85:	41 8b 4a 20          	mov    0x20(%r10),%ecx
      89:	c5 fe 7f 84 24 00 01 	vmovdqu %ymm0,0x100(%rsp)
      90:	00 00 
      92:	c4 c2 7d 58 42 2c    	vpbroadcastd 0x2c(%r10),%ymm0
      98:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
      9c:	0f af ca             	imul   %edx,%ecx
      9f:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
      a4:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
      aa:	c5 fe 7f 84 24 20 01 	vmovdqu %ymm0,0x120(%rsp)
      b1:	00 00 
      b3:	c4 c2 7d 58 42 08    	vpbroadcastd 0x8(%r10),%ymm0
      b9:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
      be:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      c3:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
      c9:	c4 c2 7d 58 42 0c    	vpbroadcastd 0xc(%r10),%ymm0
      cf:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
      d4:	c5 f9 6e fa          	vmovd  %edx,%xmm7
      d8:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
      de:	c4 c2 7d 58 42 10    	vpbroadcastd 0x10(%r10),%ymm0
      e4:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      e9:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
      f0:	00 00 
      f2:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
      f6:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
      fd:	00 00 
      ff:	c4 c2 7d 58 42 14    	vpbroadcastd 0x14(%r10),%ymm0
     105:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     10a:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
     111:	00 00 
     113:	c5 fe 7f 84 24 a0 00 	vmovdqu %ymm0,0xa0(%rsp)
     11a:	00 00 
     11c:	c4 c2 7d 58 42 18    	vpbroadcastd 0x18(%r10),%ymm0
     122:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     129:	00 00 
     12b:	c4 c2 7d 58 42 1c    	vpbroadcastd 0x1c(%r10),%ymm0
     131:	c5 fe 7f 84 24 e0 00 	vmovdqu %ymm0,0xe0(%rsp)
     138:	00 00 
     13a:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
     140:	e9 d6 00 00 00       	jmp    21b <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21b>
     145:	0f 1f 00             	nopl   (%rax)
     148:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
     14d:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     152:	49 8b 12             	mov    (%r10),%rdx
     155:	c4 e2 45 40 bc 24 60 	vpmulld 0x160(%rsp),%ymm7,%ymm7
     15c:	01 00 00 
     15f:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     164:	c4 e2 65 40 9c 24 40 	vpmulld 0x140(%rsp),%ymm3,%ymm3
     16b:	01 00 00 
     16e:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     172:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     176:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     17a:	c5 e5 72 d2 01       	vpsrld $0x1,%ymm2,%ymm3
     17f:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 1a7 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a7>
     186:	00 
     187:	c4 e2 45 90 0c 9a    	vpgatherdd %ymm7,(%rdx,%ymm3,4),%ymm1
     18d:	c5 ed 72 f2 04       	vpslld $0x4,%ymm2,%ymm2
     192:	c4 e2 75 45 ca       	vpsrlvd %ymm2,%ymm1,%ymm1
     197:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     19b:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     1a0:	c5 f5 72 d1 0c       	vpsrld $0xc,%ymm1,%ymm1
     1a5:	c5 ed db 15 a0 00 00 	vpand  0xa0(%rip),%ymm2,%ymm2        # 24d <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24d>
     1ac:	00 
     1ad:	c5 f5 db 0d a0 00 00 	vpand  0xa0(%rip),%ymm1,%ymm1        # 255 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x255>
     1b4:	00 
     1b5:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
     1b9:	c5 dd fe c9          	vpaddd %ymm1,%ymm4,%ymm1
     1bd:	c5 ed fe 94 24 00 01 	vpaddd 0x100(%rsp),%ymm2,%ymm2
     1c4:	00 00 
     1c6:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
     1cd:	00 00 
     1cf:	c5 e5 72 f1 10       	vpslld $0x10,%ymm1,%ymm3
     1d4:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
     1d9:	49 83 c0 18          	add    $0x18,%r8
     1dd:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
     1e1:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     1e5:	c4 e2 75 00 0d 40 00 	vpshufb 0x40(%rip),%ymm1,%ymm1        # 22e <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x22e>
     1ec:	00 00 
     1ee:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
     1f2:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     1f8:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     1fd:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     202:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     206:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
     20c:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     212:	4d 39 d8             	cmp    %r11,%r8
     215:	0f 84 7d 09 00 00    	je     b98 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb98>
     21b:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     220:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
     226:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     22a:	48 8b 10             	mov    (%rax),%rdx
     22d:	44 8b 48 54          	mov    0x54(%rax),%r9d
     231:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
     237:	8b 48 50             	mov    0x50(%rax),%ecx
     23a:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
     240:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     245:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # 24e <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24e>
     24c:	00 00 
     24e:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     252:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     257:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
     25c:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
     261:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     265:	c4 e2 45 90 24 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm4
     26b:	48 8b 50 08          	mov    0x8(%rax),%rdx
     26f:	c5 e5 db c8          	vpand  %ymm0,%ymm3,%ymm1
     273:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     277:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     27c:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     281:	c4 e2 65 90 34 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm6
     287:	48 8b 50 10          	mov    0x10(%rax),%rdx
     28b:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     28f:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     293:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     298:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     29d:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 325 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x325>
     2a4:	00 
     2a5:	c4 e2 65 90 3c 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm7
     2ab:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     2b0:	48 8b 50 48          	mov    0x48(%rax),%rdx
     2b4:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 33c <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33c>
     2bb:	00 
     2bc:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     2c1:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     2c6:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     2cb:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 353 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x353>
     2d2:	00 
     2d3:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     2d8:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     2dd:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     2e2:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     2e7:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     2eb:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     2ef:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     2f3:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
     2f7:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     2fd:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     301:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     307:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     30b:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
     311:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     315:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     31a:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     31e:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     322:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     326:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     32c:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 355 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x355>
     333:	00 00 80 
     336:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     33b:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     341:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     346:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     34b:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     351:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 37a <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x37a>
     358:	00 00 c0 
     35b:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     35f:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     364:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     369:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     36d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     371:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     377:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
     37d:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     381:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
     385:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
     389:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     38e:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     392:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     396:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     39b:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     3a0:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     3a5:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     3aa:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     3af:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     3b4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     3b9:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     3bd:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     3c1:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     3c5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     3c9:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     3cf:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     3d3:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     3d8:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     3dc:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
     3e1:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     3e6:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     3ea:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     3ee:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     3f2:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     3f7:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     3fc:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     401:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
     405:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     40a:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     40f:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     413:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     418:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     41d:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     421:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     426:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     42a:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     42e:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     433:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     438:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     43c:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     441:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     445:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
     44b:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     452:	00 00 
     454:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
     45b:	00 00 
     45d:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     461:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     466:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     46b:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     46f:	c5 d5 fa da          	vpsubd %ymm2,%ymm5,%ymm3
     473:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     478:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     47d:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
     483:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     487:	c5 35 66 c2          	vpcmpgtd %ymm2,%ymm9,%ymm8
     48b:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     48f:	c5 8d 66 f3          	vpcmpgtd %ymm3,%ymm14,%ymm6
     493:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     497:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     49c:	c5 f5 fa fa          	vpsubd %ymm2,%ymm1,%ymm7
     4a0:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
     4a4:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
     4a8:	c5 c5 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm7,%ymm6
     4af:	00 00 
     4b1:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
     4b5:	c5 ed 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm6
     4bb:	c5 bd eb f6          	vpor   %ymm6,%ymm8,%ymm6
     4bf:	c5 65 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm8
     4c6:	00 00 
     4c8:	c4 c1 4d eb f0       	vpor   %ymm8,%ymm6,%ymm6
     4cd:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
     4d1:	c5 fd d7 d4          	vpmovmskb %ymm4,%edx
     4d5:	85 d2                	test   %edx,%edx
     4d7:	0f 84 6b fc ff ff    	je     148 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x148>
     4dd:	48 8b 50 60          	mov    0x60(%rax),%rdx
     4e1:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     4e5:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
     4ec:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
     4f2:	c4 e2 65 90 24 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm4
     4f8:	48 8b 50 68          	mov    0x68(%rax),%rdx
     4fc:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     500:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     505:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     50a:	c4 e2 65 90 34 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm6
     510:	48 8b 50 70          	mov    0x70(%rax),%rdx
     514:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     518:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     51c:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     521:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     526:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     52b:	c4 e2 65 90 3c 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm7
     531:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     536:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     53a:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     541:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     546:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     54b:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     550:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     555:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 5dd <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5dd>
     55c:	00 
     55d:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 5e5 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5e5>
     564:	00 
     565:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 5ed <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ed>
     56c:	00 
     56d:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     572:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     577:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     57b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     57f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     583:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     587:	c5 2d fe ca          	vpaddd %ymm2,%ymm10,%ymm9
     58b:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     591:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     595:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
     59b:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     59f:	c4 a2 65 90 0c 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm1
     5a5:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     5a9:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     5ae:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     5b3:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     5b7:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     5bc:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     5c0:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     5c6:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 5ef <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ef>
     5cd:	00 00 80 
     5d0:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     5d5:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     5db:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     5e0:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     5e5:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     5eb:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 614 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x614>
     5f2:	00 00 c0 
     5f5:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     5f9:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     5fe:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     603:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     607:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     60b:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     611:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     617:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     61b:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     61f:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
     626:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     62a:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     62f:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     633:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     637:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     63c:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     641:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     646:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     64b:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     650:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     655:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     65a:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     65e:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     662:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     666:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     66a:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     670:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     674:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     679:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     67d:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     682:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     687:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     68b:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     68f:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     693:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     698:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     69d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6a2:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     6a6:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     6ab:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     6b0:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     6b4:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     6b9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     6be:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     6c2:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     6c7:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     6cb:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     6cf:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     6d4:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     6d9:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     6dd:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     6e2:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     6e6:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     6eb:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     6f1:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     6f5:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     6fa:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     6fe:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     702:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     707:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     70c:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     710:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     714:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
     71a:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
     721:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     725:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     729:	c4 e2 65 90 34 ba    	vpgatherdd %ymm3,(%rdx,%ymm7,4),%ymm6
     72f:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
     736:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
     73c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     741:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
     748:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     74c:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     751:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 7d9 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7d9>
     758:	00 
     759:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     75e:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     762:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     767:	c4 e2 65 90 3c 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm7
     76d:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     772:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     777:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
     77e:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     783:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     788:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     78c:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     791:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     796:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     79b:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 823 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x823>
     7a2:	00 
     7a3:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 82b <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x82b>
     7aa:	00 
     7ab:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     7b0:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     7b5:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     7ba:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     7be:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     7c2:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7c6:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     7ca:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     7d0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7d4:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     7da:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     7de:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     7e4:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     7e8:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     7ed:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     7f1:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     7f6:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     7fa:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     7fe:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     804:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 82d <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x82d>
     80b:	00 00 80 
     80e:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     813:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     819:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     81e:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     823:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     829:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 852 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x852>
     830:	00 00 c0 
     833:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     837:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     83c:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     841:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     845:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     849:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     84f:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     855:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     859:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     85d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
     864:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     868:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     86d:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     871:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     875:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     87a:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     87f:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     884:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     889:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     88e:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     893:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     898:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     89c:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     8a0:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     8a4:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     8a8:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     8ae:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     8b2:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     8b7:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     8bb:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     8c0:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     8c5:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     8c9:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     8cd:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     8d1:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     8d6:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     8db:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8e0:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     8e4:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     8e9:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     8ee:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     8f2:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     8f7:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     8fc:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     900:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     905:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     909:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     90d:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     912:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     917:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     91b:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     920:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     924:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     929:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     92f:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     933:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     938:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     93c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     940:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     945:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     94a:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     94e:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     952:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
     958:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
     95f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     963:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     967:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     96b:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
     971:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
     978:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     97d:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     982:	c4 e2 65 90 3c 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm7
     988:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
     98f:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
     995:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     99a:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     99f:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
     9a6:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # a2e <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa2e>
     9ad:	00 
     9ae:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     9b2:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     9b7:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     9bc:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     9c1:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     9c6:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     9ca:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     9cf:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     9d4:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     9d9:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # a61 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa61>
     9e0:	00 
     9e1:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # a69 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa69>
     9e8:	00 
     9e9:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     9ee:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     9f3:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     9f8:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     9fd:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     a01:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a05:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a09:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
     a0d:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     a13:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a17:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     a1d:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     a21:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
     a27:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     a2b:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     a30:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     a34:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     a38:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     a3e:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # a67 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa67>
     a45:	00 00 80 
     a48:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     a4d:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     a53:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     a58:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     a5d:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     a63:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # a8c <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa8c>
     a6a:	00 00 c0 
     a6d:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a71:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     a76:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     a7b:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     a7f:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     a83:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a87:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     a8d:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     a93:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     a97:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
     a9b:	c5 cd db d0          	vpand  %ymm0,%ymm6,%ymm2
     a9f:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     aa4:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     aa8:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     aac:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     ab1:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     ab6:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     abb:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     ac0:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     ac5:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     aca:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     acf:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     ad3:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     ad7:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     adb:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     adf:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     ae5:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
     ae9:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
     aee:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     af2:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     af7:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     afc:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     b00:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     b04:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     b08:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     b0d:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     b12:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     b17:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     b1b:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     b20:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     b25:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     b29:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     b2e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b33:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     b37:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     b3c:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     b40:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
     b44:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     b49:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     b4e:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     b52:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     b57:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     b5b:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
     b61:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     b65:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b6a:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     b6f:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     b73:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     b78:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     b7d:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     b81:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     b85:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     b89:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b8e:	e9 3c f6 ff ff       	jmp    1cf <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cf>
     b93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     b98:	c5 f8 77             	vzeroupper
     b9b:	c5 f8 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm6
     ba2:	00 00 
     ba4:	c5 f8 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm7
     bab:	00 00 
     bad:	c5 78 28 84 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm8
     bb4:	00 00 
     bb6:	c5 78 28 8c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm9
     bbd:	00 00 
     bbf:	c5 78 28 94 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm10
     bc6:	00 00 
     bc8:	c5 78 28 9c 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm11
     bcf:	00 00 
     bd1:	c5 78 28 a4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm12
     bd8:	00 00 
     bda:	c5 78 28 ac 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm13
     be1:	00 00 
     be3:	c5 78 28 b4 24 00 02 	vmovaps 0x200(%rsp),%xmm14
     bea:	00 00 
     bec:	c5 78 28 bc 24 10 02 	vmovaps 0x210(%rsp),%xmm15
     bf3:	00 00 
     bf5:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
     bfc:	c3                   	ret
     bfd:	0f 1f 00             	nopl   (%rax)

0000000000000c00 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     c00:	56                   	push   %rsi
     c01:	53                   	push   %rbx
     c02:	48 81 ec 28 03 00 00 	sub    $0x328,%rsp
     c09:	c5 f8 29 b4 24 80 02 	vmovaps %xmm6,0x280(%rsp)
     c10:	00 00 
     c12:	c5 f8 29 bc 24 90 02 	vmovaps %xmm7,0x290(%rsp)
     c19:	00 00 
     c1b:	c5 78 29 84 24 a0 02 	vmovaps %xmm8,0x2a0(%rsp)
     c22:	00 00 
     c24:	c5 78 29 8c 24 b0 02 	vmovaps %xmm9,0x2b0(%rsp)
     c2b:	00 00 
     c2d:	c5 78 29 94 24 c0 02 	vmovaps %xmm10,0x2c0(%rsp)
     c34:	00 00 
     c36:	c5 78 29 9c 24 d0 02 	vmovaps %xmm11,0x2d0(%rsp)
     c3d:	00 00 
     c3f:	c5 78 29 a4 24 e0 02 	vmovaps %xmm12,0x2e0(%rsp)
     c46:	00 00 
     c48:	c5 78 29 ac 24 f0 02 	vmovaps %xmm13,0x2f0(%rsp)
     c4f:	00 00 
     c51:	c5 78 29 b4 24 00 03 	vmovaps %xmm14,0x300(%rsp)
     c58:	00 00 
     c5a:	c5 78 29 bc 24 10 03 	vmovaps %xmm15,0x310(%rsp)
     c61:	00 00 
     c63:	49 89 d2             	mov    %rdx,%r10
     c66:	4d 85 c9             	test   %r9,%r9
     c69:	0f 84 f4 09 00 00    	je     1663 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa63>
     c6f:	c4 c2 7d 58 62 28    	vpbroadcastd 0x28(%r10),%ymm4
     c75:	c4 c2 7d 58 7a 0c    	vpbroadcastd 0xc(%r10),%ymm7
     c7b:	49 ff c9             	dec    %r9
     c7e:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     c83:	8b 42 24             	mov    0x24(%rdx),%eax
     c86:	49 c1 e9 03          	shr    $0x3,%r9
     c8a:	8b 52 20             	mov    0x20(%rdx),%edx
     c8d:	c4 c1 35 72 d3 18    	vpsrld $0x18,%ymm11,%ymm9
     c93:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
     c9a:	00 00 
     c9c:	c4 c2 7d 58 62 2c    	vpbroadcastd 0x2c(%r10),%ymm4
     ca2:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
     ca6:	48 8d 99 80 01 00 00 	lea    0x180(%rcx),%rbx
     cad:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
     cb4:	00 00 
     cb6:	c4 c2 7d 58 7a 14    	vpbroadcastd 0x14(%r10),%ymm7
     cbc:	0f af d0             	imul   %eax,%edx
     cbf:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
     cc4:	c5 fe 7f a4 24 00 02 	vmovdqu %ymm4,0x200(%rsp)
     ccb:	00 00 
     ccd:	c4 c2 7d 58 62 08    	vpbroadcastd 0x8(%r10),%ymm4
     cd3:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
     cd9:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
     ce0:	00 00 
     ce2:	c4 c2 7d 58 7a 1c    	vpbroadcastd 0x1c(%r10),%ymm7
     ce8:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
     cef:	00 00 
     cf1:	c4 c2 7d 58 62 10    	vpbroadcastd 0x10(%r10),%ymm4
     cf7:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
     cfe:	00 00 
     d00:	c5 f9 6e f8          	vmovd  %eax,%xmm7
     d04:	c5 fe 7f a4 24 60 01 	vmovdqu %ymm4,0x160(%rsp)
     d0b:	00 00 
     d0d:	c4 c2 7d 58 62 18    	vpbroadcastd 0x18(%r10),%ymm4
     d13:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     d18:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
     d1f:	00 00 
     d21:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
     d28:	00 00 
     d2a:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
     d2f:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     d34:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     d3b:	00 00 
     d3d:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     d41:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     d46:	c5 fe 7f a4 24 40 02 	vmovdqu %ymm4,0x240(%rsp)
     d4d:	00 00 
     d4f:	e9 d8 00 00 00       	jmp    e2c <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x22c>
     d54:	0f 1f 40 00          	nopl   0x0(%rax)
     d58:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
     d5d:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
     d62:	49 8b 02             	mov    (%r10),%rax
     d65:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     d69:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
     d6e:	c4 e2 6d 40 94 24 20 	vpmulld 0x220(%rsp),%ymm2,%ymm2
     d75:	02 00 00 
     d78:	c4 e2 55 40 ac 24 40 	vpmulld 0x240(%rsp),%ymm5,%ymm5
     d7f:	02 00 00 
     d82:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     d86:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
     d8a:	c5 fd 72 d1 01       	vpsrld $0x1,%ymm1,%ymm0
     d8f:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # db7 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b7>
     d96:	00 
     d97:	c4 e2 5d 90 14 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm2
     d9d:	c5 f5 72 f1 04       	vpslld $0x4,%ymm1,%ymm1
     da2:	c4 e2 6d 45 d1       	vpsrlvd %ymm1,%ymm2,%ymm2
     da7:	c4 c1 6d db c9       	vpand  %ymm9,%ymm2,%ymm1
     dac:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
     db1:	c5 ed 72 d2 0c       	vpsrld $0xc,%ymm2,%ymm2
     db6:	c5 fd db 05 a0 00 00 	vpand  0xa0(%rip),%ymm0,%ymm0        # e5e <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25e>
     dbd:	00 
     dbe:	c5 ed db 15 a0 00 00 	vpand  0xa0(%rip),%ymm2,%ymm2        # e66 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x266>
     dc5:	00 
     dc6:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     dca:	c5 f5 fe d2          	vpaddd %ymm2,%ymm1,%ymm2
     dce:	c5 fd fe b4 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm6
     dd5:	00 00 
     dd7:	c5 ed fe 94 24 00 02 	vpaddd 0x200(%rsp),%ymm2,%ymm2
     dde:	00 00 
     de0:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     de5:	c5 fd 72 f6 08       	vpslld $0x8,%ymm6,%ymm0
     dea:	49 83 c0 18          	add    $0x18,%r8
     dee:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     df2:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     df6:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # e3f <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23f>
     dfd:	00 00 
     dff:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     e03:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     e09:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     e0e:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     e13:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     e17:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     e1d:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     e23:	4d 39 c3             	cmp    %r8,%r11
     e26:	0f 84 34 08 00 00    	je     1660 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa60>
     e2c:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     e31:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     e37:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     e3b:	48 8b 01             	mov    (%rcx),%rax
     e3e:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     e42:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     e48:	8b 51 50             	mov    0x50(%rcx),%edx
     e4b:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     e51:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
     e56:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # e5f <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25f>
     e5d:	00 00 
     e5f:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     e63:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     e68:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     e6d:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     e72:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
     e77:	c4 e2 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm3
     e7d:	48 8b 41 08          	mov    0x8(%rcx),%rax
     e81:	c4 c1 6d db c1       	vpand  %ymm9,%ymm2,%ymm0
     e86:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     e8a:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     e8f:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     e94:	c4 e2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm5
     e9a:	48 8b 41 10          	mov    0x10(%rcx),%rax
     e9e:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     ea2:	c5 79 6e d2          	vmovd  %edx,%xmm10
     ea6:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     eab:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     eb0:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # f38 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x338>
     eb7:	00 
     eb8:	c4 e2 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm6
     ebe:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     ec3:	48 8b 41 48          	mov    0x48(%rcx),%rax
     ec7:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # f4f <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x34f>
     ece:	00 
     ecf:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     ed4:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
     ed9:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     edd:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     ee2:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # f6a <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36a>
     ee9:	00 
     eea:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     eef:	c4 62 65 39 ed       	vpminsd %ymm5,%ymm3,%ymm13
     ef4:	c4 62 15 39 e6       	vpminsd %ymm6,%ymm13,%ymm12
     ef9:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
     efd:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     f01:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     f05:	c5 ad fe d1          	vpaddd %ymm1,%ymm10,%ymm2
     f09:	c4 62 45 90 3c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm15
     f0f:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     f13:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     f18:	c5 65 fe d5          	vpaddd %ymm5,%ymm3,%ymm10
     f1c:	c4 e2 45 90 04 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm0
     f22:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     f26:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     f2b:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     f2f:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     f34:	c4 c1 05 db e9       	vpand  %ymm9,%ymm15,%ymm5
     f39:	c4 c3 5d 4c d6 20    	vpblendvb %ymm2,%ymm14,%ymm4,%ymm2
     f3f:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # f68 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x368>
     f46:	00 00 70 
     f49:	c4 c1 3d fe fc       	vpaddd %ymm12,%ymm8,%ymm7
     f4e:	c4 c3 5d 4c e6 30    	vpblendvb %ymm3,%ymm14,%ymm4,%ymm4
     f54:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     f5b:	00 00 
     f5d:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     f61:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     f66:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm4,%ymm4        # f8f <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x38f>
     f6d:	00 00 d0 
     f70:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     f74:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     f79:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
     f7e:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     f82:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     f86:	c4 e2 2d 90 14 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm2
     f8c:	c4 e2 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm3
     f92:	c4 41 6d db d1       	vpand  %ymm9,%ymm2,%ymm10
     f97:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
     f9c:	c4 c1 65 db e1       	vpand  %ymm9,%ymm3,%ymm4
     fa1:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     fa6:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     faa:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     fae:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     fb3:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     fb8:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     fbd:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     fc2:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
     fc7:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
     fcc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     fd1:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
     fd6:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     fdb:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     fdf:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     fe3:	c4 c1 4d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm6
     fe9:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     fed:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     ff2:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
     ff7:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
     ffc:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    1001:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    1006:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    100b:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    100f:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    1014:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1019:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    101e:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    1022:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    1027:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    102c:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    1031:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    1036:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    103b:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    1040:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1045:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1049:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    104d:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1052:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    1057:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    105b:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    1060:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1064:	c4 c1 55 72 d7 10    	vpsrld $0x10,%ymm15,%ymm5
    106a:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    106f:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1074:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    1079:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    107d:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
    1081:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1086:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    108b:	c5 7e 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm8
    1092:	00 00 
    1094:	c5 7e 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm15
    109b:	00 00 
    109d:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    10a1:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    10a8:	00 00 
    10aa:	c5 bd 66 f2          	vpcmpgtd %ymm2,%ymm8,%ymm6
    10ae:	c5 95 66 f9          	vpcmpgtd %ymm1,%ymm13,%ymm7
    10b2:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    10b6:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    10ba:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    10bf:	c5 fd fa e9          	vpsubd %ymm1,%ymm0,%ymm5
    10c3:	c5 85 66 dd          	vpcmpgtd %ymm5,%ymm15,%ymm3
    10c7:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    10cb:	c5 d5 66 b4 24 c0 01 	vpcmpgtd 0x1c0(%rsp),%ymm5,%ymm6
    10d2:	00 00 
    10d4:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    10d8:	c5 f5 66 b4 24 40 01 	vpcmpgtd 0x140(%rsp),%ymm1,%ymm6
    10df:	00 00 
    10e1:	c5 c5 eb f6          	vpor   %ymm6,%ymm7,%ymm6
    10e5:	c5 ed 66 bc 24 80 01 	vpcmpgtd 0x180(%rsp),%ymm2,%ymm7
    10ec:	00 00 
    10ee:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    10f2:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    10f6:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    10fa:	85 c0                	test   %eax,%eax
    10fc:	0f 84 56 fc ff ff    	je     d58 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x158>
    1102:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
    1108:	48 8d 41 60          	lea    0x60(%rcx),%rax
    110c:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    1112:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1118:	48 8b 10             	mov    (%rax),%rdx
    111b:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    1121:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1125:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    112b:	8b 70 54             	mov    0x54(%rax),%esi
    112e:	c4 e2 5d 90 04 ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm0
    1134:	48 8b 50 08          	mov    0x8(%rax),%rdx
    1138:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    113e:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1142:	44 8b 48 50          	mov    0x50(%rax),%r9d
    1146:	c4 e2 5d 90 2c ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm5
    114c:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1150:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1154:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    1159:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    115e:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    1163:	c4 e2 5d 90 3c 9a    	vpgatherdd %ymm4,(%rdx,%ymm3,4),%ymm7
    1169:	c5 f9 6e e6          	vmovd  %esi,%xmm4
    116d:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1172:	48 8b 50 48          	mov    0x48(%rax),%rdx
    1176:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    117b:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    1180:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1208 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x608>
    1187:	00 
    1188:	c4 e2 65 40 da       	vpmulld %ymm2,%ymm3,%ymm3
    118d:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    1192:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 121a <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x61a>
    1199:	00 
    119a:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    119f:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 1227 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x627>
    11a6:	00 
    11a7:	c5 55 66 e0          	vpcmpgtd %ymm0,%ymm5,%ymm12
    11ab:	c4 62 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm14
    11b0:	c4 62 0d 39 d7       	vpminsd %ymm7,%ymm14,%ymm10
    11b5:	c5 0d 66 f7          	vpcmpgtd %ymm7,%ymm14,%ymm14
    11b9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    11bd:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    11c1:	c4 63 6d 4c e4 c0    	vpblendvb %ymm12,%ymm4,%ymm2,%ymm12
    11c7:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    11cb:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    11d0:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    11d5:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    11dc:	00 00 
    11de:	c4 c1 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm6
    11e3:	c4 22 65 90 2c ba    	vpgatherdd %ymm3,(%rdx,%ymm15,4),%ymm13
    11e9:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    11ed:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    11f2:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    11f6:	c4 e2 75 90 34 9a    	vpgatherdd %ymm1,(%rdx,%ymm3,4),%ymm6
    11fc:	c4 e2 7d 3d dd       	vpmaxsd %ymm5,%ymm0,%ymm3
    1201:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
    1205:	c4 e2 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm3
    120a:	c4 41 65 fe c2       	vpaddd %ymm10,%ymm3,%ymm8
    120f:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1214:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    1219:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm12,%ymm12        # 1242 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x642>
    1220:	00 00 10 
    1223:	c5 fd fe cd          	vpaddd %ymm5,%ymm0,%ymm1
    1227:	c5 fd 66 c5          	vpcmpgtd %ymm5,%ymm0,%ymm0
    122b:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    1230:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1235:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    1239:	c4 a2 05 90 0c a2    	vpgatherdd %ymm15,(%rdx,%ymm12,4),%ymm1
    123f:	c4 41 75 db f9       	vpand  %ymm9,%ymm1,%ymm15
    1244:	c4 e3 6d 4c c4 00    	vpblendvb %ymm0,%ymm4,%ymm2,%ymm0
    124a:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 1273 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x673>
    1251:	00 00 e0 
    1254:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
    1258:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    125c:	c4 62 45 90 24 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm12
    1262:	c4 c1 15 db f9       	vpand  %ymm9,%ymm13,%ymm7
    1267:	c4 c1 4d db c1       	vpand  %ymm9,%ymm6,%ymm0
    126c:	c4 c1 1d db e9       	vpand  %ymm9,%ymm12,%ymm5
    1271:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1276:	c5 85 fa ff          	vpsubd %ymm7,%ymm15,%ymm7
    127a:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    127e:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    1283:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
    1288:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    128f:	00 00 
    1291:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1296:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    129b:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    12a0:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    12a5:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    12a9:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    12ad:	c5 d5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm5
    12b2:	c5 fd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm0
    12b7:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    12be:	00 00 
    12c0:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    12c5:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    12cb:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    12cf:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    12d5:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    12da:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    12df:	c4 41 15 db f1       	vpand  %ymm9,%ymm13,%ymm14
    12e4:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    12e9:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    12f0:	00 00 
    12f2:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    12f7:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    12fd:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1302:	c4 41 4d fe ff       	vpaddd %ymm15,%ymm6,%ymm15
    1307:	c5 7e 7f bc 24 00 01 	vmovdqu %ymm15,0x100(%rsp)
    130e:	00 00 
    1310:	0f 84 ca 00 00 00    	je     13e0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7e0>
    1316:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    131b:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    1321:	48 83 c0 60          	add    $0x60,%rax
    1325:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    132a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    132f:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    1334:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    1338:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    133c:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    1342:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1347:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    134c:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1350:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    1355:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    135a:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    135f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1363:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    136a:	00 00 
    136c:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1370:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1374:	c4 c1 5d fa d4       	vpsubd %ymm12,%ymm4,%ymm2
    1379:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    137e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1383:	c5 1d fa e1          	vpsubd %ymm1,%ymm12,%ymm12
    1387:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    138c:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    1391:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
    1395:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    139a:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    139f:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    13a4:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    13a8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    13ad:	c5 fd 6f d1          	vmovdqa %ymm1,%ymm2
    13b1:	48 39 d8             	cmp    %rbx,%rax
    13b4:	0f 84 96 02 00 00    	je     1650 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa50>
    13ba:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    13c0:	c5 fe 7f 4c 24 20    	vmovdqu %ymm1,0x20(%rsp)
    13c6:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    13cd:	00 00 
    13cf:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    13d5:	e9 3e fd ff ff       	jmp    1118 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x518>
    13da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    13e0:	4c 8b 48 28          	mov    0x28(%rax),%r9
    13e4:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    13ea:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    13ee:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    13f3:	c5 7e 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm12
    13f9:	48 83 c0 60          	add    $0x60,%rax
    13fd:	c4 c2 65 90 34 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm6
    1403:	4c 8b 48 c0          	mov    -0x40(%rax),%r9
    1407:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
    140d:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1411:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1499 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x899>
    1418:	00 
    1419:	c4 42 65 90 04 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm8
    141f:	4c 8b 48 b8          	mov    -0x48(%rax),%r9
    1423:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1427:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 14af <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8af>
    142e:	00 
    142f:	c4 82 65 90 0c a1    	vpgatherdd %ymm3,(%r9,%ymm12,4),%ymm1
    1435:	4c 8b 48 e0          	mov    -0x20(%rax),%r9
    1439:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 14c1 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8c1>
    1440:	00 
    1441:	c4 42 75 3d e8       	vpmaxsd %ymm8,%ymm1,%ymm13
    1446:	c5 3d 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm10
    144a:	c4 42 75 39 e0       	vpminsd %ymm8,%ymm1,%ymm12
    144f:	c4 c1 4d 66 dd       	vpcmpgtd %ymm13,%ymm6,%ymm3
    1454:	c4 62 15 3d ee       	vpmaxsd %ymm6,%ymm13,%ymm13
    1459:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    145f:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm10,%ymm10        # 1488 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x888>
    1466:	00 00 30 
    1469:	c4 e2 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm3
    146e:	c5 2d fe 94 24 a0 00 	vpaddd 0xa0(%rsp),%ymm10,%ymm10
    1475:	00 00 
    1477:	c5 fe 7f 9c 24 60 02 	vmovdqu %ymm3,0x260(%rsp)
    147e:	00 00 
    1480:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1484:	c4 a2 05 90 1c 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm3
    148a:	c4 41 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm10
    148f:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1494:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    1499:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    149e:	c5 7e 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm8
    14a4:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    14a9:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    14af:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # 14d8 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8d8>
    14b6:	00 00 c0 
    14b9:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    14be:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    14c3:	c4 22 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm12
    14c9:	c5 7e 6f bc 24 60 02 	vmovdqu 0x260(%rsp),%ymm15
    14d0:	00 00 
    14d2:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    14d8:	c4 41 15 fe d7       	vpaddd %ymm15,%ymm13,%ymm10
    14dd:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    14e2:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    14e7:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    14ec:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    14f0:	c5 9d fa f3          	vpsubd %ymm3,%ymm12,%ymm6
    14f4:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    14f9:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    14fd:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1502:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    1508:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    150d:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
    1512:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1516:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    151a:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    151e:	c4 c2 45 90 04 a9    	vpgatherdd %ymm7,(%r9,%ymm5,4),%ymm0
    1524:	4c 8b 48 d8          	mov    -0x28(%rax),%r9
    1528:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    152c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1530:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 15b8 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9b8>
    1537:	00 
    1538:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    153d:	c4 82 55 90 3c 81    	vpgatherdd %ymm5,(%r9,%ymm8,4),%ymm7
    1543:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    1549:	4c 8b 48 d0          	mov    -0x30(%rax),%r9
    154d:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    1552:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 15da <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9da>
    1559:	00 
    155a:	c5 fd 6f f1          	vmovdqa %ymm1,%ymm6
    155e:	c4 82 3d 90 2c a9    	vpgatherdd %ymm8,(%r9,%ymm13,4),%ymm5
    1564:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 15ec <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9ec>
    156b:	00 
    156c:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    1571:	c5 45 66 c5          	vpcmpgtd %ymm5,%ymm7,%ymm8
    1575:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    157a:	c4 c1 7d 66 da       	vpcmpgtd %ymm10,%ymm0,%ymm3
    157f:	c4 62 1d 39 e8       	vpminsd %ymm0,%ymm12,%ymm13
    1584:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    1589:	c5 1d 66 e0          	vpcmpgtd %ymm0,%ymm12,%ymm12
    158d:	c4 63 6d 4c c4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm8
    1593:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 15bc <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9bc>
    159a:	00 00 30 
    159d:	c5 3d fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm8,%ymm8
    15a4:	00 00 
    15a6:	c4 a2 05 90 1c 82    	vpgatherdd %ymm15,(%rdx,%ymm8,4),%ymm3
    15ac:	c5 55 66 c7          	vpcmpgtd %ymm7,%ymm5,%ymm8
    15b0:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    15b4:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    15bb:	00 00 
    15bd:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    15c2:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    15c7:	c4 e3 6d 4c d4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm2
    15cd:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 15f6 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f6>
    15d4:	00 00 c0 
    15d7:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    15dc:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
    15e0:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    15e5:	c4 e2 1d 90 24 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm4
    15eb:	c4 c1 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm2
    15f0:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    15f5:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    15f9:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    15fe:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1602:	c5 dd fa d3          	vpsubd %ymm3,%ymm4,%ymm2
    1606:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    160b:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1610:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1615:	c5 c5 fa d4          	vpsubd %ymm4,%ymm7,%ymm2
    1619:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    161e:	c5 e5 fe 9c 24 00 01 	vpaddd 0x100(%rsp),%ymm3,%ymm3
    1625:	00 00 
    1627:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    162b:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    162f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1634:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
    1638:	48 39 c3             	cmp    %rax,%rbx
    163b:	74 13                	je     1650 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa50>
    163d:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
    1643:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1649:	e9 78 fd ff ff       	jmp    13c6 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c6>
    164e:	66 90                	xchg   %ax,%ax
    1650:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
    1657:	00 00 
    1659:	e9 82 f7 ff ff       	jmp    de0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e0>
    165e:	66 90                	xchg   %ax,%ax
    1660:	c5 f8 77             	vzeroupper
    1663:	c5 f8 28 b4 24 80 02 	vmovaps 0x280(%rsp),%xmm6
    166a:	00 00 
    166c:	c5 f8 28 bc 24 90 02 	vmovaps 0x290(%rsp),%xmm7
    1673:	00 00 
    1675:	c5 78 28 84 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm8
    167c:	00 00 
    167e:	c5 78 28 8c 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm9
    1685:	00 00 
    1687:	c5 78 28 94 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm10
    168e:	00 00 
    1690:	c5 78 28 9c 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm11
    1697:	00 00 
    1699:	c5 78 28 a4 24 e0 02 	vmovaps 0x2e0(%rsp),%xmm12
    16a0:	00 00 
    16a2:	c5 78 28 ac 24 f0 02 	vmovaps 0x2f0(%rsp),%xmm13
    16a9:	00 00 
    16ab:	c5 78 28 b4 24 00 03 	vmovaps 0x300(%rsp),%xmm14
    16b2:	00 00 
    16b4:	c5 78 28 bc 24 10 03 	vmovaps 0x310(%rsp),%xmm15
    16bb:	00 00 
    16bd:	48 81 c4 28 03 00 00 	add    $0x328,%rsp
    16c4:	5b                   	pop    %rbx
    16c5:	5e                   	pop    %rsi
    16c6:	c3                   	ret
    16c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    16ce:	00 00 

00000000000016d0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    16d0:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
    16d7:	c5 f8 29 b4 24 40 02 	vmovaps %xmm6,0x240(%rsp)
    16de:	00 00 
    16e0:	c5 f8 29 bc 24 50 02 	vmovaps %xmm7,0x250(%rsp)
    16e7:	00 00 
    16e9:	c5 78 29 84 24 60 02 	vmovaps %xmm8,0x260(%rsp)
    16f0:	00 00 
    16f2:	c5 78 29 8c 24 70 02 	vmovaps %xmm9,0x270(%rsp)
    16f9:	00 00 
    16fb:	c5 78 29 94 24 80 02 	vmovaps %xmm10,0x280(%rsp)
    1702:	00 00 
    1704:	c5 78 29 9c 24 90 02 	vmovaps %xmm11,0x290(%rsp)
    170b:	00 00 
    170d:	c5 78 29 a4 24 a0 02 	vmovaps %xmm12,0x2a0(%rsp)
    1714:	00 00 
    1716:	c5 78 29 ac 24 b0 02 	vmovaps %xmm13,0x2b0(%rsp)
    171d:	00 00 
    171f:	c5 78 29 b4 24 c0 02 	vmovaps %xmm14,0x2c0(%rsp)
    1726:	00 00 
    1728:	c5 78 29 bc 24 d0 02 	vmovaps %xmm15,0x2d0(%rsp)
    172f:	00 00 
    1731:	48 89 c8             	mov    %rcx,%rax
    1734:	49 89 d2             	mov    %rdx,%r10
    1737:	4d 85 c9             	test   %r9,%r9
    173a:	0f 84 63 0d 00 00    	je     24a3 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdd3>
    1740:	c4 c2 7d 58 7a 28    	vpbroadcastd 0x28(%r10),%ymm7
    1746:	49 ff c9             	dec    %r9
    1749:	8b 52 24             	mov    0x24(%rdx),%edx
    174c:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    1751:	49 c1 e9 03          	shr    $0x3,%r9
    1755:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    1759:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    175f:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    1766:	00 00 
    1768:	c4 c2 7d 58 7a 2c    	vpbroadcastd 0x2c(%r10),%ymm7
    176e:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    1772:	0f af ca             	imul   %edx,%ecx
    1775:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    177a:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    1780:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    1787:	00 00 
    1789:	c4 c2 7d 58 7a 08    	vpbroadcastd 0x8(%r10),%ymm7
    178f:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    1796:	00 00 
    1798:	c4 c2 7d 58 7a 0c    	vpbroadcastd 0xc(%r10),%ymm7
    179e:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    17a5:	00 00 
    17a7:	c4 c2 7d 58 7a 10    	vpbroadcastd 0x10(%r10),%ymm7
    17ad:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    17b4:	00 00 
    17b6:	c4 c2 7d 58 7a 14    	vpbroadcastd 0x14(%r10),%ymm7
    17bc:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    17c3:	00 00 
    17c5:	c4 c2 7d 58 7a 18    	vpbroadcastd 0x18(%r10),%ymm7
    17cb:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    17d2:	00 00 
    17d4:	c4 c2 7d 58 7a 1c    	vpbroadcastd 0x1c(%r10),%ymm7
    17da:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    17e1:	00 00 
    17e3:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    17e8:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    17ed:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    17f2:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    17f6:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    17fb:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
    1802:	00 00 
    1804:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    1808:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    180d:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
    1814:	00 00 
    1816:	e9 d8 00 00 00       	jmp    18f3 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x223>
    181b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1820:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    1824:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    1829:	49 8b 12             	mov    (%r10),%rdx
    182c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1830:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    1835:	c4 e2 75 40 8c 24 00 	vpmulld 0x200(%rsp),%ymm1,%ymm1
    183c:	02 00 00 
    183f:	c4 e2 55 40 ac 24 20 	vpmulld 0x220(%rsp),%ymm5,%ymm5
    1846:	02 00 00 
    1849:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    184d:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1851:	c5 ed 72 d1 01       	vpsrld $0x1,%ymm1,%ymm2
    1856:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # 187e <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ae>
    185d:	00 
    185e:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    1864:	c5 f5 72 f1 04       	vpslld $0x4,%ymm1,%ymm1
    1869:	c4 e2 7d 45 c1       	vpsrlvd %ymm1,%ymm0,%ymm0
    186e:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    1873:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1878:	c5 fd 72 d0 0c       	vpsrld $0xc,%ymm0,%ymm0
    187d:	c5 f5 db 0d a0 00 00 	vpand  0xa0(%rip),%ymm1,%ymm1        # 1925 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x255>
    1884:	00 
    1885:	c5 fd db 05 a0 00 00 	vpand  0xa0(%rip),%ymm0,%ymm0        # 192d <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25d>
    188c:	00 
    188d:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
    1891:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    1895:	c5 f5 fe 8c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm1,%ymm1
    189c:	00 00 
    189e:	c5 fd fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm0
    18a5:	00 00 
    18a7:	c5 ed 72 f0 10       	vpslld $0x10,%ymm0,%ymm2
    18ac:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    18b1:	49 83 c0 18          	add    $0x18,%r8
    18b5:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    18b9:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    18bd:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 1906 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x236>
    18c4:	00 00 
    18c6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    18ca:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    18d0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    18d5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    18da:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    18de:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    18e4:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    18ea:	4d 39 d8             	cmp    %r11,%r8
    18ed:	0f 84 ad 0b 00 00    	je     24a0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdd0>
    18f3:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    18f8:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    18fe:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    1902:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    1907:	48 8b 10             	mov    (%rax),%rdx
    190a:	44 8b 48 54          	mov    0x54(%rax),%r9d
    190e:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
    1914:	8b 48 50             	mov    0x50(%rax),%ecx
    1917:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
    191d:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # 1926 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x256>
    1924:	00 00 
    1926:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    192b:	c5 c5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm7
    1930:	c4 c1 75 db f7       	vpand  %ymm15,%ymm1,%ymm6
    1935:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    193b:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    193f:	c4 e2 5d 90 14 b2    	vpgatherdd %ymm4,(%rdx,%ymm6,4),%ymm2
    1945:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    194a:	48 8b 50 08          	mov    0x8(%rax),%rdx
    194e:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    1954:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    195a:	48 8b 50 10          	mov    0x10(%rax),%rdx
    195e:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    1965:	00 00 
    1967:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    196b:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    1970:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    1975:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 19fd <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32d>
    197c:	00 
    197d:	c4 e2 75 90 1c ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm3
    1983:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
    1987:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    198c:	48 8b 50 48          	mov    0x48(%rax),%rdx
    1990:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1995:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    199a:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    199f:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    19a4:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    19a9:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 1a31 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x361>
    19b0:	00 
    19b1:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    19b6:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 1a3e <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36e>
    19bd:	00 
    19be:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    19c3:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    19c7:	c5 7d fe ce          	vpaddd %ymm6,%ymm0,%ymm9
    19cb:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    19cf:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    19d4:	c4 22 7d 90 1c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm11
    19da:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    19de:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    19e2:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    19e7:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    19ec:	c4 41 7d fe e9       	vpaddd %ymm9,%ymm0,%ymm13
    19f1:	c4 a2 2d 90 04 aa    	vpgatherdd %ymm10,(%rdx,%ymm13,4),%ymm0
    19f7:	c5 7e 7f 4c 24 60    	vmovdqu %ymm9,0x60(%rsp)
    19fd:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    1a02:	c5 7d 6f e0          	vmovdqa %ymm0,%ymm12
    1a06:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    1a0a:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    1a0e:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    1a14:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 1a3d <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36d>
    1a1b:	00 00 40 
    1a1e:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    1a23:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    1a28:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    1a2e:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    1a32:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    1a37:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1a3c:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1a40:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    1a46:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 1a6f <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x39f>
    1a4d:	00 00 80 
    1a50:	c5 95 fa c0          	vpsubd %ymm0,%ymm13,%ymm0
    1a54:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    1a5a:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
    1a61:	00 00 
    1a63:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    1a68:	c5 05 db 8c 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm9
    1a6f:	00 00 
    1a71:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1a76:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    1a7b:	48 8b 48 28          	mov    0x28(%rax),%rcx
    1a7f:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    1a85:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    1a89:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    1a8d:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    1a93:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    1a98:	c4 c1 05 db d4       	vpand  %ymm12,%ymm15,%ymm2
    1a9d:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    1aa2:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    1aa7:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    1aac:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    1ab1:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1ab6:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    1abb:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    1ac0:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    1ac4:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1ac8:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1acc:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
    1ad3:	00 00 
    1ad5:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1ad9:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    1adf:	c4 e2 65 90 34 a1    	vpgatherdd %ymm3,(%rcx,%ymm4,4),%ymm6
    1ae5:	48 8b 48 20          	mov    0x20(%rax),%rcx
    1ae9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1aee:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1af2:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1b7a <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4aa>
    1af9:	00 
    1afa:	c4 62 65 90 04 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm8
    1b00:	48 8b 48 18          	mov    0x18(%rax),%rcx
    1b04:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 1b8c <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4bc>
    1b0b:	00 
    1b0c:	c4 e2 2d 90 14 a9    	vpgatherdd %ymm10,(%rcx,%ymm5,4),%ymm2
    1b12:	48 8b 48 40          	mov    0x40(%rax),%rcx
    1b16:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 1b9e <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4ce>
    1b1d:	00 
    1b1e:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    1b23:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    1b27:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    1b2c:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    1b31:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    1b36:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    1b3b:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    1b42:	00 00 
    1b44:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    1b48:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    1b4e:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 1b77 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4a7>
    1b55:	00 00 30 
    1b58:	c5 dd fe 64 24 60    	vpaddd 0x60(%rsp),%ymm4,%ymm4
    1b5e:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    1b64:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    1b69:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    1b6e:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    1b73:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1b78:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1b7d:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    1b83:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 1bac <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4dc>
    1b8a:	00 00 50 
    1b8d:	c4 c1 55 72 d4 08    	vpsrld $0x8,%ymm12,%ymm5
    1b93:	c5 95 fa e4          	vpsubd %ymm4,%ymm13,%ymm4
    1b97:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1b9c:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    1ba2:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
    1ba9:	00 00 
    1bab:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
    1bb2:	00 00 
    1bb4:	c5 2d fe a4 24 e0 00 	vpaddd 0xe0(%rsp),%ymm10,%ymm12
    1bbb:	00 00 
    1bbd:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    1bc3:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    1bc8:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    1bce:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    1bd3:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1bd8:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    1bdc:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    1be0:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    1be5:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    1bea:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1bef:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1bf4:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    1bfa:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    1bff:	c4 e2 55 40 ac 24 e0 	vpmulld 0xe0(%rsp),%ymm5,%ymm5
    1c06:	00 00 00 
    1c09:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    1c0e:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    1c13:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    1c17:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    1c1e:	00 00 
    1c20:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    1c24:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1c28:	c4 e2 1d 90 2c b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm5
    1c2e:	48 8b 48 38          	mov    0x38(%rax),%rcx
    1c32:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    1c38:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    1c3d:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1c43:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1c48:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1cd0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x600>
    1c4f:	00 
    1c50:	c4 e2 1d 90 34 91    	vpgatherdd %ymm12,(%rcx,%ymm2,4),%ymm6
    1c56:	48 8b 48 30          	mov    0x30(%rax),%rcx
    1c5a:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    1c5f:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1ce7 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x617>
    1c66:	00 
    1c67:	c4 e2 2d 90 14 99    	vpgatherdd %ymm10,(%rcx,%ymm3,4),%ymm2
    1c6d:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 1cf5 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x625>
    1c74:	00 
    1c75:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    1c7a:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    1c7e:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    1c83:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    1c88:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    1c8d:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    1c92:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    1c96:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    1c9c:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 1cc5 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5f5>
    1ca3:	00 00 30 
    1ca6:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    1cac:	c4 a2 1d 90 1c 82    	vpgatherdd %ymm12,(%rdx,%ymm8,4),%ymm3
    1cb2:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    1cb6:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    1cbb:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1cc0:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    1cc5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1cc9:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1cce:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    1cd2:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    1cd8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 1d01 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x631>
    1cdf:	00 00 a0 
    1ce2:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    1ce7:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    1ceb:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    1cf2:	00 00 
    1cf4:	c4 e2 2d 90 3c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm7
    1cfa:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    1d01:	00 00 
    1d03:	c4 c1 2d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm10
    1d09:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1d0e:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    1d15:	00 00 
    1d17:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1d1c:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1d21:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    1d26:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1d2b:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    1d2f:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    1d33:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    1d3a:	00 00 
    1d3c:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    1d41:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    1d46:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    1d4a:	c5 7e 6f 9c 24 00 01 	vmovdqu 0x100(%rsp),%ymm11
    1d51:	00 00 
    1d53:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1d58:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    1d5d:	c5 dd fa c8          	vpsubd %ymm0,%ymm4,%ymm1
    1d61:	c5 3d fe 04 24       	vpaddd (%rsp),%ymm8,%ymm8
    1d66:	c5 a5 66 f0          	vpcmpgtd %ymm0,%ymm11,%ymm6
    1d6a:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    1d6f:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    1d73:	c5 c5 66 d9          	vpcmpgtd %ymm1,%ymm7,%ymm3
    1d77:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1d7c:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1d82:	c5 bd fa e8          	vpsubd %ymm0,%ymm8,%ymm5
    1d86:	c5 95 66 d5          	vpcmpgtd %ymm5,%ymm13,%ymm2
    1d8a:	c5 e5 eb d2          	vpor   %ymm2,%ymm3,%ymm2
    1d8e:	c5 d5 66 9c 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm5,%ymm3
    1d95:	00 00 
    1d97:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    1d9b:	c5 fd 66 9c 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm3
    1da2:	00 00 
    1da4:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    1da8:	c5 f5 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm1,%ymm6
    1daf:	00 00 
    1db1:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    1db5:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    1db9:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    1dbd:	85 d2                	test   %edx,%edx
    1dbf:	0f 84 5b fa ff ff    	je     1820 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x150>
    1dc5:	48 8b 50 60          	mov    0x60(%rax),%rdx
    1dc9:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1dcd:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
    1dd4:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
    1dda:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
    1de0:	48 8b 50 68          	mov    0x68(%rax),%rdx
    1de4:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1de8:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    1ded:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    1df2:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    1df7:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 1e7f <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7af>
    1dfe:	00 
    1dff:	c4 e2 45 90 2c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm5
    1e05:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    1e09:	48 8b 50 70          	mov    0x70(%rax),%rdx
    1e0d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1e11:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1e16:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    1e1b:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    1e20:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    1e25:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1e2a:	c4 a2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm8,4),%ymm6
    1e30:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    1e37:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1e3c:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    1e40:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1ec8 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7f8>
    1e47:	00 
    1e48:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1e4d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1e51:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1ed9 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x809>
    1e58:	00 
    1e59:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    1e5e:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    1e63:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    1e68:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    1e6c:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1e70:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1e74:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    1e78:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    1e7e:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1e82:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    1e88:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    1e8c:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    1e92:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    1e96:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1e9b:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    1e9f:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    1ea4:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    1ea9:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    1eaf:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1ed8 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x808>
    1eb6:	00 00 70 
    1eb9:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    1ebe:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    1ec4:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    1ec9:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1ecd:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1ed3:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 1efc <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x82c>
    1eda:	00 00 b0 
    1edd:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1ee1:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    1ee6:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    1eeb:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    1eef:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    1ef3:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    1ef9:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    1eff:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    1f04:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1f09:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    1f10:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    1f15:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    1f1a:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    1f1e:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    1f22:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    1f27:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1f2c:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    1f31:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1f36:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1f3b:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    1f40:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1f45:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    1f4a:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1f4f:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    1f53:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1f57:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    1f5d:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    1f61:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1f66:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1f6b:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1f70:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    1f75:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1f7a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1f7f:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    1f83:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    1f88:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1f8d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1f92:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    1f96:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1f9b:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1fa0:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1fa5:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    1faa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1faf:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1fb4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1fb9:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1fbd:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1fc1:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1fc6:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1fcb:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    1fcf:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    1fd3:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    1fd8:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    1fdc:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    1fe1:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    1fe7:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1fec:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    1ff1:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    1ff5:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    1ffa:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1fff:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2003:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2007:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    200d:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    2014:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2018:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    201c:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2022:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
    2029:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
    202f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2034:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    203b:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    203f:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2044:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 20cc <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9fc>
    204b:	00 
    204c:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    2051:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    2055:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    205a:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2060:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2065:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    206a:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2071:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2076:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    207b:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    207f:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2084:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    2089:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    208e:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2116 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa46>
    2095:	00 
    2096:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    209a:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2122 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa52>
    20a1:	00 
    20a2:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    20a7:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    20ac:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    20b1:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    20b5:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    20b9:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    20bd:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    20c1:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    20c7:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    20cb:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    20d1:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    20d5:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    20db:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    20df:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    20e4:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    20e8:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    20ed:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    20f2:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    20f8:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2121 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa51>
    20ff:	00 00 70 
    2102:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2107:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    210d:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2112:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2116:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    211c:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2145 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa75>
    2123:	00 00 b0 
    2126:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    212a:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    212f:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2134:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    2138:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    213c:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2142:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    2148:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    214d:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2152:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    2159:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    215e:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2163:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2167:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    216b:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2170:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2175:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    217a:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    217f:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2184:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2189:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    218e:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2193:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2198:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    219c:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    21a0:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    21a6:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    21aa:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    21af:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    21b4:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    21b9:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    21be:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    21c3:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    21c8:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    21cc:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    21d1:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    21d6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    21db:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    21df:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    21e4:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    21e9:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    21ee:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    21f3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    21f8:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    21fd:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2202:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2206:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    220a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    220f:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2214:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2218:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    221c:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2221:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2225:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    222a:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    2230:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2235:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    223a:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    223e:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2243:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    2248:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    224c:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2250:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    2256:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    225d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2261:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2265:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    226b:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    2272:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2277:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    227b:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2280:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2286:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
    228d:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
    2293:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2298:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    229d:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    22a4:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 232c <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc5c>
    22ab:	00 
    22ac:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    22b0:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    22b4:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    22b9:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    22be:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    22c3:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    22c8:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    22cc:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    22d1:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    22d6:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    22db:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2363 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc93>
    22e2:	00 
    22e3:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 236b <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc9b>
    22ea:	00 
    22eb:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    22f0:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    22f5:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    22fa:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    22fe:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2302:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2306:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    230a:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2310:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2314:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    231a:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    231e:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2324:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2328:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    232d:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2331:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2336:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    233c:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2365 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc95>
    2343:	00 00 70 
    2346:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    234b:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2351:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2356:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    235a:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    2360:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2389 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcb9>
    2367:	00 00 b0 
    236a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    236e:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2373:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2378:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    237d:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    2381:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2385:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    238b:	c4 e2 4d 90 2c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm5
    2391:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2396:	c4 c1 15 db e7       	vpand  %ymm15,%ymm13,%ymm4
    239b:	c4 c1 55 db cf       	vpand  %ymm15,%ymm5,%ymm1
    23a0:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    23a5:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
    23a9:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    23ad:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    23b2:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    23b7:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    23bc:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    23c1:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    23c6:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    23cb:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    23d0:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    23d5:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    23da:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    23de:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    23e2:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    23e8:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    23ec:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    23f1:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    23f6:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    23fb:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2400:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2405:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    240a:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    240e:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2413:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2418:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    241d:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    2421:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    2426:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    242b:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2430:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2435:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    243a:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    243f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2444:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    2448:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    244c:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2451:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2456:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    245a:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    245f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2463:	c4 c1 5d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm4
    2469:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    246e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2473:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    2478:	c5 ed fa e4          	vpsubd %ymm4,%ymm2,%ymm4
    247c:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2481:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2486:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    248a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    248e:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2492:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2497:	e9 0b f4 ff ff       	jmp    18a7 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d7>
    249c:	0f 1f 40 00          	nopl   0x0(%rax)
    24a0:	c5 f8 77             	vzeroupper
    24a3:	c5 f8 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm6
    24aa:	00 00 
    24ac:	c5 f8 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm7
    24b3:	00 00 
    24b5:	c5 78 28 84 24 60 02 	vmovaps 0x260(%rsp),%xmm8
    24bc:	00 00 
    24be:	c5 78 28 8c 24 70 02 	vmovaps 0x270(%rsp),%xmm9
    24c5:	00 00 
    24c7:	c5 78 28 94 24 80 02 	vmovaps 0x280(%rsp),%xmm10
    24ce:	00 00 
    24d0:	c5 78 28 9c 24 90 02 	vmovaps 0x290(%rsp),%xmm11
    24d7:	00 00 
    24d9:	c5 78 28 a4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm12
    24e0:	00 00 
    24e2:	c5 78 28 ac 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm13
    24e9:	00 00 
    24eb:	c5 78 28 b4 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm14
    24f2:	00 00 
    24f4:	c5 78 28 bc 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm15
    24fb:	00 00 
    24fd:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
    2504:	c3                   	ret
    2505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    250c:	00 00 00 00 

0000000000002510 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    2510:	56                   	push   %rsi
    2511:	53                   	push   %rbx
    2512:	48 81 ec 08 03 00 00 	sub    $0x308,%rsp
    2519:	c5 f8 29 b4 24 60 02 	vmovaps %xmm6,0x260(%rsp)
    2520:	00 00 
    2522:	c5 f8 29 bc 24 70 02 	vmovaps %xmm7,0x270(%rsp)
    2529:	00 00 
    252b:	c5 78 29 84 24 80 02 	vmovaps %xmm8,0x280(%rsp)
    2532:	00 00 
    2534:	c5 78 29 8c 24 90 02 	vmovaps %xmm9,0x290(%rsp)
    253b:	00 00 
    253d:	c5 78 29 94 24 a0 02 	vmovaps %xmm10,0x2a0(%rsp)
    2544:	00 00 
    2546:	c5 78 29 9c 24 b0 02 	vmovaps %xmm11,0x2b0(%rsp)
    254d:	00 00 
    254f:	c5 78 29 a4 24 c0 02 	vmovaps %xmm12,0x2c0(%rsp)
    2556:	00 00 
    2558:	c5 78 29 ac 24 d0 02 	vmovaps %xmm13,0x2d0(%rsp)
    255f:	00 00 
    2561:	c5 78 29 b4 24 e0 02 	vmovaps %xmm14,0x2e0(%rsp)
    2568:	00 00 
    256a:	c5 78 29 bc 24 f0 02 	vmovaps %xmm15,0x2f0(%rsp)
    2571:	00 00 
    2573:	48 89 c8             	mov    %rcx,%rax
    2576:	49 89 d2             	mov    %rdx,%r10
    2579:	4d 85 c9             	test   %r9,%r9
    257c:	0f 84 01 0c 00 00    	je     3183 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc73>
    2582:	c4 c2 7d 58 52 28    	vpbroadcastd 0x28(%r10),%ymm2
    2588:	8b 52 24             	mov    0x24(%rdx),%edx
    258b:	49 ff c9             	dec    %r9
    258e:	48 8d 98 80 01 00 00 	lea    0x180(%rax),%rbx
    2595:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    2599:	49 c1 e9 03          	shr    $0x3,%r9
    259d:	c5 fe 7f 94 24 c0 01 	vmovdqu %ymm2,0x1c0(%rsp)
    25a4:	00 00 
    25a6:	c4 c2 7d 58 52 2c    	vpbroadcastd 0x2c(%r10),%ymm2
    25ac:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    25b0:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    25b4:	0f af ca             	imul   %edx,%ecx
    25b7:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    25bc:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    25c1:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    25c7:	c5 fe 7f 94 24 e0 01 	vmovdqu %ymm2,0x1e0(%rsp)
    25ce:	00 00 
    25d0:	c4 c2 7d 58 52 08    	vpbroadcastd 0x8(%r10),%ymm2
    25d6:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
    25db:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    25e0:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
    25e7:	00 00 
    25e9:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    25f0:	00 00 
    25f2:	c4 c2 7d 58 52 0c    	vpbroadcastd 0xc(%r10),%ymm2
    25f8:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    25ff:	00 00 
    2601:	c5 fe 7f 94 24 20 01 	vmovdqu %ymm2,0x120(%rsp)
    2608:	00 00 
    260a:	c4 c2 7d 58 52 10    	vpbroadcastd 0x10(%r10),%ymm2
    2610:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    2617:	00 00 
    2619:	c4 c2 7d 58 52 14    	vpbroadcastd 0x14(%r10),%ymm2
    261f:	c5 fe 7f 94 24 60 01 	vmovdqu %ymm2,0x160(%rsp)
    2626:	00 00 
    2628:	c4 c2 7d 58 52 18    	vpbroadcastd 0x18(%r10),%ymm2
    262e:	c5 fe 7f 94 24 80 01 	vmovdqu %ymm2,0x180(%rsp)
    2635:	00 00 
    2637:	c4 c2 7d 58 52 1c    	vpbroadcastd 0x1c(%r10),%ymm2
    263d:	c5 fe 7f 94 24 a0 01 	vmovdqu %ymm2,0x1a0(%rsp)
    2644:	00 00 
    2646:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    264a:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    264f:	c5 fe 7f 94 24 20 02 	vmovdqu %ymm2,0x220(%rsp)
    2656:	00 00 
    2658:	e9 da 00 00 00       	jmp    2737 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x227>
    265d:	0f 1f 00             	nopl   (%rax)
    2660:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    2664:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    2669:	49 8b 12             	mov    (%r10),%rdx
    266c:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    2670:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
    2675:	c4 e2 75 40 8c 24 00 	vpmulld 0x200(%rsp),%ymm1,%ymm1
    267c:	02 00 00 
    267f:	c4 e2 65 40 9c 24 20 	vpmulld 0x220(%rsp),%ymm3,%ymm3
    2686:	02 00 00 
    2689:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    268d:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    2691:	c5 f5 72 d0 01       	vpsrld $0x1,%ymm0,%ymm1
    2696:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 26be <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ae>
    269d:	00 
    269e:	c4 e2 55 90 14 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm2
    26a4:	c5 fd 72 f0 04       	vpslld $0x4,%ymm0,%ymm0
    26a9:	c4 e2 6d 45 d0       	vpsrlvd %ymm0,%ymm2,%ymm2
    26ae:	c5 ed db 0d 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm1        # 2716 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x206>
    26b5:	00 
    26b6:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
    26bb:	c5 ed 72 d2 0c       	vpsrld $0xc,%ymm2,%ymm2
    26c0:	c5 fd db 05 a0 00 00 	vpand  0xa0(%rip),%ymm0,%ymm0        # 2768 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x258>
    26c7:	00 
    26c8:	c5 ed db 15 a0 00 00 	vpand  0xa0(%rip),%ymm2,%ymm2        # 2770 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x260>
    26cf:	00 
    26d0:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    26d4:	c5 f5 fe d2          	vpaddd %ymm2,%ymm1,%ymm2
    26d8:	c5 7d fe ac 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm0,%ymm13
    26df:	00 00 
    26e1:	c5 ed fe 94 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm2,%ymm2
    26e8:	00 00 
    26ea:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    26ef:	c4 c1 7d 72 f5 08    	vpslld $0x8,%ymm13,%ymm0
    26f5:	49 83 c0 18          	add    $0x18,%r8
    26f9:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    26fd:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2701:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 274a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23a>
    2708:	00 00 
    270a:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    270e:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2714:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2719:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    271e:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2722:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2728:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    272e:	4d 39 c3             	cmp    %r8,%r11
    2731:	0f 84 49 0a 00 00    	je     3180 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc70>
    2737:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    273c:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    2742:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    2746:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    274b:	48 8b 10             	mov    (%rax),%rdx
    274e:	44 8b 48 54          	mov    0x54(%rax),%r9d
    2752:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2758:	8b 48 50             	mov    0x50(%rax),%ecx
    275b:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2761:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
    2766:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 276f <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25f>
    276d:	00 00 
    276f:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    2774:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2779:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    277e:	c5 fd db 2d 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm5        # 27e6 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d6>
    2785:	00 
    2786:	c5 fe 7f 2c 24       	vmovdqu %ymm5,(%rsp)
    278b:	c4 e2 6d 90 1c aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm3
    2791:	c5 f5 db 15 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm2        # 27f9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e9>
    2798:	00 
    2799:	48 8b 50 08          	mov    0x8(%rax),%rdx
    279d:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    27a1:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    27a7:	c4 e2 75 90 34 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm6
    27ad:	48 8b 50 10          	mov    0x10(%rax),%rdx
    27b1:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    27b7:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    27bb:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    27bf:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    27c4:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    27c9:	c4 e2 75 90 24 ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm4
    27cf:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    27d4:	48 8b 50 48          	mov    0x48(%rax),%rdx
    27d8:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2860 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x350>
    27df:	00 
    27e0:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    27e5:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    27ea:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2872 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x362>
    27f1:	00 
    27f2:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    27f7:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    27fc:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 2884 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x374>
    2803:	00 
    2804:	c4 e2 65 3d fe       	vpmaxsd %ymm6,%ymm3,%ymm7
    2809:	c4 62 65 39 d6       	vpminsd %ymm6,%ymm3,%ymm10
    280e:	c4 62 2d 39 e4       	vpminsd %ymm4,%ymm10,%ymm12
    2813:	c5 2d 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm10
    2817:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    281b:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    281f:	c5 7d fe f5          	vpaddd %ymm5,%ymm0,%ymm14
    2823:	c5 dd 66 ef          	vpcmpgtd %ymm7,%ymm4,%ymm5
    2827:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    282b:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    2830:	c4 22 75 90 2c b2    	vpgatherdd %ymm1,(%rdx,%ymm14,4),%ymm13
    2836:	c4 e2 45 3d fc       	vpmaxsd %ymm4,%ymm7,%ymm7
    283b:	c4 41 7d fe fe       	vpaddd %ymm14,%ymm0,%ymm15
    2840:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    2844:	c4 a2 7d 90 0c ba    	vpgatherdd %ymm0,(%rdx,%ymm15,4),%ymm1
    284a:	c5 cd 66 c3          	vpcmpgtd %ymm3,%ymm6,%ymm0
    284e:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    2854:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm0,%ymm0        # 287d <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36d>
    285b:	00 00 50 
    285e:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
    2862:	c4 e2 25 90 2c 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm5
    2868:	c5 e5 66 c6          	vpcmpgtd %ymm6,%ymm3,%ymm0
    286c:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
    2872:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    2877:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    287b:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    2881:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm0,%ymm0        # 28aa <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x39a>
    2888:	00 00 a0 
    288b:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
    288f:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    2894:	c4 62 25 90 14 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm10
    289a:	c5 15 db 1d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm11        # 2902 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3f2>
    28a1:	00 
    28a2:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 290a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3fa>
    28a9:	00 
    28aa:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 2912 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x402>
    28b1:	00 
    28b2:	c4 41 45 fe ec       	vpaddd %ymm12,%ymm7,%ymm13
    28b7:	48 8b 48 28          	mov    0x28(%rax),%rcx
    28bb:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    28c0:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    28c6:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    28cb:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    28d0:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    28d4:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    28d8:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    28dd:	c5 f5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm3        # 2945 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x435>
    28e4:	00 
    28e5:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    28ea:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    28ef:	c5 fd fe 84 24 80 00 	vpaddd 0x80(%rsp),%ymm0,%ymm0
    28f6:	00 00 
    28f8:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    28fd:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    2902:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    2907:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    290b:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    290f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2913:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
    2919:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    291d:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2923:	c4 e2 5d 90 3c a9    	vpgatherdd %ymm4,(%rcx,%ymm5,4),%ymm7
    2929:	48 8b 48 20          	mov    0x20(%rax),%rcx
    292d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2932:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    2936:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 29be <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4ae>
    293d:	00 
    293e:	c4 62 5d 90 14 99    	vpgatherdd %ymm4,(%rcx,%ymm3,4),%ymm10
    2944:	48 8b 48 18          	mov    0x18(%rax),%rcx
    2948:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 29d0 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4c0>
    294f:	00 
    2950:	c4 e2 1d 90 1c b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm3
    2956:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 29de <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4ce>
    295d:	00 
    295e:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
    2963:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
    2967:	c4 c2 65 39 f2       	vpminsd %ymm10,%ymm3,%ymm6
    296c:	c4 c1 45 66 e4       	vpcmpgtd %ymm12,%ymm7,%ymm4
    2971:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    2976:	c4 62 1d 3d e7       	vpmaxsd %ymm7,%ymm12,%ymm12
    297b:	c5 7e 7f 9c 24 c0 00 	vmovdqu %ymm11,0xc0(%rsp)
    2982:	00 00 
    2984:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    2988:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    298e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 29b7 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4a7>
    2995:	00 00 40 
    2998:	c5 8d fe ed          	vpaddd %ymm5,%ymm14,%ymm5
    299c:	c4 e2 15 90 24 aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm4
    29a2:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
    29a7:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    29ac:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    29b1:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    29b6:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    29bc:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 29e5 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4d5>
    29c3:	00 00 60 
    29c6:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    29cc:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    29d0:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    29d5:	c4 62 15 90 1c aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm11
    29db:	c4 c1 15 72 d7 08    	vpsrld $0x8,%ymm15,%ymm13
    29e1:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    29e8:	00 00 
    29ea:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    29f0:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    29f5:	c5 15 db 2d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm13        # 2a5d <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x54d>
    29fc:	00 
    29fd:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 2a65 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x555>
    2a04:	00 
    2a05:	c5 1d fe bc 24 c0 00 	vpaddd 0xc0(%rsp),%ymm12,%ymm15
    2a0c:	00 00 
    2a0e:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 2a76 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x566>
    2a15:	00 
    2a16:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
    2a1c:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2a84 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x574>
    2a23:	00 
    2a24:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
    2a29:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
    2a30:	00 00 
    2a32:	48 8b 48 40          	mov    0x40(%rax),%rcx
    2a36:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2a3b:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
    2a3f:	c5 a5 fa fc          	vpsubd %ymm4,%ymm11,%ymm7
    2a43:	c4 e2 65 40 ff       	vpmulld %ymm7,%ymm3,%ymm7
    2a48:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    2a4d:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    2a52:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2a58:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    2a5d:	c4 e2 4d 40 b4 24 c0 	vpmulld 0xc0(%rsp),%ymm6,%ymm6
    2a64:	00 00 00 
    2a67:	c5 c5 fe ed          	vpaddd %ymm5,%ymm7,%ymm5
    2a6b:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    2a71:	c5 cd fe f4          	vpaddd %ymm4,%ymm6,%ymm6
    2a75:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    2a7a:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    2a7e:	c4 e2 05 90 34 b9    	vpgatherdd %ymm15,(%rcx,%ymm7,4),%ymm6
    2a84:	48 8b 48 38          	mov    0x38(%rax),%rcx
    2a88:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2a8d:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2b15 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x605>
    2a94:	00 
    2a95:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    2a9a:	c4 e2 05 90 3c 99    	vpgatherdd %ymm15,(%rcx,%ymm3,4),%ymm7
    2aa0:	48 8b 48 30          	mov    0x30(%rax),%rcx
    2aa4:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2aa9:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 2b31 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x621>
    2ab0:	00 
    2ab1:	c4 e2 05 90 1c a1    	vpgatherdd %ymm15,(%rcx,%ymm4,4),%ymm3
    2ab7:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2abc:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2b44 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x634>
    2ac3:	00 
    2ac4:	c4 62 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm11
    2ac9:	c5 45 66 d3          	vpcmpgtd %ymm3,%ymm7,%ymm10
    2acd:	c4 62 65 39 e7       	vpminsd %ymm7,%ymm3,%ymm12
    2ad2:	c4 c1 4d 66 e3       	vpcmpgtd %ymm11,%ymm6,%ymm4
    2ad7:	c4 62 1d 39 ee       	vpminsd %ymm6,%ymm12,%ymm13
    2adc:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    2ae1:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    2ae5:	c4 43 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm10
    2aeb:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm10,%ymm10        # 2b14 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x604>
    2af2:	00 00 40 
    2af5:	c4 41 0d fe d2       	vpaddd %ymm10,%ymm14,%ymm10
    2afa:	c4 a2 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm4
    2b00:	c5 65 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm10
    2b04:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    2b0a:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    2b0e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2b13:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 2b7b <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x66b>
    2b1a:	00 
    2b1b:	c4 c3 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm2
    2b21:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 2b4a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x63a>
    2b28:	00 00 c0 
    2b2b:	c4 41 25 fe e5       	vpaddd %ymm13,%ymm11,%ymm12
    2b30:	c5 85 fa d2          	vpsubd %ymm2,%ymm15,%ymm2
    2b34:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2b39:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    2b3e:	c4 62 05 90 04 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm8
    2b44:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
    2b4b:	00 00 
    2b4d:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    2b51:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2b57:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2b5c:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 2bc4 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6b4>
    2b63:	00 
    2b64:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2bcc <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6bc>
    2b6b:	00 
    2b6c:	c5 bd fa f4          	vpsubd %ymm4,%ymm8,%ymm6
    2b70:	c5 ad 72 f2 10       	vpslld $0x10,%ymm2,%ymm10
    2b75:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    2b7a:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    2b7e:	c5 2d fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm10,%ymm10
    2b85:	00 00 
    2b87:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    2b8c:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 2bf4 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6e4>
    2b93:	00 
    2b94:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    2b9b:	00 00 
    2b9d:	c5 7e 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm15
    2ba4:	00 00 
    2ba6:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    2bab:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
    2bb2:	00 00 
    2bb4:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    2bb9:	c4 41 4d fe d2       	vpaddd %ymm10,%ymm6,%ymm10
    2bbe:	c5 8d 66 f0          	vpcmpgtd %ymm0,%ymm14,%ymm6
    2bc2:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2bc6:	c5 2d fe d1          	vpaddd %ymm1,%ymm10,%ymm10
    2bca:	c5 d5 fa c8          	vpsubd %ymm0,%ymm5,%ymm1
    2bce:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    2bd4:	c5 c5 66 e1          	vpcmpgtd %ymm1,%ymm7,%ymm4
    2bd8:	c5 ad fa d8          	vpsubd %ymm0,%ymm10,%ymm3
    2bdc:	c5 85 66 d3          	vpcmpgtd %ymm3,%ymm15,%ymm2
    2be0:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
    2be4:	c5 e5 66 a4 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm3,%ymm4
    2beb:	00 00 
    2bed:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    2bf1:	c5 fd 66 a4 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm4
    2bf8:	00 00 
    2bfa:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    2bfe:	c5 f5 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm1,%ymm6
    2c05:	00 00 
    2c07:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    2c0b:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    2c0f:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    2c13:	85 d2                	test   %edx,%edx
    2c15:	0f 84 45 fa ff ff    	je     2660 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x150>
    2c1b:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    2c21:	48 8d 50 60          	lea    0x60(%rax),%rdx
    2c25:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    2c2b:	c5 7e 7f 14 24       	vmovdqu %ymm10,(%rsp)
    2c30:	48 8b 0a             	mov    (%rdx),%rcx
    2c33:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
    2c39:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    2c3d:	8b 72 54             	mov    0x54(%rdx),%esi
    2c40:	44 8b 4a 50          	mov    0x50(%rdx),%r9d
    2c44:	c4 e2 45 90 04 a9    	vpgatherdd %ymm7,(%rcx,%ymm5,4),%ymm0
    2c4a:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    2c4e:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2c54:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    2c58:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
    2c5d:	c5 ed 72 d0 11       	vpsrld $0x11,%ymm0,%ymm2
    2c62:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    2c67:	c4 e2 45 90 34 a9    	vpgatherdd %ymm7,(%rcx,%ymm5,4),%ymm6
    2c6d:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    2c71:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
    2c76:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    2c7a:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2c7f:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    2c84:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 2d0c <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7fc>
    2c8b:	00 
    2c8c:	c4 62 45 90 04 a9    	vpgatherdd %ymm7,(%rcx,%ymm5,4),%ymm8
    2c92:	c5 f9 6e ee          	vmovd  %esi,%xmm5
    2c96:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2d1e <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x80e>
    2c9d:	00 
    2c9e:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
    2ca2:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    2ca7:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    2cac:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    2cb0:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    2cb5:	c4 c1 5d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm4
    2cbb:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 2d43 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x833>
    2cc2:	00 
    2cc3:	c5 4d 66 d8          	vpcmpgtd %ymm0,%ymm6,%ymm11
    2cc7:	c4 62 7d 39 ee       	vpminsd %ymm6,%ymm0,%ymm13
    2ccc:	c4 42 15 39 d0       	vpminsd %ymm8,%ymm13,%ymm10
    2cd1:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
    2cd6:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    2cdc:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2ce0:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
    2ce4:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    2ce9:	c4 e2 7d 3d e6       	vpmaxsd %ymm6,%ymm0,%ymm4
    2cee:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2cf3:	c5 7e 7f 7c 24 60    	vmovdqu %ymm15,0x60(%rsp)
    2cf9:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    2cfe:	c5 bd 66 cc          	vpcmpgtd %ymm4,%ymm8,%ymm1
    2d02:	c4 a2 45 90 14 b9    	vpgatherdd %ymm7,(%rcx,%ymm15,4),%ymm2
    2d08:	c4 c2 5d 3d e0       	vpmaxsd %ymm8,%ymm4,%ymm4
    2d0d:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    2d14:	00 00 
    2d16:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    2d1a:	c4 22 45 90 24 b1    	vpgatherdd %ymm7,(%rcx,%ymm14,4),%ymm12
    2d20:	c4 c1 5d fe fa       	vpaddd %ymm10,%ymm4,%ymm7
    2d25:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm11,%ymm11        # 2d4e <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x83e>
    2d2c:	00 00 10 
    2d2f:	c5 fd fe ce          	vpaddd %ymm6,%ymm0,%ymm1
    2d33:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
    2d37:	c5 fd 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm0
    2d3b:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
    2d40:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    2d44:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2d49:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    2d4d:	c5 6d db 05 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm8        # 2db5 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8a5>
    2d54:	00 
    2d55:	c4 a2 05 90 0c 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm1
    2d5b:	c4 e3 65 4c c5 00    	vpblendvb %ymm0,%ymm5,%ymm3,%ymm0
    2d61:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 2d8a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x87a>
    2d68:	00 00 d0 
    2d6b:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    2d71:	c5 8d fa c0          	vpsubd %ymm0,%ymm14,%ymm0
    2d75:	c4 62 4d 90 1c 81    	vpgatherdd %ymm6,(%rcx,%ymm0,4),%ymm11
    2d7b:	c5 a5 db 35 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm6        # 2de3 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8d3>
    2d82:	00 
    2d83:	c5 75 db 35 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm14        # 2deb <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8db>
    2d8a:	00 
    2d8b:	c5 9d db 05 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm0        # 2df3 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8e3>
    2d92:	00 
    2d93:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    2d9a:	00 00 
    2d9c:	c4 41 0d fa c0       	vpsubd %ymm8,%ymm14,%ymm8
    2da1:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    2da5:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
    2da9:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    2dae:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
    2db3:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2db8:	c4 e2 4d 40 f7       	vpmulld %ymm7,%ymm6,%ymm6
    2dbd:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    2dc2:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    2dc7:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    2dcc:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    2dd0:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    2dd5:	c4 c1 7d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm0
    2ddb:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    2de2:	00 00 
    2de4:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    2de9:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2dee:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 2e56 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x946>
    2df5:	00 
    2df6:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2e5e <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x94e>
    2dfd:	00 
    2dfe:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    2e04:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2e6c <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x95c>
    2e0b:	00 
    2e0c:	c5 1d db 35 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm14        # 2e74 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x964>
    2e13:	00 
    2e14:	c5 9d 72 f2 10       	vpslld $0x10,%ymm2,%ymm12
    2e19:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    2e1e:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    2e23:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    2e28:	c5 7e 7f a4 24 e0 00 	vmovdqu %ymm12,0xe0(%rsp)
    2e2f:	00 00 
    2e31:	0f 84 c9 00 00 00    	je     2f00 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f0>
    2e37:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    2e3c:	c4 c1 55 72 d3 08    	vpsrld $0x8,%ymm11,%ymm5
    2e42:	48 83 c2 60          	add    $0x60,%rdx
    2e46:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2eae <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x99e>
    2e4d:	00 
    2e4e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2e53:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2ebb <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9ab>
    2e5a:	00 
    2e5b:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    2e61:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 2ec9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9b9>
    2e68:	00 
    2e69:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    2e6d:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    2e71:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 2ed9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9c9>
    2e78:	00 
    2e79:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2e7e:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2e83:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    2e87:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    2e8c:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2e90:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    2e95:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2e99:	c4 c1 0d fa db       	vpsubd %ymm11,%ymm14,%ymm3
    2e9e:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2ea3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2ea8:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    2eac:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2eb0:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    2eb5:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    2eb9:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    2ebe:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
    2ec3:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    2ec8:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
    2ecc:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2ed1:	c5 fd 6f d1          	vmovdqa %ymm1,%ymm2
    2ed5:	48 39 da             	cmp    %rbx,%rdx
    2ed8:	0f 84 92 02 00 00    	je     3170 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc60>
    2ede:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    2ee4:	c5 fe 7f 0c 24       	vmovdqu %ymm1,(%rsp)
    2ee9:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    2ef0:	00 00 
    2ef2:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    2ef8:	e9 33 fd ff ff       	jmp    2c30 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x720>
    2efd:	0f 1f 00             	nopl   (%rax)
    2f00:	4c 8b 4a 28          	mov    0x28(%rdx),%r9
    2f04:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    2f09:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    2f0d:	48 83 c2 60          	add    $0x60,%rdx
    2f11:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    2f17:	c4 c2 75 90 3c a1    	vpgatherdd %ymm1,(%r9,%ymm4,4),%ymm7
    2f1d:	4c 8b 4a c0          	mov    -0x40(%rdx),%r9
    2f21:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    2f27:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    2f2b:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 2fb3 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaa3>
    2f32:	00 
    2f33:	c4 42 75 90 14 a1    	vpgatherdd %ymm1,(%r9,%ymm4,4),%ymm10
    2f39:	4c 8b 4a b8          	mov    -0x48(%rdx),%r9
    2f3d:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    2f41:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 2fc9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xab9>
    2f48:	00 
    2f49:	c4 82 5d 90 0c b9    	vpgatherdd %ymm4,(%r9,%ymm15,4),%ymm1
    2f4f:	4c 8b 4a e0          	mov    -0x20(%rdx),%r9
    2f53:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 2fdb <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xacb>
    2f5a:	00 
    2f5b:	c4 42 75 3d ea       	vpmaxsd %ymm10,%ymm1,%ymm13
    2f60:	c5 2d 66 d9          	vpcmpgtd %ymm1,%ymm10,%ymm11
    2f64:	c4 42 75 39 e2       	vpminsd %ymm10,%ymm1,%ymm12
    2f69:	c4 c1 45 66 e5       	vpcmpgtd %ymm13,%ymm7,%ymm4
    2f6e:	c4 62 1d 39 ff       	vpminsd %ymm7,%ymm12,%ymm15
    2f73:	c4 62 15 3d ef       	vpmaxsd %ymm7,%ymm13,%ymm13
    2f78:	c5 7e 7f bc 24 40 02 	vmovdqu %ymm15,0x240(%rsp)
    2f7f:	00 00 
    2f81:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2f86:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    2f8a:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    2f90:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm11,%ymm11        # 2fb9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaa9>
    2f97:	00 00 40 
    2f9a:	c5 25 fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm11,%ymm11
    2fa0:	c4 a2 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm4
    2fa6:	c4 41 75 66 da       	vpcmpgtd %ymm10,%ymm1,%ymm11
    2fab:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    2fb0:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    2fb5:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2fba:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3022 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb12>
    2fc1:	00 
    2fc2:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    2fc8:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm11,%ymm11        # 2ff1 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xae1>
    2fcf:	00 00 c0 
    2fd2:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    2fd9:	00 00 
    2fdb:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    2fe0:	c4 22 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm12
    2fe6:	c5 7e 6f bc 24 40 02 	vmovdqu 0x240(%rsp),%ymm15
    2fed:	00 00 
    2fef:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    2ff5:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # 305d <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb4d>
    2ffc:	00 
    2ffd:	c4 41 15 fe df       	vpaddd %ymm15,%ymm13,%ymm11
    3002:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
    3007:	c5 c5 fe c9          	vpaddd %ymm1,%ymm7,%ymm1
    300b:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    3010:	c5 9d fa fc          	vpsubd %ymm4,%ymm12,%ymm7
    3014:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    3018:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    301d:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    3022:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    3027:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
    302c:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    3030:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    3035:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    3039:	c4 c2 45 90 04 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm0
    303f:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 30c7 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb7>
    3046:	00 
    3047:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    304b:	4c 8b 4a d8          	mov    -0x28(%rdx),%r9
    304f:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    3053:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3059:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    305f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3064:	c5 7d 6f e9          	vmovdqa %ymm1,%ymm13
    3068:	c4 c2 4d 90 3c a1    	vpgatherdd %ymm6,(%r9,%ymm4,4),%ymm7
    306e:	4c 8b 4a d0          	mov    -0x30(%rdx),%r9
    3072:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    3076:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 30fe <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbee>
    307d:	00 
    307e:	c4 82 5d 90 34 b9    	vpgatherdd %ymm4,(%r9,%ymm15,4),%ymm6
    3084:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3089:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 3111 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc01>
    3090:	00 
    3091:	c4 62 4d 3d d7       	vpmaxsd %ymm7,%ymm6,%ymm10
    3096:	c5 45 66 c6          	vpcmpgtd %ymm6,%ymm7,%ymm8
    309a:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    309f:	c4 c1 7d 66 e2       	vpcmpgtd %ymm10,%ymm0,%ymm4
    30a4:	c4 62 25 39 e0       	vpminsd %ymm0,%ymm11,%ymm12
    30a9:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    30ae:	c5 25 66 d8          	vpcmpgtd %ymm0,%ymm11,%ymm11
    30b2:	c4 63 65 4c c5 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm8
    30b8:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm8,%ymm8        # 30e1 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbd1>
    30bf:	00 00 40 
    30c2:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    30c8:	c4 a2 05 90 24 81    	vpgatherdd %ymm15,(%rcx,%ymm8,4),%ymm4
    30ce:	c5 4d 66 c7          	vpcmpgtd %ymm7,%ymm6,%ymm8
    30d2:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    30d7:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    30dc:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    30e0:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3148 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc38>
    30e7:	00 
    30e8:	c4 e3 65 4c dd 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm3
    30ee:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    30f5:	00 00 
    30f7:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm3,%ymm3        # 3120 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc10>
    30fe:	00 00 b0 
    3101:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    3105:	c4 e2 05 90 1c a9    	vpgatherdd %ymm15,(%rcx,%ymm5,4),%ymm3
    310b:	c4 c1 2d fe ec       	vpaddd %ymm12,%ymm10,%ymm5
    3110:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3115:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    3119:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3181 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc71>
    3120:	00 
    3121:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    3125:	c5 e5 fa ec          	vpsubd %ymm4,%ymm3,%ymm5
    3129:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    312d:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    3132:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    3137:	c5 8d fa db          	vpsubd %ymm3,%ymm14,%ymm3
    313b:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    3140:	c5 dd fe a4 24 e0 00 	vpaddd 0xe0(%rsp),%ymm4,%ymm4
    3147:	00 00 
    3149:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    314d:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3151:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3156:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
    315a:	48 39 d3             	cmp    %rdx,%rbx
    315d:	74 11                	je     3170 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc60>
    315f:	c5 fe 7f 4c 24 20    	vmovdqu %ymm1,0x20(%rsp)
    3165:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    316a:	e9 7a fd ff ff       	jmp    2ee9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9d9>
    316f:	90                   	nop
    3170:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
    3177:	00 00 
    3179:	e9 6c f5 ff ff       	jmp    26ea <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1da>
    317e:	66 90                	xchg   %ax,%ax
    3180:	c5 f8 77             	vzeroupper
    3183:	c5 f8 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm6
    318a:	00 00 
    318c:	c5 f8 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm7
    3193:	00 00 
    3195:	c5 78 28 84 24 80 02 	vmovaps 0x280(%rsp),%xmm8
    319c:	00 00 
    319e:	c5 78 28 8c 24 90 02 	vmovaps 0x290(%rsp),%xmm9
    31a5:	00 00 
    31a7:	c5 78 28 94 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm10
    31ae:	00 00 
    31b0:	c5 78 28 9c 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm11
    31b7:	00 00 
    31b9:	c5 78 28 a4 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm12
    31c0:	00 00 
    31c2:	c5 78 28 ac 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm13
    31c9:	00 00 
    31cb:	c5 78 28 b4 24 e0 02 	vmovaps 0x2e0(%rsp),%xmm14
    31d2:	00 00 
    31d4:	c5 78 28 bc 24 f0 02 	vmovaps 0x2f0(%rsp),%xmm15
    31db:	00 00 
    31dd:	48 81 c4 08 03 00 00 	add    $0x308,%rsp
    31e4:	5b                   	pop    %rbx
    31e5:	5e                   	pop    %rsi
    31e6:	c3                   	ret
    31e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    31ee:	00 00 

00000000000031f0 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    31f0:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    31f7:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
    31fe:	00 00 
    3200:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
    3207:	00 00 
    3209:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
    3210:	00 00 
    3212:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
    3219:	00 00 
    321b:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
    3222:	00 00 
    3224:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
    322b:	00 00 
    322d:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
    3234:	00 00 
    3236:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
    323d:	00 00 
    323f:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
    3246:	00 00 
    3248:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
    324f:	00 00 
    3251:	48 89 c8             	mov    %rcx,%rax
    3254:	49 89 d2             	mov    %rdx,%r10
    3257:	4d 85 c9             	test   %r9,%r9
    325a:	0f 84 d3 0a 00 00    	je     3d33 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb43>
    3260:	c4 c2 7d 58 42 08    	vpbroadcastd 0x8(%r10),%ymm0
    3266:	49 ff c9             	dec    %r9
    3269:	8b 52 24             	mov    0x24(%rdx),%edx
    326c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3271:	49 c1 e9 03          	shr    $0x3,%r9
    3275:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    3279:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    327f:	c4 c2 7d 58 42 0c    	vpbroadcastd 0xc(%r10),%ymm0
    3285:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    3289:	0f af ca             	imul   %edx,%ecx
    328c:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    3291:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    3297:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
    329d:	c4 c2 7d 58 42 10    	vpbroadcastd 0x10(%r10),%ymm0
    32a3:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    32a8:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    32ad:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    32b4:	00 00 
    32b6:	c4 c2 7d 58 42 14    	vpbroadcastd 0x14(%r10),%ymm0
    32bc:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    32c1:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    32c5:	c5 fe 7f 84 24 a0 00 	vmovdqu %ymm0,0xa0(%rsp)
    32cc:	00 00 
    32ce:	c4 c2 7d 58 42 18    	vpbroadcastd 0x18(%r10),%ymm0
    32d4:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    32d9:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    32e0:	00 00 
    32e2:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    32e6:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    32ed:	00 00 
    32ef:	c4 c2 7d 58 42 1c    	vpbroadcastd 0x1c(%r10),%ymm0
    32f5:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    32fa:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    3301:	00 00 
    3303:	c5 fe 7f 84 24 e0 00 	vmovdqu %ymm0,0xe0(%rsp)
    330a:	00 00 
    330c:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
    3312:	e9 9f 00 00 00       	jmp    33b6 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c6>
    3317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    331e:	00 00 
    3320:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    3325:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
    332a:	49 8b 12             	mov    (%r10),%rdx
    332d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3331:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    3336:	c4 e2 5d 40 a4 24 00 	vpmulld 0x100(%rsp),%ymm4,%ymm4
    333d:	01 00 00 
    3340:	c4 e2 45 40 bc 24 20 	vpmulld 0x120(%rsp),%ymm7,%ymm7
    3347:	01 00 00 
    334a:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    334e:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    3352:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
    3358:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
    335d:	c5 e5 db e8          	vpand  %ymm0,%ymm3,%ymm5
    3361:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3365:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    336a:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    336f:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
    3374:	49 83 c0 18          	add    $0x18,%r8
    3378:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
    337c:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
    3380:	c4 e2 75 00 0d 40 00 	vpshufb 0x40(%rip),%ymm1,%ymm1        # 33c9 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d9>
    3387:	00 00 
    3389:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
    338d:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    3393:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
    3398:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    339d:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    33a1:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
    33a7:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    33ad:	4d 39 d8             	cmp    %r11,%r8
    33b0:	0f 84 7a 09 00 00    	je     3d30 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb40>
    33b6:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    33bb:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
    33c1:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    33c5:	48 8b 10             	mov    (%rax),%rdx
    33c8:	44 8b 48 54          	mov    0x54(%rax),%r9d
    33cc:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
    33d2:	8b 48 50             	mov    0x50(%rax),%ecx
    33d5:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
    33db:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    33e0:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # 33e9 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f9>
    33e7:	00 00 
    33e9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    33ee:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    33f3:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
    33f8:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    33fc:	c4 e2 55 90 24 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm4
    3402:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3406:	c5 e5 db c8          	vpand  %ymm0,%ymm3,%ymm1
    340a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    340e:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    3412:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    3417:	c4 e2 65 90 34 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm6
    341d:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3421:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3425:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    342a:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    342f:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    3433:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 34bb <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cb>
    343a:	00 
    343b:	c4 e2 65 90 3c 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm7
    3441:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3446:	48 8b 50 48          	mov    0x48(%rax),%rdx
    344a:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    344f:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3454:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3459:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 34e1 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f1>
    3460:	00 
    3461:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3466:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 34ee <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fe>
    346d:	00 
    346e:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3473:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3478:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    347d:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3482:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3486:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    348a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    348e:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    3492:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    3498:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    349c:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    34a2:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    34a6:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
    34ac:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    34b0:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    34b5:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    34b9:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    34bd:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    34c1:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    34c7:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 34f0 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x300>
    34ce:	00 00 80 
    34d1:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    34d6:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    34dc:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    34e1:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    34e6:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    34ec:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 3515 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x325>
    34f3:	00 00 c0 
    34f6:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    34fa:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    34ff:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    3504:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    3508:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    350c:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    3512:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
    3518:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    351c:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
    3520:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
    3524:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3529:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    352d:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    3531:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    3536:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    353b:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3540:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3545:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    354a:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    354f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3554:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3558:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    355c:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    3560:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3564:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    356a:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    356e:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    3573:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3577:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    357c:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3581:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3585:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    3589:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    358d:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3592:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3597:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    359c:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    35a0:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    35a5:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    35aa:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    35ae:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    35b3:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    35b8:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    35bc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    35c1:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    35c5:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    35c9:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    35ce:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    35d3:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    35d7:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    35dc:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    35e0:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    35e6:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    35ed:	00 00 
    35ef:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    35f6:	00 00 
    35f8:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    35fd:	c5 6d 66 44 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm8
    3603:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3607:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    360c:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    3610:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3615:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    361a:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
    3620:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3624:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3628:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    362c:	c5 d5 fa e2          	vpsubd %ymm2,%ymm5,%ymm4
    3630:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3635:	c5 8d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm6
    3639:	c5 f5 fa fa          	vpsubd %ymm2,%ymm1,%ymm7
    363d:	c5 a5 66 df          	vpcmpgtd %ymm7,%ymm11,%ymm3
    3641:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    3645:	c5 c5 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm7,%ymm6
    364c:	00 00 
    364e:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    3652:	c5 b5 66 f2          	vpcmpgtd %ymm2,%ymm9,%ymm6
    3656:	c5 bd eb f6          	vpor   %ymm6,%ymm8,%ymm6
    365a:	c5 5d 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm4,%ymm8
    3661:	00 00 
    3663:	c4 c1 4d eb f0       	vpor   %ymm8,%ymm6,%ymm6
    3668:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    366c:	c5 fd d7 d3          	vpmovmskb %ymm3,%edx
    3670:	85 d2                	test   %edx,%edx
    3672:	0f 84 a8 fc ff ff    	je     3320 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x130>
    3678:	48 8b 50 60          	mov    0x60(%rax),%rdx
    367c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3680:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3684:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
    368b:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
    3691:	c4 e2 65 90 24 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm4
    3697:	48 8b 50 68          	mov    0x68(%rax),%rdx
    369b:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    36a0:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    36a5:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
    36ab:	48 8b 50 70          	mov    0x70(%rax),%rdx
    36af:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    36b3:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    36b8:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 3740 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x550>
    36bf:	00 
    36c0:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
    36c6:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    36cb:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    36cf:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    36d6:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    36db:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    36e0:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    36e5:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    36ea:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    36ef:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    36f3:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    36f8:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 3780 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x590>
    36ff:	00 
    3700:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 3788 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x598>
    3707:	00 
    3708:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    370d:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    3712:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3716:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    371a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    371e:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3722:	c5 2d fe ca          	vpaddd %ymm2,%ymm10,%ymm9
    3726:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    372c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3730:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
    3736:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    373a:	c4 a2 65 90 0c 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm1
    3740:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3744:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3749:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    374e:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    3752:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3757:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    375b:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    3761:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 378a <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x59a>
    3768:	00 00 80 
    376b:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3770:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    3776:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    377b:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3780:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    3786:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 37af <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5bf>
    378d:	00 00 c0 
    3790:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3794:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    3799:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    379e:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    37a2:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    37a6:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    37ac:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
    37b2:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    37b6:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    37ba:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    37c1:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    37c5:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    37ca:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    37ce:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    37d2:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    37d7:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    37dc:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    37e1:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    37e6:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    37eb:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    37f0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    37f5:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    37f9:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    37fd:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3801:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3805:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    380b:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    380f:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    3814:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3818:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    381d:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3822:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3826:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    382a:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    382e:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3833:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3838:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    383d:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    3841:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    3846:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    384b:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    384f:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3854:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3859:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    385d:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3862:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    3866:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    386a:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    386f:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3874:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3878:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    387d:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    3881:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    3886:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    388c:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3890:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    3895:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    3899:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    389d:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    38a2:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    38a7:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    38ab:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    38af:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
    38b5:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    38bc:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    38c0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    38c4:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
    38ca:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
    38d1:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    38d8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    38dd:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
    38e3:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    38e7:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    38ec:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 3974 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x784>
    38f3:	00 
    38f4:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
    38fa:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    38ff:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3904:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    390b:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    390f:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3914:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    3919:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    391e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3923:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    3927:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    392c:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3931:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3936:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 39be <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ce>
    393d:	00 
    393e:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 39c6 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7d6>
    3945:	00 
    3946:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    394b:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    3950:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3955:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3959:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    395d:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3961:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
    3965:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    396b:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    396f:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    3975:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    3979:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
    397f:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3983:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3988:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    398c:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    3991:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    3995:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3999:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    399f:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 39c8 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7d8>
    39a6:	00 00 80 
    39a9:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    39ae:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    39b4:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    39b9:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    39be:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    39c4:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 39ed <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7fd>
    39cb:	00 00 c0 
    39ce:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    39d2:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    39d7:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    39dc:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    39e0:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    39e4:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    39ea:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
    39f0:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    39f4:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    39f8:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    39ff:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    3a03:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3a08:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    3a0c:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    3a10:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    3a15:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3a1a:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    3a1f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3a24:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3a29:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3a2e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3a33:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3a37:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3a3b:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3a3f:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3a43:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    3a49:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3a4d:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    3a52:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3a56:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    3a5b:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3a60:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3a64:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3a68:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3a6c:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3a71:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3a76:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3a7b:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    3a7f:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    3a84:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    3a89:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3a8d:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3a92:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3a97:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3a9b:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3aa0:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    3aa4:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    3aa8:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3aad:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3ab2:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3ab6:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3abb:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    3abf:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    3ac4:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    3aca:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3ace:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    3ad3:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    3ad7:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3adb:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3ae0:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    3ae5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3ae9:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3aed:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
    3af3:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    3afa:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3afe:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3b02:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
    3b08:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    3b0f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3b14:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3b18:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3b1d:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
    3b23:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
    3b2a:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
    3b30:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3b35:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3b3a:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    3b41:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 3bc9 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9d9>
    3b48:	00 
    3b49:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    3b4d:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3b52:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    3b57:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3b5c:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3b61:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    3b65:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3b6a:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3b6f:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3b74:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 3bfc <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa0c>
    3b7b:	00 
    3b7c:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 3c04 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa14>
    3b83:	00 
    3b84:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3b89:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3b8e:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    3b93:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3b98:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3b9c:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3ba0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3ba4:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    3ba8:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    3bae:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3bb2:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    3bb8:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    3bbc:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
    3bc2:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3bc6:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    3bcb:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    3bcf:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3bd3:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    3bd7:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    3bdd:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 3c06 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa16>
    3be4:	00 00 80 
    3be7:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3bec:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    3bf2:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    3bf7:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3bfc:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    3c02:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 3c2b <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa3b>
    3c09:	00 00 c0 
    3c0c:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3c10:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    3c15:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    3c1a:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    3c1e:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3c22:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    3c28:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
    3c2e:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3c32:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    3c36:	c5 dd db d0          	vpand  %ymm0,%ymm4,%ymm2
    3c3a:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3c3f:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    3c43:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    3c47:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
    3c4c:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3c51:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    3c56:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3c5b:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3c60:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3c65:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3c6a:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3c6e:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3c72:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3c76:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3c7a:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    3c80:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3c84:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    3c89:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3c8d:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    3c92:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3c97:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3c9b:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3c9f:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3ca3:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3ca8:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3cad:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3cb2:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    3cb6:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    3cbb:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3cc0:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3cc4:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3cc9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3cce:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3cd2:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3cd7:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    3cdb:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    3cdf:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3ce4:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3ce9:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3ced:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3cf2:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3cf6:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    3cfc:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3d00:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3d05:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3d0a:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    3d0e:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3d13:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3d18:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3d1c:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3d20:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3d24:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    3d29:	e9 3c f6 ff ff       	jmp    336a <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a>
    3d2e:	66 90                	xchg   %ax,%ax
    3d30:	c5 f8 77             	vzeroupper
    3d33:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
    3d3a:	00 00 
    3d3c:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
    3d43:	00 00 
    3d45:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
    3d4c:	00 00 
    3d4e:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
    3d55:	00 00 
    3d57:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
    3d5e:	00 00 
    3d60:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
    3d67:	00 00 
    3d69:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
    3d70:	00 00 
    3d72:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
    3d79:	00 00 
    3d7b:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
    3d82:	00 00 
    3d84:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
    3d8b:	00 00 
    3d8d:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    3d94:	c3                   	ret
    3d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d9c:	00 00 00 00 

0000000000003da0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    3da0:	56                   	push   %rsi
    3da1:	53                   	push   %rbx
    3da2:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
    3da9:	c5 f8 29 b4 24 40 02 	vmovaps %xmm6,0x240(%rsp)
    3db0:	00 00 
    3db2:	c5 f8 29 bc 24 50 02 	vmovaps %xmm7,0x250(%rsp)
    3db9:	00 00 
    3dbb:	c5 78 29 84 24 60 02 	vmovaps %xmm8,0x260(%rsp)
    3dc2:	00 00 
    3dc4:	c5 78 29 8c 24 70 02 	vmovaps %xmm9,0x270(%rsp)
    3dcb:	00 00 
    3dcd:	c5 78 29 94 24 80 02 	vmovaps %xmm10,0x280(%rsp)
    3dd4:	00 00 
    3dd6:	c5 78 29 9c 24 90 02 	vmovaps %xmm11,0x290(%rsp)
    3ddd:	00 00 
    3ddf:	c5 78 29 a4 24 a0 02 	vmovaps %xmm12,0x2a0(%rsp)
    3de6:	00 00 
    3de8:	c5 78 29 ac 24 b0 02 	vmovaps %xmm13,0x2b0(%rsp)
    3def:	00 00 
    3df1:	c5 78 29 b4 24 c0 02 	vmovaps %xmm14,0x2c0(%rsp)
    3df8:	00 00 
    3dfa:	c5 78 29 bc 24 d0 02 	vmovaps %xmm15,0x2d0(%rsp)
    3e01:	00 00 
    3e03:	49 89 d2             	mov    %rdx,%r10
    3e06:	4d 85 c9             	test   %r9,%r9
    3e09:	0f 84 a4 09 00 00    	je     47b3 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa13>
    3e0f:	c4 c2 7d 58 52 08    	vpbroadcastd 0x8(%r10),%ymm2
    3e15:	8b 42 24             	mov    0x24(%rdx),%eax
    3e18:	49 ff c9             	dec    %r9
    3e1b:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    3e20:	8b 52 20             	mov    0x20(%rdx),%edx
    3e23:	49 c1 e9 03          	shr    $0x3,%r9
    3e27:	c4 c2 7d 58 62 14    	vpbroadcastd 0x14(%r10),%ymm4
    3e2d:	c4 c1 35 72 d3 18    	vpsrld $0x18,%ymm11,%ymm9
    3e33:	c5 fe 7f 94 24 20 01 	vmovdqu %ymm2,0x120(%rsp)
    3e3a:	00 00 
    3e3c:	c4 c2 7d 58 52 0c    	vpbroadcastd 0xc(%r10),%ymm2
    3e42:	c4 c2 7d 58 7a 18    	vpbroadcastd 0x18(%r10),%ymm7
    3e48:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    3e4c:	0f af d0             	imul   %eax,%edx
    3e4f:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    3e54:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    3e5a:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
    3e61:	00 00 
    3e63:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    3e6a:	00 00 
    3e6c:	c4 c2 7d 58 52 10    	vpbroadcastd 0x10(%r10),%ymm2
    3e72:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    3e77:	48 8d 99 80 01 00 00 	lea    0x180(%rcx),%rbx
    3e7e:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    3e85:	00 00 
    3e87:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    3e8b:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3e90:	c5 fe 7f 94 24 60 01 	vmovdqu %ymm2,0x160(%rsp)
    3e97:	00 00 
    3e99:	c4 c2 7d 58 52 1c    	vpbroadcastd 0x1c(%r10),%ymm2
    3e9f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    3ea4:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    3eab:	00 00 
    3ead:	c5 fe 7f 94 24 c0 01 	vmovdqu %ymm2,0x1c0(%rsp)
    3eb4:	00 00 
    3eb6:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    3eba:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3ebf:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    3ec6:	00 00 
    3ec8:	c5 fe 7f 94 24 00 02 	vmovdqu %ymm2,0x200(%rsp)
    3ecf:	00 00 
    3ed1:	e9 a2 00 00 00       	jmp    3f78 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d8>
    3ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3edd:	00 00 00 
    3ee0:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    3ee5:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    3eea:	49 8b 02             	mov    (%r10),%rax
    3eed:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    3ef1:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    3ef6:	c4 e2 6d 40 94 24 e0 	vpmulld 0x1e0(%rsp),%ymm2,%ymm2
    3efd:	01 00 00 
    3f00:	c4 e2 55 40 ac 24 00 	vpmulld 0x200(%rsp),%ymm5,%ymm5
    3f07:	02 00 00 
    3f0a:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3f0e:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    3f12:	c4 e2 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm0
    3f18:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    3f1d:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    3f22:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    3f27:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    3f2c:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    3f31:	c5 fd 72 f6 08       	vpslld $0x8,%ymm6,%ymm0
    3f36:	49 83 c0 18          	add    $0x18,%r8
    3f3a:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    3f3e:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    3f42:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 3f8b <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1eb>
    3f49:	00 00 
    3f4b:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    3f4f:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    3f55:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    3f5a:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    3f5f:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    3f63:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    3f69:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    3f6f:	4d 39 c3             	cmp    %r8,%r11
    3f72:	0f 84 38 08 00 00    	je     47b0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa10>
    3f78:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    3f7d:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    3f83:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3f87:	48 8b 01             	mov    (%rcx),%rax
    3f8a:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    3f8e:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    3f94:	8b 51 50             	mov    0x50(%rcx),%edx
    3f97:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    3f9d:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
    3fa2:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 3fab <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20b>
    3fa9:	00 00 
    3fab:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    3faf:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    3fb4:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3fb9:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    3fbe:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    3fc3:	c4 e2 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm3
    3fc9:	48 8b 41 08          	mov    0x8(%rcx),%rax
    3fcd:	c4 c1 6d db c1       	vpand  %ymm9,%ymm2,%ymm0
    3fd2:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3fd6:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3fdb:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3fe0:	c4 e2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm5
    3fe6:	48 8b 41 10          	mov    0x10(%rcx),%rax
    3fea:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3fee:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3ff2:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    3ff7:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3ffc:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 4084 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e4>
    4003:	00 
    4004:	c4 e2 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm6
    400a:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    400f:	48 8b 41 48          	mov    0x48(%rcx),%rax
    4013:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 409b <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fb>
    401a:	00 
    401b:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    4020:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    4025:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    4029:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    402e:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 40b6 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x316>
    4035:	00 
    4036:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    403b:	c4 62 65 39 ed       	vpminsd %ymm5,%ymm3,%ymm13
    4040:	c4 62 15 39 e6       	vpminsd %ymm6,%ymm13,%ymm12
    4045:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
    4049:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    404d:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4051:	c5 ad fe d1          	vpaddd %ymm1,%ymm10,%ymm2
    4055:	c4 62 45 90 3c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm15
    405b:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    405f:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    4064:	c5 65 fe d5          	vpaddd %ymm5,%ymm3,%ymm10
    4068:	c4 e2 45 90 04 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm0
    406e:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    4072:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4077:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    407b:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4080:	c4 c1 05 db e9       	vpand  %ymm9,%ymm15,%ymm5
    4085:	c4 c3 5d 4c d6 20    	vpblendvb %ymm2,%ymm14,%ymm4,%ymm2
    408b:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 40b4 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x314>
    4092:	00 00 70 
    4095:	c4 c1 3d fe fc       	vpaddd %ymm12,%ymm8,%ymm7
    409a:	c4 c3 5d 4c e6 30    	vpblendvb %ymm3,%ymm14,%ymm4,%ymm4
    40a0:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    40a7:	00 00 
    40a9:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    40ad:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    40b2:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm4,%ymm4        # 40db <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33b>
    40b9:	00 00 d0 
    40bc:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    40c0:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
    40c5:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    40ca:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    40ce:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    40d2:	c4 e2 2d 90 14 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm2
    40d8:	c4 e2 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm3
    40de:	c4 41 6d db d1       	vpand  %ymm9,%ymm2,%ymm10
    40e3:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
    40e8:	c4 c1 65 db e1       	vpand  %ymm9,%ymm3,%ymm4
    40ed:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    40f2:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
    40f6:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    40fa:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    40ff:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    4104:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4109:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    410e:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    4113:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
    4118:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    411d:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    4122:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    4127:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    412b:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    412f:	c4 c1 4d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm6
    4135:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4139:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    413e:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    4143:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
    4148:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    414d:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    4152:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    4157:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    415b:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    4160:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    4165:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    416a:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    416e:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    4173:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    4178:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    417d:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    4182:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4187:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    418c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4191:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    4195:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    4199:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    419e:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    41a3:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    41a7:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    41ac:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    41b0:	c4 c1 55 72 d7 10    	vpsrld $0x10,%ymm15,%ymm5
    41b6:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    41bb:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    41c0:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    41c5:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    41c9:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
    41cd:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    41d2:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    41d7:	c5 7e 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm8
    41de:	00 00 
    41e0:	c5 7e 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm15
    41e7:	00 00 
    41e9:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    41ed:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    41f4:	00 00 
    41f6:	c5 f5 66 bc 24 40 01 	vpcmpgtd 0x140(%rsp),%ymm1,%ymm7
    41fd:	00 00 
    41ff:	c5 bd 66 f2          	vpcmpgtd %ymm2,%ymm8,%ymm6
    4203:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    4207:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    420b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4210:	c5 fd fa e9          	vpsubd %ymm1,%ymm0,%ymm5
    4214:	c5 85 66 dd          	vpcmpgtd %ymm5,%ymm15,%ymm3
    4218:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    421c:	c5 d5 66 b4 24 c0 01 	vpcmpgtd 0x1c0(%rsp),%ymm5,%ymm6
    4223:	00 00 
    4225:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    4229:	c5 95 66 f1          	vpcmpgtd %ymm1,%ymm13,%ymm6
    422d:	c5 c5 eb f6          	vpor   %ymm6,%ymm7,%ymm6
    4231:	c5 ed 66 bc 24 80 01 	vpcmpgtd 0x180(%rsp),%ymm2,%ymm7
    4238:	00 00 
    423a:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    423e:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    4242:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    4246:	85 c0                	test   %eax,%eax
    4248:	0f 84 92 fc ff ff    	je     3ee0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x140>
    424e:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
    4254:	48 8d 41 60          	lea    0x60(%rcx),%rax
    4258:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    425e:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    4264:	48 8b 10             	mov    (%rax),%rdx
    4267:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    426d:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    4271:	8b 70 54             	mov    0x54(%rax),%esi
    4274:	44 8b 48 50          	mov    0x50(%rax),%r9d
    4278:	c4 e2 5d 90 04 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm0
    427e:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4282:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    4288:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    428c:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    4291:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 4319 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x579>
    4298:	00 
    4299:	c4 e2 5d 90 2c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm5
    429f:	48 8b 50 10          	mov    0x10(%rax),%rdx
    42a3:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    42a9:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    42ad:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    42b2:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 433a <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x59a>
    42b9:	00 
    42ba:	c4 e2 5d 90 3c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm7
    42c0:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    42c5:	c5 f9 6e e6          	vmovd  %esi,%xmm4
    42c9:	48 8b 50 48          	mov    0x48(%rax),%rdx
    42cd:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    42d2:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    42d7:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    42dc:	c4 e2 65 40 da       	vpmulld %ymm2,%ymm3,%ymm3
    42e1:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    42e6:	c4 62 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm14
    42eb:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    42f0:	c5 55 66 e0          	vpcmpgtd %ymm0,%ymm5,%ymm12
    42f4:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 437c <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5dc>
    42fb:	00 
    42fc:	c4 62 0d 39 d7       	vpminsd %ymm7,%ymm14,%ymm10
    4301:	c5 0d 66 f7          	vpcmpgtd %ymm7,%ymm14,%ymm14
    4305:	c4 63 6d 4c e4 c0    	vpblendvb %ymm12,%ymm4,%ymm2,%ymm12
    430b:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    430f:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    4313:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    4318:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    431c:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4321:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    4328:	00 00 
    432a:	c4 c1 75 fe df       	vpaddd %ymm15,%ymm1,%ymm3
    432f:	c4 22 4d 90 2c ba    	vpgatherdd %ymm6,(%rdx,%ymm15,4),%ymm13
    4335:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    4339:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
    433e:	c4 e2 75 90 34 9a    	vpgatherdd %ymm1,(%rdx,%ymm3,4),%ymm6
    4344:	c4 e2 7d 3d dd       	vpmaxsd %ymm5,%ymm0,%ymm3
    4349:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
    434d:	c4 e2 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm3
    4352:	c4 41 65 fe c2       	vpaddd %ymm10,%ymm3,%ymm8
    4357:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    435c:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    4361:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm12,%ymm12        # 438a <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ea>
    4368:	00 00 10 
    436b:	c5 fd fe cd          	vpaddd %ymm5,%ymm0,%ymm1
    436f:	c5 fd 66 c5          	vpcmpgtd %ymm5,%ymm0,%ymm0
    4373:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    4378:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    437d:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    4381:	c4 a2 05 90 0c a2    	vpgatherdd %ymm15,(%rdx,%ymm12,4),%ymm1
    4387:	c4 41 75 db f9       	vpand  %ymm9,%ymm1,%ymm15
    438c:	c4 e3 6d 4c c4 00    	vpblendvb %ymm0,%ymm4,%ymm2,%ymm0
    4392:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 43bb <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x61b>
    4399:	00 00 e0 
    439c:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
    43a0:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    43a4:	c4 62 45 90 24 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm12
    43aa:	c4 c1 15 db f9       	vpand  %ymm9,%ymm13,%ymm7
    43af:	c4 c1 4d db c1       	vpand  %ymm9,%ymm6,%ymm0
    43b4:	c4 c1 1d db e9       	vpand  %ymm9,%ymm12,%ymm5
    43b9:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    43be:	c5 85 fa ff          	vpsubd %ymm7,%ymm15,%ymm7
    43c2:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    43c6:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    43cb:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
    43d0:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    43d7:	00 00 
    43d9:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    43de:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    43e3:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    43e8:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    43ed:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    43f1:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    43f5:	c5 d5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm5
    43fa:	c5 fd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm0
    43ff:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4406:	00 00 
    4408:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    440d:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    4413:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    4417:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    441d:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    4422:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    4427:	c4 41 15 db f1       	vpand  %ymm9,%ymm13,%ymm14
    442c:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    4431:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    4438:	00 00 
    443a:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    443f:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    4445:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    444a:	c4 41 4d fe ff       	vpaddd %ymm15,%ymm6,%ymm15
    444f:	c5 7e 7f bc 24 00 01 	vmovdqu %ymm15,0x100(%rsp)
    4456:	00 00 
    4458:	0f 84 ca 00 00 00    	je     4528 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x788>
    445e:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    4463:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    4469:	48 83 c0 60          	add    $0x60,%rax
    446d:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    4472:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4477:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    447c:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    4480:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    4484:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    448a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    448f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    4494:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    4498:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    449d:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    44a2:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    44a7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    44ab:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    44b2:	00 00 
    44b4:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    44b8:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    44bc:	c4 c1 5d fa d4       	vpsubd %ymm12,%ymm4,%ymm2
    44c1:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    44c6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    44cb:	c5 1d fa e1          	vpsubd %ymm1,%ymm12,%ymm12
    44cf:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    44d4:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    44d9:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
    44dd:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    44e2:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    44e7:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    44ec:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    44f0:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    44f5:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    44f9:	48 39 d8             	cmp    %rbx,%rax
    44fc:	0f 84 9e 02 00 00    	je     47a0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa00>
    4502:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    4508:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    450e:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    4515:	00 00 
    4517:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
    451d:	e9 42 fd ff ff       	jmp    4264 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4c4>
    4522:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4528:	4c 8b 48 28          	mov    0x28(%rax),%r9
    452c:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    4532:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    4536:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    453b:	c5 7e 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm12
    4541:	48 83 c0 60          	add    $0x60,%rax
    4545:	c4 c2 65 90 34 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm6
    454b:	4c 8b 48 c0          	mov    -0x40(%rax),%r9
    454f:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
    4555:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    4559:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 45e1 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x841>
    4560:	00 
    4561:	c4 42 65 90 04 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm8
    4567:	4c 8b 48 b8          	mov    -0x48(%rax),%r9
    456b:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    456f:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 45f7 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x857>
    4576:	00 
    4577:	c4 82 65 90 0c a1    	vpgatherdd %ymm3,(%r9,%ymm12,4),%ymm1
    457d:	4c 8b 48 e0          	mov    -0x20(%rax),%r9
    4581:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 4609 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x869>
    4588:	00 
    4589:	c4 42 75 3d e8       	vpmaxsd %ymm8,%ymm1,%ymm13
    458e:	c5 3d 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm10
    4592:	c4 42 75 39 e0       	vpminsd %ymm8,%ymm1,%ymm12
    4597:	c4 c1 4d 66 dd       	vpcmpgtd %ymm13,%ymm6,%ymm3
    459c:	c4 62 15 3d ee       	vpmaxsd %ymm6,%ymm13,%ymm13
    45a1:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    45a7:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm10,%ymm10        # 45d0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x830>
    45ae:	00 00 30 
    45b1:	c4 e2 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm3
    45b6:	c5 2d fe 94 24 a0 00 	vpaddd 0xa0(%rsp),%ymm10,%ymm10
    45bd:	00 00 
    45bf:	c5 fe 7f 9c 24 20 02 	vmovdqu %ymm3,0x220(%rsp)
    45c6:	00 00 
    45c8:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    45cc:	c4 a2 05 90 1c 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm3
    45d2:	c4 41 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm10
    45d7:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    45dc:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    45e1:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    45e6:	c5 7e 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm8
    45ec:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    45f2:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # 461b <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x87b>
    45f9:	00 00 c0 
    45fc:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    4601:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    4606:	c4 22 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm12
    460c:	c5 7e 6f bc 24 20 02 	vmovdqu 0x220(%rsp),%ymm15
    4613:	00 00 
    4615:	c4 41 65 db d1       	vpand  %ymm9,%ymm3,%ymm10
    461a:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    4620:	c4 c1 15 fe df       	vpaddd %ymm15,%ymm13,%ymm3
    4625:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    462a:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
    462e:	c4 c1 1d fa da       	vpsubd %ymm10,%ymm12,%ymm3
    4633:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
    4637:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    463b:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    4641:	c4 42 2d 40 d5       	vpmulld %ymm13,%ymm10,%ymm10
    4646:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    464b:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    4650:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    4655:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    465a:	c5 2d fe d7          	vpaddd %ymm7,%ymm10,%ymm10
    465e:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    4662:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4666:	c4 c2 45 90 04 a9    	vpgatherdd %ymm7,(%r9,%ymm5,4),%ymm0
    466c:	4c 8b 48 d8          	mov    -0x28(%rax),%r9
    4670:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    4674:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 46fc <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x95c>
    467b:	00 
    467c:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    4681:	c4 82 55 90 3c 81    	vpgatherdd %ymm5,(%r9,%ymm8,4),%ymm7
    4687:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    468d:	4c 8b 48 d0          	mov    -0x30(%rax),%r9
    4691:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    4696:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 471e <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x97e>
    469d:	00 
    469e:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    46a3:	c4 82 3d 90 2c a9    	vpgatherdd %ymm8,(%r9,%ymm13,4),%ymm5
    46a9:	c5 fd 6f f3          	vmovdqa %ymm3,%ymm6
    46ad:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4735 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x995>
    46b4:	00 
    46b5:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    46ba:	c5 45 66 c5          	vpcmpgtd %ymm5,%ymm7,%ymm8
    46be:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    46c3:	c4 c1 7d 66 ca       	vpcmpgtd %ymm10,%ymm0,%ymm1
    46c8:	c4 62 1d 39 e8       	vpminsd %ymm0,%ymm12,%ymm13
    46cd:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    46d2:	c5 1d 66 e0          	vpcmpgtd %ymm0,%ymm12,%ymm12
    46d6:	c4 63 6d 4c c4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm8
    46dc:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # 4705 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x965>
    46e3:	00 00 10 
    46e6:	c5 3d fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm8,%ymm8
    46ed:	00 00 
    46ef:	c4 a2 05 90 0c 82    	vpgatherdd %ymm15,(%rdx,%ymm8,4),%ymm1
    46f5:	c5 55 66 c7          	vpcmpgtd %ymm7,%ymm5,%ymm8
    46f9:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    46fd:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    4704:	00 00 
    4706:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    470b:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    4710:	c4 e3 6d 4c d4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm2
    4716:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 473f <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x99f>
    471d:	00 00 c0 
    4720:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    4725:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
    4729:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    472e:	c4 e2 1d 90 24 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm4
    4734:	c4 c1 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm2
    4739:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    473e:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    4742:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    4747:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    474b:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
    474f:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    4754:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    4759:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    475e:	c5 c5 fa d4          	vpsubd %ymm4,%ymm7,%ymm2
    4762:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    4767:	c5 f5 fe 8c 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm1
    476e:	00 00 
    4770:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4774:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4778:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    477d:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4781:	48 39 c3             	cmp    %rax,%rbx
    4784:	74 1a                	je     47a0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa00>
    4786:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    478c:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    4792:	e9 77 fd ff ff       	jmp    450e <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x76e>
    4797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    479e:	00 00 
    47a0:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    47a7:	00 00 
    47a9:	e9 7e f7 ff ff       	jmp    3f2c <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18c>
    47ae:	66 90                	xchg   %ax,%ax
    47b0:	c5 f8 77             	vzeroupper
    47b3:	c5 f8 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm6
    47ba:	00 00 
    47bc:	c5 f8 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm7
    47c3:	00 00 
    47c5:	c5 78 28 84 24 60 02 	vmovaps 0x260(%rsp),%xmm8
    47cc:	00 00 
    47ce:	c5 78 28 8c 24 70 02 	vmovaps 0x270(%rsp),%xmm9
    47d5:	00 00 
    47d7:	c5 78 28 94 24 80 02 	vmovaps 0x280(%rsp),%xmm10
    47de:	00 00 
    47e0:	c5 78 28 9c 24 90 02 	vmovaps 0x290(%rsp),%xmm11
    47e7:	00 00 
    47e9:	c5 78 28 a4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm12
    47f0:	00 00 
    47f2:	c5 78 28 ac 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm13
    47f9:	00 00 
    47fb:	c5 78 28 b4 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm14
    4802:	00 00 
    4804:	c5 78 28 bc 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm15
    480b:	00 00 
    480d:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
    4814:	5b                   	pop    %rbx
    4815:	5e                   	pop    %rsi
    4816:	c3                   	ret
    4817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    481e:	00 00 

0000000000004820 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    4820:	48 81 ec a8 02 00 00 	sub    $0x2a8,%rsp
    4827:	c5 f8 29 b4 24 00 02 	vmovaps %xmm6,0x200(%rsp)
    482e:	00 00 
    4830:	c5 f8 29 bc 24 10 02 	vmovaps %xmm7,0x210(%rsp)
    4837:	00 00 
    4839:	c5 78 29 84 24 20 02 	vmovaps %xmm8,0x220(%rsp)
    4840:	00 00 
    4842:	c5 78 29 8c 24 30 02 	vmovaps %xmm9,0x230(%rsp)
    4849:	00 00 
    484b:	c5 78 29 94 24 40 02 	vmovaps %xmm10,0x240(%rsp)
    4852:	00 00 
    4854:	c5 78 29 9c 24 50 02 	vmovaps %xmm11,0x250(%rsp)
    485b:	00 00 
    485d:	c5 78 29 a4 24 60 02 	vmovaps %xmm12,0x260(%rsp)
    4864:	00 00 
    4866:	c5 78 29 ac 24 70 02 	vmovaps %xmm13,0x270(%rsp)
    486d:	00 00 
    486f:	c5 78 29 b4 24 80 02 	vmovaps %xmm14,0x280(%rsp)
    4876:	00 00 
    4878:	c5 78 29 bc 24 90 02 	vmovaps %xmm15,0x290(%rsp)
    487f:	00 00 
    4881:	48 89 c8             	mov    %rcx,%rax
    4884:	49 89 d2             	mov    %rdx,%r10
    4887:	4d 85 c9             	test   %r9,%r9
    488a:	0f 84 03 0d 00 00    	je     5593 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd73>
    4890:	c4 c2 7d 58 7a 08    	vpbroadcastd 0x8(%r10),%ymm7
    4896:	49 ff c9             	dec    %r9
    4899:	8b 52 24             	mov    0x24(%rdx),%edx
    489c:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    48a1:	49 c1 e9 03          	shr    $0x3,%r9
    48a5:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    48a9:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    48af:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    48b6:	00 00 
    48b8:	c4 c2 7d 58 7a 0c    	vpbroadcastd 0xc(%r10),%ymm7
    48be:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    48c2:	0f af ca             	imul   %edx,%ecx
    48c5:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    48ca:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    48d0:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    48d7:	00 00 
    48d9:	c4 c2 7d 58 7a 10    	vpbroadcastd 0x10(%r10),%ymm7
    48df:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    48e6:	00 00 
    48e8:	c4 c2 7d 58 7a 14    	vpbroadcastd 0x14(%r10),%ymm7
    48ee:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    48f5:	00 00 
    48f7:	c4 c2 7d 58 7a 18    	vpbroadcastd 0x18(%r10),%ymm7
    48fd:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    4904:	00 00 
    4906:	c4 c2 7d 58 7a 1c    	vpbroadcastd 0x1c(%r10),%ymm7
    490c:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    4913:	00 00 
    4915:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    491a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    491f:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    4924:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    4928:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    492d:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    4934:	00 00 
    4936:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    493a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    493f:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    4946:	00 00 
    4948:	e9 9a 00 00 00       	jmp    49e7 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c7>
    494d:	0f 1f 00             	nopl   (%rax)
    4950:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    4954:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    4959:	49 8b 12             	mov    (%r10),%rdx
    495c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4960:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    4965:	c4 e2 6d 40 94 24 c0 	vpmulld 0x1c0(%rsp),%ymm2,%ymm2
    496c:	01 00 00 
    496f:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    4976:	01 00 00 
    4979:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    497d:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    4981:	c4 e2 45 90 14 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm2
    4987:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    498c:	c4 c1 6d db e7       	vpand  %ymm15,%ymm2,%ymm4
    4991:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    4996:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    499b:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    49a0:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    49a5:	49 83 c0 18          	add    $0x18,%r8
    49a9:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    49ad:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    49b1:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 49fa <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1da>
    49b8:	00 00 
    49ba:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    49be:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    49c4:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    49c9:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    49ce:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    49d2:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    49d8:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    49de:	4d 39 d8             	cmp    %r11,%r8
    49e1:	0f 84 a9 0b 00 00    	je     5590 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd70>
    49e7:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    49ec:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    49f2:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    49f6:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    49fb:	48 8b 10             	mov    (%rax),%rdx
    49fe:	44 8b 48 54          	mov    0x54(%rax),%r9d
    4a02:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    4a08:	8b 48 50             	mov    0x50(%rax),%ecx
    4a0b:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    4a11:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 4a1a <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1fa>
    4a18:	00 00 
    4a1a:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    4a1f:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    4a24:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    4a29:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    4a2f:	c4 e2 5d 90 14 b2    	vpgatherdd %ymm4,(%rdx,%ymm6,4),%ymm2
    4a35:	c4 c1 75 db e7       	vpand  %ymm15,%ymm1,%ymm4
    4a3a:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4a3e:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    4a42:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    4a48:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    4a4e:	48 8b 50 10          	mov    0x10(%rax),%rdx
    4a52:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    4a59:	00 00 
    4a5b:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    4a5f:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    4a64:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    4a69:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4af1 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d1>
    4a70:	00 
    4a71:	c4 e2 75 90 1c ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm3
    4a77:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
    4a7b:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    4a80:	48 8b 50 48          	mov    0x48(%rax),%rdx
    4a84:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    4a89:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4a8e:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    4a93:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    4a98:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    4a9d:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 4b25 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x305>
    4aa4:	00 
    4aa5:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    4aaa:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 4b32 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x312>
    4ab1:	00 
    4ab2:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    4ab7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    4abb:	c5 7d fe ce          	vpaddd %ymm6,%ymm0,%ymm9
    4abf:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    4ac3:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    4ac8:	c4 22 7d 90 1c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm11
    4ace:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    4ad2:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    4ad6:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4adb:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    4ae0:	c4 41 7d fe e9       	vpaddd %ymm9,%ymm0,%ymm13
    4ae5:	c4 a2 2d 90 04 aa    	vpgatherdd %ymm10,(%rdx,%ymm13,4),%ymm0
    4aeb:	c5 7e 7f 4c 24 60    	vmovdqu %ymm9,0x60(%rsp)
    4af1:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    4af6:	c5 7d 6f e0          	vmovdqa %ymm0,%ymm12
    4afa:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    4afe:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    4b02:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    4b08:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 4b31 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x311>
    4b0f:	00 00 40 
    4b12:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    4b17:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    4b1c:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    4b22:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    4b26:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    4b2b:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    4b30:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    4b34:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    4b3a:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 4b63 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x343>
    4b41:	00 00 80 
    4b44:	c5 95 fa c0          	vpsubd %ymm0,%ymm13,%ymm0
    4b48:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    4b4e:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
    4b55:	00 00 
    4b57:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    4b5c:	c5 05 db 8c 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm9
    4b63:	00 00 
    4b65:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    4b6a:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    4b6f:	48 8b 48 28          	mov    0x28(%rax),%rcx
    4b73:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    4b79:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    4b7d:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    4b81:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    4b87:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    4b8c:	c4 c1 05 db d4       	vpand  %ymm12,%ymm15,%ymm2
    4b91:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    4b96:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    4b9b:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    4ba0:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    4ba5:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    4baa:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    4baf:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    4bb4:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    4bb8:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    4bbc:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    4bc0:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
    4bc7:	00 00 
    4bc9:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4bcd:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    4bd3:	c4 e2 65 90 34 a1    	vpgatherdd %ymm3,(%rcx,%ymm4,4),%ymm6
    4bd9:	48 8b 48 20          	mov    0x20(%rax),%rcx
    4bdd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4be2:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    4be6:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4c6e <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x44e>
    4bed:	00 
    4bee:	c4 62 65 90 04 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm8
    4bf4:	48 8b 48 18          	mov    0x18(%rax),%rcx
    4bf8:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 4c80 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x460>
    4bff:	00 
    4c00:	c4 e2 2d 90 14 a9    	vpgatherdd %ymm10,(%rcx,%ymm5,4),%ymm2
    4c06:	48 8b 48 40          	mov    0x40(%rax),%rcx
    4c0a:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 4c92 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x472>
    4c11:	00 
    4c12:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    4c17:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    4c1b:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    4c20:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    4c25:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    4c2a:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    4c2f:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    4c36:	00 00 
    4c38:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    4c3c:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    4c42:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 4c6b <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x44b>
    4c49:	00 00 30 
    4c4c:	c5 dd fe 64 24 60    	vpaddd 0x60(%rsp),%ymm4,%ymm4
    4c52:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    4c58:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    4c5d:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    4c62:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    4c67:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    4c6c:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    4c71:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    4c77:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 4ca0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x480>
    4c7e:	00 00 50 
    4c81:	c4 c1 55 72 d4 08    	vpsrld $0x8,%ymm12,%ymm5
    4c87:	c5 95 fa e4          	vpsubd %ymm4,%ymm13,%ymm4
    4c8b:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    4c90:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    4c96:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
    4c9d:	00 00 
    4c9f:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
    4ca6:	00 00 
    4ca8:	c5 2d fe a4 24 e0 00 	vpaddd 0xe0(%rsp),%ymm10,%ymm12
    4caf:	00 00 
    4cb1:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    4cb7:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    4cbc:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    4cc2:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    4cc7:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    4ccc:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    4cd0:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    4cd4:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    4cd9:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    4cde:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    4ce3:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    4ce8:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    4cee:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    4cf3:	c4 e2 55 40 ac 24 e0 	vpmulld 0xe0(%rsp),%ymm5,%ymm5
    4cfa:	00 00 00 
    4cfd:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    4d02:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    4d07:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    4d0b:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    4d12:	00 00 
    4d14:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    4d18:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    4d1c:	c4 e2 1d 90 2c b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm5
    4d22:	48 8b 48 38          	mov    0x38(%rax),%rcx
    4d26:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    4d2c:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    4d31:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    4d37:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    4d3c:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4dc4 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5a4>
    4d43:	00 
    4d44:	c4 e2 1d 90 34 91    	vpgatherdd %ymm12,(%rcx,%ymm2,4),%ymm6
    4d4a:	48 8b 48 30          	mov    0x30(%rax),%rcx
    4d4e:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    4d53:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4ddb <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5bb>
    4d5a:	00 
    4d5b:	c4 e2 2d 90 14 99    	vpgatherdd %ymm10,(%rcx,%ymm3,4),%ymm2
    4d61:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 4de9 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5c9>
    4d68:	00 
    4d69:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    4d6e:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    4d72:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    4d77:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    4d7c:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    4d81:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    4d86:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    4d8a:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    4d90:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 4db9 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x599>
    4d97:	00 00 30 
    4d9a:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    4da0:	c4 a2 1d 90 1c 82    	vpgatherdd %ymm12,(%rdx,%ymm8,4),%ymm3
    4da6:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    4daa:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    4daf:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4db4:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    4db9:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    4dbd:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    4dc2:	c5 fd 66 b4 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm6
    4dc9:	00 00 
    4dcb:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    4dcf:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    4dd5:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 4dfe <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5de>
    4ddc:	00 00 a0 
    4ddf:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    4de4:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    4de8:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    4def:	00 00 
    4df1:	c4 e2 2d 90 3c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm7
    4df7:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    4dfe:	00 00 
    4e00:	c4 c1 2d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm10
    4e06:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    4e0b:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    4e12:	00 00 
    4e14:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4e19:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    4e1e:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    4e23:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    4e28:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    4e2c:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    4e30:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    4e37:	00 00 
    4e39:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    4e3e:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    4e42:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
    4e46:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    4e4b:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    4e50:	c5 7e 6f 9c 24 00 01 	vmovdqu 0x100(%rsp),%ymm11
    4e57:	00 00 
    4e59:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    4e5e:	c5 3d fe 04 24       	vpaddd (%rsp),%ymm8,%ymm8
    4e63:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    4e68:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    4e6c:	c5 c5 66 da          	vpcmpgtd %ymm2,%ymm7,%ymm3
    4e70:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    4e75:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    4e7b:	c5 bd fa e8          	vpsubd %ymm0,%ymm8,%ymm5
    4e7f:	c5 95 66 cd          	vpcmpgtd %ymm5,%ymm13,%ymm1
    4e83:	c5 e5 eb c9          	vpor   %ymm1,%ymm3,%ymm1
    4e87:	c5 d5 66 9c 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm5,%ymm3
    4e8e:	00 00 
    4e90:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
    4e94:	c5 a5 66 d8          	vpcmpgtd %ymm0,%ymm11,%ymm3
    4e98:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    4e9c:	c5 ed 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm2,%ymm6
    4ea3:	00 00 
    4ea5:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    4ea9:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
    4ead:	c5 fd d7 d1          	vpmovmskb %ymm1,%edx
    4eb1:	85 d2                	test   %edx,%edx
    4eb3:	0f 84 97 fa ff ff    	je     4950 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x130>
    4eb9:	48 8b 50 60          	mov    0x60(%rax),%rdx
    4ebd:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4ec1:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
    4ec8:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
    4ece:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
    4ed4:	48 8b 50 68          	mov    0x68(%rax),%rdx
    4ed8:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4edc:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    4ee1:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    4ee6:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    4eeb:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 4f73 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x753>
    4ef2:	00 
    4ef3:	c4 e2 45 90 2c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm5
    4ef9:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    4efd:	48 8b 50 70          	mov    0x70(%rax),%rdx
    4f01:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4f05:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    4f0a:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    4f0f:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    4f14:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    4f19:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    4f1e:	c4 a2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm8,4),%ymm6
    4f24:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    4f2b:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    4f30:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    4f34:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4fbc <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x79c>
    4f3b:	00 
    4f3c:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4f41:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4f45:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4fcd <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ad>
    4f4c:	00 
    4f4d:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    4f52:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    4f57:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    4f5c:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    4f60:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4f64:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4f68:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    4f6c:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    4f72:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4f76:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    4f7c:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    4f80:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    4f86:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    4f8a:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4f8f:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    4f93:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4f98:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    4f9d:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    4fa3:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 4fcc <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ac>
    4faa:	00 00 70 
    4fad:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4fb2:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    4fb8:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    4fbd:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    4fc1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4fc5:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 4fee <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ce>
    4fcc:	00 00 b0 
    4fcf:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    4fd4:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    4fd9:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    4fdd:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    4fe3:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    4fe9:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    4fee:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    4ff2:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    4ff8:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    4ffd:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    5002:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    5009:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    500e:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    5012:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    5017:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    501b:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    5020:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    5025:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    502a:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    502f:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    5034:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5039:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    503e:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    5043:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    5047:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    504b:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    5051:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    5055:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    505a:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    505f:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    5064:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    5069:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    506e:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    5073:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    5077:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    507c:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    5081:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5086:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    508a:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    508f:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    5094:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    5099:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    509e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    50a3:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    50a8:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    50ad:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    50b1:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    50b5:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    50ba:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    50bf:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    50c3:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    50c7:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    50cc:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    50d0:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    50d5:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    50db:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    50e0:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    50e5:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    50e9:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    50ee:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    50f3:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    50f7:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    50fb:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    5101:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    5108:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    510c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5110:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    5116:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
    511d:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
    5123:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5128:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    512f:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    5133:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    5138:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 51c0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9a0>
    513f:	00 
    5140:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    5145:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    5149:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    514e:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    5154:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    5159:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    515e:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    5165:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    516a:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    516f:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    5173:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    5178:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    517d:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5182:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 520a <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9ea>
    5189:	00 
    518a:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    518e:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 5216 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f6>
    5195:	00 
    5196:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    519b:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    51a0:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    51a5:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    51a9:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    51ad:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    51b1:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    51b5:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    51bb:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    51bf:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    51c5:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    51c9:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    51cf:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    51d3:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    51d8:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    51dc:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    51e1:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    51e6:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    51ec:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 5215 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f5>
    51f3:	00 00 70 
    51f6:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    51fb:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    5201:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    5206:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    520a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    520e:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 5237 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa17>
    5215:	00 00 b0 
    5218:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    521d:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    5222:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    5226:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    522c:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    5232:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    5237:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    523b:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    5241:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    5246:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    524b:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    5252:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    5257:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    525b:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    5260:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    5264:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    5269:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    526e:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    5273:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    5278:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    527d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5282:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    5287:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    528c:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    5290:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    5294:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    529a:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    529e:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    52a3:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    52a8:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    52ad:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    52b2:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    52b7:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    52bc:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    52c0:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    52c5:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    52ca:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    52cf:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    52d3:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    52d8:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    52dd:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    52e2:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    52e7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    52ec:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    52f1:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    52f6:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    52fa:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    52fe:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5303:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5308:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    530c:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    5310:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    5315:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    5319:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    531e:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    5324:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    5329:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    532e:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    5332:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    5337:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    533c:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    5340:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    5344:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    534a:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    5351:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    5355:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5359:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    535f:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    5366:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    536b:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    536f:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    5374:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    537a:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
    5381:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
    5387:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    538c:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    5391:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    5398:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 5420 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc00>
    539f:	00 
    53a0:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    53a4:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    53a8:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    53ad:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    53b2:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    53b7:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    53bc:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    53c0:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    53c5:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    53ca:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    53cf:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 5457 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc37>
    53d6:	00 
    53d7:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 545f <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc3f>
    53de:	00 
    53df:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    53e4:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    53e9:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    53ee:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    53f2:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    53f6:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    53fa:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    53fe:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    5404:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    5408:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    540e:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    5412:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    5418:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    541c:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5421:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    5425:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    542a:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    542f:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    5435:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 545e <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc3e>
    543c:	00 00 70 
    543f:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5444:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    544a:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    544f:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    5453:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    5457:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 5480 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc60>
    545e:	00 00 b0 
    5461:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    5466:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    546b:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    546f:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    5475:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    547b:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    5480:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    5484:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
    548a:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    548f:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    5494:	c4 c1 65 db cf       	vpand  %ymm15,%ymm3,%ymm1
    5499:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    549d:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    54a2:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    54a6:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    54ab:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    54b0:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    54b5:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    54ba:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    54bf:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    54c4:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    54c9:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    54ce:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    54d2:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    54d6:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    54dc:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    54e0:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    54e5:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    54ea:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    54ef:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    54f4:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    54f9:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    54fe:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    5502:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    5507:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    550c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5511:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    5515:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    551a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    551f:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    5524:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    5529:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    552e:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    5533:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    5538:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    553c:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    5540:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5545:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    554a:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    554e:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    5553:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    5557:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
    555d:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    5562:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5567:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    556c:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    5570:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    5575:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    557a:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    557e:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    5582:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    5586:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    558b:	e9 0b f4 ff ff       	jmp    499b <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17b>
    5590:	c5 f8 77             	vzeroupper
    5593:	c5 f8 28 b4 24 00 02 	vmovaps 0x200(%rsp),%xmm6
    559a:	00 00 
    559c:	c5 f8 28 bc 24 10 02 	vmovaps 0x210(%rsp),%xmm7
    55a3:	00 00 
    55a5:	c5 78 28 84 24 20 02 	vmovaps 0x220(%rsp),%xmm8
    55ac:	00 00 
    55ae:	c5 78 28 8c 24 30 02 	vmovaps 0x230(%rsp),%xmm9
    55b5:	00 00 
    55b7:	c5 78 28 94 24 40 02 	vmovaps 0x240(%rsp),%xmm10
    55be:	00 00 
    55c0:	c5 78 28 9c 24 50 02 	vmovaps 0x250(%rsp),%xmm11
    55c7:	00 00 
    55c9:	c5 78 28 a4 24 60 02 	vmovaps 0x260(%rsp),%xmm12
    55d0:	00 00 
    55d2:	c5 78 28 ac 24 70 02 	vmovaps 0x270(%rsp),%xmm13
    55d9:	00 00 
    55db:	c5 78 28 b4 24 80 02 	vmovaps 0x280(%rsp),%xmm14
    55e2:	00 00 
    55e4:	c5 78 28 bc 24 90 02 	vmovaps 0x290(%rsp),%xmm15
    55eb:	00 00 
    55ed:	48 81 c4 a8 02 00 00 	add    $0x2a8,%rsp
    55f4:	c3                   	ret
    55f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    55fc:	00 00 00 00 

0000000000005600 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    5600:	56                   	push   %rsi
    5601:	53                   	push   %rbx
    5602:	48 81 ec c8 02 00 00 	sub    $0x2c8,%rsp
    5609:	c5 f8 29 b4 24 20 02 	vmovaps %xmm6,0x220(%rsp)
    5610:	00 00 
    5612:	c5 f8 29 bc 24 30 02 	vmovaps %xmm7,0x230(%rsp)
    5619:	00 00 
    561b:	c5 78 29 84 24 40 02 	vmovaps %xmm8,0x240(%rsp)
    5622:	00 00 
    5624:	c5 78 29 8c 24 50 02 	vmovaps %xmm9,0x250(%rsp)
    562b:	00 00 
    562d:	c5 78 29 94 24 60 02 	vmovaps %xmm10,0x260(%rsp)
    5634:	00 00 
    5636:	c5 78 29 9c 24 70 02 	vmovaps %xmm11,0x270(%rsp)
    563d:	00 00 
    563f:	c5 78 29 a4 24 80 02 	vmovaps %xmm12,0x280(%rsp)
    5646:	00 00 
    5648:	c5 78 29 ac 24 90 02 	vmovaps %xmm13,0x290(%rsp)
    564f:	00 00 
    5651:	c5 78 29 b4 24 a0 02 	vmovaps %xmm14,0x2a0(%rsp)
    5658:	00 00 
    565a:	c5 78 29 bc 24 b0 02 	vmovaps %xmm15,0x2b0(%rsp)
    5661:	00 00 
    5663:	48 89 c8             	mov    %rcx,%rax
    5666:	49 89 d2             	mov    %rdx,%r10
    5669:	4d 85 c9             	test   %r9,%r9
    566c:	0f 84 b1 0b 00 00    	je     6223 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc23>
    5672:	c4 c2 7d 58 52 08    	vpbroadcastd 0x8(%r10),%ymm2
    5678:	c4 c2 7d 58 6a 0c    	vpbroadcastd 0xc(%r10),%ymm5
    567e:	49 ff c9             	dec    %r9
    5681:	48 8d 98 80 01 00 00 	lea    0x180(%rax),%rbx
    5688:	8b 52 24             	mov    0x24(%rdx),%edx
    568b:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    568f:	49 c1 e9 03          	shr    $0x3,%r9
    5693:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    569a:	00 00 
    569c:	c4 c2 7d 58 52 10    	vpbroadcastd 0x10(%r10),%ymm2
    56a2:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    56a6:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
    56ad:	00 00 
    56af:	c4 c2 7d 58 6a 14    	vpbroadcastd 0x14(%r10),%ymm5
    56b5:	0f af ca             	imul   %edx,%ecx
    56b8:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    56bd:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    56c4:	00 00 
    56c6:	c4 c2 7d 58 52 18    	vpbroadcastd 0x18(%r10),%ymm2
    56cc:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    56d2:	c5 fe 7f ac 24 60 01 	vmovdqu %ymm5,0x160(%rsp)
    56d9:	00 00 
    56db:	c4 c2 7d 58 6a 1c    	vpbroadcastd 0x1c(%r10),%ymm5
    56e1:	c5 fe 7f 94 24 80 01 	vmovdqu %ymm2,0x180(%rsp)
    56e8:	00 00 
    56ea:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    56ef:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    56f4:	c5 fe 7f ac 24 a0 01 	vmovdqu %ymm5,0x1a0(%rsp)
    56fb:	00 00 
    56fd:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    5701:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    5708:	00 00 
    570a:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    570e:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    5713:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    5718:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
    571f:	00 00 
    5721:	c5 fe 7f 94 24 e0 01 	vmovdqu %ymm2,0x1e0(%rsp)
    5728:	00 00 
    572a:	e9 9f 00 00 00       	jmp    57ce <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ce>
    572f:	90                   	nop
    5730:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    5734:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    5739:	49 8b 12             	mov    (%r10),%rdx
    573c:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    5740:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
    5745:	c4 e2 75 40 8c 24 c0 	vpmulld 0x1c0(%rsp),%ymm1,%ymm1
    574c:	01 00 00 
    574f:	c4 e2 65 40 9c 24 e0 	vpmulld 0x1e0(%rsp),%ymm3,%ymm3
    5756:	01 00 00 
    5759:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    575d:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    5761:	c4 e2 6d 90 0c 82    	vpgatherdd %ymm2,(%rdx,%ymm0,4),%ymm1
    5767:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    576c:	c5 f5 db 15 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm2        # 57d4 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d4>
    5773:	00 
    5774:	c5 7d db 2d 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm13        # 57dc <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dc>
    577b:	00 
    577c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5781:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    5786:	c4 c1 7d 72 f5 08    	vpslld $0x8,%ymm13,%ymm0
    578c:	49 83 c0 18          	add    $0x18,%r8
    5790:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    5794:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    5798:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 57e1 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e1>
    579f:	00 00 
    57a1:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    57a5:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    57ab:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    57b0:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    57b5:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    57b9:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    57bf:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    57c5:	4d 39 c3             	cmp    %r8,%r11
    57c8:	0f 84 52 0a 00 00    	je     6220 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc20>
    57ce:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    57d3:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    57d9:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    57dd:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    57e2:	48 8b 10             	mov    (%rax),%rdx
    57e5:	44 8b 48 54          	mov    0x54(%rax),%r9d
    57e9:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    57ef:	8b 48 50             	mov    0x50(%rax),%ecx
    57f2:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    57f8:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
    57fd:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 5806 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x206>
    5804:	00 00 
    5806:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    580b:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    5810:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    5815:	c5 fd db 15 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm2        # 587d <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x27d>
    581c:	00 
    581d:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    5822:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
    5828:	c5 f5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm5        # 5890 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x290>
    582f:	00 
    5830:	48 8b 50 08          	mov    0x8(%rax),%rdx
    5834:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    5838:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    583c:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    5841:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    5847:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    584c:	c4 e2 75 90 34 aa    	vpgatherdd %ymm1,(%rdx,%ymm5,4),%ymm6
    5852:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5856:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    585c:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    5860:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    5865:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 58ed <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ed>
    586c:	00 
    586d:	c4 e2 75 90 24 ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm4
    5873:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    5878:	48 8b 50 48          	mov    0x48(%rax),%rdx
    587c:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 5904 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x304>
    5883:	00 
    5884:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    5889:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    588e:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    5893:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 591b <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x31b>
    589a:	00 
    589b:	c4 e2 65 3d fe       	vpmaxsd %ymm6,%ymm3,%ymm7
    58a0:	c4 62 65 39 d6       	vpminsd %ymm6,%ymm3,%ymm10
    58a5:	c4 62 2d 39 e4       	vpminsd %ymm4,%ymm10,%ymm12
    58aa:	c5 2d 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm10
    58ae:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    58b2:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    58b6:	c5 7d fe f5          	vpaddd %ymm5,%ymm0,%ymm14
    58ba:	c5 dd 66 ef          	vpcmpgtd %ymm7,%ymm4,%ymm5
    58be:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    58c2:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    58c7:	c4 22 75 90 2c b2    	vpgatherdd %ymm1,(%rdx,%ymm14,4),%ymm13
    58cd:	c4 e2 45 3d fc       	vpmaxsd %ymm4,%ymm7,%ymm7
    58d2:	c4 41 7d fe fe       	vpaddd %ymm14,%ymm0,%ymm15
    58d7:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    58db:	c4 a2 7d 90 0c ba    	vpgatherdd %ymm0,(%rdx,%ymm15,4),%ymm1
    58e1:	c5 cd 66 c3          	vpcmpgtd %ymm3,%ymm6,%ymm0
    58e5:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    58eb:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm0,%ymm0        # 5914 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x314>
    58f2:	00 00 50 
    58f5:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
    58f9:	c4 e2 25 90 2c 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm5
    58ff:	c5 e5 66 c6          	vpcmpgtd %ymm6,%ymm3,%ymm0
    5903:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
    5909:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    590e:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    5912:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    5918:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm0,%ymm0        # 5941 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x341>
    591f:	00 00 a0 
    5922:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
    5926:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    592b:	c4 62 25 90 14 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm10
    5931:	c5 15 db 1d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm11        # 5999 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x399>
    5938:	00 
    5939:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 59a1 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3a1>
    5940:	00 
    5941:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 59a9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3a9>
    5948:	00 
    5949:	c4 41 45 fe ec       	vpaddd %ymm12,%ymm7,%ymm13
    594e:	48 8b 48 28          	mov    0x28(%rax),%rcx
    5952:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    5957:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    595d:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5963:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    5968:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    596c:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    5970:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    5975:	c5 f5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm3        # 59dd <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3dd>
    597c:	00 
    597d:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    5982:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    5987:	c5 fd fe 84 24 80 00 	vpaddd 0x80(%rsp),%ymm0,%ymm0
    598e:	00 00 
    5990:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    5995:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    599a:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    599f:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    59a3:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    59a8:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    59ac:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
    59b2:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    59b6:	c4 e2 1d 90 3c a9    	vpgatherdd %ymm12,(%rcx,%ymm5,4),%ymm7
    59bc:	48 8b 48 20          	mov    0x20(%rax),%rcx
    59c0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    59c5:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    59ca:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 5a52 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x452>
    59d1:	00 
    59d2:	c4 62 1d 90 14 b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm10
    59d8:	48 8b 48 18          	mov    0x18(%rax),%rcx
    59dc:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    59e1:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 5a69 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x469>
    59e8:	00 
    59e9:	c4 e2 1d 90 1c a1    	vpgatherdd %ymm12,(%rcx,%ymm4,4),%ymm3
    59ef:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 5a77 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x477>
    59f6:	00 
    59f7:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
    59fc:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
    5a00:	c4 c2 65 39 f2       	vpminsd %ymm10,%ymm3,%ymm6
    5a05:	c4 c1 45 66 e4       	vpcmpgtd %ymm12,%ymm7,%ymm4
    5a0a:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    5a0f:	c4 62 1d 3d e7       	vpmaxsd %ymm7,%ymm12,%ymm12
    5a14:	c5 7e 7f 9c 24 c0 00 	vmovdqu %ymm11,0xc0(%rsp)
    5a1b:	00 00 
    5a1d:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    5a21:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    5a27:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 5a50 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x450>
    5a2e:	00 00 40 
    5a31:	c5 8d fe ed          	vpaddd %ymm5,%ymm14,%ymm5
    5a35:	c4 e2 15 90 24 aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm4
    5a3b:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
    5a40:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    5a45:	c4 c1 15 72 d7 08    	vpsrld $0x8,%ymm15,%ymm13
    5a4b:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    5a50:	c5 15 db 2d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm13        # 5ab8 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4b8>
    5a57:	00 
    5a58:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    5a5e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 5a87 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x487>
    5a65:	00 00 60 
    5a68:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    5a6e:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    5a72:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    5a76:	c4 62 4d 90 1c aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm11
    5a7c:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    5a83:	00 00 
    5a85:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    5a8a:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    5a90:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
    5a96:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 5afe <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4fe>
    5a9d:	00 
    5a9e:	c5 1d fe bc 24 c0 00 	vpaddd 0xc0(%rsp),%ymm12,%ymm15
    5aa5:	00 00 
    5aa7:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 5b0f <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x50f>
    5aae:	00 
    5aaf:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5ab4:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
    5abb:	00 00 
    5abd:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
    5ac2:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 5b2a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x52a>
    5ac9:	00 
    5aca:	48 8b 48 40          	mov    0x40(%rax),%rcx
    5ace:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5ad3:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
    5ad7:	c5 a5 fa fc          	vpsubd %ymm4,%ymm11,%ymm7
    5adb:	c4 e2 65 40 ff       	vpmulld %ymm7,%ymm3,%ymm7
    5ae0:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    5ae5:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    5aea:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    5af0:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    5af5:	c4 e2 4d 40 b4 24 c0 	vpmulld 0xc0(%rsp),%ymm6,%ymm6
    5afc:	00 00 00 
    5aff:	c5 c5 fe ed          	vpaddd %ymm5,%ymm7,%ymm5
    5b03:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    5b09:	c5 cd fe f4          	vpaddd %ymm4,%ymm6,%ymm6
    5b0d:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    5b12:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    5b16:	c4 e2 05 90 34 b9    	vpgatherdd %ymm15,(%rcx,%ymm7,4),%ymm6
    5b1c:	48 8b 48 38          	mov    0x38(%rax),%rcx
    5b20:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5b25:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 5bad <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ad>
    5b2c:	00 
    5b2d:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    5b32:	c4 e2 05 90 3c 99    	vpgatherdd %ymm15,(%rcx,%ymm3,4),%ymm7
    5b38:	48 8b 48 30          	mov    0x30(%rax),%rcx
    5b3c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5b41:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 5bc9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5c9>
    5b48:	00 
    5b49:	c4 e2 05 90 1c a1    	vpgatherdd %ymm15,(%rcx,%ymm4,4),%ymm3
    5b4f:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5b54:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 5bdc <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5dc>
    5b5b:	00 
    5b5c:	c4 62 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm11
    5b61:	c5 45 66 d3          	vpcmpgtd %ymm3,%ymm7,%ymm10
    5b65:	c4 62 65 39 e7       	vpminsd %ymm7,%ymm3,%ymm12
    5b6a:	c4 c1 4d 66 e3       	vpcmpgtd %ymm11,%ymm6,%ymm4
    5b6f:	c4 62 1d 39 ee       	vpminsd %ymm6,%ymm12,%ymm13
    5b74:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    5b79:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    5b7d:	c4 43 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm10
    5b83:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm10,%ymm10        # 5bac <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ac>
    5b8a:	00 00 40 
    5b8d:	c4 41 0d fe d2       	vpaddd %ymm10,%ymm14,%ymm10
    5b92:	c4 a2 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm4
    5b98:	c5 65 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm10
    5b9c:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    5ba2:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    5ba6:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    5bab:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 5c13 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x613>
    5bb2:	00 
    5bb3:	c4 c3 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm2
    5bb9:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 5be2 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5e2>
    5bc0:	00 00 c0 
    5bc3:	c4 41 25 fe e5       	vpaddd %ymm13,%ymm11,%ymm12
    5bc8:	c5 85 fa d2          	vpsubd %ymm2,%ymm15,%ymm2
    5bcc:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5bd1:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    5bd6:	c4 62 05 90 04 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm8
    5bdc:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
    5be3:	00 00 
    5be5:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    5be9:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    5bef:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5bf4:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 5c5c <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x65c>
    5bfb:	00 
    5bfc:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 5c64 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x664>
    5c03:	00 
    5c04:	c5 bd fa f4          	vpsubd %ymm4,%ymm8,%ymm6
    5c08:	c5 ad 72 f2 10       	vpslld $0x10,%ymm2,%ymm10
    5c0d:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    5c12:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    5c16:	c5 2d fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm10,%ymm10
    5c1d:	00 00 
    5c1f:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    5c24:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 5c8c <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x68c>
    5c2b:	00 
    5c2c:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    5c33:	00 00 
    5c35:	c5 7e 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm15
    5c3c:	00 00 
    5c3e:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    5c43:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
    5c4a:	00 00 
    5c4c:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    5c51:	c4 41 4d fe d2       	vpaddd %ymm10,%ymm6,%ymm10
    5c56:	c5 fd 66 b4 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm6
    5c5d:	00 00 
    5c5f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    5c63:	c5 2d fe d1          	vpaddd %ymm1,%ymm10,%ymm10
    5c67:	c5 d5 fa c8          	vpsubd %ymm0,%ymm5,%ymm1
    5c6b:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    5c71:	c5 c5 66 d1          	vpcmpgtd %ymm1,%ymm7,%ymm2
    5c75:	c5 ad fa d8          	vpsubd %ymm0,%ymm10,%ymm3
    5c79:	c5 85 66 e3          	vpcmpgtd %ymm3,%ymm15,%ymm4
    5c7d:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    5c81:	c5 e5 66 a4 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm3,%ymm4
    5c88:	00 00 
    5c8a:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    5c8e:	c5 8d 66 e0          	vpcmpgtd %ymm0,%ymm14,%ymm4
    5c92:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    5c96:	c5 f5 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm1,%ymm6
    5c9d:	00 00 
    5c9f:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    5ca3:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    5ca7:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    5cab:	85 d2                	test   %edx,%edx
    5cad:	0f 84 7d fa ff ff    	je     5730 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x130>
    5cb3:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    5cb9:	48 8d 50 60          	lea    0x60(%rax),%rdx
    5cbd:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    5cc3:	c5 7e 7f 14 24       	vmovdqu %ymm10,(%rsp)
    5cc8:	48 8b 0a             	mov    (%rdx),%rcx
    5ccb:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    5cd1:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    5cd5:	8b 72 54             	mov    0x54(%rdx),%esi
    5cd8:	44 8b 4a 50          	mov    0x50(%rdx),%r9d
    5cdc:	c4 e2 6d 90 04 b9    	vpgatherdd %ymm2,(%rcx,%ymm7,4),%ymm0
    5ce2:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    5ce6:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    5cec:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    5cf0:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
    5cf5:	c5 f9 6e ee          	vmovd  %esi,%xmm5
    5cf9:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    5cfe:	c4 e2 6d 90 34 b9    	vpgatherdd %ymm2,(%rcx,%ymm7,4),%ymm6
    5d04:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    5d08:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    5d0d:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    5d11:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    5d16:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5d1b:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    5d20:	c4 62 6d 90 04 b9    	vpgatherdd %ymm2,(%rcx,%ymm7,4),%ymm8
    5d26:	c5 ed 72 d0 11       	vpsrld $0x11,%ymm0,%ymm2
    5d2b:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 5db3 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7b3>
    5d32:	00 
    5d33:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
    5d37:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    5d3c:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    5d41:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 5dc9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c9>
    5d48:	00 
    5d49:	c4 c1 5d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm4
    5d4f:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 5dd7 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7d7>
    5d56:	00 
    5d57:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    5d5b:	c5 4d 66 d8          	vpcmpgtd %ymm0,%ymm6,%ymm11
    5d5f:	c4 62 7d 39 ee       	vpminsd %ymm6,%ymm0,%ymm13
    5d64:	c4 42 15 39 d0       	vpminsd %ymm8,%ymm13,%ymm10
    5d69:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
    5d6e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    5d72:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    5d78:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
    5d7c:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    5d81:	c4 e2 7d 3d e6       	vpmaxsd %ymm6,%ymm0,%ymm4
    5d86:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    5d8b:	c5 7e 7f 7c 24 60    	vmovdqu %ymm15,0x60(%rsp)
    5d91:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    5d96:	c5 bd 66 cc          	vpcmpgtd %ymm4,%ymm8,%ymm1
    5d9a:	c4 a2 45 90 14 b9    	vpgatherdd %ymm7,(%rcx,%ymm15,4),%ymm2
    5da0:	c4 c2 5d 3d e0       	vpmaxsd %ymm8,%ymm4,%ymm4
    5da5:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    5dac:	00 00 
    5dae:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    5db2:	c4 22 45 90 24 b1    	vpgatherdd %ymm7,(%rcx,%ymm14,4),%ymm12
    5db8:	c4 c1 5d fe fa       	vpaddd %ymm10,%ymm4,%ymm7
    5dbd:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm11,%ymm11        # 5de6 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7e6>
    5dc4:	00 00 10 
    5dc7:	c5 fd fe ce          	vpaddd %ymm6,%ymm0,%ymm1
    5dcb:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
    5dcf:	c5 fd 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm0
    5dd3:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
    5dd8:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    5ddc:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5de1:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    5de5:	c5 6d db 05 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm8        # 5e4d <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x84d>
    5dec:	00 
    5ded:	c4 a2 05 90 0c 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm1
    5df3:	c4 e3 65 4c c5 00    	vpblendvb %ymm0,%ymm5,%ymm3,%ymm0
    5df9:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 5e22 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x822>
    5e00:	00 00 d0 
    5e03:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    5e09:	c5 8d fa c0          	vpsubd %ymm0,%ymm14,%ymm0
    5e0d:	c4 62 4d 90 1c 81    	vpgatherdd %ymm6,(%rcx,%ymm0,4),%ymm11
    5e13:	c5 a5 db 35 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm6        # 5e7b <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x87b>
    5e1a:	00 
    5e1b:	c5 75 db 35 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm14        # 5e83 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x883>
    5e22:	00 
    5e23:	c5 9d db 05 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm0        # 5e8b <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x88b>
    5e2a:	00 
    5e2b:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    5e32:	00 00 
    5e34:	c4 41 0d fa c0       	vpsubd %ymm8,%ymm14,%ymm8
    5e39:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    5e3d:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
    5e41:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    5e46:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
    5e4b:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5e50:	c4 e2 4d 40 f7       	vpmulld %ymm7,%ymm6,%ymm6
    5e55:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    5e5a:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    5e5f:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    5e64:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5e68:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    5e6d:	c4 c1 7d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm0
    5e73:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    5e7a:	00 00 
    5e7c:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    5e81:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5e86:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 5eee <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8ee>
    5e8d:	00 
    5e8e:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 5ef6 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8f6>
    5e95:	00 
    5e96:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    5e9c:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 5f04 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x904>
    5ea3:	00 
    5ea4:	c5 1d db 35 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm14        # 5f0c <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x90c>
    5eab:	00 
    5eac:	c5 9d 72 f2 10       	vpslld $0x10,%ymm2,%ymm12
    5eb1:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    5eb6:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    5ebb:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    5ec0:	c5 7e 7f a4 24 e0 00 	vmovdqu %ymm12,0xe0(%rsp)
    5ec7:	00 00 
    5ec9:	0f 84 c9 00 00 00    	je     5f98 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x998>
    5ecf:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    5ed4:	c4 c1 55 72 d3 08    	vpsrld $0x8,%ymm11,%ymm5
    5eda:	48 83 c2 60          	add    $0x60,%rdx
    5ede:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 5f46 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x946>
    5ee5:	00 
    5ee6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5eeb:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 5f53 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x953>
    5ef2:	00 
    5ef3:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    5ef9:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 5f61 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x961>
    5f00:	00 
    5f01:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    5f05:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    5f09:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 5f71 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x971>
    5f10:	00 
    5f11:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5f16:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    5f1b:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    5f1f:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    5f24:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    5f28:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    5f2d:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    5f31:	c4 c1 0d fa db       	vpsubd %ymm11,%ymm14,%ymm3
    5f36:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    5f3b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5f40:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    5f44:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    5f48:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    5f4d:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    5f51:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    5f56:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
    5f5b:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    5f60:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    5f64:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5f69:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    5f6d:	48 39 da             	cmp    %rbx,%rdx
    5f70:	0f 84 9a 02 00 00    	je     6210 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc10>
    5f76:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5f7c:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    5f81:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    5f88:	00 00 
    5f8a:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    5f90:	e9 33 fd ff ff       	jmp    5cc8 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6c8>
    5f95:	0f 1f 00             	nopl   (%rax)
    5f98:	4c 8b 4a 28          	mov    0x28(%rdx),%r9
    5f9c:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
    5fa1:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    5fa5:	48 83 c2 60          	add    $0x60,%rdx
    5fa9:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    5faf:	c4 c2 5d 90 3c 89    	vpgatherdd %ymm4,(%r9,%ymm1,4),%ymm7
    5fb5:	4c 8b 4a c0          	mov    -0x40(%rdx),%r9
    5fb9:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    5fbf:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    5fc3:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 604b <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa4b>
    5fca:	00 
    5fcb:	c4 42 5d 90 14 89    	vpgatherdd %ymm4,(%r9,%ymm1,4),%ymm10
    5fd1:	4c 8b 4a b8          	mov    -0x48(%rdx),%r9
    5fd5:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    5fd9:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 6061 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa61>
    5fe0:	00 
    5fe1:	c4 82 5d 90 0c b9    	vpgatherdd %ymm4,(%r9,%ymm15,4),%ymm1
    5fe7:	4c 8b 4a e0          	mov    -0x20(%rdx),%r9
    5feb:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 6073 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa73>
    5ff2:	00 
    5ff3:	c4 42 75 3d ea       	vpmaxsd %ymm10,%ymm1,%ymm13
    5ff8:	c5 2d 66 d9          	vpcmpgtd %ymm1,%ymm10,%ymm11
    5ffc:	c4 42 75 39 e2       	vpminsd %ymm10,%ymm1,%ymm12
    6001:	c4 c1 45 66 e5       	vpcmpgtd %ymm13,%ymm7,%ymm4
    6006:	c4 62 1d 39 ff       	vpminsd %ymm7,%ymm12,%ymm15
    600b:	c4 62 15 3d ef       	vpmaxsd %ymm7,%ymm13,%ymm13
    6010:	c5 7e 7f bc 24 00 02 	vmovdqu %ymm15,0x200(%rsp)
    6017:	00 00 
    6019:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    601e:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    6022:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    6028:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm11,%ymm11        # 6051 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa51>
    602f:	00 00 40 
    6032:	c5 25 fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm11,%ymm11
    6038:	c4 a2 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm4
    603e:	c4 41 75 66 da       	vpcmpgtd %ymm10,%ymm1,%ymm11
    6043:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    6048:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    604d:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    6052:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    6058:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm11,%ymm11        # 6081 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa81>
    605f:	00 00 c0 
    6062:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    6069:	00 00 
    606b:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    6070:	c4 22 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm12
    6076:	c5 7e 6f bc 24 00 02 	vmovdqu 0x200(%rsp),%ymm15
    607d:	00 00 
    607f:	c5 5d db 1d 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm11        # 60e7 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xae7>
    6086:	00 
    6087:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    608d:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # 60f5 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaf5>
    6094:	00 
    6095:	c4 c1 15 fe e7       	vpaddd %ymm15,%ymm13,%ymm4
    609a:	c5 c5 fa fc          	vpsubd %ymm4,%ymm7,%ymm7
    609e:	c5 c5 fe c9          	vpaddd %ymm1,%ymm7,%ymm1
    60a2:	c4 c1 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm4
    60a7:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    60ab:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    60b0:	c5 25 fa de          	vpsubd %ymm6,%ymm11,%ymm11
    60b4:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    60b9:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    60be:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    60c3:	c4 42 25 40 dd       	vpmulld %ymm13,%ymm11,%ymm11
    60c8:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    60cc:	c4 41 25 fe d8       	vpaddd %ymm8,%ymm11,%ymm11
    60d1:	c4 c2 45 90 04 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm0
    60d7:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    60dc:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6164 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb64>
    60e3:	00 
    60e4:	4c 8b 4a d8          	mov    -0x28(%rdx),%r9
    60e8:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    60ec:	c5 dd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm4
    60f1:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    60f7:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    60fd:	c5 7d 6f ec          	vmovdqa %ymm4,%ymm13
    6101:	c4 c2 4d 90 3c 89    	vpgatherdd %ymm6,(%r9,%ymm1,4),%ymm7
    6107:	4c 8b 4a d0          	mov    -0x30(%rdx),%r9
    610b:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    610f:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 6197 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb97>
    6116:	00 
    6117:	c4 82 75 90 34 b9    	vpgatherdd %ymm1,(%r9,%ymm15,4),%ymm6
    611d:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    6122:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 61aa <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbaa>
    6129:	00 
    612a:	c4 62 4d 3d d7       	vpmaxsd %ymm7,%ymm6,%ymm10
    612f:	c5 45 66 c6          	vpcmpgtd %ymm6,%ymm7,%ymm8
    6133:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    6138:	c4 c1 7d 66 ca       	vpcmpgtd %ymm10,%ymm0,%ymm1
    613d:	c4 62 25 39 e0       	vpminsd %ymm0,%ymm11,%ymm12
    6142:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    6147:	c5 25 66 d8          	vpcmpgtd %ymm0,%ymm11,%ymm11
    614b:	c4 63 65 4c c5 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm8
    6151:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # 617a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb7a>
    6158:	00 00 10 
    615b:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    6161:	c4 a2 05 90 0c 81    	vpgatherdd %ymm15,(%rcx,%ymm8,4),%ymm1
    6167:	c5 4d 66 c7          	vpcmpgtd %ymm7,%ymm6,%ymm8
    616b:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    6170:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6175:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    6179:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 61e1 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbe1>
    6180:	00 
    6181:	c4 e3 65 4c dd 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm3
    6187:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    618e:	00 00 
    6190:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm3,%ymm3        # 61b9 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb9>
    6197:	00 00 b0 
    619a:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    619e:	c4 e2 05 90 1c a9    	vpgatherdd %ymm15,(%rcx,%ymm5,4),%ymm3
    61a4:	c4 c1 2d fe ec       	vpaddd %ymm12,%ymm10,%ymm5
    61a9:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    61ae:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    61b2:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 621a <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc1a>
    61b9:	00 
    61ba:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    61be:	c5 e5 fa e9          	vpsubd %ymm1,%ymm3,%ymm5
    61c2:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    61c6:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    61cb:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    61d0:	c5 8d fa db          	vpsubd %ymm3,%ymm14,%ymm3
    61d4:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    61d9:	c5 f5 fe 8c 24 e0 00 	vpaddd 0xe0(%rsp),%ymm1,%ymm1
    61e0:	00 00 
    61e2:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    61e6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    61ea:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    61ef:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    61f3:	48 39 d3             	cmp    %rdx,%rbx
    61f6:	74 18                	je     6210 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc10>
    61f8:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    61fe:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    6203:	e9 79 fd ff ff       	jmp    5f81 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x981>
    6208:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    620f:	00 
    6210:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    6217:	00 00 
    6219:	e9 63 f5 ff ff       	jmp    5781 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x181>
    621e:	66 90                	xchg   %ax,%ax
    6220:	c5 f8 77             	vzeroupper
    6223:	c5 f8 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm6
    622a:	00 00 
    622c:	c5 f8 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm7
    6233:	00 00 
    6235:	c5 78 28 84 24 40 02 	vmovaps 0x240(%rsp),%xmm8
    623c:	00 00 
    623e:	c5 78 28 8c 24 50 02 	vmovaps 0x250(%rsp),%xmm9
    6245:	00 00 
    6247:	c5 78 28 94 24 60 02 	vmovaps 0x260(%rsp),%xmm10
    624e:	00 00 
    6250:	c5 78 28 9c 24 70 02 	vmovaps 0x270(%rsp),%xmm11
    6257:	00 00 
    6259:	c5 78 28 a4 24 80 02 	vmovaps 0x280(%rsp),%xmm12
    6260:	00 00 
    6262:	c5 78 28 ac 24 90 02 	vmovaps 0x290(%rsp),%xmm13
    6269:	00 00 
    626b:	c5 78 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm14
    6272:	00 00 
    6274:	c5 78 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm15
    627b:	00 00 
    627d:	48 81 c4 c8 02 00 00 	add    $0x2c8,%rsp
    6284:	5b                   	pop    %rbx
    6285:	5e                   	pop    %rsi
    6286:	c3                   	ret
    6287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    628e:	00 00 

0000000000006290 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    6290:	44 8b 5a 30          	mov    0x30(%rdx),%r11d
    6294:	44 0f b6 91 b8 00 00 	movzbl 0xb8(%rcx),%r10d
    629b:	00 
    629c:	0f b6 41 58          	movzbl 0x58(%rcx),%eax
    62a0:	45 85 db             	test   %r11d,%r11d
    62a3:	74 2b                	je     62d0 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x40>
    62a5:	45 84 d2             	test   %r10b,%r10b
    62a8:	74 5e                	je     6308 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x78>
    62aa:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    62b1:	74 55                	je     6308 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x78>
    62b3:	44 0f b6 91 78 01 00 	movzbl 0x178(%rcx),%r10d
    62ba:	00 
    62bb:	84 c0                	test   %al,%al
    62bd:	74 69                	je     6328 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x98>
    62bf:	45 84 d2             	test   %r10b,%r10b
    62c2:	74 48                	je     630c <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c>
    62c4:	e9 37 9d ff ff       	jmp    0 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    62c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62d0:	45 84 d2             	test   %r10b,%r10b
    62d3:	74 23                	je     62f8 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x68>
    62d5:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    62dc:	74 1a                	je     62f8 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x68>
    62de:	44 0f b6 91 78 01 00 	movzbl 0x178(%rcx),%r10d
    62e5:	00 
    62e6:	84 c0                	test   %al,%al
    62e8:	74 4e                	je     6338 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa8>
    62ea:	45 84 d2             	test   %r10b,%r10b
    62ed:	74 0d                	je     62fc <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6c>
    62ef:	e9 fc ce ff ff       	jmp    31f0 <void jshc_compact_cache::(anonymous namespace)::cached<true, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    62f4:	0f 1f 40 00          	nopl   0x0(%rax)
    62f8:	84 c0                	test   %al,%al
    62fa:	74 24                	je     6320 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x90>
    62fc:	e9 9f da ff ff       	jmp    3da0 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	84 c0                	test   %al,%al
    630a:	74 0c                	je     6318 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x88>
    630c:	e9 ef a8 ff ff       	jmp    c00 <void jshc_compact_cache::(anonymous namespace)::cached<true, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    6311:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6318:	e9 f3 c1 ff ff       	jmp    2510 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    631d:	0f 1f 00             	nopl   (%rax)
    6320:	e9 db f2 ff ff       	jmp    5600 <void jshc_compact_cache::(anonymous namespace)::cached<false, false, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    6325:	0f 1f 00             	nopl   (%rax)
    6328:	45 84 d2             	test   %r10b,%r10b
    632b:	74 eb                	je     6318 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x88>
    632d:	e9 9e b3 ff ff       	jmp    16d0 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, true>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    6332:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6338:	45 84 d2             	test   %r10b,%r10b
    633b:	74 e3                	je     6320 <jshc_compact_cache::avx2_chain_cached(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x90>
    633d:	e9 de e4 ff ff       	jmp    4820 <void jshc_compact_cache::(anonymous namespace)::cached<false, true, false>(jshc_compact_cache::View const*, jshc_compact_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    6350:	56                   	push   %rsi
    6351:	53                   	push   %rbx
    6352:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
    6359:	c5 f8 29 b4 24 80 01 	vmovaps %xmm6,0x180(%rsp)
    6360:	00 00 
    6362:	c5 f8 29 bc 24 90 01 	vmovaps %xmm7,0x190(%rsp)
    6369:	00 00 
    636b:	c5 78 29 84 24 a0 01 	vmovaps %xmm8,0x1a0(%rsp)
    6372:	00 00 
    6374:	c5 78 29 8c 24 b0 01 	vmovaps %xmm9,0x1b0(%rsp)
    637b:	00 00 
    637d:	c5 78 29 94 24 c0 01 	vmovaps %xmm10,0x1c0(%rsp)
    6384:	00 00 
    6386:	c5 78 29 9c 24 d0 01 	vmovaps %xmm11,0x1d0(%rsp)
    638d:	00 00 
    638f:	c5 78 29 a4 24 e0 01 	vmovaps %xmm12,0x1e0(%rsp)
    6396:	00 00 
    6398:	c5 78 29 ac 24 f0 01 	vmovaps %xmm13,0x1f0(%rsp)
    639f:	00 00 
    63a1:	c5 78 29 b4 24 00 02 	vmovaps %xmm14,0x200(%rsp)
    63a8:	00 00 
    63aa:	c5 78 29 bc 24 10 02 	vmovaps %xmm15,0x210(%rsp)
    63b1:	00 00 
    63b3:	49 89 d2             	mov    %rdx,%r10
    63b6:	48 83 fa 04          	cmp    $0x4,%rdx
    63ba:	0f 84 b9 06 00 00    	je     6a79 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x729>
    63c0:	4d 85 c9             	test   %r9,%r9
    63c3:	0f 84 4c 06 00 00    	je     6a15 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c5>
    63c9:	c5 fd 6f 0d 00 00 00 	vmovdqa 0x0(%rip),%ymm1        # 63d1 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x81>
    63d0:	00 
    63d1:	49 ff c9             	dec    %r9
    63d4:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    63d9:	49 c1 e9 03          	shr    $0x3,%r9
    63dd:	c4 c1 1d 72 d2 18    	vpsrld $0x18,%ymm10,%ymm12
    63e3:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    63e7:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    63ee:	00 00 
    63f0:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 6438 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe8>
    63f7:	00 
    63f8:	4f 8d 0c 52          	lea    (%r10,%r10,2),%r9
    63fc:	4d 8d 5c c0 18       	lea    0x18(%r8,%rax,8),%r11
    6401:	b8 00 80 00 00       	mov    $0x8000,%eax
    6406:	49 c1 e1 05          	shl    $0x5,%r9
    640a:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    6411:	00 00 
    6413:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    6417:	49 01 c9             	add    %rcx,%r9
    641a:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    641f:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
    6426:	00 00 
    6428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    642f:	00 
    6430:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    6435:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    643b:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
    6441:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
    6447:	c4 e2 75 00 8c 24 40 	vpshufb 0x140(%rsp),%ymm1,%ymm1
    644e:	01 00 00 
    6451:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    6456:	c4 c1 75 db c4       	vpand  %ymm12,%ymm1,%ymm0
    645b:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    6460:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6465:	4d 85 d2             	test   %r10,%r10
    6468:	0f 84 57 05 00 00    	je     69c5 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x675>
    646e:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
    6474:	48 89 c8             	mov    %rcx,%rax
    6477:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    647d:	c5 fe 7f 4c 24 20    	vmovdqu %ymm1,0x20(%rsp)
    6483:	e9 c4 00 00 00       	jmp    654c <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fc>
    6488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    648f:	00 
    6490:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
    6495:	c5 f5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm1
    649a:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
    64a1:	00 00 
    64a3:	48 83 c0 60          	add    $0x60,%rax
    64a7:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    64ac:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    64b1:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    64b6:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    64ba:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    64be:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    64c3:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    64c8:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    64cd:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    64d1:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    64d6:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    64da:	c5 a5 fa d4          	vpsubd %ymm4,%ymm11,%ymm2
    64de:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    64e3:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    64e8:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    64ec:	c5 f5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm1
    64f1:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    64f6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    64fb:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    64ff:	c4 c1 75 fa cf       	vpsubd %ymm15,%ymm1,%ymm1
    6504:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
    6508:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
    650d:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    6512:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    6516:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    651b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    651f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    6524:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    6528:	4c 39 c8             	cmp    %r9,%rax
    652b:	0f 84 87 04 00 00    	je     69b8 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x668>
    6531:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    6537:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    653d:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    6544:	00 00 
    6546:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
    654c:	48 8b 10             	mov    (%rax),%rdx
    654f:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    6555:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    6559:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    655f:	8b 58 54             	mov    0x54(%rax),%ebx
    6562:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    6568:	48 8b 50 08          	mov    0x8(%rax),%rdx
    656c:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    6570:	8b 70 50             	mov    0x50(%rax),%esi
    6573:	c5 7d 7f d2          	vmovdqa %ymm10,%ymm2
    6577:	c5 79 6e c3          	vmovd  %ebx,%xmm8
    657b:	c4 e2 45 90 1c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm3
    6581:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6585:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    658b:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    6590:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    6595:	c5 cd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm6
    659a:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 6622 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d2>
    65a1:	00 
    65a2:	c4 e2 6d 90 24 ba    	vpgatherdd %ymm2,(%rdx,%ymm7,4),%ymm4
    65a8:	c5 f9 6e d6          	vmovd  %esi,%xmm2
    65ac:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    65b0:	48 8b 50 48          	mov    0x48(%rax),%rdx
    65b4:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    65b9:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    65be:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6646 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f6>
    65c5:	00 
    65c6:	c4 e2 4d 40 f2       	vpmulld %ymm2,%ymm6,%ymm6
    65cb:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    65d0:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 6658 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x308>
    65d7:	00 
    65d8:	c4 62 7d 39 f3       	vpminsd %ymm3,%ymm0,%ymm14
    65dd:	c5 7d fe fb          	vpaddd %ymm3,%ymm0,%ymm15
    65e1:	c4 62 0d 39 ec       	vpminsd %ymm4,%ymm14,%ymm13
    65e6:	c5 0d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm14
    65ea:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    65ee:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    65f2:	c5 f5 fe fd          	vpaddd %ymm5,%ymm1,%ymm7
    65f6:	c5 f9 6e ee          	vmovd  %esi,%xmm5
    65fa:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    65ff:	c4 62 4d 90 1c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm11
    6605:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    660a:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    660e:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    6612:	c5 e5 66 e8          	vpcmpgtd %ymm0,%ymm3,%ymm5
    6616:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    661d:	00 00 
    661f:	c5 fd 6f cf          	vmovdqa %ymm7,%ymm1
    6623:	c4 62 4d 90 0c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm9
    6629:	c4 e2 7d 3d f3       	vpmaxsd %ymm3,%ymm0,%ymm6
    662e:	c5 dd 66 fe          	vpcmpgtd %ymm6,%ymm4,%ymm7
    6632:	c5 fd 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm0
    6636:	c4 e2 4d 3d f4       	vpmaxsd %ymm4,%ymm6,%ymm6
    663b:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    6641:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 666a <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31a>
    6648:	00 00 70 
    664b:	c4 c1 4d fe fd       	vpaddd %ymm13,%ymm6,%ymm7
    6650:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    6656:	c5 dd fa ff          	vpsubd %ymm7,%ymm4,%ymm7
    665a:	c5 d5 fe 2c 24       	vpaddd (%rsp),%ymm5,%ymm5
    665f:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 6688 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x338>
    6666:	00 00 e0 
    6669:	c4 41 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm15
    666e:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    6672:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
    6679:	00 00 
    667b:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    6680:	c4 e2 05 90 3c aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm7
    6686:	c5 7d 7f d5          	vmovdqa %ymm10,%ymm5
    668a:	c4 e2 55 90 24 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm4
    6690:	c4 41 45 db fc       	vpand  %ymm12,%ymm7,%ymm15
    6695:	c4 c1 25 db ec       	vpand  %ymm12,%ymm11,%ymm5
    669a:	c4 c1 5d db dc       	vpand  %ymm12,%ymm4,%ymm3
    669f:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
    66a4:	c4 c1 35 db c4       	vpand  %ymm12,%ymm9,%ymm0
    66a9:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    66ad:	c5 85 fa ed          	vpsubd %ymm5,%ymm15,%ymm5
    66b1:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
    66b6:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    66bb:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    66c0:	c4 e2 65 40 9c 24 80 	vpmulld 0x80(%rsp),%ymm3,%ymm3
    66c7:	00 00 00 
    66ca:	c5 fe 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm1
    66d1:	00 00 
    66d3:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    66d7:	c5 0d fe f1          	vpaddd %ymm1,%ymm14,%ymm14
    66db:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    66e0:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    66e4:	c4 c1 55 72 d3 08    	vpsrld $0x8,%ymm11,%ymm5
    66ea:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    66ee:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    66f4:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    66f9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    66fe:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    6703:	c4 41 25 db fc       	vpand  %ymm12,%ymm11,%ymm15
    6708:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    670f:	00 00 
    6711:	c4 c1 7d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm0
    6717:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    671d:	c5 65 fe f1          	vpaddd %ymm1,%ymm3,%ymm14
    6721:	c4 41 35 db dc       	vpand  %ymm12,%ymm9,%ymm11
    6726:	c4 c1 35 72 f7 10    	vpslld $0x10,%ymm15,%ymm9
    672c:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    6731:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
    6735:	c5 7e 7f 9c 24 00 01 	vmovdqu %ymm11,0x100(%rsp)
    673c:	00 00 
    673e:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    6745:	00 00 
    6747:	0f 85 43 fd ff ff    	jne    6490 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
    674d:	48 8b 58 28          	mov    0x28(%rax),%rbx
    6751:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    6757:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    675b:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    675f:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    6765:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    676b:	48 83 c0 60          	add    $0x60,%rax
    676f:	c4 e2 45 90 34 a3    	vpgatherdd %ymm7,(%rbx,%ymm4,4),%ymm6
    6775:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
    6779:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    677d:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 6805 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4b5>
    6784:	00 
    6785:	c4 e2 5d 90 3c 9b    	vpgatherdd %ymm4,(%rbx,%ymm3,4),%ymm7
    678b:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
    678f:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    6793:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 681b <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4cb>
    679a:	00 
    679b:	c4 a2 5d 90 1c ab    	vpgatherdd %ymm4,(%rbx,%ymm13,4),%ymm3
    67a1:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
    67a5:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 682d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4dd>
    67ac:	00 
    67ad:	c4 62 65 3d ef       	vpmaxsd %ymm7,%ymm3,%ymm13
    67b2:	c5 45 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm9
    67b6:	c4 62 65 39 df       	vpminsd %ymm7,%ymm3,%ymm11
    67bb:	c4 c1 4d 66 e5       	vpcmpgtd %ymm13,%ymm6,%ymm4
    67c0:	c4 62 15 3d ee       	vpmaxsd %ymm6,%ymm13,%ymm13
    67c5:	c4 43 6d 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm2,%ymm9
    67cb:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm9,%ymm9        # 67f4 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4a4>
    67d2:	00 00 40 
    67d5:	c4 e2 25 39 e6       	vpminsd %ymm6,%ymm11,%ymm4
    67da:	c5 35 fe 0c 24       	vpaddd (%rsp),%ymm9,%ymm9
    67df:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    67e6:	00 00 
    67e8:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    67ec:	c4 a2 75 90 24 8a    	vpgatherdd %ymm1,(%rdx,%ymm9,4),%ymm4
    67f2:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
    67f6:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    67fa:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    67ff:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    6803:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    6809:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    680e:	c4 43 6d 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm2,%ymm9
    6814:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm9,%ymm9        # 683d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ed>
    681b:	00 00 b0 
    681e:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    6825:	00 00 
    6827:	c4 41 25 fa c9       	vpsubd %ymm9,%ymm11,%ymm9
    682c:	c4 22 75 90 1c 8a    	vpgatherdd %ymm1,(%rdx,%ymm9,4),%ymm11
    6832:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    6839:	00 00 
    683b:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    6841:	c5 15 fe c9          	vpaddd %ymm1,%ymm13,%ymm9
    6845:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    684a:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    684f:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    6854:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    6858:	c5 a5 fa f4          	vpsubd %ymm4,%ymm11,%ymm6
    685c:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    6861:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    6866:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    686a:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    686e:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
    6873:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    6878:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    687c:	c4 e2 75 90 04 bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm0
    6882:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    6888:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
    688c:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    6890:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6918 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
    6897:	00 
    6898:	c4 c1 5d fe e6       	vpaddd %ymm14,%ymm4,%ymm4
    689d:	c4 e2 75 90 2c bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm5
    68a3:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    68a9:	48 8b 70 d0          	mov    -0x30(%rax),%rsi
    68ad:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    68b1:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    68b5:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 693d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5ed>
    68bc:	00 
    68bd:	c4 e2 75 90 24 be    	vpgatherdd %ymm1,(%rsi,%ymm7,4),%ymm4
    68c3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    68c8:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 6950 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x600>
    68cf:	00 
    68d0:	c5 7d 6f f3          	vmovdqa %ymm3,%ymm14
    68d4:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
    68d9:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    68dd:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
    68e1:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
    68e6:	c4 c3 6d 4c f0 60    	vpblendvb %ymm6,%ymm8,%ymm2,%ymm6
    68ec:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 6915 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c5>
    68f3:	00 00 90 
    68f6:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    68fb:	c5 cd fe 34 24       	vpaddd (%rsp),%ymm6,%ymm6
    6900:	c4 62 35 39 d8       	vpminsd %ymm0,%ymm9,%ymm11
    6905:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    6909:	c4 e2 15 90 0c b2    	vpgatherdd %ymm13,(%rdx,%ymm6,4),%ymm1
    690f:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    6913:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    6917:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    691c:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    6921:	c4 c3 6d 4c d0 60    	vpblendvb %ymm6,%ymm8,%ymm2,%ymm2
    6927:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    692e:	00 00 
    6930:	c4 41 7d 6f c2       	vmovdqa %ymm10,%ymm8
    6935:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm2,%ymm2        # 695e <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x60e>
    693c:	00 00 90 
    693f:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    6943:	c4 e2 3d 90 34 92    	vpgatherdd %ymm8,(%rdx,%ymm2,4),%ymm6
    6949:	c4 c1 45 fe d3       	vpaddd %ymm11,%ymm7,%ymm2
    694e:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    6953:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    6957:	c4 c1 4d db f4       	vpand  %ymm12,%ymm6,%ymm6
    695c:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6960:	c5 cd fa d1          	vpsubd %ymm1,%ymm6,%ymm2
    6964:	c4 c1 75 fa cf       	vpsubd %ymm15,%ymm1,%ymm1
    6969:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    696e:	c5 fe 6f 94 24 00 01 	vmovdqu 0x100(%rsp),%ymm2
    6975:	00 00 
    6977:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    697c:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    6980:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    6985:	c5 f5 fe 8c 24 e0 00 	vpaddd 0xe0(%rsp),%ymm1,%ymm1
    698c:	00 00 
    698e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6992:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    6996:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    699b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    699f:	49 39 c1             	cmp    %rax,%r9
    69a2:	74 14                	je     69b8 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x668>
    69a4:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    69aa:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    69b0:	e9 88 fb ff ff       	jmp    653d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ed>
    69b5:	0f 1f 00             	nopl   (%rax)
    69b8:	c5 fe 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm0
    69bf:	00 00 
    69c1:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    69c5:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    69ca:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    69cf:	49 83 c0 18          	add    $0x18,%r8
    69d3:	c5 ed eb c9          	vpor   %ymm1,%ymm2,%ymm1
    69d7:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    69db:	c4 e2 7d 00 84 24 60 	vpshufb 0x160(%rsp),%ymm0,%ymm0
    69e2:	01 00 00 
    69e5:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    69e9:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    69ef:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    69f4:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    69f9:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    69fd:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    6a03:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    6a09:	4d 39 c3             	cmp    %r8,%r11
    6a0c:	0f 85 1e fa ff ff    	jne    6430 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
    6a12:	c5 f8 77             	vzeroupper
    6a15:	c5 f8 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm6
    6a1c:	00 00 
    6a1e:	c5 f8 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm7
    6a25:	00 00 
    6a27:	c5 78 28 84 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm8
    6a2e:	00 00 
    6a30:	c5 78 28 8c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm9
    6a37:	00 00 
    6a39:	c5 78 28 94 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm10
    6a40:	00 00 
    6a42:	c5 78 28 9c 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm11
    6a49:	00 00 
    6a4b:	c5 78 28 a4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm12
    6a52:	00 00 
    6a54:	c5 78 28 ac 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm13
    6a5b:	00 00 
    6a5d:	c5 78 28 b4 24 00 02 	vmovaps 0x200(%rsp),%xmm14
    6a64:	00 00 
    6a66:	c5 78 28 bc 24 10 02 	vmovaps 0x210(%rsp),%xmm15
    6a6d:	00 00 
    6a6f:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
    6a76:	5b                   	pop    %rbx
    6a77:	5e                   	pop    %rsi
    6a78:	c3                   	ret
    6a79:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    6a7d:	0f 85 3d f9 ff ff    	jne    63c0 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    6a83:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    6a8a:	0f 84 30 f9 ff ff    	je     63c0 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    6a90:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    6a97:	0f 84 23 f9 ff ff    	je     63c0 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    6a9d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    6aa4:	0f 84 16 f9 ff ff    	je     63c0 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    6aaa:	4d 85 c9             	test   %r9,%r9
    6aad:	0f 84 62 ff ff ff    	je     6a15 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c5>
    6ab3:	c5 fd 6f 0d 00 00 00 	vmovdqa 0x0(%rip),%ymm1        # 6abb <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x76b>
    6aba:	00 
    6abb:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    6abf:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    6ac4:	48 c1 e8 03          	shr    $0x3,%rax
    6ac8:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
    6ace:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6ad2:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    6ad9:	00 00 
    6adb:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 6b23 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d3>
    6ae2:	00 
    6ae3:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    6ae8:	b8 00 80 00 00       	mov    $0x8000,%eax
    6aed:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    6af4:	00 00 
    6af6:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    6afa:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    6aff:	c5 fe 7f 0c 24       	vmovdqu %ymm1,(%rsp)
    6b04:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    6b09:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    6b0f:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    6b13:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6b18:	48 8b 01             	mov    (%rcx),%rax
    6b1b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    6b1f:	49 83 c0 18          	add    $0x18,%r8
    6b23:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    6b29:	8b 51 50             	mov    0x50(%rcx),%edx
    6b2c:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    6b32:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    6b37:	c4 e2 7d 00 84 24 40 	vpshufb 0x140(%rsp),%ymm0,%ymm0
    6b3e:	01 00 00 
    6b41:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    6b45:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    6b4a:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    6b4f:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    6b54:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    6b59:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    6b5f:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    6b64:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6b69:	c4 e2 6d 90 04 b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm0
    6b6f:	c4 c1 35 db f6       	vpand  %ymm14,%ymm9,%ymm6
    6b74:	48 8b 41 08          	mov    0x8(%rcx),%rax
    6b78:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    6b7c:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    6b82:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    6b86:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    6b8b:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6c13 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c3>
    6b92:	00 
    6b93:	c4 e2 6d 90 34 a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm6
    6b99:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b9d:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    6ba2:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    6ba6:	c4 a2 6d 90 24 a0    	vpgatherdd %ymm2,(%rax,%ymm12,4),%ymm4
    6bac:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    6bb1:	48 8b 41 48          	mov    0x48(%rcx),%rax
    6bb5:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 6c3d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8ed>
    6bbc:	00 
    6bbd:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6bc2:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    6bc7:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 6c4f <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8ff>
    6bce:	00 
    6bcf:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    6bd3:	c5 f9 6e da          	vmovd  %edx,%xmm3
    6bd7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    6bdb:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    6be0:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    6be4:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    6be8:	c4 62 55 90 2c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm13
    6bee:	c4 e2 3d 90 2c 98    	vpgatherdd %ymm8,(%rax,%ymm3,4),%ymm5
    6bf4:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    6bf9:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    6c00:	00 00 
    6c02:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    6c06:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    6c0b:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
    6c10:	c5 7e 7f 84 24 a0 00 	vmovdqu %ymm8,0xa0(%rsp)
    6c17:	00 00 
    6c19:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    6c1e:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    6c23:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    6c27:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    6c2d:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # 6c56 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x906>
    6c34:	00 00 a0 
    6c37:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    6c3c:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    6c40:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
    6c46:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    6c4a:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    6c4e:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    6c54:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # 6c7d <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x92d>
    6c5b:	00 00 80 
    6c5e:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6c63:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    6c67:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    6c6d:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
    6c73:	c4 c1 05 db ee       	vpand  %ymm14,%ymm15,%ymm5
    6c78:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
    6c7f:	00 00 
    6c81:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    6c86:	c5 0d db 6c 24 60    	vpand  0x60(%rsp),%ymm14,%ymm13
    6c8c:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    6c90:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    6c95:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6c9b:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    6c9f:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    6ca3:	c4 c1 3d 72 f5 10    	vpslld $0x10,%ymm13,%ymm8
    6ca9:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    6cae:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    6cb3:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    6cb8:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    6cbf:	00 00 00 
    6cc2:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6cc7:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    6ccb:	c5 8d db a4 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm4
    6cd2:	00 00 
    6cd4:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    6cd9:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    6cde:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    6ce3:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    6ce7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6ceb:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6cf0:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    6cf7:	00 00 
    6cf9:	c4 a2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm5
    6cff:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d03:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 6d8b <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa3b>
    6d0a:	00 
    6d0b:	c4 62 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm8
    6d11:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    6d15:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6d1b:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    6d20:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 6da8 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa58>
    6d27:	00 
    6d28:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    6d2e:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6db6 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa66>
    6d35:	00 
    6d36:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    6d3b:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    6d3f:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    6d43:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    6d48:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    6d4d:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    6d53:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # 6d7c <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa2c>
    6d5a:	00 00 a0 
    6d5d:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
    6d62:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    6d69:	00 00 
    6d6b:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    6d6f:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    6d73:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    6d78:	c4 62 2d 90 2c a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm13
    6d7e:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    6d83:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    6d88:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    6d8d:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6d92:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    6d98:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 6dc1 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa71>
    6d9f:	00 00 60 
    6da2:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    6da6:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    6dac:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    6db2:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    6db9:	00 00 
    6dbb:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    6dc0:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    6dc5:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    6dcb:	c4 41 5d db fe       	vpand  %ymm14,%ymm4,%ymm15
    6dd0:	c4 c1 5d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm4
    6dd6:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    6ddd:	00 00 
    6ddf:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    6de6:	00 00 
    6de8:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    6ded:	c4 41 4d db d6       	vpand  %ymm14,%ymm6,%ymm10
    6df2:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
    6df7:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
    6dfd:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    6e02:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    6e06:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    6e0a:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    6e0f:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    6e14:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    6e19:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    6e1e:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    6e22:	c5 8d db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm14,%ymm0
    6e29:	00 00 
    6e2b:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    6e2f:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6e35:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    6e3a:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    6e41:	00 00 00 
    6e44:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6e48:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    6e4c:	c4 a2 3d 90 04 a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm0
    6e52:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    6e56:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6e5b:	c5 95 72 d5 10       	vpsrld $0x10,%ymm5,%ymm13
    6e60:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 6ee8 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb98>
    6e67:	00 
    6e68:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    6e6d:	c4 e2 3d 90 2c b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm5
    6e73:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    6e77:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6e7d:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    6e82:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 6f0a <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbba>
    6e89:	00 
    6e8a:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    6e90:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 6f18 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbc8>
    6e97:	00 
    6e98:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6e9d:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    6ea1:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    6ea6:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    6eab:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    6eb1:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 6eda <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb8a>
    6eb8:	00 00 90 
    6ebb:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    6ec0:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    6ec4:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    6ec9:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    6ecd:	c4 e2 1d 90 14 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm2
    6ed3:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    6ed7:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    6edb:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    6ee1:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    6ee5:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # 6f0e <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbbe>
    6eec:	00 00 90 
    6eef:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    6ef4:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    6ef8:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
    6efe:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    6f03:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    6f09:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6f0d:	48 8b 41 60          	mov    0x60(%rcx),%rax
    6f11:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    6f16:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    6f1b:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    6f22:	00 00 
    6f24:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    6f29:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
    6f2e:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    6f33:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    6f38:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    6f3d:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    6f42:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    6f46:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    6f4b:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    6f50:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    6f54:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    6f58:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    6f5d:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6f61:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    6f66:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    6f6a:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    6f6e:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    6f72:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    6f77:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    6f7b:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    6f7f:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
    6f86:	00 00 
    6f88:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6f8d:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    6f93:	48 8b 41 68          	mov    0x68(%rcx),%rax
    6f97:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    6f9b:	c4 a2 75 90 2c a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm5
    6fa1:	48 8b 41 70          	mov    0x70(%rcx),%rax
    6fa5:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    6fac:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    6fb0:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    6fb6:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6fbb:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 7043 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcf3>
    6fc2:	00 
    6fc3:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6fc8:	c4 e2 75 90 34 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm6
    6fce:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    6fd5:	c5 79 6e ca          	vmovd  %edx,%xmm9
    6fd9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    6fde:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6fe3:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    6fea:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    6fef:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    6ff4:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 707c <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd2c>
    6ffb:	00 
    6ffc:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    7001:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    7006:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    700b:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 7093 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd43>
    7012:	00 
    7013:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    7018:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    701d:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    7021:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    7026:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    702a:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    702e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    7032:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    7036:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    703b:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    7041:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    7045:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    704b:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    7051:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    7055:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    705a:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    705e:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    7063:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    7068:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    706e:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 7097 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd47>
    7075:	00 00 70 
    7078:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    707d:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    7081:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    7085:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    708b:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    7090:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    7095:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    709b:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    70a1:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    70a5:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    70aa:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 70d3 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd83>
    70b1:	00 00 c0 
    70b4:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    70b9:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    70be:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    70c2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    70c7:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    70cc:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    70d2:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    70d7:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    70de:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    70e3:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    70e8:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    70ec:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    70f0:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    70f5:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    70fa:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    70ff:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    7104:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    7109:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    710e:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    7112:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    7117:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    711b:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    7120:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    7125:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    712a:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    7130:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    7135:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    713a:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    713f:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    7144:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    7149:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    714e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    7152:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    7157:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    715c:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    7161:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    7166:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    716b:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    7170:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    7175:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    717a:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    717f:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    7184:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    7188:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    718d:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    7192:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    7197:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    719c:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    71a1:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    71a6:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    71aa:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    71ae:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    71b2:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    71b7:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    71bc:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    71c1:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    71c6:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    71ca:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    71ce:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    71d2:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    71d6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    71da:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    71de:	c4 e2 75 90 24 a8    	vpgatherdd %ymm1,(%rax,%ymm5,4),%ymm4
    71e4:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    71eb:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    71f0:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    71f4:	c4 e2 75 90 2c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm5
    71fa:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    7201:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    7205:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    720a:	c4 e2 75 90 34 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm6
    7210:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    7216:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    721b:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    7222:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    7227:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    722c:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 72b4 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf64>
    7233:	00 
    7234:	c5 79 6e ca          	vmovd  %edx,%xmm9
    7238:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    723d:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 72c5 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf75>
    7244:	00 
    7245:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    724c:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    7251:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 72d9 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf89>
    7258:	00 
    7259:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    725e:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    7263:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    7268:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    726d:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    7271:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    7275:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    7279:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    727d:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    7283:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    7287:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    728c:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    7292:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    7296:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    729c:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    72a2:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    72a6:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    72ab:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    72af:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    72b4:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    72b9:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    72bf:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 72e8 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf98>
    72c6:	00 00 70 
    72c9:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    72ce:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    72d2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    72d6:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    72dc:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    72e1:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    72e6:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    72ec:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    72f2:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    72f6:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    72fb:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 7324 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfd4>
    7302:	00 00 c0 
    7305:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    730a:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    730f:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    7313:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    7318:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    731d:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    7323:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    7328:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    732f:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    7334:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    7339:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    733d:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    7341:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    7346:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    734b:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    7350:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    7355:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    735a:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    735f:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    7363:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    7368:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    736c:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    7371:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    7376:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    737b:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    7381:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    7386:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    738b:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    7390:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    7395:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    739a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    739f:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    73a3:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    73a8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    73ad:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    73b2:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    73b7:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    73bc:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    73c1:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    73c6:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    73cb:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    73d0:	c5 79 6e ca          	vmovd  %edx,%xmm9
    73d4:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    73d9:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    73de:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    73e3:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    73e7:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    73ec:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    73f1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    73f6:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    73fb:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    7400:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    7405:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    7409:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    740d:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    7411:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    7416:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    741b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    7420:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    7425:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    7429:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    742d:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    7431:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    7435:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    7439:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    743d:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    7441:	c4 e2 75 90 24 a8    	vpgatherdd %ymm1,(%rax,%ymm5,4),%ymm4
    7447:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    744e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    7453:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    7459:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    7460:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    7464:	c4 e2 6d 90 34 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm6
    746a:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    746f:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 74f7 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11a7>
    7476:	00 
    7477:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    747c:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    7481:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 7509 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11b9>
    7488:	00 
    7489:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    748e:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    7493:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 751b <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11cb>
    749a:	00 
    749b:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    74a2:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    74a7:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    74ac:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    74b1:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    74b5:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    74b9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    74bd:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    74c1:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    74c5:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    74ca:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    74d0:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    74d4:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    74da:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    74e0:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    74e4:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    74e9:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    74ed:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    74f2:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    74f8:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 7521 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d1>
    74ff:	00 00 70 
    7502:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    7507:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    750b:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    750f:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    7515:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    751a:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    751f:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    7525:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    752b:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    7530:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    7535:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    753a:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    753f:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 7568 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1218>
    7546:	00 00 c0 
    7549:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    754d:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    7551:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    7556:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    755c:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    7561:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    7565:	c4 c1 55 db d6       	vpand  %ymm14,%ymm5,%ymm2
    756a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    756f:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    7574:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    7578:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    757d:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
    7582:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    7587:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    758c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    7591:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    7596:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    759a:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    759f:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    75a3:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    75a8:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    75ad:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    75b2:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    75b8:	c5 8d db f6          	vpand  %ymm6,%ymm14,%ymm6
    75bc:	c5 8d db d2          	vpand  %ymm2,%ymm14,%ymm2
    75c0:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    75c5:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    75ca:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    75cf:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    75d4:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    75d8:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    75dd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    75e2:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    75e7:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    75ec:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    75f1:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    75f6:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    75fb:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    7600:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    7604:	c4 c1 75 db f6       	vpand  %ymm14,%ymm1,%ymm6
    7609:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    760e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    7613:	c4 c1 65 db ee       	vpand  %ymm14,%ymm3,%ymm5
    7618:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    761d:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    7622:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    7626:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    762a:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    762e:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    7633:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    7638:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    763d:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    7642:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    7647:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    764b:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    764f:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    7653:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    7658:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    765d:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    7661:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    7665:	c4 e2 7d 00 84 24 60 	vpshufb 0x160(%rsp),%ymm0,%ymm0
    766c:	01 00 00 
    766f:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    7673:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    7679:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    767e:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    7683:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    7687:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    768d:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    7693:	4d 39 c2             	cmp    %r8,%r10
    7696:	0f 85 68 f4 ff ff    	jne    6b04 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7b4>
    769c:	e9 71 f3 ff ff       	jmp    6a12 <jshc_compact_cache::avx2_chain(jshc_compact_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c2>
    76a1:	90                   	nop
    76a2:	90                   	nop
    76a3:	90                   	nop
    76a4:	90                   	nop
    76a5:	90                   	nop
    76a6:	90                   	nop
    76a7:	90                   	nop
    76a8:	90                   	nop
    76a9:	90                   	nop
    76aa:	90                   	nop
    76ab:	90                   	nop
    76ac:	90                   	nop
    76ad:	90                   	nop
    76ae:	90                   	nop
    76af:	90                   	nop
