# Empty compiler generated dependencies file for jshc_direct_rgb24.
# This may be replaced when dependencies are built.
