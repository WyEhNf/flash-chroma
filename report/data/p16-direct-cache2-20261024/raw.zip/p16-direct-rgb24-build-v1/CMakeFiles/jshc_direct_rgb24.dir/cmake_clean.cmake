file(REMOVE_RECURSE
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/andn_inplace.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/andn_inplace.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/andn_outplace.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/andn_outplace.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/channel_runtime.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/channel_runtime.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/compile_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/compile_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/direct_rgb24_avx2.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/direct_rgb24_avx2.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/linear.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/linear.cpp.obj.d"
  "CMakeFiles/jshc_direct_rgb24.dir/normal_inplace.cpp.obj"
  "CMakeFiles/jshc_direct_rgb24.dir/normal_inplace.cpp.obj.d"
  "libjshc_direct_rgb24.dll"
  "libjshc_direct_rgb24.dll.a"
  "libjshc_direct_rgb24.dll.manifest"
  "libjshc_direct_rgb24.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_direct_rgb24.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
