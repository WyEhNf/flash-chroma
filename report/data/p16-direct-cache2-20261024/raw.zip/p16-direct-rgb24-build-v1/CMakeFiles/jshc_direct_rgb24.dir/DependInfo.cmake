
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/andn_inplace.cpp" "CMakeFiles/jshc_direct_rgb24.dir/andn_inplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/andn_inplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/andn_outplace.cpp" "CMakeFiles/jshc_direct_rgb24.dir/andn_outplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/andn_outplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/channel_runtime.cpp" "CMakeFiles/jshc_direct_rgb24.dir/channel_runtime.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/channel_runtime.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/compile_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/compile_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/compile_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/direct_rgb24_avx2.cpp" "CMakeFiles/jshc_direct_rgb24.dir/direct_rgb24_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/direct_rgb24_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/linear.cpp" "CMakeFiles/jshc_direct_rgb24.dir/linear.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/linear.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-rgb24-runtime/normal_inplace.cpp" "CMakeFiles/jshc_direct_rgb24.dir/normal_inplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_rgb24.dir/normal_inplace.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
