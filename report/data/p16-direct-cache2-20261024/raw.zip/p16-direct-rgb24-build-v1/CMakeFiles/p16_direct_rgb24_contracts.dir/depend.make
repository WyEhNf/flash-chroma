# Empty dependencies file for p16_direct_rgb24_contracts.
# This may be replaced when dependencies are built.
