file(REMOVE_RECURSE
  "CMakeFiles/p16_direct_rgb24_contracts.dir/andn_inplace.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/andn_inplace.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/andn_outplace.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/andn_outplace.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/compile_avx2.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/compile_avx2.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/contracts.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/contracts.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/direct_rgb24_avx2.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/direct_rgb24_avx2.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/linear.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/linear.cpp.obj.d"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/normal_inplace.cpp.obj"
  "CMakeFiles/p16_direct_rgb24_contracts.dir/normal_inplace.cpp.obj.d"
  "libp16_direct_rgb24_contracts.dll.a"
  "p16_direct_rgb24_contracts.exe"
  "p16_direct_rgb24_contracts.exe.manifest"
  "p16_direct_rgb24_contracts.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/p16_direct_rgb24_contracts.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
