# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for p16_direct_rgb24_contracts.
