
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-chroma-2op-runtime/channel_avx2.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/channel_avx2.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/channel_avx2.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-chroma-2op-runtime/channel_runtime.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/channel_runtime.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/channel_runtime.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-chroma-2op-runtime/outplace_bench.cpp" "CMakeFiles/jshc_skylake_chroma_2op.dir/outplace_bench.cpp.o" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/outplace_bench.cpp.o.d"
  "" "libjshc_skylake_chroma_2op.so" "gcc" "CMakeFiles/jshc_skylake_chroma_2op.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
