"""只读反汇编入口分派：追踪16个已知shared布尔组合至循环区，禁止以地址顺序猜对应关系。"""
from pathlib import Path
import json,re,sys,hashlib,subprocess
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'scripts'))
from inspect_skylake_avx2 import functions

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=read(HERE/'results.json')
# 用同一工具链静态断言布局；只编译检查，不生成/加载程序。
probe=HERE/'view-layout-proof.cpp'
probe.write_text('#include <cstddef>\n#include "experiments/channel-runtime/channel_views.hpp"\n#include "experiments/skylake-r-contiguous-runtime/channel_views.hpp"\nstatic_assert(sizeof(jshc_channel::View)==96 && offsetof(jshc_channel::View,shared)==88);\nstatic_assert(sizeof(jshc_r_contiguous::View)==96 && offsetof(jshc_r_contiguous::View,shared)==88);\n',encoding='utf-8')
command=['E:/mingw64/bin/g++.exe','-std=c++17','-fsyntax-only','-I'+str(ROOT),str(probe)]
p=subprocess.run(command,capture_output=True,text=True);save(HERE/'view-layout-proof.json',{'command':command,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'source_sha256':sha(probe),'native_calls':0})
if p.returncode:raise RuntimeError('ABI布局静态断言失败')
UNKNOWN=object()
def reg(x):
 x=x.strip().lstrip('%')
 aliases={'eax':'rax','ax':'rax','al':'rax','ah':'rax','ecx':'rcx','cx':'rcx','cl':'rcx','edx':'rdx','dx':'rdx','dl':'rdx','ebx':'rbx','bx':'rbx','bl':'rbx','esi':'rsi','edi':'rdi','esp':'rsp','ebp':'rbp'}
 return aliases.get(x,re.sub(r'(r[0-9]+)[bwd]$',r'\1',x))
def trace(fn,selected,bits):
 seq=fn['instructions'];lookup={a:i for i,(a,_,_) in enumerate(seq)};state={'rcx':('chain',0),'rdx':('cache',0),'r8':('image',0),'r9':4096};zf=None;path=[]
 def val(x):
  x=x.strip()
  if x.startswith('$'):return int(x[1:],0)
  if x.startswith('%'):return state.get(reg(x),UNKNOWN)
  m=re.fullmatch(r'(0x[0-9a-f]+)?\(%([a-z0-9]+)\)',x)
  if m:
   base=state.get(reg(m[2]),UNKNOWN);offset=int(m[1] or '0',0)
   if isinstance(base,tuple) and base[0]=='chain':
    offset+=base[1]
    if offset in (88,184,280,376):return bits[(offset-88)//96]
  return UNKNOWN
 i=0
 for steps in range(500):
  a,op,args=seq[i]
  for k,l in enumerate(selected):
   if int(l['start'],16)<=a<=int(l['end'],16):return k,path
  path.append(hex(a));parts=[x.strip() for x in args.split(',')]
  if op.startswith('j'):
   target=int(re.match(r'([0-9a-f]+)',args)[1],16)
   if op=='jmp':take=True
   elif op in ('je','jz','jne','jnz'):
    if zf is None:raise ValueError('分派依赖未知条件：'+hex(a))
    take=zf if op in ('je','jz') else not zf
   else:raise ValueError('未覆盖入口条件跳转：'+op)
   i=lookup[target] if take else i+1;continue
  if op in ('cmp','cmpb','cmpl','cmpq'):
   x,y=map(val,parts);zf=None if x is UNKNOWN or y is UNKNOWN else x==y
  elif op.startswith('test'):
   x,y=map(val,parts);zf=None if not isinstance(x,int) or not isinstance(y,int) else (x&y)==0
  elif op in ('mov','movzbl','movzbq','movl','movq') and len(parts)==2 and parts[1].startswith('%'):
   state[reg(parts[1])]=val(parts[0])
  elif op=='xor' and len(parts)==2 and parts[0]==parts[1]:state[reg(parts[1])]=0;zf=True
  elif op in ('sub','add','imul','shr','shl') and len(parts)==2 and parts[1].startswith('%'):
   x,y=val(parts[0]),val(parts[1]);v=UNKNOWN
   if isinstance(x,int) and isinstance(y,int):
    v={'sub':lambda:y-x,'add':lambda:y+x,'imul':lambda:y*x,'shr':lambda:y>>x,'shl':lambda:y<<x}[op]()
   state[reg(parts[1])]=v;zf=None if v is UNKNOWN else v==0
  elif op in ('inc','dec') and len(parts)==1:
   v=val(parts[0]);v=v+(1 if op=='inc' else -1) if isinstance(v,int) else UNKNOWN;state[reg(parts[0])]=v;zf=None if v is UNKNOWN else v==0
  elif op=='lea' and len(parts)>=2:state[reg(parts[-1])]=UNKNOWN
  elif op in ('ret','call'):raise ValueError('未进入选定循环即返回/调用')
  i+=1
 raise ValueError('分派未收敛')
roles={};traces=[]
for role in ('reference','candidate'):
 fs=functions((HERE/(role+'.asm')).read_text());fn=[f for f in fs if '::avx2_chain_cached(' in f['function']]
 assert len(fn)==1;mapping={};selected=record['variants'][role]['selected']
 for n in range(16):
  bits=[(n>>s)&1 for s in range(4)];k,path=trace(fn[0],selected,bits)
  key=('shared' if bits[0] else 'unshared')+'/'+('shared' if all(bits[1:]) else 'mixed')
  if key in mapping:assert mapping[key]==k
  mapping[key]=k;traces.append({'role':role,'shared_bits':bits,'semantic_case':key,'loop_index':k,'loop_start':selected[k]['start'],'dispatch_addresses':path})
 assert len(mapping)==4 and len(set(mapping.values()))==4;roles[role]=mapping
bounds=[]
for key in sorted(roles['reference']):
 r=record['variants']['reference']['selected'][roles['reference'][key]];c=record['variants']['candidate']['selected'][roles['candidate'][key]]
 assert r['gathers']==c['gathers'] and r['calls']==c['calls']==0
 for cpu in ('skylake','skylake-avx512'):
  ratio={k:c['models'][cpu][k]/r['models'][cpu][k] for k in ('Total Cycles','Block RThroughput')}
  bounds.append({'semantic_case':key,'cpu':cpu,'reference_loop':r['start'],'candidate_loop':c['start'],'ratio':ratio,'pass':all(v<=1.03 for v in ratio.values())})
self_comparison={str(g):max(v['models']['skylake']['Total Cycles'] for v in record['variants']['reference']['selected'] if v['gathers']==g)/min(v['models']['skylake']['Total Cycles'] for v in record['variants']['reference']['selected'] if v['gathers']==g) for g in (8,18)}
result={'purpose':__doc__,'initial_static_sha256':sha(HERE/'results.json'),'source_sha256':sha(Path(__file__)),
 'static_view_layout_proof_sha256':sha(HERE/'view-layout-proof.json'),'semantic_loops':roles,'dispatch_traces':traces,
 'initial_comparator_reference_against_itself':self_comparison,'paired_cost_bounds':bounds,'paired_cost_gate_pass':all(x['pass'] for x in bounds),
 'correction':'初版max/min把shared/mixed后缀不同路径交叉比较，连参考自比也拒绝；现以16组入口旗标的只读分派证明逐语义配对。候选未改/未重编译，3%参数及未来性能门槛不变，尚无原生调用。',
 'project_native_calls':0,'performance_calls':0}
save(HERE/'dispatch-proof.json',result);print(json.dumps({'semantic_loops':roles,'initial_reference_self_ratios':self_comparison,'paired_cost_bounds':bounds,'pass':result['paired_cost_gate_pass']},ensure_ascii=False))
