#include <cstddef>
#include "experiments/channel-runtime/channel_views.hpp"
#include "experiments/skylake-r-contiguous-runtime/channel_views.hpp"
static_assert(sizeof(jshc_channel::View)==96 && offsetof(jshc_channel::View,shared)==88);
static_assert(sizeof(jshc_r_contiguous::View)==96 && offsetof(jshc_r_contiguous::View,shared)==88);
