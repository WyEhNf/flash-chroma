import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
validation=json.loads(Path('experiments/skylake-r-contiguous-validation-v2.json').read_text(encoding='utf-8'))
for name in ('code_plan','build','initial_static','dispatch_proof'):
 spec=validation[name]
 if sha(spec['path'])!=spec['sha256']:raise ValueError('验证修订身份不同：'+name)
proof=json.loads(Path(validation['dispatch_proof']['path']).read_text(encoding='utf-8'))
if not proof['paired_cost_gate_pass']:raise ValueError('逐语义静态门槛未过')
common=['--plan',validation['code_plan']['path'],'--build',str(HERE.relative_to(ROOT)).replace('\\','/')]
base='artifacts/skylake-r-contiguous-contract-v1/results.json';cache='artifacts/skylake-r-contiguous-cache-contract-v1/results.json'
commands=[('base',['scripts/verify_skylake_packed.py',*common,'--output','artifacts/skylake-r-contiguous-contract-v1']),
 ('cache',['scripts/verify_skylake_suffix_cache.py',*common,'--contract',base,'--output','artifacts/skylake-r-contiguous-cache-contract-v1']),
 ('storage',['scripts/verify_skylake_rcontiguous.py',*common,'--contract',base,'--cache-contract',cache,'--output','artifacts/skylake-r-contiguous-layout-contract-v1']),
 ('full',['scripts/accept_skylake_runtime.py',*common,'--contract',base,'--cache-contract',cache,'--output','artifacts/skylake-r-contiguous-full-v1'])]
records=[]
for name,args in commands:
 command=[sys.executable,'-X','utf8',*args];p=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (HERE/(name+'.stdout.log')).write_text(p.stdout,encoding='utf-8');(HERE/(name+'.stderr.log')).write_text(p.stderr,encoding='utf-8')
 records.append({'name':name,'command':command,'returncode':p.returncode,'stdout_sha256':sha(HERE/(name+'.stdout.log')),'stderr_sha256':sha(HERE/(name+'.stderr.log'))})
 save(HERE/'validation-commands.json',{'purpose':'一次集中逐阶段验证；任何失败停止，不自动重试','validation_plan_sha256':sha('experiments/skylake-r-contiguous-validation-v2.json'),'commands':records})
 print(name,p.returncode,p.stdout[-1600:],flush=True)
 if p.returncode:raise RuntimeError(p.stderr)
print('集中合同和实际完整域/百图完成；尚未计时',flush=True)
