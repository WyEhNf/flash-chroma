"""单独导出带色彩标记的FFV1文件，并解码核对全部RGB原字节。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--ffmpeg", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run = json.loads((args.run / "results.json").read_text())
    if not run.get("complete"):
        raise ValueError("映射未完整结束，不能导出完整流程结果")
    args.output.mkdir(parents=True, exist_ok=False)
    args.ffmpeg.chmod(args.ffmpeg.stat().st_mode | 0o111)
    version = subprocess.run([str(args.ffmpeg), "-version"], capture_output=True, check=True).stdout.decode()
    result = {"run_sha256": hashlib.sha256((args.run / "results.json").read_bytes()).hexdigest(),
              "ffmpeg_sha256": hashlib.sha256(args.ffmpeg.read_bytes()).hexdigest(), "ffmpeg_version": version,
              "scope": "编码在映射计时全部结束后执行；解码逐字节验证不计入生产映射", "files": []}
    for target in ("sdr", "hdr"):
        for kind, pixel_format, width_bytes in (("reference16", "rgb48le", 6), ("runtime8", "rgb24", 3)):
            directory = args.run / f"{target}-{kind}"
            frames = sorted(directory.glob("frame-*.rgb"))
            if len(frames) != len(run["frames"]):
                raise ValueError("输出帧数不符")
            output = args.output / f"{target}-{kind}.mkv"
            command = [str(args.ffmpeg), "-hide_banner", "-nostdin", "-f", "rawvideo", "-pixel_format", pixel_format,
                       "-video_size", f'{run["width"]}x{run["height"]}', "-framerate", str(run["fps"]), "-i", "pipe:0",
                       "-an", "-c:v", "ffv1", "-level", "3", "-coder", "1", "-context", "1", "-threads", "4",
                       "-pix_fmt", "gbrp16le", "-color_range", "pc", "-colorspace", "gbr",
                       "-color_primaries", "bt2020" if target == "hdr" else "bt709",
                       "-color_trc", "smpte2084" if target == "hdr" else "bt709", str(output)]
            start = time.perf_counter()
            expected, size = hashlib.sha256(), 0
            with (args.output / f"{target}-{kind}-encode.log").open("wb") as log:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=log)
                try:
                    for frame in frames:
                        if frame.stat().st_size != run["width"] * run["height"] * width_bytes:
                            raise ValueError("输出帧字节数不符")
                        with frame.open("rb") as stream:
                            while chunk := stream.read(4 * 1024 * 1024):
                                expected.update(chunk)
                                size += len(chunk)
                                process.stdin.write(chunk)
                    process.stdin.close()
                    if process.wait() != 0:
                        raise RuntimeError("FFV1编码失败，见原始日志")
                except BaseException:
                    process.kill(); process.wait()
                    raise
            encode_seconds = time.perf_counter() - start
            command_decode = [str(args.ffmpeg), "-hide_banner", "-nostdin", "-i", str(output), "-map", "0:v:0",
                              "-an", "-threads", "4", "-f", "rawvideo", "-pix_fmt", pixel_format, "pipe:1"]
            start = time.perf_counter()
            actual, decoded_size = hashlib.sha256(), 0
            with (args.output / f"{target}-{kind}-verify.log").open("wb") as log:
                process = subprocess.Popen(command_decode, stdout=subprocess.PIPE, stderr=log)
                while chunk := process.stdout.read(4 * 1024 * 1024):
                    actual.update(chunk); decoded_size += len(chunk)
                if process.wait() != 0:
                    raise RuntimeError("FFV1解码失败")
            if decoded_size != size or actual.hexdigest() != expected.hexdigest():
                raise AssertionError("容器往返RGB字节不一致")
            metadata_log = (args.output / f"{target}-{kind}-verify.log").read_text(errors="replace")
            if "gbrp16le" not in metadata_log or (target == "hdr" and "smpte2084" not in metadata_log):
                raise AssertionError("输出像素格式或HDR传递函数标记未确认")
            with output.open("rb") as stream:
                file_sha = hashlib.file_digest(stream, "sha256").hexdigest()
            row = {"target": target, "kind": kind, "command": command, "decode_command": command_decode,
                   "file": str(output.resolve()), "bytes": output.stat().st_size, "sha256": file_sha,
                   "input_significant_bits": 16 if kind == "reference16" else 8,
                   "stored_pixel_format": "gbrp16le", "frames": len(frames), "roundtrip_bytes": size,
                   "roundtrip_sha256": actual.hexdigest(), "roundtrip_equal": True,
                   "encode_seconds": encode_seconds, "verification_seconds": time.perf_counter() - start}
            result["files"].append(row)
            (args.output / "progress.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            print(json.dumps({k: row[k] for k in ("target", "kind", "frames", "bytes", "roundtrip_equal")}), flush=True)
    result["complete"] = True
    (args.output / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
