"""独立核对交付的结构、来源绑定、链接及暂存字节，不重复像素计算。"""
import ast
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import zipfile

ROOT = Path.cwd()
BASE = ROOT / "artifacts/camera-raw-workflow-v1"
DEST = ROOT / "report/data/camera-raw-workflow-v1"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


summary = read(DEST / "summary.json")
assert summary["total_frames"] == 54 and len(summary["video_files"]) == 12
assert summary["all_native_scalar_equal"] and not summary["float_reference_precision_preserved"]
assert sum(c["pixels_per_branch"] for c in summary["cameras"].values()) == 1128231168
manifest = read(DEST / "manifest.json")
assert digest((DEST / "evidence.zip").read_bytes()) == manifest["zip_sha256"]
json_count = ast_count = 0
payload_hashes = set()
with zipfile.ZipFile(DEST / "evidence.zip") as zipped:
    assert zipped.testzip() is None
    assert set(zipped.namelist()) == {r["path"] for r in manifest["files"]}
    for row in manifest["files"]:
        payload = zipped.read(row["path"])
        assert len(payload) == row["bytes"] and digest(payload) == row["sha256"]
        payload_hashes.add(row["sha256"])
        if row["path"].endswith(".py"):
            ast.parse(payload.decode("utf-8"), filename=row["path"])
            ast_count += 1
        if row["path"].endswith(".json"):
            if row["path"].endswith("/braw-download-response.json"):
                assert payload.strip() == b"Bad Request"
            else:
                json.loads(payload)
                json_count += 1
for name in ("run-arri-v1", "run-blackmagic-stream-v1", "run-red-v1"):
    data = read(BASE / name / "results.json")
    for key in ("script_sha256", "graph_script_sha256", "bridge_sha256", "policy_sha256", "model_manifest_sha256"):
        if key in data:
            assert data[key] in payload_hashes, (name, key)
for record in summary["video_files"]:
    raw_path = record["file"]
    path = Path("F:" + raw_path[len("/mnt/f"):]) if raw_path.startswith("/mnt/f/") else Path(raw_path)
    assert path.stat().st_size == record["bytes"]
    assert record["roundtrip_equal"]
    assert record["frames"] == summary["cameras"][record["camera"]]["frames"]
    assert record["roundtrip_bytes"] == record["frames"] * summary["cameras"][record["camera"]]["dimensions"][0] * summary["cameras"][record["camera"]]["dimensions"][1] * (6 if record["kind"] == "reference16" else 3)

result = {"purpose": "最终交付静态检查；不重复执行像素/视频，不证明新性能或画质门槛通过",
          "platform": platform.platform(), "python": sys.version,
          "archive_files": len(manifest["files"]), "json_parsed": json_count, "python_ast_parsed": ast_count,
          "external_non_json_response": "braw-download-response.json原文Bad Request，按原响应保留",
          "frames": 54, "video_files": 12, "video_sizes_match": True, "execution_source_hashes_found": True,
          "zip_sha256_and_crc_equal": True}
# 该回执在ZIP创建后产生，单独发布，避免自指哈希。
(DEST / "verification-final.json").write_text("{}\n", encoding="utf-8")
document = ROOT / "docs/stages/2026-10-23-camera-raw-workflow.md"
links = []
for target in re.findall(r"\]\(([^)]+)\)", document.read_text(encoding="utf-8")):
    if "://" not in target and not target.startswith("#"):
        path = (document.parent / target.split("#", 1)[0]).resolve()
        assert path.exists(), target
        links.append(target)
result["local_links_checked"] = len(links)
subprocess.run(["git", "diff", "--check"], check=True)
subprocess.run(["git", "diff", "--cached", "--check"], check=True)
staged = subprocess.check_output(["git", "diff", "--cached", "--name-only", "-z"]).decode("utf-8").split("\0")
frozen = [p for p in staged if p and (p.startswith("experiments/camera-raw-workflow")
          or p in ("scripts/archive_camera_raw_workflow.py", "scripts/fetch_camera_raw_asset.py")
          or p.startswith("report/data/camera-raw-workflow-v1/")) and not p.endswith("/verification-final.json")]
assert frozen, "必须先暂存阶段文件"
for name in frozen:
    actual = subprocess.check_output(["git", "show", ":" + name])
    assert actual == (ROOT / name).read_bytes(), name
result["frozen_staged_blobs_equal"] = len(frozen)
result["all_passed"] = True
payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
(BASE / "verification-final.json").write_text(payload, encoding="utf-8")
(DEST / "verification-final.json").write_text(payload, encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))
