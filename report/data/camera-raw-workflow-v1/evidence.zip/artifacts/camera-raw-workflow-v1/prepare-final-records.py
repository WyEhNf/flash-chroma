"""整理已执行回执的来源与最终源码身份，不再次执行像素变换。"""
import ast
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path.cwd()
BASE = ROOT / "artifacts/camera-raw-workflow-v1"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def row(path):
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}


def read(name):
    return json.loads((BASE / name).read_text(encoding="utf-8"))


def dump(name, value):
    (BASE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


materials = [
    ("arri", "raw/arri/L001C028_140110_R6MS.0018267.ari", "https://www.arri.com/en/learn/camera-systems/camera-sample-footage-reference-image", "官方FTPS路径见agent-arri-download.json；公开凭据不保存"),
    ("blackmagic", "raw/blackmagic/The-End-of-the-World-Train-Original.braw", "https://downloads.blackmagicdesign.com/products/blackmagicpocketcinemacamera/originals/end-of-the-world/The-End-of-the-World-Train-Original.zip", "官方图库完整52帧，Guido Pezz作品；ZIP身份见下方工具/素材下载包"),
    ("red", "raw/red/F099_C001_0317IH.R3D", "https://samples.ffmpeg.org/r3d/F099_C001_0317IH.R3D", "FFmpeg公开原始R3D测试单帧；实际使用官方REDline解码，不冒充RED当前官方样片")]
source = {"purpose": "最终权威来源身份；初始pending_source和旧检索事实仍按历史原件保留",
          "materials": [{"camera": c, **row(BASE / p), "source_url": url, "scope": scope} for c, p, url, scope in materials],
          "downloads": [], "decoder_evidence": {"arri": "arri-decode-v3.json", "blackmagic": ["braw-configuration.json", "braw-decode.json"], "red": "red-input-verification.json"},
          "limitations": ["ARRI/RED均单帧；只有Blackmagic是52帧短片", "不分发第三方素材、像素、视频或厂商二进制", "RED成功输入来源补充red-camera.json，烘焙策略不变", "先前工具及来源快照不覆盖或改写"]}
for path in sorted((BASE / "downloads").glob("*.download.json")):
    data = json.loads(path.read_text(encoding="utf-8"))
    source["downloads"].append({"original_receipt": row(path), **{k: data[k] for k in ("source_url", "status", "bytes", "sha256", "http_status", "error") if k in data}})
dump("source-manifest.json", source)

paths = sorted((ROOT / "experiments/camera-raw-workflow").glob("*.py"))
paths += sorted((ROOT / "experiments/camera-raw-workflow").glob("*.cpp"))
paths += [ROOT / "scripts/fetch_camera_raw_asset.py", ROOT / "scripts/archive_camera_raw_workflow.py", ROOT / "experiments/camera-raw-workflow-v1.json", Path(__file__).resolve()]
for path in paths:
    if path.suffix == ".py":
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
old = read("tool-source-inventory.json")
tools = [ROOT / r["path"] for r in old["files"] if r["path"].startswith("artifacts")]
tools += [BASE / "tools/arri-art-cmd-win/bin/art-cmd.exe", BASE / "tools/redline-linux/bin/REDline",
          ROOT / "artifacts/skylake-andn-split-linux-build-v1/libjshc_skylake_andn_split.so",
          ROOT / "artifacts/camera-raw-env-v1/Lib/site-packages/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe",
          BASE / "linux-site/imageio_ffmpeg/binaries/ffmpeg-linux-x86_64-v7.0.2"]
dump("tool-source-inventory-final.json", {"purpose": "最终源码与实际工具身份，旧快照保留；执行版本另见各回执SHA和冻结脚本", "platform": platform.platform(), "python": sys.version,
                                         "files": [row(p) for p in paths], "tools": [row(p) for p in tools]})

initial, final = read("remote-initial.json"), read("remote-final.json")
before = {r["issue_number"]: r["body"] for r in initial["all_prs"]["issues"]}
after = {r["issue_number"]: r["body"] for r in final["all_prs"]["issues"]}
changed = [key for key in after if key not in before or before[key] != after[key]]
if changed or set(before) != set(after):
    raise AssertionError("远端协作记录有变化，必须人工检查原文")
ancestry = {}
for commit in ("337a3dd", "876e15b8", "397cc367"):
    ancestry[commit] = subprocess.run(["git", "merge-base", "--is-ancestor", commit, "HEAD"]).returncode == 0
if not all(ancestry.values()):
    raise AssertionError("既有修复祖先缺失")
dump("remote-comparison.json", {"pr_bodies_before": len(before), "pr_bodies_after": len(after), "changed_or_added": changed,
    "parent_sha": final["parent"]["head_sha"], "main_sha": subprocess.check_output(["git", "rev-parse", "github/main"], text=True).strip(), "fix_ancestors": ancestry,
    "issues": "7绑定修复在祖先；8接口/预算/实板未决，保持打开；全部评论另存remote-issue-refresh.json",
    "discussion_gap": "连接器没有Discussion接口；无法读取不等同没有意见，本阶段不合并/关闭"})
print(json.dumps({"sources": len(materials), "final_sources": len(paths), "tools": len(tools), "remote_prs": len(after), "static_ast": True}, ensure_ascii=False))
