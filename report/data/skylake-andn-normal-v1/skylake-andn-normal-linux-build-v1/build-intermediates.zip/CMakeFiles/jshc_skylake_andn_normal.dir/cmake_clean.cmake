file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_andn_normal.dir/link.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/andn_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/andn_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/andn_outplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/andn_outplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/normal_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/normal_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_normal.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_andn_normal.dir/outplace_bench.cpp.o.d"
  "libjshc_skylake_andn_normal.pdb"
  "libjshc_skylake_andn_normal.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_andn_normal.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
