"""只读研究固定8³恒色砖块：128KiB粗表可否覆盖足够完整8像素包，不运行新内核。"""
from pathlib import Path
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
cube=ROOT/'artifacts/cinema-current-anchor-accept-v1/cube.rgb';photos=ROOT/'artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(cube)=='3c9ce8d98d8db454ce9337c50c2ecadb8ba59485d6bc3e6a42e3cc1dfe307c22'
assert sha(photos)=='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
rgb=np.memmap(cube,dtype=np.uint8,mode='r').reshape(256,256,256,3)
codes=rgb[:,:,:,0].astype(np.uint32)|(rgb[:,:,:,1].astype(np.uint32)<<8)|(rgb[:,:,:,2].astype(np.uint32)<<16)
bricks=codes.reshape(32,8,32,8,32,8);low=bricks.min(axis=(1,3,5));high=bricks.max(axis=(1,3,5));flags=(low==high).reshape(-1)
pixels=0;fast_pixels=0;packets=0;fast_packets=0
source=np.memmap(photos,dtype=np.uint8,mode='r').reshape(-1,3)
for start in range(0,len(source),2**20):
    data=source[start:start+2**20].astype(np.uint16)
    key=((data[:,0]>>3)<<10)|((data[:,1]>>3)<<5)|(data[:,2]>>3)
    fast=flags[key];pixels+=len(fast);fast_pixels+=int(fast.sum());packets+=len(fast)//8;fast_packets+=int(fast.reshape(-1,8).all(axis=1).sum())
fraction=fast_packets/packets
result={'purpose':__doc__,'tile_rgb':[8,8,8],'coarse_table_bytes':32768*4,'uniform_tiles':int(flags.sum()),'total_tiles':32768,'domain_fraction_uniform':float(flags.mean()),'photo_pixels':pixels,'photo_uniform_pixel_fraction':fast_pixels/pixels,'photo_packets':packets,'photo_all_uniform_packet_fraction':fraction,'predeclared_full_packet_interest_threshold':0.5,'candidate_proceeds':fraction>=0.5,'criterion':'低于50%完整包覆盖就停止此恒色粗表候选；这是研究筛选，不是运行时速度或不可达证明','input_sha256':{'cube':sha(cube),'photos':sha(photos)},'script_sha256':sha(Path(__file__)),'new_native_calls':0,'new_performance_calls':0}
out=ROOT/'artifacts/skylake-uniform-tiles-v1';out.mkdir(exist_ok=False);(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(result)
