"""将完整协作快照与上一阶段已读正文比较；祖先验证单独执行，不以CI代替。"""
from pathlib import Path
import json,subprocess,argparse
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--snapshot',default='audit-before');a=p.parse_args();current=Path(__file__).parent/a.snapshot;old=ROOT/'artifacts/skylake-threefold-delivery-v1/pre-create'
def read(x):return json.loads(x.read_text(encoding='utf-8'))
old_prs={x['number']:x for x in read(old/'prs.json')['items']};new_prs={x['number']:x for x in read(current/'prs.json')['items']}
changes=[]
for number,prev in old_prs.items():
    new=new_prs[number]
    for key in ('body','title'):
        if prev[key]!=new[key]:changes.append({'number':number,'field':key,'before':prev[key],'after':new[key]})
opinion=[]
for path in old.glob('*-comments.json'):
    if read(path)['items']!=read(current/path.name)['items']:opinion.append(path.name)
for path in old.glob('*-reviews.json'):
    if read(path)['items']!=read(current/path.name)['items']:opinion.append(path.name)
og=read(old/'graphql.json')['data']['repository'];ng=read(current/'graphql.json')['data']['repository']
gql=[key for key in og if og[key]!=ng[key]]
commits=['b19c5a0','337a3dd','876e15b8','397cc367','e3975ea','b3d7f4c','8355402','b55a444']
ancestors={c:subprocess.run(['git','merge-base','--is-ancestor',c,'HEAD'],cwd=ROOT).returncode==0 for c in commits}
assert all(ancestors.values())
prior=read(ROOT/'report/data/skylake-threefold-v1/remote-check.json')
for item in prior['related']:
    if item['url'].endswith('/pull/43'):item['status']='保留16历史结果；本阶段唯一计时参考为23，不乘算历史收益'
result={'scope':'全量PR/issue正文、评论、reviews、行内及GraphQL Discussion/审查线程；完整分页；与已读上一阶段正文逐项比较','summary':read(current/'summary.json'),'existing_body_changes':changes,'existing_opinion_changes':opinion,'existing_graphql_changes':gql,'new_prs':[{k:v for k,v in x.items() if k in ('number','title','body','html_url','state','draft')} for n,x in new_prs.items() if n not in old_prs],'included_commits':ancestors,'related':prior['related']+[{'url':'https://github.com/WyEhNf/flash-chroma/pull/47','status':'依赖b55a444检查点，正文与已发送文本逐字相同；没有评论/review/线程，常规CI成功不代替实验验收'},{'url':'https://github.com/WyEhNf/flash-chroma/pull/45','status':'22历史结果保留，不乘算收益'},{'url':'https://github.com/WyEhNf/flash-chroma/pull/46','status':'23作为当前唯一参考；头8355402，Draft无新增意见'}],'unresolved':prior['unresolved']+['相对23的3倍目标尚未达到，31—37仍未满足整体门槛；37仅四线程真实输出达到3.03倍'],'decision':'仅提交独立WIP/Draft研究，不合并、不改变已验23或公共默认','redaction':'快照递归剔除API临时克隆元数据字段；正文/评论不删改'}
(current/'check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print({'summary':result['summary'],'existing_body_changes':len(changes),'existing_opinion_changes':opinion,'existing_graphql_changes':gql,'new_prs':[x['number'] for x in result['new_prs']]})
