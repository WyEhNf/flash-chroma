"""冻结34保护页/只读源与完整RGB8验证；不以尾部哨兵替代读越界检查。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_loadindex_linux.py').read_text(encoding='utf-8').replace('精确独立字节载荷及真实融合输出33','RGB24宽输入密集输出34')
s=s.replace('from outplace_support import apply_to,reject_to', 'from outplace_support import apply_to,reject_to\nfrom guarded_buffer_support import guarded_apply')
s=s.replace("sources['scripts/outplace_support.py']=digest(ROOT/'scripts/outplace_support.py');", "sources['scripts/outplace_support.py']=digest(ROOT/'scripts/outplace_support.py'); sources['scripts/guarded_buffer_support.py']=digest(ROOT/'scripts/guarded_buffer_support.py');")
s=s.replace('out_finite=0; out_negative=0', 'out_finite=0; out_negative=0;guarded_count=0')
s=s.replace('                                out_finite+=2', '''                                out_finite+=2
                                if offset==0 and kernel==1:
                                    if guarded_apply(d,operators[name][mode],source,kernel,threads)!=expected:raise AssertionError('分离保护页输出不同')
                                    if guarded_apply(d,operators[name][mode],source,kernel,threads,same=True)!=expected:raise AssertionError('同址保护页输出不同')
                                    guarded_count+=2''')
s=s.replace("'outplace_full_pixels':out_counts,", "'guarded_page_comparisons':guarded_count,'outplace_full_pixels':out_counts,")
new='scripts/verify_skylake_pack32_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'34新增31/32/33/39/40/41/63/64/65边界、不可访问尾页与只读源、24组完整RGB8，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-pack32-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-pack32-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结34验证器，未运行')
