"""冻结35同机直接对23的唯一配对计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_pack32_linux.py').read_text(encoding='utf-8').replace('比较34与23','比较35与23').replace('bench_skylake_pack32_linux.py','bench_skylake_loadle_linux.py').replace('精确宽打包字节索引','精确小端字节索引')
s=s.replace("state['format']!=8", "state['format']!=9")
(ROOT/'scripts/bench_skylake_loadle_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_loadle_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-pack32-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-loadle-v1.json','build':'artifacts/skylake-loadle-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-loadle-linux-full-v1/results.json','validation':'experiments/skylake-loadle-validation-v1.json','benchmark_script':'scripts/bench_skylake_loadle_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('34','35').replace('RGB24宽输入及三次32字节密集输出','小端字节序输入与三次32字节密集输出')
(ROOT/'experiments/skylake-loadle-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结35性能策略，未运行')
