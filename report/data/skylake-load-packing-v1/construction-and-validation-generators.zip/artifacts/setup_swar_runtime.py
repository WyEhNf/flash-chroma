"""冻结36：小端精确索引配合64bit整数RGB24输出拼装，移除向量寄存器来回打包。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-loadle-runtime';out=ROOT/'experiments/skylake-swar-runtime';out.mkdir(exist_ok=False)
kernel='''// 36核心使用普通整数载荷和64bit拼装，仍经原AVX2资格分派；原回退保持。
#include "suffix_cache.hpp"
#include <cstring>
namespace jshc_channel {
namespace {
template<size_t Offset,bool Wide>
inline __attribute__((always_inline)) uint32_t lookup(const uint32_t* table,const uint32_t* palette,const uint8_t* source) {
  uint32_t code;
  if constexpr(Wide || Offset<21) {std::memcpy(&code,source+Offset,4);code&=0xffffff;}
  else {uint16_t low;std::memcpy(&low,source+Offset,2);code=uint32_t(low)|(uint32_t(source[Offset+2])<<16);}
  return palette[reinterpret_cast<const uint8_t*>(table)[code]];
}
template<bool Wide>
inline __attribute__((always_inline)) void packet(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination) {
  const uint32_t v0=lookup<0,Wide>(table,palette,source),v1=lookup<3,Wide>(table,palette,source),v2=lookup<6,Wide>(table,palette,source);
  const uint64_t a=uint64_t(v0)|(uint64_t(v1)<<24)|(uint64_t(v2)<<48);
  std::memcpy(destination,&a,8);
  // 已读取的颜色才会被覆盖；后续输入从第9字节开始，不与首个8字节输出重叠。
  const uint32_t v3=lookup<9,Wide>(table,palette,source),v4=lookup<12,Wide>(table,palette,source),v5=lookup<15,Wide>(table,palette,source);
  const uint64_t b=uint64_t(v2>>16)|(uint64_t(v3)<<8)|(uint64_t(v4)<<32)|(uint64_t(v5)<<56);
  std::memcpy(destination+8,&b,8);
  const uint32_t v6=lookup<18,Wide>(table,palette,source),v7=lookup<21,Wide>(table,palette,source);
  const uint64_t c=uint64_t(v5>>8)|(uint64_t(v6)<<16)|(uint64_t(v7)<<40);
  std::memcpy(destination+16,&c,8);
}
inline __attribute__((always_inline)) void run(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {
  size_t p=0;
  for(;p+16<=pixels;p+=8)packet<true>(table,palette,source+3*p,destination+3*p);
  for(;p<pixels;p+=8)packet<false>(table,palette,source+3*p,destination+3*p);
}
}
void avx2_chain_swar(const uint32_t* table,const uint32_t* palette,uint8_t* data,size_t pixels) noexcept {run(table,palette,data,data,pixels);}
void avx2_chain_swar_to(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {run(table,palette,source,destination,pixels);}
}
'''
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_loadle','skylake_swar').replace('avx2_chain_loadle','avx2_chain_swar')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 35;','jshc_cc_revision(void) {return 36;')
    if p.name=='channel_avx2.cpp':s=kernel
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-loadle-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；小端精确索引与整数RGB24拼装，避免向量寄存器转换',candidate='每8像素按3/3/2分组读色后拼装三个64bit输出，原地安全；边界最后像素精确3字节输入',revisions={'reference':23,'candidate':36},cmake_project='experiments/skylake-swar-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_swar'])
plan.pop('loadle_policy',None);plan['swar_policy']={'format':9,'table_bytes':2**24,'input_code':'R|(G<<8)|(B<<16)','wide_loop_pixels_required':16,'packet_pixels':8,'output_stores_u64':3,'new_core':'普通整数SWAR，不称向量数学提速；原CPU/AVX2分派与回退不变','guard_pages_required':True}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-loadle-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-swar-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结36，未构建或计时')
