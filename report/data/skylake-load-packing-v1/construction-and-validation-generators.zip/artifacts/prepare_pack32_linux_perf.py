"""冻结34同机对23计时，保持所有模式与全部原始轮次。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_loadindex_linux.py').read_text(encoding='utf-8').replace('比较33与23','比较34与23').replace('bench_skylake_loadindex_linux.py','bench_skylake_pack32_linux.py').replace('精确独立字节索引','精确宽打包字节索引')
(ROOT/'scripts/bench_skylake_pack32_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_pack32_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-loadindex-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-pack32-v1.json','build':'artifacts/skylake-pack32-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-pack32-linux-full-v1/results.json','validation':'experiments/skylake-pack32-validation-v1.json','benchmark_script':'scripts/bench_skylake_pack32_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('33','34').replace('独立标量ID和调色板载荷','RGB24宽输入及三次32字节密集输出')
(ROOT/'experiments/skylake-pack32-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结34计时策略，未运行')
