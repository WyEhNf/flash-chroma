"""冻结34：16MiB线性精确ID，32字节输入与三次32字节输出的RGB24打包。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-loadindex-runtime';out=ROOT/'experiments/skylake-pack32-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_loadindex','skylake_pack32').replace('avx2_chain_loadindex','avx2_chain_pack32')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 33;','jshc_cc_revision(void) {return 34;')
    if p.name=='channel_avx2.cpp':
        s=(ROOT/'experiments/skylake-tileindex-runtime/channel_avx2.cpp').read_text(encoding='utf-8').replace('avx2_chain_tileindex','avx2_chain_pack32')
        a=s.index('inline __attribute__((always_inline)) __m256i ids(');b=s.index('inline __attribute__((always_inline)) __m256i rgb(',a)
        linear=(ROOT/'experiments/skylake-pageindex-runtime/channel_avx2.cpp').read_text(encoding='utf-8');la=linear.index('inline __attribute__((always_inline)) __m256i ids(');lb=linear.index('inline __attribute__((always_inline)) __m256i rgb(',la)
        s=s[:a]+linear[la:lb]+s[b:]
        marker='inline __attribute__((always_inline)) __m256i ids('
        s=s.replace(marker,'''// 仅在后续至少还剩8像素时调用，32字节载荷严格落在当前线程块内。
inline __attribute__((always_inline)) __m256i input_wide(const uint8_t* p) {
  const __m256i raw=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(p));
  const __m256i lanes=_mm256_permutevar8x32_epi32(raw,_mm256_setr_epi32(0,1,2,0,3,4,5,0));
  return _mm256_shuffle_epi8(lanes,_mm256_setr_epi8(2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1,2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1));
}
'''+marker,1)
        marker='namespace {\ninline __attribute__((always_inline)) void run('
        s=s.replace(marker,'''namespace {
inline __attribute__((always_inline)) __m256i pack(__m256i value) {
  const __m256i bytes=_mm256_shuffle_epi8(value,_mm256_setr_epi8(0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1,0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1));
  return _mm256_permutevar8x32_epi32(bytes,_mm256_setr_epi32(0,1,2,4,5,6,3,7));
}
inline __attribute__((always_inline)) void output_four(uint8_t* p,__m256i v0,__m256i v1,__m256i v2,__m256i v3) {
  const __m128i a=_mm256_castsi256_si128(v0),b=_mm256_extracti128_si256(v0,1);
  const __m128i c=_mm256_castsi256_si128(v1),d=_mm256_extracti128_si256(v1,1);
  const __m128i e=_mm256_castsi256_si128(v2),f=_mm256_extracti128_si256(v2,1);
  const __m128i g=_mm256_castsi256_si128(v3),h=_mm256_extracti128_si256(v3,1);
  const __m256i s0=_mm256_inserti128_si256(_mm256_castsi128_si256(a),_mm_unpacklo_epi64(b,c),1);
  const __m256i s1=_mm256_inserti128_si256(_mm256_castsi128_si256(_mm_alignr_epi8(d,c,8)),e,1);
  const __m256i s2=_mm256_inserti128_si256(_mm256_castsi128_si256(_mm_unpacklo_epi64(f,g)),_mm_alignr_epi8(h,g,8),1);
  _mm256_storeu_si256(reinterpret_cast<__m256i*>(p),s0);
  _mm256_storeu_si256(reinterpret_cast<__m256i*>(p+32),s1);
  _mm256_storeu_si256(reinterpret_cast<__m256i*>(p+64),s2);
}
inline __attribute__((always_inline)) void run(''',1)
        s=s.replace('for(;p+32<=pixels;p+=32)', 'for(;p+40<=pixels;p+=32)')
        s=s.replace('c0=input(source+3*p),c1=input(source+3*p+24),c2=input(source+3*p+48),c3=input(source+3*p+72)', 'c0=input_wide(source+3*p),c1=input_wide(source+3*p+24),c2=input_wide(source+3*p+48),c3=input_wide(source+3*p+72)')
        s=s.replace('output(destination+3*p,r0);output(destination+3*p+24,r1);output(destination+3*p+48,r2);output(destination+3*p+72,r3);', 'output_four(destination+3*p,pack(r0),pack(r1),pack(r2),pack(r3));')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-loadindex-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；线性精确ID与RGB24宽输入/密集输出打包',candidate='4个8像素gather包，32字节输入load+permute+shuffle，96字节输出三次store；尾部继续精确24字节读取',revisions={'reference':23,'candidate':34},cmake_project='experiments/skylake-pack32-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_pack32'])
plan.pop('loadindex_policy',None);plan['pack32_policy']={'table_bytes':2**24,'unroll_packets':4,'wide_loop_pixels_required':40,'output_bytes':96,'output_stores':3,'guard_pages_required':True,'thread_chunk_reads_confined':True}
plan['contract']['lengths']=sorted(set(plan['contract']['lengths']+[31,32,33,39,40,41,63,64,65]))
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-loadindex-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-pack32-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结34，未构建或计时')
