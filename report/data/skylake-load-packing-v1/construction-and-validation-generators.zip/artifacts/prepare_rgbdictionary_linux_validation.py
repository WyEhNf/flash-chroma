"""冻结32独立RGB32块解码与完整输出合同。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_dictionary_linux.py').read_text(encoding='utf-8').replace('精确8颜色字典及真实融合输出31','精确RGB32字典及真实融合输出32')
s=s.replace("direct_state['format']!=216", "direct_state['format']!=224").replace('di.entries!=78478 or di.table_capacity_bytes!=524280','di.entries!=313912 or di.table_capacity_bytes!=2097120')
s=s.replace("dictionary_bytes[i:i+8] for i in range(0,len(dictionary_bytes),8)", "dictionary_bytes[i:i+32] for i in range(0,len(dictionary_bytes),32)")
a=s.index('                    old_words=(ct.c_uint32*');b=s.index('                    for start in range(0,2**24,65536):',a)
s=s[:a]+s[b:]
s=s.replace("                        ids=b''.join(chunks[int.from_bytes(raw[i:i+2],'little')] for i in range(0,len(raw),2))\n                        if b''.join(palette_rgb[i] for i in ids)!=cube[start*3:(start+65536)*3]:raise AssertionError('独立字典全表输出不符')", """                        packed=b''.join(chunks[int.from_bytes(raw[i:i+2],'little')] for i in range(0,len(raw),2))
                        if packed[3::4]!=bytes(65536):raise AssertionError('RGB32高字节未清零')
                        actual=bytearray(65536*3);actual[0::3]=packed[0::4];actual[1::3]=packed[1::4];actual[2::3]=packed[2::4]
                        if actual!=cube[start*3:(start+65536)*3]:raise AssertionError('独立RGB32字典全表输出不符')""")
s=s.replace('del dict_words,dictionary_bytes,chunks,old_words', 'del dict_words,dictionary_bytes,chunks')
s=s.replace('==48+2**22+4+524280','==48+2**22+4+2097120')
new='scripts/verify_skylake_rgbdictionary_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'32独立RGB32字典和全索引重建、24组完整RGB8及新增诊断拒绝，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-rgbdictionary-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py')},'oracle':'独立旧完整输出流，不复用构造器去重算法'}
(ROOT/'experiments/skylake-rgbdictionary-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结32验证器，未运行')
