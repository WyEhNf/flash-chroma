"""冻结37首次绑定配对计时，包含SFENCE与全部对齐前缀/尾部。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_loadle_pinned_linux.py').read_text(encoding='utf-8').replace('比较35与23','比较37与23').replace('bench_skylake_loadle_pinned_linux.py','bench_skylake_stream_pinned_linux.py').replace('小端独立字节索引','小端非临时输出索引').replace('35首次计时','37首次计时')
new='scripts/bench_skylake_stream_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-loadle-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-stream-v1.json','build':'artifacts/skylake-stream-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-stream-linux-full-v1/results.json','validation':'experiments/skylake-stream-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='37完整缓存行非临时输出，首次固定四物理核直接对23；SFENCE、普通前缀/尾部都包含于原生API'
(ROOT/'experiments/skylake-stream-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结37首次绑定性能策略，未计时')
