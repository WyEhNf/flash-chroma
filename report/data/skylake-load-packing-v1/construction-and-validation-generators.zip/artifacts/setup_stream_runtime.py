"""冻结37：64像素完整缓存行非临时输出、精确标量对齐前缀和SFENCE。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-loadle-runtime';out=ROOT/'experiments/skylake-stream-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_loadle','skylake_stream').replace('avx2_chain_loadle','avx2_chain_stream')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 35;','jshc_cc_revision(void) {return 37;')
    if p.name=='channel_avx2.cpp':
        a=s.index('inline __attribute__((always_inline)) void output_four(');b=s.index('inline __attribute__((always_inline)) void run(',a)
        helper=s[a:b].replace('void output_four(', 'void output_four_stream(')
        helper=helper.replace('_mm256_storeu_si256(', '_mm256_stream_si256(')
        s=s[:b]+helper+'''inline __attribute__((always_inline)) void scalar_one(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination) {
  const uint32_t code=uint32_t(source[0])|(uint32_t(source[1])<<8)|(uint32_t(source[2])<<16);
  const uint32_t value=palette[reinterpret_cast<const uint8_t*>(table)[code]];
  destination[0]=uint8_t(value);destination[1]=uint8_t(value>>8);destination[2]=uint8_t(value>>16);
}
'''+s[b:]
        a=s.index('  size_t p=0;',s.index('void run('));b=s.index('\n}\n }',a)
        s=s[:a]+'''  size_t p=0;
  // 对齐到完整64字节缓存行，避免前缀普通写与非临时写共享同一行。
  for(;p<pixels && (reinterpret_cast<uintptr_t>(destination+3*p)&63);++p)scalar_one(table,palette,source+3*p,destination+3*p);
  bool streamed=false;
  for(;p+72<=pixels;p+=64) {
    // 全部64像素先读后写，主体输出恰好192字节即三条完整缓存行。
    const __m256i r0=pack(read_wide(table,palette,source+3*p)),r1=pack(read_wide(table,palette,source+3*p+24));
    const __m256i r2=pack(read_wide(table,palette,source+3*p+48)),r3=pack(read_wide(table,palette,source+3*p+72));
    const __m256i r4=pack(read_wide(table,palette,source+3*p+96)),r5=pack(read_wide(table,palette,source+3*p+120));
    const __m256i r6=pack(read_wide(table,palette,source+3*p+144)),r7=pack(read_wide(table,palette,source+3*p+168));
    output_four_stream(destination+3*p,r0,r1,r2,r3);output_four_stream(destination+3*p+96,r4,r5,r6,r7);streamed=true;
  }
  // 在普通尾部、调用方读取和OpenMP barrier之前发布非临时写入。
  if(streamed)_mm_sfence();
  for(;p+40<=pixels;p+=32) {
    const __m256i r0=read_wide(table,palette,source+3*p),r1=read_wide(table,palette,source+3*p+24),r2=read_wide(table,palette,source+3*p+48),r3=read_wide(table,palette,source+3*p+72);
    output_four(destination+3*p,pack(r0),pack(r1),pack(r2),pack(r3));
  }
  for(;p+8<=pixels;p+=8)output(destination+3*p,read(table,palette,source+3*p));
  for(;p<pixels;++p)scalar_one(table,palette,source+3*p,destination+3*p);
'''+s[b:]
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-loadle-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；64像素完整缓存行非临时输出减少缓存污染',candidate='小端精确ID保持；标量对齐64B，8包先读后写，6次32B流写覆盖192B，SFENCE后普通尾部',revisions={'reference':23,'candidate':37},cmake_project='experiments/skylake-stream-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_stream'])
plan.pop('loadle_policy',None);plan['stream_policy']={'format':9,'table_bytes':2**24,'destination_alignment':64,'stream_pixels':64,'stream_output_bytes':192,'stream_stores':6,'wide_loop_pixels_required':72,'sfence':'仅已执行非临时写的路径，普通尾部与返回/barrier之前','alignment_validation':'目标全部64种字节偏移；保护页；完整色域','references':['https://doc.rust-lang.org/core/arch/x86_64/fn._mm256_stream_si256.html','https://www.intel.com/content/dam/doc/manual/64-ia-32-architectures-optimization-manual.pdf']}
plan['contract']['lengths']=sorted(set(plan['contract']['lengths']+[71,72,73,127,128,129,191,192,193,255,256,257]))
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-loadle-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-stream-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结37，未构建或计时')
