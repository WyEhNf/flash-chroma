"""冻结31：固定8输入颜色块的精确字典，4MiB索引加共享8字节ID串。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-tileindex-runtime';out=ROOT/'experiments/skylake-dictionary-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_tileindex','skylake_dictionary').replace('avx2_chain_tileindex','avx2_chain_dictionary')
    if p.name=='channel_runtime.cpp':
        s=s.replace('#include "aligned_table.hpp"','#include "aligned_table.hpp"\n#include <unordered_map>')
        s=s.replace('jshc_channel::AlignedTable direct_index;','jshc_channel::AlignedTable direct_index;\n  std::vector<uint32_t> dictionary_words;')
        s=s.replace('jshc_cc_revision(void) {return 30;','jshc_cc_revision(void) {return 31;')
        s=s.replace('h.direct_index.data(),h.output_palette.data()', 'h.direct_index.data(),h.dictionary_words.data(),h.output_palette.data()')
        a=s.index('      // 四个输入ID');b=s.index('    }catch(const std::bad_alloc&)',a)
        s=s[:a]+'''      // 按RGB顺序给相同8字节ID串分配字典号；超过u16容量则完整回退。
      std::unordered_map<uint64_t,uint16_t> intern;intern.reserve(65535);
      std::vector<uint16_t> indices(size_t{1}<<21);
      std::vector<uint32_t> dictionary;dictionary.reserve(2*65535);
      bool eligible=true;
      for(size_t block=0;block<(size_t{1}<<21);++block) {
        uint64_t key=0;
        for(unsigned k=0;k<8;++k) {
          const size_t i=block*8+k;
          const uint32_t v=uint32_t(rgb[3*i])|(uint32_t(rgb[3*i+1])<<8)|(uint32_t(rgb[3*i+2])<<16);
          key|=uint64_t(lookup[v])<<(8*k);
        }
        auto found=intern.find(key);
        if(found==intern.end()) {
          if(intern.size()==65535) {eligible=false;break;}
          const uint16_t id=uint16_t(intern.size());intern.emplace(key,id);
          dictionary.push_back(uint32_t(key));dictionary.push_back(uint32_t(key>>32));indices[block]=id;
        }else indices[block]=found->second;
      }
      if(eligible) {
        h.direct_index.allocate((size_t{1}<<20)+1);
        std::memcpy(h.direct_index.data(),indices.data(),indices.size()*sizeof(uint16_t));
        h.direct_index.data()[size_t{1}<<20]=0;h.dictionary_words.swap(dictionary);
        info.temporary_peak_bytes+=h.direct_index.bytes()+indices.capacity()*sizeof(uint16_t)+h.dictionary_words.capacity()*sizeof(uint32_t);
        // unordered_map实现相关内存没有伪装成精确峰值RSS，另列为未核算。
      }
'''+s[b:]
        s=s.replace('+h.direct_index.bytes();','+h.direct_index.bytes()+h.dictionary_words.capacity()*sizeof(uint32_t);')
        s=s.replace('h.palette_info.enabled,h.exceptions.size()', 'h.palette_info.enabled,h.exceptions.size()')
        s=s.replace('uint32_t(!h.direct_index.empty()),8,0,', 'uint32_t(!h.direct_index.empty()),216,0,')
        marker='int jshc_cc_get_paged_info('
        s=s.replace(marker,'''int jshc_cc_get_dictionary_info(const void* handle,jshc_cc_dictionary_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_dictionary_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);*output={1,uint32_t(!h.direct_index.empty()),h.dictionary_words.size(),h.dictionary_words.capacity()*sizeof(uint32_t)};return 0;
}
int jshc_cc_copy_dictionary(const void* handle,uint32_t* output,size_t entries) {
  if(!handle)return 1;const auto& h=*static_cast<const Handle*>(handle);
  if(entries!=h.dictionary_words.size() || (entries && !output))return 1;
  if(entries)std::memcpy(output,h.dictionary_words.data(),entries*sizeof(uint32_t));return 0;
}
'''+marker,1)
    if p.name=='suffix_cache.hpp':
        s=s.replace('void avx2_chain_dictionary(const uint32_t*,const uint32_t*,uint8_t*,size_t)', 'void avx2_chain_dictionary(const uint32_t*,const uint32_t*,const uint32_t*,uint8_t*,size_t)')
        s=s.replace('void avx2_chain_dictionary_to(const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t)', 'void avx2_chain_dictionary_to(const uint32_t*,const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t)')
        s+='''
extern "C" {
struct jshc_cc_dictionary_info {uint32_t version,enabled;uint64_t entries,table_capacity_bytes;};
JSHC_CC_API int jshc_cc_get_dictionary_info(const void*,jshc_cc_dictionary_info*,size_t);
JSHC_CC_API int jshc_cc_copy_dictionary(const void*,uint32_t*,size_t);
}
'''
    if p.name=='channel_avx2.cpp':
        a=s.index('inline __attribute__((always_inline)) __m256i ids(');b=s.index('inline __attribute__((always_inline)) __m256i rgb(',a)
        s=s[:a]+'''inline __attribute__((always_inline)) __m256i ids(const uint32_t* table,const uint32_t* dictionary,__m256i code) {
  const __m256i id=_mm256_and_si256(_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,3),2),_mm256_set1_epi32(65535));
  const __m256i index=_mm256_or_si256(_mm256_slli_epi32(id,1),_mm256_and_si256(_mm256_srli_epi32(code,2),_mm256_set1_epi32(1)));
  const __m256i word=_mm256_i32gather_epi32(reinterpret_cast<const int*>(dictionary),index,4);
  const __m256i shift=_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(3)),3);
  return _mm256_and_si256(_mm256_srlv_epi32(word,shift),_mm256_set1_epi32(255));
}
'''+s[b:]
        s=s.replace('const uint32_t* table,const uint32_t* palette,','const uint32_t* table,const uint32_t* dictionary,const uint32_t* palette,')
        s=s.replace('ids(table,','ids(table,dictionary,').replace('run(table,palette,','run(table,dictionary,palette,')
    write(p.name,s)
plan=json.loads((ROOT/'experiments/skylake-tileindex-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；精确8颜色字典，以4MiB索引替代16MiB直接索引，保留真实输出API',candidate='u16块号、两u32保存8个字节ID，三层gather；只从原模型构造，超过65535块完全回退',base_commit='b55a444',revisions={'reference':23,'candidate':31},cmake_project='experiments/skylake-dictionary-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_dictionary'])
for k in ('tileindex_policy','pageindex_policy'):plan.pop(k,None)
plan['dictionary_policy']={'input_colors_per_block':8,'max_unique_blocks':65535,'index_words':2**20+1,'index_bytes':2**22+4,'dictionary_reserved_words':2*65535,'extra_metadata':48,'construction_map_memory':'unordered_map桶/节点实现相关，不计入精确临时字节声明；准备墙钟全计'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-tileindex-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-dictionary-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结31，未构建或计时')
