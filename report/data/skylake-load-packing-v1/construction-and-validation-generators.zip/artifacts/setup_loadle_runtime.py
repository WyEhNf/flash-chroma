"""冻结35：线性表按输入小端字节码重排，简化独立载荷的RGB24地址解包。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-loadindex-runtime';out=ROOT/'experiments/skylake-loadle-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_loadindex','skylake_loadle').replace('avx2_chain_loadindex','avx2_chain_loadle')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 33;','jshc_cc_revision(void) {return 35;')
        s=s.replace('const size_t i=size_t(group)*4+k;', 'const uint32_t address=uint32_t(group)*4+k;\n          const size_t i=((address&255u)<<16)|(address&0xff00u)|(address>>16);')
        s=s.replace('uint32_t(!h.direct_index.empty()),8,0,','uint32_t(!h.direct_index.empty()),9,0,')
    if p.name=='channel_avx2.cpp':
        a=s.index('// 精确读取24字节输入');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''// 表按R低/G中/B高的输入字节序排列，输出RGB32的字节序保持原样。
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  uint64_t a,b,c;std::memcpy(&a,p,8);std::memcpy(&b,p+8,8);std::memcpy(&c,p+16,8);
  const auto value=[table,palette](uint32_t code) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code]]);};
  return _mm256_setr_epi32(value(uint32_t(a&0xffffff)),value(uint32_t((a>>24)&0xffffff)),
      value(uint32_t(((a>>48)|(b<<16))&0xffffff)),value(uint32_t((b>>8)&0xffffff)),
      value(uint32_t((b>>32)&0xffffff)),value(uint32_t(((b>>56)|(c<<8))&0xffffff)),
      value(uint32_t((c>>16)&0xffffff)),value(uint32_t(c>>40)));
}
// 仅宽循环调用；最后一个32bit输入读取多出的1字节仍在当前线程块内。
inline __attribute__((always_inline)) __m256i read_wide(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  const auto value=[table,palette,p](size_t offset) {uint32_t code;std::memcpy(&code,p+offset,4);return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code&0xffffff]]);};
  return _mm256_setr_epi32(value(0),value(3),value(6),value(9),value(12),value(15),value(18),value(21));
}
'''+s[b:]
        wide=(ROOT/'experiments/skylake-pack32-runtime/channel_avx2.cpp').read_text(encoding='utf-8');a=wide.index('inline __attribute__((always_inline)) __m256i pack(');b=wide.index('inline __attribute__((always_inline)) void run(',a)
        s=s.replace('inline __attribute__((always_inline)) void run(',wide[a:b]+'inline __attribute__((always_inline)) void run(',1)
        s=s.replace('for(;p+32<=pixels;p+=32)','for(;p+40<=pixels;p+=32)')
        s=s.replace('r0=read(table,palette,source+3*p),r1=read(table,palette,source+3*p+24),r2=read(table,palette,source+3*p+48),r3=read(table,palette,source+3*p+72)', 'r0=read_wide(table,palette,source+3*p),r1=read_wide(table,palette,source+3*p+24),r2=read_wide(table,palette,source+3*p+48),r3=read_wide(table,palette,source+3*p+72)')
        s=s.replace('output(destination+3*p,r0);output(destination+3*p+24,r1);output(destination+3*p+48,r2);output(destination+3*p+72,r3);','output_four(destination+3*p,pack(r0),pack(r1),pack(r2),pack(r3));')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-loadindex-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；小端RGB24精确索引、无bswap的独立载荷与密集输出',candidate='表地址R低G中B高；宽循环8个32bit输入读取后mask，边界精确24字节读取；三次32字节输出',revisions={'reference':23,'candidate':35},cmake_project='experiments/skylake-loadle-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_loadle'])
plan.pop('loadindex_policy',None);plan['loadle_policy']={'format':9,'table_bytes':2**24,'index':'R|(G<<8)|(B<<16)','unroll_packets':4,'hardware_gather':False,'bswap':False,'wide_loop_pixels_required':40,'output_stores':3,'guard_pages_required':True}
plan['contract']['lengths']=sorted(set(plan['contract']['lengths']+[31,32,33,39,40,41,63,64,65]))
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-loadindex-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-loadle-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结35，未构建或计时')
