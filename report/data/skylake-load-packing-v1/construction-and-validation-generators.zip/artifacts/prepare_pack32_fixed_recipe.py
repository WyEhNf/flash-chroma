"""提供34未来复现的汇总修复入口；原v2测量源和失败层保持原字节，不执行v3计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
old='scripts/bench_skylake_pack32_pinned_linux.py';new='scripts/bench_skylake_pack32_pinned_fixed_linux.py'
s=(ROOT/old).read_text(encoding='utf-8').replace('bench_skylake_pack32_pinned_linux.py','bench_skylake_pack32_pinned_fixed_linux.py')
s=s.replace("summary.append({'task_affinities_after_rounds':pinned_state(cpus),'variant'", "summary.append({'variant'")
s=s.replace('固定绑定v2只运行一次，v1团队失败原始记录完整保留','修复汇总层的复现入口；本阶段v3未执行，历史v2使用独立离线复算')
(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=json.loads((ROOT/'experiments/skylake-pack32-linux-perf-v2.json').read_text(encoding='utf-8'));p['benchmark_script']=spec(new)
p['purpose']='34未来复现修复入口，仅删除父汇总层误插入的worker局部变量；本阶段v3未执行'
p['reproduction_fix_for']={'policy':spec('experiments/skylake-pack32-linux-perf-v2.json'),'bug':'父汇总引用未定义cpus；四个已测worker不受影响，旧v2回执离线复算而不重测'}
(ROOT/'experiments/skylake-pack32-linux-perf-v3-recipe.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('保存34修复复现入口；v3没有运行')
