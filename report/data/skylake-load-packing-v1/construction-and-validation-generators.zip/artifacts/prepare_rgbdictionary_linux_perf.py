"""冻结32的固定配对计时，不重计31。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_dictionary_linux.py').read_text(encoding='utf-8').replace('比较31与23','比较32与23').replace('bench_skylake_dictionary_linux.py','bench_skylake_rgbdictionary_linux.py')
s=s.replace("state['format']!=216", "state['format']!=224").replace('v.entries!=78478 or v.table_capacity_bytes!=524280','v.entries!=313912 or v.table_capacity_bytes!=2097120')
(ROOT/'scripts/bench_skylake_rgbdictionary_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_rgbdictionary_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-dictionary-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-rgbdictionary-v1.json','build':'artifacts/skylake-rgbdictionary-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-rgbdictionary-linux-full-v1/results.json','validation':'experiments/skylake-rgbdictionary-validation-v1.json','benchmark_script':'scripts/bench_skylake_rgbdictionary_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('31','32').replace('8颜色精确字典','8颜色RGB32精确字典')
policy['limits'][1]='每个候选句柄smaps证明4MiB主体THP，末尾4字节保护不要求大页；字典实际313912词'
(ROOT/'experiments/skylake-rgbdictionary-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结32计时，未运行')
