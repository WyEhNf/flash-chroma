"""冻结36完整域、独立小端索引与保护页验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_loadle_linux.py').read_text(encoding='utf-8').replace('RGB24小端独立载荷与密集输出35','RGB24小端索引与整数拼装36')
new='scripts/verify_skylake_swar_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'36独立小端16M索引、整数原地拼装/保护页、只读源及24组完整域，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-swar-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-swar-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结36验证器，未运行')
