"""冻结37完整色域、保护页、全部64种目标对齐及原地别名检查。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_loadle_linux.py').read_text(encoding='utf-8').replace('RGB24小端独立载荷与密集输出35','RGB24非临时写入及完整缓存行37')
s=s.replace('out_negative=0;guarded_count=0','out_negative=0;guarded_count=0;alignment_count=0')
needle='            # 65536像素'
assert needle in s
s=s.replace(needle,'''            alignment_source=probe[:257*3]
            alignment_expected=b''.join(cube[(alignment_source[i]*65536+alignment_source[i+1]*256+alignment_source[i+2])*3:(alignment_source[i]*65536+alignment_source[i+1]*256+alignment_source[i+2])*3+3] for i in range(0,len(alignment_source),3))
            for name,d in libraries.items():
                for threads in (1,4):
                    for target_offset in range(64):
                        for source_offset in range(4):
                            if apply_to(d,operators[name]['chain'],alignment_source,1,threads,source_offset,target_offset)!=alignment_expected:raise AssertionError('完整64种目标对齐输出不同')
                            alignment_count+=1
                        if apply_to(d,operators[name]['chain'],alignment_source,1,threads,target_offset,target_offset,same=True)!=alignment_expected:raise AssertionError('完整64种原地对齐输出不同')
                        alignment_count+=1
'''+needle,1)
s=s.replace("'guarded_page_comparisons':guarded_count,", "'stream_alignment_comparisons':alignment_count,'guarded_page_comparisons':guarded_count,")
new='scripts/verify_skylake_stream_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'37完整16M表/24组色域、64种目标偏移独立源/别名1280比较、保护页和NT边界，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-stream-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-stream-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结37验证器，未运行')
