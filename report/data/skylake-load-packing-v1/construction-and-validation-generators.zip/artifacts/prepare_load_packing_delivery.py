"""派生阶段归档与协作核对，不修改旧档案或测量代码。"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'artifacts/skylake-load-packing-delivery-v1'
s=(ROOT/'artifacts/skylake-threefold-delivery-v1/check_remote.py').read_text(encoding='utf-8')
s=s.replace("old=ROOT/'artifacts/skylake-exception-delivery-v1'", "old=ROOT/'artifacts/skylake-threefold-delivery-v1/pre-create'")
s=s.replace("'8355402']", "'8355402','b55a444']")
s=s.replace('report/data/skylake-exception-v1/remote-check.json','report/data/skylake-threefold-v1/remote-check.json')
s=s.replace('24—30全部保留负门槛结论','31—37仍未满足整体门槛；37仅四线程真实输出达到3.03倍')
s=s.replace("'related':prior['related']+[", "'related':prior['related']+[{'url':'https://github.com/WyEhNf/flash-chroma/pull/47','status':'依赖b55a444检查点，正文与已发送文本逐字相同；没有评论/review/线程，常规CI成功不代替实验验收'},")
s=s.replace("print(json.dumps(result,ensure_ascii=False,indent=2))", "print({'summary':result['summary'],'existing_body_changes':len(changes),'existing_opinion_changes':opinion,'existing_graphql_changes':gql,'new_prs':[x['number'] for x in result['new_prs']]})")
(out/'check_remote.py').write_bytes(s.encode('utf-8'));compile(s,'check_remote.py','exec')
s=(ROOT/'artifacts/skylake-threefold-delivery-v1/archive.py').read_text(encoding='utf-8')
s=s.replace('24—30','31—37').replace('skylake-threefold-v1','skylake-load-packing-v1')
s=s.replace("names=['direct16','byteindex','paged32','pageindex','fused16','load16','tileindex']", "names=['dictionary','rgbdictionary','loadindex','pack32','loadle','swar','stream']")
a=s.index('for src,dirname in ');b=s.index("shutil.copyfile(Path(__file__).parent/'performance",a)
s=s[:a]+'''for src,dirname in [('skylake-uniform-tiles-v1','uniform-tiles'),('skylake-luma-certificate-v1','luma-certificate'),('skylake-pinned-openmp-v1','pinned-openmp'),('skylake-pmu-probe-v1','pmu-probe'),('skylake-pmu-profile-v1','pmu-profile')]:
    shutil.copytree(ROOT/'artifacts'/src,OUT/dirname)
'''+s[b:]
s=s.replace('performance-audit-final.json','performance-audit.json')
s=s.replace("('profile_threefold_structure.py','profile_tile_locality.py','probe_large_pages_readonly.py')", "('profile_uniform_tiles.py','profile_luma_certificate.py','prepare_pmu_profile.py','prepare_load_packing_delivery.py')")
s=s.replace("'base_commit':'83554020bee6b3313292d40d41d8f3a29b8b87de'", "'base_commit':'b55a444cac7ac7e4438eefa524e723a983be9e92'")
(out/'archive.py').write_bytes(s.encode('utf-8'));compile(s,'archive.py','exec');print('生成阶段归档器；尚未归档')
