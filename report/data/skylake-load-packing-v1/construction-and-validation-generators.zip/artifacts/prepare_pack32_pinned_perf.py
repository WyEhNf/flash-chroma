"""34原v1第四进程团队检查失败；另存固定绑定v2，不改v1源码、回执或轮次。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_pack32_linux.py').read_text(encoding='utf-8')
s=s.replace('bench_skylake_pack32_linux.py','bench_skylake_pack32_pinned_linux.py')
s=s.replace('from outplace_support import bind_to','from outplace_support import bind_to\nfrom pinned_openmp_support import probe as pinned_probe,state as pinned_state,require_environment,places')
s=s.replace("cpus=policy['affinity_cpus'];os.sched_setaffinity(0,cpus);top=topology(cpus)", "cpus=policy['affinity_cpus'];require_environment(cpus);os.sched_setaffinity(0,cpus);top=topology(cpus)")
s=s.replace('    index=args.worker_index', '    initial_team=pinned_probe(driver,4,cpus)\n    index=args.worker_index')
s=s.replace('probe=team(driver,threads,cpus)', 'probe=pinned_probe(driver,threads,cpus)')
s=s.replace("if sorted(os.sched_getaffinity(0))!=cpus:raise ValueError('实际主线程允许CPU变化')", "if sorted(os.sched_getaffinity(0))!=cpus[:1]:raise ValueError('实际主线程固定CPU变化')")
s=s.replace("'variant':role,'requested_threads':threads", "'task_affinities_after_rounds':pinned_state(cpus),'variant':role,'requested_threads':threads")
s=s.replace("'actual_affinity':sorted(os.sched_getaffinity(0)),'source_sha256'", "'initial_team':initial_team,'selected_cpus':cpus,'actual_affinity':sorted(os.sched_getaffinity(0)),'source_sha256'")
s=s.replace("'validation','benchmark_script')", "'validation','benchmark_script','pinning_support','pinning_probe')")
s=s.replace("'scripts/paged_table_support.py','scripts/outplace_support.py'", "'scripts/pinned_openmp_support.py','scripts/paged_table_support.py','scripts/outplace_support.py'")
s=s.replace("OMP_PROC_BIND='FALSE'", "OMP_PROC_BIND='TRUE',OMP_PLACES=places(policy['affinity_cpus'])")
s=s.replace("for key in ('OMP_PLACES','GOMP_CPU_AFFINITY'):", "for key in ('GOMP_CPU_AFFINITY',):")
s=s.replace("'actual_affinity':policy['affinity_cpus']", "'selected_cpus':policy['affinity_cpus'],'actual_main_affinity':[policy['affinity_cpus'][0]]")
s=s.replace('；只运行一次', '；固定绑定v2只运行一次，v1团队失败原始记录完整保留')
new='scripts/bench_skylake_pack32_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-pack32-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
policy['benchmark_script']=spec(new);policy['pinning_support']=spec('scripts/pinned_openmp_support.py');policy['pinning_probe']=spec('artifacts/skylake-pinned-openmp-v1/results.json')
policy['purpose']='34的v1第四进程团队检查失败；v2显式四位置和每线程固定CPU，仍直接对23，不选择或补齐v1轮次'
policy['affinity_protocol']={'OMP_PROC_BIND':'TRUE','OMP_PLACES':'{0},{2},{4},{6}','main_cpu':0,'selected_physical_cpus':[0,2,4,6],'validation':'初始4线程与每档团队的实际CPU顺序、前后每TID单CPU允许集合；不更改系统设置'}
policy['supersedes_incomplete']={'run':spec('artifacts/skylake-pack32-linux-perf-v1/run.json'),'reason':'worker3团队未覆盖不同物理核；只有worker0—2回执，没有完整results，不参与新汇总'}
policy['limits'].append('v2为显式线程绑定的新协议，不与旧未绑定绝对时间或比值叠乘')
(ROOT/'experiments/skylake-pack32-linux-perf-v2.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结34绑定v2策略，未计时')
