"""冻结独立计数画像；不调用本机四进程计时器，不回写任何性能结果。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
cases={}
for label,name,role,revision in [('reference23','loadle','reference',23),('loadindex33','loadindex','candidate',33),('loadle35','loadle','candidate',35),('stream37','stream','candidate',37)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    cases[label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':role,'library':read(build)['libraries'][role]}
policy={'purpose':'探索单次用户态硬件计数，分析指令/周期/cache事件；不是重新生成墙钟或三倍验收','probe':spec('artifacts/skylake-pmu-probe-v1/results.json'),'script':spec('scripts/profile_skylake_pmu.py'),'pinning_probe':spec('artifacts/skylake-pinned-openmp-v1/results.json'),'models_plan':spec('experiments/skylake-loadle-v1.json'),'cases':cases,'cpus':[0,2,4,6],'orders':[{'threads':1,'variants':['reference23','loadindex33','loadle35','stream37']},{'threads':4,'variants':['stream37','loadle35','loadindex33','reference23']}],'photos':read('experiments/skylake-loadle-linux-perf-v1.json')['photos'],'driver':read('experiments/skylake-loadle-linux-perf-v1.json')['driver'],'expected_output_sha256':'f3c0d9078bbcf069f33060a45021a28985b70c9616493ba9bea1ac2027858528','events':['cycles','instructions','cache_references','cache_misses'],'counter_scope':'每个参与TID独立组，exclude_kernel/exclude_hv，启停与ct开销少量包含；running/enabled>=0.99才可解释','python_sources':['scripts/profile_skylake_pmu.py','scripts/probe_skylake_pmu.py','scripts/pinned_openmp_support.py','scripts/paged_table_support.py','scripts/skylake_server_support.py','scripts/verify_skylake_linux_stdlib.py'],'reference':'https://man7.org/linux/man-pages/man2/perf_event_open.2.html','limits':['不计墙钟，不替代已冻结ABBA性能','泛化cache计数与具体缓存层的映射依赖CPU/虚拟PMU，不冒充精确L3指标','不改系统权限/缓解，不安装工具','每配置一个预热与一个计数调用，完整235MB输出SHA及保护区验证']}
(ROOT/'experiments/skylake-pmu-profile-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结PMU画像，尚未调用候选或计时器')
