"""冻结31同机对23的固定配对性能策略。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_fused16_linux.py').read_text(encoding='utf-8').replace('比较28与23','比较31与23').replace('bench_skylake_fused16_linux.py','bench_skylake_dictionary_linux.py')
s=s.replace("state['format']!=16 or state['table_capacity_bytes']!=2**25+4 or not pages['aligned_2m'] or pages['anon_huge_bytes']<2**25", "state['format']!=216 or state['table_capacity_bytes']!=2**22+4 or not pages['aligned_2m'] or pages['anon_huge_bytes']<2**22")
s=s.replace('32MiB精确16bit及主体THP','4MiB精确字典索引及主体THP')
s=s.replace('                f=d.jshc_cc_bench;', '''                dictionary_state=None
                if role=='candidate':
                    class DictionaryInfo(ct.Structure):
                        _fields_=[('version',ct.c_uint32),('enabled',ct.c_uint32),('entries',ct.c_uint64),('table_capacity_bytes',ct.c_uint64)]
                    v=DictionaryInfo();get_dict=d.jshc_cc_get_dictionary_info
                    get_dict.argtypes=[ct.c_void_p,ct.POINTER(DictionaryInfo),ct.c_size_t];get_dict.restype=ct.c_int
                    if get_dict(handle,ct.byref(v),ct.sizeof(v)) or v.version!=1 or v.enabled!=1 or v.entries!=78478 or v.table_capacity_bytes!=524280:raise ValueError('候选实际字典不符')
                    dictionary_state={k:getattr(v,k) for k,_ in v._fields_}
                f=d.jshc_cc_bench;''')
s=s.replace("'direct_info':state,'paged_info':pages", "'direct_info':state,'dictionary_info':dictionary_state,'paged_info':pages")
(ROOT/'scripts/bench_skylake_dictionary_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_dictionary_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-fused16-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-dictionary-v1.json','build':'artifacts/skylake-dictionary-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-dictionary-linux-full-v1/results.json','validation':'experiments/skylake-dictionary-validation-v1.json','benchmark_script':'scripts/bench_skylake_dictionary_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('28','31')+'；8颜色精确字典'
policy['limits'][1]='每个候选句柄smaps证明4MiB主体THP，末尾4字节保护不要求大页；字典实际78478词'
(ROOT/'experiments/skylake-dictionary-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结31计时，未运行')
