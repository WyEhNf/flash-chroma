"""冻结35小端坐标独立解码、保护页与完整RGB8验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_pack32_linux.py').read_text(encoding='utf-8').replace('RGB24宽输入密集输出34','RGB24小端独立载荷与密集输出35')
s=s.replace("direct_state['format']!=8", "direct_state['format']!=9")
a=s.index('                    for start in range(0,2**24,65536):');b=s.index('                    guard=',a)
s=s[:a]+'''                    raw_table=ct.string_at(words,2**24)
                    for red in range(256):
                        # 固定R后，物理次序为B外层/G内层；独立按坐标转回RGB次序。
                        plane=raw_table[red::256];ids=b''.join(plane[g::256] for g in range(256))
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                        start=red*65536
                        if b''.join(palette_rgb[i] for i in ids)!=cube[start*3:(start+65536)*3]:raise AssertionError('独立小端字节索引全表不符')
                    del old_words,raw_table
'''+s[b:]
new='scripts/verify_skylake_loadle_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'35小端坐标独立重建16M表、宽载荷边界/保护页、只读源及24组完整域，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-loadle-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-loadle-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结35验证器，未运行')
