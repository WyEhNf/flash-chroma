"""冻结36首次固定绑定计时，直接对23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_loadle_pinned_linux.py').read_text(encoding='utf-8').replace('比较35与23','比较36与23').replace('bench_skylake_loadle_pinned_linux.py','bench_skylake_swar_pinned_linux.py').replace('小端独立字节索引','小端整数拼装字节索引').replace('35首次计时','36首次计时')
new='scripts/bench_skylake_swar_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-loadle-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-swar-v1.json','build':'artifacts/skylake-swar-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-swar-linux-full-v1/results.json','validation':'experiments/skylake-swar-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='36小端精确索引及64bit整数RGB24拼装，首次固定四物理核位置直接对23；全部模式保留'
(ROOT/'experiments/skylake-swar-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结36首次绑定性能策略，未计时')
