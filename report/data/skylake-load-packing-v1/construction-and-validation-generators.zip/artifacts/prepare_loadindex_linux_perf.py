"""冻结33同机直接对23配对计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_tileindex_linux.py').read_text(encoding='utf-8').replace('比较30与23','比较33与23').replace('bench_skylake_tileindex_linux.py','bench_skylake_loadindex_linux.py').replace('精确分块索引','精确独立字节索引')
(ROOT/'scripts/bench_skylake_loadindex_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_loadindex_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-tileindex-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-loadindex-v1.json','build':'artifacts/skylake-loadindex-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-loadindex-linux-full-v1/results.json','validation':'experiments/skylake-loadindex-validation-v1.json','benchmark_script':'scripts/bench_skylake_loadindex_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('30','33').replace('4×4×4颜色共享缓存行','独立标量ID和调色板载荷')
(ROOT/'experiments/skylake-loadindex-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结33性能策略，未运行')
