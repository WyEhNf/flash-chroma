"""35首次计时采用已验证显式绑定；只修正34v2的父进程汇总误插入，不修改34记录。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_pack32_pinned_linux.py').read_text(encoding='utf-8').replace('比较34与23','比较35与23').replace('bench_skylake_pack32_pinned_linux.py','bench_skylake_loadle_pinned_linux.py')
s=s.replace("summary.append({'task_affinities_after_rounds':pinned_state(cpus),'variant'", "summary.append({'variant'")
s=s.replace("state['format']!=8", "state['format']!=9").replace('宽打包字节索引','小端独立字节索引')
s=s.replace('固定绑定v2只运行一次，v1团队失败原始记录完整保留', '35首次计时，固定绑定只运行一次；34失败记录另外保存，不混算')
new='scripts/bench_skylake_loadle_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-pack32-linux-perf-v2.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-loadle-v1.json','build':'artifacts/skylake-loadle-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-loadle-linux-full-v1/results.json','validation':'experiments/skylake-loadle-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='35小端独立载荷及密集输出，首次固定四物理核位置直接对23；保留全部模式'
policy['binding_motivation']=policy.pop('supersedes_incomplete')
(ROOT/'experiments/skylake-loadle-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结35首次绑定性能策略，未计时')
