"""冻结33：16MiB线性字节ID，独立标量载荷同时读ID与调色板；AVX2只打包输出。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-tileindex-runtime';out=ROOT/'experiments/skylake-loadindex-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_tileindex','skylake_loadindex').replace('avx2_chain_tileindex','avx2_chain_loadindex')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 30;','jshc_cc_revision(void) {return 33;')
        s=s.replace('const uint32_t address=uint32_t(group)*4+k;\n          const size_t i=(address&0xfc0003u)|((address&0x03f000u)>>2)|((address&0x000fc0u)>>4)|((address&0x30u)<<12)|((address&0x0cu)<<6);', 'const size_t i=size_t(group)*4+k;')
    if p.name=='channel_avx2.cpp':
        s=s.replace('#include <immintrin.h>','#include <immintrin.h>\n#include <cstring>')
        a=s.index('inline __attribute__((always_inline)) __m256i input(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''// 精确读取24字节输入；八个独立字节ID与RGB32载荷，不使用硬件gather。
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  uint64_t a,b,c;std::memcpy(&a,p,8);std::memcpy(&b,p+8,8);std::memcpy(&c,p+16,8);
  a=__builtin_bswap64(a);b=__builtin_bswap64(b);c=__builtin_bswap64(c);
  const auto value=[table,palette](uint32_t code) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code]]);};
  return _mm256_setr_epi32(value(uint32_t(a>>40)),value(uint32_t((a>>16)&0xffffff)),
      value(uint32_t(((a&0xffff)<<8)|(b>>56))),value(uint32_t((b>>32)&0xffffff)),
      value(uint32_t((b>>8)&0xffffff)),value(uint32_t(((b&255)<<16)|(c>>48))),
      value(uint32_t((c>>24)&0xffffff)),value(uint32_t(c&0xffffff)));
}
'''+s[b:]
        a=s.index('    const __m256i c0=input(');b=s.index('    output(destination',a)
        s=s[:a]+'''    const __m256i r0=read(table,palette,source+3*p),r1=read(table,palette,source+3*p+24),r2=read(table,palette,source+3*p+48),r3=read(table,palette,source+3*p+72);
'''+s[b:]
        s=s.replace('const __m256i c=input(source+3*p);output(destination+3*p,rgb(palette,ids(table,c)));', 'output(destination+3*p,read(table,palette,source+3*p));')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-tileindex-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；16MiB线性字节ID的两级独立标量读取，不使用硬件gather',candidate='三次64bit输入读取，八个字节ID+调色板独立载荷，AVX2输出打包',base_commit='b55a444',revisions={'reference':23,'candidate':33},cmake_project='experiments/skylake-loadindex-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_loadindex'])
plan.pop('tileindex_policy',None)
plan['loadindex_policy']={'format':8,'table_bytes':2**24,'hardware_gather':False,'input_loads_per_8':3,'unroll_packets':4,'extra_metadata':24}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-tileindex-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-loadindex-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结33，未构建或计时')
