"""只读认证固定整数投影77R+150G+29B的全域恒色键；不允许近似代替原输出。"""
from pathlib import Path
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parents[1];cube=ROOT/'artifacts/cinema-current-anchor-accept-v1/cube.rgb';photos=ROOT/'artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(cube)=='3c9ce8d98d8db454ce9337c50c2ecadb8ba59485d6bc3e6a42e3cc1dfe307c22'
assert sha(photos)=='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
rgb=np.memmap(cube,dtype=np.uint8,mode='r').reshape(256,256,256,3)
codes=rgb[:,:,:,0].astype(np.uint32)|(rgb[:,:,:,1].astype(np.uint32)<<8)|(rgb[:,:,:,2].astype(np.uint32)<<16)
colors=np.unique(codes);rank=np.searchsorted(colors,codes).astype(np.uint16)
low=np.full(65281,65535,dtype=np.uint16);high=np.zeros(65281,dtype=np.uint16);counts=np.zeros(65281,dtype=np.uint32)
gb=150*np.arange(256,dtype=np.uint32)[:,None]+29*np.arange(256,dtype=np.uint32)[None,:]
for r in range(256):
    keys=(r*77+gb).ravel();values=rank[r].ravel();np.minimum.at(low,keys,values);np.maximum.at(high,keys,values);np.add.at(counts,keys,1)
valid=(counts>0)&(low==high);span=high.astype(np.int32)-low.astype(np.int32)
pixels=0;fast_pixels=0;packets=0;fast_packets=0
source=np.memmap(photos,dtype=np.uint8,mode='r').reshape(-1,3)
for start in range(0,len(source),2**20):
    x=source[start:start+2**20].astype(np.uint32);keys=77*x[:,0]+150*x[:,1]+29*x[:,2];fast=valid[keys]
    pixels+=len(fast);fast_pixels+=int(fast.sum());packets+=len(fast)//8;fast_packets+=int(fast.reshape(-1,8).all(axis=1).sum())
fraction=fast_packets/packets
result={'purpose':__doc__,'weights':[77,150,29],'key_shift':0,'key_entries':65281,'coarse_rgb32_bytes':65281*4,'reachable_keys':int(np.count_nonzero(counts)),'certified_constant_keys':int(valid.sum()),'domain_constant_key_pixel_fraction':int(counts[valid].sum())/2**24,'photo_constant_key_pixel_fraction':fast_pixels/pixels,'photo_all_constant_key_packet_fraction':fraction,'predeclared_full_packet_interest_threshold':0.5,'candidate_proceeds':fraction>=0.5,'domain_fraction_output_colour_rank_span_le3':int(counts[(counts>0)&(span<=3)].sum())/2**24,'limitation':'全域认证相同整数键必须输出同色；不是拟合灰度近似，不是速度或不可达证明。颜色rank只来自最终221色，不等同运行时230项palette ID。','input_sha256':{'cube':sha(cube),'photos':sha(photos)},'script_sha256':sha(Path(__file__)),'new_native_calls':0,'new_performance_calls':0}
out=ROOT/'artifacts/skylake-luma-certificate-v1';out.mkdir(exist_ok=False);(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(result)
