"""冻结31完整色域和独立字典解码；先验证后计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_fused16_linux.py').read_text(encoding='utf-8').replace('精确16bit及真实融合输出28','精确8颜色字典及真实融合输出31')
s=s.replace("direct_state['format']!=16 or direct_state['entries']!=2**23+1 or direct_state['table_capacity_bytes']!=2**25+4", "direct_state['format']!=216 or direct_state['entries']!=2**20+1 or direct_state['table_capacity_bytes']!=2**22+4")
s=s.replace("pages_state['bytes']!=2**25+4", "pages_state['bytes']!=2**22+4").replace('words=(ct.c_uint32*(2**23+1))()', 'words=(ct.c_uint32*(2**20+1))()')
a=s.index("                    if words[-1]!=0:");b=s.index('                    guard=',a)
s=s[:a]+'''                    if words[-1]!=0:raise AssertionError('索引末端零保护词不符')
                    class DictionaryInfo(ct.Structure):
                        _fields_=[('version',ct.c_uint32),('enabled',ct.c_uint32),('entries',ct.c_uint64),('table_capacity_bytes',ct.c_uint64)]
                    di=DictionaryInfo();get_dict=d.jshc_cc_get_dictionary_info
                    get_dict.argtypes=[ct.c_void_p,ct.POINTER(DictionaryInfo),ct.c_size_t];get_dict.restype=ct.c_int
                    if get_dict(h,ct.byref(di),ct.sizeof(di)) or di.version!=1 or di.enabled!=1 or di.entries!=78478 or di.table_capacity_bytes!=524280:raise ValueError('实际字典未启用预期精确块')
                    dict_words=(ct.c_uint32*di.entries)();copy_dict=d.jshc_cc_copy_dictionary
                    copy_dict.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t];copy_dict.restype=ct.c_int
                    if copy_dict(h,dict_words,len(dict_words)):raise ValueError('字典快照失败')
                    dictionary_state={n:getattr(di,n) for n,_ in di._fields_}
                    dictionary_hash=hashlib.sha256(memoryview(dict_words).cast('B')).hexdigest()
                    dictionary_bytes=ct.string_at(dict_words,di.entries*4)
                    chunks=tuple(dictionary_bytes[i:i+8] for i in range(0,len(dictionary_bytes),8))
                    if len(set(chunks))!=len(chunks):raise AssertionError('字典未唯一化')
                    old_words=(ct.c_uint32*(2**21))();palette=(ct.c_uint32*256)()
                    cp=d.jshc_cc_copy_palette;cp.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t,ct.POINTER(ct.c_uint32),ct.c_size_t];cp.restype=ct.c_int
                    if cp(h,old_words,len(old_words),palette,256):raise ValueError('原调色板快照失败')
                    palette_rgb=tuple(int(v).to_bytes(4,'little')[:3] for v in palette)
                    for start in range(0,2**24,65536):
                        raw=ct.string_at(ct.addressof(words)+start//8*2,65536//8*2)
                        ids=b''.join(chunks[int.from_bytes(raw[i:i+2],'little')] for i in range(0,len(raw),2))
                        if b''.join(palette_rgb[i] for i in ids)!=cube[start*3:(start+65536)*3]:raise AssertionError('独立字典全表输出不符')
                    guard_dict=(ct.c_uint32*8)(*[0xa7a7a7a7]*8)
                    for handle,pointer,count in [(None,guard_dict,len(dict_words)),(h,guard_dict,len(dict_words)-1),(h,None,len(dict_words))]:
                        if copy_dict(handle,pointer,count)!=1 or list(guard_dict)!=[0xa7a7a7a7]*8:raise AssertionError('字典复制拒绝改写')
                    ct.memset(ct.byref(di),0xa7,ct.sizeof(di));before=bytes(di)
                    for handle,pointer,count in [(None,ct.byref(di),ct.sizeof(di)),(h,None,ct.sizeof(di)),(h,ct.byref(di),ct.sizeof(di)-1)]:
                        if get_dict(handle,pointer,count)!=1 or bytes(di)!=before:raise AssertionError('字典诊断拒绝改写')
                    del dict_words,dictionary_bytes,chunks,old_words
'''+s[b:]
s=s.replace("memory['candidate']['single']-memory['reference']['single']==32", "memory['candidate']['single']-memory['reference']['single']==48").replace("memory['candidate']['chain']-memory['reference']['chain']==32+2**25+4", "memory['candidate']['chain']-memory['reference']['chain']==48+2**22+4+524280")
s=s.replace("'direct_info':direct_state,", "'dictionary_info':dictionary_state,'dictionary_sha256':dictionary_hash,'direct_info':direct_state,")
new='scripts/verify_skylake_dictionary_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'31独立字典和全索引重建、24组完整RGB8及新字典6条拒绝，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-dictionary-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py')},'oracle':'独立旧完整输出流，不复用构造器哈希算法'}
(ROOT/'experiments/skylake-dictionary-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结31验证器，未运行')
