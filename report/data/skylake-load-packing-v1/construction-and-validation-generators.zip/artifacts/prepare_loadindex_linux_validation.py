"""冻结33线性字节表、完整色域与真实输出验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_tileindex_linux.py').read_text(encoding='utf-8').replace('精确分块索引及真实融合输出30','精确独立字节载荷及真实融合输出33')
a=s.index('                    raw_table=ct.string_at(');b=s.index('                    guard=',a)
s=s[:a]+'''                    for start in range(0,2**24,65536):
                        ids=ct.string_at(ct.addressof(words)+start,65536)
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                        truth=cube[start*3:(start+65536)*3]
                        if b''.join(palette_rgb[i] for i in ids)!=truth:raise AssertionError('独立线性字节索引全表不符')
                    del old_words
'''+s[b:]
new='scripts/verify_skylake_loadindex_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'33完整16M字节索引独立解码、24组全域、源只读及重叠合同，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-loadindex-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py')}}
(ROOT/'experiments/skylake-loadindex-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结33验证器，未运行')
