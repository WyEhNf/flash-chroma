"""冻结32：相同8输入块u16字典索引，字典直接保存RGB32，减少一次依赖查表。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-dictionary-runtime';out=ROOT/'experiments/skylake-rgbdictionary-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_dictionary','skylake_rgbdictionary').replace('avx2_chain_dictionary','avx2_chain_rgbdictionary')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 31;','jshc_cc_revision(void) {return 32;').replace('dictionary.reserve(2*65535)','dictionary.reserve(8*65535)')
        s=s.replace('dictionary.push_back(uint32_t(key));dictionary.push_back(uint32_t(key>>32));', 'for(unsigned k=0;k<8;++k)dictionary.push_back(h.output_palette[uint8_t(key>>(8*k))]);')
        s=s.replace('h.direct_index.data(),h.dictionary_words.data(),h.output_palette.data()', 'h.direct_index.data(),h.dictionary_words.data()')
        s=s.replace('uint32_t(!h.direct_index.empty()),216,0,', 'uint32_t(!h.direct_index.empty()),224,0,')
    if p.name=='suffix_cache.hpp':
        s=s.replace('void avx2_chain_rgbdictionary(const uint32_t*,const uint32_t*,const uint32_t*,uint8_t*,size_t)', 'void avx2_chain_rgbdictionary(const uint32_t*,const uint32_t*,uint8_t*,size_t)')
        s=s.replace('void avx2_chain_rgbdictionary_to(const uint32_t*,const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t)', 'void avx2_chain_rgbdictionary_to(const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t)')
    if p.name=='channel_avx2.cpp':
        a=s.index('inline __attribute__((always_inline)) __m256i ids(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''inline __attribute__((always_inline)) __m256i lookup(const uint32_t* table,const uint32_t* dictionary,__m256i code) {
  const __m256i id=_mm256_and_si256(_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,3),2),_mm256_set1_epi32(65535));
  const __m256i index=_mm256_or_si256(_mm256_slli_epi32(id,3),_mm256_and_si256(code,_mm256_set1_epi32(7)));
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(dictionary),index,4);
}
'''+s[b:]
        s=s.replace('const uint32_t* dictionary,const uint32_t* palette,', 'const uint32_t* dictionary,')
        a=s.index('    const __m256i i0=ids(');b=s.index('    output(destination',a)
        s=s[:a]+'''    const __m256i r0=lookup(table,dictionary,c0),r1=lookup(table,dictionary,c1),r2=lookup(table,dictionary,c2),r3=lookup(table,dictionary,c3);
'''+s[b:]
        s=s.replace('rgb(palette,ids(table,dictionary,c))', 'lookup(table,dictionary,c)').replace('run(table,dictionary,palette,','run(table,dictionary,')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-dictionary-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；4MiB u16索引及RGB32块字典，以容量交换一次依赖gather',candidate='固定同样8颜色块，字典存8个RGB32，不再通过ID调色板输出',revisions={'reference':23,'candidate':32},cmake_project='experiments/skylake-rgbdictionary-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_rgbdictionary'])
plan['dictionary_policy']['dictionary_reserved_words']=8*65535;plan['dictionary_policy']['value_format']='每块8个RGB32，仍以8字节ID串去重'
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-dictionary-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-rgbdictionary-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结32，尚未构建或计时')
