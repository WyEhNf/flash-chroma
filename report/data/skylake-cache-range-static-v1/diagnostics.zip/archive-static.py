import json,hashlib,shutil,zipfile
from pathlib import Path
ROOT=Path.cwd();build=Path(__file__).resolve().parent;out=ROOT/'report/data/skylake-cache-range-static-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if out.exists():raise ValueError('不覆盖静态档案')
out.mkdir()
for name in ('build.json','build-log.json','compile_commands.json','measured-source.zip'):
 shutil.copyfile(build/name,out/('build-'+name))
shutil.copyfile(ROOT/'experiments/skylake-cache-range-v1.json',out/'plan.json')
shutil.copyfile(build/'cached-static-v1/results.json',out/'analysis.json')
shutil.copyfile(ROOT/'artifacts/skylake-cache-range-design-v1.json',out/'initial-design.json')
with zipfile.ZipFile(out/'diagnostics.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((build/'cached-static-v1').iterdir()):
  if p.is_file():z.write(p,p.name)
 z.write(ROOT/'scripts/inspect_skylake_avx2.py','parser-source.py')
 z.write(ROOT/'artifacts/skylake-cache-range-design-v1.py','source-generator.py')
 z.write(Path(__file__),'archive-static.py')
objects=[]
for target in ('jshc_skylake_reference','jshc_skylake_cache_range'):
 for name in ('channel_runtime.cpp.obj','channel_avx2.cpp.obj'):
  found=[p for p in build.rglob(name) if target+'.dir' in p.parts]
  assert len(found)==1;objects.append((target+'/'+name,found[0]))
with zipfile.ZipFile(out/'built-not-executed.zip','w',zipfile.ZIP_DEFLATED) as z:
 for role,s in read(build/'build.json')['libraries'].items():z.write(s['path'],role+'/'+Path(s['path']).name)
 for name,path in objects:z.write(path,name)
old=ROOT/'artifacts/skylake-delta-cache-build-v1';equivalence=[]
for name in ('channel_runtime.cpp.obj','channel_avx2.cpp.obj'):
 a=[p for p in old.rglob(name) if 'jshc_skylake_delta_cache.dir' in p.parts]
 b=[p for p in build.rglob(name) if 'jshc_skylake_reference.dir' in p.parts]
 assert len(a)==len(b)==1
 equivalence.append({'file':name,'old_combo_sha256':sha(a[0]),'current_reference_sha256':sha(b[0]),'byte_equal':a[0].read_bytes()==b[0].read_bytes()})
assert all(x['byte_equal'] for x in equivalence)
save(out/'decision.json',{'purpose':'数学证明与静态潜力审核；信号不足，停止而不运行数值或性能',
 'reference_objects_equal_previous_passed_combo':equivalence,'runtime_validation_performed':False,
 'full_domain_performed':False,'photo_validation_performed':False,'performance_performed':False,
 'decision':'stop_static_not_adopted','reason':'各少13条指令但Total Cycles一增一减，吞吐下界仅约1.2%改善；不支持实质加速判断',
 'sources':[{'path':str(p),'sha256':sha(p)} for p in (Path('E:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avx2intrin.h'),Path('E:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/avxintrin.h'))],
 'primary_documentation':['https://clang.llvm.org/doxygen/avx2intrin_8h.html','https://www.intel.com/content/dam/develop/external/us/en/documents/cpp_compiler_classic.pdf'],
 'new_native_calls':0,'new_fits':0,'new_performance_calls':0})
save(out/'manifest.json',{'purpose':'范围判定简化的静态停止证据；没有数值或性能验收',
 'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()},
 'scope':'构建/对象/汇编/MCA与数学条件；不代表实际正确性、Linux或Skylake运行结果。'})
print(json.dumps({'reference_object_equality':equivalence,'decision':'stop_static_not_adopted'},ensure_ascii=False))
