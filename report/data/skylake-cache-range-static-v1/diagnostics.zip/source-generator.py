"""只生成独立范围判定候选，不修改已冻结组合后端，不执行数值。"""
from pathlib import Path
ROOT=Path.cwd();old=ROOT/'experiments/skylake-delta-cache-runtime';out=ROOT/'experiments/skylake-cache-range-runtime'
if out.exists():raise ValueError('不覆盖新候选')
out.mkdir()
for name in ('channel_runtime.cpp','channel_views.hpp','suffix_cache.hpp'):
 text=(old/name).read_text(encoding='utf-8').replace('jshc_delta16_cache','jshc_cache_range')
 if name=='channel_runtime.cpp':text=text.replace('uint32_t jshc_cc_revision(void) {return 6;}','uint32_t jshc_cc_revision(void) {return 7;}')
 (out/name).write_text(text,encoding='utf-8')
text=(old/'channel_avx2.cpp').read_text(encoding='utf-8')
start=text.index('template<bool FirstShared,bool SuffixShared,bool FirstDelta16=false>')
end=text.index('template<bool Delta16>\nvoid fixed_four',start)
new='''template<bool FirstShared,bool SuffixShared,bool FirstDelta16=false>
void cached(const View* chain,const SuffixCacheView& cache,uint8_t* data,size_t pixels) noexcept {
  const __m256i rmin=_mm256_set1_epi32(cache.r_min),gmin=_mm256_set1_epi32(cache.dg_min),bmin=_mm256_set1_epi32(cache.db_min);
  const __m256i spans=_mm256_packs_epi32(_mm256_set1_epi32(cache.dg_max-cache.dg_min),_mm256_set1_epi32(cache.db_max-cache.db_min));
  for(size_t p=0;p<pixels;p+=8) {
    Rgb rgb;load(data+3*p,rgb);transform<FirstShared,FirstDelta16>(chain[0],rgb);
    // 首级R是R节点的Q16凸组合，half-up后仍在全节点R范围内；构造器不可缩小该范围。
    // 两个差偏移在[-510,510]，有符号packs无损；负数转为u16必大于[0,510]的span。
    const __m256i dg=_mm256_sub_epi32(_mm256_sub_epi32(rgb.g,rgb.r),gmin);
    const __m256i db=_mm256_sub_epi32(_mm256_sub_epi32(rgb.b,rgb.r),bmin);
    rgb.r=_mm256_sub_epi32(rgb.r,rmin);rgb.g=dg;rgb.b=db;
    const __m256i excess=_mm256_subs_epu16(_mm256_packs_epi32(rgb.g,rgb.b),spans);
    if(_mm256_testz_si256(excess,excess)) {
      const __m256i index=_mm256_add_epi32(_mm256_mullo_epi32(rgb.r,_mm256_set1_epi32(cache.width_g*cache.width_b)),
          _mm256_add_epi32(_mm256_mullo_epi32(rgb.g,_mm256_set1_epi32(cache.width_b)),rgb.b));
      const __m256i value=gather(cache.table,index),mask=_mm256_set1_epi32(255);
      rgb.r=_mm256_and_si256(value,mask);rgb.g=_mm256_and_si256(_mm256_srli_epi32(value,8),mask);
      rgb.b=_mm256_srli_epi32(value,16);
    } else {
      // 只在未命中时重建原首级RGB，缩短主路径中旧RGB与差值同时活跃的时间。
      rgb.r=_mm256_add_epi32(rgb.r,rmin);
      rgb.g=_mm256_add_epi32(_mm256_add_epi32(rgb.g,gmin),rgb.r);
      rgb.b=_mm256_add_epi32(_mm256_add_epi32(rgb.b,bmin),rgb.r);
      if constexpr(SuffixShared) {
        transform<true>(chain[1],rgb);transform<true>(chain[2],rgb);transform<true>(chain[3],rgb);
      } else {
        for(size_t s=1;s<4;++s) {
          if(chain[s].shared)transform<true>(chain[s],rgb);
          else if(chain[s].delta16)transform<false,true>(chain[s],rgb);
          else transform<false>(chain[s],rgb);
        }
      }
    }
    store(data+3*p,rgb);
  }
}
'''
text=text[:start]+new+text[end:]
(out/'channel_avx2.cpp').write_text(text.replace('jshc_delta16_cache','jshc_cache_range'),encoding='utf-8')
cm=(old/'CMakeLists.txt').read_text(encoding='utf-8').replace('jshc_skylake_delta_cache','jshc_skylake_cache_range')
cm=cm.replace('experiments/skylake-suffix-cache-runtime/','experiments/skylake-delta-cache-runtime/')
(out/'CMakeLists.txt').write_text(cm,encoding='utf-8')
print('独立范围判定候选生成完成')
