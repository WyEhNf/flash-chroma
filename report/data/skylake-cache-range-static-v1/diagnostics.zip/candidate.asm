
artifacts\skylake-cache-range-build-v1\CMakeFiles\jshc_skylake_cache_range.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
       7:	c5 f8 29 34 24       	vmovaps %xmm6,(%rsp)
       c:	c5 f8 29 7c 24 10    	vmovaps %xmm7,0x10(%rsp)
      12:	c5 78 29 44 24 20    	vmovaps %xmm8,0x20(%rsp)
      18:	c5 78 29 4c 24 30    	vmovaps %xmm9,0x30(%rsp)
      1e:	c5 78 29 54 24 40    	vmovaps %xmm10,0x40(%rsp)
      24:	c5 78 29 5c 24 50    	vmovaps %xmm11,0x50(%rsp)
      2a:	c5 78 29 64 24 60    	vmovaps %xmm12,0x60(%rsp)
      30:	c5 78 29 6c 24 70    	vmovaps %xmm13,0x70(%rsp)
      36:	c5 78 29 b4 24 80 00 	vmovaps %xmm14,0x80(%rsp)
      3d:	00 00 
      3f:	c5 78 29 bc 24 90 00 	vmovaps %xmm15,0x90(%rsp)
      46:	00 00 
      48:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      4c:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
      50:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
      54:	48 8b 01             	mov    (%rcx),%rax
      57:	c5 fd 6f 2a          	vmovdqa (%rdx),%ymm5
      5b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      5f:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      63:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
      69:	48 8b 41 08          	mov    0x8(%rcx),%rax
      6d:	c5 fd 6f 52 20       	vmovdqa 0x20(%rdx),%ymm2
      72:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      76:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
      7b:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
      80:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
      85:	c4 e2 75 90 3c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm7
      8b:	48 8b 41 10          	mov    0x10(%rcx),%rax
      8f:	c5 fd 6f 4a 40       	vmovdqa 0x40(%rdx),%ymm1
      94:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
      99:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
      9e:	c4 62 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm8
      a4:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
      a9:	48 8b 41 48          	mov    0x48(%rcx),%rax
      ad:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
      b2:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
      b7:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
      bc:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
      c0:	c4 c1 6d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm2
      c6:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      ca:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      cf:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
      d3:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
      d8:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
      dc:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
      e0:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
      e4:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
      ea:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
      ee:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      f2:	c5 3d db c1          	vpand  %ymm1,%ymm8,%ymm8
      f6:	c4 62 5d 3d d7       	vpmaxsd %ymm7,%ymm4,%ymm10
      fb:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
     101:	c5 c5 66 ec          	vpcmpgtd %ymm4,%ymm7,%ymm5
     105:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
     10a:	c4 62 5d 39 ef       	vpminsd %ymm7,%ymm4,%ymm13
     10f:	c5 5d fe ff          	vpaddd %ymm7,%ymm4,%ymm15
     113:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     117:	c4 42 15 39 e0       	vpminsd %ymm8,%ymm13,%ymm12
     11c:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
     121:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
     126:	c4 c3 25 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm11,%ymm5
     12c:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm5,%ymm5        # 135 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x135>
     133:	ff ff 90 
     136:	c4 43 25 4c de 40    	vpblendvb %ymm4,%ymm14,%ymm11,%ymm11
     13c:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
     141:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm11,%ymm11        # 14a <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x14a>
     148:	ff ff d0 
     14b:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     150:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
     154:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     159:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
     15e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     162:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     166:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
     16c:	c4 e2 5d 90 1c b0    	vpgatherdd %ymm4,(%rax,%ymm6,4),%ymm3
     172:	b8 00 80 00 00       	mov    $0x8000,%eax
     177:	c5 cd 72 d0 18       	vpsrld $0x18,%ymm0,%ymm6
     17c:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     181:	c5 55 db de          	vpand  %ymm6,%ymm5,%ymm11
     185:	c5 ed db e6          	vpand  %ymm6,%ymm2,%ymm4
     189:	c5 e5 db c6          	vpand  %ymm6,%ymm3,%ymm0
     18d:	c5 f5 db fe          	vpand  %ymm6,%ymm1,%ymm7
     191:	c5 bd 72 f4 10       	vpslld $0x10,%ymm4,%ymm8
     196:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
     19a:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     19e:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     1a3:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     1a8:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     1ad:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     1b2:	c5 15 db ee          	vpand  %ymm6,%ymm13,%ymm13
     1b6:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     1bb:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     1c0:	c5 25 db de          	vpand  %ymm6,%ymm11,%ymm11
     1c4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     1c9:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
     1cd:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
     1d1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     1d5:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     1d9:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     1de:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1e2:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     1e7:	c4 c1 3d 72 f3 10    	vpslld $0x10,%ymm11,%ymm8
     1ed:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     1f2:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     1f6:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     1fb:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     204:	c4 42 25 40 da       	vpmulld %ymm10,%ymm11,%ymm11
     209:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     20d:	c5 fd 7f 02          	vmovdqa %ymm0,(%rdx)
     211:	c5 fd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm0
     216:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     21b:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     21f:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     223:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     227:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
     22c:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     231:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     236:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     23b:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     240:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
     244:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     249:	c5 f5 72 f2 10       	vpslld $0x10,%ymm2,%ymm1
     24e:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     252:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     256:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     25a:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     25e:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     263:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     268:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
     26d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     271:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     276:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     27b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     27f:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     283:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     287:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     28c:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     291:	c5 f8 77             	vzeroupper
     294:	c5 f8 28 34 24       	vmovaps (%rsp),%xmm6
     299:	c5 f8 28 7c 24 10    	vmovaps 0x10(%rsp),%xmm7
     29f:	c5 78 28 44 24 20    	vmovaps 0x20(%rsp),%xmm8
     2a5:	c5 78 28 4c 24 30    	vmovaps 0x30(%rsp),%xmm9
     2ab:	c5 78 28 54 24 40    	vmovaps 0x40(%rsp),%xmm10
     2b1:	c5 78 28 5c 24 50    	vmovaps 0x50(%rsp),%xmm11
     2b7:	c5 78 28 64 24 60    	vmovaps 0x60(%rsp),%xmm12
     2bd:	c5 78 28 6c 24 70    	vmovaps 0x70(%rsp),%xmm13
     2c3:	c5 78 28 b4 24 80 00 	vmovaps 0x80(%rsp),%xmm14
     2ca:	00 00 
     2cc:	c5 78 28 bc 24 90 00 	vmovaps 0x90(%rsp),%xmm15
     2d3:	00 00 
     2d5:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
     2dc:	c3                   	ret
     2dd:	0f 1f 00             	nopl   (%rax)

00000000000002e0 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>:
     2e0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
     2e7:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
     2ee:	00 00 
     2f0:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
     2f7:	00 00 
     2f9:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
     300:	00 00 
     302:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
     309:	00 00 
     30b:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
     312:	00 00 
     314:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
     31b:	00 00 
     31d:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
     324:	00 00 
     326:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
     32d:	00 00 
     32f:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
     336:	00 00 
     338:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
     33f:	00 00 
     341:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     345:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     349:	48 8b 01             	mov    (%rcx),%rax
     34c:	c5 fd 6f 3a          	vmovdqa (%rdx),%ymm7
     350:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     354:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     358:	c4 e2 65 90 24 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm4
     35e:	48 8b 41 08          	mov    0x8(%rcx),%rax
     362:	c5 fd 6f 7a 20       	vmovdqa 0x20(%rdx),%ymm7
     367:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     36b:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
     370:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     375:	c5 7d 6f 32          	vmovdqa (%rdx),%ymm14
     379:	c5 7d 6f 52 20       	vmovdqa 0x20(%rdx),%ymm10
     37e:	c4 e2 65 90 2c b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm5
     384:	c5 fd 6f 7a 40       	vmovdqa 0x40(%rdx),%ymm7
     389:	48 8b 41 10          	mov    0x10(%rcx),%rax
     38d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     391:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     396:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     39b:	c4 e2 65 90 34 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm6
     3a1:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     3a6:	c4 c1 79 6e d8       	vmovd  %r8d,%xmm3
     3ab:	48 8b 41 48          	mov    0x48(%rcx),%rax
     3af:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     3b4:	c5 b5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm9
     3b9:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     3be:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     3c3:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     3c7:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     3cb:	c4 41 75 fe d9       	vpaddd %ymm9,%ymm1,%ymm11
     3d0:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
     3d5:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     3d9:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     3dd:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     3e1:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     3e6:	c4 22 6d 90 24 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm12
     3ec:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     3f0:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     3f5:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     3fa:	c4 41 75 fe eb       	vpaddd %ymm11,%ymm1,%ymm13
     3ff:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     403:	c4 a2 75 90 14 a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm2
     409:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     40d:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
     413:	c4 02 75 90 3c b0    	vpgatherdd %ymm1,(%r8,%ymm14,4),%ymm15
     419:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     41d:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     421:	48 8b 49 28          	mov    0x28(%rcx),%rcx
     425:	c4 02 75 90 34 90    	vpgatherdd %ymm1,(%r8,%ymm10,4),%ymm14
     42b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     42f:	c4 62 5d 3d d5       	vpmaxsd %ymm5,%ymm4,%ymm10
     434:	c4 e2 75 90 14 b9    	vpgatherdd %ymm1,(%rcx,%ymm7,4),%ymm2
     43a:	c5 d5 66 cc          	vpcmpgtd %ymm4,%ymm5,%ymm1
     43e:	b9 00 80 00 00       	mov    $0x8000,%ecx
     443:	c4 c1 4d 66 fa       	vpcmpgtd %ymm10,%ymm6,%ymm7
     448:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     44e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm1,%ymm1        # 457 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x177>
     455:	ff ff 70 
     458:	c4 e2 2d 3d fe       	vpmaxsd %ymm6,%ymm10,%ymm7
     45d:	c4 62 35 39 d6       	vpminsd %ymm6,%ymm9,%ymm10
     462:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     469:	00 00 
     46b:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     470:	c5 35 66 ce          	vpcmpgtd %ymm6,%ymm9,%ymm9
     474:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
     47b:	00 00 
     47d:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     481:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     487:	c4 e2 2d 90 3c 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm7
     48d:	c5 dd 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm1
     491:	c5 7e 7f 2c 24       	vmovdqu %ymm13,(%rsp)
     496:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     49c:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 4a5 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x1c5>
     4a3:	ff ff 90 
     4a6:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
     4aa:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
     4ae:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
     4b5:	00 00 
     4b7:	c4 62 35 90 1c 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm11
     4bd:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     4c3:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     4c8:	c5 15 fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm13,%ymm12
     4cf:	00 00 
     4d1:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     4d5:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     4d9:	c5 5d fe ed          	vpaddd %ymm5,%ymm4,%ymm13
     4dd:	c5 75 db 54 24 40    	vpand  0x40(%rsp),%ymm1,%ymm10
     4e3:	c4 41 4d fa e4       	vpsubd %ymm12,%ymm6,%ymm12
     4e8:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
     4ed:	c5 25 fa e7          	vpsubd %ymm7,%ymm11,%ymm12
     4f1:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
     4f7:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
     4fc:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     500:	c4 c1 45 fa fa       	vpsubd %ymm10,%ymm7,%ymm7
     505:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     50a:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     511:	00 00 00 
     514:	c4 c1 2d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm10
     51a:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
     51f:	c5 2d fe d5          	vpaddd %ymm5,%ymm10,%ymm10
     523:	c5 7e 7f ac 24 80 00 	vmovdqu %ymm13,0x80(%rsp)
     52a:	00 00 
     52c:	c4 41 1d fe c9       	vpaddd %ymm9,%ymm12,%ymm9
     531:	c5 75 db 64 24 60    	vpand  0x60(%rsp),%ymm1,%ymm12
     537:	c4 41 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm12
     53c:	c4 62 1d 40 a4 24 c0 	vpmulld 0xc0(%rsp),%ymm12,%ymm12
     543:	00 00 00 
     546:	c5 1d fe e7          	vpaddd %ymm7,%ymm12,%ymm12
     54a:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     54f:	c4 c1 45 72 d1 10    	vpsrld $0x10,%ymm9,%ymm7
     555:	c4 c1 35 72 e7 10    	vpsrad $0x10,%ymm15,%ymm9
     55b:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     562:	00 00 
     564:	c5 c5 72 e2 10       	vpsrad $0x10,%ymm2,%ymm7
     569:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     56e:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
     572:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     577:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
     57b:	c4 41 2d fe e1       	vpaddd %ymm9,%ymm10,%ymm12
     580:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     584:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
     58a:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
     591:	00 00 
     593:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     598:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
     59c:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
     5a2:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     5a6:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     5ab:	c5 6d fe f5          	vpaddd %ymm5,%ymm2,%ymm14
     5af:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
     5b3:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
     5ba:	00 00 
     5bc:	c4 62 5d 3d dd       	vpmaxsd %ymm5,%ymm4,%ymm11
     5c1:	c5 55 66 ec          	vpcmpgtd %ymm4,%ymm5,%ymm13
     5c5:	c4 62 5d 39 f5       	vpminsd %ymm5,%ymm4,%ymm14
     5ca:	c4 c1 6d 66 f3       	vpcmpgtd %ymm11,%ymm2,%ymm6
     5cf:	c5 dd 66 ed          	vpcmpgtd %ymm5,%ymm4,%ymm5
     5d3:	c4 62 0d 39 e2       	vpminsd %ymm2,%ymm14,%ymm12
     5d8:	c5 0d 66 f2          	vpcmpgtd %ymm2,%ymm14,%ymm14
     5dc:	c4 62 25 3d da       	vpmaxsd %ymm2,%ymm11,%ymm11
     5e1:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     5e5:	c4 43 65 4c e8 d0    	vpblendvb %ymm13,%ymm8,%ymm3,%ymm13
     5eb:	c4 63 15 4c 2d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm13,%ymm13        # 5f4 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x314>
     5f2:	ff ff 60 
     5f5:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     5fb:	c5 15 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm13,%ymm13
     601:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm5,%ymm5        # 60a <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x32a>
     608:	ff ff e0 
     60b:	c4 a2 05 90 34 a8    	vpgatherdd %ymm15,(%rax,%ymm13,4),%ymm6
     611:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     616:	c4 41 25 fe fc       	vpaddd %ymm12,%ymm11,%ymm15
     61b:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     620:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     625:	c5 95 fa ed          	vpsubd %ymm5,%ymm13,%ymm5
     629:	c5 dd fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm4,%ymm4
     630:	00 00 
     632:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     636:	c4 62 6d 90 2c a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm13
     63c:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     642:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     648:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
     64e:	c5 8d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm14
     653:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
     658:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     65c:	c5 0d db f1          	vpand  %ymm1,%ymm14,%ymm14
     660:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     664:	c5 15 fa fe          	vpsubd %ymm6,%ymm13,%ymm15
     668:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     66d:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     672:	c4 42 5d 40 ff       	vpmulld %ymm15,%ymm4,%ymm15
     677:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
     67c:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
     681:	c4 42 35 39 da       	vpminsd %ymm10,%ymm9,%ymm11
     686:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
     68c:	c4 62 25 39 e7       	vpminsd %ymm7,%ymm11,%ymm12
     691:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     695:	c5 ed fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm2,%ymm2
     69c:	00 00 
     69e:	c5 25 66 df          	vpcmpgtd %ymm7,%ymm11,%ymm11
     6a2:	c5 85 fe d2          	vpaddd %ymm2,%ymm15,%ymm2
     6a6:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     6aa:	c4 c2 35 3d f2       	vpmaxsd %ymm10,%ymm9,%ymm6
     6af:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     6b3:	c4 c1 2d 66 e9       	vpcmpgtd %ymm9,%ymm10,%ymm5
     6b8:	c5 c5 66 e6          	vpcmpgtd %ymm6,%ymm7,%ymm4
     6bc:	c4 41 35 66 ca       	vpcmpgtd %ymm10,%ymm9,%ymm9
     6c1:	c4 e2 4d 3d f7       	vpmaxsd %ymm7,%ymm6,%ymm6
     6c6:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6cb:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     6d1:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm5,%ymm5        # 6da <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x3fa>
     6d8:	ff ff 40 
     6db:	c4 c3 65 4c d8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm3
     6e1:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     6e7:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     6ec:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm3,%ymm3        # 6f5 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)+0x415>
     6f3:	ff ff b0 
     6f6:	c5 95 fa db          	vpsubd %ymm3,%ymm13,%ymm3
     6fa:	c4 e2 0d 90 24 a8    	vpgatherdd %ymm14,(%rax,%ymm5,4),%ymm4
     700:	c4 e2 7d 90 2c 98    	vpgatherdd %ymm0,(%rax,%ymm3,4),%ymm5
     706:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     70c:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     712:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     717:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     71c:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     720:	c5 fd 7f 52 20       	vmovdqa %ymm2,0x20(%rdx)
     725:	c5 bd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm8
     72a:	c4 c1 4d fe c4       	vpaddd %ymm12,%ymm6,%ymm0
     72f:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     733:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
     737:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     73c:	c5 d5 fa fc          	vpsubd %ymm4,%ymm5,%ymm7
     740:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
     744:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
     74b:	00 00 
     74d:	c5 bd db c9          	vpand  %ymm1,%ymm8,%ymm1
     751:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     755:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     759:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
     75e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     763:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
     768:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
     76d:	c5 b5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm9,%ymm7
     774:	00 00 
     776:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
     77a:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     77e:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     785:	00 00 
     787:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     78b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     790:	c5 fd 7f 3a          	vmovdqa %ymm7,(%rdx)
     794:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     799:	c5 f8 77             	vzeroupper
     79c:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
     7a3:	00 00 
     7a5:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
     7ac:	00 00 
     7ae:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
     7b5:	00 00 
     7b7:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
     7be:	00 00 
     7c0:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
     7c7:	00 00 
     7c9:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
     7d0:	00 00 
     7d2:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
     7d9:	00 00 
     7db:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
     7e2:	00 00 
     7e4:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
     7eb:	00 00 
     7ed:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
     7f4:	00 00 
     7f6:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
     7fd:	c3                   	ret
     7fe:	66 90                	xchg   %ax,%ax

0000000000000800 <void jshc_cache_range::(anonymous namespace)::transform<false, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>:
     800:	48 81 ec 88 01 00 00 	sub    $0x188,%rsp
     807:	c5 f8 29 b4 24 e0 00 	vmovaps %xmm6,0xe0(%rsp)
     80e:	00 00 
     810:	c5 f8 29 bc 24 f0 00 	vmovaps %xmm7,0xf0(%rsp)
     817:	00 00 
     819:	c5 78 29 84 24 00 01 	vmovaps %xmm8,0x100(%rsp)
     820:	00 00 
     822:	c5 78 29 8c 24 10 01 	vmovaps %xmm9,0x110(%rsp)
     829:	00 00 
     82b:	c5 78 29 94 24 20 01 	vmovaps %xmm10,0x120(%rsp)
     832:	00 00 
     834:	c5 78 29 9c 24 30 01 	vmovaps %xmm11,0x130(%rsp)
     83b:	00 00 
     83d:	c5 78 29 a4 24 40 01 	vmovaps %xmm12,0x140(%rsp)
     844:	00 00 
     846:	c5 78 29 ac 24 50 01 	vmovaps %xmm13,0x150(%rsp)
     84d:	00 00 
     84f:	c5 78 29 b4 24 60 01 	vmovaps %xmm14,0x160(%rsp)
     856:	00 00 
     858:	c5 78 29 bc 24 70 01 	vmovaps %xmm15,0x170(%rsp)
     85f:	00 00 
     861:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     865:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     869:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     86d:	48 89 d0             	mov    %rdx,%rax
     870:	48 8b 11             	mov    (%rcx),%rdx
     873:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     877:	c5 fd 6f 10          	vmovdqa (%rax),%ymm2
     87b:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     87f:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
     884:	c4 e2 4d 90 1c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm3
     88a:	48 8b 51 08          	mov    0x8(%rcx),%rdx
     88e:	c5 fd 6f 50 20       	vmovdqa 0x20(%rax),%ymm2
     893:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     897:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     89c:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     8a1:	c4 e2 4d 90 3c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm7
     8a7:	48 8b 51 10          	mov    0x10(%rcx),%rdx
     8ab:	c5 fd 6f 50 40       	vmovdqa 0x40(%rax),%ymm2
     8b0:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     8b4:	c5 d5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm5
     8b9:	c4 e2 4d 90 24 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm4
     8bf:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     8c4:	c4 c1 79 6e d0       	vmovd  %r8d,%xmm2
     8c9:	48 8b 51 48          	mov    0x48(%rcx),%rdx
     8cd:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     8d2:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
     8d7:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     8dc:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     8e1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     8e5:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     8e9:	c5 75 fe de          	vpaddd %ymm6,%ymm1,%ymm11
     8ed:	c5 cd 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm6
     8f2:	c4 a2 55 90 0c 9a    	vpgatherdd %ymm5,(%rdx,%ymm11,4),%ymm1
     8f8:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     8fc:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     900:	c5 7d 6f f9          	vmovdqa %ymm1,%ymm15
     904:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     909:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     90d:	41 b8 00 80 00 00    	mov    $0x8000,%r8d
     913:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     918:	c4 62 65 3d d7       	vpmaxsd %ymm7,%ymm3,%ymm10
     91d:	c4 62 65 39 c7       	vpminsd %ymm7,%ymm3,%ymm8
     922:	c4 41 75 fe e3       	vpaddd %ymm11,%ymm1,%ymm12
     927:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
     92b:	c4 c1 5d 66 ea       	vpcmpgtd %ymm10,%ymm4,%ymm5
     930:	c4 22 15 90 34 a2    	vpgatherdd %ymm13,(%rdx,%ymm12,4),%ymm14
     936:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     93c:	c4 62 3d 39 ec       	vpminsd %ymm4,%ymm8,%ymm13
     941:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     947:	c5 8d 72 d0 1f       	vpsrld $0x1f,%ymm0,%ymm14
     94c:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
     950:	c4 62 2d 3d d4       	vpmaxsd %ymm4,%ymm10,%ymm10
     955:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     95b:	c4 c3 75 4c ce 50    	vpblendvb %ymm5,%ymm14,%ymm1,%ymm1
     961:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     966:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     96a:	c4 e2 25 90 2c 8a    	vpgatherdd %ymm11,(%rdx,%ymm1,4),%ymm5
     970:	c5 e5 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm1
     974:	c5 7e 7f 24 24       	vmovdqu %ymm12,(%rsp)
     979:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     97d:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     983:	c4 c3 75 4c ce 80    	vpblendvb %ymm8,%ymm14,%ymm1,%ymm1
     989:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     98d:	c5 9d fa c9          	vpsubd %ymm1,%ymm12,%ymm1
     991:	c4 62 3d 90 1c 8a    	vpgatherdd %ymm8,(%rdx,%ymm1,4),%ymm11
     997:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     99c:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
     9a2:	c4 41 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm15
     9a7:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     9ab:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     9af:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     9b4:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     9b8:	c5 a5 fa e5          	vpsubd %ymm5,%ymm11,%ymm4
     9bc:	c5 75 db 64 24 40    	vpand  0x40(%rsp),%ymm1,%ymm12
     9c2:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
     9c7:	c4 c1 79 6e e0       	vmovd  %r8d,%xmm4
     9cc:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     9d0:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9d5:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
     9db:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     9e0:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     9e4:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     9e9:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     9f0:	00 00 
     9f2:	c4 41 65 fe c0       	vpaddd %ymm8,%ymm3,%ymm8
     9f7:	c5 f5 db 5c 24 60    	vpand  0x60(%rsp),%ymm1,%ymm3
     9fd:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     a02:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
     a07:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a0b:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     a0f:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     a13:	c4 c1 05 72 d0 10    	vpsrld $0x10,%ymm8,%ymm15
     a19:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
     a20:	00 00 
     a22:	c5 7d 6f 50 40       	vmovdqa 0x40(%rax),%ymm10
     a27:	c5 7d 6f 58 20       	vmovdqa 0x20(%rax),%ymm11
     a2c:	c4 02 15 90 04 90    	vpgatherdd %ymm13,(%r8,%ymm10,4),%ymm8
     a32:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     a36:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a3a:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     a3e:	c4 02 15 90 14 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm10
     a44:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     a48:	c5 7d 6f 18          	vmovdqa (%rax),%ymm11
     a4c:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a50:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     a54:	c4 82 15 90 1c 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm3
     a5a:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     a5e:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a62:	4c 8b 41 40          	mov    0x40(%rcx),%r8
     a66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     a6a:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
     a6f:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
     a73:	c4 c2 65 39 fa       	vpminsd %ymm10,%ymm3,%ymm7
     a78:	c4 c1 3d 66 e4       	vpcmpgtd %ymm12,%ymm8,%ymm4
     a7d:	c4 42 45 39 f8       	vpminsd %ymm8,%ymm7,%ymm15
     a82:	c4 42 1d 3d e0       	vpmaxsd %ymm8,%ymm12,%ymm12
     a87:	c4 c1 45 66 f8       	vpcmpgtd %ymm8,%ymm7,%ymm7
     a8c:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     a92:	c4 c3 55 4c ee 40    	vpblendvb %ymm4,%ymm14,%ymm5,%ymm5
     a98:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     a9e:	c4 e2 25 90 24 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm4
     aa4:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
     aa9:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
     aae:	c5 7d 6f 10          	vmovdqa (%rax),%ymm10
     ab2:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     ab7:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     abb:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     ac1:	c4 c3 55 4c ee 70    	vpblendvb %ymm7,%ymm14,%ymm5,%ymm5
     ac7:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     acc:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     ad0:	c4 62 15 90 1c aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm11
     ad6:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
     adc:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
     ae3:	00 00 
     ae5:	c4 41 1d fe ff       	vpaddd %ymm15,%ymm12,%ymm15
     aea:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
     af0:	c4 41 3d fa c7       	vpsubd %ymm15,%ymm8,%ymm8
     af5:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     af9:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     afd:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     b02:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
     b06:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     b0c:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     b10:	c5 25 fa c4          	vpsubd %ymm4,%ymm11,%ymm8
     b14:	c4 42 65 40 c0       	vpmulld %ymm8,%ymm3,%ymm8
     b19:	c5 c5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm7
     b1e:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
     b23:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     b28:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
     b2e:	c5 7d 6f 68 40       	vmovdqa 0x40(%rax),%ymm13
     b33:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     b37:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
     b3e:	00 00 
     b40:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     b45:	c4 82 05 90 1c a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm3
     b4b:	c5 7d 6f 68 20       	vmovdqa 0x20(%rax),%ymm13
     b50:	4c 8b 41 38          	mov    0x38(%rcx),%r8
     b54:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b58:	48 8b 49 30          	mov    0x30(%rcx),%rcx
     b5c:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     b63:	00 00 00 
     b66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     b6a:	c5 bd fe ed          	vpaddd %ymm5,%ymm8,%ymm5
     b6e:	c4 02 05 90 04 a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm8
     b74:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b78:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     b7c:	c4 a2 05 90 24 91    	vpgatherdd %ymm15,(%rcx,%ymm10,4),%ymm4
     b82:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     b86:	c5 dd db f6          	vpand  %ymm6,%ymm4,%ymm6
     b8a:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     b8e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b92:	c4 42 4d 3d d0       	vpmaxsd %ymm8,%ymm6,%ymm10
     b97:	c5 bd 66 fe          	vpcmpgtd %ymm6,%ymm8,%ymm7
     b9b:	c4 42 4d 39 d8       	vpminsd %ymm8,%ymm6,%ymm11
     ba0:	c4 c1 65 66 e2       	vpcmpgtd %ymm10,%ymm3,%ymm4
     ba5:	c4 62 25 39 e3       	vpminsd %ymm3,%ymm11,%ymm12
     baa:	c4 62 2d 3d d3       	vpmaxsd %ymm3,%ymm10,%ymm10
     baf:	c5 25 66 db          	vpcmpgtd %ymm3,%ymm11,%ymm11
     bb3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     bb8:	c4 c3 6d 4c f9 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm7
     bbe:	c4 c3 45 4c fe 40    	vpblendvb %ymm4,%ymm14,%ymm7,%ymm7
     bc4:	c5 c5 fe 7c 24 20    	vpaddd 0x20(%rsp),%ymm7,%ymm7
     bca:	c4 e2 05 90 24 ba    	vpgatherdd %ymm15,(%rdx,%ymm7,4),%ymm4
     bd0:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     bd5:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
     bda:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
     be1:	00 00 
     be3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     be8:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     bec:	c4 c3 6d 4c d1 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm2
     bf2:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     bf7:	c4 c3 6d 4c d6 b0    	vpblendvb %ymm11,%ymm14,%ymm2,%ymm2
     bfd:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     c03:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
     c07:	c4 62 7d 90 0c 92    	vpgatherdd %ymm0,(%rdx,%ymm2,4),%ymm9
     c0d:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     c13:	c4 c1 2d fe c4       	vpaddd %ymm12,%ymm10,%ymm0
     c18:	c5 7d 7f 38          	vmovdqa %ymm15,(%rax)
     c1c:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
     c22:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     c28:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
     c2c:	c5 fd 7f 68 20       	vmovdqa %ymm5,0x20(%rax)
     c31:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     c36:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
     c3a:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     c3e:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     c42:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
     c46:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     c4a:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     c4f:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     c53:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     c58:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     c5d:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     c62:	c5 a5 72 f2 10       	vpslld $0x10,%ymm2,%ymm11
     c67:	c5 25 fe 9c 24 80 00 	vpaddd 0x80(%rsp),%ymm11,%ymm11
     c6e:	00 00 
     c70:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     c75:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     c79:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     c7d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     c82:	c5 fd 7f 40 40       	vmovdqa %ymm0,0x40(%rax)
     c87:	c5 f8 77             	vzeroupper
     c8a:	c5 f8 28 b4 24 e0 00 	vmovaps 0xe0(%rsp),%xmm6
     c91:	00 00 
     c93:	c5 f8 28 bc 24 f0 00 	vmovaps 0xf0(%rsp),%xmm7
     c9a:	00 00 
     c9c:	c5 78 28 84 24 00 01 	vmovaps 0x100(%rsp),%xmm8
     ca3:	00 00 
     ca5:	c5 78 28 8c 24 10 01 	vmovaps 0x110(%rsp),%xmm9
     cac:	00 00 
     cae:	c5 78 28 94 24 20 01 	vmovaps 0x120(%rsp),%xmm10
     cb5:	00 00 
     cb7:	c5 78 28 9c 24 30 01 	vmovaps 0x130(%rsp),%xmm11
     cbe:	00 00 
     cc0:	c5 78 28 a4 24 40 01 	vmovaps 0x140(%rsp),%xmm12
     cc7:	00 00 
     cc9:	c5 78 28 ac 24 50 01 	vmovaps 0x150(%rsp),%xmm13
     cd0:	00 00 
     cd2:	c5 78 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm14
     cd9:	00 00 
     cdb:	c5 78 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm15
     ce2:	00 00 
     ce4:	48 81 c4 88 01 00 00 	add    $0x188,%rsp
     ceb:	c3                   	ret
     cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000cf0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     cf0:	41 55                	push   %r13
     cf2:	41 54                	push   %r12
     cf4:	55                   	push   %rbp
     cf5:	57                   	push   %rdi
     cf6:	56                   	push   %rsi
     cf7:	53                   	push   %rbx
     cf8:	48 81 ec 98 04 00 00 	sub    $0x498,%rsp
     cff:	c5 f8 29 b4 24 f0 03 	vmovaps %xmm6,0x3f0(%rsp)
     d06:	00 00 
     d08:	c5 f8 29 bc 24 00 04 	vmovaps %xmm7,0x400(%rsp)
     d0f:	00 00 
     d11:	c5 78 29 84 24 10 04 	vmovaps %xmm8,0x410(%rsp)
     d18:	00 00 
     d1a:	c5 78 29 8c 24 20 04 	vmovaps %xmm9,0x420(%rsp)
     d21:	00 00 
     d23:	c5 78 29 94 24 30 04 	vmovaps %xmm10,0x430(%rsp)
     d2a:	00 00 
     d2c:	c5 78 29 9c 24 40 04 	vmovaps %xmm11,0x440(%rsp)
     d33:	00 00 
     d35:	c5 78 29 a4 24 50 04 	vmovaps %xmm12,0x450(%rsp)
     d3c:	00 00 
     d3e:	c5 78 29 ac 24 60 04 	vmovaps %xmm13,0x460(%rsp)
     d45:	00 00 
     d47:	c5 78 29 b4 24 70 04 	vmovaps %xmm14,0x470(%rsp)
     d4e:	00 00 
     d50:	c5 78 29 bc 24 80 04 	vmovaps %xmm15,0x480(%rsp)
     d57:	00 00 
     d59:	48 89 d3             	mov    %rdx,%rbx
     d5c:	c4 e2 7d 58 7a 08    	vpbroadcastd 0x8(%rdx),%ymm7
     d62:	49 89 ca             	mov    %rcx,%r10
     d65:	8b 4a 10             	mov    0x10(%rdx),%ecx
     d68:	8b 43 1c             	mov    0x1c(%rbx),%eax
     d6b:	8b 52 18             	mov    0x18(%rdx),%edx
     d6e:	48 8d b4 24 1f 02 00 	lea    0x21f(%rsp),%rsi
     d75:	00 
     d76:	4d 89 c3             	mov    %r8,%r11
     d79:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     d80:	00 00 
     d82:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
     d86:	48 83 e6 e0          	and    $0xffffffffffffffe0,%rsi
     d8a:	29 d0                	sub    %edx,%eax
     d8c:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     d90:	8b 53 14             	mov    0x14(%rbx),%edx
     d93:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     d98:	c5 f9 6e c0          	vmovd  %eax,%xmm0
     d9c:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     da2:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     da7:	41 0f b6 42 58       	movzbl 0x58(%r10),%eax
     dac:	29 ca                	sub    %ecx,%edx
     dae:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     db3:	41 80 ba b8 00 00 00 	cmpb   $0x0,0xb8(%r10)
     dba:	00 
     dbb:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     dc1:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     dc5:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     dca:	c5 f5 6b e0          	vpackssdw %ymm0,%ymm1,%ymm4
     dce:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     dd4:	0f 84 ee 0a 00 00    	je     18c8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbd8>
     dda:	41 80 ba 18 01 00 00 	cmpb   $0x0,0x118(%r10)
     de1:	00 
     de2:	0f 84 e0 0a 00 00    	je     18c8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbd8>
     de8:	41 0f b6 92 78 01 00 	movzbl 0x178(%r10),%edx
     def:	00 
     df0:	84 c0                	test   %al,%al
     df2:	0f 85 f8 22 00 00    	jne    30f0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2400>
     df8:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
     dfd:	0f 84 0d 2e 00 00    	je     3c10 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f20>
     e03:	84 d2                	test   %dl,%dl
     e05:	0f 84 f8 0e 00 00    	je     1d03 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1013>
     e0b:	4d 85 c9             	test   %r9,%r9
     e0e:	0f 84 6c 15 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
     e14:	c5 fd 6f 15 60 00 00 	vmovdqa 0x60(%rip),%ymm2        # e7c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18c>
     e1b:	00 
     e1c:	b8 00 80 00 00       	mov    $0x8000,%eax
     e21:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # ea9 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b9>
     e28:	00 
     e29:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
     e2d:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
     e32:	48 c1 ef 03          	shr    $0x3,%rdi
     e36:	31 ed                	xor    %ebp,%ebp
     e38:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
     e3f:	00 00 
     e41:	c5 f9 6e d0          	vmovd  %eax,%xmm2
     e45:	c4 c1 05 72 d4 18    	vpsrld $0x18,%ymm12,%ymm15
     e4b:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     e50:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
     e57:	00 00 
     e59:	c5 fe 7f 94 24 c0 00 	vmovdqu %ymm2,0xc0(%rsp)
     e60:	00 00 
     e62:	e9 b0 00 00 00       	jmp    f17 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x227>
     e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     e6e:	00 00 
     e70:	8b 43 24             	mov    0x24(%rbx),%eax
     e73:	8b 53 20             	mov    0x20(%rbx),%edx
     e76:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
     e7a:	c5 c5 fa 8c 24 e0 00 	vpsubd 0xe0(%rsp),%ymm7,%ymm1
     e81:	00 00 
     e83:	0f af d0             	imul   %eax,%edx
     e86:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     e8a:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     e8f:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
     e94:	c5 f9 6e c0          	vmovd  %eax,%xmm0
     e98:	48 8b 03             	mov    (%rbx),%rax
     e9b:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     ea0:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
     ea5:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     ea9:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     ead:	c4 e2 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm0
     eb3:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     eb8:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     ebd:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
     ec2:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     ec7:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     ecc:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
     ed1:	49 83 c3 18          	add    $0x18,%r11
     ed5:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     ed9:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
     edd:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
     ee4:	00 00 00 
     ee7:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     eeb:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     ef1:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     ef6:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     efb:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     eff:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
     f05:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
     f0b:	48 39 ef             	cmp    %rbp,%rdi
     f0e:	0f 84 6c 14 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
     f14:	48 ff c5             	inc    %rbp
     f17:	c4 c1 7a 6f 1b       	vmovdqu (%r11),%xmm3
     f1c:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
     f22:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f26:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
     f2b:	49 8b 02             	mov    (%r10),%rax
     f2e:	41 8b 4a 54          	mov    0x54(%r10),%ecx
     f32:	c4 e3 79 0f c3 0c    	vpalignr $0xc,%xmm3,%xmm0,%xmm0
     f38:	41 8b 52 50          	mov    0x50(%r10),%edx
     f3c:	c4 e3 65 38 d8 01    	vinserti128 $0x1,%xmm0,%ymm3,%ymm3
     f42:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     f46:	c4 e2 65 00 9c 24 80 	vpshufb 0x80(%rsp),%ymm3,%ymm3
     f4d:	00 00 00 
     f50:	c5 f9 6e d2          	vmovd  %edx,%xmm2
     f54:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     f59:	c5 dd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm4
     f5e:	c5 cd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm6
     f63:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     f68:	c4 e2 45 90 2c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm5
     f6e:	49 8b 42 08          	mov    0x8(%r10),%rax
     f72:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     f77:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f7b:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     f80:	c5 bd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm8
     f85:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     f89:	c4 e2 45 90 0c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm1
     f8f:	49 8b 42 10          	mov    0x10(%r10),%rax
     f93:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f97:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # fbf <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cf>
     f9e:	00 
     f9f:	c4 62 3d 40 c2       	vpmulld %ymm2,%ymm8,%ymm8
     fa4:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
     faa:	c5 c5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm7
     faf:	49 8b 42 48          	mov    0x48(%r10),%rax
     fb3:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # fdb <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2eb>
     fba:	00 
     fbb:	c4 c2 45 40 fe       	vpmulld %ymm14,%ymm7,%ymm7
     fc0:	c5 b5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm9
     fc5:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # fed <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fd>
     fcc:	00 
     fcd:	c4 c1 45 fe f8       	vpaddd %ymm8,%ymm7,%ymm7
     fd2:	c4 62 55 39 c1       	vpminsd %ymm1,%ymm5,%ymm8
     fd7:	c4 41 45 fe d1       	vpaddd %ymm9,%ymm7,%ymm10
     fdc:	c4 a2 25 90 3c 90    	vpgatherdd %ymm11,(%rax,%ymm10,4),%ymm7
     fe2:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
     fe7:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     fee:	00 00 
     ff0:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     ff4:	49 8b 52 18          	mov    0x18(%r10),%rdx
     ff8:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     ffd:	c4 41 45 fe ca       	vpaddd %ymm10,%ymm7,%ymm9
    1002:	c4 e2 55 3d f9       	vpmaxsd %ymm1,%ymm5,%ymm7
    1007:	c4 22 25 90 2c 88    	vpgatherdd %ymm11,(%rax,%ymm9,4),%ymm13
    100d:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1012:	c5 7e 7f ac 24 60 01 	vmovdqu %ymm13,0x160(%rsp)
    1019:	00 00 
    101b:	c4 62 25 90 2c 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm13
    1021:	49 8b 52 20          	mov    0x20(%r10),%rdx
    1025:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    1029:	c4 62 65 90 1c b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm11
    102f:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1033:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1037:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
    103d:	c5 f5 66 f5          	vpcmpgtd %ymm5,%ymm1,%ymm6
    1041:	c5 7e 7f 94 24 00 01 	vmovdqu %ymm10,0x100(%rsp)
    1048:	00 00 
    104a:	c5 fd 66 e7          	vpcmpgtd %ymm7,%ymm0,%ymm4
    104e:	c4 c3 6d 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
    1054:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm6,%ymm6        # 105d <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36d>
    105b:	ff ff 40 
    105e:	c4 e2 45 3d e0       	vpmaxsd %ymm0,%ymm7,%ymm4
    1063:	c4 e2 3d 39 f8       	vpminsd %ymm0,%ymm8,%ymm7
    1068:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
    106f:	00 00 
    1071:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    1076:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
    107a:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    1081:	00 00 
    1083:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1087:	c4 e2 45 90 24 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm4
    108d:	c5 d5 66 f1          	vpcmpgtd %ymm1,%ymm5,%ymm6
    1091:	c5 7e 6f 94 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm10
    1098:	00 00 
    109a:	c5 7e 7f 8c 24 40 01 	vmovdqu %ymm9,0x140(%rsp)
    10a1:	00 00 
    10a3:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    10a7:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    10ac:	c4 c3 6d 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
    10b2:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm6,%ymm6        # 10bb <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3cb>
    10b9:	ff ff 80 
    10bc:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    10c0:	c5 2d fe 8c 24 80 01 	vpaddd 0x180(%rsp),%ymm10,%ymm9
    10c7:	00 00 
    10c9:	c4 62 45 90 04 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm8
    10cf:	c5 55 fe d1          	vpaddd %ymm1,%ymm5,%ymm10
    10d3:	c5 85 db bc 24 20 01 	vpand  0x120(%rsp),%ymm15,%ymm7
    10da:	00 00 
    10dc:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    10e1:	c4 41 7d fa c9       	vpsubd %ymm9,%ymm0,%ymm9
    10e6:	c4 41 35 fe d2       	vpaddd %ymm10,%ymm9,%ymm10
    10eb:	c5 3d fa cc          	vpsubd %ymm4,%ymm8,%ymm9
    10ef:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
    10f4:	c4 42 2d 40 c9       	vpmulld %ymm9,%ymm10,%ymm9
    10f9:	c5 cd fe b4 24 c0 00 	vpaddd 0xc0(%rsp),%ymm6,%ymm6
    1100:	00 00 
    1102:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    1106:	c4 e2 5d 40 a4 24 80 	vpmulld 0x180(%rsp),%ymm4,%ymm4
    110d:	01 00 00 
    1110:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
    1114:	c5 05 db 8c 24 60 01 	vpand  0x160(%rsp),%ymm15,%ymm9
    111b:	00 00 
    111d:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
    1122:	c4 62 35 40 8c 24 a0 	vpmulld 0x1a0(%rsp),%ymm9,%ymm9
    1129:	01 00 00 
    112c:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
    1130:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1135:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    113a:	c4 c1 4d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm6
    1140:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    1147:	00 00 
    1149:	c4 c1 45 72 e3 10    	vpsrad $0x10,%ymm11,%ymm7
    114f:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1153:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    1157:	c5 cd fe e7          	vpaddd %ymm7,%ymm6,%ymm4
    115b:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    1162:	00 00 
    1164:	c5 dd 72 e3 10       	vpsrad $0x10,%ymm3,%ymm4
    1169:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    116e:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1173:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    1177:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    117b:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    1181:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    1186:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    118a:	c4 c1 75 72 f5 10    	vpslld $0x10,%ymm13,%ymm1
    1190:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1195:	c5 65 fe d0          	vpaddd %ymm0,%ymm3,%ymm10
    1199:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    119d:	c4 62 75 3d c0       	vpmaxsd %ymm0,%ymm1,%ymm8
    11a2:	c5 7d 66 d9          	vpcmpgtd %ymm1,%ymm0,%ymm11
    11a6:	c4 62 75 39 e8       	vpminsd %ymm0,%ymm1,%ymm13
    11ab:	c4 c1 65 66 e8       	vpcmpgtd %ymm8,%ymm3,%ymm5
    11b0:	c5 f5 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm0
    11b4:	c4 62 15 39 cb       	vpminsd %ymm3,%ymm13,%ymm9
    11b9:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    11bd:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    11c2:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    11c9:	00 00 
    11cb:	c4 43 6d 4c de b0    	vpblendvb %ymm11,%ymm14,%ymm2,%ymm11
    11d1:	c5 7e 7f 84 24 80 01 	vmovdqu %ymm8,0x180(%rsp)
    11d8:	00 00 
    11da:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    11df:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm11,%ymm11        # 11e8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4f8>
    11e6:	ff ff 50 
    11e9:	c4 c3 6d 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm2,%ymm0
    11ef:	c5 25 fe 9c 24 00 01 	vpaddd 0x100(%rsp),%ymm11,%ymm11
    11f6:	00 00 
    11f8:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 1201 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x511>
    11ff:	ff ff d0 
    1202:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1206:	c4 a2 3d 90 2c 98    	vpgatherdd %ymm8,(%rax,%ymm11,4),%ymm5
    120c:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    1211:	c4 62 3d 90 1c 80    	vpgatherdd %ymm8,(%rax,%ymm0,4),%ymm11
    1217:	c5 fe 6f 84 24 20 01 	vmovdqu 0x120(%rsp),%ymm0
    121e:	00 00 
    1220:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    1225:	c5 35 fe 84 24 80 01 	vpaddd 0x180(%rsp),%ymm9,%ymm8
    122c:	00 00 
    122e:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    1234:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1239:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    123e:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    1245:	00 00 
    1247:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    124c:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    1251:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1256:	c5 25 fa d5          	vpsubd %ymm5,%ymm11,%ymm10
    125a:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    125f:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1264:	c4 42 75 40 d2       	vpmulld %ymm10,%ymm1,%ymm10
    1269:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    126e:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1273:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    1279:	c4 62 4d 39 c7       	vpminsd %ymm7,%ymm6,%ymm8
    127e:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    1283:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
    128a:	00 00 
    128c:	c4 e2 55 40 ac 24 80 	vpmulld 0x180(%rsp),%ymm5,%ymm5
    1293:	01 00 00 
    1296:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    129b:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    12a0:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    12a5:	c5 7e 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm13
    12ac:	00 00 
    12ae:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    12b2:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    12b6:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    12ba:	c4 e2 4d 3d ef       	vpmaxsd %ymm7,%ymm6,%ymm5
    12bf:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    12c3:	c5 c5 66 de          	vpcmpgtd %ymm6,%ymm7,%ymm3
    12c7:	c5 dd 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm1
    12cb:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    12cf:	c4 e2 55 3d ec       	vpmaxsd %ymm4,%ymm5,%ymm5
    12d4:	c4 c1 45 72 d5 10    	vpsrld $0x10,%ymm13,%ymm7
    12da:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12df:	c4 c3 6d 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm2,%ymm3
    12e5:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    12ea:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm3,%ymm3        # 12f3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x603>
    12f1:	ff ff 10 
    12f4:	c4 c3 6d 4c d6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm2
    12fa:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
    1301:	00 00 
    1303:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    1308:	c5 e5 fe 9c 24 00 01 	vpaddd 0x100(%rsp),%ymm3,%ymm3
    130f:	00 00 
    1311:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm2,%ymm2        # 131a <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x62a>
    1318:	ff ff 80 
    131b:	c4 41 55 fe c1       	vpaddd %ymm9,%ymm5,%ymm8
    1320:	c4 c1 5d fa e0       	vpsubd %ymm8,%ymm4,%ymm4
    1325:	c4 e2 25 90 0c 98    	vpgatherdd %ymm11,(%rax,%ymm3,4),%ymm1
    132b:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    1332:	00 00 
    1334:	c5 dd fe a4 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm4,%ymm4
    133b:	00 00 
    133d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1342:	c5 e5 fa d2          	vpsubd %ymm2,%ymm3,%ymm2
    1346:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    134b:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    1351:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
    1356:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    135b:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1360:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1365:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    136a:	c5 65 fa c1          	vpsubd %ymm1,%ymm3,%ymm8
    136e:	c5 c5 fa fb          	vpsubd %ymm3,%ymm7,%ymm7
    1372:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1376:	c4 42 5d 40 c0       	vpmulld %ymm8,%ymm4,%ymm8
    137b:	c5 cd fe b4 24 c0 00 	vpaddd 0xc0(%rsp),%ymm6,%ymm6
    1382:	00 00 
    1384:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    1389:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    138e:	c5 fd fa 54 24 20    	vpsubd 0x20(%rsp),%ymm0,%ymm2
    1394:	c5 bd fe f6          	vpaddd %ymm6,%ymm8,%ymm6
    1398:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    139c:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    13a0:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    13a7:	00 00 
    13a9:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    13ae:	c5 cd fa 5c 24 40    	vpsubd 0x40(%rsp),%ymm6,%ymm3
    13b4:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    13b8:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    13bc:	c5 ed 6b cb          	vpackssdw %ymm3,%ymm2,%ymm1
    13c0:	c5 f5 d9 4c 24 60    	vpsubusw 0x60(%rsp),%ymm1,%ymm1
    13c6:	c4 e2 7d 17 c9       	vptest %ymm1,%ymm1
    13cb:	0f 84 9f fa ff ff    	je     e70 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x180>
    13d1:	c5 fd 7f be 20 01 00 	vmovdqa %ymm7,0x120(%rsi)
    13d8:	00 
    13d9:	48 8d 96 20 01 00 00 	lea    0x120(%rsi),%rdx
    13e0:	49 8d 4a 60          	lea    0x60(%r10),%rcx
    13e4:	c5 fd 7f 86 40 01 00 	vmovdqa %ymm0,0x140(%rsi)
    13eb:	00 
    13ec:	c5 fd 7f b6 60 01 00 	vmovdqa %ymm6,0x160(%rsi)
    13f3:	00 
    13f4:	c5 f8 77             	vzeroupper
    13f7:	e8 04 ec ff ff       	call   0 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    13fc:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    1401:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    1408:	c5 fd 6f 86 20 01 00 	vmovdqa 0x120(%rsi),%ymm0
    140f:	00 
    1410:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    1414:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    141b:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    141f:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    1426:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    142a:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    142e:	c4 e2 5d 90 14 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm2
    1434:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    143b:	c5 fd 6f 86 40 01 00 	vmovdqa 0x140(%rsi),%ymm0
    1442:	00 
    1443:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    1447:	c5 f9 6e da          	vmovd  %edx,%xmm3
    144b:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1450:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1454:	c4 e2 55 90 24 80    	vpgatherdd %ymm5,(%rax,%ymm0,4),%ymm4
    145a:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    1461:	c5 fd 6f 86 60 01 00 	vmovdqa 0x160(%rsi),%ymm0
    1468:	00 
    1469:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    146e:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    1473:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 149b <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ab>
    147a:	00 
    147b:	c4 e2 4d 90 2c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm5
    1481:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1486:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    148d:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 14b5 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c5>
    1494:	00 
    1495:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    149a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    149f:	c5 cd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm6
    14a4:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 14cc <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7dc>
    14ab:	00 
    14ac:	c4 62 6d 39 cc       	vpminsd %ymm4,%ymm2,%ymm9
    14b1:	c5 6d fe dc          	vpaddd %ymm4,%ymm2,%ymm11
    14b5:	c4 62 35 39 c5       	vpminsd %ymm5,%ymm9,%ymm8
    14ba:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    14be:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    14c2:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    14c6:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    14ca:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    14cf:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    14d3:	c4 62 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm14
    14d9:	c5 75 fe f8          	vpaddd %ymm0,%ymm1,%ymm15
    14dd:	c4 e2 6d 3d fc       	vpmaxsd %ymm4,%ymm2,%ymm7
    14e2:	c5 dd 66 ca          	vpcmpgtd %ymm2,%ymm4,%ymm1
    14e6:	c5 ed 66 d4          	vpcmpgtd %ymm4,%ymm2,%ymm2
    14ea:	c4 22 4d 90 2c b8    	vpgatherdd %ymm6,(%rax,%ymm15,4),%ymm13
    14f0:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    14f4:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    14f9:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    14fd:	c4 c3 65 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm3,%ymm1
    1503:	c4 c3 65 4c da 20    	vpblendvb %ymm2,%ymm10,%ymm3,%ymm3
    1509:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 1512 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x822>
    1510:	ff ff 60 
    1513:	c4 c1 45 fe f0       	vpaddd %ymm8,%ymm7,%ymm6
    1518:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm3,%ymm3        # 1521 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x831>
    151f:	ff ff 90 
    1522:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    1526:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
    152a:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 1572 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x882>
    1531:	00 
    1532:	c4 c1 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm6
    1537:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    153b:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1540:	c4 e2 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm1
    1546:	c4 e2 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm0
    154c:	c4 c1 0d db df       	vpand  %ymm15,%ymm14,%ymm3
    1551:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    1558:	00 00 
    155a:	c4 41 75 db cf       	vpand  %ymm15,%ymm1,%ymm9
    155f:	c4 c1 7d db d7       	vpand  %ymm15,%ymm0,%ymm2
    1564:	c4 c1 15 db e7       	vpand  %ymm15,%ymm13,%ymm4
    1569:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    1570:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    1575:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1579:	c5 b5 fa db          	vpsubd %ymm3,%ymm9,%ymm3
    157d:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    1582:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1587:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    158c:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1591:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    1596:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    159b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    15a0:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    15a5:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    15aa:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    15ae:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    15b2:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
    15b8:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    15bc:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    15c1:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    15c6:	c4 c1 6d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm2
    15cc:	c5 ad 72 f5 10       	vpslld $0x10,%ymm5,%ymm10
    15d1:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    15d6:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    15db:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    15df:	c4 41 2d fe d3       	vpaddd %ymm11,%ymm10,%ymm10
    15e4:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    15e9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    15ee:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    15f2:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    15f7:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    15fc:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1601:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    1606:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    160c:	c4 41 0d db f7       	vpand  %ymm15,%ymm14,%ymm14
    1611:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1616:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    161a:	c4 c1 55 72 f6 10    	vpslld $0x10,%ymm14,%ymm5
    1620:	c4 41 75 fa f6       	vpsubd %ymm14,%ymm1,%ymm14
    1625:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    162a:	c4 62 0d 40 f7       	vpmulld %ymm7,%ymm14,%ymm14
    162f:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    1634:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1638:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    163e:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1642:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1647:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    164c:	c5 e5 fa d8          	vpsubd %ymm0,%ymm3,%ymm3
    1650:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1654:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    1659:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    165e:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1662:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1666:	c4 41 65 fe f6       	vpaddd %ymm14,%ymm3,%ymm14
    166b:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    1671:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    1678:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    167f:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1683:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    168a:	c5 0d fe f0          	vpaddd %ymm0,%ymm14,%ymm14
    168e:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    1693:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 16bb <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9cb>
    169a:	00 
    169b:	c4 e2 55 90 24 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm4
    16a1:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    16a5:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    16ac:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    16b0:	c5 79 6e c2          	vmovd  %edx,%xmm8
    16b4:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    16b9:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    16bd:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    16c2:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    16c7:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 16ef <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9ff>
    16ce:	00 
    16cf:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    16d4:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    16d9:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    16df:	c4 62 65 39 dc       	vpminsd %ymm4,%ymm3,%ymm11
    16e4:	c5 65 fe ec          	vpaddd %ymm4,%ymm3,%ymm13
    16e8:	c4 a2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm14,4),%ymm5
    16ee:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    16f5:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    16fa:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 1722 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa32>
    1701:	00 
    1702:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1706:	c4 62 25 39 cd       	vpminsd %ymm5,%ymm11,%ymm9
    170b:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    170f:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1713:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1717:	c4 e2 6d 90 04 88    	vpgatherdd %ymm2,(%rax,%ymm1,4),%ymm0
    171d:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1721:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1726:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    172a:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    1731:	00 00 
    1733:	c4 62 45 90 34 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm14
    1739:	c5 dd 66 d3          	vpcmpgtd %ymm3,%ymm4,%ymm2
    173d:	c4 e2 65 3d fc       	vpmaxsd %ymm4,%ymm3,%ymm7
    1742:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    1746:	c5 e5 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm3
    174a:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    174f:	c4 c3 3d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm8,%ymm2
    1755:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm2,%ymm2        # 175e <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa6e>
    175c:	ff ff 60 
    175f:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    1764:	c4 43 3d 4c c2 30    	vpblendvb %ymm3,%ymm10,%ymm8,%ymm8
    176a:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    176e:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
    1775:	00 00 
    1777:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm8,%ymm8        # 1780 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa90>
    177e:	ff ff b0 
    1781:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1785:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    178a:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    178f:	c4 c1 0d db df       	vpand  %ymm15,%ymm14,%ymm3
    1794:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    1799:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    179d:	c4 e2 15 90 14 88    	vpgatherdd %ymm13,(%rax,%ymm1,4),%ymm2
    17a3:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    17aa:	00 00 
    17ac:	c4 a2 55 90 24 80    	vpgatherdd %ymm5,(%rax,%ymm8,4),%ymm4
    17b2:	c4 41 6d db d7       	vpand  %ymm15,%ymm2,%ymm10
    17b7:	c4 c1 7d db ef       	vpand  %ymm15,%ymm0,%ymm5
    17bc:	c4 c1 5d db cf       	vpand  %ymm15,%ymm4,%ymm1
    17c1:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    17c6:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
    17ca:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    17ce:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    17d3:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    17d8:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    17dd:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    17e2:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    17e7:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
    17ec:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    17f1:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    17f6:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    17fb:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1800:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    1804:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    1809:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    180d:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
    1812:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1817:	c4 c1 75 72 d6 08    	vpsrld $0x8,%ymm14,%ymm1
    181d:	c4 c1 25 72 f0 10    	vpslld $0x10,%ymm8,%ymm11
    1823:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1828:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    182d:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
    1832:	c4 41 25 fe dd       	vpaddd %ymm13,%ymm11,%ymm11
    1837:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    183c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1841:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1845:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    184a:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    184f:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1854:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
    1859:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    185e:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1863:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1868:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    186d:	c5 bd 72 f0 10       	vpslld $0x10,%ymm0,%ymm8
    1872:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    1876:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    187b:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    1880:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    1885:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1889:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
    188f:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1894:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1899:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    189d:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    18a1:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    18a6:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    18ab:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    18af:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    18b4:	c5 d5 fe d4          	vpaddd %ymm4,%ymm5,%ymm2
    18b8:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    18bd:	e9 05 f6 ff ff       	jmp    ec7 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d7>
    18c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    18c8:	84 c0                	test   %al,%al
    18ca:	0f 84 28 04 00 00    	je     1cf8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1008>
    18d0:	4d 85 c9             	test   %r9,%r9
    18d3:	0f 84 a7 0a 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    18d9:	c5 fd 6f 15 60 00 00 	vmovdqa 0x60(%rip),%ymm2        # 1941 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc51>
    18e0:	00 
    18e1:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 1969 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc79>
    18e8:	00 
    18e9:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    18ed:	45 31 e4             	xor    %r12d,%r12d
    18f0:	48 c1 ed 03          	shr    $0x3,%rbp
    18f4:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    18f9:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    1900:	00 00 
    1902:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
    1909:	00 00 
    190b:	e9 a6 00 00 00       	jmp    19b6 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcc6>
    1910:	8b 43 24             	mov    0x24(%rbx),%eax
    1913:	8b 53 20             	mov    0x20(%rbx),%edx
    1916:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    191a:	c5 ed fa 94 24 e0 00 	vpsubd 0xe0(%rsp),%ymm2,%ymm2
    1921:	00 00 
    1923:	0f af d0             	imul   %eax,%edx
    1926:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    192a:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    192f:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    1934:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    1938:	48 8b 03             	mov    (%rbx),%rax
    193b:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1940:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    1945:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1949:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    194d:	c4 e2 45 90 04 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm0
    1953:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1958:	c5 fd db d1          	vpand  %ymm1,%ymm0,%ymm2
    195c:	c5 65 db f1          	vpand  %ymm1,%ymm3,%ymm14
    1960:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1965:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    196a:	c4 c1 7d 72 f6 08    	vpslld $0x8,%ymm14,%ymm0
    1970:	49 83 c3 18          	add    $0x18,%r11
    1974:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1978:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    197c:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
    1983:	00 00 00 
    1986:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    198a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1990:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1995:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    199a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    199e:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    19a4:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    19aa:	4c 39 e5             	cmp    %r12,%rbp
    19ad:	0f 84 cd 09 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    19b3:	49 ff c4             	inc    %r12
    19b6:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    19bb:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    19c1:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    19c5:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
    19c9:	49 8b 02             	mov    (%r10),%rax
    19cc:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    19d0:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    19d6:	41 8b 52 50          	mov    0x50(%r10),%edx
    19da:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    19e0:	c4 c1 75 72 d5 18    	vpsrld $0x18,%ymm13,%ymm1
    19e6:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    19ea:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
    19f1:	00 00 00 
    19f4:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    19f9:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    19fe:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    1a03:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1a07:	c4 e2 45 90 24 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
    1a0d:	49 8b 42 08          	mov    0x8(%r10),%rax
    1a11:	c5 ed db c1          	vpand  %ymm1,%ymm2,%ymm0
    1a15:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1a19:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
    1a1f:	49 8b 42 10          	mov    0x10(%r10),%rax
    1a23:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1a28:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 1a50 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd60>
    1a2f:	00 
    1a30:	c4 e2 55 90 3c 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm7
    1a36:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
    1a3b:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    1a3f:	49 8b 42 48          	mov    0x48(%r10),%rax
    1a43:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    1a48:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1a4d:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1a51:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    1a56:	c5 fd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm0
    1a5b:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1a5f:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1a64:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 1a8c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd9c>
    1a6b:	00 
    1a6c:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 1a94 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xda4>
    1a73:	00 
    1a74:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    1a79:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    1a7e:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    1a83:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    1a88:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1a8c:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    1a90:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1a94:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    1a98:	c4 e2 65 90 04 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm0
    1a9e:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    1aa2:	c5 7e 7f 9c 24 c0 00 	vmovdqu %ymm11,0xc0(%rsp)
    1aa9:	00 00 
    1aab:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    1aaf:	c4 22 65 90 3c 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm15
    1ab5:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    1ab9:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    1abe:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    1ac2:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    1ac6:	c4 c3 55 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm5,%ymm3
    1acc:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 1ad5 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xde5>
    1ad3:	ff ff 80 
    1ad6:	c4 c3 55 4c ee 40    	vpblendvb %ymm4,%ymm14,%ymm5,%ymm5
    1adc:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1ae1:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    1ae8:	00 00 
    1aea:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 1af3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe03>
    1af1:	ff ff c0 
    1af4:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1af9:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1afd:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1b02:	c5 dd fa ed          	vpsubd %ymm5,%ymm4,%ymm5
    1b06:	c4 41 7d 6f d5       	vmovdqa %ymm13,%ymm10
    1b0b:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1b0f:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    1b15:	c5 fd db d1          	vpand  %ymm1,%ymm0,%ymm2
    1b19:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    1b1f:	c5 05 db d1          	vpand  %ymm1,%ymm15,%ymm10
    1b23:	c5 e5 db f9          	vpand  %ymm1,%ymm3,%ymm7
    1b27:	b8 00 80 00 00       	mov    $0x8000,%eax
    1b2c:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    1b31:	c5 dd db e9          	vpand  %ymm1,%ymm4,%ymm5
    1b35:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    1b39:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1b3e:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    1b43:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
    1b47:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    1b4c:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
    1b50:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
    1b54:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1b59:	c5 c5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm7
    1b5e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1b63:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1b68:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
    1b6c:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1b71:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    1b75:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    1b79:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1b7e:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1b82:	c5 ad fe d2          	vpaddd %ymm2,%ymm10,%ymm2
    1b86:	c5 79 6e d0          	vmovd  %eax,%xmm10
    1b8a:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1b8f:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    1b94:	c4 41 0d fe f2       	vpaddd %ymm10,%ymm14,%ymm14
    1b99:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1b9d:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    1ba2:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1ba6:	c4 c1 55 72 d7 08    	vpsrld $0x8,%ymm15,%ymm5
    1bac:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    1bb0:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1bb5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1bba:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    1bbe:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    1bc2:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    1bc7:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    1bcb:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1bd0:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1bd5:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1bd9:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1bde:	c5 c5 72 f0 10       	vpslld $0x10,%ymm0,%ymm7
    1be3:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1be7:	c4 c1 4d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm6
    1bed:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1bf1:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    1bf5:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1bfa:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
    1bff:	c5 cd fa f4          	vpsubd %ymm4,%ymm6,%ymm6
    1c03:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    1c07:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1c0c:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    1c11:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1c16:	c5 d5 fa 5c 24 20    	vpsubd 0x20(%rsp),%ymm5,%ymm3
    1c1c:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    1c20:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    1c24:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1c28:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1c2c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1c31:	c5 fd fa 74 24 40    	vpsubd 0x40(%rsp),%ymm0,%ymm6
    1c37:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    1c3b:	c5 e5 6b e6          	vpackssdw %ymm6,%ymm3,%ymm4
    1c3f:	c5 dd d9 64 24 60    	vpsubusw 0x60(%rsp),%ymm4,%ymm4
    1c45:	c4 e2 7d 17 e4       	vptest %ymm4,%ymm4
    1c4a:	0f 84 c0 fc ff ff    	je     1910 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc20>
    1c50:	c5 fe 7f 94 24 c0 00 	vmovdqu %ymm2,0xc0(%rsp)
    1c57:	00 00 
    1c59:	c5 7d 6f f5          	vmovdqa %ymm5,%ymm14
    1c5d:	c5 7d 6f e0          	vmovdqa %ymm0,%ymm12
    1c61:	49 8d 7a 60          	lea    0x60(%r10),%rdi
    1c65:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    1c6c:	80 7f 58 00          	cmpb   $0x0,0x58(%rdi)
    1c70:	0f 85 ea 0b 00 00    	jne    2860 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b70>
    1c76:	80 7f 59 00          	cmpb   $0x0,0x59(%rdi)
    1c7a:	0f 84 70 07 00 00    	je     23f0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1700>
    1c80:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    1c87:	00 00 
    1c89:	c5 7d 7f b6 a0 01 00 	vmovdqa %ymm14,0x1a0(%rsi)
    1c90:	00 
    1c91:	48 8d 96 80 01 00 00 	lea    0x180(%rsi),%rdx
    1c98:	48 89 f9             	mov    %rdi,%rcx
    1c9b:	c5 7d 7f a6 c0 01 00 	vmovdqa %ymm12,0x1c0(%rsi)
    1ca2:	00 
    1ca3:	c5 fd 7f be 80 01 00 	vmovdqa %ymm7,0x180(%rsi)
    1caa:	00 
    1cab:	c5 f8 77             	vzeroupper
    1cae:	e8 2d e6 ff ff       	call   2e0 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    1cb3:	c5 fd 6f ae 80 01 00 	vmovdqa 0x180(%rsi),%ymm5
    1cba:	00 
    1cbb:	c5 7d 6f b6 a0 01 00 	vmovdqa 0x1a0(%rsi),%ymm14
    1cc2:	00 
    1cc3:	c5 7d 6f a6 c0 01 00 	vmovdqa 0x1c0(%rsi),%ymm12
    1cca:	00 
    1ccb:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    1cd0:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    1cd7:	00 00 
    1cd9:	48 83 c7 60          	add    $0x60,%rdi
    1cdd:	49 39 fd             	cmp    %rdi,%r13
    1ce0:	75 8a                	jne    1c6c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xf7c>
    1ce2:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    1ce9:	00 00 
    1ceb:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    1cef:	e9 71 fc ff ff       	jmp    1965 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc75>
    1cf4:	0f 1f 40 00          	nopl   0x0(%rax)
    1cf8:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
    1cfd:	0f 84 a5 0d 00 00    	je     2aa8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1db8>
    1d03:	4d 85 c9             	test   %r9,%r9
    1d06:	0f 84 74 06 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    1d0c:	b8 00 80 00 00       	mov    $0x8000,%eax
    1d11:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # 1d79 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1089>
    1d18:	00 
    1d19:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 1da1 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10b1>
    1d20:	00 
    1d21:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    1d25:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    1d29:	48 c1 ef 03          	shr    $0x3,%rdi
    1d2d:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    1d32:	45 31 e4             	xor    %r12d,%r12d
    1d35:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1d3a:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
    1d41:	00 00 
    1d43:	c4 c1 05 72 d4 18    	vpsrld $0x18,%ymm12,%ymm15
    1d49:	49 89 f8             	mov    %rdi,%r8
    1d4c:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
    1d53:	00 00 
    1d55:	c5 fe 7f 94 24 80 01 	vmovdqu %ymm2,0x180(%rsp)
    1d5c:	00 00 
    1d5e:	e9 ac 00 00 00       	jmp    1e0f <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x111f>
    1d63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1d68:	8b 43 24             	mov    0x24(%rbx),%eax
    1d6b:	8b 53 20             	mov    0x20(%rbx),%edx
    1d6e:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1d72:	c5 c5 fa 84 24 e0 00 	vpsubd 0xe0(%rsp),%ymm7,%ymm0
    1d79:	00 00 
    1d7b:	0f af d0             	imul   %eax,%edx
    1d7e:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    1d82:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1d87:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    1d8c:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    1d90:	48 8b 03             	mov    (%rbx),%rax
    1d93:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1d98:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    1d9d:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1da1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1da5:	c4 e2 4d 90 0c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm1
    1dab:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    1db0:	c4 c1 75 db d7       	vpand  %ymm15,%ymm1,%ymm2
    1db5:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1dba:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1dbf:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1dc4:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    1dc9:	49 83 c3 18          	add    $0x18,%r11
    1dcd:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1dd1:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1dd5:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
    1ddc:	00 00 00 
    1ddf:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1de3:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1de9:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1dee:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1df3:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1df7:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    1dfd:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    1e03:	4d 39 e0             	cmp    %r12,%r8
    1e06:	0f 84 74 05 00 00    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    1e0c:	49 ff c4             	inc    %r12
    1e0f:	c4 c1 7a 6f 13       	vmovdqu (%r11),%xmm2
    1e14:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
    1e1a:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1e1e:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1e22:	49 8b 02             	mov    (%r10),%rax
    1e25:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    1e29:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1e2e:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    1e33:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
    1e39:	41 8b 52 50          	mov    0x50(%r10),%edx
    1e3d:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
    1e43:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    1e47:	c4 e2 6d 00 94 24 80 	vpshufb 0x80(%rsp),%ymm2,%ymm2
    1e4e:	00 00 00 
    1e51:	c5 79 6e f2          	vmovd  %edx,%xmm14
    1e55:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1e5a:	c5 e5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm3
    1e5f:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    1e64:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1e69:	c4 e2 4d 90 24 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm4
    1e6f:	49 8b 42 08          	mov    0x8(%r10),%rax
    1e73:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1e78:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1e7c:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1e81:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1e85:	c4 e2 45 90 0c a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm1
    1e8b:	49 8b 42 10          	mov    0x10(%r10),%rax
    1e8f:	c5 c5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm7
    1e94:	c4 c2 45 40 fe       	vpmulld %ymm14,%ymm7,%ymm7
    1e99:	c4 e2 4d 90 04 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm0
    1e9f:	c5 cd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm6
    1ea4:	49 8b 42 48          	mov    0x48(%r10),%rax
    1ea8:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1ead:	c5 bd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm8
    1eb2:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1eb6:	c4 41 4d fe c0       	vpaddd %ymm8,%ymm6,%ymm8
    1ebb:	c4 c1 4d 72 d4 0f    	vpsrld $0xf,%ymm12,%ymm6
    1ec1:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
    1ec5:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
    1ec9:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
    1ecd:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1ed1:	c4 a2 4d 90 3c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
    1ed7:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    1edb:	49 8b 52 18          	mov    0x18(%r10),%rdx
    1edf:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1ee4:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    1eeb:	00 00 
    1eed:	c4 c1 4d fe f8       	vpaddd %ymm8,%ymm6,%ymm7
    1ef2:	c4 e2 5d 39 f1       	vpminsd %ymm1,%ymm4,%ymm6
    1ef7:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
    1efe:	00 00 
    1f00:	c4 62 25 90 2c b8    	vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm13
    1f06:	c4 c1 45 72 d4 1f    	vpsrld $0x1f,%ymm12,%ymm7
    1f0c:	c5 7e 7f ac 24 60 01 	vmovdqu %ymm13,0x160(%rsp)
    1f13:	00 00 
    1f15:	c4 62 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm11
    1f1b:	49 8b 52 20          	mov    0x20(%r10),%rdx
    1f1f:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1f23:	c4 62 6d 90 14 aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm10
    1f29:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1f2d:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1f31:	c4 e2 5d 3d e9       	vpmaxsd %ymm1,%ymm4,%ymm5
    1f36:	c4 62 6d 90 2c 9a    	vpgatherdd %ymm2,(%rdx,%ymm3,4),%ymm13
    1f3c:	c5 f5 66 dc          	vpcmpgtd %ymm4,%ymm1,%ymm3
    1f40:	c5 fd 66 d5          	vpcmpgtd %ymm5,%ymm0,%ymm2
    1f44:	c4 e2 55 3d e8       	vpmaxsd %ymm0,%ymm5,%ymm5
    1f49:	c5 fe 7f ac 24 a0 01 	vmovdqu %ymm5,0x1a0(%rsp)
    1f50:	00 00 
    1f52:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1f56:	c4 c3 0d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm14,%ymm3
    1f5c:	c4 e3 65 4c df 20    	vpblendvb %ymm2,%ymm7,%ymm3,%ymm3
    1f62:	c4 e2 4d 39 d0       	vpminsd %ymm0,%ymm6,%ymm2
    1f67:	c5 fe 7f 94 24 c0 01 	vmovdqu %ymm2,0x1c0(%rsp)
    1f6e:	00 00 
    1f70:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1f75:	c5 cd 66 f0          	vpcmpgtd %ymm0,%ymm6,%ymm6
    1f79:	c5 7e 7f 84 24 20 01 	vmovdqu %ymm8,0x120(%rsp)
    1f80:	00 00 
    1f82:	c5 7e 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm8
    1f89:	00 00 
    1f8b:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
    1f91:	c5 dd 66 d9          	vpcmpgtd %ymm1,%ymm4,%ymm3
    1f95:	c5 7e 7f 8c 24 00 01 	vmovdqu %ymm9,0x100(%rsp)
    1f9c:	00 00 
    1f9e:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1fa2:	c5 3d fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm8,%ymm8
    1fa9:	00 00 
    1fab:	c5 5d fe c9          	vpaddd %ymm1,%ymm4,%ymm9
    1faf:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1fb4:	c4 e3 0d 4c 9c 24 00 	vpblendvb %ymm3,0x100(%rsp),%ymm14,%ymm3
    1fbb:	01 00 00 30 
    1fbf:	c4 41 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm8
    1fc4:	c4 e3 65 4c df 60    	vpblendvb %ymm6,%ymm7,%ymm3,%ymm3
    1fca:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    1fd1:	00 00 
    1fd3:	c4 41 3d fe c9       	vpaddd %ymm9,%ymm8,%ymm9
    1fd8:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    1fdc:	c4 e2 55 90 34 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm6
    1fe2:	c5 85 db ac 24 40 01 	vpand  0x140(%rsp),%ymm15,%ymm5
    1fe9:	00 00 
    1feb:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1ff0:	c5 4d fa c2          	vpsubd %ymm2,%ymm6,%ymm8
    1ff4:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    1ff9:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1ffd:	c4 42 35 40 c0       	vpmulld %ymm8,%ymm9,%ymm8
    2002:	c4 e2 6d 40 94 24 a0 	vpmulld 0x1a0(%rsp),%ymm2,%ymm2
    2009:	01 00 00 
    200c:	c4 c1 55 72 e3 10    	vpsrad $0x10,%ymm11,%ymm5
    2012:	c5 e5 fe 9c 24 80 01 	vpaddd 0x180(%rsp),%ymm3,%ymm3
    2019:	00 00 
    201b:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    201f:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    2023:	c5 05 db 84 24 60 01 	vpand  0x160(%rsp),%ymm15,%ymm8
    202a:	00 00 
    202c:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
    2030:	c4 c1 4d 72 e2 10    	vpsrad $0x10,%ymm10,%ymm6
    2036:	c4 62 3d 40 84 24 c0 	vpmulld 0x1c0(%rsp),%ymm8,%ymm8
    203d:	01 00 00 
    2040:	c5 3d fe c2          	vpaddd %ymm2,%ymm8,%ymm8
    2044:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
    2048:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    204d:	c5 ed 72 d3 10       	vpsrld $0x10,%ymm3,%ymm2
    2052:	c5 d5 fe de          	vpaddd %ymm6,%ymm5,%ymm3
    2056:	c5 fe 7f 94 24 a0 01 	vmovdqu %ymm2,0x1a0(%rsp)
    205d:	00 00 
    205f:	c4 c1 6d 72 f5 10    	vpslld $0x10,%ymm13,%ymm2
    2065:	c5 fe 7f 9c 24 e0 01 	vmovdqu %ymm3,0x1e0(%rsp)
    206c:	00 00 
    206e:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    2073:	c4 c1 65 72 e5 10    	vpsrad $0x10,%ymm13,%ymm3
    2079:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    207d:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    2081:	c4 c1 7d 72 f2 10    	vpslld $0x10,%ymm10,%ymm0
    2087:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    208c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2090:	c4 c1 75 72 f3 10    	vpslld $0x10,%ymm11,%ymm1
    2096:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    209b:	c5 6d fe d0          	vpaddd %ymm0,%ymm2,%ymm10
    209f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    20a3:	c5 7e 7f 94 24 c0 01 	vmovdqu %ymm10,0x1c0(%rsp)
    20aa:	00 00 
    20ac:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    20b1:	c4 62 75 3d c0       	vpmaxsd %ymm0,%ymm1,%ymm8
    20b6:	c5 7d 66 d9          	vpcmpgtd %ymm1,%ymm0,%ymm11
    20ba:	c4 62 75 39 e8       	vpminsd %ymm0,%ymm1,%ymm13
    20bf:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    20c4:	c5 f5 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm0
    20c8:	c4 62 15 39 ca       	vpminsd %ymm2,%ymm13,%ymm9
    20cd:	c5 15 66 ea          	vpcmpgtd %ymm2,%ymm13,%ymm13
    20d1:	c4 62 3d 3d c2       	vpmaxsd %ymm2,%ymm8,%ymm8
    20d6:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    20dd:	00 00 
    20df:	c4 63 0d 4c 9c 24 00 	vpblendvb %ymm11,0x100(%rsp),%ymm14,%ymm11
    20e6:	01 00 00 b0 
    20ea:	c4 63 25 4c df 40    	vpblendvb %ymm4,%ymm7,%ymm11,%ymm11
    20f0:	c4 e3 0d 4c 84 24 00 	vpblendvb %ymm0,0x100(%rsp),%ymm14,%ymm0
    20f7:	01 00 00 00 
    20fb:	c5 25 fe 9c 24 20 01 	vpaddd 0x120(%rsp),%ymm11,%ymm11
    2102:	00 00 
    2104:	c4 e3 7d 4c c7 d0    	vpblendvb %ymm13,%ymm7,%ymm0,%ymm0
    210a:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    210e:	c4 a2 2d 90 24 98    	vpgatherdd %ymm10,(%rax,%ymm11,4),%ymm4
    2114:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    2119:	c4 62 2d 90 1c 80    	vpgatherdd %ymm10,(%rax,%ymm0,4),%ymm11
    211f:	c5 fe 6f 84 24 40 01 	vmovdqu 0x140(%rsp),%ymm0
    2126:	00 00 
    2128:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    212d:	c4 41 3d fe d1       	vpaddd %ymm9,%ymm8,%ymm10
    2132:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    2137:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    213d:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2142:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    2147:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    214e:	00 00 
    2150:	c5 f5 fe 8c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm1,%ymm1
    2157:	00 00 
    2159:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    215e:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    2163:	c5 25 fa d4          	vpsubd %ymm4,%ymm11,%ymm10
    2167:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    216c:	c4 42 75 40 d2       	vpmulld %ymm10,%ymm1,%ymm10
    2171:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    2176:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    217b:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2180:	c4 62 55 39 c6       	vpminsd %ymm6,%ymm5,%ymm8
    2185:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    218a:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    2190:	c5 7e 6f 9c 24 00 01 	vmovdqu 0x100(%rsp),%ymm11
    2197:	00 00 
    2199:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    219e:	c5 fd fe 84 24 80 01 	vpaddd 0x180(%rsp),%ymm0,%ymm0
    21a5:	00 00 
    21a7:	c4 62 3d 39 cb       	vpminsd %ymm3,%ymm8,%ymm9
    21ac:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    21b0:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    21b4:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    21b9:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    21bd:	c4 e2 55 3d e6       	vpmaxsd %ymm6,%ymm5,%ymm4
    21c2:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    21c6:	c5 cd 66 d5          	vpcmpgtd %ymm5,%ymm6,%ymm2
    21ca:	c5 e5 66 cc          	vpcmpgtd %ymm4,%ymm3,%ymm1
    21ce:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    21d2:	c4 e2 5d 3d e3       	vpmaxsd %ymm3,%ymm4,%ymm4
    21d7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    21dc:	c4 c3 0d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm14,%ymm2
    21e2:	c4 e3 6d 4c d7 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm2
    21e8:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    21ef:	00 00 
    21f1:	c4 e2 2d 90 0c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm1
    21f7:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    21fe:	00 00 
    2200:	c4 c3 0d 4c d3 50    	vpblendvb %ymm5,%ymm11,%ymm14,%ymm2
    2206:	c5 7e 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm13
    220d:	00 00 
    220f:	c4 e3 6d 4c d7 80    	vpblendvb %ymm8,%ymm7,%ymm2,%ymm2
    2215:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    2219:	c4 41 5d fe c1       	vpaddd %ymm9,%ymm4,%ymm8
    221e:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    2222:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
    2229:	00 00 
    222b:	c4 c1 65 fa d8       	vpsubd %ymm8,%ymm3,%ymm3
    2230:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2235:	c4 e2 55 90 3c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm7
    223b:	c5 e5 fe 9c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm3,%ymm3
    2242:	00 00 
    2244:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2249:	c5 d5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm5
    224e:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2253:	c4 c1 4d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm6
    2259:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    225e:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2263:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2268:	c5 ed 72 f5 10       	vpslld $0x10,%ymm5,%ymm2
    226d:	c5 45 fa c1          	vpsubd %ymm1,%ymm7,%ymm8
    2271:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
    2275:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    2279:	c4 42 65 40 c0       	vpmulld %ymm8,%ymm3,%ymm8
    227e:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    2285:	00 00 
    2287:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    228c:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    2291:	c5 ed fe 94 24 80 01 	vpaddd 0x180(%rsp),%ymm2,%ymm2
    2298:	00 00 
    229a:	c5 fd fa 5c 24 20    	vpsubd 0x20(%rsp),%ymm0,%ymm3
    22a0:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    22a4:	c5 bd fe d2          	vpaddd %ymm2,%ymm8,%ymm2
    22a8:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    22ac:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    22b0:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    22b5:	c5 f5 fa 64 24 40    	vpsubd 0x40(%rsp),%ymm1,%ymm4
    22bb:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    22bf:	c5 e5 6b d4          	vpackssdw %ymm4,%ymm3,%ymm2
    22c3:	c5 ed d9 54 24 60    	vpsubusw 0x60(%rsp),%ymm2,%ymm2
    22c9:	c4 e2 7d 17 d2       	vptest %ymm2,%ymm2
    22ce:	0f 84 94 fa ff ff    	je     1d68 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1078>
    22d4:	c5 fe 6f 94 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm2
    22db:	00 00 
    22dd:	48 89 9c 24 d8 04 00 	mov    %rbx,0x4d8(%rsp)
    22e4:	00 
    22e5:	49 8d 6a 60          	lea    0x60(%r10),%rbp
    22e9:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    22f0:	4c 89 d3             	mov    %r10,%rbx
    22f3:	48 8d be c0 00 00 00 	lea    0xc0(%rsi),%rdi
    22fa:	4d 89 c2             	mov    %r8,%r10
    22fd:	80 7d 58 00          	cmpb   $0x0,0x58(%rbp)
    2301:	0f 85 d9 18 00 00    	jne    3be0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ef0>
    2307:	80 7d 59 00          	cmpb   $0x0,0x59(%rbp)
    230b:	c5 fd 7f 96 c0 00 00 	vmovdqa %ymm2,0xc0(%rsi)
    2312:	00 
    2313:	48 89 fa             	mov    %rdi,%rdx
    2316:	48 89 e9             	mov    %rbp,%rcx
    2319:	c5 fd 7f 86 e0 00 00 	vmovdqa %ymm0,0xe0(%rsi)
    2320:	00 
    2321:	c5 fd 7f 8e 00 01 00 	vmovdqa %ymm1,0x100(%rsi)
    2328:	00 
    2329:	0f 84 51 18 00 00    	je     3b80 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e90>
    232f:	c5 f8 77             	vzeroupper
    2332:	e8 a9 df ff ff       	call   2e0 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    2337:	c5 fd 6f 96 c0 00 00 	vmovdqa 0xc0(%rsi),%ymm2
    233e:	00 
    233f:	c5 fd 6f 86 e0 00 00 	vmovdqa 0xe0(%rsi),%ymm0
    2346:	00 
    2347:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    234c:	c5 fd 6f 8e 00 01 00 	vmovdqa 0x100(%rsi),%ymm1
    2353:	00 
    2354:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 239c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16ac>
    235b:	00 
    235c:	48 83 c5 60          	add    $0x60,%rbp
    2360:	49 39 ed             	cmp    %rbp,%r13
    2363:	75 98                	jne    22fd <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x160d>
    2365:	4d 89 d0             	mov    %r10,%r8
    2368:	49 89 da             	mov    %rbx,%r10
    236b:	48 8b 9c 24 d8 04 00 	mov    0x4d8(%rsp),%rbx
    2372:	00 
    2373:	e9 47 fa ff ff       	jmp    1dbf <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10cf>
    2378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    237f:	00 
    2380:	c5 f8 77             	vzeroupper
    2383:	c5 f8 28 b4 24 f0 03 	vmovaps 0x3f0(%rsp),%xmm6
    238a:	00 00 
    238c:	c5 f8 28 bc 24 00 04 	vmovaps 0x400(%rsp),%xmm7
    2393:	00 00 
    2395:	c5 78 28 84 24 10 04 	vmovaps 0x410(%rsp),%xmm8
    239c:	00 00 
    239e:	c5 78 28 8c 24 20 04 	vmovaps 0x420(%rsp),%xmm9
    23a5:	00 00 
    23a7:	c5 78 28 94 24 30 04 	vmovaps 0x430(%rsp),%xmm10
    23ae:	00 00 
    23b0:	c5 78 28 9c 24 40 04 	vmovaps 0x440(%rsp),%xmm11
    23b7:	00 00 
    23b9:	c5 78 28 a4 24 50 04 	vmovaps 0x450(%rsp),%xmm12
    23c0:	00 00 
    23c2:	c5 78 28 ac 24 60 04 	vmovaps 0x460(%rsp),%xmm13
    23c9:	00 00 
    23cb:	c5 78 28 b4 24 70 04 	vmovaps 0x470(%rsp),%xmm14
    23d2:	00 00 
    23d4:	c5 78 28 bc 24 80 04 	vmovaps 0x480(%rsp),%xmm15
    23db:	00 00 
    23dd:	48 81 c4 98 04 00 00 	add    $0x498,%rsp
    23e4:	5b                   	pop    %rbx
    23e5:	5e                   	pop    %rsi
    23e6:	5f                   	pop    %rdi
    23e7:	5d                   	pop    %rbp
    23e8:	41 5c                	pop    %r12
    23ea:	41 5d                	pop    %r13
    23ec:	c3                   	ret
    23ed:	0f 1f 00             	nopl   (%rax)
    23f0:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    23f7:	00 00 
    23f9:	48 8b 07             	mov    (%rdi),%rax
    23fc:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    2400:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    2404:	8b 4f 54             	mov    0x54(%rdi),%ecx
    2407:	8b 57 50             	mov    0x50(%rdi),%edx
    240a:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    240f:	c4 41 7d 6f cd       	vmovdqa %ymm13,%ymm9
    2414:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    241b:	00 00 
    241d:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    2423:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2427:	c5 7e 7f b4 24 20 01 	vmovdqu %ymm14,0x120(%rsp)
    242e:	00 00 
    2430:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    2434:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2439:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    243e:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2466 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1776>
    2445:	00 
    2446:	c4 a2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm14,4),%ymm5
    244c:	48 8b 47 10          	mov    0x10(%rdi),%rax
    2450:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    2454:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2459:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 2481 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1791>
    2460:	00 
    2461:	c4 a2 6d 90 1c a0    	vpgatherdd %ymm2,(%rax,%ymm12,4),%ymm3
    2467:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    246c:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    2470:	48 8b 47 48          	mov    0x48(%rdi),%rax
    2474:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2479:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    247e:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2482:	c4 e2 5d 40 e2       	vpmulld %ymm2,%ymm4,%ymm4
    2487:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 24af <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17bf>
    248e:	00 
    248f:	c4 62 7d 3d c5       	vpmaxsd %ymm5,%ymm0,%ymm8
    2494:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2498:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
    249d:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    24a2:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    24a6:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    24aa:	c4 e2 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm6
    24af:	c4 22 75 90 14 b8    	vpgatherdd %ymm1,(%rax,%ymm15,4),%ymm10
    24b5:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    24b9:	ba 00 80 00 00       	mov    $0x8000,%edx
    24be:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    24c3:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    24c8:	c4 a2 25 90 0c b0    	vpgatherdd %ymm11,(%rax,%ymm14,4),%ymm1
    24ce:	c4 62 4d 39 db       	vpminsd %ymm3,%ymm6,%ymm11
    24d3:	c5 fe 7f 8c 24 80 01 	vmovdqu %ymm1,0x180(%rsp)
    24da:	00 00 
    24dc:	c5 d5 66 c8          	vpcmpgtd %ymm0,%ymm5,%ymm1
    24e0:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
    24e4:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    24ea:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 24f3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1803>
    24f1:	ff ff 40 
    24f4:	c5 85 fe c9          	vpaddd %ymm1,%ymm15,%ymm1
    24f8:	c4 e2 35 90 24 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm4
    24fe:	c5 fd 66 cd          	vpcmpgtd %ymm5,%ymm0,%ymm1
    2502:	c5 7e 7f b4 24 60 01 	vmovdqu %ymm14,0x160(%rsp)
    2509:	00 00 
    250b:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    250f:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    2513:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    2518:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    251e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 2527 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1837>
    2525:	ff ff 60 
    2528:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    252c:	c5 8d fa c9          	vpsubd %ymm1,%ymm14,%ymm1
    2530:	c4 41 3d fe f3       	vpaddd %ymm11,%ymm8,%ymm14
    2535:	c4 62 4d 90 0c 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm9
    253b:	c4 c1 75 72 d5 18    	vpsrld $0x18,%ymm13,%ymm1
    2541:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    2546:	c5 7e 7f 94 24 40 01 	vmovdqu %ymm10,0x140(%rsp)
    254d:	00 00 
    254f:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    2553:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    2557:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    255b:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
    255f:	c5 75 db 94 24 40 01 	vpand  0x140(%rsp),%ymm1,%ymm10
    2566:	00 00 
    2568:	c5 fe 7f ac 24 a0 01 	vmovdqu %ymm5,0x1a0(%rsp)
    256f:	00 00 
    2571:	48 8b 57 28          	mov    0x28(%rdi),%rdx
    2575:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    257a:	c5 fe 6f 9c 24 20 01 	vmovdqu 0x120(%rsp),%ymm3
    2581:	00 00 
    2583:	c4 c1 4d 72 f2 10    	vpslld $0x10,%ymm10,%ymm6
    2589:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    258e:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    2592:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2597:	c5 fd fe f6          	vpaddd %ymm6,%ymm0,%ymm6
    259b:	c5 f5 db 84 24 80 01 	vpand  0x180(%rsp),%ymm1,%ymm0
    25a2:	00 00 
    25a4:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    25a9:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    25ae:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    25b2:	c5 fe 6f a4 24 00 01 	vmovdqu 0x100(%rsp),%ymm4
    25b9:	00 00 
    25bb:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    25bf:	c5 a5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm11
    25c4:	c5 7e 7f 9c 24 c0 00 	vmovdqu %ymm11,0xc0(%rsp)
    25cb:	00 00 
    25cd:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    25d2:	c4 a2 25 90 34 a2    	vpgatherdd %ymm11,(%rdx,%ymm12,4),%ymm6
    25d8:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    25dc:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    25e1:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 2609 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1919>
    25e8:	00 
    25e9:	c4 62 25 90 04 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm8
    25ef:	48 8b 57 18          	mov    0x18(%rdi),%rdx
    25f3:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    25f8:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 2620 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1930>
    25ff:	00 
    2600:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    2606:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    260b:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    260f:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 2637 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1947>
    2616:	00 
    2617:	c4 42 65 3d d0       	vpmaxsd %ymm8,%ymm3,%ymm10
    261c:	c5 bd 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm0
    2620:	c4 c2 65 39 e8       	vpminsd %ymm8,%ymm3,%ymm5
    2625:	c4 c1 4d 66 e2       	vpcmpgtd %ymm10,%ymm6,%ymm4
    262a:	c4 62 55 39 f6       	vpminsd %ymm6,%ymm5,%ymm14
    262f:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    2634:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    2638:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    263e:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm0,%ymm0        # 2647 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1957>
    2645:	ff ff 40 
    2648:	c5 85 fe c0          	vpaddd %ymm0,%ymm15,%ymm0
    264c:	c4 e2 25 90 24 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm4
    2652:	c4 c1 65 66 c0       	vpcmpgtd %ymm8,%ymm3,%ymm0
    2657:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    265c:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    2661:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    2666:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    266a:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    2670:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 2679 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1989>
    2677:	ff ff 50 
    267a:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    2681:	00 00 
    2683:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2687:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
    268e:	00 00 
    2690:	c4 62 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm9
    2696:	c5 fe 6f 84 24 40 01 	vmovdqu 0x140(%rsp),%ymm0
    269d:	00 00 
    269f:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    26a5:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    26aa:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    26ae:	c5 a5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm11
    26b3:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    26b7:	c5 7e 7f 8c 24 c0 01 	vmovdqu %ymm9,0x1c0(%rsp)
    26be:	00 00 
    26c0:	c4 41 2d fe ce       	vpaddd %ymm14,%ymm10,%ymm9
    26c5:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
    26c9:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    26ce:	c5 7e 6f 8c 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm9
    26d5:	00 00 
    26d7:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    26dd:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    26e1:	c5 fd fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm0,%ymm0
    26e8:	00 00 
    26ea:	c5 b5 fa f4          	vpsubd %ymm4,%ymm9,%ymm6
    26ee:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    26f3:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    26f8:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
    26fd:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    2702:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2707:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    270c:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    2710:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    2714:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2718:	c5 8d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm14
    271d:	c4 a2 25 90 04 a2    	vpgatherdd %ymm11,(%rdx,%ymm12,4),%ymm0
    2723:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    2728:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2750 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a60>
    272f:	00 
    2730:	48 8b 57 38          	mov    0x38(%rdi),%rdx
    2734:	c5 fe 6f 9c 24 20 01 	vmovdqu 0x120(%rsp),%ymm3
    273b:	00 00 
    273d:	c5 fe 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm6
    2744:	00 00 
    2746:	c4 e2 25 90 2c 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm5
    274c:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    2750:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    2754:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 277c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a8c>
    275b:	00 
    275c:	c4 e2 65 90 24 b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm4
    2762:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 278a <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a9a>
    2769:	00 
    276a:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    276f:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    2773:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    2778:	c4 c1 7d 66 d8       	vpcmpgtd %ymm8,%ymm0,%ymm3
    277d:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    2782:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    2787:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    278b:	c4 41 3d fe da       	vpaddd %ymm10,%ymm8,%ymm11
    2790:	c4 e3 6d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm6
    2796:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    279b:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 27a4 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ab4>
    27a2:	ff ff 30 
    27a5:	c5 85 fe f6          	vpaddd %ymm6,%ymm15,%ymm6
    27a9:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    27ae:	c4 e2 05 90 1c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm3
    27b4:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    27b8:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    27bd:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    27c2:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    27c6:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    27ca:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    27ce:	c4 e3 6d 4c d7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm2
    27d4:	c5 fe 6f bc 24 60 01 	vmovdqu 0x160(%rsp),%ymm7
    27db:	00 00 
    27dd:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
    27e4:	00 00 
    27e6:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm2,%ymm2        # 27ef <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1aff>
    27ed:	ff ff 90 
    27f0:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    27f4:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    27f9:	c4 e2 05 90 3c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm7
    27ff:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    2806:	00 00 
    2808:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    280c:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2811:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    2816:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    281b:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
    281f:	c5 35 fe 8c 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm9,%ymm9
    2826:	00 00 
    2828:	c5 ed db c9          	vpand  %ymm1,%ymm2,%ymm1
    282c:	c5 c5 fa e3          	vpsubd %ymm3,%ymm7,%ymm4
    2830:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    2834:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2839:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    283e:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    2842:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    2847:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    284c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2850:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2854:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    2859:	e9 7b f4 ff ff       	jmp    1cd9 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xfe9>
    285e:	66 90                	xchg   %ax,%ax
    2860:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
    2867:	00 00 
    2869:	48 8b 07             	mov    (%rdi),%rax
    286c:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    2870:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    2874:	8b 4f 54             	mov    0x54(%rdi),%ecx
    2877:	8b 57 50             	mov    0x50(%rdi),%edx
    287a:	c4 e2 5d 90 1c a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm3
    2880:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2884:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    2888:	c5 79 6e ca          	vmovd  %edx,%xmm9
    288c:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2891:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2895:	c4 a2 5d 90 2c b0    	vpgatherdd %ymm4,(%rax,%ymm14,4),%ymm5
    289b:	48 8b 47 10          	mov    0x10(%rdi),%rax
    289f:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    28a4:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    28a8:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    28ad:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    28b2:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 28da <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bea>
    28b9:	00 
    28ba:	c4 a2 45 90 34 a0    	vpgatherdd %ymm7,(%rax,%ymm12,4),%ymm6
    28c0:	c5 79 6e e1          	vmovd  %ecx,%xmm12
    28c4:	48 8b 47 48          	mov    0x48(%rdi),%rax
    28c8:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 28f0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c00>
    28cf:	00 
    28d0:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    28d5:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    28da:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 2902 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c12>
    28e1:	00 
    28e2:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    28e7:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    28ec:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    28f0:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    28f5:	c5 65 fe f5          	vpaddd %ymm5,%ymm3,%ymm14
    28f9:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    28fe:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2902:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2906:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    290a:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    290e:	c4 e2 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm0
    2914:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2918:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    291c:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2921:	c4 c1 55 72 d5 18    	vpsrld $0x18,%ymm13,%ymm5
    2927:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    292b:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
    2931:	c4 62 45 90 3c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm15
    2937:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    293c:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2941:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
    2947:	c4 c1 1d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm12
    294d:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm9,%ymm9        # 2956 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c66>
    2954:	ff ff b0 
    2957:	c5 1d db e5          	vpand  %ymm5,%ymm12,%ymm12
    295b:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 2964 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c74>
    2962:	ff ff 70 
    2965:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    296a:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    296f:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2973:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2977:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    297b:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    2980:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    2985:	c4 e2 0d 90 14 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm2
    298b:	c4 c1 0d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm14
    2991:	c4 e2 4d 90 0c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm1
    2997:	b8 00 80 00 00       	mov    $0x8000,%eax
    299c:	c5 f5 db dd          	vpand  %ymm5,%ymm1,%ymm3
    29a0:	c5 6d db dd          	vpand  %ymm5,%ymm2,%ymm11
    29a4:	c5 fd db f5          	vpand  %ymm5,%ymm0,%ymm6
    29a8:	c5 85 db e5          	vpand  %ymm5,%ymm15,%ymm4
    29ac:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    29b1:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
    29b5:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    29b9:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    29be:	c5 0d db f5          	vpand  %ymm5,%ymm14,%ymm14
    29c2:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    29c7:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    29cb:	c4 c1 65 fa f3       	vpsubd %ymm11,%ymm3,%ymm6
    29d0:	c5 f9 6e d8          	vmovd  %eax,%xmm3
    29d4:	c4 e2 4d 40 f7       	vpmulld %ymm7,%ymm6,%ymm6
    29d9:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
    29de:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    29e3:	c5 35 fe cb          	vpaddd %ymm3,%ymm9,%ymm9
    29e7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    29ec:	c5 25 db dd          	vpand  %ymm5,%ymm11,%ymm11
    29f0:	c5 ed db d5          	vpand  %ymm5,%ymm2,%ymm2
    29f4:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    29f9:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    29fe:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    2a02:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2a07:	c5 35 db cd          	vpand  %ymm5,%ymm9,%ymm9
    2a0b:	c5 cd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm6
    2a10:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    2a15:	c5 fd db c5          	vpand  %ymm5,%ymm0,%ymm0
    2a19:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
    2a1d:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    2a24:	00 00 
    2a26:	c4 c1 4d 72 f1 10    	vpslld $0x10,%ymm9,%ymm6
    2a2c:	c4 41 25 fa c9       	vpsubd %ymm9,%ymm11,%ymm9
    2a31:	c5 0d fa f4          	vpsubd %ymm4,%ymm14,%ymm14
    2a35:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    2a3a:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    2a3f:	c4 42 0d 40 f2       	vpmulld %ymm10,%ymm14,%ymm14
    2a44:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2a49:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
    2a4d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2a52:	c5 f5 db cd          	vpand  %ymm5,%ymm1,%ymm1
    2a56:	c5 1d fa e1          	vpsubd %ymm1,%ymm12,%ymm12
    2a5a:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2a5e:	c4 42 1d 40 e2       	vpmulld %ymm10,%ymm12,%ymm12
    2a63:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2a68:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    2a6c:	c4 41 0d fe f1       	vpaddd %ymm9,%ymm14,%ymm14
    2a71:	c5 0d fe f4          	vpaddd %ymm4,%ymm14,%ymm14
    2a75:	c5 dd 72 f0 10       	vpslld $0x10,%ymm0,%ymm4
    2a7a:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    2a7e:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    2a83:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    2a89:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    2a8d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2a91:	c5 1d fe e0          	vpaddd %ymm0,%ymm12,%ymm12
    2a95:	c5 1d fe e1          	vpaddd %ymm1,%ymm12,%ymm12
    2a99:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    2a9f:	e9 35 f2 ff ff       	jmp    1cd9 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xfe9>
    2aa4:	0f 1f 40 00          	nopl   0x0(%rax)
    2aa8:	4d 85 c9             	test   %r9,%r9
    2aab:	0f 84 cf f8 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    2ab1:	b8 00 80 00 00       	mov    $0x8000,%eax
    2ab6:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 2b1e <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e2e>
    2abd:	00 
    2abe:	c5 fd 6f 15 80 00 00 	vmovdqa 0x80(%rip),%ymm2        # 2b46 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e56>
    2ac5:	00 
    2ac6:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    2aca:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    2ace:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    2ad2:	48 c1 ef 03          	shr    $0x3,%rdi
    2ad6:	45 31 e4             	xor    %r12d,%r12d
    2ad9:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2ade:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    2ae5:	00 00 
    2ae7:	c5 a5 72 d6 18       	vpsrld $0x18,%ymm6,%ymm11
    2aec:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    2af3:	00 00 
    2af5:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    2afc:	00 00 
    2afe:	e9 ac 00 00 00       	jmp    2baf <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ebf>
    2b03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2b08:	8b 43 24             	mov    0x24(%rbx),%eax
    2b0b:	8b 53 20             	mov    0x20(%rbx),%edx
    2b0e:	c5 c5 fa 84 24 e0 00 	vpsubd 0xe0(%rsp),%ymm7,%ymm0
    2b15:	00 00 
    2b17:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    2b1b:	0f af d0             	imul   %eax,%edx
    2b1e:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2b22:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2b27:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    2b2c:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    2b30:	48 8b 03             	mov    (%rbx),%rax
    2b33:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2b38:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    2b3d:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2b41:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2b45:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
    2b4b:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    2b50:	c4 c1 75 db d3       	vpand  %ymm11,%ymm1,%ymm2
    2b55:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    2b5a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b5f:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    2b64:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    2b69:	49 83 c3 18          	add    $0x18,%r11
    2b6d:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2b71:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2b75:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
    2b7c:	00 00 00 
    2b7f:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2b83:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2b89:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2b8e:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2b93:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2b97:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    2b9d:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    2ba3:	4c 39 e7             	cmp    %r12,%rdi
    2ba6:	0f 84 d4 f7 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    2bac:	49 ff c4             	inc    %r12
    2baf:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    2bb4:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    2bba:	c5 fd 6f d6          	vmovdqa %ymm6,%ymm2
    2bbe:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    2bc2:	49 8b 02             	mov    (%r10),%rax
    2bc5:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    2bc9:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
    2bcd:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2bd3:	41 8b 52 50          	mov    0x50(%r10),%edx
    2bd7:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2bdd:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    2be1:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
    2be8:	00 00 00 
    2beb:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    2bf0:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2bf5:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    2bfa:	c4 c1 7d db fb       	vpand  %ymm11,%ymm0,%ymm7
    2bff:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
    2c06:	00 00 
    2c08:	c4 e2 6d 90 04 b8    	vpgatherdd %ymm2,(%rax,%ymm7,4),%ymm0
    2c0e:	c4 c1 75 db d3       	vpand  %ymm11,%ymm1,%ymm2
    2c13:	49 8b 42 08          	mov    0x8(%r10),%rax
    2c17:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    2c1b:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    2c22:	00 00 
    2c24:	c4 e2 75 90 2c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm5
    2c2a:	49 8b 42 10          	mov    0x10(%r10),%rax
    2c2e:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
    2c35:	00 00 
    2c37:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    2c3b:	c5 e5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm3
    2c40:	c4 e2 75 90 14 a0    	vpgatherdd %ymm1,(%rax,%ymm4,4),%ymm2
    2c46:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    2c4b:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2c4f:	49 8b 42 48          	mov    0x48(%r10),%rax
    2c53:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2c58:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    2c5d:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2c61:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    2c66:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
    2c6b:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    2c6f:	c5 dd 72 d6 0f       	vpsrld $0xf,%ymm6,%ymm4
    2c74:	c5 65 fe ff          	vpaddd %ymm7,%ymm3,%ymm15
    2c78:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    2c7c:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
    2c80:	c5 f9 6e da          	vmovd  %edx,%xmm3
    2c84:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2c88:	c4 62 7d 3d c5       	vpmaxsd %ymm5,%ymm0,%ymm8
    2c8d:	c5 d5 66 f8          	vpcmpgtd %ymm0,%ymm5,%ymm7
    2c91:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2c96:	c4 22 1d 90 2c b8    	vpgatherdd %ymm12,(%rax,%ymm15,4),%ymm13
    2c9c:	c4 41 65 fe e7       	vpaddd %ymm15,%ymm3,%ymm12
    2ca1:	c4 c1 6d 66 d8       	vpcmpgtd %ymm8,%ymm2,%ymm3
    2ca6:	c5 7e 7f ac 24 20 01 	vmovdqu %ymm13,0x120(%rsp)
    2cad:	00 00 
    2caf:	c4 22 35 90 14 a0    	vpgatherdd %ymm9,(%rax,%ymm12,4),%ymm10
    2cb5:	c4 62 3d 3d ca       	vpmaxsd %ymm2,%ymm8,%ymm9
    2cba:	c5 7d 6f c6          	vmovdqa %ymm6,%ymm8
    2cbe:	c4 c3 75 4c fe 70    	vpblendvb %ymm7,%ymm14,%ymm1,%ymm7
    2cc4:	c5 7e 7f 94 24 60 01 	vmovdqu %ymm10,0x160(%rsp)
    2ccb:	00 00 
    2ccd:	c4 62 7d 39 d5       	vpminsd %ymm5,%ymm0,%ymm10
    2cd2:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm7,%ymm7        # 2cdb <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1feb>
    2cd9:	ff ff 30 
    2cdc:	c4 62 2d 39 ea       	vpminsd %ymm2,%ymm10,%ymm13
    2ce1:	c5 85 fe ff          	vpaddd %ymm7,%ymm15,%ymm7
    2ce5:	c5 2d 66 d2          	vpcmpgtd %ymm2,%ymm10,%ymm10
    2ce9:	c4 e2 3d 90 1c b8    	vpgatherdd %ymm8,(%rax,%ymm7,4),%ymm3
    2cef:	c5 fd 66 fd          	vpcmpgtd %ymm5,%ymm0,%ymm7
    2cf3:	c5 7e 7f a4 24 40 01 	vmovdqu %ymm12,0x140(%rsp)
    2cfa:	00 00 
    2cfc:	c5 7d 6f c6          	vmovdqa %ymm6,%ymm8
    2d00:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2d05:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2d09:	c4 c3 75 4c fe 70    	vpblendvb %ymm7,%ymm14,%ymm1,%ymm7
    2d0f:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm7,%ymm7        # 2d18 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2028>
    2d16:	ff ff a0 
    2d19:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    2d1d:	c5 25 db a4 24 20 01 	vpand  0x120(%rsp),%ymm11,%ymm12
    2d24:	00 00 
    2d26:	c4 62 3d 90 14 b8    	vpgatherdd %ymm8,(%rax,%ymm7,4),%ymm10
    2d2c:	c4 41 35 fe c5       	vpaddd %ymm13,%ymm9,%ymm8
    2d31:	c4 41 2d db d3       	vpand  %ymm11,%ymm10,%ymm10
    2d36:	c4 c1 45 72 f4 10    	vpslld $0x10,%ymm12,%ymm7
    2d3c:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    2d41:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    2d45:	c5 ad fa d3          	vpsubd %ymm3,%ymm10,%ymm2
    2d49:	c5 c5 fe bc 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm7,%ymm7
    2d50:	00 00 
    2d52:	c4 e2 7d 40 d2       	vpmulld %ymm2,%ymm0,%ymm2
    2d57:	c5 a5 db 84 24 60 01 	vpand  0x160(%rsp),%ymm11,%ymm0
    2d5e:	00 00 
    2d60:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    2d65:	49 8b 52 28          	mov    0x28(%r10),%rdx
    2d69:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    2d6e:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    2d73:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    2d77:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    2d7c:	c5 7d 6f ee          	vmovdqa %ymm6,%ymm13
    2d80:	c5 ed fe ff          	vpaddd %ymm7,%ymm2,%ymm7
    2d84:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    2d8b:	00 00 
    2d8d:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2d91:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    2d98:	00 00 
    2d9a:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
    2d9e:	c5 fe 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm0
    2da5:	00 00 
    2da7:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2dac:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    2db3:	00 00 
    2db5:	c4 e2 2d 90 3c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm7
    2dbb:	49 8b 52 20          	mov    0x20(%r10),%rdx
    2dbf:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    2dc3:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
    2dc7:	c4 62 2d 90 04 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm8
    2dcd:	49 8b 52 18          	mov    0x18(%r10),%rdx
    2dd1:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    2dd5:	c5 3d db c4          	vpand  %ymm4,%ymm8,%ymm8
    2dd9:	c4 e2 2d 90 14 9a    	vpgatherdd %ymm10,(%rdx,%ymm3,4),%ymm2
    2ddf:	49 8b 52 40          	mov    0x40(%r10),%rdx
    2de3:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2de7:	c4 42 6d 3d e0       	vpmaxsd %ymm8,%ymm2,%ymm12
    2dec:	c5 bd 66 c2          	vpcmpgtd %ymm2,%ymm8,%ymm0
    2df0:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    2df5:	c4 c1 45 66 dc       	vpcmpgtd %ymm12,%ymm7,%ymm3
    2dfa:	c4 62 55 39 cf       	vpminsd %ymm7,%ymm5,%ymm9
    2dff:	c4 62 1d 3d e7       	vpmaxsd %ymm7,%ymm12,%ymm12
    2e04:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
    2e08:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2e0e:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm0,%ymm0        # 2e17 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2127>
    2e15:	ff ff 30 
    2e18:	c5 85 fe c0          	vpaddd %ymm0,%ymm15,%ymm0
    2e1c:	c4 e2 15 90 1c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm3
    2e22:	c4 c1 6d 66 c0       	vpcmpgtd %ymm8,%ymm2,%ymm0
    2e27:	c5 7d 6f ee          	vmovdqa %ymm6,%ymm13
    2e2b:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    2e30:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2e35:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2e3a:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2e40:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 2e49 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2159>
    2e47:	ff ff 50 
    2e4a:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    2e51:	00 00 
    2e53:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2e57:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    2e5e:	00 00 
    2e60:	c4 62 15 90 14 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm10
    2e66:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    2e6d:	00 00 
    2e6f:	c5 7e 7f 8c 24 c0 01 	vmovdqu %ymm9,0x1c0(%rsp)
    2e76:	00 00 
    2e78:	c4 41 1d fe c9       	vpaddd %ymm9,%ymm12,%ymm9
    2e7d:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    2e83:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    2e88:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
    2e8d:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
    2e93:	c4 41 2d db d3       	vpand  %ymm11,%ymm10,%ymm10
    2e98:	c5 c5 fe d2          	vpaddd %ymm2,%ymm7,%ymm2
    2e9c:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    2ea1:	c5 ad fa fb          	vpsubd %ymm3,%ymm10,%ymm7
    2ea5:	c4 c1 55 db eb       	vpand  %ymm11,%ymm5,%ymm5
    2eaa:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    2eaf:	c4 e2 6d 40 ff       	vpmulld %ymm7,%ymm2,%ymm7
    2eb4:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    2eb9:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    2ec0:	00 00 
    2ec2:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    2ec7:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    2ecd:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    2ed1:	c4 e2 55 40 ac 24 c0 	vpmulld 0x1c0(%rsp),%ymm5,%ymm5
    2ed8:	01 00 00 
    2edb:	c5 fd fe 84 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm0,%ymm0
    2ee2:	00 00 
    2ee4:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
    2ee8:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    2eec:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2ef0:	c4 e2 1d 90 2c 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm5
    2ef6:	49 8b 52 38          	mov    0x38(%r10),%rdx
    2efa:	c5 fe 6f 94 24 00 01 	vmovdqu 0x100(%rsp),%ymm2
    2f01:	00 00 
    2f03:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    2f07:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    2f0e:	00 00 
    2f10:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    2f14:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    2f1b:	00 00 
    2f1d:	c4 e2 1d 90 3c 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm7
    2f23:	49 8b 52 30          	mov    0x30(%r10),%rdx
    2f27:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2f2c:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    2f30:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
    2f34:	c4 e2 1d 90 14 9a    	vpgatherdd %ymm12,(%rdx,%ymm3,4),%ymm2
    2f3a:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2f3e:	c4 62 6d 3d c7       	vpmaxsd %ymm7,%ymm2,%ymm8
    2f43:	c5 c5 66 e2          	vpcmpgtd %ymm2,%ymm7,%ymm4
    2f47:	c4 62 6d 39 d7       	vpminsd %ymm7,%ymm2,%ymm10
    2f4c:	c4 c1 55 66 d8       	vpcmpgtd %ymm8,%ymm5,%ymm3
    2f51:	c4 62 2d 39 e5       	vpminsd %ymm5,%ymm10,%ymm12
    2f56:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
    2f5b:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    2f5f:	c4 c3 75 4c e6 40    	vpblendvb %ymm4,%ymm14,%ymm1,%ymm4
    2f65:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm4,%ymm4        # 2f6e <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x227e>
    2f6c:	ff ff 30 
    2f6f:	c5 85 fe e4          	vpaddd %ymm4,%ymm15,%ymm4
    2f73:	c5 7d 6f fe          	vmovdqa %ymm6,%ymm15
    2f77:	c4 e2 05 90 1c a0    	vpgatherdd %ymm15,(%rax,%ymm4,4),%ymm3
    2f7d:	c5 ed 66 e7          	vpcmpgtd %ymm7,%ymm2,%ymm4
    2f81:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    2f85:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    2f8c:	00 00 
    2f8e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2f93:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2f98:	c4 c3 75 4c ce 40    	vpblendvb %ymm4,%ymm14,%ymm1,%ymm1
    2f9e:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    2fa5:	00 00 
    2fa7:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm1,%ymm1        # 2fb0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x22c0>
    2fae:	ff ff a0 
    2fb1:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    2fb5:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    2fb9:	c4 62 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm10
    2fbf:	c5 fe 6f 8c 24 60 01 	vmovdqu 0x160(%rsp),%ymm1
    2fc6:	00 00 
    2fc8:	c4 c1 5d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm4
    2fce:	c4 41 3d fe ec       	vpaddd %ymm12,%ymm8,%ymm13
    2fd3:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    2fd9:	c4 c1 5d db e3       	vpand  %ymm11,%ymm4,%ymm4
    2fde:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    2fe3:	c5 b5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm9
    2fe8:	c4 41 2d db d3       	vpand  %ymm11,%ymm10,%ymm10
    2fed:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    2ff1:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2ff6:	c5 f5 72 f4 10       	vpslld $0x10,%ymm4,%ymm1
    2ffb:	c5 ad fa eb          	vpsubd %ymm3,%ymm10,%ymm5
    2fff:	c4 41 35 fa ca       	vpsubd %ymm10,%ymm9,%ymm9
    3004:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    3008:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    300d:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    3012:	c4 42 35 40 cc       	vpmulld %ymm12,%ymm9,%ymm9
    3017:	c5 f5 fe 8c 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm1,%ymm1
    301e:	00 00 
    3020:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    3024:	c5 35 fe cb          	vpaddd %ymm3,%ymm9,%ymm9
    3028:	c5 fd fa 5c 24 20    	vpsubd 0x20(%rsp),%ymm0,%ymm3
    302e:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    3033:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3038:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    303c:	c5 f5 fa 64 24 40    	vpsubd 0x40(%rsp),%ymm1,%ymm4
    3042:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    3046:	c5 e5 6b d4          	vpackssdw %ymm4,%ymm3,%ymm2
    304a:	c5 ed d9 54 24 60    	vpsubusw 0x60(%rsp),%ymm2,%ymm2
    3050:	c4 e2 7d 17 d2       	vptest %ymm2,%ymm2
    3055:	0f 84 ad fa ff ff    	je     2b08 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e18>
    305b:	41 80 ba b8 00 00 00 	cmpb   $0x0,0xb8(%r10)
    3062:	00 
    3063:	49 8d 6a 60          	lea    0x60(%r10),%rbp
    3067:	c5 fe 6f 94 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm2
    306e:	00 00 
    3070:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    3077:	75 53                	jne    30cc <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23dc>
    3079:	80 7d 59 00          	cmpb   $0x0,0x59(%rbp)
    307d:	c5 fd 7f 16          	vmovdqa %ymm2,(%rsi)
    3081:	48 89 f2             	mov    %rsi,%rdx
    3084:	48 89 e9             	mov    %rbp,%rcx
    3087:	c5 fd 7f 46 20       	vmovdqa %ymm0,0x20(%rsi)
    308c:	c5 fd 7f 4e 40       	vmovdqa %ymm1,0x40(%rsi)
    3091:	0f 84 21 0b 00 00    	je     3bb8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ec8>
    3097:	c5 f8 77             	vzeroupper
    309a:	e8 41 d2 ff ff       	call   2e0 <void jshc_cache_range::(anonymous namespace)::transform<false, true>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    309f:	c5 fd 6f 16          	vmovdqa (%rsi),%ymm2
    30a3:	c5 fd 6f 46 20       	vmovdqa 0x20(%rsi),%ymm0
    30a8:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    30ac:	c5 fd 6f 4e 40       	vmovdqa 0x40(%rsi),%ymm1
    30b1:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 30f9 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2409>
    30b8:	00 
    30b9:	48 83 c5 60          	add    $0x60,%rbp
    30bd:	49 39 ed             	cmp    %rbp,%r13
    30c0:	0f 84 99 fa ff ff    	je     2b5f <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e6f>
    30c6:	80 7d 58 00          	cmpb   $0x0,0x58(%rbp)
    30ca:	74 ad                	je     3079 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2389>
    30cc:	c5 fd 7f 16          	vmovdqa %ymm2,(%rsi)
    30d0:	48 89 f2             	mov    %rsi,%rdx
    30d3:	48 89 e9             	mov    %rbp,%rcx
    30d6:	c5 fd 7f 46 20       	vmovdqa %ymm0,0x20(%rsi)
    30db:	c5 fd 7f 4e 40       	vmovdqa %ymm1,0x40(%rsi)
    30e0:	c5 f8 77             	vzeroupper
    30e3:	e8 18 cf ff ff       	call   0 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    30e8:	eb b5                	jmp    309f <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23af>
    30ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    30f0:	84 d2                	test   %dl,%dl
    30f2:	0f 84 d8 e7 ff ff    	je     18d0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbe0>
    30f8:	4d 85 c9             	test   %r9,%r9
    30fb:	0f 84 7f f2 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    3101:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 3169 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2479>
    3108:	00 
    3109:	49 ff c9             	dec    %r9
    310c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3111:	49 c1 e9 03          	shr    $0x3,%r9
    3115:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
    311b:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    311f:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    3126:	00 00 
    3128:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 31b0 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24c0>
    312f:	00 
    3130:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    3135:	b8 00 80 00 00       	mov    $0x8000,%eax
    313a:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
    3141:	00 00 
    3143:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    3147:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    314c:	c5 fe 7f a4 24 c0 00 	vmovdqu %ymm4,0xc0(%rsp)
    3153:	00 00 
    3155:	e9 a8 00 00 00       	jmp    3202 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2512>
    315a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3160:	8b 43 24             	mov    0x24(%rbx),%eax
    3163:	8b 53 20             	mov    0x20(%rbx),%edx
    3166:	c5 e5 fa 9c 24 e0 00 	vpsubd 0xe0(%rsp),%ymm3,%ymm3
    316d:	00 00 
    316f:	0f af d0             	imul   %eax,%edx
    3172:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    3176:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    317b:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    3180:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    3184:	48 8b 03             	mov    (%rbx),%rax
    3187:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    318c:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    3191:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    3195:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    3199:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    319d:	c4 e2 5d 90 0c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm1
    31a3:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    31a8:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
    31ad:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    31b1:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    31b5:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    31ba:	c5 f5 72 f3 08       	vpslld $0x8,%ymm3,%ymm1
    31bf:	49 83 c0 18          	add    $0x18,%r8
    31c3:	c5 f5 eb ca          	vpor   %ymm2,%ymm1,%ymm1
    31c7:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
    31cb:	c4 e2 75 00 8c 24 a0 	vpshufb 0xa0(%rsp),%ymm1,%ymm1
    31d2:	00 00 00 
    31d5:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
    31d9:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    31df:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
    31e4:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    31e9:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    31ed:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
    31f3:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    31f9:	4d 39 c8             	cmp    %r9,%r8
    31fc:	0f 84 7e f1 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    3202:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    3207:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
    320d:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    3211:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    3216:	49 8b 02             	mov    (%r10),%rax
    3219:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    321d:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
    3223:	41 8b 52 50          	mov    0x50(%r10),%edx
    3227:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
    322d:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3231:	c4 e2 75 00 8c 24 80 	vpshufb 0x80(%rsp),%ymm1,%ymm1
    3238:	00 00 00 
    323b:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    323f:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3244:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    3249:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    324e:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3252:	c4 e2 5d 90 2c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm5
    3258:	49 8b 42 08          	mov    0x8(%r10),%rax
    325c:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
    3260:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    3264:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    3269:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    326e:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3272:	c4 e2 5d 90 3c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm7
    3278:	49 8b 42 10          	mov    0x10(%r10),%rax
    327c:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    3280:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 32a8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25b8>
    3287:	00 
    3288:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    328d:	c4 62 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm8
    3293:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3298:	49 8b 42 48          	mov    0x48(%r10),%rax
    329c:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    32a0:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
    32a5:	c4 c1 75 72 d0 11    	vpsrld $0x11,%ymm8,%ymm1
    32ab:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 32d3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25e3>
    32b2:	00 
    32b3:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 32db <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25eb>
    32ba:	00 
    32bb:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    32c0:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    32c5:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
    32ca:	c4 42 1d 39 d8       	vpminsd %ymm8,%ymm12,%ymm11
    32cf:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
    32d4:	c4 41 1d 66 e0       	vpcmpgtd %ymm8,%ymm12,%ymm12
    32d9:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    32dd:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    32e1:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    32e5:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    32ea:	c4 e2 5d 90 0c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm1
    32f0:	c5 ed fe e3          	vpaddd %ymm3,%ymm2,%ymm4
    32f4:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    32fb:	00 00 
    32fd:	c4 e2 0d 90 14 a0    	vpgatherdd %ymm14,(%rax,%ymm4,4),%ymm2
    3303:	c5 c5 66 e5          	vpcmpgtd %ymm5,%ymm7,%ymm4
    3307:	c5 55 fe f7          	vpaddd %ymm7,%ymm5,%ymm14
    330b:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
    330f:	c5 fe 6f bc 24 00 01 	vmovdqu 0x100(%rsp),%ymm7
    3316:	00 00 
    3318:	c4 c3 4d 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm6,%ymm4
    331e:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 3327 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2637>
    3325:	ff ff 90 
    3328:	c4 c3 4d 4c f5 50    	vpblendvb %ymm5,%ymm13,%ymm6,%ymm6
    332e:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    3333:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 333c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x264c>
    333a:	ff ff c0 
    333d:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
    3342:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3346:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    334b:	c5 c5 fa f6          	vpsubd %ymm6,%ymm7,%ymm6
    334f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    3354:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3358:	c4 e2 0d 90 24 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm4
    335e:	c5 ed db d8          	vpand  %ymm0,%ymm2,%ymm3
    3362:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    3369:	00 00 
    336b:	c4 e2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm5
    3371:	c5 5d db e0          	vpand  %ymm0,%ymm4,%ymm12
    3375:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    3379:	c5 d5 db f0          	vpand  %ymm0,%ymm5,%ymm6
    337d:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    3382:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    3386:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    338a:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    338f:	c4 c2 45 40 fa       	vpmulld %ymm10,%ymm7,%ymm7
    3394:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    3399:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    339e:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    33a3:	c5 9d 72 d4 08       	vpsrld $0x8,%ymm4,%ymm12
    33a8:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    33ad:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
    33b1:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    33b5:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
    33ba:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    33be:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    33c3:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    33c7:	c5 c5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm7
    33cc:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    33d0:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    33d5:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    33db:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    33df:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    33e3:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    33e8:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    33ed:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    33f2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    33f7:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
    33fb:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
    3400:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    3405:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3409:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    340e:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3413:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3418:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    341d:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    3421:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3425:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    3429:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    342d:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3432:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    3437:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
    343c:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3441:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    3445:	c5 c5 72 f1 10       	vpslld $0x10,%ymm1,%ymm7
    344a:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    344e:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3453:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3458:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    345d:	c5 cd fa 64 24 20    	vpsubd 0x20(%rsp),%ymm6,%ymm4
    3463:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    3467:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    346b:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    346f:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3473:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3478:	c5 f5 fa 6c 24 40    	vpsubd 0x40(%rsp),%ymm1,%ymm5
    347e:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    3482:	c5 dd 6b d5          	vpackssdw %ymm5,%ymm4,%ymm2
    3486:	c5 ed d9 54 24 60    	vpsubusw 0x60(%rsp),%ymm2,%ymm2
    348c:	c4 e2 7d 17 d2       	vptest %ymm2,%ymm2
    3491:	0f 84 c9 fc ff ff    	je     3160 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2470>
    3497:	49 8b 42 60          	mov    0x60(%r10),%rax
    349b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    349f:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    34a3:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    34aa:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    34b1:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    34b5:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    34ba:	c4 e2 45 90 2c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm5
    34c0:	49 8b 42 68          	mov    0x68(%r10),%rax
    34c4:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    34c8:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    34cd:	c4 e2 6d 90 3c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm7
    34d3:	49 8b 42 70          	mov    0x70(%r10),%rax
    34d7:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    34dc:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    34e0:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    34e5:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 350d <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x281d>
    34ec:	00 
    34ed:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 3515 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2825>
    34f4:	00 
    34f5:	c4 62 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm8
    34fb:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
    3500:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    3504:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    350b:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    3510:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3514:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    3519:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    351e:	c4 c1 75 72 d0 11    	vpsrld $0x11,%ymm8,%ymm1
    3524:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 354c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x285c>
    352b:	00 
    352c:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    3531:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
    3536:	c4 42 1d 39 d8       	vpminsd %ymm8,%ymm12,%ymm11
    353b:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
    3540:	c4 41 1d 66 e0       	vpcmpgtd %ymm8,%ymm12,%ymm12
    3545:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    3549:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    354d:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    3551:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3556:	c4 e2 5d 90 0c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm1
    355c:	c5 ed fe e3          	vpaddd %ymm3,%ymm2,%ymm4
    3560:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    3567:	00 00 
    3569:	c4 e2 0d 90 14 a0    	vpgatherdd %ymm14,(%rax,%ymm4,4),%ymm2
    356f:	c5 c5 66 e5          	vpcmpgtd %ymm5,%ymm7,%ymm4
    3573:	c5 55 fe f7          	vpaddd %ymm7,%ymm5,%ymm14
    3577:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
    357b:	c5 fe 6f bc 24 00 01 	vmovdqu 0x100(%rsp),%ymm7
    3582:	00 00 
    3584:	c4 c3 4d 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm6,%ymm4
    358a:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 3593 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x28a3>
    3591:	ff ff 90 
    3594:	c4 c3 4d 4c f5 50    	vpblendvb %ymm5,%ymm13,%ymm6,%ymm6
    359a:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    359f:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 35a8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x28b8>
    35a6:	ff ff c0 
    35a9:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
    35ae:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    35b2:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    35b7:	c5 c5 fa f6          	vpsubd %ymm6,%ymm7,%ymm6
    35bb:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    35c0:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    35c4:	c4 e2 0d 90 24 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm4
    35ca:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    35ce:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    35d5:	00 00 
    35d7:	c4 e2 55 90 1c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm3
    35dd:	c5 5d db e0          	vpand  %ymm0,%ymm4,%ymm12
    35e1:	c5 ed db f0          	vpand  %ymm0,%ymm2,%ymm6
    35e5:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    35ec:	c5 e5 db e8          	vpand  %ymm0,%ymm3,%ymm5
    35f0:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    35f5:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    35f9:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    35fd:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    3602:	c4 c2 45 40 fa       	vpmulld %ymm10,%ymm7,%ymm7
    3607:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    360c:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    3611:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    3616:	c5 9d 72 d4 08       	vpsrld $0x8,%ymm4,%ymm12
    361b:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3620:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
    3624:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3628:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    362d:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    3631:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    3636:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    363a:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    363f:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    3643:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    3648:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    364e:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3652:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    3656:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    365b:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    3660:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    3665:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    366a:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
    366e:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
    3673:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    3678:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    367c:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3681:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3686:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    368b:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3690:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3694:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3698:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    369c:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    36a0:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    36a5:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    36aa:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    36af:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    36b4:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    36b9:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    36bd:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    36c1:	c5 bd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm8
    36c6:	c5 d5 72 f1 10       	vpslld $0x10,%ymm1,%ymm5
    36cb:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    36cf:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    36d4:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    36d9:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    36dd:	c4 e2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm5
    36e3:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    36ea:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    36ee:	c4 a2 4d 90 3c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
    36f4:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    36fb:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    3702:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    3706:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    370d:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    3711:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3716:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    371a:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    371e:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3723:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 374b <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a5b>
    372a:	00 
    372b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3730:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3735:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 375d <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a6d>
    373c:	00 
    373d:	c4 62 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm8
    3743:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
    3748:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    374c:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    3753:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    3758:	c4 c1 75 72 d0 11    	vpsrld $0x11,%ymm8,%ymm1
    375e:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3762:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    3767:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 378f <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a9f>
    376e:	00 
    376f:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    3774:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    3779:	c5 55 fe f7          	vpaddd %ymm7,%ymm5,%ymm14
    377d:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
    3782:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
    3787:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    378b:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    378f:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    3793:	c4 e2 6d 90 0c 98    	vpgatherdd %ymm2,(%rax,%ymm3,4),%ymm1
    3799:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    379d:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    37a2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    37a6:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    37ad:	00 00 
    37af:	c5 fd 6f e2          	vmovdqa %ymm2,%ymm4
    37b3:	c4 e2 25 90 14 a0    	vpgatherdd %ymm11,(%rax,%ymm4,4),%ymm2
    37b9:	c5 c5 66 e5          	vpcmpgtd %ymm5,%ymm7,%ymm4
    37bd:	c4 42 1d 39 d8       	vpminsd %ymm8,%ymm12,%ymm11
    37c2:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
    37c6:	c4 41 1d 66 e0       	vpcmpgtd %ymm8,%ymm12,%ymm12
    37cb:	c5 fe 6f bc 24 00 01 	vmovdqu 0x100(%rsp),%ymm7
    37d2:	00 00 
    37d4:	c4 c3 4d 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm6,%ymm4
    37da:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 37e3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2af3>
    37e1:	ff ff 90 
    37e4:	c4 c3 4d 4c f5 50    	vpblendvb %ymm5,%ymm13,%ymm6,%ymm6
    37ea:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    37ef:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 37f8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2b08>
    37f6:	ff ff c0 
    37f9:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
    37fe:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3802:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    3807:	c5 c5 fa f6          	vpsubd %ymm6,%ymm7,%ymm6
    380b:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    3810:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3814:	c4 e2 0d 90 24 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm4
    381a:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    381e:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    3825:	00 00 
    3827:	c4 e2 55 90 1c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm3
    382d:	c5 5d db e0          	vpand  %ymm0,%ymm4,%ymm12
    3831:	c5 ed db f0          	vpand  %ymm0,%ymm2,%ymm6
    3835:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    383c:	c5 e5 db e8          	vpand  %ymm0,%ymm3,%ymm5
    3840:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
    3845:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    3849:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    384d:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    3852:	c4 c2 45 40 fa       	vpmulld %ymm10,%ymm7,%ymm7
    3857:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    385c:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    3861:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    3866:	c5 9d 72 d4 08       	vpsrld $0x8,%ymm4,%ymm12
    386b:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3870:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
    3874:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3878:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    387d:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    3881:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    3886:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    388a:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    388f:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    3893:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    3898:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    389e:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    38a2:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    38a6:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    38ab:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    38b0:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    38b5:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    38ba:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
    38be:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
    38c3:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    38c8:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    38cc:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    38d1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    38d6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    38db:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    38e0:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    38e4:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    38e8:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    38ec:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    38f0:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    38f5:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    38fa:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    38ff:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    3904:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3909:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    390d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3911:	c5 bd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm8
    3916:	c5 d5 72 f1 10       	vpslld $0x10,%ymm1,%ymm5
    391b:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    391f:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3924:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    3929:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    392d:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    3931:	c4 e2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm5
    3937:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    393e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    3942:	c4 a2 4d 90 3c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
    3948:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    394f:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    3953:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3958:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    395c:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3961:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3966:	c4 62 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm8
    396c:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    3973:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    397a:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    3981:	c4 c1 75 72 d0 11    	vpsrld $0x11,%ymm8,%ymm1
    3987:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 39af <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cbf>
    398e:	00 
    398f:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    3993:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3997:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    399b:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    39a0:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    39a5:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 39cd <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cdd>
    39ac:	00 
    39ad:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    39b2:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
    39b7:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 39df <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2cef>
    39be:	00 
    39bf:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    39c4:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    39c9:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
    39ce:	c5 55 fe f7          	vpaddd %ymm7,%ymm5,%ymm14
    39d2:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
    39d7:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    39db:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    39df:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    39e3:	c4 e2 6d 90 0c 98    	vpgatherdd %ymm2,(%rax,%ymm3,4),%ymm1
    39e9:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    39ed:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    39f2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    39f6:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    39fd:	00 00 
    39ff:	c5 fd 6f e2          	vmovdqa %ymm2,%ymm4
    3a03:	c4 e2 25 90 14 a0    	vpgatherdd %ymm11,(%rax,%ymm4,4),%ymm2
    3a09:	c5 c5 66 e5          	vpcmpgtd %ymm5,%ymm7,%ymm4
    3a0d:	c4 42 1d 39 d8       	vpminsd %ymm8,%ymm12,%ymm11
    3a12:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
    3a16:	c4 41 1d 66 e0       	vpcmpgtd %ymm8,%ymm12,%ymm12
    3a1b:	c4 c3 4d 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm6,%ymm4
    3a21:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 3a2a <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d3a>
    3a28:	ff ff 90 
    3a2b:	c4 c3 4d 4c f5 50    	vpblendvb %ymm5,%ymm13,%ymm6,%ymm6
    3a31:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
    3a36:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
    3a3d:	00 00 
    3a3f:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
    3a44:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 3a4d <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d5d>
    3a4b:	ff ff c0 
    3a4e:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3a52:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    3a57:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    3a5b:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    3a60:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3a64:	c4 e2 0d 90 24 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm4
    3a6a:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    3a71:	00 00 
    3a73:	c4 e2 55 90 3c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm7
    3a79:	c5 5d db e0          	vpand  %ymm0,%ymm4,%ymm12
    3a7d:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
    3a81:	c5 c5 db d8          	vpand  %ymm0,%ymm7,%ymm3
    3a85:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    3a8a:	c5 ed db e8          	vpand  %ymm0,%ymm2,%ymm5
    3a8e:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    3a92:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    3a96:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    3a9b:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    3aa0:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    3aa5:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    3aaa:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    3aaf:	c5 9d 72 d4 08       	vpsrld $0x8,%ymm4,%ymm12
    3ab4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3ab9:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
    3abd:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3ac1:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    3ac6:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3aca:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    3acf:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    3ad3:	c5 cd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm6
    3ad8:	c5 3d db c0          	vpand  %ymm0,%ymm8,%ymm8
    3adc:	c5 e5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm3
    3ae1:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    3ae7:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3aeb:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3aef:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    3af4:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    3af9:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    3afe:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3b03:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    3b07:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    3b0c:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    3b11:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3b15:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3b1a:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    3b1f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3b24:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3b29:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3b2d:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3b31:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    3b35:	c5 c5 fa fc          	vpsubd %ymm4,%ymm7,%ymm7
    3b39:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3b3e:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3b43:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    3b48:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    3b4d:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    3b51:	c5 cd 72 f1 10       	vpslld $0x10,%ymm1,%ymm6
    3b56:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    3b5a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3b5f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3b64:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    3b69:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
    3b6d:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3b71:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3b75:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3b7a:	e9 36 f6 ff ff       	jmp    31b5 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24c5>
    3b7f:	90                   	nop
    3b80:	c5 f8 77             	vzeroupper
    3b83:	e8 78 cc ff ff       	call   800 <void jshc_cache_range::(anonymous namespace)::transform<false, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    3b88:	c5 fd 6f 96 c0 00 00 	vmovdqa 0xc0(%rsi),%ymm2
    3b8f:	00 
    3b90:	c5 fd 6f 86 e0 00 00 	vmovdqa 0xe0(%rsi),%ymm0
    3b97:	00 
    3b98:	c5 fd 6f 8e 00 01 00 	vmovdqa 0x100(%rsi),%ymm1
    3b9f:	00 
    3ba0:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 3be8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ef8>
    3ba7:	00 
    3ba8:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3bad:	e9 aa e7 ff ff       	jmp    235c <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x166c>
    3bb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3bb8:	c5 f8 77             	vzeroupper
    3bbb:	e8 40 cc ff ff       	call   800 <void jshc_cache_range::(anonymous namespace)::transform<false, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    3bc0:	c5 fd 6f 16          	vmovdqa (%rsi),%ymm2
    3bc4:	c5 fd 6f 46 20       	vmovdqa 0x20(%rsi),%ymm0
    3bc9:	c5 fd 6f 4e 40       	vmovdqa 0x40(%rsi),%ymm1
    3bce:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 3c16 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f26>
    3bd5:	00 
    3bd6:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    3bda:	e9 da f4 ff ff       	jmp    30b9 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23c9>
    3bdf:	90                   	nop
    3be0:	c5 fd 7f 96 c0 00 00 	vmovdqa %ymm2,0xc0(%rsi)
    3be7:	00 
    3be8:	48 89 fa             	mov    %rdi,%rdx
    3beb:	48 89 e9             	mov    %rbp,%rcx
    3bee:	c5 fd 7f 86 e0 00 00 	vmovdqa %ymm0,0xe0(%rsi)
    3bf5:	00 
    3bf6:	c5 fd 7f 8e 00 01 00 	vmovdqa %ymm1,0x100(%rsi)
    3bfd:	00 
    3bfe:	c5 f8 77             	vzeroupper
    3c01:	e8 fa c3 ff ff       	call   0 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    3c06:	e9 2c e7 ff ff       	jmp    2337 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1647>
    3c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3c10:	84 d2                	test   %dl,%dl
    3c12:	0f 84 90 ee ff ff    	je     2aa8 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1db8>
    3c18:	4d 85 c9             	test   %r9,%r9
    3c1b:	0f 84 5f e7 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    3c21:	b8 00 80 00 00       	mov    $0x8000,%eax
    3c26:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 3c8e <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f9e>
    3c2d:	00 
    3c2e:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 3cb6 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fc6>
    3c35:	00 
    3c36:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    3c3a:	c5 f9 6e e8          	vmovd  %eax,%xmm5
    3c3e:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3c43:	48 c1 ef 03          	shr    $0x3,%rdi
    3c47:	31 ed                	xor    %ebp,%ebp
    3c49:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3c4e:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
    3c55:	00 00 
    3c57:	c4 c1 2d 72 d4 18    	vpsrld $0x18,%ymm12,%ymm10
    3c5d:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    3c64:	00 00 
    3c66:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    3c6d:	00 00 
    3c6f:	e9 ab 00 00 00       	jmp    3d1f <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x302f>
    3c74:	0f 1f 40 00          	nopl   0x0(%rax)
    3c78:	8b 43 24             	mov    0x24(%rbx),%eax
    3c7b:	8b 53 20             	mov    0x20(%rbx),%edx
    3c7e:	c5 c5 fa 84 24 e0 00 	vpsubd 0xe0(%rsp),%ymm7,%ymm0
    3c85:	00 00 
    3c87:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    3c8b:	0f af d0             	imul   %eax,%edx
    3c8e:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    3c92:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3c97:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    3c9c:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    3ca0:	48 8b 03             	mov    (%rbx),%rax
    3ca3:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3ca8:	c4 e2 6d 40 c9       	vpmulld %ymm1,%ymm2,%ymm1
    3cad:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3cb1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3cb5:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
    3cbb:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    3cc0:	c4 c1 75 db d2       	vpand  %ymm10,%ymm1,%ymm2
    3cc5:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    3cca:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3ccf:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    3cd4:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    3cd9:	49 83 c3 18          	add    $0x18,%r11
    3cdd:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    3ce1:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    3ce5:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
    3cec:	00 00 00 
    3cef:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    3cf3:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    3cf9:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    3cfe:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    3d03:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    3d07:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    3d0d:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    3d13:	48 39 ef             	cmp    %rbp,%rdi
    3d16:	0f 84 64 e6 ff ff    	je     2380 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1690>
    3d1c:	48 ff c5             	inc    %rbp
    3d1f:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    3d24:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    3d2a:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    3d2e:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    3d33:	49 8b 02             	mov    (%r10),%rax
    3d36:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    3d3a:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    3d3f:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    3d45:	41 8b 52 50          	mov    0x50(%r10),%edx
    3d49:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    3d4f:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
    3d56:	00 00 00 
    3d59:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3d5e:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    3d63:	c4 c1 7d db fa       	vpand  %ymm10,%ymm0,%ymm7
    3d68:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    3d6f:	00 00 
    3d71:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3d75:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3d79:	c4 e2 4d 90 0c b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm1
    3d7f:	c4 c1 6d db f2       	vpand  %ymm10,%ymm2,%ymm6
    3d84:	49 8b 42 08          	mov    0x8(%r10),%rax
    3d88:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    3d8c:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
    3d93:	00 00 
    3d95:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    3d99:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3d9e:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    3da4:	49 8b 42 10          	mov    0x10(%r10),%rax
    3da8:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
    3daf:	00 00 
    3db1:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    3db5:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    3dba:	c4 e2 6d 90 1c a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm3
    3dc0:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3dc5:	49 8b 42 48          	mov    0x48(%r10),%rax
    3dc9:	c5 dd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm4
    3dce:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3dd3:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
    3dd8:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    3ddd:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3de1:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    3de5:	c5 6d fe f6          	vpaddd %ymm6,%ymm2,%ymm14
    3de9:	c4 c1 6d 72 d4 0f    	vpsrld $0xf,%ymm12,%ymm2
    3def:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3df4:	c4 22 25 90 3c b0    	vpgatherdd %ymm11,(%rax,%ymm14,4),%ymm15
    3dfa:	c5 d5 db ea          	vpand  %ymm2,%ymm5,%ymm5
    3dfe:	c4 41 5d fe de       	vpaddd %ymm14,%ymm4,%ymm11
    3e03:	c5 7e 7f bc 24 40 01 	vmovdqu %ymm15,0x140(%rsp)
    3e0a:	00 00 
    3e0c:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
    3e10:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
    3e14:	c4 22 3d 90 0c 98    	vpgatherdd %ymm8,(%rax,%ymm11,4),%ymm9
    3e1a:	c5 d5 66 f1          	vpcmpgtd %ymm1,%ymm5,%ymm6
    3e1e:	c4 62 75 3d c5       	vpmaxsd %ymm5,%ymm1,%ymm8
    3e23:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
    3e28:	c4 62 3d 3d fb       	vpmaxsd %ymm3,%ymm8,%ymm15
    3e2d:	c5 7e 7f 8c 24 80 01 	vmovdqu %ymm9,0x180(%rsp)
    3e34:	00 00 
    3e36:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    3e3b:	c4 62 75 39 cd       	vpminsd %ymm5,%ymm1,%ymm9
    3e40:	c4 e3 7d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm6
    3e46:	c4 62 35 39 eb       	vpminsd %ymm3,%ymm9,%ymm13
    3e4b:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm6,%ymm6        # 3e54 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3164>
    3e52:	ff ff 40 
    3e55:	c5 35 66 cb          	vpcmpgtd %ymm3,%ymm9,%ymm9
    3e59:	c5 8d fe f6          	vpaddd %ymm6,%ymm14,%ymm6
    3e5d:	c4 e2 3d 90 24 b0    	vpgatherdd %ymm8,(%rax,%ymm6,4),%ymm4
    3e63:	c5 f5 66 f5          	vpcmpgtd %ymm5,%ymm1,%ymm6
    3e67:	c5 7e 7f 9c 24 60 01 	vmovdqu %ymm11,0x160(%rsp)
    3e6e:	00 00 
    3e70:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    3e75:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
    3e7a:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3e7e:	c4 e3 7d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm6
    3e84:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 3e8d <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x319d>
    3e8b:	ff ff 90 
    3e8e:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
    3e92:	c5 2d db 9c 24 40 01 	vpand  0x140(%rsp),%ymm10,%ymm11
    3e99:	00 00 
    3e9b:	c4 62 3d 90 0c b0    	vpgatherdd %ymm8,(%rax,%ymm6,4),%ymm9
    3ea1:	c4 41 05 fe c5       	vpaddd %ymm13,%ymm15,%ymm8
    3ea6:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
    3eab:	c4 c1 4d 72 f3 10    	vpslld $0x10,%ymm11,%ymm6
    3eb1:	c4 c1 65 fa d8       	vpsubd %ymm8,%ymm3,%ymm3
    3eb6:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
    3eba:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
    3ebe:	c5 cd fe b4 24 c0 00 	vpaddd 0xc0(%rsp),%ymm6,%ymm6
    3ec5:	00 00 
    3ec7:	c4 e2 75 40 db       	vpmulld %ymm3,%ymm1,%ymm3
    3ecc:	c5 ad db 8c 24 80 01 	vpand  0x180(%rsp),%ymm10,%ymm1
    3ed3:	00 00 
    3ed5:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    3eda:	49 8b 52 28          	mov    0x28(%r10),%rdx
    3ede:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    3ee3:	c4 c2 5d 40 e7       	vpmulld %ymm15,%ymm4,%ymm4
    3ee8:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    3eed:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    3ef2:	c5 7e 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm13
    3ef9:	00 00 
    3efb:	c5 e5 fe f6          	vpaddd %ymm6,%ymm3,%ymm6
    3eff:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    3f06:	00 00 
    3f08:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3f0c:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
    3f10:	c5 fe 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm1
    3f17:	00 00 
    3f19:	c5 dd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm4
    3f1e:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
    3f25:	00 00 
    3f27:	c4 e2 35 90 34 9a    	vpgatherdd %ymm9,(%rdx,%ymm3,4),%ymm6
    3f2d:	49 8b 52 20          	mov    0x20(%r10),%rdx
    3f31:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    3f36:	c5 cd db f2          	vpand  %ymm2,%ymm6,%ymm6
    3f3a:	c4 62 35 90 04 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm8
    3f40:	49 8b 52 18          	mov    0x18(%r10),%rdx
    3f44:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    3f49:	c5 3d db c2          	vpand  %ymm2,%ymm8,%ymm8
    3f4d:	c4 a2 35 90 0c aa    	vpgatherdd %ymm9,(%rdx,%ymm13,4),%ymm1
    3f53:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    3f58:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    3f5d:	49 8b 52 40          	mov    0x40(%r10),%rdx
    3f61:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
    3f65:	c4 42 75 3d d8       	vpmaxsd %ymm8,%ymm1,%ymm11
    3f6a:	c5 bd 66 e1          	vpcmpgtd %ymm1,%ymm8,%ymm4
    3f6e:	c4 c2 75 39 e8       	vpminsd %ymm8,%ymm1,%ymm5
    3f73:	c4 c1 4d 66 db       	vpcmpgtd %ymm11,%ymm6,%ymm3
    3f78:	c4 62 55 39 fe       	vpminsd %ymm6,%ymm5,%ymm15
    3f7d:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    3f82:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    3f86:	c4 e3 7d 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm0,%ymm4
    3f8c:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm4,%ymm4        # 3f95 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32a5>
    3f93:	ff ff 30 
    3f96:	c5 8d fe e4          	vpaddd %ymm4,%ymm14,%ymm4
    3f9a:	c4 e2 35 90 1c a0    	vpgatherdd %ymm9,(%rax,%ymm4,4),%ymm3
    3fa0:	c4 c1 75 66 e0       	vpcmpgtd %ymm8,%ymm1,%ymm4
    3fa5:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    3faa:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    3faf:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    3fb4:	c4 e3 7d 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm0,%ymm4
    3fba:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm4,%ymm4        # 3fc3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32d3>
    3fc1:	ff ff 50 
    3fc4:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    3fcb:	00 00 
    3fcd:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    3fd1:	c4 62 15 90 0c a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm9
    3fd7:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    3fde:	00 00 
    3fe0:	c5 7e 7f bc 24 c0 01 	vmovdqu %ymm15,0x1c0(%rsp)
    3fe7:	00 00 
    3fe9:	c4 41 25 fe ff       	vpaddd %ymm15,%ymm11,%ymm15
    3fee:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    3ff4:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    3ff9:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    3ffe:	c5 95 72 d4 08       	vpsrld $0x8,%ymm4,%ymm13
    4003:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
    4008:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    400c:	c5 fe 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm4
    4013:	00 00 
    4015:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
    401a:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    401e:	c4 e2 75 40 f6       	vpmulld %ymm6,%ymm1,%ymm6
    4023:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
    4028:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    402d:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4032:	c4 c1 5d 72 f5 10    	vpslld $0x10,%ymm13,%ymm4
    4038:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    403d:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    4042:	c5 dd fe a4 24 c0 00 	vpaddd 0xc0(%rsp),%ymm4,%ymm4
    4049:	00 00 
    404b:	c4 e2 55 40 ac 24 c0 	vpmulld 0x1c0(%rsp),%ymm5,%ymm5
    4052:	01 00 00 
    4055:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    4059:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    405d:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    4064:	00 00 
    4066:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    406a:	c4 e2 05 90 34 9a    	vpgatherdd %ymm15,(%rdx,%ymm3,4),%ymm6
    4070:	49 8b 52 38          	mov    0x38(%r10),%rdx
    4074:	c5 fe 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm1
    407b:	00 00 
    407d:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    4081:	c5 7e 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm13
    4088:	00 00 
    408a:	c5 cd db f2          	vpand  %ymm2,%ymm6,%ymm6
    408e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    4093:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    4098:	c4 62 65 90 04 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm8
    409e:	49 8b 52 30          	mov    0x30(%r10),%rdx
    40a2:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    40a6:	c5 3d db c2          	vpand  %ymm2,%ymm8,%ymm8
    40aa:	c4 a2 65 90 0c aa    	vpgatherdd %ymm3,(%rdx,%ymm13,4),%ymm1
    40b0:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
    40b4:	c4 42 75 3d c8       	vpmaxsd %ymm8,%ymm1,%ymm9
    40b9:	c5 bd 66 e9          	vpcmpgtd %ymm1,%ymm8,%ymm5
    40bd:	c4 42 75 39 e8       	vpminsd %ymm8,%ymm1,%ymm13
    40c2:	c4 c1 4d 66 d9       	vpcmpgtd %ymm9,%ymm6,%ymm3
    40c7:	c4 62 15 39 de       	vpminsd %ymm6,%ymm13,%ymm11
    40cc:	c4 62 35 3d ce       	vpmaxsd %ymm6,%ymm9,%ymm9
    40d1:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
    40d5:	c4 e3 7d 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm0,%ymm5
    40db:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm5,%ymm5        # 40e4 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33f4>
    40e2:	ff ff 30 
    40e5:	c5 8d fe ed          	vpaddd %ymm5,%ymm14,%ymm5
    40e9:	c4 41 35 fe f3       	vpaddd %ymm11,%ymm9,%ymm14
    40ee:	c4 e2 05 90 1c a8    	vpgatherdd %ymm15,(%rax,%ymm5,4),%ymm3
    40f4:	c4 c1 75 66 e8       	vpcmpgtd %ymm8,%ymm1,%ymm5
    40f9:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    40fe:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4103:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    4108:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    410d:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    4112:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    4116:	c4 e3 7d 4c c7 50    	vpblendvb %ymm5,%ymm7,%ymm0,%ymm0
    411c:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    4123:	00 00 
    4125:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 412e <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x343e>
    412c:	ff ff d0 
    412f:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    4133:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    413a:	00 00 
    413c:	c4 62 05 90 2c 80    	vpgatherdd %ymm15,(%rax,%ymm0,4),%ymm13
    4142:	c5 c5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm7
    4147:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
    414e:	00 00 
    4150:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    4156:	c4 c1 45 db fa       	vpand  %ymm10,%ymm7,%ymm7
    415b:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
    4160:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    4165:	c5 d5 72 f7 10       	vpslld $0x10,%ymm7,%ymm5
    416a:	c5 95 fa f3          	vpsubd %ymm3,%ymm13,%ymm6
    416e:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    4173:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    4177:	c5 d5 fe ac 24 c0 00 	vpaddd 0xc0(%rsp),%ymm5,%ymm5
    417e:	00 00 
    4180:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    4187:	00 00 
    4189:	c4 e2 75 40 f6       	vpmulld %ymm6,%ymm1,%ymm6
    418e:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    4193:	c5 dd fa 4c 24 20    	vpsubd 0x20(%rsp),%ymm4,%ymm1
    4199:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    419e:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    41a3:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    41a7:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
    41ab:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    41af:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    41b3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    41b8:	c5 d5 fa 5c 24 40    	vpsubd 0x40(%rsp),%ymm5,%ymm3
    41be:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    41c2:	c5 f5 6b c3          	vpackssdw %ymm3,%ymm1,%ymm0
    41c6:	c5 fd d9 44 24 60    	vpsubusw 0x60(%rsp),%ymm0,%ymm0
    41cc:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
    41d1:	0f 84 a1 fa ff ff    	je     3c78 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f88>
    41d7:	49 8b 42 60          	mov    0x60(%r10),%rax
    41db:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    41df:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    41e6:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    41ed:	c4 e2 4d 90 1c b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm3
    41f3:	49 8b 42 68          	mov    0x68(%r10),%rax
    41f7:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    41fb:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    41ff:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    4204:	c4 e2 4d 90 0c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm1
    420a:	49 8b 42 70          	mov    0x70(%r10),%rax
    420e:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    4212:	c5 fd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm0
    4217:	c4 e2 5d 90 34 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm6
    421d:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
    4222:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    4226:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    422d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    4232:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    4237:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    423b:	c4 e2 55 40 ec       	vpmulld %ymm4,%ymm5,%ymm5
    4240:	c5 c5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm7
    4245:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
    4249:	c5 cd db f2          	vpand  %ymm2,%ymm6,%ymm6
    424d:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    4251:	c5 f5 db ea          	vpand  %ymm2,%ymm1,%ymm5
    4255:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    4259:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    425d:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4262:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    4266:	c4 62 45 90 3c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm15
    426c:	c5 f5 fe f8          	vpaddd %ymm0,%ymm1,%ymm7
    4270:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    4274:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    427b:	00 00 
    427d:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    4282:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    4287:	c4 62 75 90 34 b8    	vpgatherdd %ymm1,(%rax,%ymm7,4),%ymm14
    428d:	c5 d5 66 cb          	vpcmpgtd %ymm3,%ymm5,%ymm1
    4291:	c4 62 25 39 ce       	vpminsd %ymm6,%ymm11,%ymm9
    4296:	c5 7e 7f b4 24 00 01 	vmovdqu %ymm14,0x100(%rsp)
    429d:	00 00 
    429f:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    42a4:	c5 65 fe f5          	vpaddd %ymm5,%ymm3,%ymm14
    42a8:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    42ad:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    42b1:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    42b5:	c5 fe 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm5
    42bc:	00 00 
    42be:	c4 c3 5d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm4,%ymm1
    42c4:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm1,%ymm1        # 42cd <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x35dd>
    42cb:	ff ff 70 
    42ce:	c4 c1 3d fe f9       	vpaddd %ymm9,%ymm8,%ymm7
    42d3:	c4 c3 5d 4c e5 30    	vpblendvb %ymm3,%ymm13,%ymm4,%ymm4
    42d9:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    42dd:	c5 7e 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm13
    42e4:	00 00 
    42e6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    42ea:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm4,%ymm4        # 42f3 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3603>
    42f1:	ff ff b0 
    42f4:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    42f9:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    42fe:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    4302:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    4306:	c4 e2 0d 90 0c 80    	vpgatherdd %ymm14,(%rax,%ymm0,4),%ymm1
    430c:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    4313:	00 00 
    4315:	c4 e2 55 90 04 a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm0
    431b:	c4 41 75 db da       	vpand  %ymm10,%ymm1,%ymm11
    4320:	c4 c1 2d db ef       	vpand  %ymm15,%ymm10,%ymm5
    4325:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    432c:	c4 c1 7d db da       	vpand  %ymm10,%ymm0,%ymm3
    4331:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    4336:	c4 c1 2d db e5       	vpand  %ymm13,%ymm10,%ymm4
    433b:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    433f:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    4343:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    4348:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    434d:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    4352:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    4357:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    435c:	c5 a5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm11
    4361:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4366:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
    436b:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    4370:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    4374:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    4378:	c4 c1 4d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm6
    437e:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    4382:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    4387:	c4 c1 4d db f2       	vpand  %ymm10,%ymm6,%ymm6
    438c:	c4 c1 65 72 d5 08    	vpsrld $0x8,%ymm13,%ymm3
    4392:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    4397:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    439c:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    43a1:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
    43a5:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    43aa:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    43af:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    43b4:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    43b8:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    43bd:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    43c2:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    43c7:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    43cc:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    43d1:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    43d5:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    43da:	c5 7e 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm13
    43e1:	00 00 
    43e3:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    43e7:	c4 c1 55 72 d7 10    	vpsrld $0x10,%ymm15,%ymm5
    43ed:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    43f2:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    43f8:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    43fd:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    4402:	c5 a5 72 f5 10       	vpslld $0x10,%ymm5,%ymm11
    4407:	c5 f5 fa ed          	vpsubd %ymm5,%ymm1,%ymm5
    440b:	c5 e5 fa d8          	vpsubd %ymm0,%ymm3,%ymm3
    440f:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    4413:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    4418:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    441d:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    4422:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    4427:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
    442c:	c5 e5 fe ed          	vpaddd %ymm5,%ymm3,%ymm5
    4430:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    4434:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    4439:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    443d:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    4443:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    444a:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    444e:	c4 e2 55 90 24 b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm4
    4454:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    445b:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    4462:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    4466:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    446d:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    4472:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
    4476:	c5 79 6e d9          	vmovd  %ecx,%xmm11
    447a:	c5 79 6e c2          	vmovd  %edx,%xmm8
    447e:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4482:	c4 e2 4d 90 2c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm5
    4488:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    448d:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    4492:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    4499:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    449e:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    44a3:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
    44a7:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    44ac:	c5 cd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm6
    44b1:	c5 d5 db ea          	vpand  %ymm2,%ymm5,%ymm5
    44b5:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    44b9:	c4 e2 65 3d fc       	vpmaxsd %ymm4,%ymm3,%ymm7
    44be:	c4 62 65 39 ec       	vpminsd %ymm4,%ymm3,%ymm13
    44c3:	c4 62 15 39 cd       	vpminsd %ymm5,%ymm13,%ymm9
    44c8:	c5 15 66 ed          	vpcmpgtd %ymm5,%ymm13,%ymm13
    44cc:	49 8d 8a 20 01 00 00 	lea    0x120(%r10),%rcx
    44d3:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    44d7:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    44db:	c4 e2 6d 90 04 88    	vpgatherdd %ymm2,(%rax,%ymm1,4),%ymm0
    44e1:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    44e5:	48 8d 56 60          	lea    0x60(%rsi),%rdx
    44e9:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    44ee:	c5 ed fe f1          	vpaddd %ymm1,%ymm2,%ymm6
    44f2:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    44f6:	c5 fe 7f b4 24 00 01 	vmovdqu %ymm6,0x100(%rsp)
    44fd:	00 00 
    44ff:	c4 62 6d 90 34 b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm14
    4505:	c5 dd 66 d3          	vpcmpgtd %ymm3,%ymm4,%ymm2
    4509:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    450d:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
    4512:	c5 65 fe f4          	vpaddd %ymm4,%ymm3,%ymm14
    4516:	c5 e5 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm3
    451a:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    451f:	c5 fe 6f a4 24 00 01 	vmovdqu 0x100(%rsp),%ymm4
    4526:	00 00 
    4528:	c4 c3 3d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm8,%ymm2
    452e:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm2,%ymm2        # 4537 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3847>
    4535:	ff ff 60 
    4538:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    453d:	c4 43 3d 4c c3 30    	vpblendvb %ymm3,%ymm11,%ymm8,%ymm8
    4543:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    4547:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    454b:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm8,%ymm8        # 4554 <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3864>
    4552:	ff ff d0 
    4555:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    455a:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    455f:	c4 41 5d fa c0       	vpsubd %ymm8,%ymm4,%ymm8
    4564:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    4568:	c4 e2 0d 90 14 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm2
    456e:	c4 a2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm1
    4574:	c4 41 6d db da       	vpand  %ymm10,%ymm2,%ymm11
    4579:	c4 c1 7d db ea       	vpand  %ymm10,%ymm0,%ymm5
    457e:	c4 c1 75 db da       	vpand  %ymm10,%ymm1,%ymm3
    4583:	c4 c1 2d db e7       	vpand  %ymm15,%ymm10,%ymm4
    4588:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    458d:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
    4594:	00 00 
    4596:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    459b:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    459f:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    45a3:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    45a8:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    45ad:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    45b2:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    45b7:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    45bc:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
    45c1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    45c6:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
    45cb:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
    45d0:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    45d5:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    45d9:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    45de:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    45e2:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    45e7:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
    45ec:	c4 c1 65 72 d6 08    	vpsrld $0x8,%ymm14,%ymm3
    45f2:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    45f8:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    45fd:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    4602:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    4607:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    460c:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    4611:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4616:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    461a:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    461f:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    4624:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    4629:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
    462e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4633:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    4638:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    463d:	c5 fd 7f 66 60       	vmovdqa %ymm4,0x60(%rsi)
    4642:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    4647:	c5 bd 72 f0 10       	vpslld $0x10,%ymm0,%ymm8
    464c:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    4650:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    4655:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    465a:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    465f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4663:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
    4669:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    466e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4673:	c5 d5 fa e9          	vpsubd %ymm1,%ymm5,%ymm5
    4677:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    467b:	c5 fd 7f 9e 80 00 00 	vmovdqa %ymm3,0x80(%rsi)
    4682:	00 
    4683:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    4688:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    468d:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    4691:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    4696:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    469a:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    469f:	c5 fd 7f ae a0 00 00 	vmovdqa %ymm5,0xa0(%rsi)
    46a6:	00 
    46a7:	c5 f8 77             	vzeroupper
    46aa:	e8 51 b9 ff ff       	call   0 <void jshc_cache_range::(anonymous namespace)::transform<true, false>(jshc_cache_range::View const&, jshc_cache_range::(anonymous namespace)::Rgb&)>
    46af:	c5 fd 6f 86 80 00 00 	vmovdqa 0x80(%rsi),%ymm0
    46b6:	00 
    46b7:	c5 fd 6f 8e a0 00 00 	vmovdqa 0xa0(%rsi),%ymm1
    46be:	00 
    46bf:	c5 fd 6f 56 60       	vmovdqa 0x60(%rsi),%ymm2
    46c4:	c5 7d 6f 15 40 00 00 	vmovdqa 0x40(%rip),%ymm10        # 470c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2c>
    46cb:	00 
    46cc:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    46d1:	e9 f9 f5 ff ff       	jmp    3ccf <jshc_cache_range::avx2_chain_cached(jshc_cache_range::View const*, jshc_cache_range::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fdf>
    46d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    46dd:	00 00 00 

00000000000046e0 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    46e0:	57                   	push   %rdi
    46e1:	56                   	push   %rsi
    46e2:	53                   	push   %rbx
    46e3:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
    46ea:	c5 f8 29 b4 24 20 02 	vmovaps %xmm6,0x220(%rsp)
    46f1:	00 00 
    46f3:	c5 f8 29 bc 24 30 02 	vmovaps %xmm7,0x230(%rsp)
    46fa:	00 00 
    46fc:	c5 78 29 84 24 40 02 	vmovaps %xmm8,0x240(%rsp)
    4703:	00 00 
    4705:	c5 78 29 8c 24 50 02 	vmovaps %xmm9,0x250(%rsp)
    470c:	00 00 
    470e:	c5 78 29 94 24 60 02 	vmovaps %xmm10,0x260(%rsp)
    4715:	00 00 
    4717:	c5 78 29 9c 24 70 02 	vmovaps %xmm11,0x270(%rsp)
    471e:	00 00 
    4720:	c5 78 29 a4 24 80 02 	vmovaps %xmm12,0x280(%rsp)
    4727:	00 00 
    4729:	c5 78 29 ac 24 90 02 	vmovaps %xmm13,0x290(%rsp)
    4730:	00 00 
    4732:	c5 78 29 b4 24 a0 02 	vmovaps %xmm14,0x2a0(%rsp)
    4739:	00 00 
    473b:	c5 78 29 bc 24 b0 02 	vmovaps %xmm15,0x2b0(%rsp)
    4742:	00 00 
    4744:	49 89 d3             	mov    %rdx,%r11
    4747:	48 83 fa 04          	cmp    $0x4,%rdx
    474b:	0f 84 f8 08 00 00    	je     5049 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x969>
    4751:	4d 85 c9             	test   %r9,%r9
    4754:	0f 84 7a 08 00 00    	je     4fd4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    475a:	49 ff c9             	dec    %r9
    475d:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 47c5 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe5>
    4764:	00 
    4765:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
    4769:	49 c1 e9 03          	shr    $0x3,%r9
    476d:	49 c1 e2 05          	shl    $0x5,%r10
    4771:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    4775:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    477c:	00 00 
    477e:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 4806 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x126>
    4785:	00 
    4786:	49 01 ca             	add    %rcx,%r10
    4789:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    478e:	b8 00 80 00 00       	mov    $0x8000,%eax
    4793:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    4797:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    479e:	00 00 
    47a0:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    47a4:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    47a9:	c5 95 72 d6 18       	vpsrld $0x18,%ymm6,%ymm13
    47ae:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    47b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    47b8:	c4 c1 7a 6f 10       	vmovdqu (%r8),%xmm2
    47bd:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    47c3:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
    47c9:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
    47cf:	c4 e2 6d 00 94 24 e0 	vpshufb 0x1e0(%rsp),%ymm2,%ymm2
    47d6:	01 00 00 
    47d9:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
    47de:	c4 c1 6d db c5       	vpand  %ymm13,%ymm2,%ymm0
    47e3:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    47e8:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    47ed:	4d 85 db             	test   %r11,%r11
    47f0:	0f 84 4a 08 00 00    	je     5040 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x960>
    47f6:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    47fd:	00 00 
    47ff:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4803:	48 89 c8             	mov    %rcx,%rax
    4806:	c5 fd 6f cc          	vmovdqa %ymm4,%ymm1
    480a:	e9 22 02 00 00       	jmp    4a31 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    480f:	90                   	nop
    4810:	c4 c1 5d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm4
    4816:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
    481b:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    481f:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
    4823:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    4827:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    482c:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
    4832:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    4837:	c5 dd fe ef          	vpaddd %ymm7,%ymm4,%ymm5
    483b:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4842:	00 00 
    4844:	c4 c1 55 72 e1 10    	vpsrad $0x10,%ymm9,%ymm5
    484a:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    4850:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4854:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
    485a:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
    4860:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    4864:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
    4868:	c5 b5 fe db          	vpaddd %ymm3,%ymm9,%ymm3
    486c:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    4870:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
    4875:	c5 75 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm8
    4879:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    4880:	00 00 
    4882:	c4 c1 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm2
    4887:	c4 62 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm10
    488c:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
    4891:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
    4895:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
    489a:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    489f:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
    48a3:	c4 63 1d 4c 44 24 60 	vpblendvb %ymm8,0x60(%rsp),%ymm12,%ymm8
    48aa:	80 
    48ab:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    48b1:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm8,%ymm8        # 48ba <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1da>
    48b8:	ff ff 20 
    48bb:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
    48c1:	c4 e3 1d 4c 4c 24 60 	vpblendvb %ymm1,0x60(%rsp),%ymm12,%ymm1
    48c8:	10 
    48c9:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm1,%ymm1        # 48d2 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f2>
    48d0:	ff ff a0 
    48d3:	c4 a2 0d 90 14 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm2
    48d9:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    48dd:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    48e1:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
    48e7:	c5 fe 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm1
    48ee:	00 00 
    48f0:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    48f5:	c4 62 5d 3d c7       	vpmaxsd %ymm7,%ymm4,%ymm8
    48fa:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    48ff:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4904:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4908:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    490d:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    4912:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    4916:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
    491a:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
    4921:	00 00 
    4923:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
    4927:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    492c:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
    4932:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4937:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    493c:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
    4941:	c4 62 35 39 d5       	vpminsd %ymm5,%ymm9,%ymm10
    4946:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    494a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    494e:	c5 c5 66 dc          	vpcmpgtd %ymm4,%ymm7,%ymm3
    4952:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    4959:	00 00 
    495b:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
    495f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    4966:	00 00 
    4968:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    496c:	c4 c1 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm2
    4971:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
    4977:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    497d:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4981:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
    4986:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 498f <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2af>
    498d:	ff ff 90 
    4990:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4995:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    499a:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm3        # 49a3 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2c3>
    49a1:	ff ff 20 
    49a4:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    49a8:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
    49ae:	c4 e2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm2
    49b4:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    49ba:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    49bf:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    49c3:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    49c8:	c4 e2 1d 90 1c a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm3
    49ce:	c4 c1 45 fa e2       	vpsubd %ymm10,%ymm7,%ymm4
    49d3:	c5 fe 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm7
    49da:	00 00 
    49dc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    49e1:	c5 dd fe ed          	vpaddd %ymm5,%ymm4,%ymm5
    49e5:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    49ea:	c5 e5 fa e2          	vpsubd %ymm2,%ymm3,%ymm4
    49ee:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
    49f2:	c4 e2 55 40 e4       	vpmulld %ymm4,%ymm5,%ymm4
    49f7:	c5 ed fa 94 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm2
    49fe:	00 00 
    4a00:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    4a05:	48 83 c0 60          	add    $0x60,%rax
    4a09:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    4a0e:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    4a12:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
    4a19:	00 00 
    4a1b:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    4a1f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4a24:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4a28:	49 39 c2             	cmp    %rax,%r10
    4a2b:	0f 84 46 05 00 00    	je     4f77 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x897>
    4a31:	8b 58 54             	mov    0x54(%rax),%ebx
    4a34:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4a38:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    4a3f:	00 00 
    4a41:	c5 fd 6f c6          	vmovdqa %ymm6,%ymm0
    4a45:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
    4a4c:	00 00 
    4a4e:	8b 70 50             	mov    0x50(%rax),%esi
    4a51:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4a55:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    4a59:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
    4a5d:	c4 e2 7d 90 14 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm2
    4a63:	48 8b 10             	mov    (%rax),%rdx
    4a66:	48 8b 78 10          	mov    0x10(%rax),%rdi
    4a6a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    4a6f:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4a76:	00 00 
    4a78:	c5 79 6e e6          	vmovd  %esi,%xmm12
    4a7c:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    4a81:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    4a87:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    4a8c:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    4a91:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    4a95:	c4 e2 65 90 04 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm0
    4a9b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4aa0:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
    4aa7:	00 00 
    4aa9:	48 8b 50 48          	mov    0x48(%rax),%rdx
    4aad:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    4ab2:	c4 a2 2d 90 1c 9f    	vpgatherdd %ymm10,(%rdi,%ymm11,4),%ymm3
    4ab8:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 4ae0 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x400>
    4abf:	00 
    4ac0:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    4ac5:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
    4aca:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 4af2 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x412>
    4ad1:	00 
    4ad2:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4afa <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x41a>
    4ad9:	00 
    4ada:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
    4ade:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
    4ae2:	c4 62 6d 39 c0       	vpminsd %ymm0,%ymm2,%ymm8
    4ae7:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4aeb:	c5 f5 fe e5          	vpaddd %ymm5,%ymm1,%ymm4
    4aef:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4af3:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    4af9:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    4aff:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
    4b04:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4b09:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    4b10:	00 00 
    4b12:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4b17:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4b1c:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
    4b23:	00 00 
    4b25:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4b2a:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    4b2f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4b34:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    4b3b:	00 00 
    4b3d:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4b42:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4b47:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
    4b4c:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    4b53:	00 00 
    4b55:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    4b59:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4b5e:	c5 75 fe dc          	vpaddd %ymm4,%ymm1,%ymm11
    4b62:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
    4b66:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4b6a:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
    4b70:	c4 62 3d 39 c3       	vpminsd %ymm3,%ymm8,%ymm8
    4b75:	c4 22 75 90 14 9a    	vpgatherdd %ymm1,(%rdx,%ymm11,4),%ymm10
    4b7b:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
    4b7f:	c4 e3 1d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm12,%ymm1
    4b85:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 4b8e <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ae>
    4b8c:	ff ff 40 
    4b8f:	c5 ed 66 e0          	vpcmpgtd %ymm0,%ymm2,%ymm4
    4b93:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    4b97:	c4 41 2d db dd       	vpand  %ymm13,%ymm10,%ymm11
    4b9c:	c4 e2 35 90 3c 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm7
    4ba2:	c5 0d fe 34 24       	vpaddd (%rsp),%ymm14,%ymm14
    4ba7:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    4bab:	c5 95 db cf          	vpand  %ymm7,%ymm13,%ymm1
    4baf:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    4bb6:	00 00 
    4bb8:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    4bbe:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    4bc2:	c4 c2 25 40 f8       	vpmulld %ymm8,%ymm11,%ymm7
    4bc7:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    4bcb:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
    4bd2:	00 00 
    4bd4:	c4 e2 6d 3d f8       	vpmaxsd %ymm0,%ymm2,%ymm7
    4bd9:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
    4bdd:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    4be2:	c5 3d fe ff          	vpaddd %ymm7,%ymm8,%ymm15
    4be6:	c4 41 65 fa ff       	vpsubd %ymm15,%ymm3,%ymm15
    4beb:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 4bf4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
    4bf2:	ff ff 90 
    4bf5:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    4bfb:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    4c01:	c5 6d fe d8          	vpaddd %ymm0,%ymm2,%ymm11
    4c05:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    4c0a:	c4 41 05 fe db       	vpaddd %ymm11,%ymm15,%ymm11
    4c0f:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    4c13:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    4c17:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4c1c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    4c21:	c5 dd fe a4 24 80 00 	vpaddd 0x80(%rsp),%ymm4,%ymm4
    4c28:	00 00 
    4c2a:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4c2f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4c33:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
    4c38:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
    4c3e:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    4c44:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
    4c4b:	00 00 
    4c4d:	c4 41 75 db fd       	vpand  %ymm13,%ymm1,%ymm15
    4c52:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    4c59:	00 00 
    4c5b:	c4 c1 2d db ed       	vpand  %ymm13,%ymm10,%ymm5
    4c60:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
    4c67:	00 00 
    4c69:	0f 85 49 02 00 00    	jne    4eb8 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d8>
    4c6f:	48 8b 58 28          	mov    0x28(%rax),%rbx
    4c73:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
    4c7a:	00 00 
    4c7c:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4c80:	48 8b 78 18          	mov    0x18(%rax),%rdi
    4c84:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
    4c88:	c4 62 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm9
    4c8e:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    4c95:	00 00 
    4c97:	48 8b 58 20          	mov    0x20(%rax),%rbx
    4c9b:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4c9f:	c4 e2 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm1
    4ca5:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
    4cac:	00 00 
    4cae:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4cb2:	c4 62 45 90 04 af    	vpgatherdd %ymm7,(%rdi,%ymm5,4),%ymm8
    4cb8:	0f 85 52 fb ff ff    	jne    4810 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
    4cbe:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # 4ce6 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x606>
    4cc5:	00 
    4cc6:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 4cee <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x60e>
    4ccd:	00 
    4cce:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4cd2:	c5 b5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm9,%ymm3        # 4cfa <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x61a>
    4cd9:	00 
    4cda:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
    4ce0:	c4 e2 3d 3d e9       	vpmaxsd %ymm1,%ymm8,%ymm5
    4ce5:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
    4cea:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
    4cf0:	c4 e2 3d 39 e1       	vpminsd %ymm1,%ymm8,%ymm4
    4cf5:	c5 e5 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm0
    4cf9:	c4 e2 5d 39 fb       	vpminsd %ymm3,%ymm4,%ymm7
    4cfe:	c4 e2 55 3d eb       	vpmaxsd %ymm3,%ymm5,%ymm5
    4d03:	48 8b 58 40          	mov    0x40(%rax),%rbx
    4d07:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
    4d0b:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4d11:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 4d1a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
    4d18:	ff ff 00 
    4d1b:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    4d20:	c4 e2 0d 90 04 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm0
    4d26:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
    4d2a:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4d2e:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    4d32:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    4d37:	c5 d5 fe cf          	vpaddd %ymm7,%ymm5,%ymm1
    4d3b:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    4d3f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    4d44:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4d48:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4d4e:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    4d52:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm2,%ymm2        # 4d5b <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x67b>
    4d59:	ff ff 40 
    4d5c:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    4d62:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    4d66:	c4 e2 0d 90 24 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm4
    4d6c:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4d70:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    4d75:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    4d7a:	c5 05 fa fc          	vpsubd %ymm4,%ymm15,%ymm15
    4d7e:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
    4d82:	c4 62 05 40 ff       	vpmulld %ymm7,%ymm15,%ymm15
    4d87:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    4d8e:	00 00 
    4d90:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    4d95:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
    4d9c:	00 00 
    4d9e:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    4da5:	00 00 
    4da7:	c4 e2 65 90 24 bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm4
    4dad:	48 8b 58 38          	mov    0x38(%rax),%rbx
    4db1:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
    4db8:	00 00 
    4dba:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4dbe:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    4dc3:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 4deb <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70b>
    4dca:	00 
    4dcb:	c4 e2 65 90 2c bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm5
    4dd1:	48 8b 58 30          	mov    0x30(%rax),%rbx
    4dd5:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4dd9:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 4e01 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x721>
    4de0:	00 
    4de1:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    4de6:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    4deb:	c4 e2 45 90 1c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm3
    4df1:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4e19 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x739>
    4df8:	00 
    4df9:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
    4e00:	00 00 
    4e02:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    4e07:	c5 d5 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm7
    4e0b:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
    4e10:	c4 c1 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm2
    4e15:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
    4e1a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4e1e:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
    4e23:	c4 c3 1d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm12,%ymm7
    4e29:	c4 62 35 39 d4       	vpminsd %ymm4,%ymm9,%ymm10
    4e2e:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4e32:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm7,%ymm7        # 4e3b <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x75b>
    4e39:	ff ff 20 
    4e3c:	c5 35 66 cc          	vpcmpgtd %ymm4,%ymm9,%ymm9
    4e40:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
    4e45:	c4 e2 0d 90 14 ba    	vpgatherdd %ymm14,(%rdx,%ymm7,4),%ymm2
    4e4b:	c5 e5 66 fd          	vpcmpgtd %ymm5,%ymm3,%ymm7
    4e4f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4e53:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4e58:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4e5d:	c4 c3 1d 4c ff 70    	vpblendvb %ymm7,%ymm15,%ymm12,%ymm7
    4e63:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # 4e6c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x78c>
    4e6a:	ff ff 90 
    4e6d:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    4e73:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    4e77:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4e7b:	c4 62 1d 90 0c ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm9
    4e81:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4e86:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    4e8c:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    4e90:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    4e95:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    4e99:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
    4e9d:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    4ea2:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    4ea9:	00 00 
    4eab:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    4eb0:	e9 42 fb ff ff       	jmp    49f7 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x317>
    4eb5:	0f 1f 00             	nopl   (%rax)
    4eb8:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    4ebf:	00 00 
    4ec1:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
    4ec7:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    4ecd:	48 83 c0 60          	add    $0x60,%rax
    4ed1:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4ed6:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    4edb:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
    4ee0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4ee5:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4eea:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    4eef:	c5 85 fa c2          	vpsubd %ymm2,%ymm15,%ymm0
    4ef3:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    4ef7:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    4efc:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    4f01:	c5 f5 fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm1,%ymm1
    4f08:	00 00 
    4f0a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4f0f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4f13:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    4f1a:	00 00 
    4f1c:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    4f20:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    4f25:	c5 35 fa 8c 24 40 01 	vpsubd 0x140(%rsp),%ymm9,%ymm9
    4f2c:	00 00 
    4f2e:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4f33:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
    4f3a:	00 00 
    4f3c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    4f41:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
    4f46:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4f4a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4f4f:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4f53:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4f57:	c5 35 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm9,%ymm9
    4f5e:	00 00 
    4f60:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    4f65:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4f6a:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4f6e:	49 39 c2             	cmp    %rax,%r10
    4f71:	0f 85 ba fa ff ff    	jne    4a31 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    4f77:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
    4f7b:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
    4f82:	00 00 
    4f84:	c5 dd 72 f7 08       	vpslld $0x8,%ymm7,%ymm4
    4f89:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    4f8e:	49 83 c0 18          	add    $0x18,%r8
    4f92:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
    4f96:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    4f9a:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    4fa1:	02 00 00 
    4fa4:	c5 f9 6f e0          	vmovdqa %xmm0,%xmm4
    4fa8:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    4fae:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
    4fb3:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    4fb8:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
    4fbc:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    4fc2:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    4fc8:	4d 39 c1             	cmp    %r8,%r9
    4fcb:	0f 85 e7 f7 ff ff    	jne    47b8 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
    4fd1:	c5 f8 77             	vzeroupper
    4fd4:	c5 f8 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm6
    4fdb:	00 00 
    4fdd:	c5 f8 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm7
    4fe4:	00 00 
    4fe6:	c5 78 28 84 24 40 02 	vmovaps 0x240(%rsp),%xmm8
    4fed:	00 00 
    4fef:	c5 78 28 8c 24 50 02 	vmovaps 0x250(%rsp),%xmm9
    4ff6:	00 00 
    4ff8:	c5 78 28 94 24 60 02 	vmovaps 0x260(%rsp),%xmm10
    4fff:	00 00 
    5001:	c5 78 28 9c 24 70 02 	vmovaps 0x270(%rsp),%xmm11
    5008:	00 00 
    500a:	c5 78 28 a4 24 80 02 	vmovaps 0x280(%rsp),%xmm12
    5011:	00 00 
    5013:	c5 78 28 ac 24 90 02 	vmovaps 0x290(%rsp),%xmm13
    501a:	00 00 
    501c:	c5 78 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm14
    5023:	00 00 
    5025:	c5 78 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm15
    502c:	00 00 
    502e:	48 81 c4 c0 02 00 00 	add    $0x2c0,%rsp
    5035:	5b                   	pop    %rbx
    5036:	5e                   	pop    %rsi
    5037:	5f                   	pop    %rdi
    5038:	c3                   	ret
    5039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5040:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
    5044:	e9 3b ff ff ff       	jmp    4f84 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8a4>
    5049:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    504d:	0f 85 fe f6 ff ff    	jne    4751 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    5053:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    505a:	0f 84 f1 f6 ff ff    	je     4751 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    5060:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    5067:	0f 84 e4 f6 ff ff    	je     4751 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    506d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    5074:	0f 84 d7 f6 ff ff    	je     4751 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    507a:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    507e:	0f 85 ff 0b 00 00    	jne    5c83 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15a3>
    5084:	4d 85 c9             	test   %r9,%r9
    5087:	0f 84 47 ff ff ff    	je     4fd4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    508d:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 50f5 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa15>
    5094:	00 
    5095:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    5099:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    509e:	48 c1 e8 03          	shr    $0x3,%rax
    50a2:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
    50a8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50ac:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    50b3:	00 00 
    50b5:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 513d <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa5d>
    50bc:	00 
    50bd:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    50c2:	b8 00 80 00 00       	mov    $0x8000,%eax
    50c7:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    50ce:	00 00 
    50d0:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    50d4:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    50d9:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    50de:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    50e3:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    50e9:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    50ed:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    50f2:	48 8b 01             	mov    (%rcx),%rax
    50f5:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    50f9:	49 83 c0 18          	add    $0x18,%r8
    50fd:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    5103:	8b 51 50             	mov    0x50(%rcx),%edx
    5106:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    510c:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    5111:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    5118:	01 00 00 
    511b:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    511f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    5124:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    5129:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    512e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    5133:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    5139:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
    513e:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    5143:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5148:	c4 e2 65 90 04 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm0
    514e:	48 8b 41 08          	mov    0x8(%rcx),%rax
    5152:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    5158:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    515c:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
    5162:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5166:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    516a:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    516f:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5197 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xab7>
    5176:	00 
    5177:	c4 a2 65 90 24 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm4
    517d:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    5182:	48 8b 41 48          	mov    0x48(%rcx),%rax
    5186:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 51ae <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xace>
    518d:	00 
    518e:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    5193:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5198:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    519d:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 51c5 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xae5>
    51a4:	00 
    51a5:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    51aa:	c4 62 3d 3d f4       	vpmaxsd %ymm4,%ymm8,%ymm14
    51af:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    51b3:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    51b7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    51bb:	c4 62 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm12
    51c1:	c5 f9 6e da          	vmovd  %edx,%xmm3
    51c5:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    51ca:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    51ce:	c4 e2 2d 90 2c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm5
    51d4:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    51d9:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    51e0:	00 00 
    51e2:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    51e7:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    51ee:	00 00 
    51f0:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    51f4:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    51f9:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    51fd:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    5203:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm5,%ymm5        # 520c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb2c>
    520a:	ff ff a0 
    520d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5212:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    5216:	c4 62 2d 90 34 a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm14
    521c:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    5220:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5224:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    522a:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm5,%ymm5        # 5233 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb53>
    5231:	ff ff 80 
    5234:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5239:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    523d:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    5243:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    5249:	c4 c1 0d db ed       	vpand  %ymm13,%ymm14,%ymm5
    524e:	c5 35 fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm14
    5255:	00 00 
    5257:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    525c:	c5 15 db 64 24 60    	vpand  0x60(%rsp),%ymm13,%ymm12
    5262:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    5266:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    526b:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5271:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    5275:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    5279:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
    527f:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    5284:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    5289:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    528e:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    5295:	00 00 00 
    5298:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    529d:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    52a1:	c5 95 db a4 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm4
    52a8:	00 00 
    52aa:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    52af:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    52b4:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    52b9:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    52bd:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    52c1:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    52c7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    52cc:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    52d3:	00 00 
    52d5:	c4 a2 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm5
    52db:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    52df:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5307 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc27>
    52e6:	00 
    52e7:	c4 62 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm8
    52ed:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    52f1:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    52f6:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 531e <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc3e>
    52fd:	00 
    52fe:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    5304:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 532c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc4c>
    530b:	00 
    530c:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    5311:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    5315:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    5319:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    531e:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    5323:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    5329:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm4,%ymm4        # 5332 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc52>
    5330:	ff ff a0 
    5333:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
    5338:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    533f:	00 00 
    5341:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    5345:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    5349:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    534e:	c4 62 2d 90 24 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm12
    5354:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    5359:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    535e:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    5363:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5368:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    536e:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm4,%ymm4        # 5377 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc97>
    5375:	ff ff 60 
    5378:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    537c:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    5382:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    5388:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    538f:	00 00 
    5391:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    5396:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    539b:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    53a1:	c4 41 5d db f5       	vpand  %ymm13,%ymm4,%ymm14
    53a6:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    53ac:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    53b3:	00 00 
    53b5:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    53bc:	00 00 
    53be:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    53c3:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
    53c8:	c4 41 1d fe e1       	vpaddd %ymm9,%ymm12,%ymm12
    53cd:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    53d3:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    53d8:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    53dc:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    53e0:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    53e5:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    53ea:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    53ef:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    53f4:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    53f8:	c5 95 db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm13,%ymm0
    53ff:	00 00 
    5401:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    5405:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    540b:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    5410:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    5417:	00 00 00 
    541a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    541e:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    5424:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    5428:	c4 a2 3d 90 04 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm0
    542e:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    5432:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5437:	c5 9d 72 d5 10       	vpsrld $0x10,%ymm5,%ymm12
    543c:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 5464 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd84>
    5443:	00 
    5444:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    5449:	c4 e2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm4,4),%ymm5
    544f:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    5453:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5458:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5480 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xda0>
    545f:	00 
    5460:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    5466:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 548e <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdae>
    546d:	00 
    546e:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5473:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    5477:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    547c:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    5481:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    5487:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 5490 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdb0>
    548e:	ff ff 90 
    5491:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    5496:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    549a:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    549f:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    54a3:	c4 e2 25 90 14 b0    	vpgatherdd %ymm11,(%rax,%ymm6,4),%ymm2
    54a9:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    54ad:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    54b1:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    54b7:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    54bb:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 54c4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde4>
    54c2:	ff ff 90 
    54c5:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    54ca:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    54ce:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    54d3:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    54d8:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    54de:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    54e3:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    54e9:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    54ed:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    54f2:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    54f9:	00 00 
    54fb:	48 8b 41 60          	mov    0x60(%rcx),%rax
    54ff:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    5504:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5509:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    550d:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    5512:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    5517:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    551c:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    5521:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    5525:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    552a:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    552f:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5533:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5537:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    553c:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    5543:	00 00 
    5545:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    5549:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    554d:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5552:	c4 e2 65 90 24 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm4
    5558:	48 8b 41 68          	mov    0x68(%rcx),%rax
    555c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5560:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5564:	c4 a2 4d 90 2c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm5
    556a:	48 8b 41 70          	mov    0x70(%rcx),%rax
    556e:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    5575:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    557b:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    5580:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    5584:	c5 79 6e ca          	vmovd  %edx,%xmm9
    5588:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    558d:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5591:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5596:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    559b:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    55a2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    55a7:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    55ac:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 55d4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xef4>
    55b3:	00 
    55b4:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    55ba:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    55bf:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    55c6:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 55ee <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf0e>
    55cd:	00 
    55ce:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    55d3:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    55d8:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    55dd:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5605 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf25>
    55e4:	00 
    55e5:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    55ea:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    55ef:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    55f3:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    55f8:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    55fc:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    5600:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5604:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5608:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    560e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5612:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    5617:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    561b:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5621:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    5625:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    562b:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    562f:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5634:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    5638:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    563d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    5641:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    5647:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5650 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf70>
    564e:	ff ff 70 
    5651:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5656:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    565a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    565e:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5664:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5669:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    566e:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5674:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    567a:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    567f:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5684:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5689:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    568e:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5697 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb7>
    5695:	ff ff b0 
    5698:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    569c:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    56a1:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    56a6:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    56ac:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    56b1:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    56b5:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    56bc:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    56c1:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    56c6:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    56cb:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    56cf:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    56d4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    56d9:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    56de:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    56e3:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    56e7:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    56ec:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    56f1:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    56f5:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    56fa:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    56ff:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    5704:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5709:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    570e:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5714:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    5719:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    571e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    5722:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    5727:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    572c:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5731:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    5736:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    573b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5740:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    5745:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    574a:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    574f:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    5754:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    5759:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    575e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    5762:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5767:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    576c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5771:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    5776:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    577b:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    5780:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    5784:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5788:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    578d:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    5791:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5796:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    579b:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    579f:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    57a4:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    57a8:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    57ac:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    57b2:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    57b9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    57bd:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    57c1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    57c5:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    57c9:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    57cf:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    57d6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    57db:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    57e0:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    57e6:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    57ec:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    57f1:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    57f8:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    57fd:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5802:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 582a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x114a>
    5809:	00 
    580a:	c5 79 6e ca          	vmovd  %edx,%xmm9
    580e:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5813:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 583b <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x115b>
    581a:	00 
    581b:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    5822:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5827:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 584f <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x116f>
    582e:	00 
    582f:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5834:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5839:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    583e:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5843:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5847:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    584b:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    584f:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5853:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5857:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    585d:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5861:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    5867:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    586c:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5870:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5876:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    587a:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    5880:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    5884:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5889:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    588d:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    5892:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    5896:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    589c:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 58a5 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11c5>
    58a3:	ff ff 70 
    58a6:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    58ab:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    58af:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    58b3:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    58b9:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    58be:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    58c3:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    58c9:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    58cf:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    58d4:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    58d9:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    58de:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    58e3:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 58ec <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120c>
    58ea:	ff ff b0 
    58ed:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    58f1:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    58f6:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    58fb:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    5901:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    5906:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    590a:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    5911:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    5916:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    591b:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    5920:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    5924:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5929:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    592e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    5933:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5938:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    593c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5941:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    5946:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    594a:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    594f:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    5954:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    5959:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    595e:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5963:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5969:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    596e:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5973:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    5977:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    597c:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5981:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5986:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    598b:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5990:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5995:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    599a:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    599f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    59a4:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    59a9:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    59ae:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    59b3:	c5 79 6e ca          	vmovd  %edx,%xmm9
    59b7:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    59bb:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    59c0:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    59c5:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    59ca:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    59cf:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    59d4:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    59d9:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    59de:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    59e2:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    59e6:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    59eb:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    59ef:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    59f4:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    59f9:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    59fd:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5a02:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5a07:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    5a0b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    5a0f:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    5a15:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    5a1c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5a20:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5a24:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5a28:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5a2c:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5a32:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    5a39:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5a3e:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    5a43:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5a6b <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138b>
    5a4a:	00 
    5a4b:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    5a51:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    5a56:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 5a7e <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x139e>
    5a5d:	00 
    5a5e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5a63:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    5a68:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5a6d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5a95 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13b5>
    5a74:	00 
    5a75:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    5a7c:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5a81:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    5a86:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5a8a:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5a8f:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    5a93:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    5a97:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5a9b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5a9f:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    5aa5:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5aa9:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    5aae:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5ab2:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5ab8:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    5abc:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    5ac2:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    5ac6:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5acb:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    5acf:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    5ad4:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    5ada:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5ae3 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1403>
    5ae1:	ff ff 70 
    5ae4:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5ae9:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    5aed:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5af1:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5af7:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5afc:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    5b01:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5b07:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    5b0d:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5b12:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5b17:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5b1c:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    5b21:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5b2a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x144a>
    5b28:	ff ff b0 
    5b2b:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    5b2f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5b33:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5b38:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5b3e:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    5b43:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5b47:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    5b4c:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5b51:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5b56:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5b5a:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5b5f:	c4 41 15 db e4       	vpand  %ymm12,%ymm13,%ymm12
    5b64:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5b69:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5b6e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5b73:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5b78:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    5b7c:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    5b81:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    5b85:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    5b8a:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5b8f:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    5b94:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5b9a:	c5 95 db f6          	vpand  %ymm6,%ymm13,%ymm6
    5b9e:	c5 95 db d2          	vpand  %ymm2,%ymm13,%ymm2
    5ba2:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5ba7:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5bac:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5bb1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5bb6:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5bba:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5bbf:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5bc4:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    5bc9:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5bce:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    5bd3:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    5bd8:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    5bdd:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    5be2:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    5be6:	c4 c1 75 db f5       	vpand  %ymm13,%ymm1,%ymm6
    5beb:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    5bf0:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5bf5:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    5bfa:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    5bff:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5c04:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    5c08:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5c0c:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    5c10:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    5c15:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5c1a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5c1f:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5c24:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    5c29:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5c2d:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5c31:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5c35:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5c3a:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    5c3f:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    5c43:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    5c47:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    5c4e:	02 00 00 
    5c51:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    5c55:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    5c5b:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    5c60:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    5c65:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    5c69:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    5c6f:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    5c75:	4d 39 c2             	cmp    %r8,%r10
    5c78:	0f 85 60 f4 ff ff    	jne    50de <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9fe>
    5c7e:	e9 4e f3 ff ff       	jmp    4fd1 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    5c83:	4d 85 c9             	test   %r9,%r9
    5c86:	0f 84 48 f3 ff ff    	je     4fd4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    5c8c:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 5cf4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1614>
    5c93:	00 
    5c94:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    5c98:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5c9d:	48 c1 e8 03          	shr    $0x3,%rax
    5ca1:	c4 c1 35 72 d7 18    	vpsrld $0x18,%ymm15,%ymm9
    5ca7:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5cab:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    5cb2:	00 00 
    5cb4:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 5d3c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x165c>
    5cbb:	00 
    5cbc:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    5cc1:	b8 00 80 00 00       	mov    $0x8000,%eax
    5cc6:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    5ccd:	00 00 
    5ccf:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    5cd3:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5cd8:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    5cdd:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    5ce2:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    5ce8:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5cec:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5cf1:	48 8b 01             	mov    (%rcx),%rax
    5cf4:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    5cf8:	49 83 c0 18          	add    $0x18,%r8
    5cfc:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    5d02:	8b 51 50             	mov    0x50(%rcx),%edx
    5d05:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    5d0b:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    5d10:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    5d17:	01 00 00 
    5d1a:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    5d1e:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    5d23:	c4 c1 7d db d9       	vpand  %ymm9,%ymm0,%ymm3
    5d28:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    5d2d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    5d32:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    5d38:	48 8b 41 08          	mov    0x8(%rcx),%rax
    5d3c:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5d41:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5d45:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    5d4a:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5d4f:	c4 a2 4d 90 14 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm2
    5d55:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5d59:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5d5d:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
    5d62:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 5d8a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16aa>
    5d69:	00 
    5d6a:	c4 e2 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm0
    5d70:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    5d75:	48 8b 41 48          	mov    0x48(%rcx),%rax
    5d79:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 5da1 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16c1>
    5d80:	00 
    5d81:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
    5d86:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    5d8b:	c5 ad 72 d0 11       	vpsrld $0x11,%ymm0,%ymm10
    5d90:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 5db8 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16d8>
    5d97:	00 
    5d98:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    5d9c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5da0:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    5da5:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5daa:	c4 62 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm12
    5db0:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    5db4:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    5db8:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5dbd:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    5dc3:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    5dc7:	c4 62 15 90 24 b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm12
    5dcd:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5dd2:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    5dd8:	c4 62 15 90 34 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm14
    5dde:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5de2:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5de6:	c4 22 65 90 2c 82    	vpgatherdd %ymm3,(%rdx,%ymm8,4),%ymm13
    5dec:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    5df0:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    5df7:	00 00 
    5df9:	c4 e2 2d 90 1c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm3
    5dff:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
    5e03:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    5e0a:	00 00 
    5e0c:	c4 e2 45 3d da       	vpmaxsd %ymm2,%ymm7,%ymm3
    5e11:	c5 7d 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm8
    5e15:	c4 62 65 3d e8       	vpmaxsd %ymm0,%ymm3,%ymm13
    5e1a:	c4 e2 45 39 da       	vpminsd %ymm2,%ymm7,%ymm3
    5e1f:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5e25:	c4 62 65 39 d0       	vpminsd %ymm0,%ymm3,%ymm10
    5e2a:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    5e2e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm1,%ymm1        # 5e37 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1757>
    5e35:	ff ff 80 
    5e38:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5e3d:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    5e41:	c4 62 3d 90 24 88    	vpgatherdd %ymm8,(%rax,%ymm1,4),%ymm12
    5e47:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
    5e4b:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    5e51:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5e57:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm1,%ymm1        # 5e60 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1780>
    5e5e:	ff ff 30 
    5e61:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5e65:	c5 cd fa c9          	vpsubd %ymm1,%ymm6,%ymm1
    5e69:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    5e6d:	c4 62 65 90 04 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm8
    5e73:	c5 b5 db 4c 24 20    	vpand  0x20(%rsp),%ymm9,%ymm1
    5e79:	c4 c1 1d db d9       	vpand  %ymm9,%ymm12,%ymm3
    5e7e:	c4 41 2d fe e5       	vpaddd %ymm13,%ymm10,%ymm12
    5e83:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5e88:	c5 45 fe ea          	vpaddd %ymm2,%ymm7,%ymm13
    5e8c:	c4 41 7d fa e4       	vpsubd %ymm12,%ymm0,%ymm12
    5e91:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
    5e98:	00 00 
    5e9a:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
    5e9f:	c5 3d fa e3          	vpsubd %ymm3,%ymm8,%ymm12
    5ea3:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    5eaa:	00 00 
    5eac:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
    5eb1:	c5 e5 fa 9c 24 80 00 	vpsubd 0x80(%rsp),%ymm3,%ymm3
    5eb8:	00 00 
    5eba:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    5ec1:	00 00 
    5ec3:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    5ec8:	c5 f5 fe 0c 24       	vpaddd (%rsp),%ymm1,%ymm1
    5ecd:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    5ed2:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5ed6:	c5 9d fe c9          	vpaddd %ymm1,%ymm12,%ymm1
    5eda:	c5 35 db 64 24 60    	vpand  0x60(%rsp),%ymm9,%ymm12
    5ee0:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    5ee5:	c4 c1 1d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm12
    5eeb:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    5ef0:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    5ef4:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    5ef8:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    5eff:	00 00 
    5f01:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    5f06:	c4 c1 3d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm8
    5f0c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5f11:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    5f15:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    5f1c:	00 00 
    5f1e:	c5 f5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm1
    5f23:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    5f28:	c4 41 3d fe d4       	vpaddd %ymm12,%ymm8,%ymm10
    5f2d:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    5f32:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    5f36:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    5f3d:	00 00 
    5f3f:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    5f43:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    5f49:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    5f4e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5f52:	c5 e5 fe d0          	vpaddd %ymm0,%ymm3,%ymm2
    5f56:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    5f5d:	00 00 
    5f5f:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
    5f65:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    5f6a:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    5f6e:	c4 62 6d 3d e8       	vpmaxsd %ymm0,%ymm2,%ymm13
    5f73:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
    5f77:	c4 41 65 66 f5       	vpcmpgtd %ymm13,%ymm3,%ymm14
    5f7c:	c4 62 15 3d d3       	vpmaxsd %ymm3,%ymm13,%ymm10
    5f81:	c4 62 6d 39 e8       	vpminsd %ymm0,%ymm2,%ymm13
    5f86:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    5f8a:	c4 c3 5d 4c fb 70    	vpblendvb %ymm7,%ymm11,%ymm4,%ymm7
    5f90:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm7,%ymm7        # 5f99 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18b9>
    5f97:	ff ff e0 
    5f9a:	c4 62 15 39 f3       	vpminsd %ymm3,%ymm13,%ymm14
    5f9f:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    5fa3:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    5faa:	00 00 
    5fac:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    5fb0:	c4 c3 5d 4c c3 00    	vpblendvb %ymm0,%ymm11,%ymm4,%ymm0
    5fb6:	c4 62 4d 90 34 b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm14
    5fbc:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    5fc2:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    5fc6:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 5fcf <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18ef>
    5fcd:	ff ff d0 
    5fd0:	c5 cd fa d8          	vpsubd %ymm0,%ymm6,%ymm3
    5fd4:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5fd8:	c4 e2 4d 90 04 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm0
    5fde:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    5fe4:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    5fe9:	c4 41 7d db e9       	vpand  %ymm9,%ymm0,%ymm13
    5fee:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    5ff5:	00 00 
    5ff7:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    5ffc:	c4 41 65 db f1       	vpand  %ymm9,%ymm3,%ymm14
    6001:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    6006:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    600c:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
    6011:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    6016:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    601a:	c5 95 fa d3          	vpsubd %ymm3,%ymm13,%ymm2
    601e:	c5 cd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm6
    6023:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
    602a:	00 00 
    602c:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    6031:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
    6037:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    603e:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    6043:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    6049:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    604e:	c5 c5 fe 14 24       	vpaddd (%rsp),%ymm7,%ymm2
    6053:	c4 c2 3d 39 fc       	vpminsd %ymm12,%ymm8,%ymm7
    6058:	c5 79 6e d2          	vmovd  %edx,%xmm10
    605c:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6061:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    6066:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    606a:	c5 b5 db c6          	vpand  %ymm6,%ymm9,%ymm0
    606e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6072:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    6077:	c4 62 45 39 e9       	vpminsd %ymm1,%ymm7,%ymm13
    607c:	c5 c5 66 f9          	vpcmpgtd %ymm1,%ymm7,%ymm7
    6080:	c4 e2 7d 40 84 24 80 	vpmulld 0x80(%rsp),%ymm0,%ymm0
    6087:	00 00 00 
    608a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    608e:	c4 c2 3d 3d dc       	vpmaxsd %ymm12,%ymm8,%ymm3
    6093:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    6097:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
    609b:	c4 e2 65 3d d9       	vpmaxsd %ymm1,%ymm3,%ymm3
    60a0:	c5 8d 72 d2 10       	vpsrld $0x10,%ymm2,%ymm14
    60a5:	c4 c1 1d 66 d0       	vpcmpgtd %ymm8,%ymm12,%ymm2
    60aa:	c4 41 3d 66 c4       	vpcmpgtd %ymm12,%ymm8,%ymm8
    60af:	c4 c3 5d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm4,%ymm2
    60b5:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 60be <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19de>
    60bc:	ff ff 00 
    60bf:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    60c3:	c4 e2 4d 90 04 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm0
    60c9:	c4 c3 5d 4c d3 80    	vpblendvb %ymm8,%ymm11,%ymm4,%ymm2
    60cf:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    60d5:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 60de <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19fe>
    60dc:	ff ff 70 
    60df:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    60e4:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    60ea:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    60ee:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    60f2:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    60f8:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    60fd:	c4 c1 65 fe c5       	vpaddd %ymm13,%ymm3,%ymm0
    6102:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6108:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    610c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    6111:	48 8b 41 60          	mov    0x60(%rcx),%rax
    6115:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    611a:	c5 dd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm4
    611f:	c5 fd fe 84 24 e0 00 	vpaddd 0xe0(%rsp),%ymm0,%ymm0
    6126:	00 00 
    6128:	c5 d5 fa ca          	vpsubd %ymm2,%ymm5,%ymm1
    612c:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    6131:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6136:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    613b:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    6140:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    6144:	c5 c5 fe 0c 24       	vpaddd (%rsp),%ymm7,%ymm1
    6149:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    614e:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    6152:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    6156:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    615a:	c4 c1 4d db c9       	vpand  %ymm9,%ymm6,%ymm1
    615f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6163:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    6167:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    616c:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6171:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    6176:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    617a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    617e:	c5 fe 6f 8c 24 00 01 	vmovdqu 0x100(%rsp),%ymm1
    6185:	00 00 
    6187:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    618c:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    6192:	48 8b 41 68          	mov    0x68(%rcx),%rax
    6196:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    619a:	c4 a2 4d 90 2c b0    	vpgatherdd %ymm6,(%rax,%ymm14,4),%ymm5
    61a0:	48 8b 41 70          	mov    0x70(%rcx),%rax
    61a4:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    61a9:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 61d1 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1af1>
    61b0:	00 
    61b1:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    61b7:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    61bc:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    61c3:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 61eb <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b0b>
    61ca:	00 
    61cb:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    61d0:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    61d5:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    61da:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6202 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b22>
    61e1:	00 
    61e2:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    61e7:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    61ec:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    61f0:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    61f5:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    61f9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    61fd:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    6201:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6205:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    620b:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    620f:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6214:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6218:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    621c:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    6222:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    6229:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    622f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6235:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    6239:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    623e:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6242:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6247:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    624b:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    6251:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 625a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b7a>
    6258:	ff ff 70 
    625b:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    6260:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    6264:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    6268:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    626e:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    6273:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6278:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    627e:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6284:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6289:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    628e:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    6293:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    6298:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 62a1 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1bc1>
    629f:	ff ff c0 
    62a2:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    62a6:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    62ab:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    62b0:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    62b6:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    62bb:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    62bf:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    62c6:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    62cb:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    62d0:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    62d5:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    62d9:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    62de:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    62e3:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    62e8:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    62ed:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    62f1:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    62f6:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    62fb:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    62ff:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    6304:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6309:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    630e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6313:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6318:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    631e:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    6323:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    6328:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    632c:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    6331:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    6336:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    633b:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    6340:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6345:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    634a:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    634f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6354:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    6359:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    635e:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    6363:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6368:	c5 79 6e d2          	vmovd  %edx,%xmm10
    636c:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    6370:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6375:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    637a:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    637f:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    6384:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6389:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    638e:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    6393:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    6397:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    639b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    63a0:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    63a4:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    63a9:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    63ae:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    63b2:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    63b7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    63bc:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    63c0:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    63c4:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    63ca:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    63d1:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    63d5:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    63d9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    63dd:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    63e1:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    63e7:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    63ee:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    63f3:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    63f8:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 6420 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d40>
    63ff:	00 
    6400:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6406:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    640b:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    6412:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 643a <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d5a>
    6419:	00 
    641a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    641f:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6424:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    6429:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6451 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d71>
    6430:	00 
    6431:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6436:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    643b:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    643f:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    6444:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    6448:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    644c:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    6450:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6454:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    645a:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    645e:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6463:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6467:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    646d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    6471:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6477:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    647b:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    6480:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6484:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6489:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    648d:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    6493:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 649c <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1dbc>
    649a:	ff ff 70 
    649d:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    64a2:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    64a6:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    64aa:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    64af:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    64b4:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    64ba:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    64c0:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    64c6:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    64cb:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 64d4 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1df4>
    64d2:	ff ff c0 
    64d5:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    64da:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    64df:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    64e6:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    64eb:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    64ef:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    64f3:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    64f9:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    64ff:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    6504:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6509:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    6510:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6515:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    651a:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    651f:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    6523:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    6528:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    652d:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    6532:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6537:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    653c:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6541:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    6545:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    654a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    654e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    6553:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6558:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    655d:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    6563:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6568:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    656d:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    6572:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6577:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    657c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6581:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    6585:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    658a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    658f:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    6594:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    6599:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    659e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    65a3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    65a8:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    65ad:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    65b2:	c5 79 6e d2          	vmovd  %edx,%xmm10
    65b6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    65bb:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    65c0:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    65c5:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    65c9:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    65ce:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    65d3:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    65d8:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    65dd:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    65e2:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    65e7:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    65eb:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    65ef:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    65f4:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    65f8:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    65fd:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    6602:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6606:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    660b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    660f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6613:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    6619:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    6620:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6624:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6628:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    662c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    6630:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    6636:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    663d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6642:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6647:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 666f <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f8f>
    664e:	00 
    664f:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6655:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    665a:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    6661:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 6689 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fa9>
    6668:	00 
    6669:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    666e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6673:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    6678:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 66a0 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fc0>
    667f:	00 
    6680:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6685:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    668a:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    668e:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    6693:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    6697:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    669b:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    669f:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    66a3:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    66a9:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    66ad:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    66b2:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    66b6:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    66bc:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    66c0:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    66c6:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    66ca:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    66cf:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    66d3:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    66d8:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    66de:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 66e7 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2007>
    66e5:	ff ff 70 
    66e8:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    66ed:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    66f1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    66f5:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    66fb:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    6700:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6705:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    670b:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6711:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6716:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    671b:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    6720:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6729 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2049>
    6727:	ff ff c0 
    672a:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    672e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6732:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    6737:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    673d:	c4 c1 7d db f1       	vpand  %ymm9,%ymm0,%ymm6
    6742:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    6746:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    674b:	c4 c1 55 db d1       	vpand  %ymm9,%ymm5,%ymm2
    6750:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6755:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    675a:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    675e:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    6763:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    6768:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    676d:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6772:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6777:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    677c:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    6780:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    6785:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    6789:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    678e:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6793:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    6798:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    679e:	c5 b5 db f6          	vpand  %ymm6,%ymm9,%ymm6
    67a2:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    67a7:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    67ac:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    67b1:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    67b6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    67bb:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    67bf:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    67c4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    67c9:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    67ce:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    67d3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    67d8:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    67dd:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    67e2:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    67e7:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    67eb:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    67f0:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    67f5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    67fa:	c4 c1 65 db e9       	vpand  %ymm9,%ymm3,%ymm5
    67ff:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    6804:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    6809:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    680d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    6811:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    6815:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    681a:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    681f:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    6824:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    6829:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    682e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6832:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    6836:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    683a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    683f:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    6844:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    6848:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    684c:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    6853:	02 00 00 
    6856:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    685a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    6860:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    6865:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    686a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    686e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    6874:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    687a:	4d 39 c2             	cmp    %r8,%r10
    687d:	0f 85 5a f4 ff ff    	jne    5cdd <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15fd>
    6883:	e9 49 e7 ff ff       	jmp    4fd1 <jshc_cache_range::avx2_chain(jshc_cache_range::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    6888:	90                   	nop
    6889:	90                   	nop
    688a:	90                   	nop
    688b:	90                   	nop
    688c:	90                   	nop
    688d:	90                   	nop
    688e:	90                   	nop
    688f:	90                   	nop
