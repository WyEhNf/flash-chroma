
artifacts\skylake-uniform-suffix-build-v1\CMakeFiles\jshc_skylake_uniform_suffix.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)>:
       0:	41 57                	push   %r15
       2:	41 56                	push   %r14
       4:	41 55                	push   %r13
       6:	41 54                	push   %r12
       8:	55                   	push   %rbp
       9:	57                   	push   %rdi
       a:	56                   	push   %rsi
       b:	53                   	push   %rbx
       c:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
      13:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
      1a:	00 00 
      1c:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
      23:	00 00 
      25:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
      2c:	00 00 
      2e:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
      35:	00 00 
      37:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
      3e:	00 00 
      40:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
      47:	00 00 
      49:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
      50:	00 00 
      52:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
      59:	00 00 
      5b:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
      62:	00 00 
      64:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
      6b:	00 00 
      6d:	49 89 cf             	mov    %rcx,%r15
      70:	4d 85 c0             	test   %r8,%r8
      73:	0f 84 52 12 00 00    	je     12cb <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x12cb>
      79:	49 ff c8             	dec    %r8
      7c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      81:	49 89 d4             	mov    %rdx,%r12
      84:	49 c1 e8 03          	shr    $0x3,%r8
      88:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
      8e:	4b 8d 04 40          	lea    (%r8,%r8,2),%rax
      92:	48 8d 44 c2 18       	lea    0x18(%rdx,%rax,8),%rax
      97:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
      9e:	00 
      9f:	b8 00 80 00 00       	mov    $0x8000,%eax
      a4:	c5 f9 6e f8          	vmovd  %eax,%xmm7
      a8:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      ad:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
      b2:	e9 04 07 00 00       	jmp    7bb <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7bb>
      b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
      be:	00 00 
      c0:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
      c7:	00 00 
      c9:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
      cd:	c5 79 6e e7          	vmovd  %edi,%xmm12
      d1:	c5 79 6e ce          	vmovd  %esi,%xmm9
      d5:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
      da:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
      df:	8d 54 37 01          	lea    0x1(%rdi,%rsi,1),%edx
      e3:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
      ea:	00 
      eb:	c4 e2 45 90 1c 81    	vpgatherdd %ymm7,(%rcx,%ymm0,4),%ymm3
      f1:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
      f5:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
      fc:	00 
      fd:	c4 c2 45 90 2c a0    	vpgatherdd %ymm7,(%r8,%ymm4,4),%ymm5
     103:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     108:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     10c:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     111:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     116:	c4 c2 45 90 34 91    	vpgatherdd %ymm7,(%r9,%ymm2,4),%ymm6
     11c:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     121:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     126:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     12a:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 192 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x192>
     131:	00 
     132:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 19a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x19a>
     139:	00 
     13a:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     13f:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1a7 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1a7>
     146:	00 
     147:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     14b:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     150:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
     155:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
     15a:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
     15e:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     162:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     166:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     16a:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     16e:	c4 e2 45 90 04 8b    	vpgatherdd %ymm7,(%rbx,%ymm1,4),%ymm0
     174:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     178:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     17f:	00 00 
     181:	c4 62 45 90 34 a3    	vpgatherdd %ymm7,(%rbx,%ymm4,4),%ymm14
     187:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     18c:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
     190:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     194:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     199:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
     19f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     1a3:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1cc <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1cc>
     1aa:	00 00 70 
     1ad:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     1b2:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
     1b8:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     1bc:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
     1c3:	00 00 
     1c5:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     1c9:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     1cd:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm9,%ymm9        # 1f6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1f6>
     1d4:	00 00 b0 
     1d7:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     1db:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     1e0:	c4 e2 5d 90 14 8b    	vpgatherdd %ymm4,(%rbx,%ymm1,4),%ymm2
     1e6:	c4 c1 65 fa e1       	vpsubd %ymm9,%ymm3,%ymm4
     1eb:	c4 e2 55 90 1c a3    	vpgatherdd %ymm5,(%rbx,%ymm4,4),%ymm3
     1f1:	c4 41 6d db cd       	vpand  %ymm13,%ymm2,%ymm9
     1f6:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     1fb:	c4 c1 65 db cd       	vpand  %ymm13,%ymm3,%ymm1
     200:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     205:	c4 c1 0d db e5       	vpand  %ymm13,%ymm14,%ymm4
     20a:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
     20e:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     212:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     217:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     21c:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     221:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     226:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     22b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     230:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     235:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     23a:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     23f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     243:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     247:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
     24c:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     250:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     255:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     25a:	c4 c1 75 72 d6 08    	vpsrld $0x8,%ymm14,%ymm1
     260:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
     265:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     26a:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     26f:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
     273:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     278:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     27d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     282:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     286:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     28b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     290:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     295:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     29a:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     29f:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     2a4:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     2a8:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
     2ad:	c4 41 79 6e cd       	vmovd  %r13d,%xmm9
     2b2:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     2b6:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     2bb:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     2c0:	c4 c1 7d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm0
     2c6:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     2cb:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     2cf:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     2d4:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     2d9:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     2de:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     2e2:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     2e6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     2eb:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     2f0:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     2f5:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     2f9:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     2fd:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     301:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     305:	c4 e2 45 90 1c a7    	vpgatherdd %ymm7,(%rdi,%ymm4,4),%ymm3
     30b:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
     312:	00 
     313:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     317:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     31c:	c4 e2 45 90 2c 8f    	vpgatherdd %ymm7,(%rdi,%ymm1,4),%ymm5
     322:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     326:	c4 e2 45 90 34 86    	vpgatherdd %ymm7,(%rsi,%ymm0,4),%ymm6
     32c:	8b 7c 24 60          	mov    0x60(%rsp),%edi
     330:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     335:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     339:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     33e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     343:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3ab <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3ab>
     34a:	00 
     34b:	8b 74 24 40          	mov    0x40(%rsp),%esi
     34f:	c5 79 6e e7          	vmovd  %edi,%xmm12
     353:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     358:	42 8d 54 2f 01       	lea    0x1(%rdi,%r13,1),%edx
     35d:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     362:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     366:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3ce <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3ce>
     36d:	00 
     36e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     373:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     378:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3e0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3e0>
     37f:	00 
     380:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     385:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
     38a:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
     38f:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
     393:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     397:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     39b:	c5 dd fe d1          	vpaddd %ymm1,%ymm4,%ymm2
     39f:	c4 e2 45 90 04 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm0
     3a5:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     3a9:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
     3af:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
     3b3:	c4 62 45 90 34 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm14
     3b9:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     3bd:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     3c2:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     3c6:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     3cb:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     3cf:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
     3d5:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 3fe <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3fe>
     3dc:	00 00 70 
     3df:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     3e4:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
     3ea:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
     3f0:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     3f4:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm9,%ymm9        # 41d <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x41d>
     3fb:	00 00 b0 
     3fe:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     402:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     407:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     40b:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     40f:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
     415:	c4 c1 65 fa e1       	vpsubd %ymm9,%ymm3,%ymm4
     41a:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
     420:	c4 41 6d db cd       	vpand  %ymm13,%ymm2,%ymm9
     425:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     42a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     431:	00 
     432:	c4 c1 65 db cd       	vpand  %ymm13,%ymm3,%ymm1
     437:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     43c:	c4 c1 0d db e5       	vpand  %ymm13,%ymm14,%ymm4
     441:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
     445:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     449:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     44e:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     453:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     458:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     45d:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     462:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     467:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     46c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     471:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     476:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     47a:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     47e:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
     483:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     487:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     48c:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     491:	c4 c1 75 72 d6 08    	vpsrld $0x8,%ymm14,%ymm1
     497:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
     49c:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     4a1:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     4a6:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
     4aa:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     4af:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     4b4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     4b9:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     4bd:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     4c2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     4c7:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     4cc:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     4d1:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     4d6:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     4db:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     4df:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
     4e4:	c5 79 6e ce          	vmovd  %esi,%xmm9
     4e8:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     4ec:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     4f1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     4f6:	c4 c1 7d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm0
     4fc:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     501:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     505:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     50a:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     50f:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     514:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     518:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     51c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     521:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     526:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     52b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     52f:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     533:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     537:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     53b:	c4 e2 45 90 1c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm3
     541:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
     548:	00 
     549:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     54d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     552:	c4 e2 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm5
     558:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
     55f:	00 
     560:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     564:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     569:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 5d1 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x5d1>
     570:	00 
     571:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
     577:	8b 44 24 20          	mov    0x20(%rsp),%eax
     57b:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     580:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     584:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     589:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     58e:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 5f6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x5f6>
     595:	00 
     596:	c5 79 6e e0          	vmovd  %eax,%xmm12
     59a:	8d 44 30 01          	lea    0x1(%rax,%rsi,1),%eax
     59e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 606 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x606>
     5a5:	00 
     5a6:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     5ab:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     5af:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     5b4:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     5b9:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     5be:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
     5c3:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
     5c8:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
     5cc:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     5d0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     5d4:	c5 dd fe d1          	vpaddd %ymm1,%ymm4,%ymm2
     5d8:	c4 e2 45 90 44 8d 00 	vpgatherdd %ymm7,0x0(%rbp,%ymm1,4),%ymm0
     5df:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     5e3:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     5e9:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
     5ed:	c4 62 45 90 74 95 00 	vpgatherdd %ymm7,0x0(%rbp,%ymm2,4),%ymm14
     5f4:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     5f8:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     5fd:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     601:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     606:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
     60c:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 635 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x635>
     613:	00 00 70 
     616:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     61b:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
     621:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
     627:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     62b:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm9,%ymm9        # 654 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x654>
     632:	00 00 b0 
     635:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     639:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     63e:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     642:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     646:	c4 e2 5d 90 54 8d 00 	vpgatherdd %ymm4,0x0(%rbp,%ymm1,4),%ymm2
     64d:	c4 c1 65 fa e1       	vpsubd %ymm9,%ymm3,%ymm4
     652:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     656:	c4 e2 65 90 6c a5 00 	vpgatherdd %ymm3,0x0(%rbp,%ymm4,4),%ymm5
     65d:	c4 41 6d db cd       	vpand  %ymm13,%ymm2,%ymm9
     662:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
     667:	c4 c1 55 db cd       	vpand  %ymm13,%ymm5,%ymm1
     66c:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     671:	c4 c1 0d db dd       	vpand  %ymm13,%ymm14,%ymm3
     676:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
     67a:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
     67e:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     683:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     688:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     68d:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     692:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     697:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     69c:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     6a1:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     6a5:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     6a9:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
     6ae:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     6b2:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
     6b7:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     6bc:	c4 c1 75 72 d6 08    	vpsrld $0x8,%ymm14,%ymm1
     6c2:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
     6c7:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     6cc:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     6d1:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
     6d5:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     6da:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     6df:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     6e4:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     6e8:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     6ed:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
     6f2:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     6f7:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     6fc:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     701:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     706:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     70b:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     70f:	c5 cd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm6
     714:	c4 c1 6d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm2
     71a:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
     71f:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     724:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     729:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     72d:	c5 dd 72 f0 10       	vpslld $0x10,%ymm0,%ymm4
     732:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     736:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
     73a:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
     73e:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     743:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
     748:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     74d:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     752:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     757:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     75b:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     75f:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
     764:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     768:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     76d:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     772:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     776:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
     77a:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 7c3 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7c3>
     781:	00 00 
     783:	49 83 c4 18          	add    $0x18,%r12
     787:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     78b:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     791:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     796:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     79b:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     79f:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
     7a6:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
     7ad:	4c 3b a4 24 28 01 00 	cmp    0x128(%rsp),%r12
     7b4:	00 
     7b5:	0f 84 0d 0b 00 00    	je     12c8 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x12c8>
     7bb:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     7c1:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     7c8:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     7cc:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     7d1:	49 8b 07             	mov    (%r15),%rax
     7d4:	41 8b 4f 54          	mov    0x54(%r15),%ecx
     7d8:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     7de:	41 8b 57 50          	mov    0x50(%r15),%edx
     7e2:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     7e8:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 7f1 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7f1>
     7ef:	00 00 
     7f1:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     7f6:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
     7fb:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
     800:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     806:	c4 c1 75 db c5       	vpand  %ymm13,%ymm1,%ymm0
     80b:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     80f:	c4 e2 55 90 14 a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm2
     815:	49 8b 47 08          	mov    0x8(%r15),%rax
     819:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     81f:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
     824:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 88c <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x88c>
     82b:	00 
     82c:	c4 e2 75 90 2c 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm5
     832:	49 8b 47 10          	mov    0x10(%r15),%rax
     836:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     83d:	00 00 
     83f:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     843:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     847:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     84b:	c4 e2 75 90 1c b8    	vpgatherdd %ymm1,(%rax,%ymm7,4),%ymm3
     851:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
     855:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     85a:	49 8b 47 48          	mov    0x48(%r15),%rax
     85e:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     863:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     868:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 8d0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x8d0>
     86f:	00 
     870:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
     875:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     87a:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
     87f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 8e7 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x8e7>
     886:	00 
     887:	c4 62 6d 3d c5       	vpmaxsd %ymm5,%ymm2,%ymm8
     88c:	c4 62 6d 39 cd       	vpminsd %ymm5,%ymm2,%ymm9
     891:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     895:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     899:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     89d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     8a2:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     8a6:	c5 5d fe e1          	vpaddd %ymm1,%ymm4,%ymm12
     8aa:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
     8af:	c4 62 4d 90 14 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm10
     8b5:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     8bb:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
     8c0:	c4 a2 25 90 34 a0    	vpgatherdd %ymm11,(%rax,%ymm12,4),%ymm6
     8c6:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     8cb:	c4 62 35 39 db       	vpminsd %ymm3,%ymm9,%ymm11
     8d0:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     8d4:	c5 d5 66 f2          	vpcmpgtd %ymm2,%ymm5,%ymm6
     8d8:	c5 35 66 cb          	vpcmpgtd %ymm3,%ymm9,%ymm9
     8dc:	c4 e3 7d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm6
     8e2:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm6,%ymm6        # 90b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x90b>
     8e9:	00 00 40 
     8ec:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
     8f0:	c4 e2 1d 90 24 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm4
     8f6:	c5 ed 66 f5          	vpcmpgtd %ymm5,%ymm2,%ymm6
     8fa:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
     900:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     904:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     909:	c4 e3 7d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm6
     90f:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 938 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x938>
     916:	00 00 90 
     919:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
     91d:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     922:	c4 62 1d 90 0c b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm9
     928:	c4 41 3d fe e3       	vpaddd %ymm11,%ymm8,%ymm12
     92d:	c5 7e 7f 94 24 80 00 	vmovdqu %ymm10,0x80(%rsp)
     934:	00 00 
     936:	49 8b 57 28          	mov    0x28(%r15),%rdx
     93a:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     93f:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
     944:	c5 15 db 94 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm10
     94b:	00 00 
     94d:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     953:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     957:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
     95b:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     960:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
     965:	c4 c1 15 db d6       	vpand  %ymm14,%ymm13,%ymm2
     96a:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     96f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     974:	c4 c1 4d 72 f2 10    	vpslld $0x10,%ymm10,%ymm6
     97a:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     97f:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     984:	c5 cd fe 34 24       	vpaddd (%rsp),%ymm6,%ymm6
     989:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     98e:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
     995:	00 00 
     997:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
     99d:	c5 e5 fe f6          	vpaddd %ymm6,%ymm3,%ymm6
     9a1:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     9a7:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     9ac:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     9b0:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
     9b7:	00 00 
     9b9:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     9bd:	c5 bd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm8
     9c2:	c5 7e 7f 84 24 e0 00 	vmovdqu %ymm8,0xe0(%rsp)
     9c9:	00 00 
     9cb:	c4 e2 1d 90 34 a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm6
     9d1:	49 8b 57 20          	mov    0x20(%r15),%rdx
     9d5:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     9da:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # a42 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa42>
     9e1:	00 
     9e2:	c4 62 1d 90 04 aa    	vpgatherdd %ymm12,(%rdx,%ymm5,4),%ymm8
     9e8:	49 8b 57 18          	mov    0x18(%r15),%rdx
     9ec:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     9f1:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # a59 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa59>
     9f8:	00 
     9f9:	c4 e2 1d 90 14 9a    	vpgatherdd %ymm12,(%rdx,%ymm3,4),%ymm2
     9ff:	49 8b 57 40          	mov    0x40(%r15),%rdx
     a03:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # a6b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa6b>
     a0a:	00 
     a0b:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
     a10:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
     a14:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
     a19:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
     a1e:	c4 62 55 39 e6       	vpminsd %ymm6,%ymm5,%ymm12
     a23:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
     a28:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
     a2c:	c4 e3 7d 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm0,%ymm4
     a32:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # a5b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa5b>
     a39:	00 00 30 
     a3c:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
     a40:	c4 e2 35 90 1c a0    	vpgatherdd %ymm9,(%rax,%ymm4,4),%ymm3
     a46:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
     a4b:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
     a50:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     a55:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     a5a:	c4 e3 7d 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm0,%ymm4
     a60:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # a89 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa89>
     a67:	00 00 50 
     a6a:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     a70:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
     a74:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     a78:	c4 62 55 90 0c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm9
     a7e:	c5 7e 7f b4 24 c0 00 	vmovdqu %ymm14,0xc0(%rsp)
     a85:	00 00 
     a87:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
     a8d:	c4 41 2d fe f4       	vpaddd %ymm12,%ymm10,%ymm14
     a92:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
     a98:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     a9d:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     aa2:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     aa7:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
     aab:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     ab0:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
     ab4:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
     ab9:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
     abf:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     ac4:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
     ac9:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
     ace:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     ad3:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
     ad8:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
     adc:	c5 fe 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm3
     ae3:	00 00 
     ae5:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
     ae9:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     aed:	c4 e2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm2
     af3:	49 8b 57 38          	mov    0x38(%r15),%rdx
     af7:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
     afd:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     b02:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
     b08:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # b70 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xb70>
     b0f:	00 
     b10:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     b15:	c4 a2 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm10,4),%ymm5
     b1b:	49 8b 57 30          	mov    0x30(%r15),%rdx
     b1f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     b24:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
     b2b:	00 00 
     b2d:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # b95 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xb95>
     b34:	00 
     b35:	c4 e2 0d 90 1c b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm3
     b3b:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     b40:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # ba8 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xba8>
     b47:	00 
     b48:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     b4d:	c5 d5 66 f3          	vpcmpgtd %ymm3,%ymm5,%ymm6
     b51:	c4 41 6d 66 c8       	vpcmpgtd %ymm8,%ymm2,%ymm9
     b56:	c4 62 3d 3d c2       	vpmaxsd %ymm2,%ymm8,%ymm8
     b5b:	c4 e3 7d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm6
     b61:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # b8a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xb8a>
     b68:	00 00 90 
     b6b:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
     b70:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
     b74:	c4 62 35 39 d2       	vpminsd %ymm2,%ymm9,%ymm10
     b79:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     b7d:	c4 e2 0d 90 0c b0    	vpgatherdd %ymm14,(%rax,%ymm6,4),%ymm1
     b83:	c5 e5 66 f5          	vpcmpgtd %ymm5,%ymm3,%ymm6
     b87:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     b8c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b91:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     b95:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     b9a:	c4 e3 7d 4c c7 60    	vpblendvb %ymm6,%ymm7,%ymm0,%ymm0
     ba0:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     ba6:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     bad:	00 00 
     baf:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm0,%ymm0        # bd8 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xbd8>
     bb6:	00 00 90 
     bb9:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
     bbd:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     bc2:	c4 e2 0d 90 3c 80    	vpgatherdd %ymm14,(%rax,%ymm0,4),%ymm7
     bc8:	c4 c1 7d 72 d3 10    	vpsrld $0x10,%ymm11,%ymm0
     bce:	c4 41 3d fe da       	vpaddd %ymm10,%ymm8,%ymm11
     bd3:	49 8b 87 20 01 00 00 	mov    0x120(%r15),%rax
     bda:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     bdf:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     be4:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
     be9:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     bee:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     bf3:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     bf7:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
     bfe:	00 
     bff:	c5 c5 fa d9          	vpsubd %ymm1,%ymm7,%ymm3
     c03:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
     c07:	c5 b5 72 f0 10       	vpslld $0x10,%ymm0,%ymm9
     c0c:	49 8b 87 28 01 00 00 	mov    0x128(%r15),%rax
     c13:	c5 f5 fa c8          	vpsubd %ymm0,%ymm1,%ymm1
     c17:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     c1c:	c5 35 fe 0c 24       	vpaddd (%rsp),%ymm9,%ymm9
     c21:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     c26:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
     c2b:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
     c32:	00 
     c33:	49 8b 87 30 01 00 00 	mov    0x130(%r15),%rax
     c3a:	c5 fd 72 f4 08       	vpslld $0x8,%ymm4,%ymm0
     c3f:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     c43:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
     c4a:	00 
     c4b:	41 8b 87 74 01 00 00 	mov    0x174(%r15),%eax
     c52:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     c57:	89 44 24 20          	mov    %eax,0x20(%rsp)
     c5b:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
     c5f:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     c63:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     c68:	c5 f5 72 f2 10       	vpslld $0x10,%ymm2,%ymm1
     c6d:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     c71:	c5 fd eb 84 24 e0 00 	vpor   0xe0(%rsp),%ymm0,%ymm0
     c78:	00 00 
     c7a:	41 8b 87 70 01 00 00 	mov    0x170(%r15),%eax
     c81:	49 8b af 68 01 00 00 	mov    0x168(%r15),%rbp
     c88:	45 8b af 10 01 00 00 	mov    0x110(%r15),%r13d
     c8f:	c4 e2 45 36 c8       	vpermd %ymm0,%ymm7,%ymm1
     c94:	49 8b 4f 60          	mov    0x60(%r15),%rcx
     c98:	4d 8b 47 68          	mov    0x68(%r15),%r8
     c9c:	89 44 24 40          	mov    %eax,0x40(%rsp)
     ca0:	49 8b 87 c0 00 00 00 	mov    0xc0(%r15),%rax
     ca7:	c5 fd ef c9          	vpxor  %ymm1,%ymm0,%ymm1
     cab:	4d 8b 4f 70          	mov    0x70(%r15),%r9
     caf:	c4 e2 7d 17 c9       	vptest %ymm1,%ymm1
     cb4:	41 8b bf b4 00 00 00 	mov    0xb4(%r15),%edi
     cbb:	41 8b b7 b0 00 00 00 	mov    0xb0(%r15),%esi
     cc2:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
     cc9:	00 
     cca:	49 8b 87 c8 00 00 00 	mov    0xc8(%r15),%rax
     cd1:	49 8b 9f a8 00 00 00 	mov    0xa8(%r15),%rbx
     cd8:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
     cdf:	00 
     ce0:	49 8b 87 d0 00 00 00 	mov    0xd0(%r15),%rax
     ce7:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
     cee:	00 
     cef:	41 8b 87 14 01 00 00 	mov    0x114(%r15),%eax
     cf6:	89 44 24 60          	mov    %eax,0x60(%rsp)
     cfa:	49 8b 87 08 01 00 00 	mov    0x108(%r15),%rax
     d01:	0f 85 b9 f3 ff ff    	jne    c0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xc0>
     d07:	c5 f9 7e c2          	vmovd  %xmm0,%edx
     d0b:	44 0f b6 d2          	movzbl %dl,%r10d
     d0f:	46 8b 34 91          	mov    (%rcx,%r10,4),%r14d
     d13:	0f b6 ce             	movzbl %dh,%ecx
     d16:	c1 ea 10             	shr    $0x10,%edx
     d19:	45 8b 04 88          	mov    (%r8,%rcx,4),%r8d
     d1d:	41 8b 14 91          	mov    (%r9,%rdx,4),%edx
     d21:	44 89 f1             	mov    %r14d,%ecx
     d24:	c1 e9 11             	shr    $0x11,%ecx
     d27:	45 89 c3             	mov    %r8d,%r11d
     d2a:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
     d31:	41 89 c9             	mov    %ecx,%r9d
     d34:	41 c1 eb 11          	shr    $0x11,%r11d
     d38:	44 89 f1             	mov    %r14d,%ecx
     d3b:	44 0f af ce          	imul   %esi,%r9d
     d3f:	81 e1 ff ff 01 00    	and    $0x1ffff,%ecx
     d45:	44 0f af df          	imul   %edi,%r11d
     d49:	45 01 cb             	add    %r9d,%r11d
     d4c:	41 89 d1             	mov    %edx,%r9d
     d4f:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
     d55:	41 c1 e9 11          	shr    $0x11,%r9d
     d59:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
     d60:	45 01 cb             	add    %r9d,%r11d
     d63:	44 39 c1             	cmp    %r8d,%ecx
     d66:	0f 8c a4 04 00 00    	jl     1210 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1210>
     d6c:	41 39 d0             	cmp    %edx,%r8d
     d6f:	0f 8c 1b 05 00 00    	jl     1290 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1290>
     d75:	41 89 fe             	mov    %edi,%r14d
     d78:	41 89 f1             	mov    %esi,%r9d
     d7b:	45 01 d9             	add    %r11d,%r9d
     d7e:	49 63 d3             	movslq %r11d,%rdx
     d81:	41 01 f3             	add    %esi,%r11d
     d84:	4d 63 d1             	movslq %r9d,%r10
     d87:	41 01 fb             	add    %edi,%r11d
     d8a:	45 01 f1             	add    %r14d,%r9d
     d8d:	8b 14 93             	mov    (%rbx,%rdx,4),%edx
     d90:	46 8b 14 93          	mov    (%rbx,%r10,4),%r10d
     d94:	4d 63 c9             	movslq %r9d,%r9
     d97:	4d 63 db             	movslq %r11d,%r11
     d9a:	46 8b 0c 8b          	mov    (%rbx,%r9,4),%r9d
     d9e:	46 8b 5c 9b 04       	mov    0x4(%rbx,%r11,4),%r11d
     da3:	0f b6 f6             	movzbl %dh,%esi
     da6:	41 0f b6 da          	movzbl %r10b,%ebx
     daa:	89 9c 24 34 01 00 00 	mov    %ebx,0x134(%rsp)
     db1:	44 89 d3             	mov    %r10d,%ebx
     db4:	41 c1 ea 10          	shr    $0x10,%r10d
     db8:	45 0f b6 f1          	movzbl %r9b,%r14d
     dbc:	44 89 9c 24 e0 00 00 	mov    %r11d,0xe0(%rsp)
     dc3:	00 
     dc4:	45 0f b6 d2          	movzbl %r10b,%r10d
     dc8:	44 0f b6 da          	movzbl %dl,%r11d
     dcc:	c1 ea 10             	shr    $0x10,%edx
     dcf:	44 89 b4 24 38 01 00 	mov    %r14d,0x138(%rsp)
     dd6:	00 
     dd7:	0f b6 d2             	movzbl %dl,%edx
     dda:	45 89 d6             	mov    %r10d,%r14d
     ddd:	0f b6 ff             	movzbl %bh,%edi
     de0:	41 29 d6             	sub    %edx,%r14d
     de3:	44 89 cb             	mov    %r9d,%ebx
     de6:	41 c1 e9 10          	shr    $0x10,%r9d
     dea:	89 bc 24 3c 01 00 00 	mov    %edi,0x13c(%rsp)
     df1:	44 0f af f1          	imul   %ecx,%r14d
     df5:	45 0f b6 c9          	movzbl %r9b,%r9d
     df9:	c1 e2 10             	shl    $0x10,%edx
     dfc:	0f b6 ff             	movzbl %bh,%edi
     dff:	8b 9c 24 34 01 00 00 	mov    0x134(%rsp),%ebx
     e06:	44 01 f2             	add    %r14d,%edx
     e09:	45 89 ce             	mov    %r9d,%r14d
     e0c:	45 29 d6             	sub    %r10d,%r14d
     e0f:	44 0f b6 94 24 e0 00 	movzbl 0xe0(%rsp),%r10d
     e16:	00 00 
     e18:	45 0f af f0          	imul   %r8d,%r14d
     e1c:	41 01 d6             	add    %edx,%r14d
     e1f:	8b 94 24 e0 00 00 00 	mov    0xe0(%rsp),%edx
     e26:	c1 ea 10             	shr    $0x10,%edx
     e29:	0f b6 d2             	movzbl %dl,%edx
     e2c:	44 29 ca             	sub    %r9d,%edx
     e2f:	41 89 d9             	mov    %ebx,%r9d
     e32:	0f af 94 24 80 00 00 	imul   0x80(%rsp),%edx
     e39:	00 
     e3a:	45 29 d9             	sub    %r11d,%r9d
     e3d:	41 c1 e3 10          	shl    $0x10,%r11d
     e41:	44 0f af c9          	imul   %ecx,%r9d
     e45:	41 8d 94 16 00 80 00 	lea    0x8000(%r14,%rdx,1),%edx
     e4c:	00 
     e4d:	44 8b b4 24 38 01 00 	mov    0x138(%rsp),%r14d
     e54:	00 
     e55:	45 01 cb             	add    %r9d,%r11d
     e58:	66 31 d2             	xor    %dx,%dx
     e5b:	45 89 f1             	mov    %r14d,%r9d
     e5e:	45 29 f2             	sub    %r14d,%r10d
     e61:	44 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14d
     e68:	00 
     e69:	41 29 d9             	sub    %ebx,%r9d
     e6c:	8b 9c 24 3c 01 00 00 	mov    0x13c(%rsp),%ebx
     e73:	45 0f af c8          	imul   %r8d,%r9d
     e77:	45 0f af d6          	imul   %r14d,%r10d
     e7b:	45 01 d9             	add    %r11d,%r9d
     e7e:	44 8b 5c 24 60       	mov    0x60(%rsp),%r11d
     e83:	47 8d 8c 11 00 80 00 	lea    0x8000(%r9,%r10,1),%r9d
     e8a:	00 
     e8b:	41 c1 f9 10          	sar    $0x10,%r9d
     e8f:	44 09 ca             	or     %r9d,%edx
     e92:	41 89 d9             	mov    %ebx,%r9d
     e95:	41 29 f1             	sub    %esi,%r9d
     e98:	c1 e6 10             	shl    $0x10,%esi
     e9b:	44 0f af c9          	imul   %ecx,%r9d
     e9f:	89 f9                	mov    %edi,%ecx
     ea1:	44 01 ce             	add    %r9d,%esi
     ea4:	29 d9                	sub    %ebx,%ecx
     ea6:	8b 9c 24 e0 00 00 00 	mov    0xe0(%rsp),%ebx
     ead:	41 0f af c8          	imul   %r8d,%ecx
     eb1:	0f b6 df             	movzbl %bh,%ebx
     eb4:	29 fb                	sub    %edi,%ebx
     eb6:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
     ebd:	00 
     ebe:	41 0f af de          	imul   %r14d,%ebx
     ec2:	01 f1                	add    %esi,%ecx
     ec4:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
     ecb:	00 
     ecc:	8d 8c 19 00 80 00 00 	lea    0x8000(%rcx,%rbx,1),%ecx
     ed3:	c1 f9 10             	sar    $0x10,%ecx
     ed6:	c1 e1 08             	shl    $0x8,%ecx
     ed9:	09 d1                	or     %edx,%ecx
     edb:	0f b6 d2             	movzbl %dl,%edx
     ede:	44 8b 04 97          	mov    (%rdi,%rdx,4),%r8d
     ee2:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
     ee9:	00 
     eea:	0f b6 d5             	movzbl %ch,%edx
     eed:	c1 e9 10             	shr    $0x10,%ecx
     ef0:	44 8b 0c 8e          	mov    (%rsi,%rcx,4),%r9d
     ef4:	8b 14 97             	mov    (%rdi,%rdx,4),%edx
     ef7:	45 89 c2             	mov    %r8d,%r10d
     efa:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
     f01:	41 c1 ea 11          	shr    $0x11,%r10d
     f05:	45 89 ce             	mov    %r9d,%r14d
     f08:	89 d1                	mov    %edx,%ecx
     f0a:	45 0f af d5          	imul   %r13d,%r10d
     f0e:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
     f14:	41 81 e6 ff ff 01 00 	and    $0x1ffff,%r14d
     f1b:	c1 e9 11             	shr    $0x11,%ecx
     f1e:	41 0f af cb          	imul   %r11d,%ecx
     f22:	44 01 d1             	add    %r10d,%ecx
     f25:	45 89 ca             	mov    %r9d,%r10d
     f28:	41 c1 ea 11          	shr    $0x11,%r10d
     f2c:	44 01 d1             	add    %r10d,%ecx
     f2f:	41 39 d0             	cmp    %edx,%r8d
     f32:	0f 8c 28 03 00 00    	jl     1260 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1260>
     f38:	44 39 f2             	cmp    %r14d,%edx
     f3b:	0f 8c 1f 04 00 00    	jl     1360 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1360>
     f41:	41 89 d2             	mov    %edx,%r10d
     f44:	45 89 e9             	mov    %r13d,%r9d
     f47:	44 89 c2             	mov    %r8d,%edx
     f4a:	45 89 d0             	mov    %r10d,%r8d
     f4d:	41 01 c9             	add    %ecx,%r9d
     f50:	4c 63 d1             	movslq %ecx,%r10
     f53:	44 01 e9             	add    %r13d,%ecx
     f56:	42 8b 1c 90          	mov    (%rax,%r10,4),%ebx
     f5a:	4d 63 d1             	movslq %r9d,%r10
     f5d:	03 4c 24 60          	add    0x60(%rsp),%ecx
     f61:	45 01 d9             	add    %r11d,%r9d
     f64:	46 8b 14 90          	mov    (%rax,%r10,4),%r10d
     f68:	4d 63 c9             	movslq %r9d,%r9
     f6b:	48 63 c9             	movslq %ecx,%rcx
     f6e:	46 8b 0c 88          	mov    (%rax,%r9,4),%r9d
     f72:	8b 4c 88 04          	mov    0x4(%rax,%rcx,4),%ecx
     f76:	44 0f b6 db          	movzbl %bl,%r11d
     f7a:	41 0f b6 c2          	movzbl %r10b,%eax
     f7e:	89 44 24 60          	mov    %eax,0x60(%rsp)
     f82:	0f b6 c7             	movzbl %bh,%eax
     f85:	45 0f b6 e9          	movzbl %r9b,%r13d
     f89:	c1 eb 10             	shr    $0x10,%ebx
     f8c:	89 84 24 e0 00 00 00 	mov    %eax,0xe0(%rsp)
     f93:	44 89 d0             	mov    %r10d,%eax
     f96:	41 c1 ea 10          	shr    $0x10,%r10d
     f9a:	0f b6 fc             	movzbl %ah,%edi
     f9d:	45 0f b6 d2          	movzbl %r10b,%r10d
     fa1:	44 89 c8             	mov    %r9d,%eax
     fa4:	44 89 ac 24 80 00 00 	mov    %r13d,0x80(%rsp)
     fab:	00 
     fac:	0f b6 f4             	movzbl %ah,%esi
     faf:	45 89 d5             	mov    %r10d,%r13d
     fb2:	0f b6 c3             	movzbl %bl,%eax
     fb5:	41 c1 e9 10          	shr    $0x10,%r9d
     fb9:	41 29 c5             	sub    %eax,%r13d
     fbc:	45 0f b6 c9          	movzbl %r9b,%r9d
     fc0:	c1 e0 10             	shl    $0x10,%eax
     fc3:	8b 5c 24 60          	mov    0x60(%rsp),%ebx
     fc7:	44 0f af ea          	imul   %edx,%r13d
     fcb:	44 01 e8             	add    %r13d,%eax
     fce:	45 89 cd             	mov    %r9d,%r13d
     fd1:	45 29 d5             	sub    %r10d,%r13d
     fd4:	41 89 ca             	mov    %ecx,%r10d
     fd7:	45 0f af e8          	imul   %r8d,%r13d
     fdb:	41 c1 ea 10          	shr    $0x10,%r10d
     fdf:	41 01 c5             	add    %eax,%r13d
     fe2:	41 0f b6 c2          	movzbl %r10b,%eax
     fe6:	44 0f b6 d1          	movzbl %cl,%r10d
     fea:	0f b6 cd             	movzbl %ch,%ecx
     fed:	44 29 c8             	sub    %r9d,%eax
     ff0:	41 89 d9             	mov    %ebx,%r9d
     ff3:	41 0f af c6          	imul   %r14d,%eax
     ff7:	45 29 d9             	sub    %r11d,%r9d
     ffa:	41 c1 e3 10          	shl    $0x10,%r11d
     ffe:	44 0f af ca          	imul   %edx,%r9d
    1002:	41 8d 84 05 00 80 00 	lea    0x8000(%r13,%rax,1),%eax
    1009:	00 
    100a:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
    1011:	00 
    1012:	45 01 cb             	add    %r9d,%r11d
    1015:	66 31 c0             	xor    %ax,%ax
    1018:	45 89 e9             	mov    %r13d,%r9d
    101b:	45 29 ea             	sub    %r13d,%r10d
    101e:	41 29 d9             	sub    %ebx,%r9d
    1021:	45 0f af d6          	imul   %r14d,%r10d
    1025:	8b 9c 24 e0 00 00 00 	mov    0xe0(%rsp),%ebx
    102c:	45 0f af c8          	imul   %r8d,%r9d
    1030:	45 01 d9             	add    %r11d,%r9d
    1033:	44 8b 5c 24 20       	mov    0x20(%rsp),%r11d
    1038:	47 8d 8c 11 00 80 00 	lea    0x8000(%r9,%r10,1),%r9d
    103f:	00 
    1040:	44 8b 54 24 40       	mov    0x40(%rsp),%r10d
    1045:	41 c1 f9 10          	sar    $0x10,%r9d
    1049:	44 09 c8             	or     %r9d,%eax
    104c:	41 89 f9             	mov    %edi,%r9d
    104f:	41 29 d9             	sub    %ebx,%r9d
    1052:	c1 e3 10             	shl    $0x10,%ebx
    1055:	44 0f af ca          	imul   %edx,%r9d
    1059:	89 f2                	mov    %esi,%edx
    105b:	44 01 cb             	add    %r9d,%ebx
    105e:	29 fa                	sub    %edi,%edx
    1060:	29 f1                	sub    %esi,%ecx
    1062:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
    1069:	00 
    106a:	41 0f af d0          	imul   %r8d,%edx
    106e:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    1075:	00 
    1076:	41 0f af ce          	imul   %r14d,%ecx
    107a:	01 da                	add    %ebx,%edx
    107c:	8d 8c 0a 00 80 00 00 	lea    0x8000(%rdx,%rcx,1),%ecx
    1083:	c1 f9 10             	sar    $0x10,%ecx
    1086:	c1 e1 08             	shl    $0x8,%ecx
    1089:	09 c1                	or     %eax,%ecx
    108b:	0f b6 c0             	movzbl %al,%eax
    108e:	44 8b 04 86          	mov    (%rsi,%rax,4),%r8d
    1092:	0f b6 c5             	movzbl %ch,%eax
    1095:	c1 e9 10             	shr    $0x10,%ecx
    1098:	8b 14 87             	mov    (%rdi,%rax,4),%edx
    109b:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    10a2:	00 
    10a3:	44 8b 0c 88          	mov    (%rax,%rcx,4),%r9d
    10a7:	44 89 c1             	mov    %r8d,%ecx
    10aa:	89 d0                	mov    %edx,%eax
    10ac:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
    10b3:	c1 e9 11             	shr    $0x11,%ecx
    10b6:	c1 e8 11             	shr    $0x11,%eax
    10b9:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
    10bf:	41 0f af c3          	imul   %r11d,%eax
    10c3:	41 0f af ca          	imul   %r10d,%ecx
    10c7:	01 c1                	add    %eax,%ecx
    10c9:	44 89 c8             	mov    %r9d,%eax
    10cc:	41 81 e1 ff ff 01 00 	and    $0x1ffff,%r9d
    10d3:	c1 e8 11             	shr    $0x11,%eax
    10d6:	01 c1                	add    %eax,%ecx
    10d8:	41 39 d0             	cmp    %edx,%r8d
    10db:	0f 8c 4f 01 00 00    	jl     1230 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1230>
    10e1:	44 39 ca             	cmp    %r9d,%edx
    10e4:	0f 8c 56 02 00 00    	jl     1340 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1340>
    10ea:	89 d0                	mov    %edx,%eax
    10ec:	44 89 c2             	mov    %r8d,%edx
    10ef:	41 89 c0             	mov    %eax,%r8d
    10f2:	41 01 ca             	add    %ecx,%r10d
    10f5:	48 63 c1             	movslq %ecx,%rax
    10f8:	03 4c 24 40          	add    0x40(%rsp),%ecx
    10fc:	49 63 da             	movslq %r10d,%rbx
    10ff:	45 01 da             	add    %r11d,%r10d
    1102:	44 8b 74 85 00       	mov    0x0(%rbp,%rax,4),%r14d
    1107:	03 4c 24 20          	add    0x20(%rsp),%ecx
    110b:	4d 63 d2             	movslq %r10d,%r10
    110e:	8b 5c 9d 00          	mov    0x0(%rbp,%rbx,4),%ebx
    1112:	48 63 c9             	movslq %ecx,%rcx
    1115:	46 8b 5c 95 00       	mov    0x0(%rbp,%r10,4),%r11d
    111a:	8b 4c 8d 04          	mov    0x4(%rbp,%rcx,4),%ecx
    111e:	45 0f b6 d6          	movzbl %r14b,%r10d
    1122:	44 0f b6 eb          	movzbl %bl,%r13d
    1126:	0f b6 ef             	movzbl %bh,%ebp
    1129:	c1 eb 10             	shr    $0x10,%ebx
    112c:	41 0f b6 c3          	movzbl %r11b,%eax
    1130:	0f b6 db             	movzbl %bl,%ebx
    1133:	89 44 24 20          	mov    %eax,0x20(%rsp)
    1137:	44 89 f0             	mov    %r14d,%eax
    113a:	0f b6 f4             	movzbl %ah,%esi
    113d:	44 89 d8             	mov    %r11d,%eax
    1140:	41 c1 eb 10          	shr    $0x10,%r11d
    1144:	0f b6 fc             	movzbl %ah,%edi
    1147:	44 89 f0             	mov    %r14d,%eax
    114a:	41 89 de             	mov    %ebx,%r14d
    114d:	45 0f b6 db          	movzbl %r11b,%r11d
    1151:	c1 e8 10             	shr    $0x10,%eax
    1154:	0f b6 c0             	movzbl %al,%eax
    1157:	41 29 c6             	sub    %eax,%r14d
    115a:	c1 e0 10             	shl    $0x10,%eax
    115d:	44 0f af f2          	imul   %edx,%r14d
    1161:	44 01 f0             	add    %r14d,%eax
    1164:	45 89 de             	mov    %r11d,%r14d
    1167:	41 29 de             	sub    %ebx,%r14d
    116a:	8b 5c 24 20          	mov    0x20(%rsp),%ebx
    116e:	45 0f af f0          	imul   %r8d,%r14d
    1172:	41 01 c6             	add    %eax,%r14d
    1175:	89 c8                	mov    %ecx,%eax
    1177:	c1 e8 10             	shr    $0x10,%eax
    117a:	0f b6 c0             	movzbl %al,%eax
    117d:	44 29 d8             	sub    %r11d,%eax
    1180:	45 89 eb             	mov    %r13d,%r11d
    1183:	45 29 d3             	sub    %r10d,%r11d
    1186:	41 c1 e2 10          	shl    $0x10,%r10d
    118a:	41 0f af c1          	imul   %r9d,%eax
    118e:	44 0f af da          	imul   %edx,%r11d
    1192:	41 8d 84 06 00 80 00 	lea    0x8000(%r14,%rax,1),%eax
    1199:	00 
    119a:	45 01 da             	add    %r11d,%r10d
    119d:	41 89 db             	mov    %ebx,%r11d
    11a0:	66 31 c0             	xor    %ax,%ax
    11a3:	45 29 eb             	sub    %r13d,%r11d
    11a6:	45 0f af d8          	imul   %r8d,%r11d
    11aa:	45 01 da             	add    %r11d,%r10d
    11ad:	44 0f b6 d9          	movzbl %cl,%r11d
    11b1:	0f b6 cd             	movzbl %ch,%ecx
    11b4:	41 29 db             	sub    %ebx,%r11d
    11b7:	45 0f af d9          	imul   %r9d,%r11d
    11bb:	47 8d 94 1a 00 80 00 	lea    0x8000(%r10,%r11,1),%r10d
    11c2:	00 
    11c3:	41 c1 fa 10          	sar    $0x10,%r10d
    11c7:	44 09 d0             	or     %r10d,%eax
    11ca:	41 89 ea             	mov    %ebp,%r10d
    11cd:	41 29 f2             	sub    %esi,%r10d
    11d0:	c1 e6 10             	shl    $0x10,%esi
    11d3:	41 0f af d2          	imul   %r10d,%edx
    11d7:	01 d6                	add    %edx,%esi
    11d9:	89 fa                	mov    %edi,%edx
    11db:	29 f9                	sub    %edi,%ecx
    11dd:	29 ea                	sub    %ebp,%edx
    11df:	41 0f af c9          	imul   %r9d,%ecx
    11e3:	41 0f af d0          	imul   %r8d,%edx
    11e7:	01 d6                	add    %edx,%esi
    11e9:	8d 94 0e 00 80 00 00 	lea    0x8000(%rsi,%rcx,1),%edx
    11f0:	c1 fa 10             	sar    $0x10,%edx
    11f3:	c1 e2 08             	shl    $0x8,%edx
    11f6:	09 d0                	or     %edx,%eax
    11f8:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    11fc:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1201:	e9 74 f5 ff ff       	jmp    77a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x77a>
    1206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    120d:	00 00 00 
    1210:	41 89 fe             	mov    %edi,%r14d
    1213:	3b 8c 24 80 00 00 00 	cmp    0x80(%rsp),%ecx
    121a:	7c 7f                	jl     129b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x129b>
    121c:	89 ca                	mov    %ecx,%edx
    121e:	41 89 f6             	mov    %esi,%r14d
    1221:	44 89 c1             	mov    %r8d,%ecx
    1224:	41 89 f9             	mov    %edi,%r9d
    1227:	41 89 d0             	mov    %edx,%r8d
    122a:	e9 4c fb ff ff       	jmp    d7b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7b>
    122f:	90                   	nop
    1230:	45 39 c8             	cmp    %r9d,%r8d
    1233:	0f 8d 17 01 00 00    	jge    1350 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1350>
    1239:	89 d0                	mov    %edx,%eax
    123b:	44 89 c2             	mov    %r8d,%edx
    123e:	41 89 c0             	mov    %eax,%r8d
    1241:	45 39 c1             	cmp    %r8d,%r9d
    1244:	0f 8e 31 01 00 00    	jle    137b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x137b>
    124a:	89 d0                	mov    %edx,%eax
    124c:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    1252:	44 89 ca             	mov    %r9d,%edx
    1255:	41 89 c1             	mov    %eax,%r9d
    1258:	e9 95 fe ff ff       	jmp    10f2 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f2>
    125d:	0f 1f 00             	nopl   (%rax)
    1260:	45 39 f0             	cmp    %r14d,%r8d
    1263:	0f 8d 07 01 00 00    	jge    1370 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1370>
    1269:	41 89 d1             	mov    %edx,%r9d
    126c:	44 89 c2             	mov    %r8d,%edx
    126f:	45 89 c8             	mov    %r9d,%r8d
    1272:	45 39 c6             	cmp    %r8d,%r14d
    1275:	0f 8e 3b 01 00 00    	jle    13b6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x13b6>
    127b:	41 89 d1             	mov    %edx,%r9d
    127e:	44 89 f2             	mov    %r14d,%edx
    1281:	45 89 ce             	mov    %r9d,%r14d
    1284:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    128a:	e9 be fc ff ff       	jmp    f4d <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf4d>
    128f:	90                   	nop
    1290:	89 ca                	mov    %ecx,%edx
    1292:	41 89 f6             	mov    %esi,%r14d
    1295:	44 89 c1             	mov    %r8d,%ecx
    1298:	41 89 d0             	mov    %edx,%r8d
    129b:	44 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10d
    12a2:	00 
    12a3:	45 39 c2             	cmp    %r8d,%r10d
    12a6:	0f 8e e8 00 00 00    	jle    1394 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1394>
    12ac:	89 8c 24 80 00 00 00 	mov    %ecx,0x80(%rsp)
    12b3:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    12b9:	44 89 d1             	mov    %r10d,%ecx
    12bc:	e9 ba fa ff ff       	jmp    d7b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7b>
    12c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    12c8:	c5 f8 77             	vzeroupper
    12cb:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
    12d2:	00 00 
    12d4:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
    12db:	00 00 
    12dd:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
    12e4:	00 00 
    12e6:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
    12ed:	00 00 
    12ef:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
    12f6:	00 00 
    12f8:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
    12ff:	00 00 
    1301:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
    1308:	00 00 
    130a:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
    1311:	00 00 
    1313:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
    131a:	00 00 
    131c:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
    1323:	00 00 
    1325:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    132c:	5b                   	pop    %rbx
    132d:	5e                   	pop    %rsi
    132e:	5f                   	pop    %rdi
    132f:	5d                   	pop    %rbp
    1330:	41 5c                	pop    %r12
    1332:	41 5d                	pop    %r13
    1334:	41 5e                	pop    %r14
    1336:	41 5f                	pop    %r15
    1338:	c3                   	ret
    1339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1340:	45 89 d3             	mov    %r10d,%r11d
    1343:	e9 f9 fe ff ff       	jmp    1241 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1241>
    1348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    134f:	00 
    1350:	45 89 d3             	mov    %r10d,%r11d
    1353:	44 8b 54 24 20       	mov    0x20(%rsp),%r10d
    1358:	e9 95 fd ff ff       	jmp    10f2 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f2>
    135d:	0f 1f 00             	nopl   (%rax)
    1360:	45 89 eb             	mov    %r13d,%r11d
    1363:	e9 0a ff ff ff       	jmp    1272 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1272>
    1368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    136f:	00 
    1370:	45 89 d9             	mov    %r11d,%r9d
    1373:	45 89 eb             	mov    %r13d,%r11d
    1376:	e9 d2 fb ff ff       	jmp    f4d <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf4d>
    137b:	89 d0                	mov    %edx,%eax
    137d:	45 89 da             	mov    %r11d,%r10d
    1380:	44 89 c2             	mov    %r8d,%edx
    1383:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1389:	45 89 c8             	mov    %r9d,%r8d
    138c:	41 89 c1             	mov    %eax,%r9d
    138f:	e9 5e fd ff ff       	jmp    10f2 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f2>
    1394:	89 ca                	mov    %ecx,%edx
    1396:	45 89 f1             	mov    %r14d,%r9d
    1399:	44 89 c1             	mov    %r8d,%ecx
    139c:	41 be 01 00 00 00    	mov    $0x1,%r14d
    13a2:	44 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8d
    13a9:	00 
    13aa:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
    13b1:	e9 c5 f9 ff ff       	jmp    d7b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7b>
    13b6:	41 89 d2             	mov    %edx,%r10d
    13b9:	45 89 d9             	mov    %r11d,%r9d
    13bc:	44 89 c2             	mov    %r8d,%edx
    13bf:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    13c5:	45 89 f0             	mov    %r14d,%r8d
    13c8:	45 89 d6             	mov    %r10d,%r14d
    13cb:	e9 7d fb ff ff       	jmp    f4d <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf4d>

00000000000013d0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)>:
    13d0:	41 57                	push   %r15
    13d2:	41 56                	push   %r14
    13d4:	41 55                	push   %r13
    13d6:	41 54                	push   %r12
    13d8:	55                   	push   %rbp
    13d9:	57                   	push   %rdi
    13da:	56                   	push   %rsi
    13db:	53                   	push   %rbx
    13dc:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    13e3:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
    13ea:	00 00 
    13ec:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
    13f3:	00 00 
    13f5:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
    13fc:	00 00 
    13fe:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
    1405:	00 00 
    1407:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
    140e:	00 00 
    1410:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
    1417:	00 00 
    1419:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
    1420:	00 00 
    1422:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
    1429:	00 00 
    142b:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
    1432:	00 00 
    1434:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
    143b:	00 00 
    143d:	49 89 cf             	mov    %rcx,%r15
    1440:	4d 85 c0             	test   %r8,%r8
    1443:	0f 84 52 12 00 00    	je     269b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x12cb>
    1449:	49 ff c8             	dec    %r8
    144c:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    1451:	49 89 d4             	mov    %rdx,%r12
    1454:	49 c1 e8 03          	shr    $0x3,%r8
    1458:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
    145e:	4b 8d 04 40          	lea    (%r8,%r8,2),%rax
    1462:	48 8d 44 c2 18       	lea    0x18(%rdx,%rax,8),%rax
    1467:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    146e:	00 
    146f:	b8 00 80 00 00       	mov    $0x8000,%eax
    1474:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    1478:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    147d:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    1482:	e9 04 07 00 00       	jmp    1b8b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7bb>
    1487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    148e:	00 00 
    1490:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    1497:	00 00 
    1499:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    149d:	c5 79 6e ef          	vmovd  %edi,%xmm13
    14a1:	c5 79 6e ce          	vmovd  %esi,%xmm9
    14a5:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    14aa:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    14af:	8d 54 37 01          	lea    0x1(%rdi,%rsi,1),%edx
    14b3:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
    14ba:	00 
    14bb:	c4 e2 45 90 1c a1    	vpgatherdd %ymm7,(%rcx,%ymm4,4),%ymm3
    14c1:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    14c5:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    14c9:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
    14d0:	00 
    14d1:	c4 c2 45 90 2c 80    	vpgatherdd %ymm7,(%r8,%ymm0,4),%ymm5
    14d7:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    14db:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    14e0:	c4 c2 45 90 34 89    	vpgatherdd %ymm7,(%r9,%ymm1,4),%ymm6
    14e6:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    14eb:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    14ef:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    14f4:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    14f9:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1561 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x191>
    1500:	00 
    1501:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    1506:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    150b:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1573 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1a3>
    1512:	00 
    1513:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 157b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1ab>
    151a:	00 
    151b:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    1520:	c4 62 65 39 e5       	vpminsd %ymm5,%ymm3,%ymm12
    1525:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    152a:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    152e:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1532:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1536:	c5 dd fe d1          	vpaddd %ymm1,%ymm4,%ymm2
    153a:	c4 e2 45 90 04 8b    	vpgatherdd %ymm7,(%rbx,%ymm1,4),%ymm0
    1540:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1544:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    154b:	00 00 
    154d:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    1551:	c4 62 45 90 3c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm15
    1557:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    155b:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1560:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    1564:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    1569:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
    1570:	00 00 
    1572:	c4 c3 35 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm9,%ymm2
    1578:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 15a1 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1d1>
    157f:	00 00 70 
    1582:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    1587:	c4 43 35 4c cd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm9
    158d:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    1592:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1596:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm9,%ymm9        # 15bf <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1ef>
    159d:	00 00 c0 
    15a0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    15a4:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    15a8:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    15ac:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    15b0:	c4 e2 5d 90 14 8b    	vpgatherdd %ymm4,(%rbx,%ymm1,4),%ymm2
    15b6:	c4 c1 55 fa e1       	vpsubd %ymm9,%ymm5,%ymm4
    15bb:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    15c0:	c4 e2 4d 90 1c a3    	vpgatherdd %ymm6,(%rbx,%ymm4,4),%ymm3
    15c6:	c4 41 6d db ce       	vpand  %ymm14,%ymm2,%ymm9
    15cb:	c4 c1 05 db e6       	vpand  %ymm14,%ymm15,%ymm4
    15d0:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    15d5:	c4 c1 65 db ce       	vpand  %ymm14,%ymm3,%ymm1
    15da:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    15de:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    15e2:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    15e7:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    15ec:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    15f1:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    15f6:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    15fb:	c5 9d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm12
    1600:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1605:	c4 41 1d db e6       	vpand  %ymm14,%ymm12,%ymm12
    160a:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    160f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1613:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1617:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    161c:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1620:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    1625:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    162a:	c4 c1 75 72 d7 08    	vpsrld $0x8,%ymm15,%ymm1
    1630:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    1635:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    163a:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    163f:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    1643:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
    1648:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    164d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1652:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1656:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    165b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1660:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    1665:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    166a:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    166f:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    1674:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1678:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    167d:	c4 41 79 6e cd       	vmovd  %r13d,%xmm9
    1682:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1686:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    168b:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1690:	c4 c1 7d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm0
    1696:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    169b:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    169f:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    16a4:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    16a9:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    16ae:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    16b2:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    16b6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    16bb:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    16c0:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    16c5:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    16c9:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    16cd:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    16d1:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    16d5:	c4 e2 45 90 1c a7    	vpgatherdd %ymm7,(%rdi,%ymm4,4),%ymm3
    16db:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
    16e2:	00 
    16e3:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    16e7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    16ec:	c4 e2 45 90 2c 8f    	vpgatherdd %ymm7,(%rdi,%ymm1,4),%ymm5
    16f2:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    16f6:	c4 e2 45 90 34 86    	vpgatherdd %ymm7,(%rsi,%ymm0,4),%ymm6
    16fc:	8b 7c 24 60          	mov    0x60(%rsp),%edi
    1700:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    1705:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1709:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    170e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1713:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 177b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3ab>
    171a:	00 
    171b:	8b 74 24 40          	mov    0x40(%rsp),%esi
    171f:	c5 79 6e ef          	vmovd  %edi,%xmm13
    1723:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1728:	42 8d 54 2f 01       	lea    0x1(%rdi,%r13,1),%edx
    172d:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    1732:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    1736:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 179e <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3ce>
    173d:	00 
    173e:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    1743:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1748:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 17b0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x3e0>
    174f:	00 
    1750:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    1755:	c4 62 65 39 e5       	vpminsd %ymm5,%ymm3,%ymm12
    175a:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    175f:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1763:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1767:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    176b:	c5 dd fe d1          	vpaddd %ymm1,%ymm4,%ymm2
    176f:	c4 e2 45 90 04 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm0
    1775:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1779:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
    177f:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    1783:	c4 62 45 90 3c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm15
    1789:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    178d:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1792:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    1796:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    179b:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
    17a1:	c4 c3 35 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm9,%ymm2
    17a7:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 17d0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x400>
    17ae:	00 00 70 
    17b1:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    17b6:	c4 43 35 4c cd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm9
    17bc:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    17c1:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    17c5:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm9,%ymm9        # 17ee <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x41e>
    17cc:	00 00 c0 
    17cf:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    17d3:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    17d7:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    17db:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
    17e1:	c4 c1 55 fa e1       	vpsubd %ymm9,%ymm5,%ymm4
    17e6:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    17ea:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    17f0:	c4 41 6d db ce       	vpand  %ymm14,%ymm2,%ymm9
    17f5:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    17fa:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    1801:	00 
    1802:	c4 c1 65 db ce       	vpand  %ymm14,%ymm3,%ymm1
    1807:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    180c:	c4 c1 05 db e6       	vpand  %ymm14,%ymm15,%ymm4
    1811:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1815:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    1819:	c5 9d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm12
    181e:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    1823:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1828:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    182d:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    1832:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1837:	c4 41 1d db e6       	vpand  %ymm14,%ymm12,%ymm12
    183c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1841:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    1846:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    184a:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    184e:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    1853:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1857:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    185c:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    1861:	c4 c1 75 72 d7 08    	vpsrld $0x8,%ymm15,%ymm1
    1867:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    186c:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    1871:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1876:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    187a:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
    187f:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1884:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1889:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    188d:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1892:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1897:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    189c:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    18a1:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    18a6:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    18ab:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    18af:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    18b4:	c5 79 6e ce          	vmovd  %esi,%xmm9
    18b8:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    18bc:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    18c1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    18c6:	c4 c1 7d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm0
    18cc:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    18d1:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    18d5:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    18da:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    18df:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    18e4:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    18e8:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    18ec:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    18f1:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    18f6:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    18fb:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    18ff:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    1903:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1907:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    190b:	c4 e2 45 90 1c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm3
    1911:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
    1918:	00 
    1919:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    191d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1922:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1926:	c4 e2 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm5
    192c:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    1933:	00 
    1934:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1938:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    193d:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 19a5 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x5d5>
    1944:	00 
    1945:	c4 e2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm6
    194b:	8b 44 24 20          	mov    0x20(%rsp),%eax
    194f:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    1954:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 19bc <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x5ec>
    195b:	00 
    195c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1961:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1966:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 19ce <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x5fe>
    196d:	00 
    196e:	c5 79 6e e8          	vmovd  %eax,%xmm13
    1972:	8d 44 30 01          	lea    0x1(%rax,%rsi,1),%eax
    1976:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    197b:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    1980:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    1984:	c4 62 65 39 e5       	vpminsd %ymm5,%ymm3,%ymm12
    1989:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    198e:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1993:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    1998:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    199c:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    19a0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    19a4:	c5 dd fe d1          	vpaddd %ymm1,%ymm4,%ymm2
    19a8:	c4 e2 45 90 44 8d 00 	vpgatherdd %ymm7,0x0(%rbp,%ymm1,4),%ymm0
    19af:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    19b3:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    19b9:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    19bd:	c4 62 45 90 7c 95 00 	vpgatherdd %ymm7,0x0(%rbp,%ymm2,4),%ymm15
    19c4:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    19c8:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    19cd:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    19d1:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    19d6:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    19dc:	c4 c3 35 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm9,%ymm2
    19e2:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1a0b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x63b>
    19e9:	00 00 70 
    19ec:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    19f1:	c4 43 35 4c cd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm9
    19f7:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    19fc:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1a00:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm9,%ymm9        # 1a29 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x659>
    1a07:	00 00 c0 
    1a0a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1a0e:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    1a12:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1a16:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1a1a:	c4 e2 5d 90 54 8d 00 	vpgatherdd %ymm4,0x0(%rbp,%ymm1,4),%ymm2
    1a21:	c4 c1 55 fa e1       	vpsubd %ymm9,%ymm5,%ymm4
    1a26:	c4 c1 05 db de       	vpand  %ymm14,%ymm15,%ymm3
    1a2b:	c4 e2 4d 90 6c a5 00 	vpgatherdd %ymm6,0x0(%rbp,%ymm4,4),%ymm5
    1a32:	c4 41 6d db ce       	vpand  %ymm14,%ymm2,%ymm9
    1a37:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
    1a3c:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    1a41:	c4 c1 55 db ce       	vpand  %ymm14,%ymm5,%ymm1
    1a46:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
    1a4a:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    1a4e:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    1a53:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1a58:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1a5d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1a62:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    1a67:	c5 9d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm12
    1a6c:	c4 41 0d db e4       	vpand  %ymm12,%ymm14,%ymm12
    1a71:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1a75:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    1a79:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    1a7e:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    1a82:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    1a87:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    1a8c:	c4 c1 75 72 d7 08    	vpsrld $0x8,%ymm15,%ymm1
    1a92:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    1a97:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    1a9c:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1aa1:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    1aa5:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
    1aaa:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1aaf:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1ab4:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    1ab8:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1abd:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    1ac2:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    1ac7:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1acc:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1ad1:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    1ad6:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1adb:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1adf:	c5 cd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm6
    1ae4:	c4 c1 6d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm2
    1aea:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    1aef:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    1af4:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    1af9:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1afd:	c5 dd 72 f0 10       	vpslld $0x10,%ymm0,%ymm4
    1b02:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1b06:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
    1b0a:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    1b0e:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    1b13:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
    1b18:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1b1d:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    1b22:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1b27:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1b2b:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1b2f:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    1b34:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1b38:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1b3d:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    1b42:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1b46:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    1b4a:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 1b93 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7c3>
    1b51:	00 00 
    1b53:	49 83 c4 18          	add    $0x18,%r12
    1b57:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1b5b:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1b61:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1b66:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1b6b:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1b6f:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    1b76:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
    1b7d:	4c 3b a4 24 28 01 00 	cmp    0x128(%rsp),%r12
    1b84:	00 
    1b85:	0f 84 0d 0b 00 00    	je     2698 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x12c8>
    1b8b:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
    1b91:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
    1b98:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1b9c:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    1ba1:	49 8b 07             	mov    (%r15),%rax
    1ba4:	41 8b 4f 54          	mov    0x54(%r15),%ecx
    1ba8:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    1bad:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    1bb2:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1bb8:	41 8b 57 50          	mov    0x50(%r15),%edx
    1bbc:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1bc2:	c5 79 6e f9          	vmovd  %ecx,%xmm15
    1bc6:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 1bcf <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x7ff>
    1bcd:	00 00 
    1bcf:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    1bd3:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
    1bd8:	c4 c1 7d db de       	vpand  %ymm14,%ymm0,%ymm3
    1bdd:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    1be2:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1be7:	c4 e2 45 90 2c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm5
    1bed:	49 8b 47 08          	mov    0x8(%r15),%rax
    1bf1:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    1bf6:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1bfa:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1bff:	c5 bd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm8
    1c04:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1c08:	c4 e2 45 90 14 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm2
    1c0e:	49 8b 47 10          	mov    0x10(%r15),%rax
    1c12:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1c16:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1c7e <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x8ae>
    1c1d:	00 
    1c1e:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
    1c23:	c4 e2 45 90 04 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm0
    1c29:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
    1c2e:	49 8b 47 48          	mov    0x48(%r15),%rax
    1c32:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1c9a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x8ca>
    1c39:	00 
    1c3a:	c4 c2 45 40 ff       	vpmulld %ymm15,%ymm7,%ymm7
    1c3f:	c5 b5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm9
    1c44:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1cac <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x8dc>
    1c4b:	00 
    1c4c:	c4 c1 45 fe f8       	vpaddd %ymm8,%ymm7,%ymm7
    1c51:	c4 41 45 fe c9       	vpaddd %ymm9,%ymm7,%ymm9
    1c56:	c4 a2 2d 90 3c 88    	vpgatherdd %ymm10,(%rax,%ymm9,4),%ymm7
    1c5c:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    1c62:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    1c66:	49 8b 57 18          	mov    0x18(%r15),%rdx
    1c6a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1c6f:	c4 41 45 fe c1       	vpaddd %ymm9,%ymm7,%ymm8
    1c74:	c4 22 1d 90 14 80    	vpgatherdd %ymm12,(%rax,%ymm8,4),%ymm10
    1c7a:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    1c81:	00 00 
    1c83:	c4 62 15 90 24 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm12
    1c89:	49 8b 57 20          	mov    0x20(%r15),%rdx
    1c8d:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1c91:	c4 62 65 90 14 b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm10
    1c97:	49 8b 57 28          	mov    0x28(%r15),%rdx
    1c9b:	c5 ed 66 dd          	vpcmpgtd %ymm5,%ymm2,%ymm3
    1c9f:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1ca3:	c4 62 4d 90 2c 8a    	vpgatherdd %ymm6,(%rdx,%ymm1,4),%ymm13
    1ca9:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    1caf:	c4 e2 55 3d f2       	vpmaxsd %ymm2,%ymm5,%ymm6
    1cb4:	c5 fd 66 ce          	vpcmpgtd %ymm6,%ymm0,%ymm1
    1cb8:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    1cbe:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
    1cc3:	c5 7e 7f 4c 24 40    	vmovdqu %ymm9,0x40(%rsp)
    1cc9:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1cd0:	00 00 
    1cd2:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1cd6:	c4 c3 45 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm7,%ymm3
    1cdc:	c4 e2 55 39 fa       	vpminsd %ymm2,%ymm5,%ymm7
    1ce1:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm3,%ymm3        # 1d0a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x93a>
    1ce8:	00 00 10 
    1ceb:	c4 e2 45 39 e0       	vpminsd %ymm0,%ymm7,%ymm4
    1cf0:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
    1cf5:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
    1cf9:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    1cff:	c4 e2 4d 90 0c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm1
    1d05:	c5 d5 66 da          	vpcmpgtd %ymm2,%ymm5,%ymm3
    1d09:	c5 7e 7f 84 24 80 00 	vmovdqu %ymm8,0x80(%rsp)
    1d10:	00 00 
    1d12:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1d16:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1d1b:	c4 c3 35 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm9,%ymm3
    1d21:	c5 55 fe ca          	vpaddd %ymm2,%ymm5,%ymm9
    1d25:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 1d4e <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x97e>
    1d2c:	00 00 70 
    1d2f:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
    1d33:	c5 7d 6f c4          	vmovdqa %ymm4,%ymm8
    1d37:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    1d3d:	c5 fe 7f a4 24 c0 00 	vmovdqu %ymm4,0xc0(%rsp)
    1d44:	00 00 
    1d46:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    1d4d:	00 00 
    1d4f:	c5 8d db 74 24 60    	vpand  0x60(%rsp),%ymm14,%ymm6
    1d55:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
    1d5a:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
    1d5e:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    1d63:	c4 41 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm8
    1d68:	c5 e5 fe 1c 24       	vpaddd (%rsp),%ymm3,%ymm3
    1d6d:	c4 41 3d fe c9       	vpaddd %ymm9,%ymm8,%ymm9
    1d72:	c5 45 fa c1          	vpsubd %ymm1,%ymm7,%ymm8
    1d76:	c4 42 35 40 c0       	vpmulld %ymm8,%ymm9,%ymm8
    1d7b:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1d7f:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    1d84:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1d88:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    1d8c:	c5 0d db 84 24 a0 00 	vpand  0xa0(%rsp),%ymm14,%ymm8
    1d93:	00 00 
    1d95:	c5 3d fa c7          	vpsubd %ymm7,%ymm8,%ymm8
    1d99:	c4 c1 45 72 e2 10    	vpsrad $0x10,%ymm10,%ymm7
    1d9f:	c4 62 3d 40 84 24 c0 	vpmulld 0xc0(%rsp),%ymm8,%ymm8
    1da6:	00 00 00 
    1da9:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    1dad:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
    1db1:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1db6:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    1dbb:	c4 c1 65 72 f5 10    	vpslld $0x10,%ymm13,%ymm3
    1dc1:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    1dc8:	00 00 
    1dca:	c4 c1 4d 72 e4 10    	vpsrad $0x10,%ymm12,%ymm6
    1dd0:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1dd5:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1dd9:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    1ddd:	c5 cd fe cf          	vpaddd %ymm7,%ymm6,%ymm1
    1de1:	c5 fe 7f 8c 24 e0 00 	vmovdqu %ymm1,0xe0(%rsp)
    1de8:	00 00 
    1dea:	c4 c1 75 72 e5 10    	vpsrad $0x10,%ymm13,%ymm1
    1df0:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    1df6:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1dfa:	c4 c1 7d 72 f2 10    	vpslld $0x10,%ymm10,%ymm0
    1e00:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    1e05:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1e09:	c4 c1 6d 72 f4 10    	vpslld $0x10,%ymm12,%ymm2
    1e0f:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    1e14:	c5 65 fe d0          	vpaddd %ymm0,%ymm3,%ymm10
    1e18:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1e1c:	c5 7d 66 e2          	vpcmpgtd %ymm2,%ymm0,%ymm12
    1e20:	c4 62 6d 3d c0       	vpmaxsd %ymm0,%ymm2,%ymm8
    1e25:	c4 c1 65 66 e8       	vpcmpgtd %ymm8,%ymm3,%ymm5
    1e2a:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    1e2f:	c4 43 15 4c e7 c0    	vpblendvb %ymm12,%ymm15,%ymm13,%ymm12
    1e35:	c4 62 6d 39 e8       	vpminsd %ymm0,%ymm2,%ymm13
    1e3a:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    1e3e:	c4 62 15 39 cb       	vpminsd %ymm3,%ymm13,%ymm9
    1e43:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm12,%ymm12        # 1e6c <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xa9c>
    1e4a:	00 00 50 
    1e4d:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    1e51:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1e57:	c5 1d fe 64 24 40    	vpaddd 0x40(%rsp),%ymm12,%ymm12
    1e5d:	c4 c3 65 4c c7 00    	vpblendvb %ymm0,%ymm15,%ymm3,%ymm0
    1e63:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
    1e6a:	00 00 
    1e6c:	c4 a2 5d 90 2c a0    	vpgatherdd %ymm4,(%rax,%ymm12,4),%ymm5
    1e72:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1e76:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 1e9f <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xacf>
    1e7d:	00 00 d0 
    1e80:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    1e85:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1e89:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    1e8e:	c4 62 5d 90 24 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm12
    1e94:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
    1e9a:	c4 c1 3d fe e1       	vpaddd %ymm9,%ymm8,%ymm4
    1e9f:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    1ea5:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1ea9:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1ead:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    1eb2:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
    1eb9:	00 00 
    1ebb:	c4 41 1d db e6       	vpand  %ymm14,%ymm12,%ymm12
    1ec0:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1ec5:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    1eca:	c5 1d fa d5          	vpsubd %ymm5,%ymm12,%ymm10
    1ece:	49 8b af 68 01 00 00 	mov    0x168(%r15),%rbp
    1ed5:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1eda:	c4 42 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm10
    1edf:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    1ee4:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1ee9:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    1eee:	c4 62 4d 39 c7       	vpminsd %ymm7,%ymm6,%ymm8
    1ef3:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    1ef8:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    1efe:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1f03:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    1f08:	c4 62 3d 39 c9       	vpminsd %ymm1,%ymm8,%ymm9
    1f0d:	c5 3d 66 c1          	vpcmpgtd %ymm1,%ymm8,%ymm8
    1f11:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    1f15:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
    1f1b:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    1f1f:	c4 e2 4d 3d ef       	vpmaxsd %ymm7,%ymm6,%ymm5
    1f24:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1f28:	c5 c5 66 de          	vpcmpgtd %ymm6,%ymm7,%ymm3
    1f2c:	c5 f5 66 d5          	vpcmpgtd %ymm5,%ymm1,%ymm2
    1f30:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    1f34:	c4 e2 55 3d e9       	vpmaxsd %ymm1,%ymm5,%ymm5
    1f39:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    1f3f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1f44:	c4 c3 2d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm10,%ymm3
    1f4a:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm3,%ymm3        # 1f73 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xba3>
    1f51:	00 00 20 
    1f54:	c5 e5 fe 5c 24 40    	vpaddd 0x40(%rsp),%ymm3,%ymm3
    1f5a:	c4 e2 5d 90 14 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm2
    1f60:	c4 c3 2d 4c e7 60    	vpblendvb %ymm6,%ymm15,%ymm10,%ymm4
    1f66:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
    1f6d:	00 00 
    1f6f:	c5 7e 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm10
    1f76:	00 00 
    1f78:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm4,%ymm4        # 1fa1 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xbd1>
    1f7f:	00 00 80 
    1f82:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1f87:	c4 41 55 fe c1       	vpaddd %ymm9,%ymm5,%ymm8
    1f8c:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    1f90:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1f94:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    1f99:	c4 e2 5d 90 34 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm6
    1f9f:	c5 e5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm3
    1fa4:	c5 f5 fe 8c 24 e0 00 	vpaddd 0xe0(%rsp),%ymm1,%ymm1
    1fab:	00 00 
    1fad:	49 8b 87 20 01 00 00 	mov    0x120(%r15),%rax
    1fb4:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1fb9:	c4 c1 5d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm4
    1fbf:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    1fc4:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    1fc9:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    1fce:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    1fd3:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    1fda:	00 
    1fdb:	c5 4d fa c2          	vpsubd %ymm2,%ymm6,%ymm8
    1fdf:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    1fe3:	49 8b 87 28 01 00 00 	mov    0x128(%r15),%rax
    1fea:	c5 c5 72 f3 10       	vpslld $0x10,%ymm3,%ymm7
    1fef:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    1ff3:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    1ff8:	c5 c5 fe 3c 24       	vpaddd (%rsp),%ymm7,%ymm7
    1ffd:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    2002:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    2007:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
    200e:	00 
    200f:	49 8b 87 30 01 00 00 	mov    0x130(%r15),%rax
    2016:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    201d:	00 
    201e:	41 8b 87 74 01 00 00 	mov    0x174(%r15),%eax
    2025:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    2029:	89 44 24 20          	mov    %eax,0x20(%rsp)
    202d:	41 8b 87 70 01 00 00 	mov    0x170(%r15),%eax
    2034:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
    2038:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    203c:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2040:	c5 ed 72 f0 08       	vpslld $0x8,%ymm0,%ymm2
    2045:	89 44 24 40          	mov    %eax,0x40(%rsp)
    2049:	49 8b 87 c0 00 00 00 	mov    0xc0(%r15),%rax
    2050:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2055:	c5 e5 72 f1 10       	vpslld $0x10,%ymm1,%ymm3
    205a:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    2061:	00 
    2062:	49 8b 87 c8 00 00 00 	mov    0xc8(%r15),%rax
    2069:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    206d:	c5 ed eb 94 24 c0 00 	vpor   0xc0(%rsp),%ymm2,%ymm2
    2074:	00 00 
    2076:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    207d:	00 
    207e:	49 8b 87 d0 00 00 00 	mov    0xd0(%r15),%rax
    2085:	c4 e2 45 36 da       	vpermd %ymm2,%ymm7,%ymm3
    208a:	c5 ed ef db          	vpxor  %ymm3,%ymm2,%ymm3
    208e:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    2095:	00 
    2096:	41 8b 87 14 01 00 00 	mov    0x114(%r15),%eax
    209d:	c4 e2 7d 17 db       	vptest %ymm3,%ymm3
    20a2:	45 8b af 10 01 00 00 	mov    0x110(%r15),%r13d
    20a9:	49 8b 4f 60          	mov    0x60(%r15),%rcx
    20ad:	4d 8b 47 68          	mov    0x68(%r15),%r8
    20b1:	4d 8b 4f 70          	mov    0x70(%r15),%r9
    20b5:	89 44 24 60          	mov    %eax,0x60(%rsp)
    20b9:	41 8b bf b4 00 00 00 	mov    0xb4(%r15),%edi
    20c0:	49 8b 87 08 01 00 00 	mov    0x108(%r15),%rax
    20c7:	41 8b b7 b0 00 00 00 	mov    0xb0(%r15),%esi
    20ce:	49 8b 9f a8 00 00 00 	mov    0xa8(%r15),%rbx
    20d5:	0f 85 b5 f3 ff ff    	jne    1490 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xc0>
    20db:	c5 f9 7e d2          	vmovd  %xmm2,%edx
    20df:	44 0f b6 d2          	movzbl %dl,%r10d
    20e3:	46 8b 34 91          	mov    (%rcx,%r10,4),%r14d
    20e7:	0f b6 ce             	movzbl %dh,%ecx
    20ea:	c1 ea 10             	shr    $0x10,%edx
    20ed:	45 8b 04 88          	mov    (%r8,%rcx,4),%r8d
    20f1:	41 8b 14 91          	mov    (%r9,%rdx,4),%edx
    20f5:	44 89 f1             	mov    %r14d,%ecx
    20f8:	c1 e9 11             	shr    $0x11,%ecx
    20fb:	45 89 c3             	mov    %r8d,%r11d
    20fe:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
    2105:	41 89 c9             	mov    %ecx,%r9d
    2108:	41 c1 eb 11          	shr    $0x11,%r11d
    210c:	44 89 f1             	mov    %r14d,%ecx
    210f:	44 0f af ce          	imul   %esi,%r9d
    2113:	81 e1 ff ff 01 00    	and    $0x1ffff,%ecx
    2119:	44 0f af df          	imul   %edi,%r11d
    211d:	45 01 cb             	add    %r9d,%r11d
    2120:	41 89 d1             	mov    %edx,%r9d
    2123:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
    2129:	41 c1 e9 11          	shr    $0x11,%r9d
    212d:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
    2134:	45 01 cb             	add    %r9d,%r11d
    2137:	44 39 c1             	cmp    %r8d,%ecx
    213a:	0f 8c a0 04 00 00    	jl     25e0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1210>
    2140:	41 39 d0             	cmp    %edx,%r8d
    2143:	0f 8c 17 05 00 00    	jl     2660 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1290>
    2149:	41 89 fe             	mov    %edi,%r14d
    214c:	41 89 f1             	mov    %esi,%r9d
    214f:	45 01 d9             	add    %r11d,%r9d
    2152:	49 63 d3             	movslq %r11d,%rdx
    2155:	41 01 f3             	add    %esi,%r11d
    2158:	4d 63 d1             	movslq %r9d,%r10
    215b:	41 01 fb             	add    %edi,%r11d
    215e:	45 01 f1             	add    %r14d,%r9d
    2161:	8b 14 93             	mov    (%rbx,%rdx,4),%edx
    2164:	46 8b 14 93          	mov    (%rbx,%r10,4),%r10d
    2168:	4d 63 c9             	movslq %r9d,%r9
    216b:	4d 63 db             	movslq %r11d,%r11
    216e:	46 8b 0c 8b          	mov    (%rbx,%r9,4),%r9d
    2172:	46 8b 5c 9b 04       	mov    0x4(%rbx,%r11,4),%r11d
    2177:	0f b6 f6             	movzbl %dh,%esi
    217a:	41 0f b6 da          	movzbl %r10b,%ebx
    217e:	89 9c 24 34 01 00 00 	mov    %ebx,0x134(%rsp)
    2185:	44 89 d3             	mov    %r10d,%ebx
    2188:	41 c1 ea 10          	shr    $0x10,%r10d
    218c:	45 0f b6 f1          	movzbl %r9b,%r14d
    2190:	44 89 9c 24 c0 00 00 	mov    %r11d,0xc0(%rsp)
    2197:	00 
    2198:	45 0f b6 d2          	movzbl %r10b,%r10d
    219c:	44 0f b6 da          	movzbl %dl,%r11d
    21a0:	c1 ea 10             	shr    $0x10,%edx
    21a3:	44 89 b4 24 38 01 00 	mov    %r14d,0x138(%rsp)
    21aa:	00 
    21ab:	0f b6 d2             	movzbl %dl,%edx
    21ae:	45 89 d6             	mov    %r10d,%r14d
    21b1:	0f b6 ff             	movzbl %bh,%edi
    21b4:	41 29 d6             	sub    %edx,%r14d
    21b7:	44 89 cb             	mov    %r9d,%ebx
    21ba:	41 c1 e9 10          	shr    $0x10,%r9d
    21be:	89 bc 24 3c 01 00 00 	mov    %edi,0x13c(%rsp)
    21c5:	44 0f af f1          	imul   %ecx,%r14d
    21c9:	45 0f b6 c9          	movzbl %r9b,%r9d
    21cd:	c1 e2 10             	shl    $0x10,%edx
    21d0:	0f b6 ff             	movzbl %bh,%edi
    21d3:	8b 9c 24 34 01 00 00 	mov    0x134(%rsp),%ebx
    21da:	44 01 f2             	add    %r14d,%edx
    21dd:	45 89 ce             	mov    %r9d,%r14d
    21e0:	45 29 d6             	sub    %r10d,%r14d
    21e3:	44 0f b6 94 24 c0 00 	movzbl 0xc0(%rsp),%r10d
    21ea:	00 00 
    21ec:	45 0f af f0          	imul   %r8d,%r14d
    21f0:	41 01 d6             	add    %edx,%r14d
    21f3:	8b 94 24 c0 00 00 00 	mov    0xc0(%rsp),%edx
    21fa:	c1 ea 10             	shr    $0x10,%edx
    21fd:	0f b6 d2             	movzbl %dl,%edx
    2200:	44 29 ca             	sub    %r9d,%edx
    2203:	41 89 d9             	mov    %ebx,%r9d
    2206:	0f af 94 24 80 00 00 	imul   0x80(%rsp),%edx
    220d:	00 
    220e:	45 29 d9             	sub    %r11d,%r9d
    2211:	41 c1 e3 10          	shl    $0x10,%r11d
    2215:	44 0f af c9          	imul   %ecx,%r9d
    2219:	41 8d 94 16 00 80 00 	lea    0x8000(%r14,%rdx,1),%edx
    2220:	00 
    2221:	44 8b b4 24 38 01 00 	mov    0x138(%rsp),%r14d
    2228:	00 
    2229:	45 01 cb             	add    %r9d,%r11d
    222c:	66 31 d2             	xor    %dx,%dx
    222f:	45 89 f1             	mov    %r14d,%r9d
    2232:	45 29 f2             	sub    %r14d,%r10d
    2235:	44 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14d
    223c:	00 
    223d:	41 29 d9             	sub    %ebx,%r9d
    2240:	8b 9c 24 3c 01 00 00 	mov    0x13c(%rsp),%ebx
    2247:	45 0f af c8          	imul   %r8d,%r9d
    224b:	45 0f af d6          	imul   %r14d,%r10d
    224f:	45 01 d9             	add    %r11d,%r9d
    2252:	44 8b 5c 24 60       	mov    0x60(%rsp),%r11d
    2257:	47 8d 8c 11 00 80 00 	lea    0x8000(%r9,%r10,1),%r9d
    225e:	00 
    225f:	41 c1 f9 10          	sar    $0x10,%r9d
    2263:	44 09 ca             	or     %r9d,%edx
    2266:	41 89 d9             	mov    %ebx,%r9d
    2269:	41 29 f1             	sub    %esi,%r9d
    226c:	c1 e6 10             	shl    $0x10,%esi
    226f:	44 0f af c9          	imul   %ecx,%r9d
    2273:	89 f9                	mov    %edi,%ecx
    2275:	44 01 ce             	add    %r9d,%esi
    2278:	29 d9                	sub    %ebx,%ecx
    227a:	8b 9c 24 c0 00 00 00 	mov    0xc0(%rsp),%ebx
    2281:	41 0f af c8          	imul   %r8d,%ecx
    2285:	0f b6 df             	movzbl %bh,%ebx
    2288:	29 fb                	sub    %edi,%ebx
    228a:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
    2291:	00 
    2292:	41 0f af de          	imul   %r14d,%ebx
    2296:	01 f1                	add    %esi,%ecx
    2298:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
    229f:	00 
    22a0:	8d 8c 19 00 80 00 00 	lea    0x8000(%rcx,%rbx,1),%ecx
    22a7:	c1 f9 10             	sar    $0x10,%ecx
    22aa:	c1 e1 08             	shl    $0x8,%ecx
    22ad:	09 d1                	or     %edx,%ecx
    22af:	0f b6 d2             	movzbl %dl,%edx
    22b2:	44 8b 04 97          	mov    (%rdi,%rdx,4),%r8d
    22b6:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
    22bd:	00 
    22be:	0f b6 d5             	movzbl %ch,%edx
    22c1:	c1 e9 10             	shr    $0x10,%ecx
    22c4:	44 8b 0c 8e          	mov    (%rsi,%rcx,4),%r9d
    22c8:	8b 14 97             	mov    (%rdi,%rdx,4),%edx
    22cb:	45 89 c2             	mov    %r8d,%r10d
    22ce:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
    22d5:	41 c1 ea 11          	shr    $0x11,%r10d
    22d9:	45 89 ce             	mov    %r9d,%r14d
    22dc:	89 d1                	mov    %edx,%ecx
    22de:	45 0f af d5          	imul   %r13d,%r10d
    22e2:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
    22e8:	41 81 e6 ff ff 01 00 	and    $0x1ffff,%r14d
    22ef:	c1 e9 11             	shr    $0x11,%ecx
    22f2:	41 0f af cb          	imul   %r11d,%ecx
    22f6:	44 01 d1             	add    %r10d,%ecx
    22f9:	45 89 ca             	mov    %r9d,%r10d
    22fc:	41 c1 ea 11          	shr    $0x11,%r10d
    2300:	44 01 d1             	add    %r10d,%ecx
    2303:	41 39 d0             	cmp    %edx,%r8d
    2306:	0f 8c 24 03 00 00    	jl     2630 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1260>
    230c:	44 39 f2             	cmp    %r14d,%edx
    230f:	0f 8c 1b 04 00 00    	jl     2730 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1360>
    2315:	41 89 d2             	mov    %edx,%r10d
    2318:	45 89 e9             	mov    %r13d,%r9d
    231b:	44 89 c2             	mov    %r8d,%edx
    231e:	45 89 d0             	mov    %r10d,%r8d
    2321:	41 01 c9             	add    %ecx,%r9d
    2324:	4c 63 d1             	movslq %ecx,%r10
    2327:	44 01 e9             	add    %r13d,%ecx
    232a:	42 8b 1c 90          	mov    (%rax,%r10,4),%ebx
    232e:	4d 63 d1             	movslq %r9d,%r10
    2331:	03 4c 24 60          	add    0x60(%rsp),%ecx
    2335:	45 01 d9             	add    %r11d,%r9d
    2338:	46 8b 14 90          	mov    (%rax,%r10,4),%r10d
    233c:	4d 63 c9             	movslq %r9d,%r9
    233f:	48 63 c9             	movslq %ecx,%rcx
    2342:	46 8b 0c 88          	mov    (%rax,%r9,4),%r9d
    2346:	8b 4c 88 04          	mov    0x4(%rax,%rcx,4),%ecx
    234a:	44 0f b6 db          	movzbl %bl,%r11d
    234e:	41 0f b6 c2          	movzbl %r10b,%eax
    2352:	89 44 24 60          	mov    %eax,0x60(%rsp)
    2356:	0f b6 c7             	movzbl %bh,%eax
    2359:	45 0f b6 e9          	movzbl %r9b,%r13d
    235d:	c1 eb 10             	shr    $0x10,%ebx
    2360:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
    2367:	44 89 d0             	mov    %r10d,%eax
    236a:	41 c1 ea 10          	shr    $0x10,%r10d
    236e:	0f b6 fc             	movzbl %ah,%edi
    2371:	45 0f b6 d2          	movzbl %r10b,%r10d
    2375:	44 89 c8             	mov    %r9d,%eax
    2378:	44 89 ac 24 80 00 00 	mov    %r13d,0x80(%rsp)
    237f:	00 
    2380:	0f b6 f4             	movzbl %ah,%esi
    2383:	45 89 d5             	mov    %r10d,%r13d
    2386:	0f b6 c3             	movzbl %bl,%eax
    2389:	41 c1 e9 10          	shr    $0x10,%r9d
    238d:	41 29 c5             	sub    %eax,%r13d
    2390:	45 0f b6 c9          	movzbl %r9b,%r9d
    2394:	c1 e0 10             	shl    $0x10,%eax
    2397:	8b 5c 24 60          	mov    0x60(%rsp),%ebx
    239b:	44 0f af ea          	imul   %edx,%r13d
    239f:	44 01 e8             	add    %r13d,%eax
    23a2:	45 89 cd             	mov    %r9d,%r13d
    23a5:	45 29 d5             	sub    %r10d,%r13d
    23a8:	41 89 ca             	mov    %ecx,%r10d
    23ab:	45 0f af e8          	imul   %r8d,%r13d
    23af:	41 c1 ea 10          	shr    $0x10,%r10d
    23b3:	41 01 c5             	add    %eax,%r13d
    23b6:	41 0f b6 c2          	movzbl %r10b,%eax
    23ba:	44 0f b6 d1          	movzbl %cl,%r10d
    23be:	0f b6 cd             	movzbl %ch,%ecx
    23c1:	44 29 c8             	sub    %r9d,%eax
    23c4:	41 89 d9             	mov    %ebx,%r9d
    23c7:	41 0f af c6          	imul   %r14d,%eax
    23cb:	45 29 d9             	sub    %r11d,%r9d
    23ce:	41 c1 e3 10          	shl    $0x10,%r11d
    23d2:	44 0f af ca          	imul   %edx,%r9d
    23d6:	41 8d 84 05 00 80 00 	lea    0x8000(%r13,%rax,1),%eax
    23dd:	00 
    23de:	44 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13d
    23e5:	00 
    23e6:	45 01 cb             	add    %r9d,%r11d
    23e9:	66 31 c0             	xor    %ax,%ax
    23ec:	45 89 e9             	mov    %r13d,%r9d
    23ef:	45 29 ea             	sub    %r13d,%r10d
    23f2:	41 29 d9             	sub    %ebx,%r9d
    23f5:	45 0f af d6          	imul   %r14d,%r10d
    23f9:	8b 9c 24 c0 00 00 00 	mov    0xc0(%rsp),%ebx
    2400:	45 0f af c8          	imul   %r8d,%r9d
    2404:	45 01 d9             	add    %r11d,%r9d
    2407:	44 8b 5c 24 20       	mov    0x20(%rsp),%r11d
    240c:	47 8d 8c 11 00 80 00 	lea    0x8000(%r9,%r10,1),%r9d
    2413:	00 
    2414:	44 8b 54 24 40       	mov    0x40(%rsp),%r10d
    2419:	41 c1 f9 10          	sar    $0x10,%r9d
    241d:	44 09 c8             	or     %r9d,%eax
    2420:	41 89 f9             	mov    %edi,%r9d
    2423:	41 29 d9             	sub    %ebx,%r9d
    2426:	c1 e3 10             	shl    $0x10,%ebx
    2429:	44 0f af ca          	imul   %edx,%r9d
    242d:	89 f2                	mov    %esi,%edx
    242f:	44 01 cb             	add    %r9d,%ebx
    2432:	29 fa                	sub    %edi,%edx
    2434:	29 f1                	sub    %esi,%ecx
    2436:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
    243d:	00 
    243e:	41 0f af d0          	imul   %r8d,%edx
    2442:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
    2449:	00 
    244a:	41 0f af ce          	imul   %r14d,%ecx
    244e:	01 da                	add    %ebx,%edx
    2450:	8d 8c 0a 00 80 00 00 	lea    0x8000(%rdx,%rcx,1),%ecx
    2457:	c1 f9 10             	sar    $0x10,%ecx
    245a:	c1 e1 08             	shl    $0x8,%ecx
    245d:	09 c1                	or     %eax,%ecx
    245f:	0f b6 c0             	movzbl %al,%eax
    2462:	44 8b 04 86          	mov    (%rsi,%rax,4),%r8d
    2466:	0f b6 c5             	movzbl %ch,%eax
    2469:	c1 e9 10             	shr    $0x10,%ecx
    246c:	8b 14 87             	mov    (%rdi,%rax,4),%edx
    246f:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    2476:	00 
    2477:	44 8b 0c 88          	mov    (%rax,%rcx,4),%r9d
    247b:	44 89 c1             	mov    %r8d,%ecx
    247e:	89 d0                	mov    %edx,%eax
    2480:	41 81 e0 ff ff 01 00 	and    $0x1ffff,%r8d
    2487:	c1 e9 11             	shr    $0x11,%ecx
    248a:	c1 e8 11             	shr    $0x11,%eax
    248d:	81 e2 ff ff 01 00    	and    $0x1ffff,%edx
    2493:	41 0f af c3          	imul   %r11d,%eax
    2497:	41 0f af ca          	imul   %r10d,%ecx
    249b:	01 c1                	add    %eax,%ecx
    249d:	44 89 c8             	mov    %r9d,%eax
    24a0:	41 81 e1 ff ff 01 00 	and    $0x1ffff,%r9d
    24a7:	c1 e8 11             	shr    $0x11,%eax
    24aa:	01 c1                	add    %eax,%ecx
    24ac:	41 39 d0             	cmp    %edx,%r8d
    24af:	0f 8c 4b 01 00 00    	jl     2600 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1230>
    24b5:	44 39 ca             	cmp    %r9d,%edx
    24b8:	0f 8c 52 02 00 00    	jl     2710 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1340>
    24be:	89 d0                	mov    %edx,%eax
    24c0:	44 89 c2             	mov    %r8d,%edx
    24c3:	41 89 c0             	mov    %eax,%r8d
    24c6:	41 01 ca             	add    %ecx,%r10d
    24c9:	48 63 c1             	movslq %ecx,%rax
    24cc:	03 4c 24 40          	add    0x40(%rsp),%ecx
    24d0:	49 63 da             	movslq %r10d,%rbx
    24d3:	45 01 da             	add    %r11d,%r10d
    24d6:	44 8b 74 85 00       	mov    0x0(%rbp,%rax,4),%r14d
    24db:	03 4c 24 20          	add    0x20(%rsp),%ecx
    24df:	4d 63 d2             	movslq %r10d,%r10
    24e2:	8b 5c 9d 00          	mov    0x0(%rbp,%rbx,4),%ebx
    24e6:	48 63 c9             	movslq %ecx,%rcx
    24e9:	46 8b 5c 95 00       	mov    0x0(%rbp,%r10,4),%r11d
    24ee:	8b 4c 8d 04          	mov    0x4(%rbp,%rcx,4),%ecx
    24f2:	45 0f b6 d6          	movzbl %r14b,%r10d
    24f6:	44 0f b6 eb          	movzbl %bl,%r13d
    24fa:	0f b6 ef             	movzbl %bh,%ebp
    24fd:	c1 eb 10             	shr    $0x10,%ebx
    2500:	41 0f b6 c3          	movzbl %r11b,%eax
    2504:	0f b6 db             	movzbl %bl,%ebx
    2507:	89 44 24 20          	mov    %eax,0x20(%rsp)
    250b:	44 89 f0             	mov    %r14d,%eax
    250e:	0f b6 f4             	movzbl %ah,%esi
    2511:	44 89 d8             	mov    %r11d,%eax
    2514:	41 c1 eb 10          	shr    $0x10,%r11d
    2518:	0f b6 fc             	movzbl %ah,%edi
    251b:	44 89 f0             	mov    %r14d,%eax
    251e:	41 89 de             	mov    %ebx,%r14d
    2521:	45 0f b6 db          	movzbl %r11b,%r11d
    2525:	c1 e8 10             	shr    $0x10,%eax
    2528:	0f b6 c0             	movzbl %al,%eax
    252b:	41 29 c6             	sub    %eax,%r14d
    252e:	c1 e0 10             	shl    $0x10,%eax
    2531:	44 0f af f2          	imul   %edx,%r14d
    2535:	44 01 f0             	add    %r14d,%eax
    2538:	45 89 de             	mov    %r11d,%r14d
    253b:	41 29 de             	sub    %ebx,%r14d
    253e:	8b 5c 24 20          	mov    0x20(%rsp),%ebx
    2542:	45 0f af f0          	imul   %r8d,%r14d
    2546:	41 01 c6             	add    %eax,%r14d
    2549:	89 c8                	mov    %ecx,%eax
    254b:	c1 e8 10             	shr    $0x10,%eax
    254e:	0f b6 c0             	movzbl %al,%eax
    2551:	44 29 d8             	sub    %r11d,%eax
    2554:	45 89 eb             	mov    %r13d,%r11d
    2557:	45 29 d3             	sub    %r10d,%r11d
    255a:	41 c1 e2 10          	shl    $0x10,%r10d
    255e:	41 0f af c1          	imul   %r9d,%eax
    2562:	44 0f af da          	imul   %edx,%r11d
    2566:	41 8d 84 06 00 80 00 	lea    0x8000(%r14,%rax,1),%eax
    256d:	00 
    256e:	45 01 da             	add    %r11d,%r10d
    2571:	41 89 db             	mov    %ebx,%r11d
    2574:	66 31 c0             	xor    %ax,%ax
    2577:	45 29 eb             	sub    %r13d,%r11d
    257a:	45 0f af d8          	imul   %r8d,%r11d
    257e:	45 01 da             	add    %r11d,%r10d
    2581:	44 0f b6 d9          	movzbl %cl,%r11d
    2585:	0f b6 cd             	movzbl %ch,%ecx
    2588:	41 29 db             	sub    %ebx,%r11d
    258b:	45 0f af d9          	imul   %r9d,%r11d
    258f:	47 8d 94 1a 00 80 00 	lea    0x8000(%r10,%r11,1),%r10d
    2596:	00 
    2597:	41 c1 fa 10          	sar    $0x10,%r10d
    259b:	44 09 d0             	or     %r10d,%eax
    259e:	41 89 ea             	mov    %ebp,%r10d
    25a1:	41 29 f2             	sub    %esi,%r10d
    25a4:	c1 e6 10             	shl    $0x10,%esi
    25a7:	41 0f af d2          	imul   %r10d,%edx
    25ab:	01 d6                	add    %edx,%esi
    25ad:	89 fa                	mov    %edi,%edx
    25af:	29 f9                	sub    %edi,%ecx
    25b1:	29 ea                	sub    %ebp,%edx
    25b3:	41 0f af c9          	imul   %r9d,%ecx
    25b7:	41 0f af d0          	imul   %r8d,%edx
    25bb:	01 d6                	add    %edx,%esi
    25bd:	8d 94 0e 00 80 00 00 	lea    0x8000(%rsi,%rcx,1),%edx
    25c4:	c1 fa 10             	sar    $0x10,%edx
    25c7:	c1 e2 08             	shl    $0x8,%edx
    25ca:	09 d0                	or     %edx,%eax
    25cc:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    25d0:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    25d5:	e9 70 f5 ff ff       	jmp    1b4a <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x77a>
    25da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    25e0:	41 89 fe             	mov    %edi,%r14d
    25e3:	3b 8c 24 80 00 00 00 	cmp    0x80(%rsp),%ecx
    25ea:	7c 7f                	jl     266b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x129b>
    25ec:	89 ca                	mov    %ecx,%edx
    25ee:	41 89 f6             	mov    %esi,%r14d
    25f1:	44 89 c1             	mov    %r8d,%ecx
    25f4:	41 89 f9             	mov    %edi,%r9d
    25f7:	41 89 d0             	mov    %edx,%r8d
    25fa:	e9 50 fb ff ff       	jmp    214f <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7f>
    25ff:	90                   	nop
    2600:	45 39 c8             	cmp    %r9d,%r8d
    2603:	0f 8d 17 01 00 00    	jge    2720 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1350>
    2609:	89 d0                	mov    %edx,%eax
    260b:	44 89 c2             	mov    %r8d,%edx
    260e:	41 89 c0             	mov    %eax,%r8d
    2611:	45 39 c1             	cmp    %r8d,%r9d
    2614:	0f 8e 31 01 00 00    	jle    274b <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x137b>
    261a:	89 d0                	mov    %edx,%eax
    261c:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    2622:	44 89 ca             	mov    %r9d,%edx
    2625:	41 89 c1             	mov    %eax,%r9d
    2628:	e9 99 fe ff ff       	jmp    24c6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f6>
    262d:	0f 1f 00             	nopl   (%rax)
    2630:	45 39 f0             	cmp    %r14d,%r8d
    2633:	0f 8d 07 01 00 00    	jge    2740 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1370>
    2639:	41 89 d1             	mov    %edx,%r9d
    263c:	44 89 c2             	mov    %r8d,%edx
    263f:	45 89 c8             	mov    %r9d,%r8d
    2642:	45 39 c6             	cmp    %r8d,%r14d
    2645:	0f 8e 3b 01 00 00    	jle    2786 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x13b6>
    264b:	41 89 d1             	mov    %edx,%r9d
    264e:	44 89 f2             	mov    %r14d,%edx
    2651:	45 89 ce             	mov    %r9d,%r14d
    2654:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    265a:	e9 c2 fc ff ff       	jmp    2321 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf51>
    265f:	90                   	nop
    2660:	89 ca                	mov    %ecx,%edx
    2662:	41 89 f6             	mov    %esi,%r14d
    2665:	44 89 c1             	mov    %r8d,%ecx
    2668:	41 89 d0             	mov    %edx,%r8d
    266b:	44 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10d
    2672:	00 
    2673:	45 39 c2             	cmp    %r8d,%r10d
    2676:	0f 8e e8 00 00 00    	jle    2764 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1394>
    267c:	89 8c 24 80 00 00 00 	mov    %ecx,0x80(%rsp)
    2683:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    2689:	44 89 d1             	mov    %r10d,%ecx
    268c:	e9 be fa ff ff       	jmp    214f <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7f>
    2691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2698:	c5 f8 77             	vzeroupper
    269b:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
    26a2:	00 00 
    26a4:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
    26ab:	00 00 
    26ad:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
    26b4:	00 00 
    26b6:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
    26bd:	00 00 
    26bf:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
    26c6:	00 00 
    26c8:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
    26cf:	00 00 
    26d1:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
    26d8:	00 00 
    26da:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
    26e1:	00 00 
    26e3:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
    26ea:	00 00 
    26ec:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
    26f3:	00 00 
    26f5:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    26fc:	5b                   	pop    %rbx
    26fd:	5e                   	pop    %rsi
    26fe:	5f                   	pop    %rdi
    26ff:	5d                   	pop    %rbp
    2700:	41 5c                	pop    %r12
    2702:	41 5d                	pop    %r13
    2704:	41 5e                	pop    %r14
    2706:	41 5f                	pop    %r15
    2708:	c3                   	ret
    2709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2710:	45 89 d3             	mov    %r10d,%r11d
    2713:	e9 f9 fe ff ff       	jmp    2611 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1241>
    2718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    271f:	00 
    2720:	45 89 d3             	mov    %r10d,%r11d
    2723:	44 8b 54 24 20       	mov    0x20(%rsp),%r10d
    2728:	e9 99 fd ff ff       	jmp    24c6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f6>
    272d:	0f 1f 00             	nopl   (%rax)
    2730:	45 89 eb             	mov    %r13d,%r11d
    2733:	e9 0a ff ff ff       	jmp    2642 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x1272>
    2738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    273f:	00 
    2740:	45 89 d9             	mov    %r11d,%r9d
    2743:	45 89 eb             	mov    %r13d,%r11d
    2746:	e9 d6 fb ff ff       	jmp    2321 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf51>
    274b:	89 d0                	mov    %edx,%eax
    274d:	45 89 da             	mov    %r11d,%r10d
    2750:	44 89 c2             	mov    %r8d,%edx
    2753:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    2759:	45 89 c8             	mov    %r9d,%r8d
    275c:	41 89 c1             	mov    %eax,%r9d
    275f:	e9 62 fd ff ff       	jmp    24c6 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0x10f6>
    2764:	89 ca                	mov    %ecx,%edx
    2766:	45 89 f1             	mov    %r14d,%r9d
    2769:	44 89 c1             	mov    %r8d,%ecx
    276c:	41 be 01 00 00 00    	mov    $0x1,%r14d
    2772:	44 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8d
    2779:	00 
    277a:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
    2781:	e9 c9 f9 ff ff       	jmp    214f <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xd7f>
    2786:	41 89 d2             	mov    %edx,%r10d
    2789:	45 89 d9             	mov    %r11d,%r9d
    278c:	44 89 c2             	mov    %r8d,%edx
    278f:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    2795:	45 89 f0             	mov    %r14d,%r8d
    2798:	45 89 d6             	mov    %r10d,%r14d
    279b:	e9 81 fb ff ff       	jmp    2321 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)+0xf51>

00000000000027a0 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    27a0:	56                   	push   %rsi
    27a1:	53                   	push   %rbx
    27a2:	48 81 ec 68 02 00 00 	sub    $0x268,%rsp
    27a9:	c5 f8 29 b4 24 c0 01 	vmovaps %xmm6,0x1c0(%rsp)
    27b0:	00 00 
    27b2:	c5 f8 29 bc 24 d0 01 	vmovaps %xmm7,0x1d0(%rsp)
    27b9:	00 00 
    27bb:	c5 78 29 84 24 e0 01 	vmovaps %xmm8,0x1e0(%rsp)
    27c2:	00 00 
    27c4:	c5 78 29 8c 24 f0 01 	vmovaps %xmm9,0x1f0(%rsp)
    27cb:	00 00 
    27cd:	c5 78 29 94 24 00 02 	vmovaps %xmm10,0x200(%rsp)
    27d4:	00 00 
    27d6:	c5 78 29 9c 24 10 02 	vmovaps %xmm11,0x210(%rsp)
    27dd:	00 00 
    27df:	c5 78 29 a4 24 20 02 	vmovaps %xmm12,0x220(%rsp)
    27e6:	00 00 
    27e8:	c5 78 29 ac 24 30 02 	vmovaps %xmm13,0x230(%rsp)
    27ef:	00 00 
    27f1:	c5 78 29 b4 24 40 02 	vmovaps %xmm14,0x240(%rsp)
    27f8:	00 00 
    27fa:	c5 78 29 bc 24 50 02 	vmovaps %xmm15,0x250(%rsp)
    2801:	00 00 
    2803:	49 89 ca             	mov    %rcx,%r10
    2806:	4c 89 c0             	mov    %r8,%rax
    2809:	48 83 fa 04          	cmp    $0x4,%rdx
    280d:	0f 84 36 09 00 00    	je     3149 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9a9>
    2813:	4d 85 c9             	test   %r9,%r9
    2816:	0f 84 8a 06 00 00    	je     2ea6 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
    281c:	49 ff c9             	dec    %r9
    281f:	4c 8d 1c 52          	lea    (%rdx,%rdx,2),%r11
    2823:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    2828:	49 89 c0             	mov    %rax,%r8
    282b:	49 c1 e9 03          	shr    $0x3,%r9
    282f:	49 c1 e3 05          	shl    $0x5,%r11
    2833:	c4 c1 05 72 d3 18    	vpsrld $0x18,%ymm11,%ymm15
    2839:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    283d:	4d 01 d3             	add    %r10,%r11
    2840:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    2845:	b8 00 80 00 00       	mov    $0x8000,%eax
    284a:	c5 f9 6e d8          	vmovd  %eax,%xmm3
    284e:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2853:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
    285a:	00 00 
    285c:	0f 1f 40 00          	nopl   0x0(%rax)
    2860:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    2865:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    286b:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2871:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2877:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 2880 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
    287e:	00 00 
    2880:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    2885:	c4 c1 7d db cf       	vpand  %ymm15,%ymm0,%ymm1
    288a:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    288f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2894:	48 85 d2             	test   %rdx,%rdx
    2897:	0f 84 a3 08 00 00    	je     3140 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9a0>
    289d:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
    28a3:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    28a7:	4c 89 d0             	mov    %r10,%rax
    28aa:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    28ae:	e9 a4 00 00 00       	jmp    2957 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b7>
    28b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    28b8:	c5 fd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm0
    28bd:	c5 ed 72 d7 08       	vpsrld $0x8,%ymm7,%ymm2
    28c2:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    28c8:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    28cd:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    28d2:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    28d7:	c5 9d fa d8          	vpsubd %ymm0,%ymm12,%ymm3
    28db:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    28df:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    28e4:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    28e9:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    28ee:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    28f2:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    28f7:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    28fb:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2900:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2904:	c5 ed 72 d7 10       	vpsrld $0x10,%ymm7,%ymm2
    2909:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    290e:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    2913:	c5 b5 fa c5          	vpsubd %ymm5,%ymm9,%ymm0
    2917:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    291b:	c5 ed fa 54 24 20    	vpsubd 0x20(%rsp),%ymm2,%ymm2
    2921:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2926:	c4 c2 55 40 ed       	vpmulld %ymm13,%ymm5,%ymm5
    292b:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    292f:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    2934:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2938:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    293d:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2941:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2946:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    294a:	48 83 c0 60          	add    $0x60,%rax
    294e:	49 39 c3             	cmp    %rax,%r11
    2951:	0f 84 f6 04 00 00    	je     2e4d <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6ad>
    2957:	c5 fe 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm6
    295d:	48 8b 08             	mov    (%rax),%rcx
    2960:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2964:	c5 fd 6f fb          	vmovdqa %ymm3,%ymm7
    2968:	8b 58 54             	mov    0x54(%rax),%ebx
    296b:	8b 70 50             	mov    0x50(%rax),%esi
    296e:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
    2975:	00 00 
    2977:	c4 e2 55 90 04 b1    	vpgatherdd %ymm5,(%rcx,%ymm6,4),%ymm0
    297d:	48 8b 48 08          	mov    0x8(%rax),%rcx
    2981:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
    2988:	00 00 
    298a:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    298e:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    2992:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    2997:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 29ff <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x25f>
    299e:	00 
    299f:	c4 e2 55 90 14 89    	vpgatherdd %ymm5,(%rcx,%ymm1,4),%ymm2
    29a5:	48 8b 48 10          	mov    0x10(%rax),%rcx
    29a9:	c5 fe 7f 9c 24 e0 00 	vmovdqu %ymm3,0xe0(%rsp)
    29b0:	00 00 
    29b2:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    29b7:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2a1f <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x27f>
    29be:	00 
    29bf:	c4 e2 4d 90 1c b9    	vpgatherdd %ymm6,(%rcx,%ymm7,4),%ymm3
    29c5:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
    29c9:	48 8b 48 48          	mov    0x48(%rax),%rcx
    29cd:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    29d1:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    29d6:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
    29db:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2a43 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2a3>
    29e2:	00 
    29e3:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    29ea:	00 00 
    29ec:	c5 7d 6f f7          	vmovdqa %ymm7,%ymm14
    29f0:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    29f5:	c5 f9 6e fe          	vmovd  %esi,%xmm7
    29f9:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    29fe:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    2a02:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2a07:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2a0b:	c5 75 fe e5          	vpaddd %ymm5,%ymm1,%ymm12
    2a0f:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    2a13:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2a18:	c5 7e 7f a4 24 20 01 	vmovdqu %ymm12,0x120(%rsp)
    2a1f:	00 00 
    2a21:	c4 41 75 fe c4       	vpaddd %ymm12,%ymm1,%ymm8
    2a26:	c5 ed 66 c8          	vpcmpgtd %ymm0,%ymm2,%ymm1
    2a2a:	c4 22 4d 90 14 a1    	vpgatherdd %ymm6,(%rcx,%ymm12,4),%ymm10
    2a30:	c5 7e 7f 84 24 80 00 	vmovdqu %ymm8,0x80(%rsp)
    2a37:	00 00 
    2a39:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    2a3d:	c4 22 4d 90 0c 81    	vpgatherdd %ymm6,(%rcx,%ymm8,4),%ymm9
    2a43:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    2a48:	c4 e2 7d 3d f2       	vpmaxsd %ymm2,%ymm0,%ymm6
    2a4d:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    2a51:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
    2a56:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    2a5b:	c4 c3 55 4c ce 10    	vpblendvb %ymm1,%ymm14,%ymm5,%ymm1
    2a61:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # 2a8a <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ea>
    2a68:	00 00 40 
    2a6b:	c4 e2 7d 39 e2       	vpminsd %ymm2,%ymm0,%ymm4
    2a70:	c4 e2 5d 39 eb       	vpminsd %ymm3,%ymm4,%ymm5
    2a75:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    2a7a:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    2a7f:	c5 cd fe fd          	vpaddd %ymm5,%ymm6,%ymm7
    2a83:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
    2a87:	c5 7d 6f ed          	vmovdqa %ymm5,%ymm13
    2a8b:	c5 e5 fa ff          	vpsubd %ymm7,%ymm3,%ymm7
    2a8f:	c5 fd fe ea          	vpaddd %ymm2,%ymm0,%ymm5
    2a93:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
    2a97:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    2a9d:	c4 e2 1d 90 3c 89    	vpgatherdd %ymm12,(%rcx,%ymm1,4),%ymm7
    2aa3:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
    2aa7:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
    2aac:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    2ab0:	c4 c3 55 4c ce 10    	vpblendvb %ymm1,%ymm14,%ymm5,%ymm1
    2ab6:	c4 41 7d 6f f3       	vmovdqa %ymm11,%ymm14
    2abb:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # 2ae4 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x344>
    2ac2:	00 00 40 
    2ac5:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    2ac9:	c4 41 2d db c7       	vpand  %ymm15,%ymm10,%ymm8
    2ace:	c4 e2 0d 90 2c 89    	vpgatherdd %ymm14,(%rcx,%ymm1,4),%ymm5
    2ad4:	c4 c1 35 db cf       	vpand  %ymm15,%ymm9,%ymm1
    2ad9:	c4 41 45 db f7       	vpand  %ymm15,%ymm7,%ymm14
    2ade:	c5 7e 7f 6c 24 40    	vmovdqu %ymm13,0x40(%rsp)
    2ae4:	c4 c1 55 db e7       	vpand  %ymm15,%ymm5,%ymm4
    2ae9:	c4 c1 1d 72 f0 10    	vpslld $0x10,%ymm8,%ymm12
    2aef:	c4 41 0d fa c0       	vpsubd %ymm8,%ymm14,%ymm8
    2af4:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    2af8:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    2afd:	c4 62 3d 40 c6       	vpmulld %ymm6,%ymm8,%ymm8
    2b02:	c5 7e 6f b4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm14
    2b09:	00 00 
    2b0b:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    2b10:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    2b16:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    2b1b:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
    2b20:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    2b25:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    2b2a:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2b2e:	c4 c1 5d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm4
    2b34:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b39:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    2b3f:	c4 41 5d db e7       	vpand  %ymm15,%ymm4,%ymm12
    2b44:	c5 fe 7f 8c 24 80 01 	vmovdqu %ymm1,0x180(%rsp)
    2b4b:	00 00 
    2b4d:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2b52:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
    2b58:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
    2b5e:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    2b64:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    2b69:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2b6e:	c5 7e 7f 54 24 20    	vmovdqu %ymm10,0x20(%rsp)
    2b74:	c5 dd 72 f1 10       	vpslld $0x10,%ymm1,%ymm4
    2b79:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    2b7e:	c5 7e 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm8
    2b84:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
    2b8a:	c4 41 3d fe f6       	vpaddd %ymm14,%ymm8,%ymm14
    2b8f:	c4 41 5d fe c2       	vpaddd %ymm10,%ymm4,%ymm8
    2b94:	c5 7e 7f b4 24 40 01 	vmovdqu %ymm14,0x140(%rsp)
    2b9b:	00 00 
    2b9d:	c5 7e 7f 84 24 60 01 	vmovdqu %ymm8,0x160(%rsp)
    2ba4:	00 00 
    2ba6:	0f 85 0c fd ff ff    	jne    28b8 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x118>
    2bac:	48 8b 58 28          	mov    0x28(%rax),%rbx
    2bb0:	c5 fe 6f b4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm6
    2bb7:	00 00 
    2bb9:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2bbd:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    2bc4:	00 00 
    2bc6:	48 8b 70 18          	mov    0x18(%rax),%rsi
    2bca:	c4 e2 55 90 3c b3    	vpgatherdd %ymm5,(%rbx,%ymm6,4),%ymm7
    2bd0:	48 8b 58 20          	mov    0x20(%rax),%rbx
    2bd4:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2bd8:	c5 7e 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm8
    2bdf:	00 00 
    2be1:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
    2be5:	c4 e2 55 90 34 a3    	vpgatherdd %ymm5,(%rbx,%ymm4,4),%ymm6
    2beb:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2bef:	c4 a2 55 90 24 86    	vpgatherdd %ymm5,(%rsi,%ymm8,4),%ymm4
    2bf5:	0f 84 15 03 00 00    	je     2f10 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x770>
    2bfb:	c5 d5 72 e4 10       	vpsrad $0x10,%ymm4,%ymm5
    2c00:	c5 dd 72 f4 10       	vpslld $0x10,%ymm4,%ymm4
    2c05:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    2c0a:	48 83 c0 60          	add    $0x60,%rax
    2c0e:	c5 55 fe c0          	vpaddd %ymm0,%ymm5,%ymm8
    2c12:	c5 d5 72 e6 10       	vpsrad $0x10,%ymm6,%ymm5
    2c17:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
    2c1c:	c5 7e 7f 44 24 40    	vmovdqu %ymm8,0x40(%rsp)
    2c22:	c5 dd 72 e4 10       	vpsrad $0x10,%ymm4,%ymm4
    2c27:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    2c2b:	c4 41 55 fe d0       	vpaddd %ymm8,%ymm5,%ymm10
    2c30:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
    2c35:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    2c39:	c5 bd 72 e7 10       	vpsrad $0x10,%ymm7,%ymm8
    2c3e:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
    2c43:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    2c47:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
    2c4e:	00 00 
    2c50:	c5 c5 72 e7 10       	vpsrad $0x10,%ymm7,%ymm7
    2c55:	c5 ed 66 f0          	vpcmpgtd %ymm0,%ymm2,%ymm6
    2c59:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    2c5d:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
    2c62:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
    2c66:	c4 e2 7d 3d fa       	vpmaxsd %ymm2,%ymm0,%ymm7
    2c6b:	c5 e5 66 e7          	vpcmpgtd %ymm7,%ymm3,%ymm4
    2c6f:	c5 65 fe f2          	vpaddd %ymm2,%ymm3,%ymm14
    2c73:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    2c78:	c4 e3 2d 4c b4 24 00 	vpblendvb %ymm6,0x100(%rsp),%ymm10,%ymm6
    2c7f:	01 00 00 60 
    2c83:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    2c8a:	00 00 
    2c8c:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm6,%ymm6        # 2cb5 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x515>
    2c93:	00 00 40 
    2c96:	c4 e2 7d 39 e2       	vpminsd %ymm2,%ymm0,%ymm4
    2c9b:	c4 62 5d 39 d3       	vpminsd %ymm3,%ymm4,%ymm10
    2ca0:	c5 fd 66 d2          	vpcmpgtd %ymm2,%ymm0,%ymm2
    2ca4:	c5 fd fa c7          	vpsubd %ymm7,%ymm0,%ymm0
    2ca8:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    2caf:	00 00 
    2cb1:	c5 7e 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm10
    2cb8:	00 00 
    2cba:	c5 dd 66 db          	vpcmpgtd %ymm3,%ymm4,%ymm3
    2cbe:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    2cc2:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    2cc7:	c4 62 15 90 34 b1    	vpgatherdd %ymm13,(%rcx,%ymm6,4),%ymm14
    2ccd:	c5 7e 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm13
    2cd4:	00 00 
    2cd6:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    2cdb:	c4 c3 4d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm6,%ymm2
    2ce1:	c5 fe 6f b4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm6
    2ce8:	00 00 
    2cea:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm2,%ymm2        # 2d13 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x573>
    2cf1:	00 00 30 
    2cf4:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
    2cfb:	00 00 
    2cfd:	c5 e5 fa d2          	vpsubd %ymm2,%ymm3,%ymm2
    2d01:	c4 e2 5d 90 1c 91    	vpgatherdd %ymm4,(%rcx,%ymm2,4),%ymm3
    2d07:	c4 c1 5d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm4
    2d0d:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    2d14:	00 00 
    2d16:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    2d1b:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2d20:	c5 8d fa d6          	vpsubd %ymm6,%ymm14,%ymm2
    2d24:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2d29:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    2d2e:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    2d32:	c5 e5 fa d4          	vpsubd %ymm4,%ymm3,%ymm2
    2d36:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    2d3a:	c5 9d fa db          	vpsubd %ymm3,%ymm12,%ymm3
    2d3e:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    2d43:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2d48:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    2d4d:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    2d53:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    2d58:	c5 d5 66 d7          	vpcmpgtd %ymm7,%ymm5,%ymm2
    2d5c:	c5 dd fe a4 24 60 01 	vpaddd 0x160(%rsp),%ymm4,%ymm4
    2d63:	00 00 
    2d65:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2d69:	c4 c3 4d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm6,%ymm2
    2d6f:	c4 e2 55 3d df       	vpmaxsd %ymm7,%ymm5,%ymm3
    2d74:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    2d79:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2d7d:	c4 e2 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm4
    2d82:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    2d87:	c5 bd 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm0
    2d8b:	c4 c2 5d 39 f0       	vpminsd %ymm8,%ymm4,%ymm6
    2d90:	c4 c1 5d 66 e0       	vpcmpgtd %ymm8,%ymm4,%ymm4
    2d95:	c4 c2 65 3d d8       	vpmaxsd %ymm8,%ymm3,%ymm3
    2d9a:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    2d9e:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm2,%ymm2        # 2dc7 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x627>
    2da5:	00 00 00 
    2da8:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    2dad:	c5 7e 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm10
    2db4:	00 00 
    2db6:	c4 e2 15 90 04 91    	vpgatherdd %ymm13,(%rcx,%ymm2,4),%ymm0
    2dbc:	c5 c5 66 d5          	vpcmpgtd %ymm5,%ymm7,%ymm2
    2dc0:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    2dc5:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2dc9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2dce:	c4 43 45 4c ee 20    	vpblendvb %ymm2,%ymm14,%ymm7,%ymm13
    2dd4:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    2ddb:	00 00 
    2ddd:	c4 63 15 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm13,%ymm13        # 2e06 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x666>
    2de4:	00 00 40 
    2de7:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2dec:	c5 ad fa c6          	vpsubd %ymm6,%ymm10,%ymm0
    2df0:	c4 41 45 fa ed       	vpsubd %ymm13,%ymm7,%ymm13
    2df5:	c4 a2 55 90 14 a9    	vpgatherdd %ymm5,(%rcx,%ymm13,4),%ymm2
    2dfb:	c5 bd fa eb          	vpsubd %ymm3,%ymm8,%ymm5
    2dff:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2e04:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2e08:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2e0d:	c5 ed fa ec          	vpsubd %ymm4,%ymm2,%ymm5
    2e11:	c5 dd fa 64 24 20    	vpsubd 0x20(%rsp),%ymm4,%ymm4
    2e17:	c5 b5 fa d2          	vpsubd %ymm2,%ymm9,%ymm2
    2e1b:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    2e20:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
    2e25:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    2e2a:	c5 dd fe a4 24 40 01 	vpaddd 0x140(%rsp),%ymm4,%ymm4
    2e31:	00 00 
    2e33:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2e37:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2e3b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2e40:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    2e44:	49 39 c3             	cmp    %rax,%r11
    2e47:	0f 85 0a fb ff ff    	jne    2957 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b7>
    2e4d:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    2e54:	00 00 
    2e56:	c4 c1 6d 72 f4 08    	vpslld $0x8,%ymm12,%ymm2
    2e5c:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    2e61:	49 83 c0 18          	add    $0x18,%r8
    2e65:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    2e69:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2e6d:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 2eb6 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x716>
    2e74:	00 00 
    2e76:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2e7a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2e80:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2e85:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2e8a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2e8e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2e94:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    2e9a:	4d 39 c1             	cmp    %r8,%r9
    2e9d:	0f 85 bd f9 ff ff    	jne    2860 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc0>
    2ea3:	c5 f8 77             	vzeroupper
    2ea6:	c5 f8 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm6
    2ead:	00 00 
    2eaf:	c5 f8 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm7
    2eb6:	00 00 
    2eb8:	c5 78 28 84 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm8
    2ebf:	00 00 
    2ec1:	c5 78 28 8c 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm9
    2ec8:	00 00 
    2eca:	c5 78 28 94 24 00 02 	vmovaps 0x200(%rsp),%xmm10
    2ed1:	00 00 
    2ed3:	c5 78 28 9c 24 10 02 	vmovaps 0x210(%rsp),%xmm11
    2eda:	00 00 
    2edc:	c5 78 28 a4 24 20 02 	vmovaps 0x220(%rsp),%xmm12
    2ee3:	00 00 
    2ee5:	c5 78 28 ac 24 30 02 	vmovaps 0x230(%rsp),%xmm13
    2eec:	00 00 
    2eee:	c5 78 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm14
    2ef5:	00 00 
    2ef7:	c5 78 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm15
    2efe:	00 00 
    2f00:	48 81 c4 68 02 00 00 	add    $0x268,%rsp
    2f07:	5b                   	pop    %rbx
    2f08:	5e                   	pop    %rsi
    2f09:	c3                   	ret
    2f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2f10:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2f78 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d8>
    2f17:	00 
    2f18:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 2f80 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7e0>
    2f1f:	00 
    2f20:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    2f25:	c5 c5 db 05 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm0        # 2f8d <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7ed>
    2f2c:	00 
    2f2d:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
    2f34:	00 00 
    2f36:	c4 62 5d 3d c6       	vpmaxsd %ymm6,%ymm4,%ymm8
    2f3b:	c5 cd 66 ec          	vpcmpgtd %ymm4,%ymm6,%ymm5
    2f3f:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    2f44:	c5 7e 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm10
    2f4b:	00 00 
    2f4d:	c4 c1 7d 66 d0       	vpcmpgtd %ymm8,%ymm0,%ymm2
    2f52:	c4 e2 5d 39 fe       	vpminsd %ymm6,%ymm4,%ymm7
    2f57:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    2f5c:	48 8b 58 40          	mov    0x40(%rax),%rbx
    2f60:	c4 c3 65 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm3,%ymm5
    2f66:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 2f8f <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7ef>
    2f6d:	00 00 20 
    2f70:	c4 e2 45 39 d0       	vpminsd %ymm0,%ymm7,%ymm2
    2f75:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    2f7a:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
    2f7e:	c4 e2 15 90 1c a9    	vpgatherdd %ymm13,(%rcx,%ymm5,4),%ymm3
    2f84:	c5 dd 66 ee          	vpcmpgtd %ymm6,%ymm4,%ymm5
    2f88:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    2f8d:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    2f91:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    2f96:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    2f9a:	c5 bd fe c2          	vpaddd %ymm2,%ymm8,%ymm0
    2f9e:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2fa3:	c5 dd fa c0          	vpsubd %ymm0,%ymm4,%ymm0
    2fa7:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    2fab:	c4 c3 15 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm13,%ymm5
    2fb1:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    2fb6:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 2fdf <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x83f>
    2fbd:	00 00 70 
    2fc0:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    2fc7:	00 00 
    2fc9:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    2fcd:	c4 e2 15 90 3c a9    	vpgatherdd %ymm13,(%rcx,%ymm5,4),%ymm7
    2fd3:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
    2fda:	00 00 
    2fdc:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    2fe1:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
    2fe6:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    2feb:	c5 c5 fa e3          	vpsubd %ymm3,%ymm7,%ymm4
    2fef:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2ff3:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2ff8:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2ffd:	c5 1d fa e7          	vpsubd %ymm7,%ymm12,%ymm12
    3001:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    3006:	c4 62 1d 40 e2       	vpmulld %ymm2,%ymm12,%ymm12
    300b:	c5 e5 fe 9c 24 60 01 	vpaddd 0x160(%rsp),%ymm3,%ymm3
    3012:	00 00 
    3014:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
    3019:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    301d:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3021:	c4 e2 65 90 24 ab    	vpgatherdd %ymm3,(%rbx,%ymm5,4),%ymm4
    3027:	48 8b 58 38          	mov    0x38(%rax),%rbx
    302b:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
    3032:	00 00 
    3034:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    3039:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 30a1 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x901>
    3040:	00 
    3041:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    3045:	c4 e2 4d 90 1c ab    	vpgatherdd %ymm6,(%rbx,%ymm5,4),%ymm3
    304b:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    3052:	00 00 
    3054:	48 8b 58 30          	mov    0x30(%rax),%rbx
    3058:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    305c:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 30c4 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x924>
    3063:	00 
    3064:	c4 e2 4d 90 14 ab    	vpgatherdd %ymm6,(%rbx,%ymm5,4),%ymm2
    306a:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 30d2 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x932>
    3071:	00 
    3072:	c4 e2 6d 3d f3       	vpmaxsd %ymm3,%ymm2,%ymm6
    3077:	c5 e5 66 ea          	vpcmpgtd %ymm2,%ymm3,%ymm5
    307b:	c5 dd 66 c6          	vpcmpgtd %ymm6,%ymm4,%ymm0
    307f:	c4 e2 4d 3d f4       	vpmaxsd %ymm4,%ymm6,%ymm6
    3084:	c4 c3 45 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm7,%ymm5
    308a:	c4 e2 6d 39 fb       	vpminsd %ymm3,%ymm2,%ymm7
    308f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm5,%ymm5        # 30b8 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x918>
    3096:	00 00 00 
    3099:	c4 62 45 39 c4       	vpminsd %ymm4,%ymm7,%ymm8
    309e:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    30a3:	c5 c5 66 fc          	vpcmpgtd %ymm4,%ymm7,%ymm7
    30a7:	c4 e2 15 90 04 a9    	vpgatherdd %ymm13,(%rcx,%ymm5,4),%ymm0
    30ad:	c5 ed 66 eb          	vpcmpgtd %ymm3,%ymm2,%ymm5
    30b1:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    30b6:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    30ba:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    30bf:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    30c4:	c4 c3 15 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm13,%ymm5
    30ca:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    30cf:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 30f8 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x958>
    30d6:	00 00 70 
    30d9:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    30e0:	00 00 
    30e2:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    30e6:	c4 e2 15 90 3c a9    	vpgatherdd %ymm13,(%rcx,%ymm5,4),%ymm7
    30ec:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
    30f1:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    30f6:	c5 dd fa ed          	vpsubd %ymm5,%ymm4,%ymm5
    30fa:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    30ff:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    3103:	c5 c5 fa d8          	vpsubd %ymm0,%ymm7,%ymm3
    3107:	c5 fd fa 44 24 20    	vpsubd 0x20(%rsp),%ymm0,%ymm0
    310d:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    3112:	c5 b5 fa df          	vpsubd %ymm7,%ymm9,%ymm3
    3116:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    311b:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    3120:	c5 fd fe 84 24 40 01 	vpaddd 0x140(%rsp),%ymm0,%ymm0
    3127:	00 00 
    3129:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    312d:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    3131:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3136:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    313a:	e9 0b f8 ff ff       	jmp    294a <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1aa>
    313f:	90                   	nop
    3140:	c5 7d 6f e2          	vmovdqa %ymm2,%ymm12
    3144:	e9 0d fd ff ff       	jmp    2e56 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6b6>
    3149:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    314d:	0f 85 c0 f6 ff ff    	jne    2813 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    3153:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    315a:	0f 84 b3 f6 ff ff    	je     2813 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    3160:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    3167:	0f 84 a6 f6 ff ff    	je     2813 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    316d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    3174:	0f 84 99 f6 ff ff    	je     2813 <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    317a:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    317e:	4d 89 c8             	mov    %r9,%r8
    3181:	48 89 c2             	mov    %rax,%rdx
    3184:	74 68                	je     31ee <jshc_uniform_suffix::avx2_chain(jshc_uniform_suffix::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa4e>
    3186:	c5 f8 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm6
    318d:	00 00 
    318f:	c5 f8 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm7
    3196:	00 00 
    3198:	c5 78 28 84 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm8
    319f:	00 00 
    31a1:	c5 78 28 8c 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm9
    31a8:	00 00 
    31aa:	c5 78 28 94 24 00 02 	vmovaps 0x200(%rsp),%xmm10
    31b1:	00 00 
    31b3:	c5 78 28 9c 24 10 02 	vmovaps 0x210(%rsp),%xmm11
    31ba:	00 00 
    31bc:	c5 78 28 a4 24 20 02 	vmovaps 0x220(%rsp),%xmm12
    31c3:	00 00 
    31c5:	c5 78 28 ac 24 30 02 	vmovaps 0x230(%rsp),%xmm13
    31cc:	00 00 
    31ce:	c5 78 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm14
    31d5:	00 00 
    31d7:	c5 78 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm15
    31de:	00 00 
    31e0:	48 81 c4 68 02 00 00 	add    $0x268,%rsp
    31e7:	5b                   	pop    %rbx
    31e8:	5e                   	pop    %rsi
    31e9:	e9 e2 e1 ff ff       	jmp    13d0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<true>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)>
    31ee:	c5 f8 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm6
    31f5:	00 00 
    31f7:	c5 f8 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm7
    31fe:	00 00 
    3200:	c5 78 28 84 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm8
    3207:	00 00 
    3209:	c5 78 28 8c 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm9
    3210:	00 00 
    3212:	c5 78 28 94 24 00 02 	vmovaps 0x200(%rsp),%xmm10
    3219:	00 00 
    321b:	c5 78 28 9c 24 10 02 	vmovaps 0x210(%rsp),%xmm11
    3222:	00 00 
    3224:	c5 78 28 a4 24 20 02 	vmovaps 0x220(%rsp),%xmm12
    322b:	00 00 
    322d:	c5 78 28 ac 24 30 02 	vmovaps 0x230(%rsp),%xmm13
    3234:	00 00 
    3236:	c5 78 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm14
    323d:	00 00 
    323f:	c5 78 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm15
    3246:	00 00 
    3248:	48 81 c4 68 02 00 00 	add    $0x268,%rsp
    324f:	5b                   	pop    %rbx
    3250:	5e                   	pop    %rsi
    3251:	e9 aa cd ff ff       	jmp    0 <void jshc_uniform_suffix::(anonymous namespace)::fixed_four<false>(jshc_uniform_suffix::View const*, unsigned char*, unsigned long long)>
    3256:	90                   	nop
    3257:	90                   	nop
    3258:	90                   	nop
    3259:	90                   	nop
    325a:	90                   	nop
    325b:	90                   	nop
    325c:	90                   	nop
    325d:	90                   	nop
    325e:	90                   	nop
    325f:	90                   	nop
