# Empty compiler generated dependencies file for jshc_direct_sentinel.
# This may be replaced when dependencies are built.
