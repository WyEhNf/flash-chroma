
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/andn_inplace.cpp" "CMakeFiles/jshc_direct_sentinel.dir/andn_inplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/andn_inplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/andn_outplace.cpp" "CMakeFiles/jshc_direct_sentinel.dir/andn_outplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/andn_outplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/channel_runtime.cpp" "CMakeFiles/jshc_direct_sentinel.dir/channel_runtime.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/channel_runtime.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/compile_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/compile_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/compile_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/direct_sentinel_avx2.cpp" "CMakeFiles/jshc_direct_sentinel.dir/direct_sentinel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/direct_sentinel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/linear.cpp" "CMakeFiles/jshc_direct_sentinel.dir/linear.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/linear.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/normal_inplace.cpp" "CMakeFiles/jshc_direct_sentinel.dir/normal_inplace.cpp.obj" "gcc" "CMakeFiles/jshc_direct_sentinel.dir/normal_inplace.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
