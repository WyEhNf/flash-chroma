
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/andn_inplace.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/andn_inplace.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/andn_inplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/andn_outplace.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/andn_outplace.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/andn_outplace.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/compile_avx2.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/compile_avx2.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/compile_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/contracts.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/contracts.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/contracts.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/direct_sentinel_avx2.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/direct_sentinel_avx2.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/direct_sentinel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/linear.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/linear.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/linear.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/p16-direct-sentinel-runtime/normal_inplace.cpp" "CMakeFiles/p16_direct_sentinel_contracts.dir/normal_inplace.cpp.obj" "gcc" "CMakeFiles/p16_direct_sentinel_contracts.dir/normal_inplace.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
