# Empty compiler generated dependencies file for p16_direct_sentinel_contracts.
# This may be replaced when dependencies are built.
