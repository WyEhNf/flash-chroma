
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_runtime.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_runtime.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-exception-runtime/channel_runtime.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/F_/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/outplace_bench.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/outplace_bench.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/experiments/skylake-andn-normal-runtime/reference_to.cpp" "baseline/CMakeFiles/jshc_skylake_reference.dir/reference_to.cpp.obj" "gcc" "baseline/CMakeFiles/jshc_skylake_reference.dir/reference_to.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
