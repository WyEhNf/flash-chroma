core/CMakeFiles/jshc_core.dir/portable/src/jshc_portable.c.obj: \
 F:\Hackathon\worktrees\p16-tail-20261023\portable\src\jshc_portable.c \
 F:/Hackathon/worktrees/p16-tail-20261023/portable/include/jshc_portable.h \
 E:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stddef.h \
 E:/mingw64/x86_64-w64-mingw32/include/stddef.h \
 E:/mingw64/x86_64-w64-mingw32/include/crtdefs.h \
 E:/mingw64/x86_64-w64-mingw32/include/corecrt.h \
 E:/mingw64/x86_64-w64-mingw32/include/_mingw.h \
 E:/mingw64/x86_64-w64-mingw32/include/_mingw_mac.h \
 E:/mingw64/x86_64-w64-mingw32/include/_mingw_secapi.h \
 E:/mingw64/x86_64-w64-mingw32/include/vadefs.h \
 E:/mingw64/x86_64-w64-mingw32/include/sdks/_mingw_ddk.h \
 E:/mingw64/lib/gcc/x86_64-w64-mingw32/15.2.0/include/stdint.h \
 E:/mingw64/x86_64-w64-mingw32/include/stdint.h
