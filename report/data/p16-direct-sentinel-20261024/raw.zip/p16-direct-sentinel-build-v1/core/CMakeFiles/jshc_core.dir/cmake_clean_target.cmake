file(REMOVE_RECURSE
  "libjshc_core.a"
)
