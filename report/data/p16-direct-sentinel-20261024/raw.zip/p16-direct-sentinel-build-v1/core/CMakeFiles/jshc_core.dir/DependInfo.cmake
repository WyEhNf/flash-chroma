
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-tail-20261023/portable/src/jshc_portable.c" "core/CMakeFiles/jshc_core.dir/portable/src/jshc_portable.c.obj" "gcc" "core/CMakeFiles/jshc_core.dir/portable/src/jshc_portable.c.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/cpp/src/fit_r14.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/fit_r14.cpp.obj" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/fit_r14.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/cpp/src/lut.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/lut.cpp.obj" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/lut.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/cpp/src/lut_simd_avx2.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/lut_simd_avx2.cpp.obj" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/lut_simd_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-tail-20261023/cpp/src/portable_bridge.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/portable_bridge.cpp.obj" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/portable_bridge.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
