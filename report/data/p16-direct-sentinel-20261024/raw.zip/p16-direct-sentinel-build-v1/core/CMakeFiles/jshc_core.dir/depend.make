# Empty dependencies file for jshc_core.
# This may be replaced when dependencies are built.
