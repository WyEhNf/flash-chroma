file(REMOVE_RECURSE
  "CMakeFiles/jshc.dir/cpp/src/main.cpp.obj"
  "CMakeFiles/jshc.dir/cpp/src/main.cpp.obj.d"
  "jshc.exe"
  "jshc.exe.manifest"
  "jshc.pdb"
  "libjshc.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
