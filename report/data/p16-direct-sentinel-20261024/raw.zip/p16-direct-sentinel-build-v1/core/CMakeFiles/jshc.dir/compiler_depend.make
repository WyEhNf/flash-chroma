# Empty compiler generated dependencies file for jshc.
# This may be replaced when dependencies are built.
