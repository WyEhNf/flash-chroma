
artifacts\skylake-prefix-split-build-v1\CMakeFiles\jshc_skylake_prefix_split.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)>:
       0:	41 57                	push   %r15
       2:	41 56                	push   %r14
       4:	41 55                	push   %r13
       6:	41 54                	push   %r12
       8:	55                   	push   %rbp
       9:	57                   	push   %rdi
       a:	56                   	push   %rsi
       b:	53                   	push   %rbx
       c:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
      13:	c5 f8 29 b4 24 20 01 	vmovaps %xmm6,0x120(%rsp)
      1a:	00 00 
      1c:	c5 f8 29 bc 24 30 01 	vmovaps %xmm7,0x130(%rsp)
      23:	00 00 
      25:	c5 78 29 84 24 40 01 	vmovaps %xmm8,0x140(%rsp)
      2c:	00 00 
      2e:	c5 78 29 8c 24 50 01 	vmovaps %xmm9,0x150(%rsp)
      35:	00 00 
      37:	c5 78 29 94 24 60 01 	vmovaps %xmm10,0x160(%rsp)
      3e:	00 00 
      40:	c5 78 29 9c 24 70 01 	vmovaps %xmm11,0x170(%rsp)
      47:	00 00 
      49:	c5 78 29 a4 24 80 01 	vmovaps %xmm12,0x180(%rsp)
      50:	00 00 
      52:	c5 78 29 ac 24 90 01 	vmovaps %xmm13,0x190(%rsp)
      59:	00 00 
      5b:	c5 78 29 b4 24 a0 01 	vmovaps %xmm14,0x1a0(%rsp)
      62:	00 00 
      64:	c5 78 29 bc 24 b0 01 	vmovaps %xmm15,0x1b0(%rsp)
      6b:	00 00 
      6d:	49 89 d6             	mov    %rdx,%r14
      70:	4d 85 c0             	test   %r8,%r8
      73:	0f 84 f3 04 00 00    	je     56c <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x56c>
      79:	8b 51 50             	mov    0x50(%rcx),%edx
      7c:	4d 8d 68 ff          	lea    -0x1(%r8),%r13
      80:	4c 8b 21             	mov    (%rcx),%r12
      83:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
      88:	48 8b 69 08          	mov    0x8(%rcx),%rbp
      8c:	48 8b 79 10          	mov    0x10(%rcx),%rdi
      90:	49 c1 ed 03          	shr    $0x3,%r13
      94:	c4 c1 0d 72 d4 18    	vpsrld $0x18,%ymm12,%ymm14
      9a:	48 8b 71 18          	mov    0x18(%rcx),%rsi
      9e:	48 8b 59 20          	mov    0x20(%rcx),%rbx
      a2:	c5 79 6e c2          	vmovd  %edx,%xmm8
      a6:	4c 8b 41 28          	mov    0x28(%rcx),%r8
      aa:	4c 8b 59 30          	mov    0x30(%rcx),%r11
      ae:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
      b3:	4c 8b 51 38          	mov    0x38(%rcx),%r10
      b7:	4c 8b 49 40          	mov    0x40(%rcx),%r9
      bb:	48 8b 41 48          	mov    0x48(%rcx),%rax
      bf:	8b 49 54             	mov    0x54(%rcx),%ecx
      c2:	44 8d 7c 11 01       	lea    0x1(%rcx,%rdx,1),%r15d
      c7:	4c 89 f2             	mov    %r14,%rdx
      ca:	c4 c1 79 6e ff       	vmovd  %r15d,%xmm7
      cf:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      d4:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
      db:	00 00 
      dd:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
      e1:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
      e6:	41 bd 00 80 00 00    	mov    $0x8000,%r13d
      ec:	c4 c1 79 6e f5       	vmovd  %r13d,%xmm6
      f1:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
      f6:	49 8d 4c ce 18       	lea    0x18(%r14,%rcx,8),%rcx
      fb:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     100:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     105:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
     10c:	00 00 
     10e:	66 90                	xchg   %ax,%ax
     110:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
     114:	c5 fa 7e 4a 10       	vmovq  0x10(%rdx),%xmm1
     119:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
     11d:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
     121:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     125:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     12a:	48 83 c2 18          	add    $0x18,%rdx
     12e:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     134:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     13a:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 143 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x143>
     141:	00 00 
     143:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
     148:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     14d:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
     152:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     158:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     15d:	c4 c2 65 90 04 a4    	vpgatherdd %ymm3,(%r12,%ymm4,4),%ymm0
     163:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     169:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
     16e:	c4 e2 6d 90 64 8d 00 	vpgatherdd %ymm2,0x0(%rbp,%ymm1,4),%ymm4
     175:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
     17c:	00 00 
     17e:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1e6 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1e6>
     185:	00 
     186:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
     18b:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     190:	c4 e2 55 90 14 b7    	vpgatherdd %ymm5,(%rdi,%ymm6,4),%ymm2
     196:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
     19b:	c4 e2 75 40 0c 24    	vpmulld (%rsp),%ymm1,%ymm1
     1a1:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 209 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x209>
     1a8:	00 
     1a9:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 211 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x211>
     1b0:	00 
     1b1:	c4 e2 7d 3d f4       	vpmaxsd %ymm4,%ymm0,%ymm6
     1b6:	c4 62 7d 39 cc       	vpminsd %ymm4,%ymm0,%ymm9
     1bb:	c4 62 35 39 da       	vpminsd %ymm2,%ymm9,%ymm11
     1c0:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     1c4:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     1c8:	c5 ed 66 de          	vpcmpgtd %ymm6,%ymm2,%ymm3
     1cc:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     1d1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     1d5:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     1d9:	c5 75 fe bc 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm15
     1e0:	00 00 
     1e2:	c4 62 55 90 2c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm13
     1e8:	c4 a2 2d 90 2c b8    	vpgatherdd %ymm10,(%rax,%ymm15,4),%ymm5
     1ee:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     1f3:	c5 fd 6f fd          	vmovdqa %ymm5,%ymm7
     1f7:	c5 dd 66 e8          	vpcmpgtd %ymm0,%ymm4,%ymm5
     1fb:	c4 e3 3d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm8,%ymm5
     202:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm5,%ymm5        # 22b <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x22b>
     209:	00 00 30 
     20c:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
     210:	c4 e2 2d 90 1c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm3
     216:	c5 fd 66 ec          	vpcmpgtd %ymm4,%ymm0,%ymm5
     21a:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     21f:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     224:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     228:	c4 e3 3d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm8,%ymm5
     22f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm5        # 258 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x258>
     236:	00 00 90 
     239:	c5 85 fa ed          	vpsubd %ymm5,%ymm15,%ymm5
     23d:	c4 62 2d 90 0c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm9
     243:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
     249:	c4 41 4d fe eb       	vpaddd %ymm11,%ymm6,%ymm13
     24e:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     253:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
     258:	c5 0d db 54 24 60    	vpand  0x60(%rsp),%ymm14,%ymm10
     25e:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     262:	c5 b5 fa d3          	vpsubd %ymm3,%ymm9,%ymm2
     266:	c4 e2 7d 40 d2       	vpmulld %ymm2,%ymm0,%ymm2
     26b:	c5 8d db c7          	vpand  %ymm7,%ymm14,%ymm0
     26f:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     274:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
     279:	c4 c1 55 72 f2 10    	vpslld $0x10,%ymm10,%ymm5
     27f:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     284:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     289:	c5 d5 fe ac 24 a0 00 	vpaddd 0xa0(%rsp),%ymm5,%ymm5
     290:	00 00 
     292:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     297:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
     29c:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     2a0:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     2a4:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
     2a8:	c5 a5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm11
     2ad:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
     2b4:	00 00 
     2b6:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     2bd:	00 00 
     2bf:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     2c5:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
     2ca:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     2d0:	c4 c2 2d 90 2c b0    	vpgatherdd %ymm10,(%r8,%ymm6,4),%ymm5
     2d6:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     2db:	c4 e2 2d 90 34 9b    	vpgatherdd %ymm10,(%rbx,%ymm3,4),%ymm6
     2e1:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     2e6:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 34e <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x34e>
     2ed:	00 
     2ee:	c4 e2 2d 90 14 a6    	vpgatherdd %ymm10,(%rsi,%ymm4,4),%ymm2
     2f4:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 35c <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x35c>
     2fb:	00 
     2fc:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 364 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x364>
     303:	00 
     304:	c4 62 6d 3d d6       	vpmaxsd %ymm6,%ymm2,%ymm10
     309:	c5 cd 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm0
     30d:	c4 e2 6d 39 e6       	vpminsd %ymm6,%ymm2,%ymm4
     312:	c4 c1 55 66 da       	vpcmpgtd %ymm10,%ymm5,%ymm3
     317:	c4 62 5d 39 ed       	vpminsd %ymm5,%ymm4,%ymm13
     31c:	c4 62 2d 3d d5       	vpmaxsd %ymm5,%ymm10,%ymm10
     321:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     325:	c4 e3 3d 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm8,%ymm0
     32c:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm0,%ymm0        # 355 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x355>
     333:	00 00 30 
     336:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     33a:	c4 e2 35 90 1c 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm3
     340:	c5 ed 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm0
     344:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     348:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     34f:	00 00 
     351:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     356:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     35b:	c4 e3 3d 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm8,%ymm0
     362:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 38b <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x38b>
     369:	00 00 40 
     36c:	c5 dd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm4
     371:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
     375:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     37a:	c4 62 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm9
     380:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     386:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
     38d:	00 00 
     38f:	c4 c1 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm7
     394:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
     39a:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
     39e:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     3a2:	c5 a5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm11
     3a7:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     3ac:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
     3b0:	c4 41 25 db de       	vpand  %ymm14,%ymm11,%ymm11
     3b5:	c5 b5 fa eb          	vpsubd %ymm3,%ymm9,%ymm5
     3b9:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
     3be:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
     3c3:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
     3c8:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     3cd:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     3d2:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
     3d8:	c4 c2 45 90 14 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm2
     3de:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     3e4:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
     3eb:	00 00 
     3ed:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     3f1:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 459 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x459>
     3f8:	00 
     3f9:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     3fd:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     401:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     407:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     40b:	c4 c2 45 90 24 9a    	vpgatherdd %ymm7,(%r10,%ymm3,4),%ymm4
     411:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     416:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     41a:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 482 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x482>
     421:	00 
     422:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
     427:	c4 c2 45 90 1c b3    	vpgatherdd %ymm7,(%r11,%ymm6,4),%ymm3
     42d:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
     432:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 49a <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x49a>
     439:	00 
     43a:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     43e:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
     444:	c4 e2 65 3d f4       	vpmaxsd %ymm4,%ymm3,%ymm6
     449:	c5 dd 66 eb          	vpcmpgtd %ymm3,%ymm4,%ymm5
     44d:	c5 6d 66 ce          	vpcmpgtd %ymm6,%ymm2,%ymm9
     451:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     456:	c4 c3 3d 4c eb 50    	vpblendvb %ymm5,%ymm11,%ymm8,%ymm5
     45c:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm5        # 485 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x485>
     463:	00 00 90 
     466:	c4 62 65 39 cc       	vpminsd %ymm4,%ymm3,%ymm9
     46b:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
     46f:	c4 62 35 39 d2       	vpminsd %ymm2,%ymm9,%ymm10
     474:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     478:	c4 e2 45 90 0c a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm1
     47e:	c5 e5 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm5
     482:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     486:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     48b:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     48f:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     494:	c4 c3 3d 4c eb 50    	vpblendvb %ymm5,%ymm11,%ymm8,%ymm5
     49a:	c4 63 55 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm9        # 4c3 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x4c3>
     4a1:	00 00 90 
     4a4:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
     4a9:	c4 41 4d fe fa       	vpaddd %ymm10,%ymm6,%ymm15
     4ae:	c4 a2 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm9,4),%ymm5
     4b4:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
     4ba:	c4 c1 6d fa d7       	vpsubd %ymm15,%ymm2,%ymm2
     4bf:	c5 a5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm11
     4c4:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
     4cb:	00 00 
     4cd:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     4d2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     4d6:	c4 41 25 db de       	vpand  %ymm14,%ymm11,%ymm11
     4db:	c4 c1 15 72 f1 10    	vpslld $0x10,%ymm9,%ymm13
     4e1:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     4e6:	c5 a5 fa d9          	vpsubd %ymm1,%ymm11,%ymm3
     4ea:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     4ef:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     4f4:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     4f9:	c5 15 fe ac 24 a0 00 	vpaddd 0xa0(%rsp),%ymm13,%ymm13
     500:	00 00 
     502:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     507:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     50c:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     511:	c4 c1 6d fe d5       	vpaddd %ymm13,%ymm2,%ymm2
     516:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
     51a:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     51e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     523:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     528:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     52c:	c5 fd eb 84 24 e0 00 	vpor   0xe0(%rsp),%ymm0,%ymm0
     533:	00 00 
     535:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 57e <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x57e>
     53c:	00 00 
     53e:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     542:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     548:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     54d:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     552:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     556:	c5 f9 d6 42 f8       	vmovq  %xmm0,-0x8(%rdx)
     55b:	c5 fa 7f 4a e8       	vmovdqu %xmm1,-0x18(%rdx)
     560:	48 39 d1             	cmp    %rdx,%rcx
     563:	0f 85 a7 fb ff ff    	jne    110 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)+0x110>
     569:	c5 f8 77             	vzeroupper
     56c:	c5 f8 28 b4 24 20 01 	vmovaps 0x120(%rsp),%xmm6
     573:	00 00 
     575:	c5 f8 28 bc 24 30 01 	vmovaps 0x130(%rsp),%xmm7
     57c:	00 00 
     57e:	c5 78 28 84 24 40 01 	vmovaps 0x140(%rsp),%xmm8
     585:	00 00 
     587:	c5 78 28 8c 24 50 01 	vmovaps 0x150(%rsp),%xmm9
     58e:	00 00 
     590:	c5 78 28 94 24 60 01 	vmovaps 0x160(%rsp),%xmm10
     597:	00 00 
     599:	c5 78 28 9c 24 70 01 	vmovaps 0x170(%rsp),%xmm11
     5a0:	00 00 
     5a2:	c5 78 28 a4 24 80 01 	vmovaps 0x180(%rsp),%xmm12
     5a9:	00 00 
     5ab:	c5 78 28 ac 24 90 01 	vmovaps 0x190(%rsp),%xmm13
     5b2:	00 00 
     5b4:	c5 78 28 b4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm14
     5bb:	00 00 
     5bd:	c5 78 28 bc 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm15
     5c4:	00 00 
     5c6:	48 81 c4 c8 01 00 00 	add    $0x1c8,%rsp
     5cd:	5b                   	pop    %rbx
     5ce:	5e                   	pop    %rsi
     5cf:	5f                   	pop    %rdi
     5d0:	5d                   	pop    %rbp
     5d1:	41 5c                	pop    %r12
     5d3:	41 5d                	pop    %r13
     5d5:	41 5e                	pop    %r14
     5d7:	41 5f                	pop    %r15
     5d9:	c3                   	ret
     5da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000005e0 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)>:
     5e0:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
     5e7:	c5 f8 29 74 24 40    	vmovaps %xmm6,0x40(%rsp)
     5ed:	c5 f8 29 7c 24 50    	vmovaps %xmm7,0x50(%rsp)
     5f3:	c5 78 29 44 24 60    	vmovaps %xmm8,0x60(%rsp)
     5f9:	c5 78 29 4c 24 70    	vmovaps %xmm9,0x70(%rsp)
     5ff:	c5 78 29 94 24 80 00 	vmovaps %xmm10,0x80(%rsp)
     606:	00 00 
     608:	c5 78 29 9c 24 90 00 	vmovaps %xmm11,0x90(%rsp)
     60f:	00 00 
     611:	c5 78 29 a4 24 a0 00 	vmovaps %xmm12,0xa0(%rsp)
     618:	00 00 
     61a:	c5 78 29 ac 24 b0 00 	vmovaps %xmm13,0xb0(%rsp)
     621:	00 00 
     623:	c5 78 29 b4 24 c0 00 	vmovaps %xmm14,0xc0(%rsp)
     62a:	00 00 
     62c:	c5 78 29 bc 24 d0 00 	vmovaps %xmm15,0xd0(%rsp)
     633:	00 00 
     635:	48 89 c8             	mov    %rcx,%rax
     638:	4d 85 c0             	test   %r8,%r8
     63b:	0f 84 63 07 00 00    	je     da4 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x7c4>
     641:	49 ff c8             	dec    %r8
     644:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     649:	49 c1 e8 03          	shr    $0x3,%r8
     64d:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
     653:	4b 8d 0c 40          	lea    (%r8,%r8,2),%rcx
     657:	4c 8d 54 ca 18       	lea    0x18(%rdx,%rcx,8),%r10
     65c:	b9 00 80 00 00       	mov    $0x8000,%ecx
     661:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
     665:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     66a:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
     66f:	90                   	nop
     670:	c5 fa 6f 0a          	vmovdqu (%rdx),%xmm1
     674:	c5 fa 7e 52 10       	vmovq  0x10(%rdx),%xmm2
     679:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     67d:	48 83 c2 18          	add    $0x18,%rdx
     681:	48 8b 48 60          	mov    0x60(%rax),%rcx
     685:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
     68c:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
     692:	44 8b 80 b0 00 00 00 	mov    0xb0(%rax),%r8d
     699:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
     69f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     6a4:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # 6ad <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0xcd>
     6ab:	00 00 
     6ad:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
     6b2:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     6b7:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     6bc:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
     6c1:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     6c5:	c4 e2 55 90 24 89    	vpgatherdd %ymm5,(%rcx,%ymm1,4),%ymm4
     6cb:	48 8b 48 68          	mov    0x68(%rax),%rcx
     6cf:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
     6d3:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     6d7:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     6dc:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     6e1:	c4 e2 55 90 34 89    	vpgatherdd %ymm5,(%rcx,%ymm1,4),%ymm6
     6e7:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     6ec:	48 8b 48 70          	mov    0x70(%rax),%rcx
     6f0:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     6f4:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     6f9:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     6fe:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 766 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x186>
     705:	00 
     706:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     70b:	c4 e2 55 90 3c 99    	vpgatherdd %ymm5,(%rcx,%ymm3,4),%ymm7
     711:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
     716:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
     71d:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     722:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     727:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 78f <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x1af>
     72e:	00 
     72f:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 797 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x1b7>
     736:	00 
     737:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     73c:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     741:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     746:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     74b:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     750:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     754:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     758:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     75c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     760:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     764:	c4 e2 65 90 0c 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm1
     76a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     76e:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
     774:	c4 62 65 90 34 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm14
     77a:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     77e:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
     782:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     786:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
     78a:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
     790:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 7b9 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x1d9>
     797:	00 00 80 
     79a:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     79f:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
     7a5:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     7ab:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     7b0:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # 7d9 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x1f9>
     7b7:	00 00 c0 
     7ba:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     7be:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     7c3:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     7c7:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     7cb:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     7cf:	c4 e2 55 90 1c 91    	vpgatherdd %ymm5,(%rcx,%ymm2,4),%ymm3
     7d5:	c4 c1 5d fa ea       	vpsubd %ymm10,%ymm4,%ymm5
     7da:	c4 e2 45 90 24 a9    	vpgatherdd %ymm7,(%rcx,%ymm5,4),%ymm4
     7e0:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     7e4:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
     7e8:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
     7ef:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     7f4:	c5 dd db d0          	vpand  %ymm0,%ymm4,%ymm2
     7f8:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     7fc:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
     800:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     805:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     80a:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     80f:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     814:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     819:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
     81e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     823:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
     827:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     82b:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     82f:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     833:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     838:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     83c:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     841:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     845:	c4 c1 6d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm2
     84b:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
     850:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     854:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     858:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     85c:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     861:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     866:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     86b:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
     86f:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     874:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     879:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     87e:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     883:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     888:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     88c:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     890:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
     895:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     899:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
     89d:	c4 c1 75 72 d6 10    	vpsrld $0x10,%ymm14,%ymm1
     8a3:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     8a8:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     8ac:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     8b0:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     8b5:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     8ba:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     8be:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     8c2:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     8c6:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     8cb:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     8d0:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8d5:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     8d9:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     8dd:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     8e1:	c4 e2 65 90 24 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm4
     8e7:	48 8b 88 c8 00 00 00 	mov    0xc8(%rax),%rcx
     8ee:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
     8f5:	44 8b 80 10 01 00 00 	mov    0x110(%rax),%r8d
     8fc:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     900:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     905:	c4 e2 65 90 34 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm6
     90b:	48 8b 88 d0 00 00 00 	mov    0xd0(%rax),%rcx
     912:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     916:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     91b:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
     920:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     925:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     92a:	c4 e2 65 90 3c 89    	vpgatherdd %ymm3,(%rcx,%ymm1,4),%ymm7
     930:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     935:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
     93a:	48 8b 88 08 01 00 00 	mov    0x108(%rax),%rcx
     941:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     946:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     94b:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     950:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     955:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     95a:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 9c2 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x3e2>
     961:	00 
     962:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     967:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 9cf <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x3ef>
     96e:	00 
     96f:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 9d7 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x3f7>
     976:	00 
     977:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     97c:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     981:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     986:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     98b:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     990:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     994:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     998:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     99c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     9a0:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     9a4:	c4 e2 65 90 0c 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm1
     9aa:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     9ae:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
     9b4:	c4 62 65 90 34 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm14
     9ba:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     9be:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
     9c2:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     9c6:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
     9ca:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
     9d0:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 9f9 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x419>
     9d7:	00 00 80 
     9da:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     9df:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
     9e5:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     9eb:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     9f0:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # a19 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x439>
     9f7:	00 00 c0 
     9fa:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     9fe:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     a03:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     a07:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     a0b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a0f:	c4 e2 55 90 1c 91    	vpgatherdd %ymm5,(%rcx,%ymm2,4),%ymm3
     a15:	c4 c1 5d fa ea       	vpsubd %ymm10,%ymm4,%ymm5
     a1a:	c4 e2 45 90 24 a9    	vpgatherdd %ymm7,(%rcx,%ymm5,4),%ymm4
     a20:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     a24:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
     a28:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
     a2f:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     a34:	c5 dd db d0          	vpand  %ymm0,%ymm4,%ymm2
     a38:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     a3c:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
     a40:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     a45:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     a4a:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     a4f:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     a54:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     a59:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
     a5e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     a63:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
     a67:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     a6b:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     a6f:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     a73:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     a78:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     a7c:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     a81:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     a85:	c4 c1 6d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm2
     a8b:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
     a90:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     a94:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     a98:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     a9c:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     aa1:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     aa6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     aab:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
     aaf:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     ab4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     ab9:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     abe:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     ac3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     ac8:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     acc:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     ad0:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
     ad5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     ad9:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
     add:	c4 c1 75 72 d6 10    	vpsrld $0x10,%ymm14,%ymm1
     ae3:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     ae8:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     aec:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     af0:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     af5:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     afa:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     afe:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     b02:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     b06:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     b0b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     b10:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b15:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     b19:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     b1d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     b21:	c4 e2 65 90 24 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm4
     b27:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
     b2e:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     b32:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b37:	c4 e2 65 90 34 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm6
     b3d:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
     b44:	44 8b 80 70 01 00 00 	mov    0x170(%rax),%r8d
     b4b:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     b4f:	48 8b 88 30 01 00 00 	mov    0x130(%rax),%rcx
     b56:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     b5b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # bc3 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x5e3>
     b62:	00 
     b63:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
     b68:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     b6d:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     b72:	c4 e2 65 90 3c 89    	vpgatherdd %ymm3,(%rcx,%ymm1,4),%ymm7
     b78:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     b7d:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     b82:	48 8b 88 68 01 00 00 	mov    0x168(%rax),%rcx
     b89:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     b8e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     b93:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
     b98:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     b9d:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     ba2:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     ba7:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # c0f <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x62f>
     bae:	00 
     baf:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # c17 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x637>
     bb6:	00 
     bb7:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     bbc:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     bc1:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     bc6:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     bcb:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     bd0:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     bd4:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     bd8:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     bdc:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     be0:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     be4:	c4 e2 65 90 0c 91    	vpgatherdd %ymm3,(%rcx,%ymm2,4),%ymm1
     bea:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     bee:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
     bf4:	c4 62 65 90 34 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm14
     bfa:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     bfe:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
     c02:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     c06:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
     c0c:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # c35 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x655>
     c13:	00 00 80 
     c16:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     c1b:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
     c21:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     c27:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     c2c:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # c55 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x675>
     c33:	00 00 c0 
     c36:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     c3a:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     c3f:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     c43:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     c47:	c4 e2 55 90 1c 91    	vpgatherdd %ymm5,(%rcx,%ymm2,4),%ymm3
     c4d:	c4 c1 5d fa ea       	vpsubd %ymm10,%ymm4,%ymm5
     c52:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     c56:	c4 e2 5d 90 34 a9    	vpgatherdd %ymm4,(%rcx,%ymm5,4),%ymm6
     c5c:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     c60:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     c64:	c5 cd db d0          	vpand  %ymm0,%ymm6,%ymm2
     c68:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     c6d:	c5 8d db e0          	vpand  %ymm0,%ymm14,%ymm4
     c71:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     c75:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     c79:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
     c7e:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     c83:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     c88:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     c8d:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     c92:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     c97:	c5 1d db e0          	vpand  %ymm0,%ymm12,%ymm12
     c9b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ca0:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     ca4:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     ca8:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     cac:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     cb1:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
     cb5:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
     cba:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     cbe:	c4 c1 6d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm2
     cc4:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
     cc9:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     ccd:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     cd1:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     cd5:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     cda:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     cdf:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ce4:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     ce8:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     ced:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     cf2:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     cf7:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     cfc:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     d01:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     d05:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     d09:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
     d0e:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     d12:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     d16:	c4 c1 75 72 d6 10    	vpsrld $0x10,%ymm14,%ymm1
     d1c:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     d21:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     d25:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     d29:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     d2e:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     d33:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     d37:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
     d3b:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     d40:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     d45:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     d4a:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
     d4f:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     d53:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     d57:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     d5b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     d60:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     d65:	c5 ed eb c9          	vpor   %ymm1,%ymm2,%ymm1
     d69:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     d6d:	c4 e2 75 00 0d 40 00 	vpshufb 0x40(%rip),%ymm1,%ymm1        # db6 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x7d6>
     d74:	00 00 
     d76:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
     d7a:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     d80:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     d85:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     d8a:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     d8e:	c5 f9 d6 4a f8       	vmovq  %xmm1,-0x8(%rdx)
     d93:	c5 fa 7f 52 e8       	vmovdqu %xmm2,-0x18(%rdx)
     d98:	49 39 d2             	cmp    %rdx,%r10
     d9b:	0f 85 cf f8 ff ff    	jne    670 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)+0x90>
     da1:	c5 f8 77             	vzeroupper
     da4:	c5 f8 28 74 24 40    	vmovaps 0x40(%rsp),%xmm6
     daa:	c5 f8 28 7c 24 50    	vmovaps 0x50(%rsp),%xmm7
     db0:	c5 78 28 44 24 60    	vmovaps 0x60(%rsp),%xmm8
     db6:	c5 78 28 4c 24 70    	vmovaps 0x70(%rsp),%xmm9
     dbc:	c5 78 28 94 24 80 00 	vmovaps 0x80(%rsp),%xmm10
     dc3:	00 00 
     dc5:	c5 78 28 9c 24 90 00 	vmovaps 0x90(%rsp),%xmm11
     dcc:	00 00 
     dce:	c5 78 28 a4 24 a0 00 	vmovaps 0xa0(%rsp),%xmm12
     dd5:	00 00 
     dd7:	c5 78 28 ac 24 b0 00 	vmovaps 0xb0(%rsp),%xmm13
     dde:	00 00 
     de0:	c5 78 28 b4 24 c0 00 	vmovaps 0xc0(%rsp),%xmm14
     de7:	00 00 
     de9:	c5 78 28 bc 24 d0 00 	vmovaps 0xd0(%rsp),%xmm15
     df0:	00 00 
     df2:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
     df9:	c3                   	ret
     dfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000000e00 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     e00:	56                   	push   %rsi
     e01:	53                   	push   %rbx
     e02:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
     e09:	c5 f8 29 b4 24 60 01 	vmovaps %xmm6,0x160(%rsp)
     e10:	00 00 
     e12:	c5 f8 29 bc 24 70 01 	vmovaps %xmm7,0x170(%rsp)
     e19:	00 00 
     e1b:	c5 78 29 84 24 80 01 	vmovaps %xmm8,0x180(%rsp)
     e22:	00 00 
     e24:	c5 78 29 8c 24 90 01 	vmovaps %xmm9,0x190(%rsp)
     e2b:	00 00 
     e2d:	c5 78 29 94 24 a0 01 	vmovaps %xmm10,0x1a0(%rsp)
     e34:	00 00 
     e36:	c5 78 29 9c 24 b0 01 	vmovaps %xmm11,0x1b0(%rsp)
     e3d:	00 00 
     e3f:	c5 78 29 a4 24 c0 01 	vmovaps %xmm12,0x1c0(%rsp)
     e46:	00 00 
     e48:	c5 78 29 ac 24 d0 01 	vmovaps %xmm13,0x1d0(%rsp)
     e4f:	00 00 
     e51:	c5 78 29 b4 24 e0 01 	vmovaps %xmm14,0x1e0(%rsp)
     e58:	00 00 
     e5a:	c5 78 29 bc 24 f0 01 	vmovaps %xmm15,0x1f0(%rsp)
     e61:	00 00 
     e63:	49 89 ca             	mov    %rcx,%r10
     e66:	4c 89 c3             	mov    %r8,%rbx
     e69:	48 83 fa 04          	cmp    $0x4,%rdx
     e6d:	0f 84 b6 06 00 00    	je     1529 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x729>
     e73:	4d 85 c9             	test   %r9,%r9
     e76:	0f 84 40 06 00 00    	je     14bc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6bc>
     e7c:	49 ff c9             	dec    %r9
     e7f:	4c 8d 1c 52          	lea    (%rdx,%rdx,2),%r11
     e83:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     e88:	49 89 d8             	mov    %rbx,%r8
     e8b:	49 c1 e9 03          	shr    $0x3,%r9
     e8f:	49 c1 e3 05          	shl    $0x5,%r11
     e93:	c4 c1 05 72 d5 18    	vpsrld $0x18,%ymm13,%ymm15
     e99:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
     e9d:	4d 01 d3             	add    %r10,%r11
     ea0:	4c 8d 4c c3 18       	lea    0x18(%rbx,%rax,8),%r9
     ea5:	b8 00 80 00 00       	mov    $0x8000,%eax
     eaa:	c5 f9 6e d8          	vmovd  %eax,%xmm3
     eae:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     eb3:	c5 fe 7f 9c 24 40 01 	vmovdqu %ymm3,0x140(%rsp)
     eba:	00 00 
     ebc:	0f 1f 40 00          	nopl   0x0(%rax)
     ec0:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     ec5:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
     ecb:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
     ed1:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     ed7:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # ee0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
     ede:	00 00 
     ee0:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     ee5:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
     eea:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     eef:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ef4:	48 85 d2             	test   %rdx,%rdx
     ef7:	0f 84 23 06 00 00    	je     1520 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x720>
     efd:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     f03:	4c 89 d0             	mov    %r10,%rax
     f06:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     f0c:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     f12:	e9 cb 00 00 00       	jmp    fe2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1e2>
     f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     f1e:	00 00 
     f20:	c5 7e 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm8
     f27:	00 00 
     f29:	c5 fd 6f f9          	vmovdqa %ymm1,%ymm7
     f2d:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     f32:	48 83 c0 60          	add    $0x60,%rax
     f36:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     f3b:	c4 c1 6d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm2
     f41:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     f46:	c5 dd fa da          	vpsubd %ymm2,%ymm4,%ymm3
     f4a:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     f4e:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     f53:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     f58:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     f5c:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     f61:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     f65:	c4 c1 6d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm2
     f6b:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
     f70:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     f75:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     f79:	c5 f5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm1
     f7e:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
     f82:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     f87:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     f8c:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     f91:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     f95:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     f9a:	c5 7d 6f e3          	vmovdqa %ymm3,%ymm12
     f9e:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     fa3:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     fa8:	c5 dd fe c2          	vpaddd %ymm2,%ymm4,%ymm0
     fac:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
     fb1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     fb5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     fba:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     fbe:	4c 39 d8             	cmp    %r11,%rax
     fc1:	0f 84 99 04 00 00    	je     1460 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x660>
     fc7:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
     fcd:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     fd3:	c5 fe 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm3
     fda:	00 00 
     fdc:	c5 fe 7f 5c 24 60    	vmovdqu %ymm3,0x60(%rsp)
     fe2:	48 8b 08             	mov    (%rax),%rcx
     fe5:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     feb:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     fef:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     ff3:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     ff9:	8b 70 54             	mov    0x54(%rax),%esi
     ffc:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    1001:	c4 e2 65 90 04 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm0
    1007:	48 8b 48 08          	mov    0x8(%rax),%rcx
    100b:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    100f:	8b 58 50             	mov    0x50(%rax),%ebx
    1012:	c5 79 6e c6          	vmovd  %esi,%xmm8
    1016:	c5 f5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm1
    101b:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1083 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x283>
    1022:	00 
    1023:	c4 e2 65 90 2c b1    	vpgatherdd %ymm3,(%rcx,%ymm6,4),%ymm5
    1029:	48 8b 48 10          	mov    0x10(%rax),%rcx
    102d:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    1033:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    1037:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    103c:	c5 dd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm4
    1041:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    1045:	c4 e2 65 90 14 b1    	vpgatherdd %ymm3,(%rcx,%ymm6,4),%ymm2
    104b:	c5 f9 6e db          	vmovd  %ebx,%xmm3
    104f:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 10b7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2b7>
    1056:	00 
    1057:	48 8b 48 48          	mov    0x48(%rax),%rcx
    105b:	c4 e2 3d 40 e4       	vpmulld %ymm4,%ymm8,%ymm4
    1060:	c5 cd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm6
    1065:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    106a:	c4 e2 65 40 c9       	vpmulld %ymm1,%ymm3,%ymm1
    106f:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 10d7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d7>
    1076:	00 
    1077:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    107b:	c5 f9 6e e6          	vmovd  %esi,%xmm4
    107f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1083:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1088:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    108c:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    1093:	00 00 
    1095:	c5 5d fe e1          	vpaddd %ymm1,%ymm4,%ymm12
    1099:	c5 d5 66 e0          	vpcmpgtd %ymm0,%ymm5,%ymm4
    109d:	c4 62 4d 90 14 89    	vpgatherdd %ymm6,(%rcx,%ymm1,4),%ymm10
    10a3:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
    10aa:	00 00 
    10ac:	c4 e2 55 3d f0       	vpmaxsd %ymm0,%ymm5,%ymm6
    10b1:	c4 22 45 90 0c a1    	vpgatherdd %ymm7,(%rcx,%ymm12,4),%ymm9
    10b7:	c5 ed 66 fe          	vpcmpgtd %ymm6,%ymm2,%ymm7
    10bb:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
    10c0:	c4 c3 65 4c e0 40    	vpblendvb %ymm4,%ymm8,%ymm3,%ymm4
    10c6:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm4,%ymm4        # 10ef <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ef>
    10cd:	00 00 70 
    10d0:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    10d4:	c4 e2 0d 90 3c a1    	vpgatherdd %ymm14,(%rcx,%ymm4,4),%ymm7
    10da:	c5 fd 66 e5          	vpcmpgtd %ymm5,%ymm0,%ymm4
    10de:	c5 fd 6f cf          	vmovdqa %ymm7,%ymm1
    10e2:	c4 e2 55 39 f8       	vpminsd %ymm0,%ymm5,%ymm7
    10e7:	c4 62 45 39 da       	vpminsd %ymm2,%ymm7,%ymm11
    10ec:	c5 c5 66 fa          	vpcmpgtd %ymm2,%ymm7,%ymm7
    10f0:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    10f4:	c4 c3 65 4c e0 40    	vpblendvb %ymm4,%ymm8,%ymm3,%ymm4
    10fa:	c4 41 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm14
    10ff:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
    1104:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm4,%ymm4        # 112d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x32d>
    110b:	00 00 70 
    110e:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1112:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1116:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    111a:	c4 c1 35 db d7       	vpand  %ymm15,%ymm9,%ymm2
    111f:	c4 62 45 90 24 a1    	vpgatherdd %ymm7,(%rcx,%ymm4,4),%ymm12
    1125:	c4 c1 2d db ff       	vpand  %ymm15,%ymm10,%ymm7
    112a:	c5 7e 7f a4 24 80 00 	vmovdqu %ymm12,0x80(%rsp)
    1131:	00 00 
    1133:	c5 05 db e1          	vpand  %ymm1,%ymm15,%ymm12
    1137:	c5 d5 72 f7 10       	vpslld $0x10,%ymm7,%ymm5
    113c:	c5 85 db a4 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm4
    1143:	00 00 
    1145:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    1149:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
    114e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1152:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    1157:	c5 7e 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm12
    115e:	00 00 
    1160:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    1164:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1169:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
    116e:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1173:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1177:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    117b:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    117f:	c4 c1 5d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm4
    1185:	c5 d5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm5
    118a:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    1190:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1195:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
    119c:	00 00 
    119e:	c4 c1 55 72 d2 08    	vpsrld $0x8,%ymm10,%ymm5
    11a4:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    11aa:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    11af:	c4 41 2d db f7       	vpand  %ymm15,%ymm10,%ymm14
    11b4:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    11b9:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    11be:	c5 7e 7f 8c 24 20 01 	vmovdqu %ymm9,0x120(%rsp)
    11c5:	00 00 
    11c7:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
    11cd:	c5 ed 72 f5 10       	vpslld $0x10,%ymm5,%ymm2
    11d2:	c4 41 45 fe d2       	vpaddd %ymm10,%ymm7,%ymm10
    11d7:	c4 41 6d fe e4       	vpaddd %ymm12,%ymm2,%ymm12
    11dc:	c5 7e 7f 94 24 00 01 	vmovdqu %ymm10,0x100(%rsp)
    11e3:	00 00 
    11e5:	0f 85 35 fd ff ff    	jne    f20 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120>
    11eb:	48 8b 58 28          	mov    0x28(%rax),%rbx
    11ef:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
    11f5:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    11f9:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    11fd:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    1203:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
    1209:	48 83 c0 60          	add    $0x60,%rax
    120d:	c4 e2 45 90 34 83    	vpgatherdd %ymm7,(%rbx,%ymm0,4),%ymm6
    1213:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
    1217:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    121b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1283 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x483>
    1222:	00 
    1223:	c4 e2 7d 90 3c 93    	vpgatherdd %ymm0,(%rbx,%ymm2,4),%ymm7
    1229:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
    122d:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    1231:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 1299 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x499>
    1238:	00 
    1239:	c4 a2 6d 90 04 9b    	vpgatherdd %ymm2,(%rbx,%ymm11,4),%ymm0
    123f:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
    1243:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 12ab <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ab>
    124a:	00 
    124b:	c4 62 7d 3d df       	vpmaxsd %ymm7,%ymm0,%ymm11
    1250:	c5 45 66 c8          	vpcmpgtd %ymm0,%ymm7,%ymm9
    1254:	c4 62 7d 39 d7       	vpminsd %ymm7,%ymm0,%ymm10
    1259:	c4 c1 4d 66 d3       	vpcmpgtd %ymm11,%ymm6,%ymm2
    125e:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    1263:	c4 43 65 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm9
    1269:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm9,%ymm9        # 1292 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x492>
    1270:	00 00 20 
    1273:	c4 e2 2d 39 d6       	vpminsd %ymm6,%ymm10,%ymm2
    1278:	c5 35 fe 8c 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm9
    127f:	00 00 
    1281:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    1288:	00 00 
    128a:	c5 2d 66 d6          	vpcmpgtd %ymm6,%ymm10,%ymm10
    128e:	c4 a2 75 90 14 89    	vpgatherdd %ymm1,(%rcx,%ymm9,4),%ymm2
    1294:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
    1298:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    129c:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    12a1:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    12a5:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    12ab:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    12b0:	c4 43 65 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm9
    12b6:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm9,%ymm9        # 12df <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4df>
    12bd:	00 00 a0 
    12c0:	c5 7e 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm10
    12c7:	00 00 
    12c9:	c4 41 2d fa c9       	vpsubd %ymm9,%ymm10,%ymm9
    12ce:	c4 22 75 90 14 89    	vpgatherdd %ymm1,(%rcx,%ymm9,4),%ymm10
    12d4:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    12db:	00 00 
    12dd:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    12e3:	c5 25 fe c9          	vpaddd %ymm1,%ymm11,%ymm9
    12e7:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    12ec:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    12f1:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    12f6:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    12fa:	c5 ad fa f2          	vpsubd %ymm2,%ymm10,%ymm6
    12fe:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    1303:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
    1309:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    130d:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    1312:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
    1316:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    131b:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    1320:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1324:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    1329:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    132d:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    1332:	c4 e2 55 90 04 8b    	vpgatherdd %ymm5,(%rbx,%ymm1,4),%ymm0
    1338:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
    133c:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    1340:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 13a8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5a8>
    1347:	00 
    1348:	c5 7d 6f e2          	vmovdqa %ymm2,%ymm12
    134c:	c4 e2 75 90 2c bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm5
    1352:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    1358:	48 8b 70 d0          	mov    -0x30(%rax),%rsi
    135c:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    1360:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 13c8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
    1367:	00 
    1368:	c4 e2 75 90 24 be    	vpgatherdd %ymm1,(%rsi,%ymm7,4),%ymm4
    136e:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 13d6 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5d6>
    1375:	00 
    1376:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
    137b:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    137f:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
    1383:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
    1388:	c4 c3 65 4c f0 60    	vpblendvb %ymm6,%ymm8,%ymm3,%ymm6
    138e:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 13b7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5b7>
    1395:	00 00 90 
    1398:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    139d:	c5 cd fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm6,%ymm6
    13a4:	00 00 
    13a6:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    13ab:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    13af:	c4 e2 25 90 0c b1    	vpgatherdd %ymm11,(%rcx,%ymm6,4),%ymm1
    13b5:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    13b9:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    13be:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    13c3:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    13c7:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    13cc:	c4 c3 65 4c d8 60    	vpblendvb %ymm6,%ymm8,%ymm3,%ymm3
    13d2:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    13d9:	00 00 
    13db:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm3,%ymm3        # 1404 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x604>
    13e2:	00 00 90 
    13e5:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    13e9:	c4 e2 25 90 34 99    	vpgatherdd %ymm11,(%rcx,%ymm3,4),%ymm6
    13ef:	c4 c1 45 fe da       	vpaddd %ymm10,%ymm7,%ymm3
    13f4:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    13f9:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    13fd:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1402:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1406:	c5 cd fa d9          	vpsubd %ymm1,%ymm6,%ymm3
    140a:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    140f:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    1414:	c5 fe 6f 9c 24 20 01 	vmovdqu 0x120(%rsp),%ymm3
    141b:	00 00 
    141d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1422:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    1426:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    142b:	c5 f5 fe 8c 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm1
    1432:	00 00 
    1434:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1438:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    143c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1441:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1445:	49 39 c3             	cmp    %rax,%r11
    1448:	74 16                	je     1460 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x660>
    144a:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    1450:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    1456:	e9 78 fb ff ff       	jmp    fd3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d3>
    145b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1460:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
    1467:	00 00 
    1469:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    146d:	c5 ed 72 f5 08       	vpslld $0x8,%ymm5,%ymm2
    1472:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1477:	49 83 c0 18          	add    $0x18,%r8
    147b:	c5 ed eb c9          	vpor   %ymm1,%ymm2,%ymm1
    147f:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    1483:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 14cc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6cc>
    148a:	00 00 
    148c:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1490:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1496:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    149b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    14a0:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    14a4:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    14aa:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    14b0:	4d 39 c1             	cmp    %r8,%r9
    14b3:	0f 85 07 fa ff ff    	jne    ec0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc0>
    14b9:	c5 f8 77             	vzeroupper
    14bc:	c5 f8 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm6
    14c3:	00 00 
    14c5:	c5 f8 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm7
    14cc:	00 00 
    14ce:	c5 78 28 84 24 80 01 	vmovaps 0x180(%rsp),%xmm8
    14d5:	00 00 
    14d7:	c5 78 28 8c 24 90 01 	vmovaps 0x190(%rsp),%xmm9
    14de:	00 00 
    14e0:	c5 78 28 94 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm10
    14e7:	00 00 
    14e9:	c5 78 28 9c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm11
    14f0:	00 00 
    14f2:	c5 78 28 a4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm12
    14f9:	00 00 
    14fb:	c5 78 28 ac 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm13
    1502:	00 00 
    1504:	c5 78 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm14
    150b:	00 00 
    150d:	c5 78 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm15
    1514:	00 00 
    1516:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
    151d:	5b                   	pop    %rbx
    151e:	5e                   	pop    %rsi
    151f:	c3                   	ret
    1520:	c5 fd 6f ea          	vmovdqa %ymm2,%ymm5
    1524:	e9 44 ff ff ff       	jmp    146d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x66d>
    1529:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    152d:	0f 85 40 f9 ff ff    	jne    e73 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    1533:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    153a:	0f 84 33 f9 ff ff    	je     e73 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    1540:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    1547:	0f 84 26 f9 ff ff    	je     e73 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    154d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    1554:	0f 84 19 f9 ff ff    	je     e73 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    155a:	4d 89 c8             	mov    %r9,%r8
    155d:	48 89 da             	mov    %rbx,%rdx
    1560:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    1565:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    156a:	e8 91 ea ff ff       	call   0 <jshc_channel::(anonymous namespace)::first_stage(jshc_channel::View const&, unsigned char*, unsigned long long)>
    156f:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
    1574:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    1579:	48 89 da             	mov    %rbx,%rdx
    157c:	c5 f8 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm6
    1583:	00 00 
    1585:	c5 f8 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm7
    158c:	00 00 
    158e:	c5 78 28 84 24 80 01 	vmovaps 0x180(%rsp),%xmm8
    1595:	00 00 
    1597:	c5 78 28 8c 24 90 01 	vmovaps 0x190(%rsp),%xmm9
    159e:	00 00 
    15a0:	c5 78 28 94 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm10
    15a7:	00 00 
    15a9:	c5 78 28 9c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm11
    15b0:	00 00 
    15b2:	c5 78 28 a4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm12
    15b9:	00 00 
    15bb:	c5 78 28 ac 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm13
    15c2:	00 00 
    15c4:	c5 78 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm14
    15cb:	00 00 
    15cd:	c5 78 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm15
    15d4:	00 00 
    15d6:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
    15dd:	5b                   	pop    %rbx
    15de:	5e                   	pop    %rsi
    15df:	e9 fc ef ff ff       	jmp    5e0 <jshc_channel::(anonymous namespace)::suffix_stages(jshc_channel::View const*, unsigned char*, unsigned long long)>
    15e4:	90                   	nop
    15e5:	90                   	nop
    15e6:	90                   	nop
    15e7:	90                   	nop
    15e8:	90                   	nop
    15e9:	90                   	nop
    15ea:	90                   	nop
    15eb:	90                   	nop
    15ec:	90                   	nop
    15ed:	90                   	nop
    15ee:	90                   	nop
    15ef:	90                   	nop
