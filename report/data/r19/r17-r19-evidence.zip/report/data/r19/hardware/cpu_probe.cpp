#include <cpuid.h>
#include <cstdio>
#include <cstdint>
int main() {
  unsigned a=0,b=0,c=0,d=0;
  __get_cpuid(1,&a,&b,&c,&d);
  const bool avx=(c&(1u<<28))!=0, osxsave=(c&(1u<<27))!=0;
  unsigned xlo=0,xhi=0;
  if(osxsave) __asm__ volatile("xgetbv" : "=a"(xlo), "=d"(xhi) : "c"(0));
  __get_cpuid_count(7,0,&a,&b,&c,&d);
  const bool avx2=(b&(1u<<5))!=0;
  std::printf("{\"avx_cpuid\":%s,\"osxsave_cpuid\":%s,\"xcr0\":%u,\"avx2_cpuid\":%s,\"avx2_usable\":%s}\n",avx?"true":"false",osxsave?"true":"false",xlo,avx2?"true":"false",(avx&&osxsave&&(xlo&6)==6&&avx2)?"true":"false");
}
