JSHC CPU runtime - Windows x86-64

Keep jshc.exe and the four bundled DLLs in the same directory. This package
does not need MinGW on PATH. Windows system DLLs are supplied by the OS and
are intentionally not bundled. Models and input images are separate assets.

Inspect the available backends:
  .\jshc.exe info

Map one competition-size image through four sparse models:
  .\jshc.exe apply --competition -i input.png -o output.png -k auto -t 4 stage1.slut stage2.slut stage3.slut stage4.slut

Verify a list of images and optionally save tightly packed RGB8 output:
  .\jshc.exe verify --competition -l images.txt --batch -k auto -t 4 -o outputs.raw stage1.slut stage2.slut stage3.slut stage4.slut

The image list contains one input path per line. Use absolute paths or paths
relative to your current directory. Raw output concatenates all images in
list order with no headers or padding. verify performs correctness preflight
only; it does not report benchmark timings.

auto checks CPU and OS AVX2 capability and retains a scalar fallback. This
package was validated on the recorded native Windows host, using only this
directory, System32 and Windows in the child process PATH. Its 100-image
output matched the accepted reference by SHA256 and byte-for-byte comparison.
This is local deployment evidence, not a fresh-machine or other-OS test.

deployment.json records each packaged binary's SHA256 and compiler source,
the recursive DLL imports, system dependencies and the verification inputs.
