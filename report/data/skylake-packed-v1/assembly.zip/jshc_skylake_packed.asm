
artifacts\skylake-packed-build-v1\CMakeFiles\jshc_skylake_packed.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec 48 02 00 00 	sub    $0x248,%rsp
       7:	c5 f8 29 b4 24 a0 01 	vmovaps %xmm6,0x1a0(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 b0 01 	vmovaps %xmm7,0x1b0(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 c0 01 	vmovaps %xmm8,0x1c0(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 d0 01 	vmovaps %xmm9,0x1d0(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 e0 01 	vmovaps %xmm10,0x1e0(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 f0 01 	vmovaps %xmm11,0x1f0(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 00 02 	vmovaps %xmm12,0x200(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 10 02 	vmovaps %xmm13,0x210(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 20 02 	vmovaps %xmm14,0x220(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 30 02 	vmovaps %xmm15,0x230(%rsp)
      5f:	00 00 
      61:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      65:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      6a:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      6e:	48 8b 41 18          	mov    0x18(%rcx),%rax
      72:	c5 fd 6f 0a          	vmovdqa (%rdx),%ymm1
      76:	44 8b 49 3c          	mov    0x3c(%rcx),%r9d
      7a:	44 8b 41 38          	mov    0x38(%rcx),%r8d
      7e:	c4 e2 dd 90 34 c8    	vpgatherdq %ymm4,(%rax,%xmm1,8),%ymm6
      84:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      88:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
      8e:	c4 62 dd 90 2c c8    	vpgatherdq %ymm4,(%rax,%xmm1,8),%ymm13
      94:	48 8b 41 20          	mov    0x20(%rcx),%rax
      98:	c5 fd 6f 4a 20       	vmovdqa 0x20(%rdx),%ymm1
      9d:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      a1:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
      a6:	c4 62 dd 90 14 c8    	vpgatherdq %ymm4,(%rax,%xmm1,8),%ymm10
      ac:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      b0:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
      b6:	c4 62 dd 90 24 c8    	vpgatherdq %ymm4,(%rax,%xmm1,8),%ymm12
      bc:	48 8b 41 28          	mov    0x28(%rcx),%rax
      c0:	c5 fd 6f 4a 40       	vmovdqa 0x40(%rdx),%ymm1
      c5:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      c9:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
      ce:	c4 e2 dd 90 3c c8    	vpgatherdq %ymm4,(%rax,%xmm1,8),%ymm7
      d4:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
      da:	c4 c1 79 6e e0       	vmovd  %r8d,%xmm4
      df:	c4 62 fd 90 1c c8    	vpgatherdq %ymm0,(%rax,%xmm1,8),%ymm11
      e5:	c5 f5 73 d7 33       	vpsrlq $0x33,%ymm7,%ymm1
      ea:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
      ef:	48 8b 41 30          	mov    0x30(%rcx),%rax
      f3:	c5 fd 70 c9 88       	vpshufd $0x88,%ymm1,%ymm1
      f8:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
      fd:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
     103:	c5 f1 6c c8          	vpunpcklqdq %xmm0,%xmm1,%xmm1
     107:	c4 c1 7d 73 d3 33    	vpsrlq $0x33,%ymm11,%ymm0
     10d:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     112:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
     118:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     11c:	c4 c1 6d 73 d2 33    	vpsrlq $0x33,%ymm10,%ymm2
     122:	c5 fd 70 d2 88       	vpshufd $0x88,%ymm2,%ymm2
     127:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     12d:	c4 e3 7d 39 d0 01    	vextracti128 $0x1,%ymm2,%xmm0
     133:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     137:	c4 c1 7d 73 d4 33    	vpsrlq $0x33,%ymm12,%ymm0
     13d:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     142:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
     148:	c5 f9 6c c3          	vpunpcklqdq %xmm3,%xmm0,%xmm0
     14c:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     152:	c5 fd 73 d6 33       	vpsrlq $0x33,%ymm6,%ymm0
     157:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     15c:	c4 e2 35 40 d2       	vpmulld %ymm2,%ymm9,%ymm2
     161:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
     167:	c5 f9 6c c3          	vpunpcklqdq %xmm3,%xmm0,%xmm0
     16b:	c4 c1 65 73 d5 33    	vpsrlq $0x33,%ymm13,%ymm3
     171:	c5 fd 70 db 88       	vpshufd $0x88,%ymm3,%ymm3
     176:	c4 e3 7d 39 dd 01    	vextracti128 $0x1,%ymm3,%xmm5
     17c:	c5 e1 6c dd          	vpunpcklqdq %xmm5,%xmm3,%xmm3
     180:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     184:	c4 e3 7d 38 c3 01    	vinserti128 $0x1,%xmm3,%ymm0,%ymm0
     18a:	c4 e2 5d 40 c0       	vpmulld %ymm0,%ymm4,%ymm0
     18f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     193:	c5 fd fe d1          	vpaddd %ymm1,%ymm0,%ymm2
     197:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
     19b:	b9 00 80 00 00       	mov    $0x8000,%ecx
     1a0:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
     1a6:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     1ab:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     1b0:	c5 fe 7f 9c 24 00 01 	vmovdqu %ymm3,0x100(%rsp)
     1b7:	00 00 
     1b9:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
     1bd:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     1c1:	c4 e2 6d 90 2c 98    	vpgatherdd %ymm2,(%rax,%ymm3,4),%ymm5
     1c7:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     1cd:	c4 c1 45 72 d7 0f    	vpsrld $0xf,%ymm15,%ymm7
     1d3:	c5 7d 6f f3          	vmovdqa %ymm3,%ymm14
     1d7:	c5 7e 7f 5c 24 60    	vmovdqu %ymm11,0x60(%rsp)
     1dd:	c5 fd 70 4c 24 40 88 	vpshufd $0x88,0x40(%rsp),%ymm1
     1e4:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
     1ea:	c5 f1 6c c8          	vpunpcklqdq %xmm0,%xmm1,%xmm1
     1ee:	c5 fd 70 44 24 60 88 	vpshufd $0x88,0x60(%rsp),%ymm0
     1f5:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
     1fb:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
     202:	00 00 
     204:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     208:	c5 7e 7f 94 24 80 00 	vmovdqu %ymm10,0x80(%rsp)
     20f:	00 00 
     211:	c5 fd 70 94 24 80 00 	vpshufd $0x88,0x80(%rsp),%ymm2
     218:	00 00 88 
     21b:	c4 c1 2d 72 d7 1f    	vpsrld $0x1f,%ymm15,%ymm10
     221:	c5 7e 7f a4 24 a0 00 	vmovdqu %ymm12,0xa0(%rsp)
     228:	00 00 
     22a:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     230:	c4 e3 7d 39 d0 01    	vextracti128 $0x1,%ymm2,%xmm0
     236:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     23b:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     23f:	c5 fd 70 84 24 a0 00 	vpshufd $0x88,0xa0(%rsp),%ymm0
     246:	00 00 88 
     249:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
     24f:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
     256:	00 00 
     258:	c5 f9 6c c3          	vpunpcklqdq %xmm3,%xmm0,%xmm0
     25c:	c5 7e 7f ac 24 e0 00 	vmovdqu %ymm13,0xe0(%rsp)
     263:	00 00 
     265:	c5 f5 db cf          	vpand  %ymm7,%ymm1,%ymm1
     269:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     26f:	c5 fd 70 84 24 c0 00 	vpshufd $0x88,0xc0(%rsp),%ymm0
     276:	00 00 88 
     279:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
     27f:	c5 f9 6c c3          	vpunpcklqdq %xmm3,%xmm0,%xmm0
     283:	c5 fd 70 9c 24 e0 00 	vpshufd $0x88,0xe0(%rsp),%ymm3
     28a:	00 00 88 
     28d:	c4 e3 7d 39 dd 01    	vextracti128 $0x1,%ymm3,%xmm5
     293:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     297:	c5 e1 6c dd          	vpunpcklqdq %xmm5,%xmm3,%xmm3
     29b:	c4 e3 7d 38 c3 01    	vinserti128 $0x1,%xmm3,%ymm0,%ymm0
     2a1:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     2a5:	c4 62 7d 3d c2       	vpmaxsd %ymm2,%ymm0,%ymm8
     2aa:	c5 ed 66 d8          	vpcmpgtd %ymm0,%ymm2,%ymm3
     2ae:	c4 e2 7d 39 f2       	vpminsd %ymm2,%ymm0,%ymm6
     2b3:	c4 c1 75 66 e8       	vpcmpgtd %ymm8,%ymm1,%ymm5
     2b8:	c4 62 4d 39 e9       	vpminsd %ymm1,%ymm6,%ymm13
     2bd:	c4 62 3d 3d c1       	vpmaxsd %ymm1,%ymm8,%ymm8
     2c2:	c5 cd 66 f1          	vpcmpgtd %ymm1,%ymm6,%ymm6
     2c6:	c4 c3 5d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm4,%ymm3
     2cc:	c4 c3 65 4c da 50    	vpblendvb %ymm5,%ymm10,%ymm3,%ymm3
     2d2:	c5 e5 fe 1c 24       	vpaddd (%rsp),%ymm3,%ymm3
     2d7:	c4 e2 1d 90 2c 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm5
     2dd:	c5 fd 66 da          	vpcmpgtd %ymm2,%ymm0,%ymm3
     2e1:	c5 7e 7f 74 24 20    	vmovdqu %ymm14,0x20(%rsp)
     2e7:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     2ec:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     2f0:	c4 c3 5d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm4,%ymm3
     2f6:	c4 c3 65 4c da 60    	vpblendvb %ymm6,%ymm10,%ymm3,%ymm3
     2fc:	c5 8d fa db          	vpsubd %ymm3,%ymm14,%ymm3
     300:	c4 41 3d fe f5       	vpaddd %ymm13,%ymm8,%ymm14
     305:	c4 62 1d 90 1c 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm11
     30b:	c4 c1 65 72 d7 18    	vpsrld $0x18,%ymm15,%ymm3
     311:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     316:	c5 25 db db          	vpand  %ymm3,%ymm11,%ymm11
     31a:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     31e:	c5 65 db a4 24 00 01 	vpand  0x100(%rsp),%ymm3,%ymm12
     325:	00 00 
     327:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     32b:	c5 a5 fa cd          	vpsubd %ymm5,%ymm11,%ymm1
     32f:	c4 e2 7d 40 c9       	vpmulld %ymm1,%ymm0,%ymm1
     334:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
     338:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     33d:	c4 c1 4d 72 f4 10    	vpslld $0x10,%ymm12,%ymm6
     343:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     348:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     34d:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
     354:	00 00 
     356:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
     35d:	00 00 
     35f:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
     363:	c5 e5 db 84 24 20 01 	vpand  0x120(%rsp),%ymm3,%ymm0
     36a:	00 00 
     36c:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     371:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
     377:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     37c:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
     380:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
     386:	c5 7e 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm13
     38d:	00 00 
     38f:	c5 f5 73 d1 11       	vpsrlq $0x11,%ymm1,%ymm1
     394:	c5 fd 70 c9 88       	vpshufd $0x88,%ymm1,%ymm1
     399:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     39d:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
     3a1:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
     3a7:	c5 f1 6c c8          	vpunpcklqdq %xmm0,%xmm1,%xmm1
     3ab:	c4 c1 7d 73 d3 11    	vpsrlq $0x11,%ymm11,%ymm0
     3b1:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     3b6:	c5 8d 72 d6 10       	vpsrld $0x10,%ymm6,%ymm14
     3bb:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     3c2:	00 00 
     3c4:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
     3ca:	c5 7e 7f b4 24 80 01 	vmovdqu %ymm14,0x180(%rsp)
     3d1:	00 00 
     3d3:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     3d7:	c5 fe 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm2
     3de:	00 00 
     3e0:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     3e6:	c5 ed 73 d2 11       	vpsrlq $0x11,%ymm2,%ymm2
     3eb:	c5 f5 db cf          	vpand  %ymm7,%ymm1,%ymm1
     3ef:	c5 fd 70 d2 88       	vpshufd $0x88,%ymm2,%ymm2
     3f4:	c4 e3 7d 39 d0 01    	vextracti128 $0x1,%ymm2,%xmm0
     3fa:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     3fe:	c4 c1 7d 73 d4 11    	vpsrlq $0x11,%ymm12,%ymm0
     404:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     409:	c4 e3 7d 39 c5 01    	vextracti128 $0x1,%ymm0,%xmm5
     40f:	c5 f9 6c c5          	vpunpcklqdq %xmm5,%xmm0,%xmm0
     413:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     419:	c5 fd 73 d6 11       	vpsrlq $0x11,%ymm6,%ymm0
     41e:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     423:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     427:	c4 e3 7d 39 c5 01    	vextracti128 $0x1,%ymm0,%xmm5
     42d:	c5 f9 6c c5          	vpunpcklqdq %xmm5,%xmm0,%xmm0
     431:	c4 c1 55 73 d5 11    	vpsrlq $0x11,%ymm13,%ymm5
     437:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     43c:	c5 fd 70 ed 88       	vpshufd $0x88,%ymm5,%ymm5
     441:	c4 e3 7d 39 ee 01    	vextracti128 $0x1,%ymm5,%xmm6
     447:	c5 d1 6c ee          	vpunpcklqdq %xmm6,%xmm5,%xmm5
     44b:	c4 e3 7d 38 c5 01    	vinserti128 $0x1,%xmm5,%ymm0,%ymm0
     451:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     455:	c4 62 7d 3d e2       	vpmaxsd %ymm2,%ymm0,%ymm12
     45a:	c5 ed 66 f0          	vpcmpgtd %ymm0,%ymm2,%ymm6
     45e:	c4 62 7d 39 c2       	vpminsd %ymm2,%ymm0,%ymm8
     463:	c4 c1 75 66 ec       	vpcmpgtd %ymm12,%ymm1,%ymm5
     468:	c4 62 3d 39 f1       	vpminsd %ymm1,%ymm8,%ymm14
     46d:	c4 62 1d 3d e1       	vpmaxsd %ymm1,%ymm12,%ymm12
     472:	c5 3d 66 c1          	vpcmpgtd %ymm1,%ymm8,%ymm8
     476:	c4 c3 5d 4c f1 60    	vpblendvb %ymm6,%ymm9,%ymm4,%ymm6
     47c:	c4 c3 4d 4c f2 50    	vpblendvb %ymm5,%ymm10,%ymm6,%ymm6
     482:	c5 cd fe 34 24       	vpaddd (%rsp),%ymm6,%ymm6
     487:	c4 e2 15 90 2c b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm5
     48d:	c5 fd 66 f2          	vpcmpgtd %ymm2,%ymm0,%ymm6
     491:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     495:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
     49a:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     49e:	c4 c3 5d 4c f1 60    	vpblendvb %ymm6,%ymm9,%ymm4,%ymm6
     4a4:	c4 c3 4d 4c f2 80    	vpblendvb %ymm8,%ymm10,%ymm6,%ymm6
     4aa:	c5 7e 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm8
     4b0:	c5 bd fa f6          	vpsubd %ymm6,%ymm8,%ymm6
     4b4:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     4b9:	c4 62 3d 90 1c b0    	vpgatherdd %ymm8,(%rax,%ymm6,4),%ymm11
     4bf:	c5 7e 7f b4 24 60 01 	vmovdqu %ymm14,0x160(%rsp)
     4c6:	00 00 
     4c8:	c4 41 1d fe f6       	vpaddd %ymm14,%ymm12,%ymm14
     4cd:	c5 7e 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm8
     4d4:	00 00 
     4d6:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
     4dc:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     4e1:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
     4e8:	00 00 
     4ea:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     4ef:	c5 25 db db          	vpand  %ymm3,%ymm11,%ymm11
     4f3:	c4 c1 15 72 d0 08    	vpsrld $0x8,%ymm8,%ymm13
     4f9:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     4fd:	c5 a5 fa cd          	vpsubd %ymm5,%ymm11,%ymm1
     501:	c5 bd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm8
     506:	c5 15 db eb          	vpand  %ymm3,%ymm13,%ymm13
     50a:	c4 e2 7d 40 c9       	vpmulld %ymm1,%ymm0,%ymm1
     50f:	c4 c1 4d 72 f5 10    	vpslld $0x10,%ymm13,%ymm6
     515:	c5 3d db c3          	vpand  %ymm3,%ymm8,%ymm8
     519:	c5 cd fe b4 24 40 01 	vpaddd 0x140(%rsp),%ymm6,%ymm6
     520:	00 00 
     522:	c4 41 3d fa c3       	vpsubd %ymm11,%ymm8,%ymm8
     527:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
     52d:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     532:	c4 62 3d 40 84 24 60 	vpmulld 0x160(%rsp),%ymm8,%ymm8
     539:	01 00 00 
     53c:	c5 7e 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm13
     543:	00 00 
     545:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
     54a:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
     551:	00 00 
     553:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
     557:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
     55d:	c5 f5 73 d1 22       	vpsrlq $0x22,%ymm1,%ymm1
     562:	c5 fd 70 c9 88       	vpshufd $0x88,%ymm1,%ymm1
     567:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     56b:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
     571:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
     576:	c5 f1 6c c8          	vpunpcklqdq %xmm0,%xmm1,%xmm1
     57a:	c4 c1 7d 73 d3 22    	vpsrlq $0x22,%ymm11,%ymm0
     580:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     585:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     58a:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
     590:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     594:	c5 fe 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm2
     59b:	00 00 
     59d:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     5a3:	c5 ed 73 d2 22       	vpsrlq $0x22,%ymm2,%ymm2
     5a8:	c5 f5 db cf          	vpand  %ymm7,%ymm1,%ymm1
     5ac:	c5 fd 70 d2 88       	vpshufd $0x88,%ymm2,%ymm2
     5b1:	c4 e3 7d 39 d0 01    	vextracti128 $0x1,%ymm2,%xmm0
     5b7:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     5bb:	c4 c1 7d 73 d4 22    	vpsrlq $0x22,%ymm12,%ymm0
     5c1:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     5c6:	c4 e3 7d 39 c5 01    	vextracti128 $0x1,%ymm0,%xmm5
     5cc:	c5 f9 6c c5          	vpunpcklqdq %xmm5,%xmm0,%xmm0
     5d0:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
     5d7:	00 00 
     5d9:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     5df:	c5 fd 73 d5 22       	vpsrlq $0x22,%ymm5,%ymm0
     5e4:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     5e8:	c5 fd 70 c0 88       	vpshufd $0x88,%ymm0,%ymm0
     5ed:	c4 e3 7d 39 c5 01    	vextracti128 $0x1,%ymm0,%xmm5
     5f3:	c5 f9 6c c5          	vpunpcklqdq %xmm5,%xmm0,%xmm0
     5f7:	c4 c1 55 73 d5 22    	vpsrlq $0x22,%ymm13,%ymm5
     5fd:	c5 fd 70 ed 88       	vpshufd $0x88,%ymm5,%ymm5
     602:	c4 c3 7d 39 e8 01    	vextracti128 $0x1,%ymm5,%xmm8
     608:	c4 c1 51 6c e8       	vpunpcklqdq %xmm8,%xmm5,%xmm5
     60d:	c4 e3 7d 38 c5 01    	vinserti128 $0x1,%xmm5,%ymm0,%ymm0
     613:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     617:	c4 62 7d 3d c2       	vpmaxsd %ymm2,%ymm0,%ymm8
     61c:	c5 ed 66 f8          	vpcmpgtd %ymm0,%ymm2,%ymm7
     620:	c4 62 7d 39 da       	vpminsd %ymm2,%ymm0,%ymm11
     625:	c4 c1 75 66 e8       	vpcmpgtd %ymm8,%ymm1,%ymm5
     62a:	c4 62 25 39 e1       	vpminsd %ymm1,%ymm11,%ymm12
     62f:	c4 62 3d 3d c1       	vpmaxsd %ymm1,%ymm8,%ymm8
     634:	c5 25 66 d9          	vpcmpgtd %ymm1,%ymm11,%ymm11
     638:	c4 c3 5d 4c f9 70    	vpblendvb %ymm7,%ymm9,%ymm4,%ymm7
     63e:	c4 c3 45 4c fa 50    	vpblendvb %ymm5,%ymm10,%ymm7,%ymm7
     644:	c5 c5 fe 3c 24       	vpaddd (%rsp),%ymm7,%ymm7
     649:	c4 e2 0d 90 2c b8    	vpgatherdd %ymm14,(%rax,%ymm7,4),%ymm5
     64f:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
     653:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     657:	c5 7e 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm14
     65e:	00 00 
     660:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     665:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     669:	c4 c3 5d 4c e1 70    	vpblendvb %ymm7,%ymm9,%ymm4,%ymm4
     66f:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     675:	c4 c3 5d 4c e2 b0    	vpblendvb %ymm11,%ymm10,%ymm4,%ymm4
     67b:	c4 41 3d fe dc       	vpaddd %ymm12,%ymm8,%ymm11
     680:	c5 c5 fa e4          	vpsubd %ymm4,%ymm7,%ymm4
     684:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
     68b:	00 00 
     68d:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     692:	c4 62 05 90 0c a0    	vpgatherdd %ymm15,(%rax,%ymm4,4),%ymm9
     698:	c5 fe 6f a4 24 00 01 	vmovdqu 0x100(%rsp),%ymm4
     69f:	00 00 
     6a1:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     6a5:	c5 7d 7f 32          	vmovdqa %ymm14,(%rdx)
     6a9:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     6af:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     6b4:	c5 fd 7f 72 20       	vmovdqa %ymm6,0x20(%rdx)
     6b9:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     6be:	c5 35 db cb          	vpand  %ymm3,%ymm9,%ymm9
     6c2:	c5 c5 db fb          	vpand  %ymm3,%ymm7,%ymm7
     6c6:	c5 dd db e3          	vpand  %ymm3,%ymm4,%ymm4
     6ca:	c5 b5 fa cd          	vpsubd %ymm5,%ymm9,%ymm1
     6ce:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     6d3:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     6d8:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     6dd:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     6e1:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     6e6:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
     6eb:	c5 2d fe 94 24 40 01 	vpaddd 0x140(%rsp),%ymm10,%ymm10
     6f2:	00 00 
     6f4:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
     6f9:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
     6fd:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     701:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     706:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     70b:	c5 f8 77             	vzeroupper
     70e:	c5 f8 28 b4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm6
     715:	00 00 
     717:	c5 f8 28 bc 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm7
     71e:	00 00 
     720:	c5 78 28 84 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm8
     727:	00 00 
     729:	c5 78 28 8c 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm9
     730:	00 00 
     732:	c5 78 28 94 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm10
     739:	00 00 
     73b:	c5 78 28 9c 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm11
     742:	00 00 
     744:	c5 78 28 a4 24 00 02 	vmovaps 0x200(%rsp),%xmm12
     74b:	00 00 
     74d:	c5 78 28 ac 24 10 02 	vmovaps 0x210(%rsp),%xmm13
     754:	00 00 
     756:	c5 78 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm14
     75d:	00 00 
     75f:	c5 78 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm15
     766:	00 00 
     768:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
     76f:	c3                   	ret

0000000000000770 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     770:	41 55                	push   %r13
     772:	41 54                	push   %r12
     774:	55                   	push   %rbp
     775:	57                   	push   %rdi
     776:	56                   	push   %rsi
     777:	53                   	push   %rbx
     778:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
     77f:	c5 f8 29 b4 24 b0 01 	vmovaps %xmm6,0x1b0(%rsp)
     786:	00 00 
     788:	c5 f8 29 bc 24 c0 01 	vmovaps %xmm7,0x1c0(%rsp)
     78f:	00 00 
     791:	c5 78 29 84 24 d0 01 	vmovaps %xmm8,0x1d0(%rsp)
     798:	00 00 
     79a:	c5 78 29 8c 24 e0 01 	vmovaps %xmm9,0x1e0(%rsp)
     7a1:	00 00 
     7a3:	c5 78 29 94 24 f0 01 	vmovaps %xmm10,0x1f0(%rsp)
     7aa:	00 00 
     7ac:	c5 78 29 9c 24 00 02 	vmovaps %xmm11,0x200(%rsp)
     7b3:	00 00 
     7b5:	c5 78 29 a4 24 10 02 	vmovaps %xmm12,0x210(%rsp)
     7bc:	00 00 
     7be:	c5 78 29 ac 24 20 02 	vmovaps %xmm13,0x220(%rsp)
     7c5:	00 00 
     7c7:	c5 78 29 b4 24 30 02 	vmovaps %xmm14,0x230(%rsp)
     7ce:	00 00 
     7d0:	c5 78 29 bc 24 40 02 	vmovaps %xmm15,0x240(%rsp)
     7d7:	00 00 
     7d9:	4c 8d 9c 24 ff 00 00 	lea    0xff(%rsp),%r11
     7e0:	00 
     7e1:	48 89 cd             	mov    %rcx,%rbp
     7e4:	48 89 d6             	mov    %rdx,%rsi
     7e7:	4d 89 c4             	mov    %r8,%r12
     7ea:	49 83 e3 e0          	and    $0xffffffffffffffe0,%r11
     7ee:	48 83 fa 04          	cmp    $0x4,%rdx
     7f2:	0f 84 77 03 00 00    	je     b6f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ff>
     7f8:	4d 85 c9             	test   %r9,%r9
     7fb:	0f 84 1a 0c 00 00    	je     141b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcab>
     801:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # 849 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd9>
     808:	00 
     809:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
     80d:	45 31 ed             	xor    %r13d,%r13d
     810:	c4 41 3d 76 c0       	vpcmpeqd %ymm8,%ymm8,%ymm8
     815:	48 c1 ef 03          	shr    $0x3,%rdi
     819:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     81f:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 887 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x117>
     826:	00 
     827:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     82d:	0f 1f 00             	nopl   (%rax)
     830:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     836:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     83d:	c4 c1 65 72 d0 18    	vpsrld $0x18,%ymm8,%ymm3
     843:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     849:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     84f:	c4 e2 7d 00 44 24 40 	vpshufb 0x40(%rsp),%ymm0,%ymm0
     856:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     85b:	c5 fd db d3          	vpand  %ymm3,%ymm0,%ymm2
     85f:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
     863:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     868:	c5 fd 6f c3          	vmovdqa %ymm3,%ymm0
     86c:	48 85 f6             	test   %rsi,%rsi
     86f:	0f 84 a6 02 00 00    	je     b1b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ab>
     875:	c4 c1 5d 72 d0 1f    	vpsrld $0x1f,%ymm8,%ymm4
     87b:	49 89 ea             	mov    %rbp,%r10
     87e:	31 db                	xor    %ebx,%ebx
     880:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     886:	e9 44 02 00 00       	jmp    acf <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x35f>
     88b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     890:	49 8b 02             	mov    (%r10),%rax
     893:	c5 7d 7f c7          	vmovdqa %ymm8,%ymm7
     897:	41 8b 4a 3c          	mov    0x3c(%r10),%ecx
     89b:	c5 7d 7f c6          	vmovdqa %ymm8,%ymm6
     89f:	41 8b 52 38          	mov    0x38(%r10),%edx
     8a3:	48 ff c3             	inc    %rbx
     8a6:	49 83 c2 48          	add    $0x48,%r10
     8aa:	c4 e2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm3
     8b0:	49 8b 42 c0          	mov    -0x40(%r10),%rax
     8b4:	c5 7d 7f c7          	vmovdqa %ymm8,%ymm7
     8b8:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     8bc:	c5 79 6e ea          	vmovd  %edx,%xmm13
     8c0:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     8c5:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     8c9:	c4 62 45 90 14 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm10
     8cf:	49 8b 42 c8          	mov    -0x38(%r10),%rax
     8d3:	c5 7d 7f c7          	vmovdqa %ymm8,%ymm7
     8d7:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     8dc:	c4 c1 75 72 d2 11    	vpsrld $0x11,%ymm10,%ymm1
     8e2:	c5 2d db 15 00 00 00 	vpand  0x0(%rip),%ymm10,%ymm10        # 8ea <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17a>
     8e9:	00 
     8ea:	c5 f9 6e ea          	vmovd  %edx,%xmm5
     8ee:	c4 62 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm11
     8f4:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     8f9:	49 8b 42 e8          	mov    -0x18(%r10),%rax
     8fd:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     902:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     907:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
     90c:	c5 7d 7f c7          	vmovdqa %ymm8,%ymm7
     910:	c4 c1 6d 72 d3 11    	vpsrld $0x11,%ymm11,%ymm2
     916:	c5 25 db 1d 00 00 00 	vpand  0x0(%rip),%ymm11,%ymm11        # 91e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ae>
     91d:	00 
     91e:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     922:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     926:	c5 e5 db 15 00 00 00 	vpand  0x0(%rip),%ymm3,%ymm2        # 92e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1be>
     92d:	00 
     92e:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
     934:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
     938:	c4 42 6d 3d ca       	vpmaxsd %ymm10,%ymm2,%ymm9
     93d:	c5 ad 66 da          	vpcmpgtd %ymm2,%ymm10,%ymm3
     941:	c4 42 6d 39 fa       	vpminsd %ymm10,%ymm2,%ymm15
     946:	c4 c1 25 66 f1       	vpcmpgtd %ymm9,%ymm11,%ymm6
     94b:	c4 42 05 39 e3       	vpminsd %ymm11,%ymm15,%ymm12
     950:	c4 42 35 3d cb       	vpmaxsd %ymm11,%ymm9,%ymm9
     955:	c4 e2 45 90 04 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm0
     95b:	c4 41 05 66 fb       	vpcmpgtd %ymm11,%ymm15,%ymm15
     960:	c4 c1 35 fe fc       	vpaddd %ymm12,%ymm9,%ymm7
     965:	c4 c3 15 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm13,%ymm3
     96b:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
     96f:	c4 e3 65 4c 5c 24 20 	vpblendvb %ymm6,0x20(%rsp),%ymm3,%ymm3
     976:	60 
     977:	c4 c1 6d fe f2       	vpaddd %ymm10,%ymm2,%ymm6
     97c:	c4 c1 6d 66 d2       	vpcmpgtd %ymm10,%ymm2,%ymm2
     981:	c5 f5 fe db          	vpaddd %ymm3,%ymm1,%ymm3
     985:	c5 7d 7f c1          	vmovdqa %ymm8,%ymm1
     989:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
     98d:	c4 e2 75 90 34 98    	vpgatherdd %ymm1,(%rax,%ymm3,4),%ymm6
     993:	c4 c3 15 4c ce 20    	vpblendvb %ymm2,%ymm14,%ymm13,%ymm1
     999:	c5 8d 72 d4 08       	vpsrld $0x8,%ymm4,%ymm14
     99e:	c5 7d 7f c2          	vmovdqa %ymm8,%ymm2
     9a2:	c4 e3 75 4c 4c 24 20 	vpblendvb %ymm15,0x20(%rsp),%ymm1,%ymm1
     9a9:	f0 
     9aa:	c5 85 72 d6 08       	vpsrld $0x8,%ymm6,%ymm15
     9af:	c5 d5 fa e9          	vpsubd %ymm1,%ymm5,%ymm5
     9b3:	c4 e2 6d 90 1c a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm3
     9b9:	c4 c1 55 72 d0 18    	vpsrld $0x18,%ymm8,%ymm5
     9bf:	b8 00 80 00 00       	mov    $0x8000,%eax
     9c4:	c5 4d db ed          	vpand  %ymm5,%ymm6,%ymm13
     9c8:	c5 5d db d5          	vpand  %ymm5,%ymm4,%ymm10
     9cc:	c5 e5 db cd          	vpand  %ymm5,%ymm3,%ymm1
     9d0:	c5 fd db d5          	vpand  %ymm5,%ymm0,%ymm2
     9d4:	c4 c1 25 72 f2 10    	vpslld $0x10,%ymm10,%ymm11
     9da:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
     9df:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     9e3:	c4 42 2d 40 d1       	vpmulld %ymm9,%ymm10,%ymm10
     9e8:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
     9ed:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
     9f2:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     9f7:	c5 0d db f5          	vpand  %ymm5,%ymm14,%ymm14
     9fb:	c4 c1 15 72 f6 10    	vpslld $0x10,%ymm14,%ymm13
     a01:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     a06:	c5 05 db fd          	vpand  %ymm5,%ymm15,%ymm15
     a0a:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
     a0f:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     a14:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
     a18:	c4 42 0d 40 f1       	vpmulld %ymm9,%ymm14,%ymm14
     a1d:	c5 cd db f5          	vpand  %ymm5,%ymm6,%ymm6
     a21:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
     a26:	c5 79 6e d0          	vmovd  %eax,%xmm10
     a2a:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     a2f:	c4 41 25 fe da       	vpaddd %ymm10,%ymm11,%ymm11
     a34:	c4 41 15 fe ea       	vpaddd %ymm10,%ymm13,%ymm13
     a39:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     a3e:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
     a43:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     a47:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     a4c:	c5 25 db dd          	vpand  %ymm5,%ymm11,%ymm11
     a50:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     a55:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     a5a:	c5 f5 db cd          	vpand  %ymm5,%ymm1,%ymm1
     a5e:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     a63:	c4 41 25 fa df       	vpsubd %ymm15,%ymm11,%ymm11
     a68:	c5 e5 db dd          	vpand  %ymm5,%ymm3,%ymm3
     a6c:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     a71:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
     a76:	c5 fd db c5          	vpand  %ymm5,%ymm0,%ymm0
     a7a:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     a7e:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
     a82:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     a87:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     a8c:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     a91:	c4 41 25 fe dd       	vpaddd %ymm13,%ymm11,%ymm11
     a96:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     a9b:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     aa0:	c5 a5 72 f4 10       	vpslld $0x10,%ymm4,%ymm11
     aa5:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     aa9:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     aae:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ab3:	c4 41 25 fe da       	vpaddd %ymm10,%ymm11,%ymm11
     ab8:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
     abd:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     ac1:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     ac5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     aca:	48 39 de             	cmp    %rbx,%rsi
     acd:	74 4c                	je     b1b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ab>
     acf:	41 80 7a 40 00       	cmpb   $0x0,0x40(%r10)
     ad4:	0f 85 b6 fd ff ff    	jne    890 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120>
     ada:	c4 c1 7d 7f 13       	vmovdqa %ymm2,(%r11)
     adf:	4c 89 d1             	mov    %r10,%rcx
     ae2:	4c 89 da             	mov    %r11,%rdx
     ae5:	c4 c1 7d 7f 4b 20    	vmovdqa %ymm1,0x20(%r11)
     aeb:	c4 c1 7d 7f 43 40    	vmovdqa %ymm0,0x40(%r11)
     af1:	c5 f8 77             	vzeroupper
     af4:	e8 07 f5 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     af9:	48 ff c3             	inc    %rbx
     afc:	c4 c1 7d 6f 13       	vmovdqa (%r11),%ymm2
     b01:	c4 c1 7d 6f 4b 20    	vmovdqa 0x20(%r11),%ymm1
     b07:	c4 c1 7d 6f 43 40    	vmovdqa 0x40(%r11),%ymm0
     b0d:	c4 41 3d 76 c0       	vpcmpeqd %ymm8,%ymm8,%ymm8
     b12:	49 83 c2 48          	add    $0x48,%r10
     b16:	48 39 de             	cmp    %rbx,%rsi
     b19:	75 b4                	jne    acf <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x35f>
     b1b:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
     b20:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     b25:	49 83 c4 18          	add    $0x18,%r12
     b29:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
     b2d:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     b31:	c4 e2 7d 00 44 24 60 	vpshufb 0x60(%rsp),%ymm0,%ymm0
     b38:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     b3c:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     b42:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     b47:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     b4c:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     b50:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
     b57:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
     b5e:	4c 39 ef             	cmp    %r13,%rdi
     b61:	0f 84 b1 08 00 00    	je     1418 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xca8>
     b67:	49 ff c5             	inc    %r13
     b6a:	e9 c1 fc ff ff       	jmp    830 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc0>
     b6f:	80 79 40 00          	cmpb   $0x0,0x40(%rcx)
     b73:	0f 85 7f fc ff ff    	jne    7f8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     b79:	80 b9 88 00 00 00 00 	cmpb   $0x0,0x88(%rcx)
     b80:	0f 84 72 fc ff ff    	je     7f8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     b86:	80 b9 d0 00 00 00 00 	cmpb   $0x0,0xd0(%rcx)
     b8d:	0f 84 65 fc ff ff    	je     7f8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     b93:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     b9a:	0f 84 58 fc ff ff    	je     7f8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     ba0:	4d 85 c9             	test   %r9,%r9
     ba3:	0f 84 72 08 00 00    	je     141b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcab>
     ba9:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # bf1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x481>
     bb0:	00 
     bb1:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     bb5:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     bba:	45 31 d2             	xor    %r10d,%r10d
     bbd:	48 c1 e8 03          	shr    $0x3,%rax
     bc1:	c4 c1 05 72 d3 18    	vpsrld $0x18,%ymm11,%ymm15
     bc7:	49 8d 73 60          	lea    0x60(%r11),%rsi
     bcb:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     bd1:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # c39 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4c9>
     bd8:	00 
     bd9:	48 8d 58 01          	lea    0x1(%rax),%rbx
     bdd:	b8 00 80 00 00       	mov    $0x8000,%eax
     be2:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     be8:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     bec:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     bf1:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     bf7:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     bfd:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     c04:	48 89 f2             	mov    %rsi,%rdx
     c07:	48 89 e9             	mov    %rbp,%rcx
     c0a:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     c10:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     c16:	c4 e2 7d 00 44 24 40 	vpshufb 0x40(%rsp),%ymm0,%ymm0
     c1d:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     c22:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     c27:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     c2c:	c4 c1 7d 7f 43 60    	vmovdqa %ymm0,0x60(%r11)
     c32:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
     c37:	c4 c1 7d 7f 83 80 00 	vmovdqa %ymm0,0x80(%r11)
     c3e:	00 00 
     c40:	c4 c1 7d 7f 93 a0 00 	vmovdqa %ymm2,0xa0(%r11)
     c47:	00 00 
     c49:	c5 f8 77             	vzeroupper
     c4c:	e8 af f3 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     c51:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     c56:	48 8b 45 48          	mov    0x48(%rbp),%rax
     c5a:	c4 c1 7d 6f 43 60    	vmovdqa 0x60(%r11),%ymm0
     c60:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     c64:	8b 8d 84 00 00 00    	mov    0x84(%rbp),%ecx
     c6a:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     c6e:	8b 95 80 00 00 00    	mov    0x80(%rbp),%edx
     c74:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     c78:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
     c7d:	49 ff c2             	inc    %r10
     c80:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
     c86:	48 8b 45 50          	mov    0x50(%rbp),%rax
     c8a:	c4 c1 7d 6f 83 80 00 	vmovdqa 0x80(%r11),%ymm0
     c91:	00 00 
     c93:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     c97:	c5 79 6e e1          	vmovd  %ecx,%xmm12
     c9b:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
     ca0:	49 83 c4 18          	add    $0x18,%r12
     ca4:	c4 e2 5d 90 1c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm3
     caa:	48 8b 45 58          	mov    0x58(%rbp),%rax
     cae:	c4 c1 7d 6f 83 a0 00 	vmovdqa 0xa0(%r11),%ymm0
     cb5:	00 00 
     cb7:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     cbc:	c4 e2 4d 90 24 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm4
     cc2:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     cc7:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     ccb:	48 8b 45 78          	mov    0x78(%rbp),%rax
     ccf:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     cd4:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     cd9:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     cdd:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
     ce2:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
     ce7:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     ceb:	c4 c1 6d 72 d3 0f    	vpsrld $0xf,%ymm11,%ymm2
     cf1:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     cf5:	c5 f9 6e ea          	vmovd  %edx,%xmm5
     cf9:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
     cfd:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     d02:	c4 62 45 90 3c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm15
     d08:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
     d0c:	c5 d5 fe f8          	vpaddd %ymm0,%ymm5,%ymm7
     d10:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
     d14:	c4 62 75 39 d3       	vpminsd %ymm3,%ymm1,%ymm10
     d19:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     d20:	00 00 
     d22:	c5 fd 6f ef          	vmovdqa %ymm7,%ymm5
     d26:	c5 65 66 c1          	vpcmpgtd %ymm1,%ymm3,%ymm8
     d2a:	c5 75 fe f3          	vpaddd %ymm3,%ymm1,%ymm14
     d2e:	c4 e2 35 90 3c a8    	vpgatherdd %ymm9,(%rax,%ymm5,4),%ymm7
     d34:	c4 e2 75 3d eb       	vpmaxsd %ymm3,%ymm1,%ymm5
     d39:	c5 5d 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm9
     d3d:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     d44:	00 00 
     d46:	c4 c1 45 72 d3 1f    	vpsrld $0x1f,%ymm11,%ymm7
     d4c:	c4 e2 55 3d ec       	vpmaxsd %ymm4,%ymm5,%ymm5
     d51:	c4 43 4d 4c c4 80    	vpblendvb %ymm8,%ymm12,%ymm6,%ymm8
     d57:	c5 f5 66 cb          	vpcmpgtd %ymm3,%ymm1,%ymm1
     d5b:	c4 63 3d 4c c7 90    	vpblendvb %ymm9,%ymm7,%ymm8,%ymm8
     d61:	c4 62 2d 39 cc       	vpminsd %ymm4,%ymm10,%ymm9
     d66:	c4 41 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm13
     d6b:	c5 2d 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm10
     d6f:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     d74:	c4 41 5d fa ed       	vpsubd %ymm13,%ymm4,%ymm13
     d79:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     d80:	00 00 
     d82:	c4 41 15 fe f6       	vpaddd %ymm14,%ymm13,%ymm14
     d87:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
     d8c:	c4 62 15 90 04 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm8
     d92:	c4 c3 4d 4c c4 10    	vpblendvb %ymm1,%ymm12,%ymm6,%ymm0
     d98:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
     d9e:	c4 e3 7d 4c c7 a0    	vpblendvb %ymm10,%ymm7,%ymm0,%ymm0
     da4:	c5 dd fa c0          	vpsubd %ymm0,%ymm4,%ymm0
     da8:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     dac:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
     db2:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
     db9:	00 00 
     dbb:	c5 7d 6f 3d 20 00 00 	vmovdqa 0x20(%rip),%ymm15        # de3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x673>
     dc2:	00 
     dc3:	c5 85 db b4 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm6
     dca:	00 00 
     dcc:	c5 85 db 84 24 a0 00 	vpand  0xa0(%rsp),%ymm15,%ymm0
     dd3:	00 00 
     dd5:	c4 41 3d db d7       	vpand  %ymm15,%ymm8,%ymm10
     dda:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
     ddf:	c5 dd 72 f6 10       	vpslld $0x10,%ymm6,%ymm4
     de4:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     de8:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     dec:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     df1:	c4 e2 4d 40 f5       	vpmulld %ymm5,%ymm6,%ymm6
     df6:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
     dfb:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     e00:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
     e05:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     e09:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     e0d:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     e14:	00 00 
     e16:	c5 7e 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm10
     e1d:	00 00 
     e1f:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     e23:	c4 c1 4d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm6
     e29:	48 8b 85 90 00 00 00 	mov    0x90(%rbp),%rax
     e30:	8b 8d cc 00 00 00    	mov    0xcc(%rbp),%ecx
     e36:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
     e3b:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
     e40:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     e45:	8b 95 c8 00 00 00    	mov    0xc8(%rbp),%edx
     e4b:	c5 fd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm0
     e50:	c4 c1 5d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm4
     e56:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     e5b:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     e60:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     e65:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
     e6a:	c5 ad 72 f0 10       	vpslld $0x10,%ymm0,%ymm10
     e6f:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     e73:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
     e77:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
     e7b:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     e80:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     e85:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     e8c:	00 00 
     e8e:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     e93:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
     e98:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     e9d:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
     ea2:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     ea6:	c5 7e 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm10
     ead:	00 00 
     eaf:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     eb3:	c5 e5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm3
     eb8:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
     ebd:	c4 c1 4d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm6
     ec3:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     ec8:	c4 c1 7d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm0
     ece:	c5 bd 72 f3 10       	vpslld $0x10,%ymm3,%ymm8
     ed3:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     ed8:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     edd:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
     ee1:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
     ee6:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     eea:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     eee:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
     ef3:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     ef8:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
     efd:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     f01:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
     f06:	c4 41 7d 6f f3       	vmovdqa %ymm11,%ymm14
     f0b:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
     f10:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     f14:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     f18:	c4 a2 4d 90 0c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm1
     f1e:	48 8b 85 98 00 00 00 	mov    0x98(%rbp),%rax
     f25:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     f29:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f2e:	c5 d5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm5
     f33:	c5 79 6e e1          	vmovd  %ecx,%xmm12
     f37:	c4 e2 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm3
     f3d:	48 8b 85 a0 00 00 00 	mov    0xa0(%rbp),%rax
     f44:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     f48:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     f4d:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
     f51:	c4 e2 4d 90 24 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm4
     f57:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     f5c:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     f60:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
     f67:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     f6c:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     f71:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     f75:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
     f7a:	c5 bd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm8
     f7f:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
     f83:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
     f87:	c4 62 75 39 d3       	vpminsd %ymm3,%ymm1,%ymm10
     f8c:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     f90:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     f95:	c4 e2 35 90 2c 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm5
     f9b:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     fa2:	00 00 
     fa4:	c5 f9 6e ea          	vmovd  %edx,%xmm5
     fa8:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     fad:	c5 55 fe c8          	vpaddd %ymm0,%ymm5,%ymm9
     fb1:	c4 e2 75 3d eb       	vpmaxsd %ymm3,%ymm1,%ymm5
     fb6:	c5 7e 7f 8c 24 c0 00 	vmovdqu %ymm9,0xc0(%rsp)
     fbd:	00 00 
     fbf:	c4 41 7d 6f c1       	vmovdqa %ymm9,%ymm8
     fc4:	c4 22 0d 90 0c 80    	vpgatherdd %ymm14,(%rax,%ymm8,4),%ymm9
     fca:	c5 65 66 c1          	vpcmpgtd %ymm1,%ymm3,%ymm8
     fce:	c5 75 fe f3          	vpaddd %ymm3,%ymm1,%ymm14
     fd2:	c5 7e 7f 8c 24 a0 00 	vmovdqu %ymm9,0xa0(%rsp)
     fd9:	00 00 
     fdb:	c5 5d 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm9
     fdf:	c5 f5 66 cb          	vpcmpgtd %ymm3,%ymm1,%ymm1
     fe3:	c4 e2 55 3d ec       	vpmaxsd %ymm4,%ymm5,%ymm5
     fe8:	c4 43 4d 4c c4 80    	vpblendvb %ymm8,%ymm12,%ymm6,%ymm8
     fee:	c4 63 3d 4c c7 90    	vpblendvb %ymm9,%ymm7,%ymm8,%ymm8
     ff4:	c4 62 2d 39 cc       	vpminsd %ymm4,%ymm10,%ymm9
     ff9:	c4 41 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm13
     ffe:	c5 2d 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm10
    1002:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    1007:	c4 41 5d fa ed       	vpsubd %ymm13,%ymm4,%ymm13
    100c:	c4 41 15 fe f6       	vpaddd %ymm14,%ymm13,%ymm14
    1011:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    1016:	c4 62 15 90 04 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm8
    101c:	c4 c3 4d 4c c4 10    	vpblendvb %ymm1,%ymm12,%ymm6,%ymm0
    1022:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    1029:	00 00 
    102b:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    1031:	c4 e3 7d 4c c7 a0    	vpblendvb %ymm10,%ymm7,%ymm0,%ymm0
    1037:	c4 41 3d db d7       	vpand  %ymm15,%ymm8,%ymm10
    103c:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
    1040:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1044:	c4 e2 4d 90 0c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm1
    104a:	c5 85 db b4 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm6
    1051:	00 00 
    1053:	c5 85 db 84 24 a0 00 	vpand  0xa0(%rsp),%ymm15,%ymm0
    105a:	00 00 
    105c:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    1061:	c5 dd 72 f6 10       	vpslld $0x10,%ymm6,%ymm4
    1066:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    106a:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    106e:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    1073:	c4 e2 4d 40 f5       	vpmulld %ymm5,%ymm6,%ymm6
    1078:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
    107d:	c5 7e 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm10
    1084:	00 00 
    1086:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    108b:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    1090:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1094:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    1098:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    109f:	00 00 
    10a1:	c4 c1 4d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm6
    10a7:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    10ab:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    10b0:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    10b5:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    10ba:	c5 fd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm0
    10bf:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    10c4:	c4 c1 5d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm4
    10ca:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    10cf:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    10d4:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    10d9:	c5 ad 72 f0 10       	vpslld $0x10,%ymm0,%ymm10
    10de:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
    10e2:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    10e6:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    10ea:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    10ef:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    10f4:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    10f9:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    10fe:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1103:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    1108:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    110c:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    1113:	00 00 
    1115:	c5 7e 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm10
    111c:	00 00 
    111e:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1122:	48 8b 85 d8 00 00 00 	mov    0xd8(%rbp),%rax
    1129:	8b 8d 14 01 00 00    	mov    0x114(%rbp),%ecx
    112f:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    1134:	c5 e5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm3
    1139:	8b 95 10 01 00 00    	mov    0x110(%rbp),%edx
    113f:	c4 c1 5d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm4
    1145:	c4 c1 7d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm0
    114b:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1150:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1155:	c5 bd 72 f3 10       	vpslld $0x10,%ymm3,%ymm8
    115a:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    115f:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1163:	c5 dd fa db          	vpsubd %ymm3,%ymm4,%ymm3
    1167:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    116c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1171:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    1175:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    117a:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    117e:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    1183:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    1187:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    118b:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    1190:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1195:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1199:	c4 a2 5d 90 1c a0    	vpgatherdd %ymm4,(%rax,%ymm12,4),%ymm3
    119f:	48 8b 85 e0 00 00 00 	mov    0xe0(%rbp),%rax
    11a6:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    11ab:	c4 e2 55 90 24 b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm4
    11b1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    11b5:	48 8b 85 e8 00 00 00 	mov    0xe8(%rbp),%rax
    11bc:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    11c0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    11c5:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    11ca:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
    11ce:	c4 e2 4d 90 2c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm5
    11d4:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    11d9:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    11dd:	48 8b 85 08 01 00 00 	mov    0x108(%rbp),%rax
    11e4:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    11e9:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    11ee:	c5 e5 db da          	vpand  %ymm2,%ymm3,%ymm3
    11f2:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    11f7:	c5 bd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm8
    11fc:	c5 d5 db d2          	vpand  %ymm2,%ymm5,%ymm2
    1200:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1204:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    1208:	c4 62 65 39 d4       	vpminsd %ymm4,%ymm3,%ymm10
    120d:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1211:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1216:	c5 5d 66 c3          	vpcmpgtd %ymm3,%ymm4,%ymm8
    121a:	c4 e2 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm0
    1220:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    1224:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    1229:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    122d:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    1234:	00 00 
    1236:	c4 62 35 90 24 a8    	vpgatherdd %ymm9,(%rax,%ymm5,4),%ymm12
    123c:	c4 e2 65 3d ec       	vpmaxsd %ymm4,%ymm3,%ymm5
    1241:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    1248:	00 00 
    124a:	c5 65 fe f4          	vpaddd %ymm4,%ymm3,%ymm14
    124e:	c5 6d 66 cd          	vpcmpgtd %ymm5,%ymm2,%ymm9
    1252:	c4 63 4d 4c 84 24 a0 	vpblendvb %ymm8,0xa0(%rsp),%ymm6,%ymm8
    1259:	00 00 00 80 
    125d:	c4 e2 55 3d ea       	vpmaxsd %ymm2,%ymm5,%ymm5
    1262:	c5 e5 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm3
    1266:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    126d:	00 00 
    126f:	c4 63 3d 4c c7 90    	vpblendvb %ymm9,%ymm7,%ymm8,%ymm8
    1275:	c4 62 2d 39 ca       	vpminsd %ymm2,%ymm10,%ymm9
    127a:	c4 41 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm13
    127f:	c5 2d 66 d2          	vpcmpgtd %ymm2,%ymm10,%ymm10
    1283:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1288:	c4 41 6d fa ed       	vpsubd %ymm13,%ymm2,%ymm13
    128d:	c4 c1 7d db d7       	vpand  %ymm15,%ymm0,%ymm2
    1292:	c4 41 15 fe f6       	vpaddd %ymm14,%ymm13,%ymm14
    1297:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    129c:	c4 62 15 90 04 88    	vpgatherdd %ymm13,(%rax,%ymm1,4),%ymm8
    12a2:	c4 e3 4d 4c 8c 24 a0 	vpblendvb %ymm3,0xa0(%rsp),%ymm6,%ymm1
    12a9:	00 00 00 30 
    12ad:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    12b3:	c4 e3 75 4c cf a0    	vpblendvb %ymm10,%ymm7,%ymm1,%ymm1
    12b9:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    12be:	c4 c1 3d db ff       	vpand  %ymm15,%ymm8,%ymm7
    12c3:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    12c7:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    12cb:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    12cf:	c4 e2 5d 90 1c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm3
    12d5:	c4 c1 1d db e7       	vpand  %ymm15,%ymm12,%ymm4
    12da:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    12df:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    12e4:	c4 c1 2d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm10
    12ea:	c4 c1 65 db cf       	vpand  %ymm15,%ymm3,%ymm1
    12ef:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    12f3:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    12f7:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    12fc:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    1301:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    1306:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    130a:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    130e:	c5 dd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm4
    1313:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1317:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    131c:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1321:	c4 c1 75 72 d4 08    	vpsrld $0x8,%ymm12,%ymm1
    1327:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    132c:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1331:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    1336:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    133b:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    133f:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    1343:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1348:	c4 e2 4d 40 f5       	vpmulld %ymm5,%ymm6,%ymm6
    134d:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    1352:	c4 c2 5d 40 e6       	vpmulld %ymm14,%ymm4,%ymm4
    1357:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    135c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1361:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1366:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    136b:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    136f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1373:	c4 c1 45 72 d0 10    	vpsrld $0x10,%ymm8,%ymm7
    1379:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    137d:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1382:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1387:	c4 c1 7d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm0
    138d:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    1392:	c5 c5 fa e4          	vpsubd %ymm4,%ymm7,%ymm4
    1396:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    139b:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
    13a0:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    13a5:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    13a9:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    13ad:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    13b2:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    13b7:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    13bc:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    13c1:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    13c5:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    13c9:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    13cd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    13d2:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    13d7:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    13db:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    13df:	c4 e2 7d 00 44 24 60 	vpshufb 0x60(%rsp),%ymm0,%ymm0
    13e6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    13ea:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    13f0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    13f5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    13fa:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    13fe:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    1405:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
    140c:	4c 39 d3             	cmp    %r10,%rbx
    140f:	0f 85 e2 f7 ff ff    	jne    bf7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x487>
    1415:	0f 1f 00             	nopl   (%rax)
    1418:	c5 f8 77             	vzeroupper
    141b:	c5 f8 28 b4 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm6
    1422:	00 00 
    1424:	c5 f8 28 bc 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm7
    142b:	00 00 
    142d:	c5 78 28 84 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm8
    1434:	00 00 
    1436:	c5 78 28 8c 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm9
    143d:	00 00 
    143f:	c5 78 28 94 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm10
    1446:	00 00 
    1448:	c5 78 28 9c 24 00 02 	vmovaps 0x200(%rsp),%xmm11
    144f:	00 00 
    1451:	c5 78 28 a4 24 10 02 	vmovaps 0x210(%rsp),%xmm12
    1458:	00 00 
    145a:	c5 78 28 ac 24 20 02 	vmovaps 0x220(%rsp),%xmm13
    1461:	00 00 
    1463:	c5 78 28 b4 24 30 02 	vmovaps 0x230(%rsp),%xmm14
    146a:	00 00 
    146c:	c5 78 28 bc 24 40 02 	vmovaps 0x240(%rsp),%xmm15
    1473:	00 00 
    1475:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
    147c:	5b                   	pop    %rbx
    147d:	5e                   	pop    %rsi
    147e:	5f                   	pop    %rdi
    147f:	5d                   	pop    %rbp
    1480:	41 5c                	pop    %r12
    1482:	41 5d                	pop    %r13
    1484:	c3                   	ret
    1485:	90                   	nop
    1486:	90                   	nop
    1487:	90                   	nop
    1488:	90                   	nop
    1489:	90                   	nop
    148a:	90                   	nop
    148b:	90                   	nop
    148c:	90                   	nop
    148d:	90                   	nop
    148e:	90                   	nop
    148f:	90                   	nop
