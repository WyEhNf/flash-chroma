"""57单次顺序执行：构建、静态、完整精度通过后才做一次PMU；失败立即停止。"""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
commands=[
 ['scripts/build_skylake_runtime.py','--plan','experiments/skylake-qwordpack-v1.json','--output','artifacts/skylake-qwordpack-linux-build-v1'],
 ['scripts/inspect_skylake_qwordpack.py','--plan','experiments/skylake-qwordpack-v1.json','--build','artifacts/skylake-qwordpack-linux-build-v1','--output','artifacts/skylake-qwordpack-linux-static-v1'],
 ['scripts/verify_skylake_qwordpack_linux.py','--plan','experiments/skylake-qwordpack-v1.json','--build','artifacts/skylake-qwordpack-linux-build-v1','--single-oracle-stream','artifacts/skylake-domain-isolated-full-v1/first-stage.rgb','--output','artifacts/skylake-qwordpack-linux-full-v1','--affinity-cpus','0,2,4,6'],
 ['artifacts/prepare_qwordpack_pmu.py'],
 ['scripts/profile_skylake_qwordpack_pmu.py','--policy','experiments/skylake-qwordpack-pmu-v1.json','--output','artifacts/skylake-qwordpack-pmu-v1']]
for command in commands:
    print('开始',command[0],flush=True)
    subprocess.run([sys.executable,*command],cwd=ROOT,check=True)
