"""冻结56：每64像素仅四个提前128像素的ID表T0提示，保留40的其他路径。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-sparsehint-runtime';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_sparsehint').replace('avx2_chain_batchspan','avx2_chain_sparsehint')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 56;')
    if p.name=='channel_avx2.cpp':
        marker='inline __attribute__((always_inline)) void run('
        hint='''template<size_t Offset>
inline __attribute__((always_inline)) void hint_one(const uint32_t* table,const uint8_t* source) {
  uint32_t code;std::memcpy(&code,source+3*Offset,4);
  _mm_prefetch(reinterpret_cast<const char*>(reinterpret_cast<const uint8_t*>(table)+(code&0xffffffu)),_MM_HINT_T0);
}
'''
        assert s.count(marker)==1;s=s.replace(marker,hint+marker)
        marker='    // 全部64像素先读后写，主体输出恰好192字节即三条完整缓存行。'
        sparse='''    // 只采样远方四个颜色，减少39逐像素提示的额外工作；最后4字节读取仍在本块。
    if(p+178<=pixels) {
      const uint8_t* future=source+3*(p+128);
      hint_one<0>(table,future);hint_one<16>(table,future);
      hint_one<32>(table,future);hint_one<48>(table,future);
    }
'''
        assert s.count(marker)==1;s=s.replace(marker,sparse+marker)
    write(out/p.name,s)
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='56研究低开销稀疏查表预取；精度不降，通用AVX2',candidate='从40仅增加每64像素四个ID表T0提示，前瞻128像素、间隔16；保留原线性地址、GPR加载、NTA、NT64与65536工作块',base_commit='6753b12ff84f8b6d6e01f7c632847db9163ff0da',revisions={'reference':23,'candidate':56},cmake_project='experiments/skylake-sparsehint-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_sparsehint'])
plan['sparsehint_policy']={'format':9,'table_bytes':2**24,'lookahead_pixels':128,'sample_offsets':[0,16,32,48],'hints_per_main_64_pixels':4,'load_bytes':4,'required_pixels':178,'hint':'_MM_HINT_T0','source_NTA_unchanged':True,'choice':'39全量提示成本过高，54/55分别减少miss/指令而单线程未改善；固定四点低开销前瞻，不扫描距离或密度','bounds':'最后读取源字节3*(p+176)..3*(p+176)+3；p+178<=pixels保证本线程块内，提示表地址mask24位','hypothesis':'少量远方请求可提前触发部分表缓存行，是否抵消额外指令需要实测','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-sparsehint-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
verify=(ROOT/'scripts/verify_skylake_vectorinput_linux.py').read_text(encoding='utf-8').replace('线性布局向量输入50','稀疏表预取56')
verify_path=ROOT/'scripts/verify_skylake_sparsehint_linux.py';write(verify_path,verify)
static=(ROOT/'scripts/inspect_skylake_vectorinput.py').read_text(encoding='utf-8').replace('50输入向量化','56稀疏表预取').replace('skylake_vectorinput','skylake_sparsehint')
static=static.replace("    assert any(i.startswith('vpextr') for i in mn)","    assert 'prefetcht0' in mn and 'prefetchnta' in mn")
static=static.replace("'vector_lane_extractions':sum(i.startswith('vpextr') for i in mn),","'table_prefetch_instructions':sum(i=='prefetcht0' for i in mn),'source_prefetch_instructions':sum(i=='prefetchnta' for i in mn),")
write(ROOT/'scripts/inspect_skylake_sparsehint.py',static)
pmu=(ROOT/'scripts/profile_skylake_palettegather_pmu.py').read_text(encoding='utf-8').replace('40/52','40/56').replace('palettegather52','sparsehint56')
write(ROOT/'scripts/profile_skylake_sparsehint_pmu.py',pmu)
validation={'purpose':'56独立16M表、24组全域、有限/别名/保护页及全对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [verify_path,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-sparsehint-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
prepare=(ROOT/'artifacts/prepare_palettegather_pmu.py').read_text(encoding='utf-8').replace('52','56').replace('palettegather','sparsehint').replace('仅改变输入加载','仅增加四点稀疏表预取')
write(ROOT/'artifacts/prepare_sparsehint_pmu.py',prepare)
runner=(ROOT/'artifacts/run_directtile_once.py').read_text(encoding='utf-8').replace('53','56').replace('directtile','sparsehint')
write(ROOT/'artifacts/run_sparsehint_once.py',runner)
for p in [verify_path,ROOT/'scripts/inspect_skylake_sparsehint.py',ROOT/'scripts/profile_skylake_sparsehint_pmu.py',ROOT/'artifacts/prepare_sparsehint_pmu.py',ROOT/'artifacts/run_sparsehint_once.py']:compile(p.read_text(encoding='utf-8'),str(p),'exec')
assert 3*176+4<=3*178 and 128>=64
print('56实现、边界和单次5%筛查冻结；未构建或执行像素')
