"""冻结57：按最终输出位置选择pack排列，只减少NT主体中间搬运。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-qwordpack-runtime'
out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
indices=[[0,1,2,4,5,6,3,7],[2,4,5,6,3,7,0,1],[5,6,3,7,0,1,2,4],[3,7,0,1,2,4,5,6]]
# 独立字节标签推导：先模拟每128bit删去alpha，再按四种dword排列拼接。
packed=[]
for group,idx in enumerate(indices):
    raw=list(range(group*32,(group+1)*32))
    shuffled=[]
    for lane in (0,16):shuffled += [raw[lane+i] for i in (0,1,2,4,5,6,8,9,10,12,13,14)]+[None]*4
    packed.append(sum([shuffled[4*i:4*i+4] for i in idx],[]))
A,B,C,D=packed
combined=A[:24]+B[24:]+B[:16]+C[16:]+C[:8]+D[8:]
assert combined==[i for i in range(128) if i%4!=3]
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_qwordpack').replace('avx2_chain_batchspan','avx2_chain_qwordpack')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 57;')
    if p.name=='channel_avx2.cpp':
        start=s.index('inline __attribute__((always_inline)) __m256i pack(')
        end=s.index('inline __attribute__((always_inline)) void output_four(',start)
        original=s[start:end]
        extra='// 按最终输出位置预排qword，普通尾部继续使用原pack。\n'
        for i in range(4):
            extra+=original.replace('pack(',f'pack_stream_{i}(').replace('0,1,2,4,5,6,3,7',','.join(map(str,indices[i])))
        s=s[:end]+extra+s[end:]
        start=s.index('  const __m128i a=',s.index('void output_four_stream('))
        end=s.index('  _mm256_stream_si256',start)
        s=s[:start]+'''  const __m256i s0=_mm256_blend_epi32(v0,v1,0xc0);
  const __m256i s1=_mm256_permute2x128_si256(v1,v2,0x30);
  const __m256i s2=_mm256_blend_epi32(v3,v2,0x03);
'''+s[end:]
        for i in range(8):
            target=f'r{i}=pack(read_wide';assert s.count(target)==1
            s=s.replace(target,f'r{i}=pack_stream_{i%4}(read_wide')
    write(out/p.name,s)
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='57研究按输出位置预排，保持全域输出与通用AVX2',candidate='从40仅改变NT主体四组pack排列及三条合并；GPR读取、ID表、NTA、NT64、SFENCE、65536工作块及普通尾部不变',base_commit='6753b12ff84f8b6d6e01f7c632847db9163ff0da',revisions={'reference':23,'candidate':57},cmake_project='experiments/skylake-qwordpack-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_qwordpack'])
plan['qwordpack_policy']={'format':9,'table_bytes':2**24,'indices':indices,'combine':['blend_epi32(A,B,0xc0)','permute2x128(B,C,0x30)','blend_epi32(D,C,0x03)'],'source':'参考libyuv的零尾qword组合思路；本版四种预排及三指令组合独立推导','source_url':'https://chromium.googlesource.com/libyuv/libyuv/+/refs/heads/main/source/row_gcc.cc','symbolic_byte_check':True,'all_64_reads_before_stores':True,'bounds_unchanged':True,'hypothesis':'移除XMM提取与复制；额外排列常量可能增加寄存器压力，性能仍需计数筛查','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-qwordpack-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
verify=(ROOT/'scripts/verify_skylake_vectorinput_linux.py').read_text(encoding='utf-8').replace('线性布局向量输入50','输出位置预排57')
vp=ROOT/'scripts/verify_skylake_qwordpack_linux.py';write(vp,verify)
static=(ROOT/'scripts/inspect_skylake_sparsehint.py').read_text(encoding='utf-8').replace('56稀疏表预取','57输出位置预排').replace('skylake_sparsehint','skylake_qwordpack')
static=static.replace("assert 'prefetcht0' in mn and 'prefetchnta' in mn","assert 'vpblendd' in mn and 'vperm2i128' in mn and 'prefetchnta' in mn")
write(ROOT/'scripts/inspect_skylake_qwordpack.py',static)
pmu=(ROOT/'scripts/profile_skylake_palettegather_pmu.py').read_text(encoding='utf-8').replace('40/52','40/57').replace('palettegather52','qwordpack57')
write(ROOT/'scripts/profile_skylake_qwordpack_pmu.py',pmu)
validation={'purpose':'57独立16M表、24组全域、有限/别名/保护页及全对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [vp,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-qwordpack-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
prepare=(ROOT/'artifacts/prepare_palettegather_pmu.py').read_text(encoding='utf-8').replace('52','57').replace('palettegather','qwordpack').replace('仅改变输入加载','仅改变输出预排')
write(ROOT/'artifacts/prepare_qwordpack_pmu.py',prepare)
runner=(ROOT/'artifacts/run_directtile_once.py').read_text(encoding='utf-8').replace('53','57').replace('directtile','qwordpack')
write(ROOT/'artifacts/run_qwordpack_once.py',runner)
for p in [vp,ROOT/'scripts/inspect_skylake_qwordpack.py',ROOT/'scripts/profile_skylake_qwordpack_pmu.py',ROOT/'artifacts/prepare_qwordpack_pmu.py',ROOT/'artifacts/run_qwordpack_once.py']:compile(p.read_text(encoding='utf-8'),str(p),'exec')
print('57字节符号验证通过；源码与5%筛查冻结；尚未构建或执行像素')
