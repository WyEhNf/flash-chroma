"""冻结58：57输出预排加两个独立XMM输入展开，准确读取每8像素24字节。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-qwordpack-runtime';out=ROOT/'experiments/skylake-splitpack-runtime';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
replacement='''// 精确读取24字节；前四索引无需等待尾部合并，两个XMM分别展开。
inline __attribute__((always_inline)) __m256i read_wide(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m128i hi=_mm_alignr_epi8(last,lo,12);
  const __m128i mask=_mm_setr_epi8(0,1,2,-1,3,4,5,-1,6,7,8,-1,9,10,11,-1);
  const __m128i low=_mm_shuffle_epi8(lo,mask),high=_mm_shuffle_epi8(hi,mask);
  const auto value=[table,palette](uint32_t i) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[i]]);};
  return _mm256_setr_epi32(value(_mm_extract_epi32(low,0)),value(_mm_extract_epi32(low,1)),
      value(_mm_extract_epi32(low,2)),value(_mm_extract_epi32(low,3)),value(_mm_extract_epi32(high,0)),
      value(_mm_extract_epi32(high,1)),value(_mm_extract_epi32(high,2)),value(_mm_extract_epi32(high,3)));
}
'''
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_qwordpack','skylake_splitpack').replace('avx2_chain_qwordpack','avx2_chain_splitpack')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 57;','jshc_cc_revision(void) {return 58;')
    if p.name=='channel_avx2.cpp':
        start=s.index('// 仅宽循环调用；');end=s.index('inline __attribute__((always_inline)) void output(',start)
        s=s[:start]+replacement+s[end:]
    write(out/p.name,s)
plan=json.loads((ROOT/'experiments/skylake-qwordpack-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='58研究独立XMM输入展开与57输出预排的互补，精度不降，通用AVX2',candidate='保留57输出，仅将宽循环输入换成精确16+8字节加载、两路XMM shuffle和GPR查表；普通8像素尾部仍为40原实现',revisions={'reference':23,'candidate':58},cmake_project='experiments/skylake-splitpack-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_splitpack'])
plan['splitpack_policy']=plan.pop('qwordpack_policy')
plan['splitpack_policy'].update(input_load_bytes=[16,8],input_offsets=[0,16],input_lane='先PALIGNR12，再各自128bit PSHUFB及4个u32提取；不先合并YMM再拆开',hypothesis='50的输入合并/拆分可避免；前四索引减少依赖，57已减少输出侧shuffle，检验组合是否有互补；不乘算历史收益',bounds='每8像素读取恰24字节，不新增过读；保留原64全部先读后写和72像素主循环界',comparison='同场40作为单次计数筛查，不能用旧57或50绝对数值计算组合收益')
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-qwordpack-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-splitpack-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
vp=ROOT/'scripts/verify_skylake_splitpack_linux.py';write(vp,(ROOT/'scripts/verify_skylake_qwordpack_linux.py').read_text(encoding='utf-8').replace('输出位置预排57','独立XMM输入与输出预排58'))
static=(ROOT/'scripts/inspect_skylake_qwordpack_v2.py').read_text(encoding='utf-8').replace('57输出位置预排','58独立XMM输入与输出预排').replace('skylake_qwordpack','skylake_splitpack')
write(ROOT/'scripts/inspect_skylake_splitpack.py',static)
write(ROOT/'scripts/profile_skylake_splitpack_pmu.py',(ROOT/'scripts/profile_skylake_qwordpack_pmu.py').read_text(encoding='utf-8').replace('40/57','40/58').replace('qwordpack57','splitpack58'))
validation={'purpose':'58独立16M表、24组全域、有限/别名/保护页及全对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [vp,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-splitpack-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
write(ROOT/'artifacts/prepare_splitpack_pmu.py',(ROOT/'artifacts/prepare_qwordpack_pmu.py').read_text(encoding='utf-8').replace('57','58').replace('qwordpack','splitpack').replace('仅改变输出预排','独立XMM输入与输出预排'))
write(ROOT/'artifacts/run_splitpack_once.py',(ROOT/'artifacts/run_qwordpack_once.py').read_text(encoding='utf-8').replace('57','58').replace('qwordpack','splitpack'))
print('58单一候选冻结，保留5%单次筛查门槛；尚未执行像素或计数')
