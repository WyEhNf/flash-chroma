
artifacts\skylake-scalar-gather-build-v1\CMakeFiles\jshc_skylake_scalar_gather.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>:
       0:	41 54                	push   %r12
       2:	55                   	push   %rbp
       3:	57                   	push   %rdi
       4:	56                   	push   %rsi
       5:	53                   	push   %rbx
       6:	48 81 ec c0 00 00 00 	sub    $0xc0,%rsp
       d:	c5 f8 29 74 24 20    	vmovaps %xmm6,0x20(%rsp)
      13:	c5 f8 29 7c 24 30    	vmovaps %xmm7,0x30(%rsp)
      19:	c5 78 29 44 24 40    	vmovaps %xmm8,0x40(%rsp)
      1f:	c5 78 29 4c 24 50    	vmovaps %xmm9,0x50(%rsp)
      25:	c5 78 29 54 24 60    	vmovaps %xmm10,0x60(%rsp)
      2b:	c5 78 29 5c 24 70    	vmovaps %xmm11,0x70(%rsp)
      31:	c5 78 29 a4 24 80 00 	vmovaps %xmm12,0x80(%rsp)
      38:	00 00 
      3a:	c5 78 29 ac 24 90 00 	vmovaps %xmm13,0x90(%rsp)
      41:	00 00 
      43:	c5 78 29 b4 24 a0 00 	vmovaps %xmm14,0xa0(%rsp)
      4a:	00 00 
      4c:	c5 78 29 bc 24 b0 00 	vmovaps %xmm15,0xb0(%rsp)
      53:	00 00 
      55:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
      59:	48 8b 01             	mov    (%rcx),%rax
      5c:	8b 72 10             	mov    0x10(%rdx),%esi
      5f:	8b 6a 18             	mov    0x18(%rdx),%ebp
      62:	8b 5a 14             	mov    0x14(%rdx),%ebx
      65:	8b 7a 1c             	mov    0x1c(%rdx),%edi
      68:	c5 f9 6e 04 b0       	vmovd  (%rax,%rsi,4),%xmm0
      6d:	c5 f9 6e 0c a8       	vmovd  (%rax,%rbp,4),%xmm1
      72:	44 8b 0a             	mov    (%rdx),%r9d
      75:	44 8b 5a 08          	mov    0x8(%rdx),%r11d
      79:	c4 e3 79 22 04 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm0,%xmm0
      80:	c4 e3 71 22 0c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm1,%xmm1
      87:	44 8b 42 04          	mov    0x4(%rdx),%r8d
      8b:	44 8b 52 0c          	mov    0xc(%rdx),%r10d
      8f:	c4 a1 79 6e 24 88    	vmovd  (%rax,%r9,4),%xmm4
      95:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
      99:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
      9f:	8b 72 30             	mov    0x30(%rdx),%esi
      a2:	c4 a3 59 22 24 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm4,%xmm4
      a9:	8b 6a 38             	mov    0x38(%rdx),%ebp
      ac:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
      b3:	48 8b 41 08          	mov    0x8(%rcx),%rax
      b7:	8b 5a 34             	mov    0x34(%rdx),%ebx
      ba:	8b 7a 3c             	mov    0x3c(%rdx),%edi
      bd:	c5 d9 6c e1          	vpunpcklqdq %xmm1,%xmm4,%xmm4
      c1:	c5 f9 6e 0c a8       	vmovd  (%rax,%rbp,4),%xmm1
      c6:	44 8b 5a 28          	mov    0x28(%rdx),%r11d
      ca:	c4 e3 5d 38 e0 01    	vinserti128 $0x1,%xmm0,%ymm4,%ymm4
      d0:	c5 f9 6e 04 b0       	vmovd  (%rax,%rsi,4),%xmm0
      d5:	44 8b 52 2c          	mov    0x2c(%rdx),%r10d
      d9:	c4 e3 71 22 0c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm1,%xmm1
      e0:	44 8b 4a 20          	mov    0x20(%rdx),%r9d
      e4:	c4 e3 79 22 04 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm0,%xmm0
      eb:	44 8b 42 24          	mov    0x24(%rdx),%r8d
      ef:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
      f3:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
      f9:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
     100:	c4 a1 79 6e 34 88    	vmovd  (%rax,%r9,4),%xmm6
     106:	8b 72 50             	mov    0x50(%rdx),%esi
     109:	8b 6a 58             	mov    0x58(%rdx),%ebp
     10c:	c4 a3 49 22 34 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm6,%xmm6
     113:	48 8b 41 10          	mov    0x10(%rcx),%rax
     117:	8b 5a 54             	mov    0x54(%rdx),%ebx
     11a:	8b 7a 5c             	mov    0x5c(%rdx),%edi
     11d:	c5 c9 6c f1          	vpunpcklqdq %xmm1,%xmm6,%xmm6
     121:	c5 f9 6e 0c a8       	vmovd  (%rax,%rbp,4),%xmm1
     126:	44 8b 4a 40          	mov    0x40(%rdx),%r9d
     12a:	c4 e3 4d 38 f0 01    	vinserti128 $0x1,%xmm0,%ymm6,%ymm6
     130:	c5 f9 6e 04 b0       	vmovd  (%rax,%rsi,4),%xmm0
     135:	44 8b 5a 48          	mov    0x48(%rdx),%r11d
     139:	c4 e3 71 22 0c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm1,%xmm1
     140:	44 8b 42 44          	mov    0x44(%rdx),%r8d
     144:	c4 e3 79 22 04 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm0,%xmm0
     14b:	44 8b 52 4c          	mov    0x4c(%rdx),%r10d
     14f:	c4 a1 79 6e 3c 88    	vmovd  (%rax,%r9,4),%xmm7
     155:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     159:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
     15d:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
     163:	c4 a3 41 22 3c 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm7,%xmm7
     16a:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     16e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     173:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
     17a:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     17f:	48 8b 41 48          	mov    0x48(%rcx),%rax
     183:	c4 41 79 6e d0       	vmovd  %r8d,%xmm10
     188:	c5 c1 6c f9          	vpunpcklqdq %xmm1,%xmm7,%xmm7
     18c:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     191:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     196:	c4 e3 45 38 f8 01    	vinserti128 $0x1,%xmm0,%ymm7,%ymm7
     19c:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
     1a1:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     1a6:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     1ab:	c5 ed 72 d7 11       	vpsrld $0x11,%ymm7,%ymm2
     1b0:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     1b4:	c5 fd 72 d3 0f       	vpsrld $0xf,%ymm3,%ymm0
     1b9:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     1bd:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     1c1:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     1c5:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     1c9:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
     1cf:	c4 c1 79 7e ca       	vmovd  %xmm1,%r10d
     1d4:	c4 c3 79 16 c4 02    	vpextrd $0x2,%xmm0,%r12d
     1da:	c5 f9 7e c7          	vmovd  %xmm0,%edi
     1de:	c4 e3 79 16 c6 01    	vpextrd $0x1,%xmm0,%esi
     1e4:	c4 a1 79 6e 2c 90    	vmovd  (%rax,%r10,4),%xmm5
     1ea:	c4 a1 79 6e 14 a0    	vmovd  (%rax,%r12,4),%xmm2
     1f0:	c4 e3 79 16 c5 03    	vpextrd $0x3,%xmm0,%ebp
     1f6:	c5 f9 6e 04 b8       	vmovd  (%rax,%rdi,4),%xmm0
     1fb:	c4 e3 79 16 cb 02    	vpextrd $0x2,%xmm1,%ebx
     201:	c4 e3 79 16 c9 01    	vpextrd $0x1,%xmm1,%ecx
     207:	c4 c3 79 16 cb 03    	vpextrd $0x3,%xmm1,%r11d
     20d:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     212:	c4 e3 69 22 14 a8 01 	vpinsrd $0x1,(%rax,%rbp,4),%xmm2,%xmm2
     219:	c4 e3 79 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm0,%xmm0
     220:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     225:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     229:	c5 e5 72 d3 18       	vpsrld $0x18,%ymm3,%ymm3
     22e:	c4 e3 51 22 2c 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm5,%xmm5
     235:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     239:	c5 f9 6e 14 98       	vmovd  (%rax,%rbx,4),%xmm2
     23e:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
     243:	c4 a3 69 22 14 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm2,%xmm2
     24a:	c5 d1 6c ea          	vpunpcklqdq %xmm2,%xmm5,%xmm5
     24e:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
     252:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     257:	c4 e3 55 38 e8 01    	vinserti128 $0x1,%xmm0,%ymm5,%ymm5
     25d:	c5 f5 fe c2          	vpaddd %ymm2,%ymm1,%ymm0
     261:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     266:	c4 c1 79 7e c0       	vmovd  %xmm0,%r8d
     26b:	c4 e3 79 16 c1 01    	vpextrd $0x1,%xmm0,%ecx
     271:	c4 c3 79 16 c2 02    	vpextrd $0x2,%xmm0,%r10d
     277:	c4 c3 79 16 c1 03    	vpextrd $0x3,%xmm0,%r9d
     27d:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     283:	c4 e3 79 16 c7 02    	vpextrd $0x2,%xmm0,%edi
     289:	c5 f9 7e c3          	vmovd  %xmm0,%ebx
     28d:	c4 c3 79 16 c3 01    	vpextrd $0x1,%xmm0,%r11d
     293:	c4 e3 79 16 c6 03    	vpextrd $0x3,%xmm0,%esi
     299:	c5 f9 6e 04 b8       	vmovd  (%rax,%rdi,4),%xmm0
     29e:	c4 e3 79 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm0,%xmm0
     2a5:	c5 f9 6e 14 98       	vmovd  (%rax,%rbx,4),%xmm2
     2aa:	c4 21 79 6e 04 90    	vmovd  (%rax,%r10,4),%xmm8
     2b0:	c4 a3 69 22 14 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm2,%xmm2
     2b7:	c4 23 39 22 04 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm8,%xmm8
     2be:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     2c2:	c4 a1 79 6e 04 80    	vmovd  (%rax,%r8,4),%xmm0
     2c8:	c4 e3 79 22 04 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm0,%xmm0
     2cf:	c4 c1 79 6c c0       	vpunpcklqdq %xmm8,%xmm0,%xmm0
     2d4:	c4 62 5d 3d c6       	vpmaxsd %ymm6,%ymm4,%ymm8
     2d9:	c4 e3 7d 38 c2 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm0
     2df:	c5 cd 66 d4          	vpcmpgtd %ymm4,%ymm6,%ymm2
     2e3:	c4 41 45 66 c8       	vpcmpgtd %ymm8,%ymm7,%ymm9
     2e8:	c4 62 3d 3d c7       	vpmaxsd %ymm7,%ymm8,%ymm8
     2ed:	c4 41 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm15
     2f2:	c4 c3 2d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm10,%ymm2
     2f8:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm2,%ymm2        # 301 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x301>
     2ff:	ff ff 90 
     302:	c5 5d fe ce          	vpaddd %ymm6,%ymm4,%ymm9
     306:	c5 f5 fe d2          	vpaddd %ymm2,%ymm1,%ymm2
     30a:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     30e:	c5 35 fe cf          	vpaddd %ymm7,%ymm9,%ymm9
     312:	c4 c3 79 16 d0 01    	vpextrd $0x1,%xmm2,%r8d
     318:	c4 c3 79 16 d2 02    	vpextrd $0x2,%xmm2,%r10d
     31e:	c4 c3 79 16 d1 03    	vpextrd $0x3,%xmm2,%r9d
     324:	c5 f9 7e d1          	vmovd  %xmm2,%ecx
     328:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
     32e:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
     333:	c5 f9 7e d3          	vmovd  %xmm2,%ebx
     337:	c4 e3 79 16 d7 02    	vpextrd $0x2,%xmm2,%edi
     33d:	c4 c3 79 16 d3 01    	vpextrd $0x1,%xmm2,%r11d
     343:	8b 0c 88             	mov    (%rax,%rcx,4),%ecx
     346:	c5 79 6e 3c 98       	vmovd  (%rax,%rbx,4),%xmm15
     34b:	c4 e3 79 16 d6 03    	vpextrd $0x3,%xmm2,%esi
     351:	c5 f9 6e 14 b8       	vmovd  (%rax,%rdi,4),%xmm2
     356:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
     35c:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm10,%ymm10        # 365 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x365>
     363:	ff ff c0 
     366:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     36b:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     36f:	c4 e3 69 22 14 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm2,%xmm2
     376:	c4 23 01 22 3c 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm15,%xmm15
     37d:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
     382:	c5 f5 fe 0c 24       	vpaddd (%rsp),%ymm1,%ymm1
     387:	c4 23 09 22 34 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm14,%xmm14
     38e:	c5 55 db d3          	vpand  %ymm3,%ymm5,%ymm10
     392:	c5 01 6c fa          	vpunpcklqdq %xmm2,%xmm15,%xmm15
     396:	c4 a1 79 6e 14 90    	vmovd  (%rax,%r10,4),%xmm2
     39c:	c4 c1 45 72 f2 10    	vpslld $0x10,%ymm10,%ymm7
     3a2:	c5 15 db eb          	vpand  %ymm3,%ymm13,%ymm13
     3a6:	c4 c1 79 7e c8       	vmovd  %xmm1,%r8d
     3ab:	c4 e3 79 16 c9 01    	vpextrd $0x1,%xmm1,%ecx
     3b1:	c4 c3 79 16 ca 02    	vpextrd $0x2,%xmm1,%r10d
     3b7:	c4 a3 69 22 14 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm2,%xmm2
     3be:	c4 a1 79 6e 34 90    	vmovd  (%rax,%r10,4),%xmm6
     3c4:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     3c9:	c4 c3 79 16 c9 03    	vpextrd $0x3,%xmm1,%r9d
     3cf:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     3d5:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     3d9:	c5 f9 7e cb          	vmovd  %xmm1,%ebx
     3dd:	c4 e3 79 16 cf 02    	vpextrd $0x2,%xmm1,%edi
     3e3:	c4 c3 79 16 cb 01    	vpextrd $0x1,%xmm1,%r11d
     3e9:	c5 f9 6e 24 98       	vmovd  (%rax,%rbx,4),%xmm4
     3ee:	c4 e3 79 16 ce 03    	vpextrd $0x3,%xmm1,%esi
     3f4:	c5 f9 6e 0c b8       	vmovd  (%rax,%rdi,4),%xmm1
     3f9:	c5 89 6c d2          	vpunpcklqdq %xmm2,%xmm14,%xmm2
     3fd:	c4 a3 49 22 34 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm6,%xmm6
     404:	c4 c3 6d 38 d7 01    	vinserti128 $0x1,%xmm15,%ymm2,%ymm2
     40a:	c4 e3 71 22 0c b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm1,%xmm1
     411:	c4 a3 59 22 24 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm4,%xmm4
     418:	c5 d9 6c e1          	vpunpcklqdq %xmm1,%xmm4,%xmm4
     41c:	c4 a1 79 6e 0c 80    	vmovd  (%rax,%r8,4),%xmm1
     422:	c4 e3 71 22 0c 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm1,%xmm1
     429:	b8 00 80 00 00       	mov    $0x8000,%eax
     42e:	c5 f1 6c ce          	vpunpcklqdq %xmm6,%xmm1,%xmm1
     432:	c4 e3 75 38 cc 01    	vinserti128 $0x1,%xmm4,%ymm1,%ymm1
     438:	c5 ed db e3          	vpand  %ymm3,%ymm2,%ymm4
     43c:	c5 75 db e3          	vpand  %ymm3,%ymm1,%ymm12
     440:	c5 9d fa f4          	vpsubd %ymm4,%ymm12,%ymm6
     444:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     449:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     44e:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     453:	c5 4d fe d4          	vpaddd %ymm4,%ymm6,%ymm10
     457:	c5 fd db f3          	vpand  %ymm3,%ymm0,%ymm6
     45b:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     45f:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     464:	c5 9d 72 d1 08       	vpsrld $0x8,%ymm1,%ymm12
     469:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     46e:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
     473:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     477:	c5 1d db e3          	vpand  %ymm3,%ymm12,%ymm12
     47b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     480:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
     484:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     488:	c5 c5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm7
     48d:	c5 ad fe f6          	vpaddd %ymm6,%ymm10,%ymm6
     491:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     496:	c5 c5 db fb          	vpand  %ymm3,%ymm7,%ymm7
     49a:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     49f:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
     4a4:	c5 fd db c3          	vpand  %ymm3,%ymm0,%ymm0
     4a8:	c5 fd 7f 32          	vmovdqa %ymm6,(%rdx)
     4ac:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     4b1:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
     4b6:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     4ba:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     4bf:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     4c4:	c5 cd db f3          	vpand  %ymm3,%ymm6,%ymm6
     4c8:	c5 1d fa e6          	vpsubd %ymm6,%ymm12,%ymm12
     4cc:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
     4d1:	c5 ed db d3          	vpand  %ymm3,%ymm2,%ymm2
     4d5:	c4 42 1d 40 e1       	vpmulld %ymm9,%ymm12,%ymm12
     4da:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     4df:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     4e3:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     4e8:	c4 c1 2d 72 f5 10    	vpslld $0x10,%ymm13,%ymm10
     4ee:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     4f2:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     4f7:	c5 2d fe d4          	vpaddd %ymm4,%ymm10,%ymm10
     4fb:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
     500:	c4 c1 45 fe fc       	vpaddd %ymm12,%ymm7,%ymm7
     505:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
     509:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     50e:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     512:	c5 cd fe f4          	vpaddd %ymm4,%ymm6,%ymm6
     516:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     51b:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     51f:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     524:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     528:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     52d:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     532:	c5 f8 77             	vzeroupper
     535:	c5 f8 28 74 24 20    	vmovaps 0x20(%rsp),%xmm6
     53b:	c5 f8 28 7c 24 30    	vmovaps 0x30(%rsp),%xmm7
     541:	c5 78 28 44 24 40    	vmovaps 0x40(%rsp),%xmm8
     547:	c5 78 28 4c 24 50    	vmovaps 0x50(%rsp),%xmm9
     54d:	c5 78 28 54 24 60    	vmovaps 0x60(%rsp),%xmm10
     553:	c5 78 28 5c 24 70    	vmovaps 0x70(%rsp),%xmm11
     559:	c5 78 28 a4 24 80 00 	vmovaps 0x80(%rsp),%xmm12
     560:	00 00 
     562:	c5 78 28 ac 24 90 00 	vmovaps 0x90(%rsp),%xmm13
     569:	00 00 
     56b:	c5 78 28 b4 24 a0 00 	vmovaps 0xa0(%rsp),%xmm14
     572:	00 00 
     574:	c5 78 28 bc 24 b0 00 	vmovaps 0xb0(%rsp),%xmm15
     57b:	00 00 
     57d:	48 81 c4 c0 00 00 00 	add    $0xc0,%rsp
     584:	5b                   	pop    %rbx
     585:	5e                   	pop    %rsi
     586:	5f                   	pop    %rdi
     587:	5d                   	pop    %rbp
     588:	41 5c                	pop    %r12
     58a:	c3                   	ret
     58b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000000590 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>:
     590:	41 57                	push   %r15
     592:	41 56                	push   %r14
     594:	41 55                	push   %r13
     596:	41 54                	push   %r12
     598:	55                   	push   %rbp
     599:	57                   	push   %rdi
     59a:	56                   	push   %rsi
     59b:	53                   	push   %rbx
     59c:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
     5a3:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
     5aa:	00 00 
     5ac:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
     5b3:	00 00 
     5b5:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
     5bc:	00 00 
     5be:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
     5c5:	00 00 
     5c7:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
     5ce:	00 00 
     5d0:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
     5d7:	00 00 
     5d9:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
     5e0:	00 00 
     5e2:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
     5e9:	00 00 
     5eb:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
     5f2:	00 00 
     5f4:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
     5fb:	00 00 
     5fd:	48 8b 01             	mov    (%rcx),%rax
     600:	44 8b 5a 18          	mov    0x18(%rdx),%r11d
     604:	8b 5a 10             	mov    0x10(%rdx),%ebx
     607:	8b 72 1c             	mov    0x1c(%rdx),%esi
     60a:	44 8b 7a 08          	mov    0x8(%rdx),%r15d
     60e:	c4 a1 79 6e 1c 98    	vmovd  (%rax,%r11,4),%xmm3
     614:	44 8b 14 98          	mov    (%rax,%rbx,4),%r10d
     618:	44 8b 0a             	mov    (%rdx),%r9d
     61b:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     620:	c4 e3 61 22 0c b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm3,%xmm1
     627:	8b 7a 14             	mov    0x14(%rdx),%edi
     62a:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
     631:	00 
     632:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
     637:	46 8b 14 b8          	mov    (%rax,%r15,4),%r10d
     63b:	44 8b 42 04          	mov    0x4(%rdx),%r8d
     63f:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
     646:	00 
     647:	c4 e3 61 22 04 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm3,%xmm0
     64e:	44 8b 72 0c          	mov    0xc(%rdx),%r14d
     652:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
     657:	c4 c1 79 6e ea       	vmovd  %r10d,%xmm5
     65c:	46 8b 14 88          	mov    (%rax,%r9,4),%r10d
     660:	8b 6a 38             	mov    0x38(%rdx),%ebp
     663:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
     66a:	00 
     66b:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
     66f:	c4 a3 51 22 0c b0 01 	vpinsrd $0x1,(%rax,%r14,4),%xmm5,%xmm1
     676:	44 8b 62 34          	mov    0x34(%rdx),%r12d
     67a:	4c 89 84 24 c8 00 00 	mov    %r8,0xc8(%rsp)
     681:	00 
     682:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
     687:	44 8b 6a 30          	mov    0x30(%rdx),%r13d
     68b:	44 8b 52 3c          	mov    0x3c(%rdx),%r10d
     68f:	4c 89 b4 24 a0 00 00 	mov    %r14,0xa0(%rsp)
     696:	00 
     697:	c4 a3 61 22 34 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm3,%xmm6
     69e:	48 8b 41 08          	mov    0x8(%rcx),%rax
     6a2:	8b 5a 2c             	mov    0x2c(%rdx),%ebx
     6a5:	44 8b 42 28          	mov    0x28(%rdx),%r8d
     6a9:	44 8b 4a 24          	mov    0x24(%rdx),%r9d
     6ad:	44 8b 72 20          	mov    0x20(%rdx),%r14d
     6b1:	c5 c9 6c f1          	vpunpcklqdq %xmm1,%xmm6,%xmm6
     6b5:	4c 89 94 24 d8 00 00 	mov    %r10,0xd8(%rsp)
     6bc:	00 
     6bd:	44 8b 3c a8          	mov    (%rax,%rbp,4),%r15d
     6c1:	c4 e3 4d 38 f0 01    	vinserti128 $0x1,%xmm0,%ymm6,%ymm6
     6c7:	48 89 ac 24 e0 00 00 	mov    %rbp,0xe0(%rsp)
     6ce:	00 
     6cf:	8b 6a 58             	mov    0x58(%rdx),%ebp
     6d2:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
     6d9:	00 
     6da:	c4 c1 79 6e ef       	vmovd  %r15d,%xmm5
     6df:	46 8b 3c b0          	mov    (%rax,%r14,4),%r15d
     6e3:	4c 89 a4 24 e8 00 00 	mov    %r12,0xe8(%rsp)
     6ea:	00 
     6eb:	c4 a3 51 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm5,%xmm1
     6f2:	46 8b 14 a8          	mov    (%rax,%r13,4),%r10d
     6f6:	4c 89 84 24 00 01 00 	mov    %r8,0x100(%rsp)
     6fd:	00 
     6fe:	4c 89 8c 24 08 01 00 	mov    %r9,0x108(%rsp)
     705:	00 
     706:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
     70b:	46 8b 14 80          	mov    (%rax,%r8,4),%r10d
     70f:	44 8b 42 40          	mov    0x40(%rdx),%r8d
     713:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
     71a:	00 
     71b:	c4 a3 61 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm3,%xmm0
     722:	c4 c1 79 6e df       	vmovd  %r15d,%xmm3
     727:	44 8b 62 54          	mov    0x54(%rdx),%r12d
     72b:	48 89 9c 24 f8 00 00 	mov    %rbx,0xf8(%rsp)
     732:	00 
     733:	c4 c1 79 6e ea       	vmovd  %r10d,%xmm5
     738:	c4 a3 61 22 24 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm3,%xmm4
     73f:	44 8b 52 50          	mov    0x50(%rdx),%r10d
     743:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
     74a:	00 
     74b:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
     74f:	c4 e3 51 22 0c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm5,%xmm1
     756:	48 8b 41 10          	mov    0x10(%rcx),%rax
     75a:	4c 89 a4 24 28 01 00 	mov    %r12,0x128(%rsp)
     761:	00 
     762:	44 8b 7a 5c          	mov    0x5c(%rdx),%r15d
     766:	44 8b 4a 48          	mov    0x48(%rdx),%r9d
     76a:	44 8b 34 a8          	mov    (%rax,%rbp,4),%r14d
     76e:	c4 a1 79 6e 1c 90    	vmovd  (%rax,%r10,4),%xmm3
     774:	c5 d9 6c e1          	vpunpcklqdq %xmm1,%xmm4,%xmm4
     778:	44 8b 6a 4c          	mov    0x4c(%rdx),%r13d
     77c:	8b 5a 44             	mov    0x44(%rdx),%ebx
     77f:	4c 89 bc 24 18 01 00 	mov    %r15,0x118(%rsp)
     786:	00 
     787:	c4 e3 5d 38 e0 01    	vinserti128 $0x1,%xmm0,%ymm4,%ymm4
     78d:	c4 c1 79 6e ee       	vmovd  %r14d,%xmm5
     792:	c4 a3 51 22 0c b8 01 	vpinsrd $0x1,(%rax,%r15,4),%xmm5,%xmm1
     799:	c4 a3 61 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm3,%xmm0
     7a0:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
     7a7:	00 
     7a8:	c4 a1 79 6e 2c 88    	vmovd  (%rax,%r9,4),%xmm5
     7ae:	c4 a1 79 6e 1c 80    	vmovd  (%rax,%r8,4),%xmm3
     7b4:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
     7bb:	00 
     7bc:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
     7c0:	c4 62 7d 58 51 54    	vpbroadcastd 0x54(%rcx),%ymm10
     7c6:	c4 a3 51 22 0c a8 01 	vpinsrd $0x1,(%rax,%r13,4),%xmm5,%xmm1
     7cd:	c5 d5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm5
     7d2:	c4 e3 61 22 3c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm3,%xmm7
     7d9:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     7dd:	48 8b 41 48          	mov    0x48(%rcx),%rax
     7e1:	c5 c1 6c f9          	vpunpcklqdq %xmm1,%xmm7,%xmm7
     7e5:	c4 e2 7d 58 49 50    	vpbroadcastd 0x50(%rcx),%ymm1
     7eb:	c4 e3 45 38 f8 01    	vinserti128 $0x1,%xmm0,%ymm7,%ymm7
     7f1:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
     7f6:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     7fb:	c4 e2 55 40 e9       	vpmulld %ymm1,%ymm5,%ymm5
     800:	c5 ed 72 d7 11       	vpsrld $0x11,%ymm7,%ymm2
     805:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
     809:	c5 fd 72 d3 0f       	vpsrld $0xf,%ymm3,%ymm0
     80e:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     812:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     816:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     81a:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     81e:	c4 e3 7d 39 e8 01    	vextracti128 $0x1,%ymm5,%xmm0
     824:	c5 f9 7e ee          	vmovd  %xmm5,%esi
     828:	c4 c3 79 16 c7 02    	vpextrd $0x2,%xmm0,%r15d
     82e:	c4 c1 79 7e c5       	vmovd  %xmm0,%r13d
     833:	c4 c3 79 16 c4 01    	vpextrd $0x1,%xmm0,%r12d
     839:	c4 a1 79 6e 14 b8    	vmovd  (%rax,%r15,4),%xmm2
     83f:	c4 c3 79 16 c6 03    	vpextrd $0x3,%xmm0,%r14d
     845:	c4 a1 79 6e 04 a8    	vmovd  (%rax,%r13,4),%xmm0
     84b:	c4 e3 79 16 ed 02    	vpextrd $0x2,%xmm5,%ebp
     851:	c5 79 6e 04 a8       	vmovd  (%rax,%rbp,4),%xmm8
     856:	c4 e3 79 16 eb 01    	vpextrd $0x1,%xmm5,%ebx
     85c:	c4 e3 79 16 ef 03    	vpextrd $0x3,%xmm5,%edi
     862:	c4 62 4d 3d dc       	vpmaxsd %ymm4,%ymm6,%ymm11
     867:	c4 a3 69 22 14 b0 01 	vpinsrd $0x1,(%rax,%r14,4),%xmm2,%xmm2
     86e:	c4 a3 79 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm0,%xmm0
     875:	c4 62 4d 39 e4       	vpminsd %ymm4,%ymm6,%ymm12
     87a:	44 8b 71 54          	mov    0x54(%rcx),%r14d
     87e:	c4 63 39 22 04 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm8,%xmm8
     885:	c5 e5 72 d3 18       	vpsrld $0x18,%ymm3,%ymm3
     88a:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     88e:	c5 f9 6e 14 b0       	vmovd  (%rax,%rsi,4),%xmm2
     893:	8b 71 50             	mov    0x50(%rcx),%esi
     896:	c4 e3 69 22 14 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm2,%xmm2
     89d:	41 8d 5c 36 01       	lea    0x1(%r14,%rsi,1),%ebx
     8a2:	c4 c1 69 6c d0       	vpunpcklqdq %xmm8,%xmm2,%xmm2
     8a7:	c5 79 6e c3          	vmovd  %ebx,%xmm8
     8ab:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     8b0:	c4 63 6d 38 f0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm14
     8b6:	c5 bd fe d5          	vpaddd %ymm5,%ymm8,%ymm2
     8ba:	c4 e3 7d 39 d0 01    	vextracti128 $0x1,%ymm2,%xmm0
     8c0:	c5 f9 7e d6          	vmovd  %xmm2,%esi
     8c4:	c4 e3 79 16 d3 01    	vpextrd $0x1,%xmm2,%ebx
     8ca:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     8cf:	c4 c3 79 16 c7 02    	vpextrd $0x2,%xmm0,%r15d
     8d5:	c4 c1 79 7e c5       	vmovd  %xmm0,%r13d
     8da:	c4 e3 79 16 d5 02    	vpextrd $0x2,%xmm2,%ebp
     8e0:	c4 e3 79 16 d7 03    	vpextrd $0x3,%xmm2,%edi
     8e6:	c4 c3 79 16 c4 01    	vpextrd $0x1,%xmm0,%r12d
     8ec:	c4 a1 79 6e 14 b8    	vmovd  (%rax,%r15,4),%xmm2
     8f2:	c4 c3 79 16 c6 03    	vpextrd $0x3,%xmm0,%r14d
     8f8:	c4 a1 79 6e 04 a8    	vmovd  (%rax,%r13,4),%xmm0
     8fe:	c5 79 6e 0c a8       	vmovd  (%rax,%rbp,4),%xmm9
     903:	c4 a3 69 22 14 b0 01 	vpinsrd $0x1,(%rax,%r14,4),%xmm2,%xmm2
     90a:	c4 a3 79 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm0,%xmm0
     911:	c4 63 31 22 0c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm9,%xmm9
     918:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     91c:	c5 f9 6e 14 b0       	vmovd  (%rax,%rsi,4),%xmm2
     921:	c4 e3 69 22 14 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm2,%xmm2
     928:	48 8b 59 18          	mov    0x18(%rcx),%rbx
     92c:	c4 c1 69 6c d1       	vpunpcklqdq %xmm9,%xmm2,%xmm2
     931:	c4 e3 6d 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm0
     937:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     93d:	c4 a1 79 6e 04 9b    	vmovd  (%rbx,%r11,4),%xmm0
     943:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
     948:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
     94d:	4c 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%r15
     954:	00 
     955:	c4 e3 79 22 04 b3 01 	vpinsrd $0x1,(%rbx,%rsi,4),%xmm0,%xmm0
     95c:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
     963:	00 
     964:	c4 21 79 6e 0c bb    	vmovd  (%rbx,%r15,4),%xmm9
     96a:	4c 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%r14
     971:	00 
     972:	c5 f9 6e 14 b3       	vmovd  (%rbx,%rsi,4),%xmm2
     977:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
     97e:	00 
     97f:	c4 23 31 22 0c b3 01 	vpinsrd $0x1,(%rbx,%r14,4),%xmm9,%xmm9
     986:	4c 8b 59 20          	mov    0x20(%rcx),%r11
     98a:	c4 e3 69 22 14 bb 01 	vpinsrd $0x1,(%rbx,%rdi,4),%xmm2,%xmm2
     991:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
     998:	00 
     999:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
     9a0:	00 
     9a1:	4c 8b ac 24 f0 00 00 	mov    0xf0(%rsp),%r13
     9a8:	00 
     9a9:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     9ad:	c5 f9 6e 04 b3       	vmovd  (%rbx,%rsi,4),%xmm0
     9b2:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
     9b9:	00 
     9ba:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
     9c1:	00 
     9c2:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
     9c9:	00 
     9ca:	c4 e3 79 22 04 bb 01 	vpinsrd $0x1,(%rbx,%rdi,4),%xmm0,%xmm0
     9d1:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
     9d8:	00 
     9d9:	48 8b 9c 24 f8 00 00 	mov    0xf8(%rsp),%rbx
     9e0:	00 
     9e1:	c4 c1 79 6c c1       	vpunpcklqdq %xmm9,%xmm0,%xmm0
     9e6:	c4 41 79 6e 0c b3    	vmovd  (%r11,%rsi,4),%xmm9
     9ec:	c4 63 7d 38 ea 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm13
     9f2:	c4 c1 79 6e 04 ab    	vmovd  (%r11,%rbp,4),%xmm0
     9f8:	c4 81 79 6e 14 ab    	vmovd  (%r11,%r13,4),%xmm2
     9fe:	c4 43 31 22 0c 9b 01 	vpinsrd $0x1,(%r11,%rbx,4),%xmm9,%xmm9
     a05:	c4 c3 79 22 04 bb 01 	vpinsrd $0x1,(%r11,%rdi,4),%xmm0,%xmm0
     a0c:	c4 83 69 22 14 a3 01 	vpinsrd $0x1,(%r11,%r12,4),%xmm2,%xmm2
     a13:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
     a1a:	00 
     a1b:	c5 e9 6c d0          	vpunpcklqdq %xmm0,%xmm2,%xmm2
     a1f:	c4 81 79 6e 04 b3    	vmovd  (%r11,%r14,4),%xmm0
     a25:	c4 c3 79 22 04 bb 01 	vpinsrd $0x1,(%r11,%rdi,4),%xmm0,%xmm0
     a2c:	c4 c1 79 6c c1       	vpunpcklqdq %xmm9,%xmm0,%xmm0
     a31:	c4 63 7d 38 fa 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm15
     a37:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
     a3e:	00 00 
     a40:	48 8b 49 28          	mov    0x28(%rcx),%rcx
     a44:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
     a4b:	00 
     a4c:	c5 4d fe fc          	vpaddd %ymm4,%ymm6,%ymm15
     a50:	4c 8b bc 24 18 01 00 	mov    0x118(%rsp),%r15
     a57:	00 
     a58:	4c 8b a4 24 28 01 00 	mov    0x128(%rsp),%r12
     a5f:	00 
     a60:	c5 7e 7f 74 24 20    	vmovdqu %ymm14,0x20(%rsp)
     a66:	c5 05 fe ff          	vpaddd %ymm7,%ymm15,%ymm15
     a6a:	c5 f9 6e 14 a9       	vmovd  (%rcx,%rbp,4),%xmm2
     a6f:	c4 a1 79 6e 04 91    	vmovd  (%rcx,%r10,4),%xmm0
     a75:	c4 21 79 6e 0c 89    	vmovd  (%rcx,%r9,4),%xmm9
     a7b:	48 8b 9c 24 38 01 00 	mov    0x138(%rsp),%rbx
     a82:	00 
     a83:	c4 a3 69 22 14 b9 01 	vpinsrd $0x1,(%rcx,%r15,4),%xmm2,%xmm2
     a8a:	c4 a3 79 22 04 a1 01 	vpinsrd $0x1,(%rcx,%r12,4),%xmm0,%xmm0
     a91:	4c 8b ac 24 30 01 00 	mov    0x130(%rsp),%r13
     a98:	00 
     a99:	c5 65 db 74 24 20    	vpand  0x20(%rsp),%ymm3,%ymm14
     a9f:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
     aa3:	c4 a1 79 6e 14 81    	vmovd  (%rcx,%r8,4),%xmm2
     aa9:	c4 23 31 22 0c a9 01 	vpinsrd $0x1,(%rcx,%r13,4),%xmm9,%xmm9
     ab0:	c4 e3 69 22 14 99 01 	vpinsrd $0x1,(%rcx,%rbx,4),%xmm2,%xmm2
     ab7:	c4 c1 69 6c d1       	vpunpcklqdq %xmm9,%xmm2,%xmm2
     abc:	c5 5d 66 ce          	vpcmpgtd %ymm6,%ymm4,%ymm9
     ac0:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     ac6:	c4 c1 45 66 c3       	vpcmpgtd %ymm11,%ymm7,%ymm0
     acb:	c4 62 25 3d df       	vpmaxsd %ymm7,%ymm11,%ymm11
     ad0:	c4 43 75 4c ca 90    	vpblendvb %ymm9,%ymm10,%ymm1,%ymm9
     ad6:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm9,%ymm9        # adf <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x54f>
     add:	ff ff 00 
     ae0:	c4 e2 1d 39 c7       	vpminsd %ymm7,%ymm12,%ymm0
     ae5:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     aeb:	c5 cd 66 c4          	vpcmpgtd %ymm4,%ymm6,%ymm0
     aef:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     af3:	c4 41 55 fe c9       	vpaddd %ymm9,%ymm5,%ymm9
     af8:	c4 c3 75 4c c2 00    	vpblendvb %ymm0,%ymm10,%ymm1,%ymm0
     afe:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm0,%ymm0        # b07 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x577>
     b05:	ff ff c0 
     b08:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
     b0c:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     b11:	c4 c1 79 7e c0       	vmovd  %xmm0,%r8d
     b16:	c4 e3 79 16 c1 01    	vpextrd $0x1,%xmm0,%ecx
     b1c:	c4 c3 79 16 c2 02    	vpextrd $0x2,%xmm0,%r10d
     b22:	c4 c3 79 16 c1 03    	vpextrd $0x3,%xmm0,%r9d
     b28:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     b2e:	c4 21 79 6e 24 90    	vmovd  (%rax,%r10,4),%xmm12
     b34:	c4 43 79 16 ca 02    	vpextrd $0x2,%xmm9,%r10d
     b3a:	c4 e3 79 16 c7 02    	vpextrd $0x2,%xmm0,%edi
     b40:	c5 f9 7e c3          	vmovd  %xmm0,%ebx
     b44:	c4 c3 79 16 c3 01    	vpextrd $0x1,%xmm0,%r11d
     b4a:	c5 79 6e 04 b8       	vmovd  (%rax,%rdi,4),%xmm8
     b4f:	c4 e3 79 16 c6 03    	vpextrd $0x3,%xmm0,%esi
     b55:	c5 f9 6e 04 98       	vmovd  (%rax,%rbx,4),%xmm0
     b5a:	c4 23 19 22 24 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm12,%xmm12
     b61:	c4 43 79 16 c9 03    	vpextrd $0x3,%xmm9,%r9d
     b67:	c4 63 39 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm8,%xmm8
     b6e:	c4 a3 79 22 04 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm0,%xmm0
     b75:	c4 c1 79 6c c0       	vpunpcklqdq %xmm8,%xmm0,%xmm0
     b7a:	c4 21 79 6e 04 80    	vmovd  (%rax,%r8,4),%xmm8
     b80:	c4 41 79 7e c8       	vmovd  %xmm9,%r8d
     b85:	c4 63 39 22 04 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm8,%xmm8
     b8c:	c4 63 79 16 c9 01    	vpextrd $0x1,%xmm9,%ecx
     b92:	c4 43 7d 39 c9 01    	vextracti128 $0x1,%ymm9,%xmm9
     b98:	c4 63 79 16 cf 02    	vpextrd $0x2,%xmm9,%edi
     b9e:	c5 79 7e cb          	vmovd  %xmm9,%ebx
     ba2:	c4 43 79 16 cb 01    	vpextrd $0x1,%xmm9,%r11d
     ba8:	c4 41 39 6c c4       	vpunpcklqdq %xmm12,%xmm8,%xmm8
     bad:	c4 63 79 16 ce 03    	vpextrd $0x3,%xmm9,%esi
     bb3:	c5 79 6e 0c 98       	vmovd  (%rax,%rbx,4),%xmm9
     bb8:	c4 21 79 6e 24 90    	vmovd  (%rax,%r10,4),%xmm12
     bbe:	c4 63 3d 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm8,%ymm8
     bc4:	c5 f9 6e 04 b8       	vmovd  (%rax,%rdi,4),%xmm0
     bc9:	c4 23 31 22 0c 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm9,%xmm9
     bd0:	c5 3d db c3          	vpand  %ymm3,%ymm8,%ymm8
     bd4:	c4 e3 79 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm0,%xmm0
     bdb:	c4 23 19 22 24 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm12,%xmm12
     be2:	c5 31 6c c8          	vpunpcklqdq %xmm0,%xmm9,%xmm9
     be6:	c4 a1 79 6e 04 80    	vmovd  (%rax,%r8,4),%xmm0
     bec:	c4 e3 79 22 04 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm0,%xmm0
     bf3:	b9 00 80 00 00       	mov    $0x8000,%ecx
     bf8:	c4 c1 79 6c c4       	vpunpcklqdq %xmm12,%xmm0,%xmm0
     bfd:	c4 c1 1d 72 f6 10    	vpslld $0x10,%ymm14,%ymm12
     c03:	c4 c3 7d 38 c1 01    	vinserti128 $0x1,%xmm9,%ymm0,%ymm0
     c09:	c5 25 fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm11,%ymm9
     c0f:	c5 fd db c3          	vpand  %ymm3,%ymm0,%ymm0
     c13:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
     c18:	c5 3d fa f8          	vpsubd %ymm0,%ymm8,%ymm15
     c1c:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
     c21:	c4 42 35 40 cf       	vpmulld %ymm15,%ymm9,%ymm9
     c26:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     c2a:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
     c31:	00 00 
     c33:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     c38:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     c3d:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
     c42:	c5 b5 fe c0          	vpaddd %ymm0,%ymm9,%ymm0
     c46:	c5 65 db 4c 24 40    	vpand  0x40(%rsp),%ymm3,%ymm9
     c4c:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
     c51:	c4 c1 3d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm8
     c57:	c4 62 35 40 4c 24 60 	vpmulld 0x60(%rsp),%ymm9,%ymm9
     c5e:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     c63:	c5 3d fe c6          	vpaddd %ymm6,%ymm8,%ymm8
     c67:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
     c6c:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
     c71:	c5 fd 72 e2 10       	vpsrad $0x10,%ymm2,%ymm0
     c76:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     c7b:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     c7f:	c5 7e 7f 9c 24 a0 00 	vmovdqu %ymm11,0xa0(%rsp)
     c86:	00 00 
     c88:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     c8d:	c4 c1 25 72 e7 10    	vpsrad $0x10,%ymm15,%ymm11
     c93:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     c97:	c4 c1 45 72 f7 10    	vpslld $0x10,%ymm15,%ymm7
     c9d:	c5 25 fe dc          	vpaddd %ymm4,%ymm11,%ymm11
     ca1:	c5 c5 72 e7 10       	vpsrad $0x10,%ymm7,%ymm7
     ca6:	c4 41 25 fe e0       	vpaddd %ymm8,%ymm11,%ymm12
     cab:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     caf:	c4 c1 5d 72 f5 10    	vpslld $0x10,%ymm13,%ymm4
     cb5:	c5 7e 7f a4 24 80 00 	vmovdqu %ymm12,0x80(%rsp)
     cbc:	00 00 
     cbe:	c5 dd 72 e4 10       	vpsrad $0x10,%ymm4,%ymm4
     cc3:	c5 6d fe ff          	vpaddd %ymm7,%ymm2,%ymm15
     cc7:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     ccb:	c4 62 5d 3d e7       	vpmaxsd %ymm7,%ymm4,%ymm12
     cd0:	c5 c5 66 f4          	vpcmpgtd %ymm4,%ymm7,%ymm6
     cd4:	c4 41 6d 66 cc       	vpcmpgtd %ymm12,%ymm2,%ymm9
     cd9:	c4 62 1d 3d e2       	vpmaxsd %ymm2,%ymm12,%ymm12
     cde:	c4 c3 75 4c f2 60    	vpblendvb %ymm6,%ymm10,%ymm1,%ymm6
     ce4:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # ced <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x75d>
     ceb:	ff ff 90 
     cee:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
     cf3:	c5 dd 66 ff          	vpcmpgtd %ymm7,%ymm4,%ymm7
     cf7:	c4 62 35 39 ea       	vpminsd %ymm2,%ymm9,%ymm13
     cfc:	c5 d5 fe f6          	vpaddd %ymm6,%ymm5,%ymm6
     d00:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     d04:	c4 c1 79 7e f0       	vmovd  %xmm6,%r8d
     d09:	c5 fe 6f 14 24       	vmovdqu (%rsp),%ymm2
     d0e:	c4 e3 79 16 f1 01    	vpextrd $0x1,%xmm6,%ecx
     d14:	c4 c3 79 16 f2 02    	vpextrd $0x2,%xmm6,%r10d
     d1a:	c4 c3 79 16 f1 03    	vpextrd $0x3,%xmm6,%r9d
     d20:	c4 e3 7d 39 f6 01    	vextracti128 $0x1,%ymm6,%xmm6
     d26:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
     d2c:	c4 c3 75 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm1,%ymm7
     d32:	c4 e3 79 16 f7 02    	vpextrd $0x2,%xmm6,%edi
     d38:	c5 f9 7e f3          	vmovd  %xmm6,%ebx
     d3c:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
     d42:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # d4b <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x7bb>
     d49:	ff ff 90 
     d4c:	c4 c3 79 16 f3 01    	vpextrd $0x1,%xmm6,%r11d
     d52:	c4 e3 79 16 f6 03    	vpextrd $0x3,%xmm6,%esi
     d58:	c5 f9 6e 34 98       	vmovd  (%rax,%rbx,4),%xmm6
     d5d:	c5 ed fa ff          	vpsubd %ymm7,%ymm2,%ymm7
     d61:	c5 f9 6e 14 b8       	vmovd  (%rax,%rdi,4),%xmm2
     d66:	c4 21 79 6e 0c 90    	vmovd  (%rax,%r10,4),%xmm9
     d6c:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
     d72:	c4 a3 49 22 34 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm6,%xmm6
     d79:	c4 c3 79 16 fa 02    	vpextrd $0x2,%xmm7,%r10d
     d7f:	c5 05 fa 7c 24 60    	vpsubd 0x60(%rsp),%ymm15,%ymm15
     d85:	c4 e3 69 22 14 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm2,%xmm2
     d8c:	c4 23 31 22 0c 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm9,%xmm9
     d93:	c4 c3 79 16 f9 03    	vpextrd $0x3,%xmm7,%r9d
     d99:	c5 15 db eb          	vpand  %ymm3,%ymm13,%ymm13
     d9d:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
     da2:	c5 c9 6c f2          	vpunpcklqdq %xmm2,%xmm6,%xmm6
     da6:	c4 a1 79 6e 14 80    	vmovd  (%rax,%r8,4),%xmm2
     dac:	c4 c1 79 7e f8       	vmovd  %xmm7,%r8d
     db1:	c5 85 fe e4          	vpaddd %ymm4,%ymm15,%ymm4
     db5:	c4 e3 69 22 14 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm2,%xmm2
     dbc:	c4 e3 79 16 f9 01    	vpextrd $0x1,%xmm7,%ecx
     dc2:	c4 e3 7d 39 ff 01    	vextracti128 $0x1,%ymm7,%xmm7
     dc8:	c4 e3 79 16 ff 02    	vpextrd $0x2,%xmm7,%edi
     dce:	c5 f9 7e fb          	vmovd  %xmm7,%ebx
     dd2:	c4 c3 79 16 fb 01    	vpextrd $0x1,%xmm7,%r11d
     dd8:	c4 c1 69 6c d1       	vpunpcklqdq %xmm9,%xmm2,%xmm2
     ddd:	c4 e3 79 16 fe 03    	vpextrd $0x3,%xmm7,%esi
     de3:	c5 f9 6e 3c 98       	vmovd  (%rax,%rbx,4),%xmm7
     de8:	c4 21 79 6e 0c 90    	vmovd  (%rax,%r10,4),%xmm9
     dee:	c4 e3 6d 38 d6 01    	vinserti128 $0x1,%xmm6,%ymm2,%ymm2
     df4:	c5 f9 6e 34 b8       	vmovd  (%rax,%rdi,4),%xmm6
     df9:	c4 a3 41 22 3c 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm7,%xmm7
     e00:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     e05:	c4 23 31 22 0c 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm9,%xmm9
     e0c:	c4 e3 49 22 34 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm6,%xmm6
     e13:	c5 ed db d3          	vpand  %ymm3,%ymm2,%ymm2
     e17:	c5 c1 6c fe          	vpunpcklqdq %xmm6,%xmm7,%xmm7
     e1b:	c4 a1 79 6e 34 80    	vmovd  (%rax,%r8,4),%xmm6
     e21:	c4 e3 49 22 34 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm6,%xmm6
     e28:	c4 c1 49 6c f1       	vpunpcklqdq %xmm9,%xmm6,%xmm6
     e2d:	c4 e3 4d 38 f7 01    	vinserti128 $0x1,%xmm7,%ymm6,%ymm6
     e33:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
     e39:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     e3e:	c5 cd db f3          	vpand  %ymm3,%ymm6,%ymm6
     e42:	c5 b5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm9
     e47:	c5 4d fa fa          	vpsubd %ymm2,%ymm6,%ymm15
     e4b:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
     e50:	c5 35 db cb          	vpand  %ymm3,%ymm9,%ymm9
     e54:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
     e59:	c4 42 5d 40 ff       	vpmulld %ymm15,%ymm4,%ymm15
     e5e:	c5 35 fa ce          	vpsubd %ymm6,%ymm9,%ymm9
     e62:	c4 62 35 40 4c 24 60 	vpmulld 0x60(%rsp),%ymm9,%ymm9
     e69:	c4 c2 3d 3d e3       	vpmaxsd %ymm11,%ymm8,%ymm4
     e6e:	c4 c1 45 72 f5 10    	vpslld $0x10,%ymm13,%ymm7
     e74:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
     e7a:	c5 fd 66 f4          	vpcmpgtd %ymm4,%ymm0,%ymm6
     e7e:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     e83:	c5 7e 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm12
     e8a:	00 00 
     e8c:	c4 e2 5d 3d e0       	vpmaxsd %ymm0,%ymm4,%ymm4
     e91:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
     e95:	c4 c1 25 66 d0       	vpcmpgtd %ymm8,%ymm11,%ymm2
     e9a:	c5 85 fe ff          	vpaddd %ymm7,%ymm15,%ymm7
     e9e:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     ea3:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     ea8:	c4 c3 75 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm1,%ymm2
     eae:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm2,%ymm2        # eb7 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x927>
     eb5:	ff ff 60 
     eb8:	c4 c2 3d 39 f3       	vpminsd %ymm11,%ymm8,%ymm6
     ebd:	c4 41 3d 66 c3       	vpcmpgtd %ymm11,%ymm8,%ymm8
     ec2:	c4 62 4d 39 c8       	vpminsd %ymm0,%ymm6,%ymm9
     ec7:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
     ecb:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
     ed0:	c5 cd 66 f0          	vpcmpgtd %ymm0,%ymm6,%ymm6
     ed4:	c4 c1 79 7e d0       	vmovd  %xmm2,%r8d
     ed9:	c4 e3 79 16 d1 01    	vpextrd $0x1,%xmm2,%ecx
     edf:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
     ee6:	00 00 
     ee8:	c4 c3 79 16 d2 02    	vpextrd $0x2,%xmm2,%r10d
     eee:	c4 c3 79 16 d1 03    	vpextrd $0x3,%xmm2,%r9d
     ef4:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
     efa:	c4 c3 75 4c ca 80    	vpblendvb %ymm8,%ymm10,%ymm1,%ymm1
     f00:	c4 e3 79 16 d7 02    	vpextrd $0x2,%xmm2,%edi
     f06:	c5 f9 7e d3          	vmovd  %xmm2,%ebx
     f0a:	c4 21 79 6e 04 80    	vmovd  (%rax,%r8,4),%xmm8
     f10:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # f19 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)+0x989>
     f17:	ff ff 60 
     f1a:	c4 c3 79 16 d3 01    	vpextrd $0x1,%xmm2,%r11d
     f20:	c5 f9 6e 34 b8       	vmovd  (%rax,%rdi,4),%xmm6
     f25:	c4 e3 79 16 d6 03    	vpextrd $0x3,%xmm2,%esi
     f2b:	c5 f9 6e 14 98       	vmovd  (%rax,%rbx,4),%xmm2
     f30:	c4 63 39 22 04 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm8,%xmm8
     f37:	c5 d5 fa c9          	vpsubd %ymm1,%ymm5,%ymm1
     f3b:	c4 41 1d fa d1       	vpsubd %ymm9,%ymm12,%ymm10
     f40:	c4 e3 49 22 34 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm6,%xmm6
     f47:	c4 c1 79 7e c8       	vmovd  %xmm1,%r8d
     f4c:	c4 e3 79 16 c9 01    	vpextrd $0x1,%xmm1,%ecx
     f52:	c4 a3 69 22 14 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm2,%xmm2
     f59:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
     f5f:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
     f63:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     f67:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
     f6c:	c5 e9 6c d6          	vpunpcklqdq %xmm6,%xmm2,%xmm2
     f70:	c4 a1 79 6e 34 90    	vmovd  (%rax,%r10,4),%xmm6
     f76:	c4 c3 79 16 ca 02    	vpextrd $0x2,%xmm1,%r10d
     f7c:	c4 a3 49 22 34 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm6,%xmm6
     f83:	c4 c3 79 16 c9 03    	vpextrd $0x3,%xmm1,%r9d
     f89:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     f8f:	c4 e3 79 16 cf 02    	vpextrd $0x2,%xmm1,%edi
     f95:	c5 f9 7e cb          	vmovd  %xmm1,%ebx
     f99:	c4 c3 79 16 cb 01    	vpextrd $0x1,%xmm1,%r11d
     f9f:	c5 39 6c c6          	vpunpcklqdq %xmm6,%xmm8,%xmm8
     fa3:	c4 e3 79 16 ce 03    	vpextrd $0x3,%xmm1,%esi
     fa9:	c5 f9 6e 0c 98       	vmovd  (%rax,%rbx,4),%xmm1
     fae:	c4 a1 79 6e 34 90    	vmovd  (%rax,%r10,4),%xmm6
     fb4:	c4 63 3d 38 c2 01    	vinserti128 $0x1,%xmm2,%ymm8,%ymm8
     fba:	c5 f9 6e 14 b8       	vmovd  (%rax,%rdi,4),%xmm2
     fbf:	c4 a3 71 22 0c 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm1,%xmm1
     fc6:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     fcc:	c4 a3 49 22 34 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm6,%xmm6
     fd3:	c4 e3 69 22 14 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm2,%xmm2
     fda:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
     fde:	c4 a1 79 6e 14 80    	vmovd  (%rax,%r8,4),%xmm2
     fe4:	c4 e3 69 22 14 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm2,%xmm2
     feb:	c5 7d 7f 1a          	vmovdqa %ymm11,(%rdx)
     fef:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     ff4:	c5 e9 6c d6          	vpunpcklqdq %xmm6,%xmm2,%xmm2
     ff8:	c4 e3 6d 38 d1 01    	vinserti128 $0x1,%xmm1,%ymm2,%ymm2
     ffe:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
    1004:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1009:	c5 cd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm6
    100e:	c5 ed db d3          	vpand  %ymm3,%ymm2,%ymm2
    1012:	c5 bd db cb          	vpand  %ymm3,%ymm8,%ymm1
    1016:	c5 cd db db          	vpand  %ymm3,%ymm6,%ymm3
    101a:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    101f:	c5 6d fa d1          	vpsubd %ymm1,%ymm2,%ymm10
    1023:	c5 e5 fa d2          	vpsubd %ymm2,%ymm3,%ymm2
    1027:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    102b:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1030:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1035:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    103a:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    103f:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    1044:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    1048:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    104c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1051:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
    1056:	c5 f8 77             	vzeroupper
    1059:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
    1060:	00 00 
    1062:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
    1069:	00 00 
    106b:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
    1072:	00 00 
    1074:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
    107b:	00 00 
    107d:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
    1084:	00 00 
    1086:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
    108d:	00 00 
    108f:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
    1096:	00 00 
    1098:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
    109f:	00 00 
    10a1:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
    10a8:	00 00 
    10aa:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
    10b1:	00 00 
    10b3:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    10ba:	5b                   	pop    %rbx
    10bb:	5e                   	pop    %rsi
    10bc:	5f                   	pop    %rdi
    10bd:	5d                   	pop    %rbp
    10be:	41 5c                	pop    %r12
    10c0:	41 5d                	pop    %r13
    10c2:	41 5e                	pop    %r14
    10c4:	41 5f                	pop    %r15
    10c6:	c3                   	ret
    10c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    10ce:	00 00 

00000000000010d0 <void jshc_scalar_gather::(anonymous namespace)::transform<false, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>:
    10d0:	41 57                	push   %r15
    10d2:	41 56                	push   %r14
    10d4:	41 55                	push   %r13
    10d6:	41 54                	push   %r12
    10d8:	55                   	push   %rbp
    10d9:	57                   	push   %rdi
    10da:	56                   	push   %rsi
    10db:	53                   	push   %rbx
    10dc:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    10e3:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
    10ea:	00 00 
    10ec:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
    10f3:	00 00 
    10f5:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
    10fc:	00 00 
    10fe:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
    1105:	00 00 
    1107:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
    110e:	00 00 
    1110:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
    1117:	00 00 
    1119:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
    1120:	00 00 
    1122:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
    1129:	00 00 
    112b:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
    1132:	00 00 
    1134:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
    113b:	00 00 
    113d:	48 8b 01             	mov    (%rcx),%rax
    1140:	8b 72 18             	mov    0x18(%rdx),%esi
    1143:	44 8b 4a 10          	mov    0x10(%rdx),%r9d
    1147:	8b 5a 1c             	mov    0x1c(%rdx),%ebx
    114a:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
    114e:	8b 7a 14             	mov    0x14(%rdx),%edi
    1151:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    1156:	42 8b 2c 88          	mov    (%rax,%r9,4),%ebp
    115a:	44 8b 72 08          	mov    0x8(%rdx),%r14d
    115e:	48 89 1c 24          	mov    %rbx,(%rsp)
    1162:	c4 c1 79 6e db       	vmovd  %r11d,%xmm3
    1167:	44 8b 42 0c          	mov    0xc(%rdx),%r8d
    116b:	44 8b 3a             	mov    (%rdx),%r15d
    116e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
    1173:	c4 e3 61 22 0c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm3,%xmm1
    117a:	c5 f9 6e dd          	vmovd  %ebp,%xmm3
    117e:	44 8b 52 04          	mov    0x4(%rdx),%r10d
    1182:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    1187:	c4 e3 61 22 04 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm3,%xmm0
    118e:	c4 a1 79 6e 1c b0    	vmovd  (%rax,%r14,4),%xmm3
    1194:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    1199:	44 8b 5a 38          	mov    0x38(%rdx),%r11d
    119d:	44 8b 62 30          	mov    0x30(%rdx),%r12d
    11a1:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
    11a6:	c4 a3 61 22 14 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm3,%xmm2
    11ad:	c4 a1 79 6e 1c b8    	vmovd  (%rax,%r15,4),%xmm3
    11b3:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
    11b7:	44 8b 6a 3c          	mov    0x3c(%rdx),%r13d
    11bb:	8b 6a 34             	mov    0x34(%rdx),%ebp
    11be:	c4 a3 61 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm3,%xmm1
    11c5:	48 8b 41 08          	mov    0x8(%rcx),%rax
    11c9:	44 8b 4a 2c          	mov    0x2c(%rdx),%r9d
    11cd:	44 8b 42 28          	mov    0x28(%rdx),%r8d
    11d1:	44 8b 52 24          	mov    0x24(%rdx),%r10d
    11d5:	8b 7a 20             	mov    0x20(%rdx),%edi
    11d8:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    11dd:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
    11e1:	42 8b 1c 98          	mov    (%rax,%r11,4),%ebx
    11e5:	42 8b 34 a0          	mov    (%rax,%r12,4),%esi
    11e9:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
    11ef:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    11f4:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    11f9:	44 8b 5a 4c          	mov    0x4c(%rdx),%r11d
    11fd:	c5 f9 6e db          	vmovd  %ebx,%xmm3
    1201:	42 8b 1c 80          	mov    (%rax,%r8,4),%ebx
    1205:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
    120a:	c4 a3 61 22 14 a8 01 	vpinsrd $0x1,(%rax,%r13,4),%xmm3,%xmm2
    1211:	c5 f9 6e de          	vmovd  %esi,%xmm3
    1215:	8b 34 b8             	mov    (%rax,%rdi,4),%esi
    1218:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    121d:	c4 e3 61 22 04 a8 01 	vpinsrd $0x1,(%rax,%rbp,4),%xmm3,%xmm0
    1224:	c5 f9 6e db          	vmovd  %ebx,%xmm3
    1228:	44 8b 42 50          	mov    0x50(%rdx),%r8d
    122c:	4c 89 54 24 60       	mov    %r10,0x60(%rsp)
    1231:	8b 5a 5c             	mov    0x5c(%rdx),%ebx
    1234:	8b 6a 48             	mov    0x48(%rdx),%ebp
    1237:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    123c:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
    1240:	c4 a3 61 22 14 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm3,%xmm2
    1247:	c5 f9 6e de          	vmovd  %esi,%xmm3
    124b:	44 8b 4a 58          	mov    0x58(%rdx),%r9d
    124f:	c4 a3 61 22 2c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm3,%xmm5
    1256:	48 8b 41 10          	mov    0x10(%rcx),%rax
    125a:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
    125f:	8b 72 54             	mov    0x54(%rdx),%esi
    1262:	44 8b 6a 40          	mov    0x40(%rdx),%r13d
    1266:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
    126b:	c4 a1 79 6e 1c 88    	vmovd  (%rax,%r9,4),%xmm3
    1271:	44 8b 14 a8          	mov    (%rax,%rbp,4),%r10d
    1275:	c5 d1 6c ea          	vpunpcklqdq %xmm2,%xmm5,%xmm5
    1279:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    1280:	00 
    1281:	44 8b 62 44          	mov    0x44(%rdx),%r12d
    1285:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
    128a:	c4 e3 55 38 e8 01    	vinserti128 $0x1,%xmm0,%ymm5,%ymm5
    1290:	c4 e3 61 22 14 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm3,%xmm2
    1297:	c4 a1 79 6e 1c 80    	vmovd  (%rax,%r8,4),%xmm3
    129d:	c4 e3 61 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm3,%xmm0
    12a4:	4c 89 9c 24 80 00 00 	mov    %r11,0x80(%rsp)
    12ab:	00 
    12ac:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
    12b1:	46 8b 14 a8          	mov    (%rax,%r13,4),%r10d
    12b5:	c4 62 7d 58 51 54    	vpbroadcastd 0x54(%rcx),%ymm10
    12bb:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    12c2:	00 
    12c3:	c5 f9 6c c2          	vpunpcklqdq %xmm2,%xmm0,%xmm0
    12c7:	c4 a3 61 22 14 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm3,%xmm2
    12ce:	c4 62 7d 58 41 50    	vpbroadcastd 0x50(%rcx),%ymm8
    12d4:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    12db:	00 
    12dc:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
    12e1:	c4 a3 61 22 24 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm3,%xmm4
    12e8:	48 8b 41 48          	mov    0x48(%rcx),%rax
    12ec:	c5 d9 6c e2          	vpunpcklqdq %xmm2,%xmm4,%xmm4
    12f0:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    12f5:	c4 e3 5d 38 e0 01    	vinserti128 $0x1,%xmm0,%ymm4,%ymm4
    12fb:	c5 fd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm0
    1300:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1305:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    130a:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
    130f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1313:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1317:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
    131b:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
    1321:	c4 e3 79 16 c5 02    	vpextrd $0x2,%xmm0,%ebp
    1327:	c5 f9 7e c6          	vmovd  %xmm0,%esi
    132b:	c4 c3 79 16 d3 02    	vpextrd $0x2,%xmm2,%r11d
    1331:	c4 c1 79 7e d5       	vmovd  %xmm2,%r13d
    1336:	c4 c3 79 16 d4 01    	vpextrd $0x1,%xmm2,%r12d
    133c:	c5 f9 6e 3c a8       	vmovd  (%rax,%rbp,4),%xmm7
    1341:	c4 a1 79 6e 34 98    	vmovd  (%rax,%r11,4),%xmm6
    1347:	c4 c3 79 16 d2 03    	vpextrd $0x3,%xmm2,%r10d
    134d:	c4 a1 79 6e 14 a8    	vmovd  (%rax,%r13,4),%xmm2
    1353:	c4 e3 79 16 c7 03    	vpextrd $0x3,%xmm0,%edi
    1359:	c4 e3 41 22 3c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm7,%xmm7
    1360:	8b 79 50             	mov    0x50(%rcx),%edi
    1363:	c5 b5 72 d3 0f       	vpsrld $0xf,%ymm3,%ymm9
    1368:	c4 e3 79 16 c3 01    	vpextrd $0x1,%xmm0,%ebx
    136e:	c4 a3 49 22 34 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm6,%xmm6
    1375:	c4 a3 69 22 14 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm2,%xmm2
    137c:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    1381:	44 8b 51 54          	mov    0x54(%rcx),%r10d
    1385:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    138a:	c5 a5 72 d3 1f       	vpsrld $0x1f,%ymm3,%ymm11
    138f:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1394:	c5 e9 6c d6          	vpunpcklqdq %xmm6,%xmm2,%xmm2
    1398:	c5 f9 6e 34 b0       	vmovd  (%rax,%rsi,4),%xmm6
    139d:	c5 e5 72 d3 18       	vpsrld $0x18,%ymm3,%ymm3
    13a2:	c4 62 75 39 ed       	vpminsd %ymm5,%ymm1,%ymm13
    13a7:	45 8d 54 3a 01       	lea    0x1(%r10,%rdi,1),%r10d
    13ac:	c4 62 15 39 e4       	vpminsd %ymm4,%ymm13,%ymm12
    13b1:	c5 15 66 ec          	vpcmpgtd %ymm4,%ymm13,%ymm13
    13b5:	c4 e3 49 22 34 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm6,%xmm6
    13bc:	c4 41 79 6e fa       	vmovd  %r10d,%xmm15
    13c1:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
    13c6:	c5 c9 6c f7          	vpunpcklqdq %xmm7,%xmm6,%xmm6
    13ca:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
    13d1:	00 00 
    13d3:	c4 63 4d 38 f2 01    	vinserti128 $0x1,%xmm2,%ymm6,%ymm14
    13d9:	c4 c1 7d fe d7       	vpaddd %ymm15,%ymm0,%ymm2
    13de:	c4 c1 79 7e d3       	vmovd  %xmm2,%r11d
    13e3:	c4 c3 79 16 d2 01    	vpextrd $0x1,%xmm2,%r10d
    13e9:	c4 e3 79 16 d6 02    	vpextrd $0x2,%xmm2,%esi
    13ef:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    13f6:	00 00 
    13f8:	c4 e3 79 16 d3 03    	vpextrd $0x3,%xmm2,%ebx
    13fe:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    1404:	c5 f9 6e 3c b0       	vmovd  (%rax,%rsi,4),%xmm7
    1409:	c4 c3 79 16 d5 02    	vpextrd $0x2,%xmm2,%r13d
    140f:	c5 f9 7e d5          	vmovd  %xmm2,%ebp
    1413:	c4 e3 79 16 d7 01    	vpextrd $0x1,%xmm2,%edi
    1419:	c4 a1 79 6e 34 a8    	vmovd  (%rax,%r13,4),%xmm6
    141f:	c4 c3 79 16 d4 03    	vpextrd $0x3,%xmm2,%r12d
    1425:	c5 f9 6e 14 a8       	vmovd  (%rax,%rbp,4),%xmm2
    142a:	c4 e3 41 22 3c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm7,%xmm7
    1431:	c4 a3 49 22 34 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm6,%xmm6
    1438:	c4 e3 69 22 14 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm2,%xmm2
    143f:	c5 e9 6c d6          	vpunpcklqdq %xmm6,%xmm2,%xmm2
    1443:	c4 a1 79 6e 34 98    	vmovd  (%rax,%r11,4),%xmm6
    1449:	c4 a3 49 22 34 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm6,%xmm6
    1450:	c5 c9 6c f7          	vpunpcklqdq %xmm7,%xmm6,%xmm6
    1454:	c5 d5 66 f9          	vpcmpgtd %ymm1,%ymm5,%ymm7
    1458:	c4 e3 4d 38 f2 01    	vinserti128 $0x1,%xmm2,%ymm6,%ymm6
    145e:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1465:	00 00 
    1467:	c4 e2 75 3d f5       	vpmaxsd %ymm5,%ymm1,%ymm6
    146c:	c5 dd 66 d6          	vpcmpgtd %ymm6,%ymm4,%ymm2
    1470:	c4 c3 3d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm8,%ymm7
    1476:	c4 e2 4d 3d f4       	vpmaxsd %ymm4,%ymm6,%ymm6
    147b:	c4 c3 45 4c fb 20    	vpblendvb %ymm2,%ymm11,%ymm7,%ymm7
    1481:	c5 f5 66 d5          	vpcmpgtd %ymm5,%ymm1,%ymm2
    1485:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1489:	c5 fd fe ff          	vpaddd %ymm7,%ymm0,%ymm7
    148d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1491:	c4 c1 4d fe e4       	vpaddd %ymm12,%ymm6,%ymm4
    1496:	c4 c3 3d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm8,%ymm2
    149c:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    14a0:	c4 c3 6d 4c d3 d0    	vpblendvb %ymm13,%ymm11,%ymm2,%ymm2
    14a6:	c5 65 db ac 24 a0 00 	vpand  0xa0(%rsp),%ymm3,%ymm13
    14ad:	00 00 
    14af:	c5 fd fa d2          	vpsubd %ymm2,%ymm0,%ymm2
    14b3:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
    14b8:	c4 c1 79 7e d3       	vmovd  %xmm2,%r11d
    14bd:	c4 c3 79 16 d2 01    	vpextrd $0x1,%xmm2,%r10d
    14c3:	c4 e3 79 16 d6 02    	vpextrd $0x2,%xmm2,%esi
    14c9:	c4 e3 79 16 d3 03    	vpextrd $0x3,%xmm2,%ebx
    14cf:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    14d5:	c4 c3 79 16 d5 02    	vpextrd $0x2,%xmm2,%r13d
    14db:	c4 c3 79 16 d4 03    	vpextrd $0x3,%xmm2,%r12d
    14e1:	c5 f9 7e d5          	vmovd  %xmm2,%ebp
    14e5:	c4 21 79 6e 34 a8    	vmovd  (%rax,%r13,4),%xmm14
    14eb:	c4 e3 79 16 d7 01    	vpextrd $0x1,%xmm2,%edi
    14f1:	c4 23 09 22 34 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm14,%xmm14
    14f8:	c5 f9 6e 14 a8       	vmovd  (%rax,%rbp,4),%xmm2
    14fd:	c5 79 6e 3c b0       	vmovd  (%rax,%rsi,4),%xmm15
    1502:	c4 e3 79 16 fe 02    	vpextrd $0x2,%xmm7,%esi
    1508:	c4 e3 69 22 14 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm2,%xmm2
    150f:	c4 63 01 22 3c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm15,%xmm15
    1516:	c4 e3 79 16 fb 03    	vpextrd $0x3,%xmm7,%ebx
    151c:	c4 c1 69 6c d6       	vpunpcklqdq %xmm14,%xmm2,%xmm2
    1521:	c4 21 79 6e 34 98    	vmovd  (%rax,%r11,4),%xmm14
    1527:	c4 c1 79 7e fb       	vmovd  %xmm7,%r11d
    152c:	c4 23 09 22 34 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm14,%xmm14
    1533:	c4 c3 79 16 fa 01    	vpextrd $0x1,%xmm7,%r10d
    1539:	c4 e3 7d 39 ff 01    	vextracti128 $0x1,%ymm7,%xmm7
    153f:	c4 c3 79 16 fd 02    	vpextrd $0x2,%xmm7,%r13d
    1545:	c5 f9 7e fd          	vmovd  %xmm7,%ebp
    1549:	c4 e3 79 16 ff 01    	vpextrd $0x1,%xmm7,%edi
    154f:	c4 41 09 6c f7       	vpunpcklqdq %xmm15,%xmm14,%xmm14
    1554:	c4 c3 79 16 fc 03    	vpextrd $0x3,%xmm7,%r12d
    155a:	c5 f9 6e 3c a8       	vmovd  (%rax,%rbp,4),%xmm7
    155f:	c5 79 6e 3c b0       	vmovd  (%rax,%rsi,4),%xmm15
    1564:	c4 63 0d 38 f2 01    	vinserti128 $0x1,%xmm2,%ymm14,%ymm14
    156a:	c4 a1 79 6e 14 a8    	vmovd  (%rax,%r13,4),%xmm2
    1570:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
    1575:	c4 e3 41 22 3c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm7,%xmm7
    157c:	c4 63 01 22 3c 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm15,%xmm15
    1583:	c5 0d db f3          	vpand  %ymm3,%ymm14,%ymm14
    1587:	c4 a3 69 22 14 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm2,%xmm2
    158e:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
    1593:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
    159a:	00 
    159b:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
    15a2:	00 
    15a3:	c5 c1 6c fa          	vpunpcklqdq %xmm2,%xmm7,%xmm7
    15a7:	c4 a1 79 6e 14 98    	vmovd  (%rax,%r11,4),%xmm2
    15ad:	4c 8b 9c 24 80 00 00 	mov    0x80(%rsp),%r11
    15b4:	00 
    15b5:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
    15bc:	00 
    15bd:	c4 a3 69 22 14 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm2,%xmm2
    15c4:	41 ba 00 80 00 00    	mov    $0x8000,%r10d
    15ca:	c4 c1 69 6c d7       	vpunpcklqdq %xmm15,%xmm2,%xmm2
    15cf:	c4 e3 6d 38 d7 01    	vinserti128 $0x1,%xmm7,%ymm2,%ymm2
    15d5:	c4 c1 45 72 f5 10    	vpslld $0x10,%ymm13,%ymm7
    15db:	c5 ed db d3          	vpand  %ymm3,%ymm2,%ymm2
    15df:	c5 8d fa ca          	vpsubd %ymm2,%ymm14,%ymm1
    15e3:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    15e8:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    15ed:	c4 e2 5d 40 c9       	vpmulld %ymm1,%ymm4,%ymm1
    15f2:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    15f6:	c5 e5 db 94 24 e0 00 	vpand  0xe0(%rsp),%ymm3,%ymm2
    15fd:	00 00 
    15ff:	c4 c1 6d fa d6       	vpsubd %ymm14,%ymm2,%ymm2
    1604:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    1609:	c4 41 79 6e e2       	vmovd  %r10d,%xmm12
    160e:	4c 8b 51 28          	mov    0x28(%rcx),%r10
    1612:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    1617:	c4 c1 45 fe fc       	vpaddd %ymm12,%ymm7,%ymm7
    161c:	41 8b 2c aa          	mov    (%r10,%rbp,4),%ebp
    1620:	c5 ed fe ff          	vpaddd %ymm7,%ymm2,%ymm7
    1624:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1628:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
    162d:	c4 81 79 6e 0c 8a    	vmovd  (%r10,%r9,4),%xmm1
    1633:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
    163a:	00 00 
    163c:	c4 c3 71 22 14 9a 01 	vpinsrd $0x1,(%r10,%rbx,4),%xmm1,%xmm2
    1643:	c4 81 79 6e 0c 82    	vmovd  (%r10,%r8,4),%xmm1
    1649:	c4 c3 71 22 0c b2 01 	vpinsrd $0x1,(%r10,%rsi,4),%xmm1,%xmm1
    1650:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
    1654:	c5 f9 6e d5          	vmovd  %ebp,%xmm2
    1658:	c4 83 69 22 14 9a 01 	vpinsrd $0x1,(%r10,%r11,4),%xmm2,%xmm2
    165f:	47 8b 1c aa          	mov    (%r10,%r13,4),%r11d
    1663:	c4 41 79 6e eb       	vmovd  %r11d,%xmm13
    1668:	c4 83 11 22 2c a2 01 	vpinsrd $0x1,(%r10,%r12,4),%xmm13,%xmm5
    166f:	4c 8b 51 20          	mov    0x20(%rcx),%r10
    1673:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    1678:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
    167d:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
    1682:	c5 d1 6c ea          	vpunpcklqdq %xmm2,%xmm5,%xmm5
    1686:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    168b:	47 8b 1c 9a          	mov    (%r10,%r11,4),%r11d
    168f:	41 8b 3c ba          	mov    (%r10,%rdi,4),%edi
    1693:	c4 e3 55 38 e9 01    	vinserti128 $0x1,%xmm1,%ymm5,%ymm5
    1699:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
    169e:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
    16a3:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    16a8:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
    16ad:	47 8b 1c a2          	mov    (%r10,%r12,4),%r11d
    16b1:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
    16b6:	89 bc 24 20 01 00 00 	mov    %edi,0x120(%rsp)
    16bd:	c4 83 71 22 14 aa 01 	vpinsrd $0x1,(%r10,%r13,4),%xmm1,%xmm2
    16c4:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
    16c9:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
    16ce:	45 8b 1c b2          	mov    (%r10,%rsi,4),%r11d
    16d2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    16d7:	c4 c3 71 22 0c aa 01 	vpinsrd $0x1,(%r10,%rbp,4),%xmm1,%xmm1
    16de:	c5 79 6e ac 24 20 01 	vmovd  0x120(%rsp),%xmm13
    16e5:	00 00 
    16e7:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
    16ec:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
    16f0:	c4 c1 79 6e d3       	vmovd  %r11d,%xmm2
    16f5:	c4 c3 11 22 34 ba 01 	vpinsrd $0x1,(%r10,%rdi,4),%xmm13,%xmm6
    16fc:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    1701:	c4 c3 69 22 14 9a 01 	vpinsrd $0x1,(%r10,%rbx,4),%xmm2,%xmm2
    1708:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    170c:	48 8b 1c 24          	mov    (%rsp),%rbx
    1710:	45 8b 1c b2          	mov    (%r10,%rsi,4),%r11d
    1714:	c5 c9 6c f2          	vpunpcklqdq %xmm2,%xmm6,%xmm6
    1718:	c4 e3 4d 38 f1 01    	vinserti128 $0x1,%xmm1,%ymm6,%ymm6
    171e:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
    1723:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    1728:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    172d:	c4 c3 71 22 14 9a 01 	vpinsrd $0x1,(%r10,%rbx,4),%xmm1,%xmm2
    1734:	43 8b 2c 9a          	mov    (%r10,%r11,4),%ebp
    1738:	c5 f9 6e cd          	vmovd  %ebp,%xmm1
    173c:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
    1741:	c4 c3 71 22 0c ba 01 	vpinsrd $0x1,(%r10,%rdi,4),%xmm1,%xmm1
    1748:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
    174c:	c4 81 79 6e 14 b2    	vmovd  (%r10,%r14,4),%xmm2
    1752:	c4 c3 69 22 24 aa 01 	vpinsrd $0x1,(%r10,%rbp,4),%xmm2,%xmm4
    1759:	c4 81 79 6e 14 ba    	vmovd  (%r10,%r15,4),%xmm2
    175f:	c4 83 69 22 14 a2 01 	vpinsrd $0x1,(%r10,%r12,4),%xmm2,%xmm2
    1766:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    176d:	00 00 
    176f:	c5 e9 6c d4          	vpunpcklqdq %xmm4,%xmm2,%xmm2
    1773:	c4 e3 6d 38 d1 01    	vinserti128 $0x1,%xmm1,%ymm2,%ymm2
    1779:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    177e:	c4 e2 6d 3d e6       	vpmaxsd %ymm6,%ymm2,%ymm4
    1783:	c5 cd 66 ca          	vpcmpgtd %ymm2,%ymm6,%ymm1
    1787:	c5 d5 66 fc          	vpcmpgtd %ymm4,%ymm5,%ymm7
    178b:	c4 62 5d 3d ed       	vpmaxsd %ymm5,%ymm4,%ymm13
    1790:	c5 ed 66 e6          	vpcmpgtd %ymm6,%ymm2,%ymm4
    1794:	c5 7e 7f ac 24 20 01 	vmovdqu %ymm13,0x120(%rsp)
    179b:	00 00 
    179d:	c4 c1 15 72 d6 08    	vpsrld $0x8,%ymm14,%ymm13
    17a3:	c4 c3 3d 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm8,%ymm1
    17a9:	c5 15 db eb          	vpand  %ymm3,%ymm13,%ymm13
    17ad:	c4 c3 75 4c cb 70    	vpblendvb %ymm7,%ymm11,%ymm1,%ymm1
    17b3:	c4 e2 6d 39 fe       	vpminsd %ymm6,%ymm2,%ymm7
    17b8:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    17bc:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
    17c3:	00 00 
    17c5:	c5 fd fe c9          	vpaddd %ymm1,%ymm0,%ymm1
    17c9:	c4 62 45 39 fd       	vpminsd %ymm5,%ymm7,%ymm15
    17ce:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    17d2:	c4 c1 79 7e cb       	vmovd  %xmm1,%r11d
    17d7:	c4 c3 79 16 ca 01    	vpextrd $0x1,%xmm1,%r10d
    17dd:	c4 e3 79 16 ce 02    	vpextrd $0x2,%xmm1,%esi
    17e3:	c4 e3 79 16 cb 03    	vpextrd $0x3,%xmm1,%ebx
    17e9:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    17ef:	c4 c3 3d 4c e2 40    	vpblendvb %ymm4,%ymm10,%ymm8,%ymm4
    17f5:	c5 79 6e 34 b0       	vmovd  (%rax,%rsi,4),%xmm14
    17fa:	c5 f9 7e cd          	vmovd  %xmm1,%ebp
    17fe:	c4 c3 79 16 cd 02    	vpextrd $0x2,%xmm1,%r13d
    1804:	c4 c3 5d 4c e3 70    	vpblendvb %ymm7,%ymm11,%ymm4,%ymm4
    180a:	c4 e3 79 16 cf 01    	vpextrd $0x1,%xmm1,%edi
    1810:	c5 f9 6e 3c a8       	vmovd  (%rax,%rbp,4),%xmm7
    1815:	c4 c3 79 16 cc 03    	vpextrd $0x3,%xmm1,%r12d
    181b:	c4 a1 79 6e 0c a8    	vmovd  (%rax,%r13,4),%xmm1
    1821:	c5 fd fa e4          	vpsubd %ymm4,%ymm0,%ymm4
    1825:	c4 63 09 22 34 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm14,%xmm14
    182c:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1830:	c4 a3 71 22 0c a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm1,%xmm1
    1837:	c4 e3 41 22 3c b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm7,%xmm7
    183e:	c5 85 fe ee          	vpaddd %ymm6,%ymm15,%ymm5
    1842:	c5 dd fe a4 24 c0 00 	vpaddd 0xc0(%rsp),%ymm4,%ymm4
    1849:	00 00 
    184b:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    184f:	c5 c1 6c f9          	vpunpcklqdq %xmm1,%xmm7,%xmm7
    1853:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
    1859:	c4 e3 79 16 e6 02    	vpextrd $0x2,%xmm4,%esi
    185f:	c4 c1 79 7e e3       	vmovd  %xmm4,%r11d
    1864:	c4 e3 79 16 e3 03    	vpextrd $0x3,%xmm4,%ebx
    186a:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
    1871:	c4 c3 79 16 e2 01    	vpextrd $0x1,%xmm4,%r10d
    1877:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    187d:	c4 c3 79 16 e5 02    	vpextrd $0x2,%xmm4,%r13d
    1883:	c5 f9 7e e5          	vmovd  %xmm4,%ebp
    1887:	c4 e3 79 16 e7 01    	vpextrd $0x1,%xmm4,%edi
    188d:	c4 c1 71 6c ce       	vpunpcklqdq %xmm14,%xmm1,%xmm1
    1892:	c4 c3 79 16 e4 03    	vpextrd $0x3,%xmm4,%r12d
    1898:	c5 f9 6e 24 a8       	vmovd  (%rax,%rbp,4),%xmm4
    189d:	c5 79 6e 34 b0       	vmovd  (%rax,%rsi,4),%xmm14
    18a2:	c4 e3 75 38 cf 01    	vinserti128 $0x1,%xmm7,%ymm1,%ymm1
    18a8:	c4 a1 79 6e 3c a8    	vmovd  (%rax,%r13,4),%xmm7
    18ae:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
    18b3:	c4 e3 59 22 24 b8 01 	vpinsrd $0x1,(%rax,%rdi,4),%xmm4,%xmm4
    18ba:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
    18bf:	c4 63 09 22 34 98 01 	vpinsrd $0x1,(%rax,%rbx,4),%xmm14,%xmm14
    18c6:	c4 a3 41 22 3c a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm7,%xmm7
    18cd:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
    18d1:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
    18d6:	c5 d9 6c e7          	vpunpcklqdq %xmm7,%xmm4,%xmm4
    18da:	c4 a1 79 6e 3c 98    	vmovd  (%rax,%r11,4),%xmm7
    18e0:	c4 a3 41 22 3c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm7,%xmm7
    18e7:	4c 8b 51 40          	mov    0x40(%rcx),%r10
    18eb:	c4 c1 41 6c fe       	vpunpcklqdq %xmm14,%xmm7,%xmm7
    18f0:	c4 c1 0d 72 f5 10    	vpslld $0x10,%ymm13,%ymm14
    18f6:	c4 e3 45 38 fc 01    	vinserti128 $0x1,%xmm4,%ymm7,%ymm7
    18fc:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    1903:	00 00 
    1905:	c4 41 0d fe f4       	vpaddd %ymm12,%ymm14,%ymm14
    190a:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
    190f:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    1914:	c5 c5 db fb          	vpand  %ymm3,%ymm7,%ymm7
    1918:	c5 dd db e3          	vpand  %ymm3,%ymm4,%ymm4
    191c:	c5 c5 fa d1          	vpsubd %ymm1,%ymm7,%ymm2
    1920:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    1925:	c4 e2 55 40 d2       	vpmulld %ymm2,%ymm5,%ymm2
    192a:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    192f:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    1933:	c4 c2 5d 40 e7       	vpmulld %ymm15,%ymm4,%ymm4
    1938:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    193d:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    1941:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1945:	c4 81 79 6e 0c 82    	vmovd  (%r10,%r8,4),%xmm1
    194b:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
    1952:	00 
    1953:	c5 ed 72 d4 10       	vpsrld $0x10,%ymm4,%ymm2
    1958:	c4 81 79 6e 24 8a    	vmovd  (%r10,%r9,4),%xmm4
    195e:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
    1965:	00 
    1966:	c4 c3 71 22 0c b2 01 	vpinsrd $0x1,(%r10,%rsi,4),%xmm1,%xmm1
    196d:	c4 c3 59 22 24 9a 01 	vpinsrd $0x1,(%r10,%rbx,4),%xmm4,%xmm4
    1974:	c5 f1 6c cc          	vpunpcklqdq %xmm4,%xmm1,%xmm1
    1978:	c4 81 79 6e 24 82    	vmovd  (%r10,%r8,4),%xmm4
    197e:	c4 83 59 22 24 8a 01 	vpinsrd $0x1,(%r10,%r9,4),%xmm4,%xmm4
    1985:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
    198c:	00 
    198d:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
    1994:	00 
    1995:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    199a:	c4 81 79 6e 2c 82    	vmovd  (%r10,%r8,4),%xmm5
    19a0:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
    19a5:	4c 8b 41 38          	mov    0x38(%rcx),%r8
    19a9:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
    19ae:	c4 83 51 22 2c 8a 01 	vpinsrd $0x1,(%r10,%r9,4),%xmm5,%xmm5
    19b5:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
    19ba:	48 8b 49 30          	mov    0x30(%rcx),%rcx
    19be:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    19c3:	c5 d1 6c ec          	vpunpcklqdq %xmm4,%xmm5,%xmm5
    19c7:	c4 81 79 6e 24 98    	vmovd  (%r8,%r11,4),%xmm4
    19cd:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
    19d2:	c4 e3 55 38 e9 01    	vinserti128 $0x1,%xmm1,%ymm5,%ymm5
    19d8:	c4 81 79 6e 0c a0    	vmovd  (%r8,%r12,4),%xmm1
    19de:	48 8b 1c 24          	mov    (%rsp),%rbx
    19e2:	c4 83 59 22 24 a8 01 	vpinsrd $0x1,(%r8,%r13,4),%xmm4,%xmm4
    19e9:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    19ee:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    19f3:	c4 c3 71 22 0c a8 01 	vpinsrd $0x1,(%r8,%rbp,4),%xmm1,%xmm1
    19fa:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    19ff:	c4 a1 79 6e 3c b1    	vmovd  (%rcx,%r14,4),%xmm7
    1a05:	c5 f1 6c cc          	vpunpcklqdq %xmm4,%xmm1,%xmm1
    1a09:	c4 81 79 6e 24 a8    	vmovd  (%r8,%r13,4),%xmm4
    1a0f:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
    1a14:	c4 83 59 22 24 a8 01 	vpinsrd $0x1,(%r8,%r13,4),%xmm4,%xmm4
    1a1b:	4c 8b 6c 24 68       	mov    0x68(%rsp),%r13
    1a20:	c4 81 79 6e 34 a8    	vmovd  (%r8,%r13,4),%xmm6
    1a26:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
    1a2b:	c4 83 49 22 34 a8 01 	vpinsrd $0x1,(%r8,%r13,4),%xmm6,%xmm6
    1a32:	c5 c9 6c f4          	vpunpcklqdq %xmm4,%xmm6,%xmm6
    1a36:	c4 a1 79 6e 24 89    	vmovd  (%rcx,%r9,4),%xmm4
    1a3c:	c4 e3 4d 38 f1 01    	vinserti128 $0x1,%xmm1,%ymm6,%ymm6
    1a42:	c5 f9 6e 0c b1       	vmovd  (%rcx,%rsi,4),%xmm1
    1a47:	c4 e3 59 22 24 b9 01 	vpinsrd $0x1,(%rcx,%rdi,4),%xmm4,%xmm4
    1a4e:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    1a53:	c4 e3 71 22 0c 99 01 	vpinsrd $0x1,(%rcx,%rbx,4),%xmm1,%xmm1
    1a5a:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    1a5f:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
    1a64:	c5 d9 6c e1          	vpunpcklqdq %xmm1,%xmm4,%xmm4
    1a68:	c4 a1 79 6e 0c b9    	vmovd  (%rcx,%r15,4),%xmm1
    1a6e:	c4 a3 41 22 3c 81 01 	vpinsrd $0x1,(%rcx,%r8,4),%xmm7,%xmm7
    1a75:	c4 a3 71 22 0c 91 01 	vpinsrd $0x1,(%rcx,%r10,4),%xmm1,%xmm1
    1a7c:	c5 f1 6c cf          	vpunpcklqdq %xmm7,%xmm1,%xmm1
    1a80:	c4 e3 75 38 cc 01    	vinserti128 $0x1,%xmm4,%ymm1,%ymm1
    1a86:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1a8b:	c5 cd 66 e1          	vpcmpgtd %ymm1,%ymm6,%ymm4
    1a8f:	c5 75 66 f6          	vpcmpgtd %ymm6,%ymm1,%ymm14
    1a93:	c4 e2 75 3d fe       	vpmaxsd %ymm6,%ymm1,%ymm7
    1a98:	c5 55 66 cf          	vpcmpgtd %ymm7,%ymm5,%ymm9
    1a9c:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    1aa1:	c4 c3 3d 4c e2 40    	vpblendvb %ymm4,%ymm10,%ymm8,%ymm4
    1aa7:	c4 43 3d 4c c2 e0    	vpblendvb %ymm14,%ymm10,%ymm8,%ymm8
    1aad:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    1ab4:	00 00 
    1ab6:	c4 c3 5d 4c e3 90    	vpblendvb %ymm9,%ymm11,%ymm4,%ymm4
    1abc:	c4 62 75 39 ce       	vpminsd %ymm6,%ymm1,%ymm9
    1ac1:	c4 62 35 39 ed       	vpminsd %ymm5,%ymm9,%ymm13
    1ac6:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    1aca:	c5 fd fe e4          	vpaddd %ymm4,%ymm0,%ymm4
    1ace:	c4 c1 79 7e e0       	vmovd  %xmm4,%r8d
    1ad3:	c4 e3 79 16 e1 01    	vpextrd $0x1,%xmm4,%ecx
    1ad9:	c4 c3 79 16 e2 02    	vpextrd $0x2,%xmm4,%r10d
    1adf:	c4 c3 79 16 e1 03    	vpextrd $0x3,%xmm4,%r9d
    1ae5:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    1aeb:	c4 21 79 6e 14 90    	vmovd  (%rax,%r10,4),%xmm10
    1af1:	c4 43 3d 4c c3 90    	vpblendvb %ymm9,%ymm11,%ymm8,%ymm8
    1af7:	c5 f9 7e e3          	vmovd  %xmm4,%ebx
    1afb:	c4 e3 79 16 e7 02    	vpextrd $0x2,%xmm4,%edi
    1b01:	c4 c3 79 16 e3 01    	vpextrd $0x1,%xmm4,%r11d
    1b07:	c4 e3 79 16 e6 03    	vpextrd $0x3,%xmm4,%esi
    1b0d:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
    1b12:	c5 f9 6e 24 b8       	vmovd  (%rax,%rdi,4),%xmm4
    1b17:	c5 79 6e 04 98       	vmovd  (%rax,%rbx,4),%xmm8
    1b1c:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
    1b23:	00 00 
    1b25:	c4 c1 35 72 d6 10    	vpsrld $0x10,%ymm14,%ymm9
    1b2b:	c4 e3 59 22 24 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm4,%xmm4
    1b32:	c4 23 29 22 14 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm10,%xmm10
    1b39:	c5 35 db cb          	vpand  %ymm3,%ymm9,%ymm9
    1b3d:	c4 23 39 22 04 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm8,%xmm8
    1b44:	c4 c3 79 16 c2 02    	vpextrd $0x2,%xmm0,%r10d
    1b4a:	c4 c3 79 16 c1 03    	vpextrd $0x3,%xmm0,%r9d
    1b50:	c5 39 6c c4          	vpunpcklqdq %xmm4,%xmm8,%xmm8
    1b54:	c4 a1 79 6e 24 80    	vmovd  (%rax,%r8,4),%xmm4
    1b5a:	c4 c1 79 7e c0       	vmovd  %xmm0,%r8d
    1b5f:	c4 e3 59 22 24 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm4,%xmm4
    1b66:	c4 e3 79 16 c1 01    	vpextrd $0x1,%xmm0,%ecx
    1b6c:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1b72:	c4 e3 79 16 c7 02    	vpextrd $0x2,%xmm0,%edi
    1b78:	c5 f9 7e c3          	vmovd  %xmm0,%ebx
    1b7c:	c4 c3 79 16 c3 01    	vpextrd $0x1,%xmm0,%r11d
    1b82:	c4 c1 59 6c e2       	vpunpcklqdq %xmm10,%xmm4,%xmm4
    1b87:	c4 e3 79 16 c6 03    	vpextrd $0x3,%xmm0,%esi
    1b8d:	c5 f9 6e 04 98       	vmovd  (%rax,%rbx,4),%xmm0
    1b92:	c4 21 79 6e 14 90    	vmovd  (%rax,%r10,4),%xmm10
    1b98:	c4 c3 5d 38 e0 01    	vinserti128 $0x1,%xmm8,%ymm4,%ymm4
    1b9e:	c5 79 6e 04 b8       	vmovd  (%rax,%rdi,4),%xmm8
    1ba3:	c4 a3 79 22 04 98 01 	vpinsrd $0x1,(%rax,%r11,4),%xmm0,%xmm0
    1baa:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1baf:	c4 23 29 22 14 88 01 	vpinsrd $0x1,(%rax,%r9,4),%xmm10,%xmm10
    1bb6:	c4 63 39 22 04 b0 01 	vpinsrd $0x1,(%rax,%rsi,4),%xmm8,%xmm8
    1bbd:	c5 dd db e3          	vpand  %ymm3,%ymm4,%ymm4
    1bc1:	c4 c1 79 6c c0       	vpunpcklqdq %xmm8,%xmm0,%xmm0
    1bc6:	c4 21 79 6e 04 80    	vmovd  (%rax,%r8,4),%xmm8
    1bcc:	c4 63 39 22 04 88 01 	vpinsrd $0x1,(%rax,%rcx,4),%xmm8,%xmm8
    1bd3:	c5 fd 7f 52 20       	vmovdqa %ymm2,0x20(%rdx)
    1bd8:	c4 41 39 6c c2       	vpunpcklqdq %xmm10,%xmm8,%xmm8
    1bdd:	c4 c1 2d 72 f1 10    	vpslld $0x10,%ymm9,%ymm10
    1be3:	c4 63 3d 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm8,%ymm8
    1be9:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
    1bf0:	00 00 
    1bf2:	c4 41 2d fe d4       	vpaddd %ymm12,%ymm10,%ymm10
    1bf7:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1bfd:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
    1c02:	c5 f5 fe c6          	vpaddd %ymm6,%ymm1,%ymm0
    1c06:	c5 3d db c3          	vpand  %ymm3,%ymm8,%ymm8
    1c0a:	c4 c1 45 fe cd       	vpaddd %ymm13,%ymm7,%ymm1
    1c0f:	c5 25 db db          	vpand  %ymm3,%ymm11,%ymm11
    1c13:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1c17:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
    1c1e:	00 00 
    1c20:	c4 41 25 fa d8       	vpsubd %ymm8,%ymm11,%ymm11
    1c25:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1c29:	c5 bd fa cc          	vpsubd %ymm4,%ymm8,%ymm1
    1c2d:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    1c32:	c4 42 25 40 dd       	vpmulld %ymm13,%ymm11,%ymm11
    1c37:	c5 fd 7f 2a          	vmovdqa %ymm5,(%rdx)
    1c3b:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    1c40:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1c45:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
    1c4a:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    1c4f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1c53:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1c58:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
    1c5d:	c5 f8 77             	vzeroupper
    1c60:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
    1c67:	00 00 
    1c69:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
    1c70:	00 00 
    1c72:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
    1c79:	00 00 
    1c7b:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
    1c82:	00 00 
    1c84:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
    1c8b:	00 00 
    1c8d:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
    1c94:	00 00 
    1c96:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
    1c9d:	00 00 
    1c9f:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
    1ca6:	00 00 
    1ca8:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
    1caf:	00 00 
    1cb1:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
    1cb8:	00 00 
    1cba:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    1cc1:	5b                   	pop    %rbx
    1cc2:	5e                   	pop    %rsi
    1cc3:	5f                   	pop    %rdi
    1cc4:	5d                   	pop    %rbp
    1cc5:	41 5c                	pop    %r12
    1cc7:	41 5d                	pop    %r13
    1cc9:	41 5e                	pop    %r14
    1ccb:	41 5f                	pop    %r15
    1ccd:	c3                   	ret
    1cce:	66 90                	xchg   %ax,%ax

0000000000001cd0 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    1cd0:	41 57                	push   %r15
    1cd2:	41 56                	push   %r14
    1cd4:	41 55                	push   %r13
    1cd6:	41 54                	push   %r12
    1cd8:	55                   	push   %rbp
    1cd9:	57                   	push   %rdi
    1cda:	56                   	push   %rsi
    1cdb:	53                   	push   %rbx
    1cdc:	48 81 ec 78 02 00 00 	sub    $0x278,%rsp
    1ce3:	c5 f8 29 b4 24 d0 01 	vmovaps %xmm6,0x1d0(%rsp)
    1cea:	00 00 
    1cec:	c5 f8 29 bc 24 e0 01 	vmovaps %xmm7,0x1e0(%rsp)
    1cf3:	00 00 
    1cf5:	c5 78 29 84 24 f0 01 	vmovaps %xmm8,0x1f0(%rsp)
    1cfc:	00 00 
    1cfe:	c5 78 29 8c 24 00 02 	vmovaps %xmm9,0x200(%rsp)
    1d05:	00 00 
    1d07:	c5 78 29 94 24 10 02 	vmovaps %xmm10,0x210(%rsp)
    1d0e:	00 00 
    1d10:	c5 78 29 9c 24 20 02 	vmovaps %xmm11,0x220(%rsp)
    1d17:	00 00 
    1d19:	c5 78 29 a4 24 30 02 	vmovaps %xmm12,0x230(%rsp)
    1d20:	00 00 
    1d22:	c5 78 29 ac 24 40 02 	vmovaps %xmm13,0x240(%rsp)
    1d29:	00 00 
    1d2b:	c5 78 29 b4 24 50 02 	vmovaps %xmm14,0x250(%rsp)
    1d32:	00 00 
    1d34:	c5 78 29 bc 24 60 02 	vmovaps %xmm15,0x260(%rsp)
    1d3b:	00 00 
    1d3d:	48 8d b4 24 bf 00 00 	lea    0xbf(%rsp),%rsi
    1d44:	00 
    1d45:	49 89 cf             	mov    %rcx,%r15
    1d48:	48 89 d5             	mov    %rdx,%rbp
    1d4b:	48 83 e6 e0          	and    $0xffffffffffffffe0,%rsi
    1d4f:	48 83 fa 04          	cmp    $0x4,%rdx
    1d53:	0f 84 ef 06 00 00    	je     2448 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x778>
    1d59:	4d 85 c9             	test   %r9,%r9
    1d5c:	0f 84 51 08 00 00    	je     25b3 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e3>
    1d62:	4d 8d 71 ff          	lea    -0x1(%r9),%r14
    1d66:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 1dce <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfe>
    1d6d:	00 
    1d6e:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 1df6 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x126>
    1d75:	00 
    1d76:	4c 89 bc 24 c0 02 00 	mov    %r15,0x2c0(%rsp)
    1d7d:	00 
    1d7e:	49 c1 ee 03          	shr    $0x3,%r14
    1d82:	4d 89 c4             	mov    %r8,%r12
    1d85:	45 31 ed             	xor    %r13d,%r13d
    1d88:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
    1d8f:	00 
    1d90:	c5 fe 7f 74 24 50    	vmovdqu %ymm6,0x50(%rsp)
    1d96:	c5 fe 7f 7c 24 70    	vmovdqu %ymm7,0x70(%rsp)
    1d9c:	0f 1f 40 00          	nopl   0x0(%rax)
    1da0:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
    1da6:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
    1dad:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    1db1:	c5 ed 72 d7 18       	vpsrld $0x18,%ymm7,%ymm2
    1db6:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1dbc:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1dc2:	c4 e2 7d 00 44 24 50 	vpshufb 0x50(%rsp),%ymm0,%ymm0
    1dc9:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1dce:	c5 fd db da          	vpand  %ymm2,%ymm0,%ymm3
    1dd2:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
    1dd6:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    1ddb:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
    1ddf:	48 85 ed             	test   %rbp,%rbp
    1de2:	0f 84 bd 00 00 00    	je     1ea5 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d5>
    1de8:	48 8d 86 c0 00 00 00 	lea    0xc0(%rsi),%rax
    1def:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
    1df4:	48 8b 9c 24 c0 02 00 	mov    0x2c0(%rsp),%rbx
    1dfb:	00 
    1dfc:	31 ff                	xor    %edi,%edi
    1dfe:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    1e03:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    1e0a:	00 
    1e0b:	eb 2f                	jmp    1e3c <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16c>
    1e0d:	0f 1f 00             	nopl   (%rax)
    1e10:	c5 f8 77             	vzeroupper
    1e13:	e8 78 e7 ff ff       	call   590 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    1e18:	c5 fd 6f 9e c0 00 00 	vmovdqa 0xc0(%rsi),%ymm3
    1e1f:	00 
    1e20:	c5 fd 6f 8e e0 00 00 	vmovdqa 0xe0(%rsi),%ymm1
    1e27:	00 
    1e28:	c5 fd 6f 86 00 01 00 	vmovdqa 0x100(%rsi),%ymm0
    1e2f:	00 
    1e30:	48 ff c7             	inc    %rdi
    1e33:	48 83 c3 60          	add    $0x60,%rbx
    1e37:	48 39 fd             	cmp    %rdi,%rbp
    1e3a:	74 5c                	je     1e98 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c8>
    1e3c:	80 7b 58 00          	cmpb   $0x0,0x58(%rbx)
    1e40:	0f 85 ba 00 00 00    	jne    1f00 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x230>
    1e46:	80 7b 59 00          	cmpb   $0x0,0x59(%rbx)
    1e4a:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    1e4f:	c5 fd 7f 9e c0 00 00 	vmovdqa %ymm3,0xc0(%rsi)
    1e56:	00 
    1e57:	48 89 d9             	mov    %rbx,%rcx
    1e5a:	c5 fd 7f 8e e0 00 00 	vmovdqa %ymm1,0xe0(%rsi)
    1e61:	00 
    1e62:	c5 fd 7f 86 00 01 00 	vmovdqa %ymm0,0x100(%rsi)
    1e69:	00 
    1e6a:	75 a4                	jne    1e10 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
    1e6c:	c5 f8 77             	vzeroupper
    1e6f:	e8 5c f2 ff ff       	call   10d0 <void jshc_scalar_gather::(anonymous namespace)::transform<false, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    1e74:	48 ff c7             	inc    %rdi
    1e77:	c5 fd 6f 9e c0 00 00 	vmovdqa 0xc0(%rsi),%ymm3
    1e7e:	00 
    1e7f:	c5 fd 6f 8e e0 00 00 	vmovdqa 0xe0(%rsi),%ymm1
    1e86:	00 
    1e87:	c5 fd 6f 86 00 01 00 	vmovdqa 0x100(%rsi),%ymm0
    1e8e:	00 
    1e8f:	48 83 c3 60          	add    $0x60,%rbx
    1e93:	48 39 fd             	cmp    %rdi,%rbp
    1e96:	75 a4                	jne    1e3c <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16c>
    1e98:	4c 8b 6c 24 48       	mov    0x48(%rsp),%r13
    1e9d:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
    1ea4:	00 
    1ea5:	c5 ed 72 f0 10       	vpslld $0x10,%ymm0,%ymm2
    1eaa:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    1eaf:	49 83 c4 18          	add    $0x18,%r12
    1eb3:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1eb7:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    1ebb:	c4 e2 7d 00 44 24 70 	vpshufb 0x70(%rsp),%ymm0,%ymm0
    1ec2:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1ec6:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1ecc:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1ed1:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1ed6:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1eda:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    1ee1:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
    1ee8:	4c 3b ac 24 98 00 00 	cmp    0x98(%rsp),%r13
    1eef:	00 
    1ef0:	0f 84 ba 06 00 00    	je     25b0 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e0>
    1ef6:	49 ff c5             	inc    %r13
    1ef9:	e9 a2 fe ff ff       	jmp    1da0 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd0>
    1efe:	66 90                	xchg   %ax,%ax
    1f00:	48 8b 03             	mov    (%rbx),%rax
    1f03:	c5 f9 7e d9          	vmovd  %xmm3,%ecx
    1f07:	c4 e3 79 16 da 01    	vpextrd $0x1,%xmm3,%edx
    1f0d:	c4 c3 79 16 d9 02    	vpextrd $0x2,%xmm3,%r9d
    1f13:	c4 c3 79 16 d8 03    	vpextrd $0x3,%xmm3,%r8d
    1f19:	c4 e3 7d 39 db 01    	vextracti128 $0x1,%ymm3,%xmm3
    1f1f:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    1f23:	c4 c3 79 16 dd 02    	vpextrd $0x2,%xmm3,%r13d
    1f29:	c4 c1 79 7e db       	vmovd  %xmm3,%r11d
    1f2e:	c4 c3 79 16 da 01    	vpextrd $0x1,%xmm3,%r10d
    1f34:	c4 a1 79 6e 24 88    	vmovd  (%rax,%r9,4),%xmm4
    1f3a:	c4 a1 79 6e 14 a8    	vmovd  (%rax,%r13,4),%xmm2
    1f40:	c4 c3 79 16 dc 03    	vpextrd $0x3,%xmm3,%r12d
    1f46:	c4 a1 79 6e 1c 98    	vmovd  (%rax,%r11,4),%xmm3
    1f4c:	c4 c3 79 16 c9 02    	vpextrd $0x2,%xmm1,%r9d
    1f52:	c4 a3 59 22 24 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm4,%xmm4
    1f59:	c5 c5 72 d7 1f       	vpsrld $0x1f,%ymm7,%ymm7
    1f5e:	c4 c3 79 16 c8 03    	vpextrd $0x3,%xmm1,%r8d
    1f64:	c4 a3 69 22 14 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm2,%xmm2
    1f6b:	c4 a3 61 22 1c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm3,%xmm3
    1f72:	c5 e1 6c da          	vpunpcklqdq %xmm2,%xmm3,%xmm3
    1f76:	c5 f9 6e 14 88       	vmovd  (%rax,%rcx,4),%xmm2
    1f7b:	c5 f9 7e c9          	vmovd  %xmm1,%ecx
    1f7f:	c4 e3 69 22 14 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm2,%xmm2
    1f86:	48 8b 43 08          	mov    0x8(%rbx),%rax
    1f8a:	c4 e3 79 16 ca 01    	vpextrd $0x1,%xmm1,%edx
    1f90:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    1f96:	c4 c3 79 16 cd 02    	vpextrd $0x2,%xmm1,%r13d
    1f9c:	c4 c1 79 7e cb       	vmovd  %xmm1,%r11d
    1fa1:	c4 c3 79 16 ca 01    	vpextrd $0x1,%xmm1,%r10d
    1fa7:	c5 e9 6c d4          	vpunpcklqdq %xmm4,%xmm2,%xmm2
    1fab:	c4 c3 79 16 cc 03    	vpextrd $0x3,%xmm1,%r12d
    1fb1:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
    1fb7:	c4 a1 79 6e 24 88    	vmovd  (%rax,%r9,4),%xmm4
    1fbd:	c4 e3 6d 38 d3 01    	vinserti128 $0x1,%xmm3,%ymm2,%ymm2
    1fc3:	c4 a1 79 6e 1c a8    	vmovd  (%rax,%r13,4),%xmm3
    1fc9:	c4 c3 79 16 c1 02    	vpextrd $0x2,%xmm0,%r9d
    1fcf:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
    1fd6:	c4 a3 59 22 24 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm4,%xmm4
    1fdd:	c4 c3 79 16 c0 03    	vpextrd $0x3,%xmm0,%r8d
    1fe3:	c4 a3 61 22 1c a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm3,%xmm3
    1fea:	c5 f1 6c cb          	vpunpcklqdq %xmm3,%xmm1,%xmm1
    1fee:	c5 f9 6e 1c 88       	vmovd  (%rax,%rcx,4),%xmm3
    1ff3:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
    1ff7:	c4 e3 61 22 1c 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm3,%xmm3
    1ffe:	48 8b 43 10          	mov    0x10(%rbx),%rax
    2002:	c4 e3 79 16 c2 01    	vpextrd $0x1,%xmm0,%edx
    2008:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    200e:	c4 c3 79 16 c5 02    	vpextrd $0x2,%xmm0,%r13d
    2014:	c4 c1 79 7e c3       	vmovd  %xmm0,%r11d
    2019:	c4 c3 79 16 c2 01    	vpextrd $0x1,%xmm0,%r10d
    201f:	c5 e1 6c dc          	vpunpcklqdq %xmm4,%xmm3,%xmm3
    2023:	c4 c3 79 16 c4 03    	vpextrd $0x3,%xmm0,%r12d
    2029:	c4 a1 79 6e 04 98    	vmovd  (%rax,%r11,4),%xmm0
    202f:	c5 79 6e 0c 88       	vmovd  (%rax,%rcx,4),%xmm9
    2034:	c4 e3 65 38 d9 01    	vinserti128 $0x1,%xmm1,%ymm3,%ymm3
    203a:	c4 a1 79 6e 0c a8    	vmovd  (%rax,%r13,4),%xmm1
    2040:	8b 4b 54             	mov    0x54(%rbx),%ecx
    2043:	c4 a3 79 22 04 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm0,%xmm0
    204a:	c4 63 31 22 0c 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm9,%xmm9
    2051:	c4 a3 71 22 0c a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm1,%xmm1
    2058:	8b 53 50             	mov    0x50(%rbx),%edx
    205b:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    205f:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    2064:	c5 f9 6c c1          	vpunpcklqdq %xmm1,%xmm0,%xmm0
    2068:	c4 a1 79 6e 0c 88    	vmovd  (%rax,%r9,4),%xmm1
    206e:	c5 79 6e d2          	vmovd  %edx,%xmm10
    2072:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2076:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    207b:	c5 79 6e da          	vmovd  %edx,%xmm11
    207f:	c4 a3 71 22 0c 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm1,%xmm1
    2086:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    208b:	c5 31 6c c9          	vpunpcklqdq %xmm1,%xmm9,%xmm9
    208f:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    2094:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 20bc <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ec>
    209b:	00 
    209c:	c4 63 35 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm9,%ymm9
    20a2:	c5 fd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm0
    20a7:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 20cf <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ff>
    20ae:	00 
    20af:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    20b4:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    20b9:	c4 c1 5d 72 d1 11    	vpsrld $0x11,%ymm9,%ymm4
    20bf:	c5 35 db 0d 20 00 00 	vpand  0x20(%rip),%ymm9,%ymm9        # 20e7 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x417>
    20c6:	00 
    20c7:	48 8b 43 48          	mov    0x48(%rbx),%rax
    20cb:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    20d1:	c4 62 6d 39 e3       	vpminsd %ymm3,%ymm2,%ymm12
    20d6:	c4 c2 1d 39 f9       	vpminsd %ymm9,%ymm12,%ymm7
    20db:	c4 41 1d 66 e1       	vpcmpgtd %ymm9,%ymm12,%ymm12
    20e0:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    20e4:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    20e8:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
    20ee:	c4 c1 79 7e c9       	vmovd  %xmm1,%r9d
    20f3:	c4 c3 79 16 cb 02    	vpextrd $0x2,%xmm1,%r11d
    20f9:	c4 c1 79 7e c5       	vmovd  %xmm0,%r13d
    20fe:	c4 c3 79 16 c7 02    	vpextrd $0x2,%xmm0,%r15d
    2104:	c4 c3 79 16 c4 01    	vpextrd $0x1,%xmm0,%r12d
    210a:	c4 21 79 6e 04 88    	vmovd  (%rax,%r9,4),%xmm8
    2110:	c4 a1 79 6e 24 b8    	vmovd  (%rax,%r15,4),%xmm4
    2116:	c4 c3 79 16 c6 03    	vpextrd $0x3,%xmm0,%r14d
    211c:	c4 a1 79 6e 04 a8    	vmovd  (%rax,%r13,4),%xmm0
    2122:	c4 c3 79 16 c8 01    	vpextrd $0x1,%xmm1,%r8d
    2128:	c4 c3 79 16 ca 03    	vpextrd $0x3,%xmm1,%r10d
    212e:	c4 23 39 22 04 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm8,%xmm8
    2135:	c4 a3 59 22 24 b0 01 	vpinsrd $0x1,(%rax,%r14,4),%xmm4,%xmm4
    213c:	c4 a3 79 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm0,%xmm0
    2143:	c5 f9 6c c4          	vpunpcklqdq %xmm4,%xmm0,%xmm0
    2147:	c4 a1 79 6e 24 98    	vmovd  (%rax,%r11,4),%xmm4
    214d:	c4 a3 59 22 24 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm4,%xmm4
    2154:	c5 39 6c c4          	vpunpcklqdq %xmm4,%xmm8,%xmm8
    2158:	c4 63 3d 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm8,%ymm8
    215e:	c4 c1 75 fe c3       	vpaddd %ymm11,%ymm1,%ymm0
    2163:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
    2167:	c4 e3 79 16 c2 01    	vpextrd $0x1,%xmm0,%edx
    216d:	c4 c3 79 16 c1 02    	vpextrd $0x2,%xmm0,%r9d
    2173:	c4 c3 79 16 c0 03    	vpextrd $0x3,%xmm0,%r8d
    2179:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    217f:	c4 a1 79 6e 2c 88    	vmovd  (%rax,%r9,4),%xmm5
    2185:	c4 c1 79 7e c3       	vmovd  %xmm0,%r11d
    218a:	c4 c3 79 16 c5 02    	vpextrd $0x2,%xmm0,%r13d
    2190:	c4 c3 79 16 c2 01    	vpextrd $0x1,%xmm0,%r10d
    2196:	c4 a1 79 6e 24 98    	vmovd  (%rax,%r11,4),%xmm4
    219c:	c4 c3 79 16 c4 03    	vpextrd $0x3,%xmm0,%r12d
    21a2:	c4 a1 79 6e 04 a8    	vmovd  (%rax,%r13,4),%xmm0
    21a8:	c4 a3 51 22 2c 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm5,%xmm5
    21af:	c4 a3 79 22 04 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm0,%xmm0
    21b6:	c4 a3 59 22 24 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm4,%xmm4
    21bd:	c5 d9 6c e0          	vpunpcklqdq %xmm0,%xmm4,%xmm4
    21c1:	c5 f9 6e 04 88       	vmovd  (%rax,%rcx,4),%xmm0
    21c6:	c4 e3 79 22 04 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm0,%xmm0
    21cd:	c5 f9 6c c5          	vpunpcklqdq %xmm5,%xmm0,%xmm0
    21d1:	c4 e2 6d 3d eb       	vpmaxsd %ymm3,%ymm2,%ymm5
    21d6:	c4 e3 7d 38 c4 01    	vinserti128 $0x1,%xmm4,%ymm0,%ymm0
    21dc:	c5 e5 66 e2          	vpcmpgtd %ymm2,%ymm3,%ymm4
    21e0:	c5 b5 66 f5          	vpcmpgtd %ymm5,%ymm9,%ymm6
    21e4:	c4 c2 55 3d e9       	vpmaxsd %ymm9,%ymm5,%ymm5
    21e9:	c5 55 fe ff          	vpaddd %ymm7,%ymm5,%ymm15
    21ed:	c4 c3 2d 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm4
    21f3:	c4 e3 5d 4c 64 24 20 	vpblendvb %ymm6,0x20(%rsp),%ymm4,%ymm4
    21fa:	60 
    21fb:	c5 ed fe f3          	vpaddd %ymm3,%ymm2,%ymm6
    21ff:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
    2203:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    2208:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    220c:	c5 f9 7e e1          	vmovd  %xmm4,%ecx
    2210:	c4 e3 79 16 e2 01    	vpextrd $0x1,%xmm4,%edx
    2216:	c4 c3 79 16 e1 02    	vpextrd $0x2,%xmm4,%r9d
    221c:	c4 c3 79 16 e0 03    	vpextrd $0x3,%xmm4,%r8d
    2222:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
    2228:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    222d:	c4 c1 79 7e e3       	vmovd  %xmm4,%r11d
    2232:	c4 c3 79 16 e5 02    	vpextrd $0x2,%xmm4,%r13d
    2238:	c4 c3 79 16 e2 01    	vpextrd $0x1,%xmm4,%r10d
    223e:	c4 21 79 6e 3c 98    	vmovd  (%rax,%r11,4),%xmm15
    2244:	c4 c3 79 16 e4 03    	vpextrd $0x3,%xmm4,%r12d
    224a:	c4 a1 79 6e 24 a8    	vmovd  (%rax,%r13,4),%xmm4
    2250:	c4 43 2d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm10,%ymm10
    2256:	c4 63 2d 4c 54 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm10,%ymm10
    225d:	c0 
    225e:	c4 a3 59 22 24 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm4,%xmm4
    2265:	c4 23 01 22 3c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm15,%xmm15
    226c:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    2271:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    2276:	c5 01 6c fc          	vpunpcklqdq %xmm4,%xmm15,%xmm15
    227a:	c4 a1 79 6e 24 88    	vmovd  (%rax,%r9,4),%xmm4
    2280:	c4 c3 79 16 c9 02    	vpextrd $0x2,%xmm1,%r9d
    2286:	c4 a3 59 22 24 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm4,%xmm4
    228d:	c4 c3 79 16 c8 03    	vpextrd $0x3,%xmm1,%r8d
    2293:	c5 79 6f f4          	vmovdqa %xmm4,%xmm14
    2297:	c5 f9 6e 24 88       	vmovd  (%rax,%rcx,4),%xmm4
    229c:	c5 f9 7e c9          	vmovd  %xmm1,%ecx
    22a0:	c4 e3 59 22 24 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm4,%xmm4
    22a7:	c4 e3 79 16 ca 01    	vpextrd $0x1,%xmm1,%edx
    22ad:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    22b3:	c4 c3 79 16 cd 02    	vpextrd $0x2,%xmm1,%r13d
    22b9:	c4 c1 79 7e cb       	vmovd  %xmm1,%r11d
    22be:	c4 c3 79 16 ca 01    	vpextrd $0x1,%xmm1,%r10d
    22c4:	c4 a1 79 6e 14 a8    	vmovd  (%rax,%r13,4),%xmm2
    22ca:	c4 c3 79 16 cc 03    	vpextrd $0x3,%xmm1,%r12d
    22d0:	c4 a1 79 6e 0c 98    	vmovd  (%rax,%r11,4),%xmm1
    22d6:	c4 c1 59 6c e6       	vpunpcklqdq %xmm14,%xmm4,%xmm4
    22db:	c4 c3 5d 38 e7 01    	vinserti128 $0x1,%xmm15,%ymm4,%ymm4
    22e1:	c4 c1 0d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm14
    22e7:	c4 a3 69 22 14 a0 01 	vpinsrd $0x1,(%rax,%r12,4),%xmm2,%xmm2
    22ee:	c4 a3 71 22 0c 90 01 	vpinsrd $0x1,(%rax,%r10,4),%xmm1,%xmm1
    22f5:	c4 a1 79 6e 1c 88    	vmovd  (%rax,%r9,4),%xmm3
    22fb:	c5 f1 6c ca          	vpunpcklqdq %xmm2,%xmm1,%xmm1
    22ff:	c5 f9 6e 14 88       	vmovd  (%rax,%rcx,4),%xmm2
    2304:	c4 a3 61 22 1c 80 01 	vpinsrd $0x1,(%rax,%r8,4),%xmm3,%xmm3
    230b:	c4 e3 69 22 14 90 01 	vpinsrd $0x1,(%rax,%rdx,4),%xmm2,%xmm2
    2312:	b8 00 80 00 00       	mov    $0x8000,%eax
    2317:	c5 e9 6c d3          	vpunpcklqdq %xmm3,%xmm2,%xmm2
    231b:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
    231f:	c5 a5 72 d3 18       	vpsrld $0x18,%ymm3,%ymm11
    2324:	c4 e3 6d 38 d1 01    	vinserti128 $0x1,%xmm1,%ymm2,%ymm2
    232a:	c4 41 3d db e3       	vpand  %ymm11,%ymm8,%ymm12
    232f:	c4 41 6d db cb       	vpand  %ymm11,%ymm2,%ymm9
    2334:	c4 c1 5d db cb       	vpand  %ymm11,%ymm4,%ymm1
    2339:	c5 b5 fa d9          	vpsubd %ymm1,%ymm9,%ymm3
    233d:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    2342:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    2348:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    234d:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    2352:	c4 41 0d db f3       	vpand  %ymm11,%ymm14,%ymm14
    2357:	c5 9d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm12
    235c:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    2362:	c4 41 1d db e3       	vpand  %ymm11,%ymm12,%ymm12
    2367:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    236c:	c4 41 3d db c3       	vpand  %ymm11,%ymm8,%ymm8
    2371:	c4 c1 6d db d3       	vpand  %ymm11,%ymm2,%ymm2
    2376:	c4 c1 15 72 f6 10    	vpslld $0x10,%ymm14,%ymm13
    237c:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    2380:	c4 c1 7d db cb       	vpand  %ymm11,%ymm0,%ymm1
    2385:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    238a:	c5 79 6e c8          	vmovd  %eax,%xmm9
    238e:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2393:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2398:	c4 41 2d fe d1       	vpaddd %ymm9,%ymm10,%ymm10
    239d:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
    23a2:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    23a7:	c5 ad 72 d4 08       	vpsrld $0x8,%ymm4,%ymm10
    23ac:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    23b0:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    23b5:	c4 41 2d db d3       	vpand  %ymm11,%ymm10,%ymm10
    23ba:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    23bf:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    23c4:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    23c9:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    23ce:	c4 41 1d fa e2       	vpsubd %ymm10,%ymm12,%ymm12
    23d3:	c4 c1 5d db e3       	vpand  %ymm11,%ymm4,%ymm4
    23d8:	c4 41 2d fa d6       	vpsubd %ymm14,%ymm10,%ymm10
    23dd:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    23e2:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    23e7:	c4 62 1d 40 e6       	vpmulld %ymm6,%ymm12,%ymm12
    23ec:	c4 62 2d 40 d5       	vpmulld %ymm5,%ymm10,%ymm10
    23f1:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    23f5:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    23fa:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    23ff:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    2403:	c4 c1 5d fa e0       	vpsubd %ymm8,%ymm4,%ymm4
    2408:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    240d:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
    2412:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    2417:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    241c:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    2421:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
    2427:	c4 41 2d fe d1       	vpaddd %ymm9,%ymm10,%ymm10
    242c:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2430:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2435:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    243a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    243e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2443:	e9 e8 f9 ff ff       	jmp    1e30 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x160>
    2448:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    244c:	0f 85 07 f9 ff ff    	jne    1d59 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x89>
    2452:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    2459:	0f 84 fa f8 ff ff    	je     1d59 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x89>
    245f:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    2466:	0f 84 ed f8 ff ff    	je     1d59 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x89>
    246c:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    2473:	0f 84 e0 f8 ff ff    	je     1d59 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x89>
    2479:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    247d:	48 8d 59 60          	lea    0x60(%rcx),%rbx
    2481:	48 8d b9 c0 00 00 00 	lea    0xc0(%rcx),%rdi
    2488:	48 8d a9 20 01 00 00 	lea    0x120(%rcx),%rbp
    248f:	0f 84 8c 01 00 00    	je     2621 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x951>
    2495:	4d 85 c9             	test   %r9,%r9
    2498:	0f 84 15 01 00 00    	je     25b3 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e3>
    249e:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 2506 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x836>
    24a5:	00 
    24a6:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 252e <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x85e>
    24ad:	00 
    24ae:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    24b2:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    24b6:	48 c1 e8 03          	shr    $0x3,%rax
    24ba:	4d 89 c4             	mov    %r8,%r12
    24bd:	48 8d 56 60          	lea    0x60(%rsi),%rdx
    24c1:	45 31 ed             	xor    %r13d,%r13d
    24c4:	c5 fe 7f 74 24 50    	vmovdqu %ymm6,0x50(%rsp)
    24ca:	4c 8d 70 01          	lea    0x1(%rax),%r14
    24ce:	c5 f5 72 d1 18       	vpsrld $0x18,%ymm1,%ymm1
    24d3:	c5 fe 7f 7c 24 70    	vmovdqu %ymm7,0x70(%rsp)
    24d9:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
    24df:	c4 c1 7a 7e 54 24 10 	vmovq  0x10(%r12),%xmm2
    24e6:	4c 89 f9             	mov    %r15,%rcx
    24e9:	c4 e3 69 0f d0 0c    	vpalignr $0xc,%xmm0,%xmm2,%xmm2
    24ef:	c4 e3 7d 38 c2 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm0
    24f5:	c4 e2 7d 00 44 24 50 	vpshufb 0x50(%rsp),%ymm0,%ymm0
    24fc:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    2501:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    2506:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    250a:	c5 fd 7f 46 60       	vmovdqa %ymm0,0x60(%rsi)
    250f:	c5 ed db c1          	vpand  %ymm1,%ymm2,%ymm0
    2513:	c5 fd 7f 86 80 00 00 	vmovdqa %ymm0,0x80(%rsi)
    251a:	00 
    251b:	c5 fd 7f 9e a0 00 00 	vmovdqa %ymm3,0xa0(%rsi)
    2522:	00 
    2523:	c5 f8 77             	vzeroupper
    2526:	e8 65 e0 ff ff       	call   590 <void jshc_scalar_gather::(anonymous namespace)::transform<false, true>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    252b:	48 89 d9             	mov    %rbx,%rcx
    252e:	49 ff c5             	inc    %r13
    2531:	e8 ca da ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    2536:	48 89 f9             	mov    %rdi,%rcx
    2539:	49 83 c4 18          	add    $0x18,%r12
    253d:	e8 be da ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    2542:	48 89 e9             	mov    %rbp,%rcx
    2545:	e8 b6 da ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    254a:	c5 fd 6f 96 a0 00 00 	vmovdqa 0xa0(%rsi),%ymm2
    2551:	00 
    2552:	c5 fd 6f 86 80 00 00 	vmovdqa 0x80(%rsi),%ymm0
    2559:	00 
    255a:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 25a2 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8d2>
    2561:	00 
    2562:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    2567:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    256c:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2570:	c5 fd eb 46 60       	vpor   0x60(%rsi),%ymm0,%ymm0
    2575:	c4 e2 7d 00 44 24 70 	vpshufb 0x70(%rsp),%ymm0,%ymm0
    257c:	c5 f9 6f d8          	vmovdqa %xmm0,%xmm3
    2580:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2586:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
    258b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2590:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    2594:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    259b:	c4 c1 7a 7f 54 24 e8 	vmovdqu %xmm2,-0x18(%r12)
    25a2:	4d 39 f5             	cmp    %r14,%r13
    25a5:	0f 85 2e ff ff ff    	jne    24d9 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x809>
    25ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    25b0:	c5 f8 77             	vzeroupper
    25b3:	c5 f8 28 b4 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm6
    25ba:	00 00 
    25bc:	c5 f8 28 bc 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm7
    25c3:	00 00 
    25c5:	c5 78 28 84 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm8
    25cc:	00 00 
    25ce:	c5 78 28 8c 24 00 02 	vmovaps 0x200(%rsp),%xmm9
    25d5:	00 00 
    25d7:	c5 78 28 94 24 10 02 	vmovaps 0x210(%rsp),%xmm10
    25de:	00 00 
    25e0:	c5 78 28 9c 24 20 02 	vmovaps 0x220(%rsp),%xmm11
    25e7:	00 00 
    25e9:	c5 78 28 a4 24 30 02 	vmovaps 0x230(%rsp),%xmm12
    25f0:	00 00 
    25f2:	c5 78 28 ac 24 40 02 	vmovaps 0x240(%rsp),%xmm13
    25f9:	00 00 
    25fb:	c5 78 28 b4 24 50 02 	vmovaps 0x250(%rsp),%xmm14
    2602:	00 00 
    2604:	c5 78 28 bc 24 60 02 	vmovaps 0x260(%rsp),%xmm15
    260b:	00 00 
    260d:	48 81 c4 78 02 00 00 	add    $0x278,%rsp
    2614:	5b                   	pop    %rbx
    2615:	5e                   	pop    %rsi
    2616:	5f                   	pop    %rdi
    2617:	5d                   	pop    %rbp
    2618:	41 5c                	pop    %r12
    261a:	41 5d                	pop    %r13
    261c:	41 5e                	pop    %r14
    261e:	41 5f                	pop    %r15
    2620:	c3                   	ret
    2621:	4d 85 c9             	test   %r9,%r9
    2624:	74 8d                	je     25b3 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e3>
    2626:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 268e <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9be>
    262d:	00 
    262e:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 26b6 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9e6>
    2635:	00 
    2636:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    263a:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    263e:	48 c1 e8 03          	shr    $0x3,%rax
    2642:	c5 f5 72 d1 18       	vpsrld $0x18,%ymm1,%ymm1
    2647:	4d 89 c4             	mov    %r8,%r12
    264a:	45 31 ed             	xor    %r13d,%r13d
    264d:	c5 fe 7f 74 24 50    	vmovdqu %ymm6,0x50(%rsp)
    2653:	4c 8d 70 01          	lea    0x1(%rax),%r14
    2657:	c5 fe 7f 7c 24 70    	vmovdqu %ymm7,0x70(%rsp)
    265d:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
    2663:	c4 c1 7a 7e 54 24 10 	vmovq  0x10(%r12),%xmm2
    266a:	48 89 f2             	mov    %rsi,%rdx
    266d:	4c 89 f9             	mov    %r15,%rcx
    2670:	c4 e3 69 0f d0 0c    	vpalignr $0xc,%xmm0,%xmm2,%xmm2
    2676:	c4 e3 7d 38 c2 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm0
    267c:	c4 e2 7d 00 44 24 50 	vpshufb 0x50(%rsp),%ymm0,%ymm0
    2683:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    2688:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    268d:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    2691:	c5 fd 7f 06          	vmovdqa %ymm0,(%rsi)
    2695:	c5 ed db c1          	vpand  %ymm1,%ymm2,%ymm0
    2699:	c5 fd 7f 46 20       	vmovdqa %ymm0,0x20(%rsi)
    269e:	c5 fd 7f 5e 40       	vmovdqa %ymm3,0x40(%rsi)
    26a3:	c5 f8 77             	vzeroupper
    26a6:	e8 25 ea ff ff       	call   10d0 <void jshc_scalar_gather::(anonymous namespace)::transform<false, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    26ab:	48 89 d9             	mov    %rbx,%rcx
    26ae:	49 ff c5             	inc    %r13
    26b1:	e8 4a d9 ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    26b6:	48 89 f9             	mov    %rdi,%rcx
    26b9:	49 83 c4 18          	add    $0x18,%r12
    26bd:	e8 3e d9 ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    26c2:	48 89 e9             	mov    %rbp,%rcx
    26c5:	e8 36 d9 ff ff       	call   0 <void jshc_scalar_gather::(anonymous namespace)::transform<true, false>(jshc_scalar_gather::View const&, jshc_scalar_gather::(anonymous namespace)::Rgb&)>
    26ca:	c5 fd 6f 56 40       	vmovdqa 0x40(%rsi),%ymm2
    26cf:	c5 fd 6f 46 20       	vmovdqa 0x20(%rsi),%ymm0
    26d4:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 271c <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa4c>
    26db:	00 
    26dc:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    26e1:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    26e6:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    26ea:	c5 fd eb 06          	vpor   (%rsi),%ymm0,%ymm0
    26ee:	c4 e2 7d 00 44 24 70 	vpshufb 0x70(%rsp),%ymm0,%ymm0
    26f5:	c5 f9 6f d8          	vmovdqa %xmm0,%xmm3
    26f9:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    26ff:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
    2704:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2709:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    270d:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    2714:	c4 c1 7a 7f 54 24 e8 	vmovdqu %xmm2,-0x18(%r12)
    271b:	4d 39 f5             	cmp    %r14,%r13
    271e:	0f 85 39 ff ff ff    	jne    265d <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x98d>
    2724:	e9 87 fe ff ff       	jmp    25b0 <jshc_scalar_gather::avx2_chain(jshc_scalar_gather::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e0>
    2729:	90                   	nop
    272a:	90                   	nop
    272b:	90                   	nop
    272c:	90                   	nop
    272d:	90                   	nop
    272e:	90                   	nop
    272f:	90                   	nop
