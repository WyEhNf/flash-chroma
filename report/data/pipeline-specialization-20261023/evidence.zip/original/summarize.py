"""汇总两个已完成实验；不启动数值测试或修改原始证据。"""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
results = [json.loads((root / name / 'summary.json').read_text(encoding='utf8'))
           for name in ['20261023', '20261023-hoisted']]
rows = [
    '# 固定四级流水线性能研究阶段总结', '',
    'Agent：Codex；Operator：本会话用户；日期：2026-10-23。状态：本地实验完成，待用户审核，未提交或推送 GitHub。', '',
    '## 阶段目标与完成内容', '',
    '承接 PR #56，固定三条四级链在17³、33³下的六份设置及原模型，验证运行时专门化能否在输出不变的前提下提升性能。', '',
    '第一轮展开四级调用并将恢复类型设为常量；第二轮在此基础上将12个阶段数组视图移至像素循环外，并加入第一轮实现作为同场中间对照。两个实验独立冻结计划，保留全部结果，没有根据失败修改门槛或重新计时择优。', '',
    '## 测量结果', '',
    '|链/尺寸|展开调用：耗时下降|第一轮门槛|视图外提：相对动态基线耗时下降|相对同场展开调用耗时下降|第二轮门槛|',
    '|---|---:|---|---:|---:|---|',
]
for a, b in zip(results[0]['rows'], results[1]['rows']):
    assert (a['recipe'], a['m']) == (b['recipe'], b['m'])
    rows.append(f"|{a['recipe']}/{a['m']}³|{a['time_reduction_percent']:.2f}%|{'通过' if a['gate_pass'] else '未通过'}|{b['time_reduction_percent']:.2f}%|{100*(1-b['candidate_vs_intermediate_ratio']):.2f}%|{'通过' if b['gate_pass'] else '未通过'}|")
rows += ['',
    '正数表示耗时降低，负数表示变慢。每列比例来自各自实验内的同场配对中位数，不通过两次实验的绝对时间相除估算收益。', '',
    f"第一轮通过 {sum(r['gate_pass'] for r in results[0]['rows'])}/6 组；第二轮通过 {sum(r['gate_pass'] for r in results[1]['rows'])}/6 组。两轮A/A控制分别为：{'通过' if results[0]['control_valid'] else '未通过'}、{'通过' if results[1]['control_valid'] else '未通过'}。", '',
    ('第二轮满足本次范围的统一采用门槛，可保留为研究后端选项。' if results[1]['all_cases_pass'] else '未取得满足六组统一采用门槛的优化，不建议替换默认动态实现；局部数值改善不能表述为普遍稳定加速。'), '',
    '## 正确性、环境与判定依据', '',
    '两轮各六组均验证全部256³个RGB8输入，候选与同一稀疏模型的动态基线逐字节一致；另核对独立探针、有限输入长度以及完整100张1024×768图片的输出SHA。精度保持原PR56结果，既有相对源LUT的误差并未消失。第二轮也验证了中间对照的完整色域输出。', '',
    '测试机器为Intel Core Ultra 5 125H、Windows 11，Python 3.12.7、NumPy 1.26.4、Numba 0.60.0、llvmlite 0.43.0，TBB 4线程。没有绑定专用核心或锁频，未验证原生C++、AVX2或其他机器的性能。', '',
    '每轮两个串行新进程，每设置每进程三轮；计时包含输出分配和完整四级映射，排除读图、模型加载、JIT和SHA。性能门槛为两个进程各自配对中位耗时均至少降低5%，每一对回退不超过2%，且A/A环境控制通过；第二轮还须相对同场中间对照通过同样门槛。该门槛是工程筛查，不是统计显著性检验。', '',
    '## 文件与复现入口', '',
    '- [第一轮详细报告](20261023/report.md)：六组原始时间、精度引用、控制结果、环境与复现命令。',
    '- [第二轮详细报告](20261023-hoisted/report.md)：三方对照、外提收益、控制结果与限制。',
    '- 两轮各自的code/kernels.py保存候选和基线；code/study.py负责验证与计时；code/run.py负责冻结与串行进程；code/report.py负责复算报告。',
    '- plan.json、run-lock.json保存输入和源码身份；verification.json及worker-*.json保存验证与原始测量；audit.json记录归档哈希。',
    '- 本文件由summarize.py生成，只读取已完成结果。工作分支为codex/pipeline-specialization-20261023，起点为pipeline的3d4d6d9；数值参考源码固定PR42提交59586f7bd6dd248cf0b68bcbdff8e41cf95ac572。本阶段尚无新提交。', '',
    '## 后续建议与未完成事项', '',
    '1. 先检查编译后的LLVM/汇编与热点，确认编译器是否已消除阶段循环、分支及重复视图创建；目前不能把差异归因于缓存或引用计数。',
    '2. 下一次只选一个有证据的热点优化，例如阶段节点寻址或数据布局，并继续固定逐级RGB8舍入与Q16语义。以本次六组完整色域和同场配对协议作为验收入口。',
    '3. 研究后端取得可重复收益后，再移植到目标C++流水线，与原生动态基线同机对比；不得把本次Numba结果当作原生后端加速。',
    '4. 本轮未测线程扩展、RSS/代码页、生产启动成本、其他模型以及色彩域兼容性。提交前还需整理独立发布文件、核查相关协作记录，并由用户审核。', '',
]
(root / 'report.md').write_text('\n'.join(rows), encoding='utf8')
print(root / 'report.md')
