"""冻结的动态基线与四级常量插值候选；不改变计算顺序或舍入。"""
import numpy as np
from numba import njit,prange
from lutlab import study_kernels

@njit(cache=True,parallel=True)
def mixed(rgb,nodes,indices,fractions,m,kinds):
    out=np.empty_like(rgb)
    for i in prange(len(rgb)):
        r,g,b=int(rgb[i,0]),int(rgb[i,1]),int(rgb[i,2])
        for stage in range(4):
            v=study_kernels.pixel(nodes[stage],indices[stage],fractions[stage],m,r,g,b,kinds[stage])
            r=min(255,max(0,int(np.floor(v[0]+.5))))
            g=min(255,max(0,int(np.floor(v[1]+.5))))
            b=min(255,max(0,int(np.floor(v[2]+.5))))
        out[i,0],out[i,1],out[i,2]=r,g,b
    return out

@njit(cache=True,parallel=True)
def fixed_0000(rgb,nodes,indices,fractions,m):
    out=np.empty_like(rgb)
    for i in prange(len(rgb)):
        r,g,b=int(rgb[i,0]),int(rgb[i,1]),int(rgb[i,2])
        v=study_kernels.pixel(nodes[0],indices[0],fractions[0],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[1],indices[1],fractions[1],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[2],indices[2],fractions[2],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[3],indices[3],fractions[3],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        out[i,0],out[i,1],out[i,2]=r,g,b
    return out

@njit(cache=True,parallel=True)
def fixed_0100(rgb,nodes,indices,fractions,m):
    out=np.empty_like(rgb)
    for i in prange(len(rgb)):
        r,g,b=int(rgb[i,0]),int(rgb[i,1]),int(rgb[i,2])
        v=study_kernels.pixel(nodes[0],indices[0],fractions[0],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[1],indices[1],fractions[1],m,r,g,b,1)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[2],indices[2],fractions[2],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[3],indices[3],fractions[3],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        out[i,0],out[i,1],out[i,2]=r,g,b
    return out

@njit(cache=True,parallel=True)
def fixed_0101(rgb,nodes,indices,fractions,m):
    out=np.empty_like(rgb)
    for i in prange(len(rgb)):
        r,g,b=int(rgb[i,0]),int(rgb[i,1]),int(rgb[i,2])
        v=study_kernels.pixel(nodes[0],indices[0],fractions[0],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[1],indices[1],fractions[1],m,r,g,b,1)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[2],indices[2],fractions[2],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[3],indices[3],fractions[3],m,r,g,b,1)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        out[i,0],out[i,1],out[i,2]=r,g,b
    return out

@njit(cache=True,parallel=True)
def fixed_1100(rgb,nodes,indices,fractions,m):
    out=np.empty_like(rgb)
    for i in prange(len(rgb)):
        r,g,b=int(rgb[i,0]),int(rgb[i,1]),int(rgb[i,2])
        v=study_kernels.pixel(nodes[0],indices[0],fractions[0],m,r,g,b,1)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[1],indices[1],fractions[1],m,r,g,b,1)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[2],indices[2],fractions[2],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        v=study_kernels.pixel(nodes[3],indices[3],fractions[3],m,r,g,b,0)
        r=min(255,max(0,int(np.floor(v[0]+.5))))
        g=min(255,max(0,int(np.floor(v[1]+.5))))
        b=min(255,max(0,int(np.floor(v[2]+.5))))
        out[i,0],out[i,1],out[i,2]=r,g,b
    return out
