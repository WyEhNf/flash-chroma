"""固定24对23的唯一比较，目标门槛仍为吞吐3倍，不降低为局部改善。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_exception.py').read_text(encoding='utf-8').replace('bench_skylake_exception.py','bench_skylake_direct16.py')
s=s.replace('from exception_support import info as exception_info','from exception_support import info as exception_info\nfrom direct16_support import info as direct_info')
s=s.replace('compiled=palette_info(chain);pool=exception_info(chain)','compiled=palette_info(chain);pool=exception_info(chain);direct=direct_info(chain)')
s=s.replace("                if name=='candidate' and (pool", "                if name=='candidate' and (direct is None or direct['enabled']!=1 or direct['entries']!=2**23 or direct['table_capacity_bytes']!=2**25):raise ValueError('计时必须启用精确16bit直表')\n                if name=='candidate' and (pool")
s=s.replace("'compiled_exceptions':pool,", "'compiled_exceptions':pool,'direct_info':direct,")
s=s.replace("'scripts/bench_skylake_direct16.py','scripts/exception_support.py'", "'scripts/bench_skylake_direct16.py','scripts/direct16_support.py','scripts/exception_support.py'")
(ROOT/'scripts/bench_skylake_direct16.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_direct16.py','exec')
policy=json.loads((ROOT/'experiments/skylake-exception-perf-v1.json').read_text(encoding='utf-8'))
def spec(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
policy.update(purpose='24直接对23的一次固定80轮，验收目标为apply/copy吞吐达到3倍；未达到则继续研究，不改门槛',build_path='artifacts/skylake-direct16-build-v1')
for key,path in {'plan':'experiments/skylake-direct16-v1.json','build':'artifacts/skylake-direct16-build-v1/build.json',
    'full_acceptance':'artifacts/skylake-direct16-full-v1/results.json','domain_contract':'artifacts/skylake-direct16-domain-contract-v1/results.json',
    'packed_contract':'artifacts/skylake-direct16-packed-contract-v1/results.json','signed_contract':'artifacts/skylake-direct16-signed-contract-v1/results.json',
    'validation':'experiments/skylake-direct16-validation-v2.json','benchmark_script':'scripts/bench_skylake_direct16.py','direct_support':'scripts/direct16_support.py'}.items():policy[key]=spec(path)
policy['adoption_gate']['median_apply_ratio_max']=1/3;policy['adoption_gate']['median_copy_apply_ratio_max']=1/3
policy['limits'].append('32MiB新直表，完整保留23的数据和回退；额外内存与准备单列；3倍未测先不宣称')
(ROOT/'experiments/skylake-direct16-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结3倍目标策略；未运行性能')
