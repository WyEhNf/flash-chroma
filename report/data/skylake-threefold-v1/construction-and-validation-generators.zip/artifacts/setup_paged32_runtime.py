"""冻结26：64MiB精确RGB32单级查表，进程内对齐与Linux MADV_HUGEPAGE；回退23。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-exception-runtime';out=ROOT/'experiments/skylake-paged32-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
write('aligned_table.hpp','''#pragma once
#include <cstdlib>
#include <cstdint>
#include <cstddef>
#include <new>
#if defined(__linux__)
#include <sys/mman.h>
#elif defined(_WIN32)
#include <malloc.h>
#endif
namespace jshc_channel {
// 只建议本对象拥有的完整2MiB对齐区域，不调整任何系统设置或权限。
class AlignedTable {
  uint32_t* data_=nullptr;
  size_t words_=0;
  int advice_=-1;
public:
  AlignedTable()=default;
  AlignedTable(const AlignedTable&)=delete;
  AlignedTable& operator=(const AlignedTable&)=delete;
  ~AlignedTable() {
#if defined(_WIN32)
    _aligned_free(data_);
#else
    std::free(data_);
#endif
  }
  void allocate(size_t words) {
    if(data_)throw std::bad_alloc();
    const size_t bytes=words*sizeof(uint32_t);
#if defined(_WIN32)
    data_=static_cast<uint32_t*>(_aligned_malloc(bytes,size_t{2}<<20));
    if(!data_)throw std::bad_alloc();
#else
    void* pointer=nullptr;
    if(posix_memalign(&pointer,size_t{2}<<20,bytes)!=0)throw std::bad_alloc();
    data_=static_cast<uint32_t*>(pointer);
#endif
    words_=words;
#if defined(__linux__)
    advice_=madvise(data_,bytes,MADV_HUGEPAGE);
#endif
  }
  uint32_t* data() noexcept {return data_;}
  const uint32_t* data() const noexcept {return data_;}
  size_t size() const noexcept {return words_;}
  size_t bytes() const noexcept {return words_*sizeof(uint32_t);}
  bool empty() const noexcept {return !data_;}
  int advice() const noexcept {return advice_;}
};
}
''')
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8').replace('#include "suffix_cache.hpp"','#include "suffix_cache.hpp"\n#include "aligned_table.hpp"')
s=s.replace('std::vector<uint32_t> exceptions;','std::vector<uint32_t> exceptions;\n  jshc_channel::AlignedTable direct32;')
s=s.replace('if(!h.compiled.empty())jshc_channel::avx2_chain_exception','if(!h.direct32.empty())jshc_channel::avx2_chain_paged32(h.direct32.data(),data,vectorized);\n        else if(!h.compiled.empty())jshc_channel::avx2_chain_exception')
marker='    h.compiled.swap(packed);h.exceptions.swap(exception_words);info.enabled=1;info.reason=0;'
s=s.replace(marker,marker+'''
    try {
      h.direct32.allocate(size_t{1}<<24);
#if defined(_OPENMP)
#pragma omp parallel for schedule(static) num_threads(4)
#endif
      for(long long i=0;i<(1LL<<24);++i)h.direct32.data()[size_t(i)]=uint32_t(rgb[3*i])|(uint32_t(rgb[3*i+1])<<8)|(uint32_t(rgb[3*i+2])<<16);
      info.temporary_peak_bytes+=h.direct32.bytes();
    }catch(const std::bad_alloc&) {} // 分配失败时已有23表仍然完整。
''')
s=s.replace('jshc_cc_revision(void) {return 23;','jshc_cc_revision(void) {return 26;')
s=s.replace('bytes+=h.cache.capacity()*sizeof(uint32_t)', 'bytes+=h.direct32.bytes()+h.cache.capacity()*sizeof(uint32_t)')
marker='uint32_t jshc_cc_domain_fast_enabled(const void* handle) {'
s=s.replace(marker,'''int jshc_cc_get_direct_info(const void* handle,jshc_cc_direct_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_direct_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(!h.direct32.empty()),32,0,h.direct32.size(),h.direct32.bytes(),0,0};return 0;
}
int jshc_cc_get_paged_info(const void* handle,jshc_cc_paged_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_paged_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(h.direct32.advice()==0),0,0,uint64_t(reinterpret_cast<uintptr_t>(h.direct32.data())),h.direct32.bytes()};return 0;
}
int jshc_cc_copy_direct(const void* handle,uint32_t* output,size_t entries) {
  if(!handle)return 1;const auto& h=*static_cast<const Handle*>(handle);
  if(entries!=h.direct32.size() || (entries && !output))return 1;
  if(entries)std::memcpy(output,h.direct32.data(),h.direct32.bytes());return 0;
}
'''+marker)
write('channel_runtime.cpp',s);write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
s=(ROOT/'experiments/skylake-direct16-runtime/suffix_cache.hpp').read_text(encoding='utf-8').replace('void avx2_chain_direct16(const uint32_t*,int32_t,int32_t,uint8_t*,size_t) noexcept;','void avx2_chain_paged32(const uint32_t*,uint8_t*,size_t) noexcept;')
s+='''
extern "C" {
struct jshc_cc_paged_info {uint32_t version,advised,reserved0,reserved1;uint64_t base,bytes;};
JSHC_CC_API int jshc_cc_get_paged_info(const void*,jshc_cc_paged_info*,size_t);
}
'''
write('suffix_cache.hpp',s)
s=(ROOT/'experiments/skylake-byteindex-runtime/channel_avx2.cpp').read_text(encoding='utf-8')
a=s.index('inline __attribute__((always_inline)) __m256i ids');b=s.index('inline __attribute__((always_inline)) void output',a)
s=s[:a]+'''inline __attribute__((always_inline)) __m256i lookup(const uint32_t* table,__m256i code) {
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(table),code,4);
}
'''+s[b:]
s=s.replace('void avx2_chain_byteindex(const uint32_t* table,const uint32_t* palette,uint8_t* data,size_t pixels)', 'void avx2_chain_paged32(const uint32_t* table,uint8_t* data,size_t pixels)')
s=s.replace('    const __m256i i0=ids(table,c0),i1=ids(table,c1),i2=ids(table,c2),i3=ids(table,c3);\n    const __m256i r0=rgb(palette,i0),r1=rgb(palette,i1),r2=rgb(palette,i2),r3=rgb(palette,i3);','    const __m256i r0=lookup(table,c0),r1=lookup(table,c1),r2=lookup(table,c2),r3=lookup(table,c3);')
s=s.replace('rgb(palette,ids(table,c))','lookup(table,c)').replace('精确全域字节索引：四包独立读取先行，所有地址由RGB24和尾保护词覆盖。','精确RGB32直表：四包独立读取先行，RGB24索引覆盖全部有效词。')
write('channel_avx2.cpp',s)
write('CMakeLists.txt',(ROOT/'experiments/skylake-byteindex-runtime/CMakeLists.txt').read_text(encoding='utf-8').replace('skylake_byteindex','skylake_paged32'))
plan=json.loads((ROOT/'experiments/skylake-exception-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；64MiB精确RGB32单次gather与进程内THP建议，通用AVX2',base_commit='8355402',candidate='从原四稀疏链生成RGB32完整输出表，不改精度，不使用源LUT或照片；Linux局部MADV_HUGEPAGE建议，真实大页由smaps核对',revisions={'reference':23,'candidate':26},cmake_project='experiments/skylake-paged32-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_paged32'])
plan['paged32_policy']={'format':32,'words':2**24,'bytes':2**26,'alignment':2**21,'packets_unrolled':4,'metadata_expected':24,'goal_ratio_max':1/3,
    'page_policy':'仅对象自有对齐分配MADV_HUGEPAGE；不修改系统THP/GDS/权限；advice成功不等同真实大页',
    'scope':'本机Linux/AMD，参考23同一环境；Windows分配普通页，未宣称收益；不是Skylake实测'}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-paged32-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结26，未执行数值或性能；大页尚未验证')
