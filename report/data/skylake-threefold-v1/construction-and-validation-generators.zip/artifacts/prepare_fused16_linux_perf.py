"""从冻结索引基准派生28基准；完整验证通过后，冻结真实输出与旧接口两种计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_pageindex_linux.py').read_text(encoding='utf-8')
def change(a,b):
    global s
    if a not in s:raise ValueError('未找到派生锚点：'+a)
    s=s.replace(a,b)
change('比较27与23','比较28与23')
change('四进程80轮','四进程80轮，每轮分别测旧接口与真实输出接口')
change('bench_skylake_pageindex_linux.py','bench_skylake_fused16_linux.py')
change('from paged_table_support import direct_info,paged_info','from paged_table_support import direct_info,paged_info\nfrom outplace_support import bind_to')
change("state['format']!=8 or state['table_capacity_bytes']!=2**24 or not pages['fully_huge']", "state['format']!=16 or state['table_capacity_bytes']!=2**25+4 or not pages['aligned_2m'] or pages['anon_huge_bytes']<2**25")
change('启用16MiB精确索引及完全THP','启用32MiB精确16bit及主体THP')
change("                ct.memmove(work,source_pointer,n)", "                bind_to(d)\n                fto=d.jshc_cc_bench_to;fto.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint8),ct.POINTER(ct.c_uint8),ct.c_size_t,ct.c_int,ct.c_int,ct.c_size_t,ct.POINTER(ct.c_double),ct.POINTER(ct.c_char),ct.c_size_t];fto.restype=ct.c_int\n                ct.memmove(work,source_pointer,n)")
a="""                apply_seconds=[];copy_apply_seconds=[];hashes=[]
                for _ in range(policy['repeats']):
                    a=ct.c_double();c=ct.c_double()
                    if f(handle,source_pointer,work,n,1,threads,1,ct.byref(a),ct.byref(c),error,len(error)):raise RuntimeError(error.value.decode())
                    result_hash=output_hash()
                    if result_hash!=expected:raise AssertionError('计时轮完整输出不同')
                    if not (math.isfinite(a.value) and math.isfinite(c.value) and 0<a.value<=c.value):raise ValueError('计时非法')
                    apply_seconds.append(a.value);copy_apply_seconds.append(c.value);hashes.append(result_hash)
"""
b="""                if d.jshc_cc_apply_to(handle,source_pointer,work,n,1,threads,error,len(error)):raise RuntimeError(error.value.decode())
                if output_hash()!=expected:raise AssertionError('真实输出接口预热不同')
                apply_seconds=[];copy_apply_seconds=[];outplace_seconds=[];hashes=[];out_hashes=[];mode_orders=[]
                for round_index in range(policy['repeats']):
                    modes=['legacy','outplace'] if (index+round_index)%2==0 else ['outplace','legacy']
                    mode_orders.append(modes)
                    for mode in modes:
                        a=ct.c_double();c=ct.c_double()
                        if mode=='legacy':
                            if f(handle,source_pointer,work,n,1,threads,1,ct.byref(a),ct.byref(c),error,len(error)):raise RuntimeError(error.value.decode())
                            if not (math.isfinite(a.value) and math.isfinite(c.value) and 0<a.value<=c.value):raise ValueError('旧接口计时非法')
                            apply_seconds.append(a.value);copy_apply_seconds.append(c.value)
                        else:
                            if fto(handle,source_pointer,work,n,1,threads,1,ct.byref(c),error,len(error)):raise RuntimeError(error.value.decode())
                            if not (math.isfinite(c.value) and c.value>0):raise ValueError('真实输出计时非法')
                            outplace_seconds.append(c.value)
                        result_hash=output_hash()
                        if result_hash!=expected:raise AssertionError('计时轮完整输出不同')
                        (hashes if mode=='legacy' else out_hashes).append(result_hash)
"""
change(a,b)
change("'copy_apply_seconds':copy_apply_seconds", "'legacy_copy_apply_seconds':copy_apply_seconds,'outplace_seconds':outplace_seconds,'mode_orders':mode_orders,'outplace_output_sha256':out_hashes")
change("'prepare_plus_first_100_copy_apply_seconds':prepare+copy_apply_seconds[0]", "'prepare_plus_first_100_copy_apply_seconds':prepare+copy_apply_seconds[0],'prepare_plus_first_100_outplace_seconds':prepare+outplace_seconds[0]")
change("'scripts/paged_table_support.py','scripts/skylake_server_support.py'", "'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/skylake_server_support.py'")
change('原生235MB整批apply/copy+apply','原生235MB整批apply、旧copy+apply及真实source→destination输出')
change("m[role]['copy_apply_seconds']", "m[role]['legacy_copy_apply_seconds']")
change("'median_copy_apply_ms_per_image':", "'median_legacy_copy_apply_ms_per_image':")
change("'prepare_wall_seconds':[m[role]['prepare_wall_seconds']", "'median_outplace_ms_per_image':statistics.median(statistics.median(m[role]['outplace_seconds'])*10 for m in matches),\n                'prepare_wall_seconds':[m[role]['prepare_wall_seconds']")
change("m['candidate']['copy_apply_seconds']", "m['candidate']['legacy_copy_apply_seconds']")
change("m['reference']['copy_apply_seconds']", "m['reference']['legacy_copy_apply_seconds']")
change("        prep=[", "        out=[statistics.median(m['candidate']['outplace_seconds'])/statistics.median(m['reference']['outplace_seconds']) for m in matches]\n        prep=[")
change("m['candidate']['prepare_plus_first_100_copy_apply_seconds']/m['reference']['prepare_plus_first_100_copy_apply_seconds']", "m['candidate']['prepare_plus_first_100_outplace_seconds']/m['reference']['prepare_plus_first_100_outplace_seconds']")
change("if statistics.median(c)>g['median_copy_apply_ratio_max']:failed.append(f'{threads}线程copy+apply未达3倍')", "if statistics.median(out)>g['median_outplace_ratio_max']:failed.append(f'{threads}线程真实输出未达3倍')")
change("'process_copy_apply_ratios':c,'median_copy_apply_ratio':statistics.median(c)", "'process_legacy_copy_apply_ratios':c,'median_legacy_copy_apply_ratio':statistics.median(c),'process_outplace_ratios':out,'median_outplace_ratio':statistics.median(out)")
change("'process_prepare_plus_100_copy_apply_ratios':prep,'median_prepare_plus_100_copy_apply_ratio':statistics.median(prep)", "'process_prepare_plus_100_outplace_ratios':prep,'median_prepare_plus_100_outplace_ratio':statistics.median(prep)")
compile(s,'bench_skylake_fused16_linux.py','exec')
(ROOT/'scripts/bench_skylake_fused16_linux.py').write_bytes(s.encode('utf-8'))
policy=json.loads((ROOT/'experiments/skylake-pageindex-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
for key,path in {'plan':'experiments/skylake-fused16-v1.json','build':'artifacts/skylake-fused16-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-fused16-linux-full-v1/results.json','validation':'experiments/skylake-fused16-validation-v1.json','benchmark_script':'scripts/bench_skylake_fused16_linux.py'}.items():policy[key]=spec(path)
policy['purpose']='同WSL/AMD的28直接对23；80轮分别计纯apply、旧copy+apply及真实source→destination输出，后者是可调用API，绝不替换旧数据'
policy['adoption_gate']['median_outplace_ratio_max']=policy['adoption_gate'].pop('median_copy_apply_ratio_max')
policy['mode_order']='(进程序号+轮序号)偶数先legacy后outplace，否则反向；两个模式各自100图及逐轮完整SHA'
policy['limits']=['仅自身分配范围MADV_HUGEPAGE，不改全局设置或权限','每个候选句柄smaps必须证明32MiB主体THP，4字节保护尾部不要求大页','纯apply及真实输出均须达到3倍；旧copy+apply完整报告，不能声称该接口达标','同机WSL不是Skylake实测','IO/解码/分配/哈希不计稳态，准备时间单列']
(ROOT/'experiments/skylake-fused16-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定28性能策略，未计时')
