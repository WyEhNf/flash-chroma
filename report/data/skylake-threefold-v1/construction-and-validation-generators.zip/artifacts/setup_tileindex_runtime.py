"""冻结30：4×4×4输入颜色共享64字节行；表容量与27相同，增加真实输出API。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-pageindex-runtime';fused=ROOT/'experiments/skylake-fused16-runtime';out=ROOT/'experiments/skylake-tileindex-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
for n in ('aligned_table.hpp','channel_views.hpp'):write(n,(old/n).read_text(encoding='utf-8'))
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8').replace('avx2_chain_pageindex','avx2_chain_tileindex').replace('jshc_cc_revision(void) {return 27;','jshc_cc_revision(void) {return 30;')
s=s.replace('const size_t i=size_t(group)*4+k;', '''const uint32_t address=uint32_t(group)*4+k;
          const size_t i=(address&0xfc0003u)|((address&0x03f000u)>>2)|((address&0x000fc0u)>>4)|((address&0x30u)<<12)|((address&0x0cu)<<6);''')
t=(fused/'channel_runtime.cpp').read_text(encoding='utf-8');a=t.index('void apply_to(');b=t.index('void prepare_palette(',a)
api=t[a:b].replace('h.direct16','h.direct_index').replace('avx2_chain_fused16_to','avx2_chain_tileindex_to').replace('h.direct_dg,h.direct_db','h.output_palette.data()')
s=s.replace('void prepare_palette(',api+'void prepare_palette(',1)
a=t.index('int jshc_cc_apply_to(');b=t.index('uint32_t jshc_cc_domain_fast_enabled(',a)
s=s.replace('uint32_t jshc_cc_domain_fast_enabled(',t[a:b]+'uint32_t jshc_cc_domain_fast_enabled(',1)
write('channel_runtime.cpp',s)
s=(old/'suffix_cache.hpp').read_text(encoding='utf-8').replace('avx2_chain_pageindex','avx2_chain_tileindex')
s+='''
namespace jshc_channel {
void avx2_chain_tileindex_to(const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t) noexcept;
}
extern "C" JSHC_CC_API int jshc_cc_apply_to(void*,const uint8_t*,uint8_t*,size_t,int,int,char*,size_t);
''';write('suffix_cache.hpp',s)
s=(old/'channel_avx2.cpp').read_text(encoding='utf-8').replace('avx2_chain_pageindex','avx2_chain_tileindex')
s=s.replace('  const __m256i word=_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,2),4);', '''  // 字索引：高R6、高G6、高B6、低R2、低G2；低B2选择字节。
  const __m256i a=_mm256_srli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(0xfc0000)),2);
  const __m256i b=_mm256_and_si256(code,_mm256_set1_epi32(0xfc00));
  const __m256i c=_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(0xfc)),2);
  const __m256i d=_mm256_srli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(0x30000)),14);
  const __m256i e=_mm256_srli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(0x300)),8);
  const __m256i index=_mm256_or_si256(_mm256_or_si256(a,b),_mm256_or_si256(c,_mm256_or_si256(d,e)));
  const __m256i word=_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),index,4);''')
s=s.replace('void avx2_chain_tileindex(const uint32_t* table,const uint32_t* palette,uint8_t* data,size_t pixels) noexcept {','namespace {\ninline __attribute__((always_inline)) void run(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {')
s=s.replace('input(data+','input(source+').replace('output(data+','output(destination+')
s=s[:-2]+''' }
void avx2_chain_tileindex(const uint32_t* table,const uint32_t* palette,uint8_t* data,size_t pixels) noexcept {run(table,palette,data,data,pixels);}
void avx2_chain_tileindex_to(const uint32_t* table,const uint32_t* palette,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {run(table,palette,source,destination,pixels);}
}
''';write('channel_avx2.cpp',s)
for n in ('reference_to.cpp','outplace_bench.cpp'):write(n,(fused/n).read_text(encoding='utf-8'))
write('CMakeLists.txt',(fused/'CMakeLists.txt').read_text(encoding='utf-8').replace('skylake_fused16','skylake_tileindex'))
plan=json.loads((ROOT/'experiments/skylake-pageindex-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；16MiB精确字节索引，4×4×4颜色分块与真实输出API',candidate='固定64字节颜色块，只改变输入地址布局，不按照片拟合；保留23回退和28新API合同',revisions={'reference':23,'candidate':30},cmake_project='experiments/skylake-tileindex-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tileindex'])
plan['tileindex_policy']={'tile_rgb':[4,4,4],'cacheline_bytes':64,'table_bytes':2**24,'metadata_expected':24,'reason':'固定64字节缓存行几何，预先只读照片分析显示包内平均访问行25.81变20.50；未据计时选参数'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-pageindex-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-tileindex-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结30，未运行')
