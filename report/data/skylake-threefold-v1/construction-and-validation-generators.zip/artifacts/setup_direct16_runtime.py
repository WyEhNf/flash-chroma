"""冻结修订24：32MiB精确16bit直表与两包并行gather，参考为23。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-exception-runtime';out=ROOT/'experiments/skylake-direct16-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8')
s=s.replace('std::vector<uint32_t> exceptions;', 'std::vector<uint32_t> exceptions;\n  std::vector<uint32_t> direct16;\n  int32_t direct_dg=0,direct_db=0;')
s=s.replace('if(!h.compiled.empty())jshc_channel::avx2_chain_exception', 'if(!h.direct16.empty())jshc_channel::avx2_chain_direct16(h.direct16.data(),h.direct_dg,h.direct_db,data,vectorized);\n        else if(!h.compiled.empty())jshc_channel::avx2_chain_exception')
marker='    h.compiled.swap(packed);h.exceptions.swap(exception_words);info.enabled=1;info.reason=0;'
replacement='''    h.compiled.swap(packed);h.exceptions.swap(exception_words);info.enabled=1;info.reason=0;
    // 用当前标签的精确通道差编码，不改变任何RGB8值；不适配的模型继续23。
    int dglo=255,dghi=-255,dblo=255,dbhi=-255;
    for(uint32_t v:values) {
      const int r=v&255,g=(v>>8)&255,b=(v>>16)&255;
      dglo=std::min(dglo,g-r);dghi=std::max(dghi,g-r);dblo=std::min(dblo,b-r);dbhi=std::max(dbhi,b-r);
    }
    if(dghi-dglo<=15 && dbhi-dblo<=15) {
      try {
        std::vector<uint32_t> direct(size_t{1}<<23);
#if defined(_OPENMP)
#pragma omp parallel for schedule(static) num_threads(4)
#endif
        for(long long pair=0;pair<(1LL<<23);++pair) {
          uint32_t word=0;
          for(unsigned k=0;k<2;++k) {
            const size_t i=size_t(pair)*2+k;
            const int r=rgb[3*i],dg=int(rgb[3*i+1])-r-dglo,db=int(rgb[3*i+2])-r-dblo;
            const uint32_t code=uint32_t(r)|(uint32_t(dg)<<8)|(uint32_t(db)<<12);
            word|=code<<(16*k);
          }
          direct[size_t(pair)]=word;
        }
        h.direct16.swap(direct);h.direct_dg=dglo;h.direct_db=dblo;
        info.temporary_peak_bytes+=h.direct16.capacity()*sizeof(uint32_t);
      }catch(const std::bad_alloc&) {} // 只放弃新增直表，已准备的23完整保留。
    }'''
assert marker in s;s=s.replace(marker,replacement)
s=s.replace('jshc_cc_revision(void) {return 23;', 'jshc_cc_revision(void) {return 24;')
s=s.replace('(h.compiled.capacity()+h.exceptions.capacity())*sizeof(uint32_t)', '(h.compiled.capacity()+h.exceptions.capacity()+h.direct16.capacity())*sizeof(uint32_t)')
marker='uint32_t jshc_cc_domain_fast_enabled(const void* handle) {'
s=s.replace(marker,'''int jshc_cc_get_direct_info(const void* handle,jshc_cc_direct_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_direct_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(!h.direct16.empty()),16,0,h.direct16.size(),h.direct16.capacity()*sizeof(uint32_t),h.direct_dg,h.direct_db};return 0;
}
int jshc_cc_copy_direct(const void* handle,uint32_t* output,size_t entries) {
  if(!handle)return 1;const auto& h=*static_cast<const Handle*>(handle);
  if(entries!=h.direct16.size() || (entries && !output))return 1;
  if(entries)std::memcpy(output,h.direct16.data(),entries*sizeof(uint32_t));return 0;
}
'''+marker)
write('channel_runtime.cpp',s);write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
s=(old/'suffix_cache.hpp').read_text(encoding='utf-8')+'''
namespace jshc_channel {
void avx2_chain_direct16(const uint32_t*,int32_t,int32_t,uint8_t*,size_t) noexcept;
}
extern "C" {
struct jshc_cc_direct_info {uint32_t version,enabled,format,reserved;uint64_t entries,table_capacity_bytes;int32_t dg_min,db_min;};
JSHC_CC_API int jshc_cc_get_direct_info(const void*,jshc_cc_direct_info*,size_t);
JSHC_CC_API int jshc_cc_copy_direct(const void*,uint32_t*,size_t);
}
'''
write('suffix_cache.hpp',s)
write('channel_avx2.cpp','''// 精确16bit输出编码：R占8bit，G-R和B-R相对各自最小值分别占4bit。
#include "suffix_cache.hpp"
#include <immintrin.h>
namespace jshc_channel {
namespace {
inline __attribute__((always_inline)) __m256i input(const uint8_t* p) {
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m128i hi=_mm_alignr_epi8(last,lo,12);
  const __m256i raw=_mm256_inserti128_si256(_mm256_castsi128_si256(lo),hi,1);
  return _mm256_shuffle_epi8(raw,_mm256_setr_epi8(2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1,2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1));
}
inline __attribute__((always_inline)) __m256i lookup(const uint32_t* table,__m256i code) {
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,1),4);
}
inline __attribute__((always_inline)) void output(uint8_t* p,__m256i code,__m256i word,__m256i dg,__m256i db) {
  const __m256i packed=_mm256_srlv_epi32(word,_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(1)),4));
  const __m256i r=_mm256_and_si256(packed,_mm256_set1_epi32(255));
  const __m256i g=_mm256_add_epi32(r,_mm256_add_epi32(dg,_mm256_and_si256(_mm256_srli_epi32(packed,8),_mm256_set1_epi32(15))));
  const __m256i b=_mm256_add_epi32(r,_mm256_add_epi32(db,_mm256_and_si256(_mm256_srli_epi32(packed,12),_mm256_set1_epi32(15))));
  const __m256i value=_mm256_or_si256(r,_mm256_or_si256(_mm256_slli_epi32(g,8),_mm256_slli_epi32(b,16)));
  const __m256i bytes=_mm256_shuffle_epi8(value,_mm256_setr_epi8(0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1,0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1));
  const __m128i bottom=_mm256_castsi256_si128(bytes),top=_mm256_extracti128_si256(bytes,1);
  _mm_storeu_si128(reinterpret_cast<__m128i*>(p),_mm_or_si128(bottom,_mm_slli_si128(top,12)));
  _mm_storel_epi64(reinterpret_cast<__m128i*>(p+16),_mm_srli_si128(top,4));
}
}
void avx2_chain_direct16(const uint32_t* table,int32_t dg_min,int32_t db_min,uint8_t* data,size_t pixels) noexcept {
  const __m256i dg=_mm256_set1_epi32(dg_min),db=_mm256_set1_epi32(db_min);size_t p=0;
  for(;p+16<=pixels;p+=16) {
    const __m256i c0=input(data+3*p),c1=input(data+3*p+24);
    const __m256i w0=lookup(table,c0),w1=lookup(table,c1);
    output(data+3*p,c0,w0,dg,db);output(data+3*p+24,c1,w1,dg,db);
  }
  if(p<pixels) {const __m256i c=input(data+3*p);output(data+3*p,c,lookup(table,c),dg,db);}
}
}
''')
s=(old/'CMakeLists.txt').read_text(encoding='utf-8').replace('project(jshc_skylake_exception','project(jshc_skylake_direct16').replace('set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_exception)','set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_direct16)')
a=s.index('add_library(jshc_skylake_reference SHARED');b=s.index('foreach(target',a)
s=s[:a]+'''add_library(jshc_skylake_reference SHARED
  "${JSHC_ROOT}/experiments/skylake-exception-runtime/channel_runtime.cpp"
  "${JSHC_ROOT}/experiments/skylake-exception-runtime/channel_avx2.cpp"
  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp"
  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")
add_library(${SKYLAKE_CANDIDATE_TARGET} SHARED "${SKYLAKE_RUNTIME_SOURCE}"
  "${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"
  "${JSHC_ROOT}/experiments/skylake-exception-runtime/channel_avx2.cpp"
  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp"
  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")
'''+s[b:]
s=s.replace('set_source_files_properties(\n','set_source_files_properties(\n  "${JSHC_ROOT}/experiments/skylake-exception-runtime/channel_avx2.cpp"\n')
write('CMakeLists.txt',s)
plan=json.loads((ROOT/'experiments/skylake-exception-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='以23为基线争取3倍吞吐；单次冻结的精确16bit直表及两包并行gather',base_commit='8355402',candidate='当前四稀疏模型精确标签，R8+两通道差4+4；不符合差值范围保留23',revisions={'reference':23,'candidate':24},cmake_project='experiments/skylake-direct16-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_direct16'])
plan['direct16_policy']={'bits':16,'pairs':2**23,'bytes':2**25,'unroll_packets':2,'metadata_expected':32,'range_guard':'从完整缓存求G-R与B-R，跨度均<=15才准备，不按照片选范围','goal_apply_and_copy_ratio_max':1/3,'scope':'当前本机固定模型，未承诺达到3倍，Skylake实测与官方预算/许可待确认'}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-direct16-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定修订24及参考23，未运行数值或性能')
