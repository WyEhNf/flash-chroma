"""冻结28：无奇偶解码的16bit大页查表及实际分离输入/输出API；参考保持23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-direct16-runtime';out=ROOT/'experiments/skylake-fused16-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
write('aligned_table.hpp',(ROOT/'experiments/skylake-paged32-runtime/aligned_table.hpp').read_text(encoding='utf-8'))
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8').replace('#include "suffix_cache.hpp"','#include "suffix_cache.hpp"\n#include "aligned_table.hpp"')
s=s.replace('std::vector<uint32_t> direct16;','jshc_channel::AlignedTable direct16;').replace('avx2_chain_direct16','avx2_chain_fused16')
s=s.replace('std::vector<uint32_t> direct(size_t{1}<<23);','h.direct16.allocate((size_t{1}<<23)+1);')
s=s.replace('direct[size_t(pair)]=word;','h.direct16.data()[size_t(pair)]=word;')
s=s.replace('h.direct16.swap(direct);','h.direct16.data()[size_t{1}<<23]=0;')
s=s.replace('h.direct16.capacity()*sizeof(uint32_t)','h.direct16.bytes()')
s=s.replace('(h.compiled.capacity()+h.exceptions.capacity()+h.direct16.capacity())*sizeof(uint32_t)','(h.compiled.capacity()+h.exceptions.capacity())*sizeof(uint32_t)+h.direct16.bytes()')
s=s.replace('jshc_cc_revision(void) {return 24;','jshc_cc_revision(void) {return 28;')
marker='void prepare_palette(Handle& h) {'
s=s.replace(marker,'''void apply_to(Handle& h,const uint8_t* source,uint8_t* destination,size_t bytes,int kernel,int threads) {
  apply(h,nullptr,0,kernel,threads); // 先验证后端/线程，不写任何目标。
  if(!bytes)return;
  if(bytes%3 || !source || !destination)throw std::runtime_error("需要有效紧密RGB8输入/输出");
  const uintptr_t src=reinterpret_cast<uintptr_t>(source),dst=reinterpret_cast<uintptr_t>(destination);
  if(bytes>std::numeric_limits<uintptr_t>::max()-src || bytes>std::numeric_limits<uintptr_t>::max()-dst)throw std::runtime_error("RGB范围溢出");
  if(source==destination) {apply(h,destination,bytes,kernel,threads);return;}
  if(src<dst+bytes && dst<src+bytes)throw std::runtime_error("分离输入/输出不得部分重叠");
  const size_t pixels=bytes/3,blocks=pixels/4096+(pixels%4096!=0);
  if(blocks>size_t(std::numeric_limits<long long>::max()))throw std::runtime_error("块计数溢出");
#if defined(_OPENMP)
  const int workers=omp_in_parallel()?1:static_cast<int>(std::min(blocks,size_t(threads)));
#pragma omp parallel for schedule(static) num_threads(workers)
#endif
  for(long long block=0;block<static_cast<long long>(blocks);++block) {
    const size_t start=size_t(block)*4096,n=std::min(size_t{4096},pixels-start);
    const uint8_t* in=source+3*start;uint8_t* target=destination+3*start;
#if defined(JSHC_CC_HAVE_AVX2)
    if(kernel==1 && !h.direct16.empty()) {
      const size_t vectorized=n&~size_t{7};
      jshc_channel::avx2_chain_fused16_to(h.direct16.data(),h.direct_dg,h.direct_db,in,target,vectorized);
      if(n!=vectorized) {
        std::memcpy(target+3*vectorized,in+3*vectorized,3*(n-vectorized));
        scalar(h.views.data(),h.views.size(),target+3*vectorized,n-vectorized);
      }
      continue;
    }
#endif
    std::memcpy(target,in,n*3);apply(h,target,n*3,kernel,1);
  }
}
'''+marker)
marker='uint32_t jshc_cc_domain_fast_enabled(const void* handle) {'
s=s.replace(marker,'''int jshc_cc_get_paged_info(const void* handle,jshc_cc_paged_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_paged_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(h.direct16.advice()==0),0,0,uint64_t(reinterpret_cast<uintptr_t>(h.direct16.data())),h.direct16.bytes()};return 0;
}
int jshc_cc_apply_to(void* handle,const uint8_t* source,uint8_t* destination,size_t bytes,int kernel,int threads,char* error,size_t size) {
  try {if(!handle)throw std::runtime_error("空研究句柄");apply_to(*static_cast<Handle*>(handle),source,destination,bytes,kernel,threads);message(error,size,"");return 0;}
  catch(const std::exception& e) {message(error,size,e.what());return 1;}
}
'''+marker)
write('channel_runtime.cpp',s);write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
s=(old/'suffix_cache.hpp').read_text(encoding='utf-8').replace('avx2_chain_direct16','avx2_chain_fused16')
s+='''
namespace jshc_channel {
void avx2_chain_fused16_to(const uint32_t*,int32_t,int32_t,const uint8_t*,uint8_t*,size_t) noexcept;
}
extern "C" {
struct jshc_cc_paged_info {uint32_t version,advised,reserved0,reserved1;uint64_t base,bytes;};
JSHC_CC_API int jshc_cc_get_paged_info(const void*,jshc_cc_paged_info*,size_t);
JSHC_CC_API int jshc_cc_apply_to(void*,const uint8_t*,uint8_t*,size_t,int,int,char*,size_t);
}
''';write('suffix_cache.hpp',s)
s=(old/'channel_avx2.cpp').read_text(encoding='utf-8')
s=s.replace('return _mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,1),4);','return _mm256_i32gather_epi32(reinterpret_cast<const int*>(table),code,2);')
s=s.replace('void output(uint8_t* p,__m256i code,__m256i word,__m256i dg,__m256i db)', 'void output(uint8_t* p,__m256i packed,__m256i dg,__m256i db)')
s=s.replace('  const __m256i packed=_mm256_srlv_epi32(word,_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(1)),4));\n','')
a=s.index('void avx2_chain_direct16(')
s=s[:a]+'''namespace {
inline __attribute__((always_inline)) void run(const uint32_t* table,int32_t dg_min,int32_t db_min,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {
  const __m256i dg=_mm256_set1_epi32(dg_min),db=_mm256_set1_epi32(db_min);size_t p=0;
  for(;p+32<=pixels;p+=32) {
    const __m256i c0=input(source+3*p),c1=input(source+3*p+24),c2=input(source+3*p+48),c3=input(source+3*p+72);
    const __m256i w0=lookup(table,c0),w1=lookup(table,c1),w2=lookup(table,c2),w3=lookup(table,c3);
    output(destination+3*p,w0,dg,db);output(destination+3*p+24,w1,dg,db);output(destination+3*p+48,w2,dg,db);output(destination+3*p+72,w3,dg,db);
  }
  for(;p<pixels;p+=8) {const __m256i c=input(source+3*p);output(destination+3*p,lookup(table,c),dg,db);}
}
}
void avx2_chain_fused16(const uint32_t* table,int32_t dg,int32_t db,uint8_t* data,size_t pixels) noexcept {run(table,dg,db,data,data,pixels);}
void avx2_chain_fused16_to(const uint32_t* table,int32_t dg,int32_t db,const uint8_t* source,uint8_t* destination,size_t pixels) noexcept {run(table,dg,db,source,destination,pixels);}
}
'''
write('channel_avx2.cpp',s)
write('reference_to.cpp','''// 23参考的真实分离输入/输出语义：先复制，再调用未改动的原映射。
#include "channel_runtime.h"
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
extern "C" JSHC_CC_API int jshc_cc_apply_to(void* handle,const uint8_t* source,uint8_t* destination,size_t bytes,int kernel,int threads,char* error,size_t size) {
  if(jshc_cc_apply(handle,nullptr,0,kernel,threads,error,size))return 1;
  if(!bytes)return 0;
  const uintptr_t src=reinterpret_cast<uintptr_t>(source),dst=reinterpret_cast<uintptr_t>(destination);
  if(bytes%3 || !source || !destination || bytes>std::numeric_limits<uintptr_t>::max()-src || bytes>std::numeric_limits<uintptr_t>::max()-dst || (source!=destination && src<dst+bytes && dst<src+bytes)) {
    if(error && size)std::snprintf(error,size,"RGB输入/输出范围无效或部分重叠");return 1;
  }
  if(source!=destination)std::memcpy(destination,source,bytes);
  return jshc_cc_apply(handle,destination,bytes,kernel,threads,error,size);
}
''')
write('outplace_bench.cpp','''// 两库共用同一真实API计时器，计时包括入口验证与所有拷贝/映射，不包含Python。
#include "channel_runtime.h"
#include <chrono>
#include <cstdio>
extern "C" JSHC_CC_API int jshc_cc_apply_to(void*,const uint8_t*,uint8_t*,size_t,int,int,char*,size_t);
extern "C" JSHC_CC_API int jshc_cc_bench_to(void* handle,const uint8_t* source,uint8_t* destination,size_t bytes,int kernel,int threads,size_t repeats,double* seconds,char* error,size_t size) {
  if(!seconds || repeats<1 || repeats>100) {if(error && size)std::snprintf(error,size,"无效输出计时参数");return 1;}
  for(size_t r=0;r<repeats;++r) {
    const auto start=std::chrono::steady_clock::now();
    const int status=jshc_cc_apply_to(handle,source,destination,bytes,kernel,threads,error,size);
    const auto end=std::chrono::steady_clock::now();
    if(status)return status;
    seconds[r]=std::chrono::duration<double>(end-start).count();
  }
  return 0;
}
''')
s=(old/'CMakeLists.txt').read_text(encoding='utf-8').replace('skylake_direct16','skylake_fused16')
s=s.replace('add_library(jshc_skylake_reference SHARED','add_library(jshc_skylake_reference SHARED\n  "${CMAKE_CURRENT_SOURCE_DIR}/reference_to.cpp"\n  "${CMAKE_CURRENT_SOURCE_DIR}/outplace_bench.cpp"')
s=s.replace('add_library(${SKYLAKE_CANDIDATE_TARGET} SHARED "${SKYLAKE_RUNTIME_SOURCE}"','add_library(${SKYLAKE_CANDIDATE_TARGET} SHARED "${SKYLAKE_RUNTIME_SOURCE}"\n  "${CMAKE_CURRENT_SOURCE_DIR}/outplace_bench.cpp"')
write('CMakeLists.txt',s)
plan=json.loads((ROOT/'experiments/skylake-exception-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23争取纯映射及真实输出API吞吐3倍；32MiB大页精确16bit，四包交错与输出融合',base_commit='8355402',candidate='保留原inplace与原bench，新增真实apply_to；23适配器复制后原apply，候选直读输入写输出，不只改计时器',revisions={'reference':23,'candidate':28},cmake_project='experiments/skylake-fused16-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_fused16'])
plan['fused16_policy']={'format':16,'words':2**23+1,'bytes':2**25+4,'alignment':2**21,'packets_unrolled':4,'metadata_expected':32,'goal_ratio_max':1/3,
    'guard':'额外零词保护最后一个16bit输入的4B读取；32MiB主体可THP，尾保护可能普通页，实际smaps单列',
    'output_contract':'源只读、目标等长；完全同址合法、部分重叠/溢出拒绝；目标与旧copy+apply相同，原bench单列保留',
    'scope':'通用AVX2，本机Linux直接对23，官方预算/许可及Skylake仍待确认；3倍未达到继续研究'}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-fused16-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结28及真实输出API，未运行数值或计时')
