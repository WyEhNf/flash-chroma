"""固定27与23的80轮，仍保留3倍apply/copy门槛及全部原始时间。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_paged32_linux.py').read_text(encoding='utf-8').replace('bench_skylake_paged32_linux.py','bench_skylake_pageindex_linux.py').replace('比较26与23','比较27与23').replace('比较26与23','比较27与23')
s=s.replace("state['format']!=32 or state['table_capacity_bytes']!=2**26", "state['format']!=8 or state['table_capacity_bytes']!=2**24").replace('64MiB直表','16MiB精确索引')
(ROOT/'scripts/bench_skylake_pageindex_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_pageindex_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-paged32-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
for key,path in {'plan':'experiments/skylake-pageindex-v1.json','build':'artifacts/skylake-pageindex-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-pageindex-linux-full-v1/results.json','validation':'experiments/skylake-pageindex-validation-v1.json','benchmark_script':'scripts/bench_skylake_pageindex_linux.py'}.items():policy[key]=spec(path)
policy['purpose']='同WSL/AMD的27直接对23，紧凑精确索引+THP；3倍目标和80轮不变'
policy['limits']=[x.replace('64MiB','16MiB') for x in policy['limits']]
(ROOT/'experiments/skylake-pageindex-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定27性能策略，未计时')
