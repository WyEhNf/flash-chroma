"""冻结30完整RGB8与独立逆布局核验；不以几何分析替代实际输出。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_fused16_linux.py').read_text(encoding='utf-8').replace('精确16bit及真实融合输出28','精确分块索引及真实融合输出30')
s=s.replace("direct_state['format']!=16 or direct_state['entries']!=2**23+1 or direct_state['table_capacity_bytes']!=2**25+4", "direct_state['format']!=8 or direct_state['entries']!=2**22 or direct_state['table_capacity_bytes']!=2**24")
s=s.replace("pages_state['bytes']!=2**25+4", "pages_state['bytes']!=2**24").replace('words=(ct.c_uint32*(2**23+1))()', 'words=(ct.c_uint32*(2**22))()')
a=s.index("                    if words[-1]!=0:");b=s.index('                    guard=',a)
s=s[:a]+'''                    old_words=(ct.c_uint32*(2**21))();palette=(ct.c_uint32*256)()
                    copy_palette=d.jshc_cc_copy_palette;copy_palette.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t,ct.POINTER(ct.c_uint32),ct.c_size_t];copy_palette.restype=ct.c_int
                    if copy_palette(h,old_words,len(old_words),palette,256):raise ValueError('原精确调色板读取失败')
                    palette_rgb=tuple(int(v).to_bytes(4,'little')[:3] for v in palette)
                    raw_table=ct.string_at(words,2**24)
                    b_offsets=tuple(((b&252)<<4)|(b&3) for b in range(256))
                    # 独立由R/G/B坐标生成地址，避免复用C++逆地址算法。
                    for r in range(256):
                        for g in range(256):
                            base=((r&252)<<16)|((g&252)<<10)|((r&3)<<4)|((g&3)<<2)
                            ids=bytes(raw_table[base|off] for off in b_offsets)
                            if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                            start=(r*65536+g*256)*3
                            if b''.join(palette_rgb[i] for i in ids)!=cube[start:start+768]:raise AssertionError('独立分块索引全表不符')
                    del old_words,raw_table
'''+s[b:]
s=s.replace("memory['candidate']['single']-memory['reference']['single']==32", "memory['candidate']['single']-memory['reference']['single']==24").replace("memory['candidate']['chain']-memory['reference']['chain']==32+2**25+4", "memory['candidate']['chain']-memory['reference']['chain']==24+2**24")
new='scripts/verify_skylake_tileindex_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v=json.loads((ROOT/'experiments/skylake-fused16-validation-v1.json').read_text(encoding='utf-8'))
v.update(purpose='30完整24组色域、源只读/重叠合同、完整分块ID表独立坐标验证，不测性能',plan_sha256=hashlib.sha256((ROOT/'experiments/skylake-tileindex-v1.json').read_bytes()).hexdigest(),outplace_semantics='参考23复制后原apply；30真实输出；原inplace与legacy bench不变')
v['source_sha256']={k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py')}
(ROOT/'experiments/skylake-tileindex-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('固定30验证器，未运行')
