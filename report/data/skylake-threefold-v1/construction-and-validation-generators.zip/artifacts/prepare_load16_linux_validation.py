"""冻结29完整正确性方案，模型与28一致，但必须重跑新二进制。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
old='scripts/verify_skylake_fused16_linux.py';new='scripts/verify_skylake_load16_linux.py'
s=(ROOT/old).read_text(encoding='utf-8').replace('精确16bit及真实融合输出28','精确16bit独立加载及真实融合输出29')
(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v=json.loads((ROOT/'experiments/skylake-fused16-validation-v1.json').read_text(encoding='utf-8'))
v['purpose']=v['purpose'].replace('28','29');v['outplace_semantics']=v['outplace_semantics'].replace('28','29')
v['plan_sha256']=hashlib.sha256((ROOT/'experiments/skylake-load16-v1.json').read_bytes()).hexdigest()
v['source_sha256']={(new if k==old else k):hashlib.sha256((ROOT/(new if k==old else k)).read_bytes()).hexdigest() for k in v['source_sha256']}
(ROOT/'experiments/skylake-load16-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结29验证器，未运行')
