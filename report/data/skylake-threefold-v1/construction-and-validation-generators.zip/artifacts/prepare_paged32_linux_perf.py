"""绑定Linux构建/完整正确性/原始照片和实际THP条件后，固定唯一比较。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def spec(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
full=json.loads((ROOT/'artifacts/skylake-paged32-linux-full-v1/results.json').read_text(encoding='utf-8'))
assert full['pass'] and full['paged_info']['fully_huge'] and full['independent_table_colors']==2**24
policy={'purpose':'同WSL/AMD环境26直接对23，冻结3倍目标与80轮；不与Windows拼接成绩','plan':spec('experiments/skylake-paged32-v1.json'),
    'build':spec('artifacts/skylake-paged32-linux-build-v1/build.json'),'full_acceptance':spec('artifacts/skylake-paged32-linux-full-v1/results.json'),
    'validation':spec('experiments/skylake-paged32-validation-v1.json'),'benchmark_script':spec('scripts/bench_skylake_paged32_linux.py'),
    'driver':spec('artifacts/skylake-domain-server-v2/artifacts/linux domain-v2/driver/libjshc_server_driver.so'),
    'photos':spec('artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'),
    'expected_output_sha256':'f3c0d9078bbcf069f33060a45021a28985b70c9616493ba9bea1ac2027858528',
    'affinity_cpus':[0,2,4,6],'orders':[['reference','candidate'],['candidate','reference'],['candidate','reference'],['reference','candidate']],
    'thread_orders':[[1,4],[4,1],[1,4],[4,1]],'repeats':5,
    'adoption_gate':{'median_apply_ratio_max':1/3,'median_copy_apply_ratio_max':1/3,'any_process_apply_ratio_max':.9,'median_prepare_plus_100_ratio_max':1},
    'limits':['仅进程内THP建议，不改全局设置或安全权限','候选每次句柄必须由smaps证明64MiB全部THP','同机WSL不是Skylake实测','IO/解码/分配/哈希不计入稳态，但准备单列']}
(ROOT/'experiments/skylake-paged32-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定Linux策略，未计时')
