"""从已验标准库入口派生26完整域/表/页诊断，调用前固定身份。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_exception_linux.py').read_text(encoding='utf-8')
s=s.replace('Linux调色板例外池23','Linux精确RGB32及进程内大页26')
s=s.replace('ROOT = Path(__file__).resolve().parents[1]', 'from paged_table_support import direct_info,paged_info,DirectInfo,PagedInfo\nROOT = Path(__file__).resolve().parents[1]')
s=s.replace("sources = dict(plan['source_sha256']);", "sources = dict(plan['source_sha256']); sources['scripts/paged_table_support.py']=digest(ROOT/'scripts/paged_table_support.py');")
s=s.replace('exception_state = None','exception_state = None; direct_state = None; pages_state = None')
marker='                for mode in operators[name]:'
s=s.replace(marker,'''                if name=='candidate':
                    h=operators[name]['chain'];direct_state=direct_info(d,h);pages_state=paged_info(d,h)
                    if direct_state['enabled']!=1 or direct_state['format']!=32 or direct_state['entries']!=2**24 or direct_state['table_capacity_bytes']!=2**26:
                        raise ValueError('新RGB32直表没有实际启用')
                    if direct_info(d,operators[name]['single'])['enabled']:raise ValueError('单级不应启用直表')
                    if pages_state['bytes']!=2**26 or not pages_state['aligned_2m']:raise ValueError('直表容量/对齐不符')
                    words=(ct.c_uint32*(2**24))();f=d.jshc_cc_copy_direct
                    f.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t];f.restype=ct.c_int
                    if f(h,words,len(words)):raise ValueError('直表快照失败')
                    table_hash=hashlib.sha256(memoryview(words).cast('B')).hexdigest()
                    for start in range(0,2**24,65536):
                        raw=cube[start*3:(start+65536)*3];truth=bytearray(65536*4)
                        truth[0::4]=raw[0::3];truth[1::4]=raw[1::3];truth[2::4]=raw[2::3]
                        if ct.string_at(ct.addressof(words)+start*4,65536*4)!=truth:raise AssertionError('独立RGB32全表不符')
                    guard=(ct.c_uint32*8)(*[0xa7a7a7a7]*8)
                    for handle,pointer,count in [(None,guard,len(words)),(h,guard,len(words)-1),(h,None,len(words))]:
                        if f(handle,pointer,count)!=1 or list(guard)!=[0xa7a7a7a7]*8:raise AssertionError('直表拒绝写入')
                    for structure,function in [(DirectInfo,d.jshc_cc_get_direct_info),(PagedInfo,d.jshc_cc_get_paged_info)]:
                        v=structure();ct.memset(ct.byref(v),0xa7,ct.sizeof(v));before=bytes(v)
                        for handle,pointer,count in [(None,ct.byref(v),ct.sizeof(v)),(h,None,ct.sizeof(v)),(h,ct.byref(v),ct.sizeof(v)-1)]:
                            if function(handle,pointer,count)!=1 or bytes(v)!=before:raise AssertionError('页诊断拒绝写入')
                    del words
                for mode in operators[name]:''')
s=s.replace("'compiled_exceptions':exception_state,", "'compiled_exceptions':exception_state,'direct_info':direct_state,'paged_info':pages_state,'direct_table_sha256':table_hash,'independent_table_colors':2**24,'direct_negative_checks':9,")
path=ROOT/'scripts/verify_skylake_paged32_linux.py';path.write_bytes(s.encode('utf-8'));compile(s,path.name,'exec')
v={'purpose':'26完整域/全部RGB32词独立重建及真实大页状态，非性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-paged32-v1.json').read_bytes()).hexdigest(),
    'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['scripts/verify_skylake_paged32_linux.py','scripts/paged_table_support.py']}}
(ROOT/'experiments/skylake-paged32-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定Linux标准库完整验证；未运行数值')
