"""固定25对23的唯一80轮，吞吐3倍的门槛不变。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_direct16.py').read_text(encoding='utf-8').replace('bench_skylake_direct16.py','bench_skylake_byteindex.py')
s=s.replace("direct['entries']!=2**23", "direct['entries']!=2**22+1").replace("direct['table_capacity_bytes']!=2**25", "direct['table_capacity_bytes']!=2**24+4")
s=s.replace('计时必须启用精确16bit直表','计时必须启用精确字节索引直表')
(ROOT/'scripts/bench_skylake_byteindex.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_byteindex.py','exec')
policy=json.loads((ROOT/'experiments/skylake-direct16-perf-v1.json').read_text(encoding='utf-8'))
def spec(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
policy.update(purpose='25直接对23的一次固定80轮，目标为apply/copy吞吐3倍；未达到继续研究，不改门槛',build_path='artifacts/skylake-byteindex-build-v1')
for key,path in {'plan':'experiments/skylake-byteindex-v1.json','build':'artifacts/skylake-byteindex-build-v1/build.json',
    'full_acceptance':'artifacts/skylake-byteindex-full-v1/results.json','domain_contract':'artifacts/skylake-byteindex-domain-contract-v1/results.json',
    'packed_contract':'artifacts/skylake-byteindex-packed-contract-v1/results.json','signed_contract':'artifacts/skylake-byteindex-signed-contract-v1/results.json',
    'validation':'experiments/skylake-byteindex-validation-v1.json','benchmark_script':'scripts/bench_skylake_byteindex.py'}.items():policy[key]=spec(path)
policy['limits']=[x for x in policy['limits'] if '32MiB' not in x]+['16MiB字节直索引及尾保护，四包交错；完整保留23；只接受同场配对结果，不跨次相乘']
(ROOT/'experiments/skylake-byteindex-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结25的3倍目标比较，未计时')
