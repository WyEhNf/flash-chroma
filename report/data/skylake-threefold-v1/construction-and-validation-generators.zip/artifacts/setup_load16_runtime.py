"""冻结29：28的相同精确表与API，仅以独立标量16bit读取代替硬件gather。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-fused16-runtime';out=ROOT/'experiments/skylake-load16-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_fused16','skylake_load16').replace('avx2_chain_fused16','avx2_chain_load16')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 28;','jshc_cc_revision(void) {return 29;')
    if p.name=='channel_avx2.cpp':
        s=s.replace('#include <immintrin.h>','#include <immintrin.h>\n#include <cstring>')
        a=s.index('inline __attribute__((always_inline)) __m256i input(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''// 三个精确8字节输入读取，展开八个独立16bit载荷；不读取输入尾部之外。
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint8_t* p) {
  uint64_t a,b,c;std::memcpy(&a,p,8);std::memcpy(&b,p+8,8);std::memcpy(&c,p+16,8);
  a=__builtin_bswap64(a);b=__builtin_bswap64(b);c=__builtin_bswap64(c);
  const auto value=[table](uint32_t code) {uint16_t v;std::memcpy(&v,reinterpret_cast<const uint8_t*>(table)+2*size_t(code),2);return int32_t(v);};
  return _mm256_setr_epi32(value(uint32_t(a>>40)),value(uint32_t((a>>16)&0xffffff)),
      value(uint32_t(((a&0xffff)<<8)|(b>>56))),value(uint32_t((b>>32)&0xffffff)),
      value(uint32_t((b>>8)&0xffffff)),value(uint32_t(((b&255)<<16)|(c>>48))),
      value(uint32_t((c>>24)&0xffffff)),value(uint32_t(c&0xffffff)));
}
'''+s[b:]
        a=s.index('    const __m256i c0=input(');b=s.index('    output(destination',a)
        s=s[:a]+'''    const __m256i w0=read(table,source+3*p),w1=read(table,source+3*p+24),w2=read(table,source+3*p+48),w3=read(table,source+3*p+72);
'''+s[b:]
        s=s.replace('const __m256i c=input(source+3*p);output(destination+3*p,lookup(table,c),dg,db);','output(destination+3*p,read(table,source+3*p),dg,db);')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-fused16-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；精确16bit独立载荷代替gather，保留28的真实输出API与THP',candidate='三次64bit输入加载并bswap提取RGB24，八次独立16bit输出加载后用AVX2还原RGB',revisions={'reference':23,'candidate':29},cmake_project='experiments/skylake-load16-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_load16'])
plan['load16_policy']={'input_loads_per_8_pixels':3,'table_load_bits':16,'hardware_gather':False,'unroll_packets':4,'oracle_reads_in_constructor':False,'choice':'只替换已验28硬件gather，不调参数择时'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-fused16-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-load16-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结29，尚未构建或计时')
