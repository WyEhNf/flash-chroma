"""冻结30同机对23的纯apply、旧接口与真实输出基准；不挪用其他候选结果。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_fused16_linux.py').read_text(encoding='utf-8').replace('比较28与23','比较30与23').replace('bench_skylake_fused16_linux.py','bench_skylake_tileindex_linux.py')
s=s.replace("state['format']!=16 or state['table_capacity_bytes']!=2**25+4 or not pages['aligned_2m'] or pages['anon_huge_bytes']<2**25", "state['format']!=8 or state['table_capacity_bytes']!=2**24 or not pages['fully_huge']")
s=s.replace('32MiB精确16bit及主体THP','16MiB精确分块索引及完全THP')
(ROOT/'scripts/bench_skylake_tileindex_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_tileindex_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-fused16-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-tileindex-v1.json','build':'artifacts/skylake-tileindex-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-tileindex-linux-full-v1/results.json','validation':'experiments/skylake-tileindex-validation-v1.json','benchmark_script':'scripts/bench_skylake_tileindex_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('28','30')+'；4×4×4颜色共享缓存行'
policy['limits'][1]='每个候选句柄smaps必须证明16MiB全部THP'
(ROOT/'experiments/skylake-tileindex-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结30计时，未运行')
