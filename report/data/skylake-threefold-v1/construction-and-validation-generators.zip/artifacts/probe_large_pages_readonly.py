"""只读核对Windows大页大小及当前进程是否已有锁页权限；不授予或启用权限。"""
import ctypes as ct,json
from pathlib import Path
k=ct.WinDLL('kernel32',use_last_error=True);a=ct.WinDLL('advapi32',use_last_error=True)
class Luid(ct.Structure):_fields_=[('low',ct.c_uint32),('high',ct.c_int32)]
k.GetCurrentProcess.restype=ct.c_void_p;k.GetLargePageMinimum.restype=ct.c_size_t
a.OpenProcessToken.argtypes=[ct.c_void_p,ct.c_uint32,ct.POINTER(ct.c_void_p)];a.OpenProcessToken.restype=ct.c_int
a.LookupPrivilegeValueW.argtypes=[ct.c_wchar_p,ct.c_wchar_p,ct.POINTER(Luid)];a.LookupPrivilegeValueW.restype=ct.c_int
a.GetTokenInformation.argtypes=[ct.c_void_p,ct.c_int,ct.c_void_p,ct.c_uint32,ct.POINTER(ct.c_uint32)];a.GetTokenInformation.restype=ct.c_int
k.CloseHandle.argtypes=[ct.c_void_p];k.CloseHandle.restype=ct.c_int
handle=ct.c_void_p();luid=Luid();size=ct.c_uint32()
if not a.OpenProcessToken(k.GetCurrentProcess(),8,ct.byref(handle)):raise ct.WinError(ct.get_last_error())
try:
    if not a.LookupPrivilegeValueW(None,'SeLockMemoryPrivilege',ct.byref(luid)):raise ct.WinError(ct.get_last_error())
    a.GetTokenInformation(handle,3,None,0,ct.byref(size));raw=ct.create_string_buffer(size.value)
    if not a.GetTokenInformation(handle,3,raw,len(raw),ct.byref(size)):raise ct.WinError(ct.get_last_error())
    count=ct.c_uint32.from_buffer(raw).value;found=False;enabled=False
    for i in range(count):
        offset=4+i*12;v=Luid.from_buffer(raw,offset)
        if v.low==luid.low and v.high==luid.high:
            found=True;enabled=bool(ct.c_uint32.from_buffer(raw,offset+8).value&2)
    result={'purpose':__doc__,'large_page_minimum_bytes':k.GetLargePageMinimum(),'lock_memory_privilege_present':found,'lock_memory_privilege_enabled':enabled,
        'privilege_or_system_changes':False,'native_pixel_calls':0,'performance_calls':0}
    p=Path(__file__).resolve().parent/'skylake-large-pages-readonly-v1.json'
    if p.exists():raise ValueError('不得覆盖只读回执')
    p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))
finally:k.CloseHandle(handle)
