"""固定28的完整inplace/outplace、全表与新ABI验证；不开始计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_paged32_linux.py').read_text(encoding='utf-8').replace('精确RGB32及进程内大页26','精确16bit及真实融合输出28')
s=s.replace('from paged_table_support import','from outplace_support import apply_to,reject_to\nfrom paged_table_support import',1)
s=s.replace("sources['scripts/paged_table_support.py']=digest(ROOT/'scripts/paged_table_support.py');", "sources['scripts/paged_table_support.py']=digest(ROOT/'scripts/paged_table_support.py'); sources['scripts/outplace_support.py']=digest(ROOT/'scripts/outplace_support.py');")
s=s.replace('direct_state = None; pages_state = None','direct_state = None; pages_state = None; out_hashes = {}; out_counts = {}; out_finite=0; out_negative=0')
s=s.replace("direct_state['format']!=32 or direct_state['entries']!=2**24 or direct_state['table_capacity_bytes']!=2**26", "direct_state['format']!=16 or direct_state['entries']!=2**23+1 or direct_state['table_capacity_bytes']!=2**25+4")
s=s.replace("pages_state['bytes']!=2**26", "pages_state['bytes']!=2**25+4")
s=s.replace('words=(ct.c_uint32*(2**24))()', 'words=(ct.c_uint32*(2**23+1))()')
a=s.index('                    for start in range(0,2**24,65536):');b=s.index('                    guard=',a)
s=s[:a]+'''                    if words[-1]!=0:raise AssertionError('末端零保护词不符')
                    for start in range(0,2**24,65536):
                        raw=cube[start*3:(start+65536)*3];truth=bytearray(65536*2)
                        red=raw[0::3];green=raw[1::3];blue=raw[2::3];truth[0::2]=red
                        high=[]
                        for r,g,b in zip(red,green,blue):
                            dg=g-r-direct_state['dg_min'];db=b-r-direct_state['db_min']
                            if not (0<=dg<=15 and 0<=db<=15):raise AssertionError('独立通道差范围不符')
                            high.append(dg|(db<<4))
                        truth[1::2]=bytes(high)
                        if ct.string_at(ct.addressof(words)+start*2,65536*2)!=truth:raise AssertionError('独立16bit全表不符')
'''+s[b:]
s=s.replace("key = f'{name}_{mode}_{kernel}_{threads}'; hashes[key] = hashlib.sha256(); counts[key] = 0", "key = f'{name}_{mode}_{kernel}_{threads}'; hashes[key] = hashlib.sha256(); counts[key] = 0;out_hashes[key]=hashlib.sha256();out_counts[key]=0")
s=s.replace("                                finite += 1", "                                finite += 1\n                                if apply_to(d,operators[name][mode],source,kernel,threads,offset,3-offset)!=expected:raise AssertionError('分离有限输出不同')\n                                if apply_to(d,operators[name][mode],source,kernel,threads,offset,offset,same=True)!=expected:raise AssertionError('同址输出不同')\n                                out_finite+=2")
s=s.replace("            # 65536像素", "            for name,d in libraries.items():\n                for h in operators[name].values():out_negative+=reject_to(d,h)\n            # 65536像素")
needle="                            key = f'{name}_{mode}_{kernel}_{threads}'; hashes[key].update(actual); counts[key] += 65536"
assert needle in s
s=s.replace(needle,needle+"\n                            actual_to=apply_to(d,operators[name][mode],source,kernel,threads,1,3)\n                            if actual_to!=expected:raise AssertionError('完整分离输出不同')\n                            out_hashes[key].update(actual_to);out_counts[key]+=65536")
s=s.replace("            outputs = {key: value.hexdigest() for key, value in hashes.items()}", "            outputs = {key: value.hexdigest() for key, value in hashes.items()};out_outputs={key:value.hexdigest() for key,value in out_hashes.items()}")
s=s.replace("'direct_info':direct_state,", "'outplace_full_pixels':out_counts,'outplace_output_sha256':out_outputs,'outplace_finite_comparisons':out_finite,'outplace_negative_checks':out_negative,'direct_info':direct_state,")
s=s.replace("    for name, sha in sources.items():\n        if digest(ROOT/name) != sha:\n            raise ValueError('核验期间源码改变：'+name)", "    assert memory['candidate']['single']-memory['reference']['single']==32\n    assert memory['candidate']['chain']-memory['reference']['chain']==32+2**25+4\n    for name, sha in sources.items():\n        if digest(ROOT/name) != sha:\n            raise ValueError('核验期间源码改变：'+name)")
path=ROOT/'scripts/verify_skylake_fused16_linux.py';path.write_bytes(s.encode('utf-8'));compile(s,path.name,'exec')
names=['scripts/verify_skylake_fused16_linux.py','scripts/paged_table_support.py','scripts/outplace_support.py']
v={'purpose':'28完整24组色域、源只读与重叠合同、完整16bit表独立重建，不测性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-fused16-v1.json').read_bytes()).hexdigest(),
    'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names},'outplace_semantics':'参考23复制后原apply；28真实融合入口；原inplace与legacy bench不变'}
(ROOT/'experiments/skylake-fused16-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定28验证器，尚未调用数值或计时')
