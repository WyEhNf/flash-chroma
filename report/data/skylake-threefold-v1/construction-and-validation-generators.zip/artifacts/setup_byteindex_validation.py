"""在调用前固定25的独立表重建与完整合同，不修改24回执。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('verify_skylake_direct16_domain.py','verify_skylake_byteindex_domain.py'),('verify_skylake_direct16_signed.py','verify_skylake_byteindex_signed.py'),('accept_skylake_direct16.py','accept_skylake_byteindex.py')]:
    s=(ROOT/'scripts'/old).read_text(encoding='utf-8').replace(old,new)
    if 'signed' in new:s=s.replace("direct['table_capacity_bytes']==2**25", "direct['table_capacity_bytes']==2**24+4")
    (ROOT/'scripts'/new).write_bytes(s.encode('utf-8'))
s=(ROOT/'scripts/verify_skylake_direct16.py').read_text(encoding='utf-8').replace('verify_skylake_direct16.py','verify_skylake_byteindex.py')
s=s.replace('独立重建全部16bit直表，核验两包流水、奇偶半词、尾部和只读ABI拒绝；不测速。','独立重建全部精确字节索引，核验四包交错、非对齐gather尾保护与只读ABI；不测速。')
s=s.replace('from palette_support import metadata_bytes','from palette_support import metadata_bytes, tables as palette_tables')
s=s.replace("state['format']==16 and len(words)==2**23 and state['table_capacity_bytes']==2**25", "state['format']==8 and len(words)==2**22+1 and state['table_capacity_bytes']==2**24+4")
a=s.index('        for start in range(0,256**3,65536):');b=s.index('        rng=',a)
s=s[:a]+'''        _,palette=palette_tables(cand)
        assert words[-1]==0
        for start in range(0,256**3,65536):
            w=words[start//4:(start+65536)//4]
            ids=((w[:,None]>>np.array([0,8,16,24],np.uint32))&255).ravel()
            actual=palette[ids]
            x=np.asarray(expected[start:start+65536])
            truth=x[:,0].astype(np.uint32)|(x[:,1].astype(np.uint32)<<8)|(x[:,2].astype(np.uint32)<<16)
            np.testing.assert_array_equal(actual,truth)
'''+s[b:]
s=s.replace('直表独立重建通过：16M颜色','字节直索引重建通过：16M颜色')
(ROOT/'scripts/verify_skylake_byteindex.py').write_bytes(s.encode('utf-8'))
names=['direct16_support.py','verify_skylake_byteindex.py','verify_skylake_byteindex_domain.py','verify_skylake_byteindex_signed.py','accept_skylake_byteindex.py']
for name in names:compile((ROOT/'scripts'/name).read_text(encoding='utf-8'),name,'exec')
v={'purpose':'相对23的字节直索引，目标仍为3倍，不把局部改善当作完成','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-byteindex-v1.json').read_bytes()).hexdigest(),
   'source_sha256':{'scripts/'+n:hashlib.sha256((ROOT/'scripts'/n).read_bytes()).hexdigest() for n in names}}
(ROOT/'experiments/skylake-byteindex-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结25的数值验证身份，尚未运行')
