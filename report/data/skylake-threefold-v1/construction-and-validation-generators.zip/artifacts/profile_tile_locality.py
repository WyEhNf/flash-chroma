"""只读几何分析：相邻32像素在固定16MiB索引中的缓存行数；不是内核性能测试或选优扫描。"""
from pathlib import Path
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'
if hashlib.sha256(source.read_bytes()).hexdigest()!='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd':raise ValueError('照片输入身份错误')
data=np.memmap(source,dtype=np.uint8,mode='r').reshape(-1,3)
counts={'linear':0,'tile4':0};packets=0
for start in range(0,len(data),2**20):
    x=data[start:start+2**20].astype(np.uint32);c=(x[:,0]<<16)|(x[:,1]<<8)|x[:,2]
    tile=(c&0xfc0003)|((c&0x00fc00)<<2)|((c&0x0000fc)<<4)|((c&0x030000)>>12)|((c&0x000300)>>6)
    for name,index in [('linear',c),('tile4',tile)]:
        lines=np.sort((index>>6).reshape(-1,32),axis=1)
        counts[name]+=int(np.count_nonzero(lines[:,1:]!=lines[:,:-1]))+len(lines)
    packets+=len(c)//32
result={'purpose':__doc__,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'packets_32_pixels':packets,'line_size':64,'bytes_per_entry':1,'mean_unique_cachelines_per_32_pixels':{k:v/packets for k,v in counts.items()},'limitation':'只统计包内空间复用；未模拟包间缓存、TLB或指令成本，不能直接推断提速'}
out=ROOT/'artifacts/skylake-tile-locality-v1';out.mkdir(exist_ok=False)
(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(result)
