"""固定27全表独立解码及实际THP验证，不改26的任何回执。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_paged32_linux.py').read_text(encoding='utf-8').replace('精确RGB32及进程内大页26','精确字节索引及进程内大页27')
s=s.replace("direct_state['format']!=32 or direct_state['entries']!=2**24 or direct_state['table_capacity_bytes']!=2**26", "direct_state['format']!=8 or direct_state['entries']!=2**22 or direct_state['table_capacity_bytes']!=2**24")
s=s.replace("pages_state['bytes']!=2**26", "pages_state['bytes']!=2**24")
s=s.replace('words=(ct.c_uint32*(2**24))()', 'words=(ct.c_uint32*(2**22))()')
a=s.index('                    for start in range(0,2**24,65536):');b=s.index('                    guard=',a)
s=s[:a]+'''                    old_words=(ct.c_uint32*(2**21))();palette=(ct.c_uint32*256)()
                    copy_palette=d.jshc_cc_copy_palette;copy_palette.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t,ct.POINTER(ct.c_uint32),ct.c_size_t];copy_palette.restype=ct.c_int
                    if copy_palette(h,old_words,len(old_words),palette,256):raise ValueError('原精确调色板读取失败')
                    palette_rgb=tuple(int(v).to_bytes(4,'little')[:3] for v in palette)
                    for start in range(0,2**24,65536):
                        ids=ct.string_at(ct.addressof(words)+start,65536)
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                        truth=cube[start*3:(start+65536)*3]
                        if b''.join(palette_rgb[i] for i in ids)!=truth:raise AssertionError('独立字节索引全表不符')
                    del old_words
'''+s[b:]
s=s.replace('新RGB32直表没有实际启用','新字节索引没有实际启用')
path=ROOT/'scripts/verify_skylake_pageindex_linux.py';path.write_bytes(s.encode('utf-8'));compile(s,path.name,'exec')
v={'purpose':'27全部16M字节索引独立解码/完整域/THP状态，非性能','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-pageindex-v1.json').read_bytes()).hexdigest(),
 'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['scripts/verify_skylake_pageindex_linux.py','scripts/paged_table_support.py']}}
(ROOT/'experiments/skylake-pageindex-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定27数值验证身份，未运行')
