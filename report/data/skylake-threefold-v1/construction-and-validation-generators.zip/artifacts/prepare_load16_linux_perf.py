"""29复用28冻结配对计时设计，不能复用其数值。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_fused16_linux.py').read_text(encoding='utf-8').replace('比较28与23','比较29与23').replace('bench_skylake_fused16_linux.py','bench_skylake_load16_linux.py')
(ROOT/'scripts/bench_skylake_load16_linux.py').write_bytes(s.encode('utf-8'));compile(s,'bench_skylake_load16_linux.py','exec')
policy=json.loads((ROOT/'experiments/skylake-fused16-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-load16-v1.json','build':'artifacts/skylake-load16-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-load16-linux-full-v1/results.json','validation':'experiments/skylake-load16-validation-v1.json','benchmark_script':'scripts/bench_skylake_load16_linux.py'}.items():policy[key]=spec(p)
policy['purpose']=policy['purpose'].replace('28','29')+'；独立16bit读取'
(ROOT/'experiments/skylake-load16-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结29计时，未运行')
