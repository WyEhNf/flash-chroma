"""固定24的资源/完整验收工具；保留所有23代码不变。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
for old,new in [('verify_skylake_exception_domain.py','verify_skylake_direct16_domain.py'),('verify_skylake_exception_signed.py','verify_skylake_direct16_signed.py'),('accept_skylake_exception.py','accept_skylake_direct16.py')]:
    s=(ROOT/'scripts'/old).read_text(encoding='utf-8').replace(old,new)
    s=s.replace('from exception_support import info as exception_info, table as exception_table, storage, ExceptionInfo','from exception_support import info as exception_info, table as exception_table, ExceptionInfo\nfrom direct16_support import info as direct_info, storage')
    s=s.replace("'scripts/exception_support.py'", "'scripts/direct16_support.py','scripts/exception_support.py'")
    if new.startswith('accept'):
        s=s.replace('exception_record = None','exception_record = None; direct_record = None')
        s=s.replace("exception_record={mode:exception_info(h) for mode,h in operators['candidate'].items()}","exception_record={mode:exception_info(h) for mode,h in operators['candidate'].items()};direct_record={mode:direct_info(h) for mode,h in operators['candidate'].items()}")
        s=s.replace("'compiled_exceptions':exception_record,", "'compiled_exceptions':exception_record,'direct_info':direct_record,")
    (ROOT/'scripts'/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
plan=ROOT/'experiments/skylake-direct16-v1.json'
names=['direct16_support.py','verify_skylake_direct16.py','verify_skylake_direct16_domain.py','verify_skylake_direct16_signed.py','accept_skylake_direct16.py']
v={'purpose':'相对23的精确16bit完整域正确性，3倍目标不因局部改善而降低','plan_sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),
   'source_sha256':{'scripts/'+n:hashlib.sha256((ROOT/'scripts'/n).read_bytes()).hexdigest() for n in names},'new_fits':0}
(ROOT/'experiments/skylake-direct16-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定直表验证身份；未执行数值')
