"""冻结25：16MiB精确字节索引与四包交错，不改23或24。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-exception-runtime';out=ROOT/'experiments/skylake-byteindex-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8').replace('std::vector<uint32_t> exceptions;','std::vector<uint32_t> exceptions;\n  std::vector<uint32_t> direct_index;')
s=s.replace('if(!h.compiled.empty())jshc_channel::avx2_chain_exception','if(!h.direct_index.empty())jshc_channel::avx2_chain_byteindex(h.direct_index.data(),h.output_palette.data(),data,vectorized);\n        else if(!h.compiled.empty())jshc_channel::avx2_chain_exception')
marker='    h.compiled.swap(packed);h.exceptions.swap(exception_words);info.enabled=1;info.reason=0;'
s=s.replace(marker,marker+'''
    try {
      // 四个输入ID按小端打包；最后一个零词保护字节偏移gather的末端4字节读取。
      std::vector<uint32_t> direct((size_t{1}<<22)+1,0);
#if defined(_OPENMP)
#pragma omp parallel for schedule(static) num_threads(4)
#endif
      for(long long group=0;group<(1LL<<22);++group) {
        uint32_t word=0;
        for(unsigned k=0;k<4;++k) {
          const size_t i=size_t(group)*4+k;
          const uint32_t v=uint32_t(rgb[3*i])|(uint32_t(rgb[3*i+1])<<8)|(uint32_t(rgb[3*i+2])<<16);
          word|=uint32_t(lookup[v])<<(8*k);
        }
        direct[size_t(group)]=word;
      }
      h.direct_index.swap(direct);info.temporary_peak_bytes+=h.direct_index.capacity()*sizeof(uint32_t);
    }catch(const std::bad_alloc&) {} // 新直表失败时保留完整23，不改变输出。
''')
s=s.replace('jshc_cc_revision(void) {return 23;','jshc_cc_revision(void) {return 25;')
s=s.replace('(h.compiled.capacity()+h.exceptions.capacity())*sizeof(uint32_t)','(h.compiled.capacity()+h.exceptions.capacity()+h.direct_index.capacity())*sizeof(uint32_t)')
marker='uint32_t jshc_cc_domain_fast_enabled(const void* handle) {'
s=s.replace(marker,'''int jshc_cc_get_direct_info(const void* handle,jshc_cc_direct_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_direct_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(!h.direct_index.empty()),8,0,h.direct_index.size(),h.direct_index.capacity()*sizeof(uint32_t),0,0};return 0;
}
int jshc_cc_copy_direct(const void* handle,uint32_t* output,size_t entries) {
  if(!handle)return 1;const auto& h=*static_cast<const Handle*>(handle);
  if(entries!=h.direct_index.size() || (entries && !output))return 1;
  if(entries)std::memcpy(output,h.direct_index.data(),entries*sizeof(uint32_t));return 0;
}
'''+marker)
write('channel_runtime.cpp',s);write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
s=(ROOT/'experiments/skylake-direct16-runtime/suffix_cache.hpp').read_text(encoding='utf-8').replace('void avx2_chain_direct16(const uint32_t*,int32_t,int32_t,uint8_t*,size_t) noexcept;','void avx2_chain_byteindex(const uint32_t*,const uint32_t*,uint8_t*,size_t) noexcept;')
write('suffix_cache.hpp',s)
write('channel_avx2.cpp','''// 精确全域字节索引：四包独立读取先行，所有地址由RGB24和尾保护词覆盖。
#include "suffix_cache.hpp"
#include <immintrin.h>
namespace jshc_channel {
namespace {
inline __attribute__((always_inline)) __m256i input(const uint8_t* p) {
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m128i hi=_mm_alignr_epi8(last,lo,12);
  return _mm256_shuffle_epi8(_mm256_inserti128_si256(_mm256_castsi128_si256(lo),hi,1),
    _mm256_setr_epi8(2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1,2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1));
}
inline __attribute__((always_inline)) __m256i ids(const uint32_t* table,__m256i code) {
  return _mm256_and_si256(_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),code,1),_mm256_set1_epi32(255));
}
inline __attribute__((always_inline)) __m256i rgb(const uint32_t* palette,__m256i index) {
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(palette),index,4);
}
inline __attribute__((always_inline)) void output(uint8_t* p,__m256i value) {
  const __m256i bytes=_mm256_shuffle_epi8(value,_mm256_setr_epi8(0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1,0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1));
  const __m128i lo=_mm256_castsi256_si128(bytes),hi=_mm256_extracti128_si256(bytes,1);
  _mm_storeu_si128(reinterpret_cast<__m128i*>(p),_mm_or_si128(lo,_mm_slli_si128(hi,12)));
  _mm_storel_epi64(reinterpret_cast<__m128i*>(p+16),_mm_srli_si128(hi,4));
}
}
void avx2_chain_byteindex(const uint32_t* table,const uint32_t* palette,uint8_t* data,size_t pixels) noexcept {
  size_t p=0;
  for(;p+32<=pixels;p+=32) {
    const __m256i c0=input(data+3*p),c1=input(data+3*p+24),c2=input(data+3*p+48),c3=input(data+3*p+72);
    const __m256i i0=ids(table,c0),i1=ids(table,c1),i2=ids(table,c2),i3=ids(table,c3);
    const __m256i r0=rgb(palette,i0),r1=rgb(palette,i1),r2=rgb(palette,i2),r3=rgb(palette,i3);
    output(data+3*p,r0);output(data+3*p+24,r1);output(data+3*p+48,r2);output(data+3*p+72,r3);
  }
  for(;p<pixels;p+=8) {const __m256i c=input(data+3*p);output(data+3*p,rgb(palette,ids(table,c)));}
}
}
''')
s=(ROOT/'experiments/skylake-direct16-runtime/CMakeLists.txt').read_text(encoding='utf-8').replace('skylake_direct16','skylake_byteindex')
write('CMakeLists.txt',s)
plan=json.loads((ROOT/'experiments/skylake-exception-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标：紧凑字节直索引及四包交错的唯一固定候选',base_commit='8355402',candidate='全RGB域每色一个精确palette ID，32bit非对齐gather的末端零保护词，不改原23回退或精度',revisions={'reference':23,'candidate':25},cmake_project='experiments/skylake-byteindex-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_byteindex'])
plan['byteindex_policy']={'format':8,'words':2**22+1,'bytes':2**24+4,'packets_unrolled':4,'guard_words':1,'metadata_expected':24,'goal_ratio_max':1/3,'scope':'通用AVX2，不假定AVX512；结果待测，不放宽3倍目标'}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-byteindex-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定25与23参考，未运行映射或计时')
