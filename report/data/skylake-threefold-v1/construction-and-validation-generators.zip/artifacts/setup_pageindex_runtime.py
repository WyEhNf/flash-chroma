"""冻结27：25的紧凑索引结合进程内THP，改为对齐词读取，参考仍23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-byteindex-runtime';out=ROOT/'experiments/skylake-pageindex-runtime';out.mkdir(exist_ok=False)
def write(n,s):(out/n).write_bytes(s.encode('utf-8'))
s=(old/'channel_runtime.cpp').read_text(encoding='utf-8').replace('#include "suffix_cache.hpp"','#include "suffix_cache.hpp"\n#include "aligned_table.hpp"')
s=s.replace('std::vector<uint32_t> direct_index;', 'jshc_channel::AlignedTable direct_index;').replace('avx2_chain_byteindex','avx2_chain_pageindex')
s=s.replace('std::vector<uint32_t> direct((size_t{1}<<22)+1,0);','h.direct_index.allocate(size_t{1}<<22);')
s=s.replace('direct[size_t(group)]=word;','h.direct_index.data()[size_t(group)]=word;').replace('h.direct_index.swap(direct);','')
s=s.replace('h.direct_index.capacity()*sizeof(uint32_t)','h.direct_index.bytes()')
s=s.replace('(h.compiled.capacity()+h.exceptions.capacity()+h.direct_index.capacity())*sizeof(uint32_t)','(h.compiled.capacity()+h.exceptions.capacity())*sizeof(uint32_t)+h.direct_index.bytes()')
s=s.replace('jshc_cc_revision(void) {return 25;','jshc_cc_revision(void) {return 27;')
s=s.replace('uint32_t jshc_cc_domain_fast_enabled(const void* handle) {','''int jshc_cc_get_paged_info(const void* handle,jshc_cc_paged_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_paged_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,uint32_t(h.direct_index.advice()==0),0,0,uint64_t(reinterpret_cast<uintptr_t>(h.direct_index.data())),h.direct_index.bytes()};return 0;
}
uint32_t jshc_cc_domain_fast_enabled(const void* handle) {''')
s=s.replace('四个输入ID按小端打包；最后一个零词保护字节偏移gather的末端4字节读取。','四个输入ID按小端打包；对齐词gather加移位，不再需要末端额外词。')
write('channel_runtime.cpp',s);write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
write('aligned_table.hpp',(ROOT/'experiments/skylake-paged32-runtime/aligned_table.hpp').read_text(encoding='utf-8'))
s=(old/'suffix_cache.hpp').read_text(encoding='utf-8').replace('avx2_chain_byteindex','avx2_chain_pageindex')
s+='''
extern "C" {
struct jshc_cc_paged_info {uint32_t version,advised,reserved0,reserved1;uint64_t base,bytes;};
JSHC_CC_API int jshc_cc_get_paged_info(const void*,jshc_cc_paged_info*,size_t);
}
''';write('suffix_cache.hpp',s)
s=(old/'channel_avx2.cpp').read_text(encoding='utf-8').replace('avx2_chain_byteindex','avx2_chain_pageindex')
s=s.replace('return _mm256_and_si256(_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),code,1),_mm256_set1_epi32(255));', '''const __m256i word=_mm256_i32gather_epi32(reinterpret_cast<const int*>(table),_mm256_srli_epi32(code,2),4);
  const __m256i shift=_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(3)),3);
  return _mm256_and_si256(_mm256_srlv_epi32(word,shift),_mm256_set1_epi32(255));''')
s=s.replace('所有地址由RGB24和尾保护词覆盖','按RGB24读取合法对齐词');write('channel_avx2.cpp',s)
write('CMakeLists.txt',(old/'CMakeLists.txt').read_text(encoding='utf-8').replace('skylake_byteindex','skylake_pageindex'))
plan=json.loads((ROOT/'experiments/skylake-exception-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；16MiB精确索引与进程内THP，对齐词gather；通用AVX2',base_commit='8355402',candidate='将25紧凑索引与26已验THP分配结合，四包交错；不是把两次收益相乘',revisions={'reference':23,'candidate':27},cmake_project='experiments/skylake-pageindex-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_pageindex'])
plan['pageindex_policy']={'format':8,'words':2**22,'bytes':2**24,'alignment':2**21,'packets_unrolled':4,'metadata_expected':24,'goal_ratio_max':1/3,
    'page_policy':'仅对象自有对齐分配MADV_HUGEPAGE；实际smaps另核验，不改系统设置/权限','scope':'同机Linux/AMD对23，不与Windows拼接；未达目标就保留部分结果继续研究'}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-pageindex-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结27，未运行数值或性能')
