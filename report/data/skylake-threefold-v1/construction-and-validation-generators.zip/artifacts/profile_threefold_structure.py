"""只读完整域标签的无损表示结构，为3倍吞吐目标选择固定候选；不运行映射或计时。"""
from pathlib import Path
import json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'artifacts/skylake-threefold-profile-v1';out.mkdir(exist_ok=False)
cube=ROOT/'artifacts/cinema-current-anchor-accept-v1/cube.rgb'
rgb=np.memmap(cube,np.uint8,'r',shape=(256**3,3))
packed=rgb[:,0].astype(np.uint32)|(rgb[:,1].astype(np.uint32)<<8)|(rgb[:,2].astype(np.uint32)<<16)
palette=np.unique(packed);prgb=np.column_stack([palette&255,(palette>>8)&255,palette>>16]).astype(np.int16)
cache=np.unique(np.fromfile(ROOT/'artifacts/skylake-server-matrix-v1/server-inputs/cache-gold.u32',dtype='<u4'))
result={'purpose':__doc__,'cube_sha256':hashlib.sha256(cube.read_bytes()).hexdigest(),'global_values':len(palette),'cache_values':len(cache),
    'channel_unique_counts':[len(np.unique(prgb[:,c])) for c in range(3)],'channel_ranges':[[int(prgb[:,c].min()),int(prgb[:,c].max())] for c in range(3)],
    'differences':{'G_R':np.unique(prgb[:,1]-prgb[:,0]).tolist(),'B_R':np.unique(prgb[:,2]-prgb[:,0]).tolist()},
    'palette_rgb':prgb.tolist(),'native_calls':0,'performance_calls':0}
ids=np.searchsorted(cache,packed).astype(np.uint8)
result['exact_block_dictionary']=[]
for width in (4,8,16):
    blocks=ids.reshape(-1,width)
    keys=np.ascontiguousarray(blocks).view(np.dtype((np.void,width))).ravel()
    unique=np.unique(keys)
    result['exact_block_dictionary'].append({'width':width,'unique_blocks':len(unique),'dictionary_bytes':len(unique)*width,
        'index_bits':16 if len(unique)<=65535 else 32,'index_bytes':len(keys)*(2 if len(unique)<=65535 else 4)})
result['R_determines_GB']=len(np.unique(prgb[:,0]))==len(prgb)
result['G_determines_RB']=len(np.unique(prgb[:,1]))==len(prgb)
result['B_determines_RG']=len(np.unique(prgb[:,2]))==len(prgb)
(out/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='palette_rgb'},ensure_ascii=False,indent=2))
print('调色板前32项',prgb[:32].tolist())
