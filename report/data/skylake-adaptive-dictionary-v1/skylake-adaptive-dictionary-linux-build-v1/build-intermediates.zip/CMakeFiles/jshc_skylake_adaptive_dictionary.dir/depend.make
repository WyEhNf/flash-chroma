# Empty dependencies file for jshc_skylake_adaptive_dictionary.
# This may be replaced when dependencies are built.
