"""只读抓取协作记录与CI，凭据只在内存用于GitHub请求，不写入或输出。"""
import datetime
import json
from pathlib import Path
import subprocess
import sys
import urllib.request

p = subprocess.run(["git","credential","fill"],input="protocol=https\nhost=github.com\n\n",text=True,capture_output=True)
if p.returncode:raise SystemExit("GitHub 凭据入口不可用")
credential = dict(line.split("=",1) for line in p.stdout.splitlines() if "=" in line)
query = '''query { repository(owner:"WyEhNf",name:"flash-chroma") {
  nameWithOwner defaultBranchRef { name target { oid ... on Commit { tree { oid } } } }
  mergeCommitAllowed squashMergeAllowed rebaseMergeAllowed
  discussion(number:4) { url title body updatedAt comments(first:30) {
    totalCount pageInfo { hasNextPage endCursor } nodes { url body author { login }
      replies(first:30) { pageInfo { hasNextPage endCursor } nodes { url body author { login } } }
    }
  } }
  pullRequests(first:40,states:OPEN,orderBy:{field:UPDATED_AT,direction:DESC}) {
    pageInfo { hasNextPage endCursor } nodes {
      number url title body baseRefName baseRefOid headRefName headRefOid isDraft mergeable reviewDecision author { login }
      comments(first:30) { pageInfo { hasNextPage endCursor } nodes { url body updatedAt author { login } } }
      reviews(first:30) { pageInfo { hasNextPage endCursor } nodes { url body state submittedAt author { login } } }
      reviewThreads(first:30) { pageInfo { hasNextPage endCursor } nodes { isResolved path
        comments(first:30) { pageInfo { hasNextPage endCursor } nodes { url body author { login } } }
      } }
      commits(last:1) { nodes { commit { oid tree { oid } statusCheckRollup { state
        contexts(first:30) { pageInfo { hasNextPage endCursor } nodes {
          ... on CheckRun { name status conclusion detailsUrl }
          ... on StatusContext { context state targetUrl }
        } }
      } } } }
    }
  }
} }'''
request = urllib.request.Request("https://api.github.com/graphql",data=json.dumps({"query":query}).encode(),headers={
    "Authorization":"Bearer "+credential["password"],"User-Agent":"Codex-PR-audit","Content-Type":"application/json"})
with urllib.request.urlopen(request,timeout=45) as response:out = json.load(response)
if out.get("errors"):raise SystemExit("查询错误："+json.dumps(out["errors"],ensure_ascii=False))
def check(value):
    if isinstance(value,dict):
        if value.get("hasNextPage"):raise ValueError("存在未读分页，不能发布完整审计结论")
        for item in value.values():check(item)
    elif isinstance(value,list):
        for item in value:check(item)
check(out)
record = {"observed_at":datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),"response":out}
Path(sys.argv[1]).write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
repository = out["data"]["repository"]
print(json.dumps({"default":repository["defaultBranchRef"],"merge_allowed":repository["mergeCommitAllowed"],
    "discussion_comments":repository["discussion"]["comments"]["totalCount"],"prs":[{"n":pr["number"],"head":pr["headRefOid"],
        "base":pr["baseRefName"],"draft":pr["isDraft"],"author":pr["author"]["login"],"review":pr["reviewDecision"],
        "checks":pr["commits"]["nodes"][0]["commit"]["statusCheckRollup"]} for pr in repository["pullRequests"]["nodes"]]},ensure_ascii=False))
