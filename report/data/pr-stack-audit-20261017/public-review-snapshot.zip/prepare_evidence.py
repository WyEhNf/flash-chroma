"""只读核对原PR链、CI及最终树，保存公开审计快照和摘要，不执行合并。"""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
folder = root / "artifacts/pr-stack-audit-20261017"
out = root / "report/data/pr-stack-audit-20261017"
out.mkdir(parents=True,exist_ok=False)
raw = json.loads((folder / "snapshot-before.json").read_text(encoding="utf-8"))
repository = raw["response"]["data"]["repository"]
prs = sorted(repository["pullRequests"]["nodes"],key=lambda p:p["number"])
assert [p["number"] for p in prs] == list(range(12,35))
def git(*args):return subprocess.check_output(["git",*args],text=True).strip()
tip = prs[-1]["headRefOid"]
required = {"FreeRTOS / cortex-m3 / QEMU","FreeRTOS / riscv32 / QEMU","Linux / Cortex-A53 / QEMU",
    "correctness (test)","correctness (test-scalar)","correctness (Docker)"}
rows,comments = [],[]
for i,pr in enumerate(prs):
    assert pr["author"]["login"] == "WyEhNf"
    subprocess.run(["git","merge-base","--is-ancestor",pr["headRefOid"],tip],check=True)
    assert pr["baseRefOid"] == (prs[i-1]["headRefOid"] if i else repository["defaultBranchRef"]["target"]["oid"])
    assert not pr["reviews"]["nodes"] and not pr["reviewThreads"]["nodes"]
    state = pr["commits"]["nodes"][0]["commit"]["statusCheckRollup"]
    checks = state["contexts"]["nodes"]
    assert state["state"] == "SUCCESS" and {c["name"] for c in checks} == required
    assert all(c["status"] == "COMPLETED" and c["conclusion"] == "SUCCESS" for c in checks)
    for c in pr["comments"]["nodes"]:
        comments.append({"pr":pr["number"],"url":c["url"],"author":c["author"]["login"],"updated_at":c["updatedAt"],"body_sha256":hashlib.sha256(c["body"].encode()).hexdigest()})
    rows.append({"pr":pr["number"],"url":pr["url"],"head":pr["headRefOid"],"head_tree":pr["commits"]["nodes"][0]["commit"]["tree"]["oid"],
        "original_base":pr["baseRefName"],"original_base_sha":pr["baseRefOid"],"comments":len(pr["comments"]["nodes"]),"six_checks_success":True,
        "checks":checks,"integration_intent":"按原提交顺序保留历史，以栈顶最终实现一次合入，合并后原PR同步到main确认包含"})
base = repository["defaultBranchRef"]["target"]["oid"]
merged_tree = git("merge-tree","--write-tree",base,tip)
assert merged_tree == git("rev-parse",tip+"^{tree}")
native_paths = ["cpp","portable","embedded","CMakeLists.txt","CMakePresets.json","pixi.toml","pixi.lock","assets"]
assert not git("diff","--name-only","337a3dd",tip,"--",*native_paths)
for fix in ("337a3dd","7e5a4e3","876e15b"):
    subprocess.run(["git","merge-base","--is-ancestor",fix,tip],check=True)
discussion = repository["discussion"]
assert discussion["comments"]["totalCount"] == 0
summary = {"observed_at":raw["observed_at"],"base":base,"tip":tip,"tip_tree":merged_tree,"prs":rows,"comments":comments,
    "original_pr_count":23,"six_check_total":138,"all_heads_in_tip":True,"original_native_and_assets_unchanged_since_337a3dd":True,
    "discussion":{"url":discussion["url"],"updated_at":discussion["updatedAt"],"comments":0,"body_sha256":hashlib.sha256(discussion["body"].encode()).hexdigest(),"read_directly":True},
    "fixed_commits":["337a3dd","7e5a4e3","876e15b"],"scope":"原PR提交及CI快照、审查内容和Git包含关系；协作者本机复测为引用证据，另列本机集成回归；不作为新拟合/性能/实板证明"}
(out / "audit.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
with zipfile.ZipFile(out / "public-review-snapshot.zip","x",zipfile.ZIP_DEFLATED) as z:
    for name in ("snapshot-before.json","snapshot.py","prepare_evidence.py"):z.write(folder / name,name)
print(json.dumps({"prs":23,"checks":138,"comments":len(comments),"tip_tree":merged_tree,"snapshot_bytes":(out / "public-review-snapshot.zip").stat().st_size},ensure_ascii=False))
