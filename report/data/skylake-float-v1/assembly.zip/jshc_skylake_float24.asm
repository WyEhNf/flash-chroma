
F:\Hackathon\projects\16-lut-color\artifacts\skylake-float-build-v1\CMakeFiles\jshc_skylake_float24.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
       7:	c5 f8 29 b4 24 c0 00 	vmovaps %xmm6,0xc0(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 d0 00 	vmovaps %xmm7,0xd0(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 e0 00 	vmovaps %xmm8,0xe0(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 f0 00 	vmovaps %xmm9,0xf0(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 00 01 	vmovaps %xmm10,0x100(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 10 01 	vmovaps %xmm11,0x110(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 20 01 	vmovaps %xmm12,0x120(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 30 01 	vmovaps %xmm13,0x130(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 40 01 	vmovaps %xmm14,0x140(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 50 01 	vmovaps %xmm15,0x150(%rsp)
      5f:	00 00 
      61:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      65:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      69:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
      6d:	48 89 d0             	mov    %rdx,%rax
      70:	48 8b 11             	mov    (%rcx),%rdx
      73:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      77:	c5 fd 6f 20          	vmovdqa (%rax),%ymm4
      7b:	c5 fd 6f 70 20       	vmovdqa 0x20(%rax),%ymm6
      80:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      84:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
      89:	c4 e2 55 90 0c a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm1
      8f:	48 8b 51 08          	mov    0x8(%rcx),%rdx
      93:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      97:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
      9c:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
      a1:	c4 e2 55 90 24 b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm4
      a7:	48 8b 51 10          	mov    0x10(%rcx),%rdx
      ab:	c5 fd 6f 70 40       	vmovdqa 0x40(%rax),%ymm6
      b0:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      b4:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
      b9:	c4 62 55 90 14 b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm10
      bf:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
      c4:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
      c9:	48 8b 51 48          	mov    0x48(%rcx),%rdx
      cd:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
      d2:	c4 c1 4d 72 d2 11    	vpsrld $0x11,%ymm10,%ymm6
      d8:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
      dd:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
      e2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
      e6:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
      ea:	c5 6d fe f6          	vpaddd %ymm6,%ymm2,%ymm14
      ee:	c5 cd 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm6
      f3:	c4 c1 79 6e d0       	vmovd  %r8d,%xmm2
      f8:	41 b8 00 00 01 00    	mov    $0x10000,%r8d
      fe:	c4 a2 65 90 3c b2    	vpgatherdd %ymm3,(%rdx,%ymm14,4),%ymm7
     104:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     109:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     10d:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
     113:	c4 c1 6d fe fe       	vpaddd %ymm14,%ymm2,%ymm7
     118:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
     11c:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     120:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     125:	c4 62 75 39 ec       	vpminsd %ymm4,%ymm1,%ymm13
     12a:	c5 5d 66 d9          	vpcmpgtd %ymm1,%ymm4,%ymm11
     12e:	c5 75 fe cc          	vpaddd %ymm4,%ymm1,%ymm9
     132:	c4 e2 05 90 1c ba    	vpgatherdd %ymm15,(%rdx,%ymm7,4),%ymm3
     138:	c4 c2 15 39 fa       	vpminsd %ymm10,%ymm13,%ymm7
     13d:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
     142:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
     148:	c4 e2 75 3d dc       	vpmaxsd %ymm4,%ymm1,%ymm3
     14d:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
     151:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     156:	c4 41 15 66 ea       	vpcmpgtd %ymm10,%ymm13,%ymm13
     15b:	c5 ad 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm2
     15f:	c4 43 55 4c d8 b0    	vpblendvb %ymm11,%ymm8,%ymm5,%ymm11
     165:	c4 c2 65 3d da       	vpmaxsd %ymm10,%ymm3,%ymm3
     16a:	c4 41 35 fe ca       	vpaddd %ymm10,%ymm9,%ymm9
     16f:	c4 c3 55 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm5,%ymm1
     175:	c5 65 fe e7          	vpaddd %ymm7,%ymm3,%ymm12
     179:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm1,%ymm1        # 182 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x182>
     180:	ff ff d0 
     183:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     187:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm11,%ymm11        # 190 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x190>
     18e:	ff ff 20 
     191:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
     195:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
     19a:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     19e:	c4 e2 15 90 0c a2    	vpgatherdd %ymm13,(%rdx,%ymm4,4),%ymm1
     1a4:	c4 41 79 6e e8       	vmovd  %r8d,%xmm13
     1a9:	c4 a2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm11,4),%ymm2
     1af:	c5 dd 72 d0 18       	vpsrld $0x18,%ymm0,%ymm4
     1b4:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     1b9:	c5 5d db 54 24 20    	vpand  0x20(%rsp),%ymm4,%ymm10
     1bf:	c5 5d db 5c 24 40    	vpand  0x40(%rsp),%ymm4,%ymm11
     1c5:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
     1cb:	c5 15 fa eb          	vpsubd %ymm3,%ymm13,%ymm13
     1cf:	c4 c1 65 fe dc       	vpaddd %ymm12,%ymm3,%ymm3
     1d4:	c4 41 45 fe e4       	vpaddd %ymm12,%ymm7,%ymm12
     1d9:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
     1dd:	c4 41 7c 5b ed       	vcvtdq2ps %ymm13,%ymm13
     1e2:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     1e6:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
     1eb:	c4 41 35 fa cc       	vpsubd %ymm12,%ymm9,%ymm9
     1f0:	c4 41 7c 5b db       	vcvtdq2ps %ymm11,%ymm11
     1f5:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
     1f9:	c4 41 7c 5b c9       	vcvtdq2ps %ymm9,%ymm9
     1fe:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     203:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
     207:	c4 41 2c 59 d5       	vmulps %ymm13,%ymm10,%ymm10
     20c:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     210:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     214:	c4 c1 74 59 c9       	vmulps %ymm9,%ymm1,%ymm1
     219:	c5 ec 59 d3          	vmulps %ymm3,%ymm2,%ymm2
     21d:	c5 a4 59 ff          	vmulps %ymm7,%ymm11,%ymm7
     221:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     225:	c4 c1 6c 58 d2       	vaddps %ymm10,%ymm2,%ymm2
     22a:	c5 c4 58 f9          	vaddps %ymm1,%ymm7,%ymm7
     22e:	c5 ec 58 d7          	vaddps %ymm7,%ymm2,%ymm2
     232:	c5 ec 58 15 20 00 00 	vaddps 0x20(%rip),%ymm2,%ymm2        # 25a <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x25a>
     239:	00 
     23a:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     23e:	c5 fd 6f 58 40       	vmovdqa 0x40(%rax),%ymm3
     243:	c5 fe 5b d2          	vcvttps2dq %ymm2,%ymm2
     247:	c5 9d 72 d2 10       	vpsrld $0x10,%ymm2,%ymm12
     24c:	c5 7e 7f a4 24 a0 00 	vmovdqu %ymm12,0xa0(%rsp)
     253:	00 00 
     255:	c4 42 25 90 14 98    	vpgatherdd %ymm11,(%r8,%ymm3,4),%ymm10
     25b:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     25f:	c5 fd 6f 58 20       	vmovdqa 0x20(%rax),%ymm3
     264:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     268:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     26c:	c4 42 25 90 0c 98    	vpgatherdd %ymm11,(%r8,%ymm3,4),%ymm9
     272:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     276:	c5 fd 6f 18          	vmovdqa (%rax),%ymm3
     27a:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     27e:	c5 35 db ce          	vpand  %ymm6,%ymm9,%ymm9
     282:	c4 c2 25 90 14 98    	vpgatherdd %ymm11,(%r8,%ymm3,4),%ymm2
     288:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
     28f:	00 00 
     291:	4c 8b 41 40          	mov    0x40(%rcx),%r8
     295:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
     299:	c4 c2 6d 3d d9       	vpmaxsd %ymm9,%ymm2,%ymm3
     29e:	c5 35 66 da          	vpcmpgtd %ymm2,%ymm9,%ymm11
     2a2:	c4 42 6d 39 f1       	vpminsd %ymm9,%ymm2,%ymm14
     2a7:	c5 ad 66 cb          	vpcmpgtd %ymm3,%ymm10,%ymm1
     2ab:	c4 c1 6d fe f9       	vpaddd %ymm9,%ymm2,%ymm7
     2b0:	c4 42 0d 39 e2       	vpminsd %ymm10,%ymm14,%ymm12
     2b5:	c4 c1 6d 66 d1       	vpcmpgtd %ymm9,%ymm2,%ymm2
     2ba:	c4 41 0d 66 f2       	vpcmpgtd %ymm10,%ymm14,%ymm14
     2bf:	c4 c2 65 3d da       	vpmaxsd %ymm10,%ymm3,%ymm3
     2c4:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
     2ca:	c4 43 55 4c d8 b0    	vpblendvb %ymm11,%ymm8,%ymm5,%ymm11
     2d0:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     2d5:	c4 41 65 fe ec       	vpaddd %ymm12,%ymm3,%ymm13
     2da:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm11,%ymm11        # 2e3 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x2e3>
     2e1:	ff ff 10 
     2e4:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
     2ea:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     2ef:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     2f3:	c4 c3 55 4c d0 20    	vpblendvb %ymm2,%ymm8,%ymm5,%ymm2
     2f9:	c4 a2 05 90 0c 9a    	vpgatherdd %ymm15,(%rdx,%ymm11,4),%ymm1
     2ff:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
     304:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm2,%ymm2        # 30d <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x30d>
     30b:	ff ff e0 
     30e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     312:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     318:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     31d:	c5 35 db cc          	vpand  %ymm4,%ymm9,%ymm9
     321:	c5 a5 fa d2          	vpsubd %ymm2,%ymm11,%ymm2
     325:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     329:	c4 41 7c 5b c9       	vcvtdq2ps %ymm9,%ymm9
     32e:	c4 62 05 90 14 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm10
     334:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
     33a:	c5 0d fa db          	vpsubd %ymm3,%ymm14,%ymm11
     33e:	c4 c1 65 fe dd       	vpaddd %ymm13,%ymm3,%ymm3
     343:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     349:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
     34e:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
     352:	c4 41 7c 5b db       	vcvtdq2ps %ymm11,%ymm11
     357:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     35c:	c5 2d db d4          	vpand  %ymm4,%ymm10,%ymm10
     360:	c4 c1 45 fa fd       	vpsubd %ymm13,%ymm7,%ymm7
     365:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
     369:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
     36d:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     371:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     376:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     37a:	c4 41 34 59 cc       	vmulps %ymm12,%ymm9,%ymm9
     37f:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
     383:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     388:	c5 7d 6f 78 40       	vmovdqa 0x40(%rax),%ymm15
     38d:	c4 c1 6c 59 d3       	vmulps %ymm11,%ymm2,%ymm2
     392:	c5 2c 59 d7          	vmulps %ymm7,%ymm10,%ymm10
     396:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
     39a:	c5 f4 59 cb          	vmulps %ymm3,%ymm1,%ymm1
     39e:	c4 41 34 58 ca       	vaddps %ymm10,%ymm9,%ymm9
     3a3:	c4 02 45 90 14 b8    	vpgatherdd %ymm7,(%r8,%ymm15,4),%ymm10
     3a9:	4c 8b 41 38          	mov    0x38(%rcx),%r8
     3ad:	c5 7d 6f 78 20       	vmovdqa 0x20(%rax),%ymm15
     3b2:	c5 f4 58 ca          	vaddps %ymm2,%ymm1,%ymm1
     3b6:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
     3ba:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     3be:	c4 c1 74 58 c9       	vaddps %ymm9,%ymm1,%ymm1
     3c3:	c5 f4 58 15 20 00 00 	vaddps 0x20(%rip),%ymm1,%ymm2        # 3eb <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x3eb>
     3ca:	00 
     3cb:	c4 02 45 90 0c b8    	vpgatherdd %ymm7,(%r8,%ymm15,4),%ymm9
     3d1:	48 8b 49 30          	mov    0x30(%rcx),%rcx
     3d5:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
     3d9:	c5 7d 6f 38          	vmovdqa (%rax),%ymm15
     3dd:	c5 35 db ce          	vpand  %ymm6,%ymm9,%ymm9
     3e1:	c4 a2 45 90 0c b9    	vpgatherdd %ymm7,(%rcx,%ymm15,4),%ymm1
     3e7:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     3eb:	c5 fe 5b d2          	vcvttps2dq %ymm2,%ymm2
     3ef:	c5 f5 db f6          	vpand  %ymm6,%ymm1,%ymm6
     3f3:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     3f8:	c4 c2 4d 3d d9       	vpmaxsd %ymm9,%ymm6,%ymm3
     3fd:	c5 35 66 de          	vpcmpgtd %ymm6,%ymm9,%ymm11
     401:	c4 42 4d 39 f1       	vpminsd %ymm9,%ymm6,%ymm14
     406:	c5 ad 66 cb          	vpcmpgtd %ymm3,%ymm10,%ymm1
     40a:	c4 c1 4d fe f9       	vpaddd %ymm9,%ymm6,%ymm7
     40f:	c4 42 0d 39 e2       	vpminsd %ymm10,%ymm14,%ymm12
     414:	c4 c1 4d 66 f1       	vpcmpgtd %ymm9,%ymm6,%ymm6
     419:	c4 41 0d 66 f2       	vpcmpgtd %ymm10,%ymm14,%ymm14
     41e:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
     424:	c4 c2 65 3d da       	vpmaxsd %ymm10,%ymm3,%ymm3
     429:	c4 43 55 4c d8 b0    	vpblendvb %ymm11,%ymm8,%ymm5,%ymm11
     42f:	c4 41 65 fe ec       	vpaddd %ymm12,%ymm3,%ymm13
     434:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     439:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm11,%ymm11        # 442 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x442>
     440:	ff ff 10 
     443:	c5 25 fe 9c 24 80 00 	vpaddd 0x80(%rsp),%ymm11,%ymm11
     44a:	00 00 
     44c:	c4 c3 55 4c e8 60    	vpblendvb %ymm6,%ymm8,%ymm5,%ymm5
     452:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm5,%ymm5        # 45b <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x45b>
     459:	ff ff e0 
     45c:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     462:	c4 a2 05 90 0c 9a    	vpgatherdd %ymm15,(%rdx,%ymm11,4),%ymm1
     468:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
     46d:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
     471:	c4 e2 7d 90 34 aa    	vpgatherdd %ymm0,(%rdx,%ymm5,4),%ymm6
     477:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     47d:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     482:	c5 fd 7f 50 20       	vmovdqa %ymm2,0x20(%rax)
     487:	c4 c1 75 72 d1 10    	vpsrld $0x10,%ymm9,%ymm1
     48d:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     492:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     496:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     49b:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
     49f:	c5 f5 db cc          	vpand  %ymm4,%ymm1,%ymm1
     4a3:	c5 fc 5b c0          	vcvtdq2ps %ymm0,%ymm0
     4a7:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
     4ab:	c5 8d fa e3          	vpsubd %ymm3,%ymm14,%ymm4
     4af:	c4 c1 65 fe dd       	vpaddd %ymm13,%ymm3,%ymm3
     4b4:	c5 fc 5b f6          	vcvtdq2ps %ymm6,%ymm6
     4b8:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
     4bd:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
     4c1:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     4c5:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     4ca:	c4 c1 45 fa fd       	vpsubd %ymm13,%ymm7,%ymm7
     4cf:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
     4d3:	c5 fc 5b ed          	vcvtdq2ps %ymm5,%ymm5
     4d7:	c5 fc 59 c3          	vmulps %ymm3,%ymm0,%ymm0
     4db:	c5 d4 59 ec          	vmulps %ymm4,%ymm5,%ymm5
     4df:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     4e3:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     4e7:	c5 cc 59 f7          	vmulps %ymm7,%ymm6,%ymm6
     4eb:	c4 c1 74 59 cc       	vmulps %ymm12,%ymm1,%ymm1
     4f0:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
     4f7:	00 00 
     4f9:	c5 7d 7f 20          	vmovdqa %ymm12,(%rax)
     4fd:	c5 fc 58 c5          	vaddps %ymm5,%ymm0,%ymm0
     501:	c5 f4 58 ce          	vaddps %ymm6,%ymm1,%ymm1
     505:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
     509:	c5 fc 58 05 20 00 00 	vaddps 0x20(%rip),%ymm0,%ymm0        # 531 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x531>
     510:	00 
     511:	c5 fe 5b c0          	vcvttps2dq %ymm0,%ymm0
     515:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     51a:	c5 fd 7f 40 40       	vmovdqa %ymm0,0x40(%rax)
     51f:	c5 f8 77             	vzeroupper
     522:	c5 f8 28 b4 24 c0 00 	vmovaps 0xc0(%rsp),%xmm6
     529:	00 00 
     52b:	c5 f8 28 bc 24 d0 00 	vmovaps 0xd0(%rsp),%xmm7
     532:	00 00 
     534:	c5 78 28 84 24 e0 00 	vmovaps 0xe0(%rsp),%xmm8
     53b:	00 00 
     53d:	c5 78 28 8c 24 f0 00 	vmovaps 0xf0(%rsp),%xmm9
     544:	00 00 
     546:	c5 78 28 94 24 00 01 	vmovaps 0x100(%rsp),%xmm10
     54d:	00 00 
     54f:	c5 78 28 9c 24 10 01 	vmovaps 0x110(%rsp),%xmm11
     556:	00 00 
     558:	c5 78 28 a4 24 20 01 	vmovaps 0x120(%rsp),%xmm12
     55f:	00 00 
     561:	c5 78 28 ac 24 30 01 	vmovaps 0x130(%rsp),%xmm13
     568:	00 00 
     56a:	c5 78 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm14
     571:	00 00 
     573:	c5 78 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm15
     57a:	00 00 
     57c:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
     583:	c3                   	ret
     584:	90                   	nop
     585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     58c:	00 00 00 00 

0000000000000590 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     590:	41 55                	push   %r13
     592:	41 54                	push   %r12
     594:	55                   	push   %rbp
     595:	57                   	push   %rdi
     596:	56                   	push   %rsi
     597:	53                   	push   %rbx
     598:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
     59f:	c5 f8 29 b4 24 90 01 	vmovaps %xmm6,0x190(%rsp)
     5a6:	00 00 
     5a8:	c5 f8 29 bc 24 a0 01 	vmovaps %xmm7,0x1a0(%rsp)
     5af:	00 00 
     5b1:	c5 78 29 84 24 b0 01 	vmovaps %xmm8,0x1b0(%rsp)
     5b8:	00 00 
     5ba:	c5 78 29 8c 24 c0 01 	vmovaps %xmm9,0x1c0(%rsp)
     5c1:	00 00 
     5c3:	c5 78 29 94 24 d0 01 	vmovaps %xmm10,0x1d0(%rsp)
     5ca:	00 00 
     5cc:	c5 78 29 9c 24 e0 01 	vmovaps %xmm11,0x1e0(%rsp)
     5d3:	00 00 
     5d5:	c5 78 29 a4 24 f0 01 	vmovaps %xmm12,0x1f0(%rsp)
     5dc:	00 00 
     5de:	c5 78 29 ac 24 00 02 	vmovaps %xmm13,0x200(%rsp)
     5e5:	00 00 
     5e7:	c5 78 29 b4 24 10 02 	vmovaps %xmm14,0x210(%rsp)
     5ee:	00 00 
     5f0:	c5 78 29 bc 24 20 02 	vmovaps %xmm15,0x220(%rsp)
     5f7:	00 00 
     5f9:	4c 8d 9c 24 df 00 00 	lea    0xdf(%rsp),%r11
     600:	00 
     601:	48 89 cd             	mov    %rcx,%rbp
     604:	48 89 d6             	mov    %rdx,%rsi
     607:	4d 89 c4             	mov    %r8,%r12
     60a:	49 83 e3 e0          	and    $0xffffffffffffffe0,%r11
     60e:	48 83 fa 04          	cmp    $0x4,%rdx
     612:	0f 84 d7 03 00 00    	je     9ef <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x45f>
     618:	4d 85 c9             	test   %r9,%r9
     61b:	0f 84 d2 0c 00 00    	je     12f3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd63>
     621:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 689 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf9>
     628:	00 
     629:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
     62d:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     632:	45 31 ed             	xor    %r13d,%r13d
     635:	48 c1 ef 03          	shr    $0x3,%rdi
     639:	c4 c1 0d 72 d5 18    	vpsrld $0x18,%ymm13,%ymm14
     63f:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     645:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 6cd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13d>
     64c:	00 
     64d:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     654:	00 00 
     656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     65d:	00 00 00 
     660:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     666:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     66d:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     673:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     679:	c4 e2 7d 00 44 24 60 	vpshufb 0x60(%rsp),%ymm0,%ymm0
     680:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
     685:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     68a:	c4 41 7d db d6       	vpand  %ymm14,%ymm0,%ymm10
     68f:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
     694:	c5 fd 6f c1          	vmovdqa %ymm1,%ymm0
     698:	48 85 f6             	test   %rsi,%rsi
     69b:	0f 84 f5 02 00 00    	je     996 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x406>
     6a1:	c4 c1 45 72 d5 0f    	vpsrld $0xf,%ymm13,%ymm7
     6a7:	49 89 ea             	mov    %rbp,%r10
     6aa:	31 db                	xor    %ebx,%ebx
     6ac:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     6b2:	e9 8b 02 00 00       	jmp    942 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3b2>
     6b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     6be:	00 00 
     6c0:	49 8b 02             	mov    (%r10),%rax
     6c3:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     6c7:	41 8b 4a 54          	mov    0x54(%r10),%ecx
     6cb:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
     6cf:	41 8b 52 50          	mov    0x50(%r10),%edx
     6d3:	48 ff c3             	inc    %rbx
     6d6:	49 83 c2 60          	add    $0x60,%r10
     6da:	c4 a2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm10,4),%ymm3
     6e0:	49 8b 42 a8          	mov    -0x58(%r10),%rax
     6e4:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     6e8:	c5 79 6e c9          	vmovd  %ecx,%xmm9
     6ec:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     6f1:	c4 a2 5d 90 2c 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm5
     6f7:	49 8b 42 b0          	mov    -0x50(%r10),%rax
     6fb:	c5 79 6e c2          	vmovd  %edx,%xmm8
     6ff:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
     703:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     708:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     70d:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     711:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
     717:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     71c:	49 8b 42 e8          	mov    -0x18(%r10),%rax
     720:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
     726:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     72b:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     730:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     735:	c5 d5 db ef          	vpand  %ymm7,%ymm5,%ymm5
     739:	c5 e5 db df          	vpand  %ymm7,%ymm3,%ymm3
     73d:	c5 cd db f7          	vpand  %ymm7,%ymm6,%ymm6
     741:	c5 55 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm15
     745:	c4 62 65 39 d5       	vpminsd %ymm5,%ymm3,%ymm10
     74a:	c4 e2 2d 39 fe       	vpminsd %ymm6,%ymm10,%ymm7
     74f:	c5 2d 66 d6          	vpcmpgtd %ymm6,%ymm10,%ymm10
     753:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     757:	c4 e2 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm0
     75c:	c4 43 3d 4c f9 f0    	vpblendvb %ymm15,%ymm9,%ymm8,%ymm15
     762:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     766:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
     76a:	c4 62 5d 90 1c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm11
     770:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     774:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     779:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     77d:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     783:	c4 62 6d 90 24 a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm12
     789:	c5 cd 66 d0          	vpcmpgtd %ymm0,%ymm6,%ymm2
     78d:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
     791:	c4 e2 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm0
     796:	c4 63 05 4c 3d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm15,%ymm15        # 79f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20f>
     79d:	ff ff 20 
     7a0:	c5 e5 fe d5          	vpaddd %ymm5,%ymm3,%ymm2
     7a4:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     7a8:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
     7ad:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     7b1:	c4 62 5d 90 3c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm15
     7b7:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     7bd:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
     7c1:	c4 c1 1d db ee       	vpand  %ymm14,%ymm12,%ymm5
     7c6:	c4 c1 05 db ce       	vpand  %ymm14,%ymm15,%ymm1
     7cb:	c5 fc 5b ed          	vcvtdq2ps %ymm5,%ymm5
     7cf:	c4 43 3d 4c c1 30    	vpblendvb %ymm3,%ymm9,%ymm8,%ymm8
     7d5:	c5 7d fe cf          	vpaddd %ymm7,%ymm0,%ymm9
     7d9:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     7dd:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm8,%ymm8        # 7e6 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x256>
     7e4:	ff ff a0 
     7e7:	c4 c1 5d fa e0       	vpsubd %ymm8,%ymm4,%ymm4
     7ec:	c4 41 25 db c6       	vpand  %ymm14,%ymm11,%ymm8
     7f1:	c4 e2 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm3
     7f7:	b8 00 00 01 00       	mov    $0x10000,%eax
     7fc:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
     801:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     805:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
     80a:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     80f:	c5 fc 5b f6          	vcvtdq2ps %ymm6,%ymm6
     813:	c5 dd fa e0          	vpsubd %ymm0,%ymm4,%ymm4
     817:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
     81c:	c4 41 45 fe c9       	vpaddd %ymm9,%ymm7,%ymm9
     821:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
     825:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     829:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     82d:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     832:	c5 fc 5b c0          	vcvtdq2ps %ymm0,%ymm0
     836:	c5 3c 59 c4          	vmulps %ymm4,%ymm8,%ymm8
     83a:	c5 74 59 d0          	vmulps %ymm0,%ymm1,%ymm10
     83e:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
     842:	c4 c1 75 72 d4 08    	vpsrld $0x8,%ymm12,%ymm1
     848:	c5 cc 59 f2          	vmulps %ymm2,%ymm6,%ymm6
     84c:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     851:	c5 d4 59 ef          	vmulps %ymm7,%ymm5,%ymm5
     855:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     859:	c5 f4 59 cf          	vmulps %ymm7,%ymm1,%ymm1
     85d:	c4 41 2c 58 d0       	vaddps %ymm8,%ymm10,%ymm10
     862:	c4 c1 3d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm8
     868:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
     86d:	c5 d4 58 ee          	vaddps %ymm6,%ymm5,%ymm5
     871:	c4 c1 4d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm6
     877:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
     87c:	c5 3c 59 c0          	vmulps %ymm0,%ymm8,%ymm8
     880:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
     885:	c5 fc 5b f6          	vcvtdq2ps %ymm6,%ymm6
     889:	c5 cc 59 f4          	vmulps %ymm4,%ymm6,%ymm6
     88d:	c5 2c 58 d5          	vaddps %ymm5,%ymm10,%ymm10
     891:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     896:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     89b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     8a0:	c5 fc 5b ed          	vcvtdq2ps %ymm5,%ymm5
     8a4:	c5 d4 59 ea          	vmulps %ymm2,%ymm5,%ymm5
     8a8:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     8ad:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
     8b1:	c5 e4 59 da          	vmulps %ymm2,%ymm3,%ymm3
     8b5:	c5 2c 58 15 20 00 00 	vaddps 0x20(%rip),%ymm10,%ymm10        # 8dd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x34d>
     8bc:	00 
     8bd:	c5 3c 58 c6          	vaddps %ymm6,%ymm8,%ymm8
     8c1:	c4 c1 4d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm6
     8c7:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
     8cc:	c5 fc 5b f6          	vcvtdq2ps %ymm6,%ymm6
     8d0:	c4 41 7e 5b d2       	vcvttps2dq %ymm10,%ymm10
     8d5:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     8db:	c5 f4 58 cd          	vaddps %ymm5,%ymm1,%ymm1
     8df:	c4 c1 55 72 d3 10    	vpsrld $0x10,%ymm11,%ymm5
     8e5:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     8ea:	c5 fc 5b ed          	vcvtdq2ps %ymm5,%ymm5
     8ee:	c5 d4 59 ec          	vmulps %ymm4,%ymm5,%ymm5
     8f2:	c5 3c 58 c1          	vaddps %ymm1,%ymm8,%ymm8
     8f6:	c4 c1 75 72 d7 10    	vpsrld $0x10,%ymm15,%ymm1
     8fc:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     901:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     905:	c5 f4 59 c0          	vmulps %ymm0,%ymm1,%ymm0
     909:	c5 cc 59 cf          	vmulps %ymm7,%ymm6,%ymm1
     90d:	c5 3c 58 05 20 00 00 	vaddps 0x20(%rip),%ymm8,%ymm8        # 935 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3a5>
     914:	00 
     915:	c4 41 7e 5b c0       	vcvttps2dq %ymm8,%ymm8
     91a:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     920:	c5 fc 58 c5          	vaddps %ymm5,%ymm0,%ymm0
     924:	c5 f4 58 cb          	vaddps %ymm3,%ymm1,%ymm1
     928:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
     92c:	c5 fc 58 05 20 00 00 	vaddps 0x20(%rip),%ymm0,%ymm0        # 954 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3c4>
     933:	00 
     934:	c5 fe 5b c0          	vcvttps2dq %ymm0,%ymm0
     938:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     93d:	48 39 de             	cmp    %rbx,%rsi
     940:	74 54                	je     996 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x406>
     942:	41 80 7a 58 00       	cmpb   $0x0,0x58(%r10)
     947:	0f 85 73 fd ff ff    	jne    6c0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
     94d:	c4 41 7d 7f 13       	vmovdqa %ymm10,(%r11)
     952:	4c 89 d1             	mov    %r10,%rcx
     955:	4c 89 da             	mov    %r11,%rdx
     958:	c4 41 7d 7f 43 20    	vmovdqa %ymm8,0x20(%r11)
     95e:	c4 c1 7d 7f 43 40    	vmovdqa %ymm0,0x40(%r11)
     964:	c5 f8 77             	vzeroupper
     967:	e8 94 f6 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     96c:	48 ff c3             	inc    %rbx
     96f:	c4 41 7d 6f 13       	vmovdqa (%r11),%ymm10
     974:	c4 41 7d 6f 43 20    	vmovdqa 0x20(%r11),%ymm8
     97a:	c4 c1 7d 6f 43 40    	vmovdqa 0x40(%r11),%ymm0
     980:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     985:	49 83 c2 60          	add    $0x60,%r10
     989:	c5 7d 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm14        # 9d1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x441>
     990:	00 
     991:	48 39 de             	cmp    %rbx,%rsi
     994:	75 ac                	jne    942 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3b2>
     996:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     99b:	c4 c1 3d 72 f0 08    	vpslld $0x8,%ymm8,%ymm8
     9a1:	49 83 c4 18          	add    $0x18,%r12
     9a5:	c5 bd eb c0          	vpor   %ymm0,%ymm8,%ymm0
     9a9:	c4 c1 7d eb c2       	vpor   %ymm10,%ymm0,%ymm0
     9ae:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
     9b5:	00 00 00 
     9b8:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     9bc:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     9c2:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     9c7:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     9cc:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     9d0:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
     9d7:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
     9de:	4c 39 ef             	cmp    %r13,%rdi
     9e1:	0f 84 09 09 00 00    	je     12f0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd60>
     9e7:	49 ff c5             	inc    %r13
     9ea:	e9 71 fc ff ff       	jmp    660 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd0>
     9ef:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     9f3:	0f 85 1f fc ff ff    	jne    618 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     9f9:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     a00:	0f 84 12 fc ff ff    	je     618 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     a06:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     a0d:	0f 84 05 fc ff ff    	je     618 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     a13:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     a1a:	0f 84 f8 fb ff ff    	je     618 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     a20:	4d 85 c9             	test   %r9,%r9
     a23:	0f 84 ca 08 00 00    	je     12f3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd63>
     a29:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # a91 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x501>
     a30:	00 
     a31:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     a35:	45 31 d2             	xor    %r10d,%r10d
     a38:	49 8d 73 60          	lea    0x60(%r11),%rsi
     a3c:	48 c1 e8 03          	shr    $0x3,%rax
     a40:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     a46:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # ace <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x53e>
     a4d:	00 
     a4e:	48 8d 58 01          	lea    0x1(%rax),%rbx
     a52:	b8 00 00 01 00       	mov    $0x10000,%eax
     a57:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     a5e:	00 00 
     a60:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
     a64:	c5 85 72 d4 18       	vpsrld $0x18,%ymm4,%ymm15
     a69:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     a6d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     a72:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     a78:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     a7e:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     a85:	48 89 f2             	mov    %rsi,%rdx
     a88:	48 89 e9             	mov    %rbp,%rcx
     a8b:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     a91:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     a97:	c4 e2 7d 00 44 24 60 	vpshufb 0x60(%rsp),%ymm0,%ymm0
     a9e:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     aa3:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     aa8:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     aad:	c4 c1 7d 7f 43 60    	vmovdqa %ymm0,0x60(%r11)
     ab3:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
     ab8:	c4 c1 7d 7f 83 80 00 	vmovdqa %ymm0,0x80(%r11)
     abf:	00 00 
     ac1:	c4 c1 7d 7f 93 a0 00 	vmovdqa %ymm2,0xa0(%r11)
     ac8:	00 00 
     aca:	c5 f8 77             	vzeroupper
     acd:	e8 2e f5 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     ad2:	48 8b 45 60          	mov    0x60(%rbp),%rax
     ad6:	c4 c1 7d 6f 43 60    	vmovdqa 0x60(%r11),%ymm0
     adc:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     ae0:	8b 8d b4 00 00 00    	mov    0xb4(%rbp),%ecx
     ae6:	8b 95 b0 00 00 00    	mov    0xb0(%rbp),%edx
     aec:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     af0:	c4 e2 65 90 24 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm4
     af6:	48 8b 45 68          	mov    0x68(%rbp),%rax
     afa:	c4 c1 7d 6f 83 80 00 	vmovdqa 0x80(%r11),%ymm0
     b01:	00 00 
     b03:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     b07:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     b0b:	c5 79 6e ca          	vmovd  %edx,%xmm9
     b0f:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     b13:	49 ff c2             	inc    %r10
     b16:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
     b1c:	48 8b 45 70          	mov    0x70(%rbp),%rax
     b20:	c4 c1 7d 6f 83 a0 00 	vmovdqa 0xa0(%r11),%ymm0
     b27:	00 00 
     b29:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     b2e:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     b33:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     b38:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     b3c:	49 83 c4 18          	add    $0x18,%r12
     b40:	c4 e2 6d 90 3c 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm7
     b46:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
     b4b:	48 8b 85 a8 00 00 00 	mov    0xa8(%rbp),%rax
     b52:	c5 7d 6f fb          	vmovdqa %ymm3,%ymm15
     b56:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     b5b:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     b60:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     b65:	c5 ed 72 d7 11       	vpsrld $0x11,%ymm7,%ymm2
     b6a:	c5 d5 72 d3 0f       	vpsrld $0xf,%ymm3,%ymm5
     b6f:	c5 cd db f5          	vpand  %ymm5,%ymm6,%ymm6
     b73:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
     b77:	c5 c5 db fd          	vpand  %ymm5,%ymm7,%ymm7
     b7b:	c5 4d 66 d4          	vpcmpgtd %ymm4,%ymm6,%ymm10
     b7f:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     b84:	c5 5d fe f6          	vpaddd %ymm6,%ymm4,%ymm14
     b88:	c5 0d fe f7          	vpaddd %ymm7,%ymm14,%ymm14
     b8c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     b90:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     b94:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     b98:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     b9d:	c5 fd 6f d3          	vmovdqa %ymm3,%ymm2
     ba1:	c4 e2 6d 90 1c 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm3
     ba7:	c5 f5 fe d0          	vpaddd %ymm0,%ymm1,%ymm2
     bab:	c4 43 35 4c d5 a0    	vpblendvb %ymm10,%ymm13,%ymm9,%ymm10
     bb1:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
     bb8:	00 00 
     bba:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
     bbe:	c4 e2 05 90 14 88    	vpgatherdd %ymm15,(%rax,%ymm1,4),%ymm2
     bc4:	c4 e2 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm1
     bc9:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
     bce:	c5 45 66 c1          	vpcmpgtd %ymm1,%ymm7,%ymm8
     bd2:	c4 c1 25 72 d3 1f    	vpsrld $0x1f,%ymm11,%ymm11
     bd8:	c4 e2 75 3d cf       	vpmaxsd %ymm7,%ymm1,%ymm1
     bdd:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     be3:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     be7:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     bec:	c4 63 2d 4c 54 24 20 	vpblendvb %ymm8,0x20(%rsp),%ymm10,%ymm10
     bf3:	80 
     bf4:	c4 62 1d 39 c7       	vpminsd %ymm7,%ymm12,%ymm8
     bf9:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     bfd:	c4 c3 35 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm4
     c03:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
     c0a:	00 00 
     c0c:	c4 41 7d fe d2       	vpaddd %ymm10,%ymm0,%ymm10
     c11:	c4 a2 25 90 04 90    	vpgatherdd %ymm11,(%rax,%ymm10,4),%ymm0
     c17:	c5 7e 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm11
     c1d:	c4 41 75 fe e8       	vpaddd %ymm8,%ymm1,%ymm13
     c22:	c4 e3 5d 4c 64 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm4,%ymm4
     c29:	c0 
     c2a:	c5 25 fa c9          	vpsubd %ymm1,%ymm11,%ymm9
     c2e:	c4 c1 75 fe cd       	vpaddd %ymm13,%ymm1,%ymm1
     c33:	c5 c5 fa e4          	vpsubd %ymm4,%ymm7,%ymm4
     c37:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     c3b:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # c83 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6f3>
     c42:	00 
     c43:	c4 41 3d fe ed       	vpaddd %ymm13,%ymm8,%ymm13
     c48:	c4 e2 45 90 34 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm6
     c4e:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     c53:	c4 41 0d fa ed       	vpsubd %ymm13,%ymm14,%ymm13
     c58:	c4 41 7c 5b c9       	vcvtdq2ps %ymm9,%ymm9
     c5d:	c4 41 65 db e7       	vpand  %ymm15,%ymm3,%ymm12
     c62:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
     c67:	c4 41 4d db d7       	vpand  %ymm15,%ymm6,%ymm10
     c6c:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     c70:	c4 c1 6d db ff       	vpand  %ymm15,%ymm2,%ymm7
     c75:	c4 41 7c 5b ed       	vcvtdq2ps %ymm13,%ymm13
     c7a:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
     c7f:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     c84:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     c88:	c4 41 1c 59 e1       	vmulps %ymm9,%ymm12,%ymm12
     c8d:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     c92:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     c96:	c4 41 2c 59 d5       	vmulps %ymm13,%ymm10,%ymm10
     c9b:	c5 8d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm14
     ca0:	c5 dc 59 e1          	vmulps %ymm1,%ymm4,%ymm4
     ca4:	c4 41 0d db f7       	vpand  %ymm15,%ymm14,%ymm14
     ca9:	c4 c1 44 59 f8       	vmulps %ymm8,%ymm7,%ymm7
     cae:	c4 41 7c 5b f6       	vcvtdq2ps %ymm14,%ymm14
     cb3:	c4 41 0c 59 f1       	vmulps %ymm9,%ymm14,%ymm14
     cb8:	c4 c1 5c 58 e4       	vaddps %ymm12,%ymm4,%ymm4
     cbd:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
     cc2:	c4 c1 44 58 fa       	vaddps %ymm10,%ymm7,%ymm7
     cc7:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
     ccc:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     cd1:	c4 41 1c 59 e5       	vmulps %ymm13,%ymm12,%ymm12
     cd6:	c5 5c 58 d7          	vaddps %ymm7,%ymm4,%ymm10
     cda:	c5 c5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm7
     cdf:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
     ce4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ce9:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
     cee:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
     cf3:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     cf7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     cfc:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     d01:	c5 c4 59 f9          	vmulps %ymm1,%ymm7,%ymm7
     d05:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     d09:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     d0e:	c5 fc 5b c0          	vcvtdq2ps %ymm0,%ymm0
     d12:	c4 c1 5c 59 e0       	vmulps %ymm8,%ymm4,%ymm4
     d17:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
     d1b:	c5 2c 58 15 20 00 00 	vaddps 0x20(%rip),%ymm10,%ymm10        # d43 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7b3>
     d22:	00 
     d23:	c5 fc 59 c1          	vmulps %ymm1,%ymm0,%ymm0
     d27:	c4 c1 6c 59 c8       	vmulps %ymm8,%ymm2,%ymm1
     d2c:	c4 41 7e 5b d2       	vcvttps2dq %ymm10,%ymm10
     d31:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     d37:	c4 c1 44 58 fe       	vaddps %ymm14,%ymm7,%ymm7
     d3c:	c4 c1 5c 58 e4       	vaddps %ymm12,%ymm4,%ymm4
     d41:	c5 c4 58 fc          	vaddps %ymm4,%ymm7,%ymm7
     d45:	c5 dd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm4
     d4a:	c5 e5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm3
     d4f:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
     d54:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     d59:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     d5d:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
     d61:	c4 c1 5c 59 e1       	vmulps %ymm9,%ymm4,%ymm4
     d66:	c5 c4 58 3d 20 00 00 	vaddps 0x20(%rip),%ymm7,%ymm7        # d8e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7fe>
     d6d:	00 
     d6e:	c4 c1 64 59 dd       	vmulps %ymm13,%ymm3,%ymm3
     d73:	c5 fe 5b ff          	vcvttps2dq %ymm7,%ymm7
     d77:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     d7c:	c5 fc 58 c4          	vaddps %ymm4,%ymm0,%ymm0
     d80:	c5 f4 58 cb          	vaddps %ymm3,%ymm1,%ymm1
     d84:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     d88:	c5 fd 6f d3          	vmovdqa %ymm3,%ymm2
     d8c:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
     d90:	c5 fc 58 05 20 00 00 	vaddps 0x20(%rip),%ymm0,%ymm0        # db8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x828>
     d97:	00 
     d98:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
     d9f:	8b 8d 14 01 00 00    	mov    0x114(%rbp),%ecx
     da5:	8b 95 10 01 00 00    	mov    0x110(%rbp),%edx
     dab:	c4 a2 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm10,4),%ymm4
     db1:	48 8b 85 c8 00 00 00 	mov    0xc8(%rbp),%rax
     db8:	c5 fd 6f da          	vmovdqa %ymm2,%ymm3
     dbc:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     dc0:	c5 fe 5b c0          	vcvttps2dq %ymm0,%ymm0
     dc4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     dc9:	c5 79 6e ca          	vmovd  %edx,%xmm9
     dcd:	c4 e2 65 90 34 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm6
     dd3:	48 8b 85 d0 00 00 00 	mov    0xd0(%rbp),%rax
     dda:	c5 fd 6f da          	vmovdqa %ymm2,%ymm3
     dde:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     de3:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     de8:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     ded:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     df1:	c4 e2 6d 90 3c 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm7
     df7:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
     dfc:	48 8b 85 08 01 00 00 	mov    0x108(%rbp),%rax
     e03:	c5 cd db f5          	vpand  %ymm5,%ymm6,%ymm6
     e07:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     e0c:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     e11:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
     e15:	c5 ed 72 d7 11       	vpsrld $0x11,%ymm7,%ymm2
     e1a:	c5 4d 66 d4          	vpcmpgtd %ymm4,%ymm6,%ymm10
     e1e:	c5 c5 db fd          	vpand  %ymm5,%ymm7,%ymm7
     e22:	c5 5d fe f6          	vpaddd %ymm6,%ymm4,%ymm14
     e26:	c5 0d fe f7          	vpaddd %ymm7,%ymm14,%ymm14
     e2a:	c4 43 35 4c d5 a0    	vpblendvb %ymm10,%ymm13,%ymm9,%ymm10
     e30:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     e34:	c5 fd 6f cb          	vmovdqa %ymm3,%ymm1
     e38:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     e3c:	c5 fd 6f d3          	vmovdqa %ymm3,%ymm2
     e40:	c4 e2 75 90 1c 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm3
     e46:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     e4a:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     e4e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     e53:	c5 75 fe e0          	vpaddd %ymm0,%ymm1,%ymm12
     e57:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
     e5b:	c5 7e 7f a4 24 a0 00 	vmovdqu %ymm12,0xa0(%rsp)
     e62:	00 00 
     e64:	c4 a2 75 90 14 a0    	vpgatherdd %ymm1,(%rax,%ymm12,4),%ymm2
     e6a:	c4 e2 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm1
     e6f:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     e74:	c5 45 66 c1          	vpcmpgtd %ymm1,%ymm7,%ymm8
     e78:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     e7c:	c4 e2 75 3d cf       	vpmaxsd %ymm7,%ymm1,%ymm1
     e81:	c4 63 2d 4c 54 24 20 	vpblendvb %ymm8,0x20(%rsp),%ymm10,%ymm10
     e88:	80 
     e89:	c4 62 1d 39 c7       	vpminsd %ymm7,%ymm12,%ymm8
     e8e:	c4 c3 35 4c e5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm4
     e94:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     e98:	c4 41 7d fe d2       	vpaddd %ymm10,%ymm0,%ymm10
     e9d:	c4 41 75 fe e8       	vpaddd %ymm8,%ymm1,%ymm13
     ea2:	c4 a2 25 90 04 90    	vpgatherdd %ymm11,(%rax,%ymm10,4),%ymm0
     ea8:	c5 7e 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm11
     eae:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
     eb2:	c4 e3 5d 4c 64 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm4,%ymm4
     eb9:	c0 
     eba:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
     ec1:	00 00 
     ec3:	c5 25 fa c9          	vpsubd %ymm1,%ymm11,%ymm9
     ec7:	c4 c1 75 fe cd       	vpaddd %ymm13,%ymm1,%ymm1
     ecc:	c4 41 3d fe ed       	vpaddd %ymm13,%ymm8,%ymm13
     ed1:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     ed6:	c4 41 7c 5b c9       	vcvtdq2ps %ymm9,%ymm9
     edb:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
     ee0:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
     ee4:	c4 41 0d fa ed       	vpsubd %ymm13,%ymm14,%ymm13
     ee9:	c4 41 65 db e7       	vpand  %ymm15,%ymm3,%ymm12
     eee:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
     ef2:	c4 e2 45 90 34 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm6
     ef8:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
     efd:	c4 c1 6d db ff       	vpand  %ymm15,%ymm2,%ymm7
     f02:	c4 41 7c 5b ed       	vcvtdq2ps %ymm13,%ymm13
     f07:	c4 41 4d db d7       	vpand  %ymm15,%ymm6,%ymm10
     f0c:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     f11:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     f15:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
     f19:	c4 41 1c 59 e1       	vmulps %ymm9,%ymm12,%ymm12
     f1e:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     f23:	c5 8d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm14
     f28:	48 8b 85 20 01 00 00 	mov    0x120(%rbp),%rax
     f2f:	c4 41 2c 59 d5       	vmulps %ymm13,%ymm10,%ymm10
     f34:	c4 41 0d db f7       	vpand  %ymm15,%ymm14,%ymm14
     f39:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     f3e:	c5 dc 59 e1          	vmulps %ymm1,%ymm4,%ymm4
     f42:	c4 41 7c 5b f6       	vcvtdq2ps %ymm14,%ymm14
     f47:	c4 c1 44 59 f8       	vmulps %ymm8,%ymm7,%ymm7
     f4c:	c4 41 0c 59 f1       	vmulps %ymm9,%ymm14,%ymm14
     f51:	c4 c1 5c 58 e4       	vaddps %ymm12,%ymm4,%ymm4
     f56:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
     f5b:	c4 c1 44 58 fa       	vaddps %ymm10,%ymm7,%ymm7
     f60:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
     f65:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
     f6a:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
     f6f:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
     f74:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     f79:	c4 41 1c 59 e5       	vmulps %ymm13,%ymm12,%ymm12
     f7e:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     f83:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     f88:	c5 dc 58 ff          	vaddps %ymm7,%ymm4,%ymm7
     f8c:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
     f91:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
     f95:	c4 41 2c 59 d0       	vmulps %ymm8,%ymm10,%ymm10
     f9a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f9f:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
     fa4:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
     fa8:	c5 dc 59 e1          	vmulps %ymm1,%ymm4,%ymm4
     fac:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
     fb1:	c5 fc 5b c0          	vcvtdq2ps %ymm0,%ymm0
     fb5:	c5 fc 59 c1          	vmulps %ymm1,%ymm0,%ymm0
     fb9:	c5 c4 58 3d 20 00 00 	vaddps 0x20(%rip),%ymm7,%ymm7        # fe1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa51>
     fc0:	00 
     fc1:	c4 c1 6c 59 c8       	vmulps %ymm8,%ymm2,%ymm1
     fc6:	c4 41 2c 58 d4       	vaddps %ymm12,%ymm10,%ymm10
     fcb:	c5 fe 5b ff          	vcvttps2dq %ymm7,%ymm7
     fcf:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     fd4:	c4 c1 5c 58 e6       	vaddps %ymm14,%ymm4,%ymm4
     fd9:	c4 c1 5c 58 e2       	vaddps %ymm10,%ymm4,%ymm4
     fde:	c5 ad 72 d3 10       	vpsrld $0x10,%ymm3,%ymm10
     fe3:	c5 e5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm3
     fe8:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
     fed:	c4 e2 25 90 34 b8    	vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm6
     ff3:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     ff8:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
     ffd:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    1002:	c4 41 2c 59 d1       	vmulps %ymm9,%ymm10,%ymm10
    1007:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
    100b:	c5 dc 58 25 20 00 00 	vaddps 0x20(%rip),%ymm4,%ymm4        # 1033 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xaa3>
    1012:	00 
    1013:	c4 c1 64 59 dd       	vmulps %ymm13,%ymm3,%ymm3
    1018:	c5 fe 5b e4          	vcvttps2dq %ymm4,%ymm4
    101c:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1021:	c4 c1 7c 58 c2       	vaddps %ymm10,%ymm0,%ymm0
    1026:	c5 f4 58 cb          	vaddps %ymm3,%ymm1,%ymm1
    102a:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
    102e:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
    1032:	c5 fc 58 05 20 00 00 	vaddps 0x20(%rip),%ymm0,%ymm0        # 105a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xaca>
    1039:	00 
    103a:	48 8b 85 28 01 00 00 	mov    0x128(%rbp),%rax
    1041:	8b 8d 74 01 00 00    	mov    0x174(%rbp),%ecx
    1047:	8b 95 70 01 00 00    	mov    0x170(%rbp),%edx
    104d:	c4 e2 65 90 3c a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm7
    1053:	48 8b 85 30 01 00 00 	mov    0x130(%rbp),%rax
    105a:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    105e:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1062:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    1066:	c5 fe 5b c0          	vcvttps2dq %ymm0,%ymm0
    106a:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    106e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1073:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1078:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    107d:	c4 62 5d 90 04 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm8
    1083:	c5 dd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm4
    1088:	48 8b 85 68 01 00 00 	mov    0x168(%rbp),%rax
    108f:	c5 c5 db fd          	vpand  %ymm5,%ymm7,%ymm7
    1093:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    1098:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
    109d:	c5 cd db f5          	vpand  %ymm5,%ymm6,%ymm6
    10a1:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    10a6:	c4 c1 75 72 d0 11    	vpsrld $0x11,%ymm8,%ymm1
    10ac:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
    10b0:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    10b4:	c4 62 4d 39 e7       	vpminsd %ymm7,%ymm6,%ymm12
    10b9:	c5 4d fe f7          	vpaddd %ymm7,%ymm6,%ymm14
    10bd:	c4 41 0d fe f0       	vpaddd %ymm8,%ymm14,%ymm14
    10c2:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    10c6:	c5 c5 66 c6          	vpcmpgtd %ymm6,%ymm7,%ymm0
    10ca:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    10ce:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    10d2:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    10d8:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    10dc:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    10e1:	c4 c3 2d 4c c5 00    	vpblendvb %ymm0,%ymm13,%ymm10,%ymm0
    10e7:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    10eb:	c4 e2 75 90 14 a8    	vpgatherdd %ymm1,(%rax,%ymm5,4),%ymm2
    10f1:	c4 e2 4d 3d cf       	vpmaxsd %ymm7,%ymm6,%ymm1
    10f6:	c5 3d 66 c9          	vpcmpgtd %ymm1,%ymm8,%ymm9
    10fa:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    10fe:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    1104:	c4 c2 75 3d c8       	vpmaxsd %ymm8,%ymm1,%ymm1
    1109:	c4 e3 7d 4c 44 24 20 	vpblendvb %ymm9,0x20(%rsp),%ymm0,%ymm0
    1110:	90 
    1111:	c4 42 1d 39 c8       	vpminsd %ymm8,%ymm12,%ymm9
    1116:	c4 41 1d 66 e0       	vpcmpgtd %ymm8,%ymm12,%ymm12
    111b:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    111f:	c4 41 6d db c7       	vpand  %ymm15,%ymm2,%ymm8
    1124:	c4 e2 25 90 04 a0    	vpgatherdd %ymm11,(%rax,%ymm4,4),%ymm0
    112a:	c4 c3 2d 4c e5 60    	vpblendvb %ymm6,%ymm13,%ymm10,%ymm4
    1130:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    1135:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
    113a:	c5 45 fa d1          	vpsubd %ymm1,%ymm7,%ymm10
    113e:	c4 c1 75 fe f9       	vpaddd %ymm9,%ymm1,%ymm7
    1143:	c4 e3 5d 4c 64 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm4,%ymm4
    114a:	c0 
    114b:	c4 41 65 db e7       	vpand  %ymm15,%ymm3,%ymm12
    1150:	c4 41 7c 5b d2       	vcvtdq2ps %ymm10,%ymm10
    1155:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    1159:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    115e:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
    1163:	c5 fc 5b e4          	vcvtdq2ps %ymm4,%ymm4
    1167:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
    116c:	c4 e2 25 90 34 a8    	vpgatherdd %ymm11,(%rax,%ymm5,4),%ymm6
    1172:	c5 f5 fe ef          	vpaddd %ymm7,%ymm1,%ymm5
    1176:	c5 b5 fe cf          	vpaddd %ymm7,%ymm9,%ymm1
    117a:	c4 41 4d db df       	vpand  %ymm15,%ymm6,%ymm11
    117f:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
    1184:	c4 41 7c 5b c9       	vcvtdq2ps %ymm9,%ymm9
    1189:	c5 8d fa f9          	vpsubd %ymm1,%ymm14,%ymm7
    118d:	c5 fc 5b ed          	vcvtdq2ps %ymm5,%ymm5
    1191:	c4 c1 3c 59 c9       	vmulps %ymm9,%ymm8,%ymm1
    1196:	c4 41 7c 5b db       	vcvtdq2ps %ymm11,%ymm11
    119b:	c5 fc 5b ff          	vcvtdq2ps %ymm7,%ymm7
    119f:	c5 dc 59 e5          	vmulps %ymm5,%ymm4,%ymm4
    11a3:	c5 bd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm8
    11a8:	c5 24 59 df          	vmulps %ymm7,%ymm11,%ymm11
    11ac:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    11b1:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
    11b6:	c4 41 3c 59 c1       	vmulps %ymm9,%ymm8,%ymm8
    11bb:	c4 c1 5c 58 e4       	vaddps %ymm12,%ymm4,%ymm4
    11c0:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    11c5:	c4 c1 74 58 cb       	vaddps %ymm11,%ymm1,%ymm1
    11ca:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    11cf:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    11d4:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    11d9:	c4 41 7c 5b e4       	vcvtdq2ps %ymm12,%ymm12
    11de:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    11e3:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
    11e8:	c4 41 7c 5b db       	vcvtdq2ps %ymm11,%ymm11
    11ed:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    11f2:	c5 dc 58 e1          	vaddps %ymm1,%ymm4,%ymm4
    11f6:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    11fb:	c5 fc 5b f6          	vcvtdq2ps %ymm6,%ymm6
    11ff:	c5 24 59 df          	vmulps %ymm7,%ymm11,%ymm11
    1203:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1208:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    120d:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
    1211:	c5 f4 59 cd          	vmulps %ymm5,%ymm1,%ymm1
    1215:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    121a:	c5 fc 5b c0          	vcvtdq2ps %ymm0,%ymm0
    121e:	c5 cc 59 f7          	vmulps %ymm7,%ymm6,%ymm6
    1222:	c5 dc 58 25 20 00 00 	vaddps 0x20(%rip),%ymm4,%ymm4        # 124a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcba>
    1229:	00 
    122a:	c4 41 3c 58 c3       	vaddps %ymm11,%ymm8,%ymm8
    122f:	c5 fe 5b e4          	vcvttps2dq %ymm4,%ymm4
    1233:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1238:	c4 c1 74 58 cc       	vaddps %ymm12,%ymm1,%ymm1
    123d:	c4 c1 74 58 c8       	vaddps %ymm8,%ymm1,%ymm1
    1242:	c5 bd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm8
    1247:	c5 e5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm3
    124c:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1251:	c5 fc 59 d5          	vmulps %ymm5,%ymm0,%ymm2
    1255:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    125a:	c4 41 7c 5b c0       	vcvtdq2ps %ymm8,%ymm8
    125f:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
    1263:	c4 41 3c 59 c2       	vmulps %ymm10,%ymm8,%ymm8
    1268:	c5 f4 58 0d 20 00 00 	vaddps 0x20(%rip),%ymm1,%ymm1        # 1290 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd00>
    126f:	00 
    1270:	c4 c1 64 59 c1       	vmulps %ymm9,%ymm3,%ymm0
    1275:	c5 fe 5b c9          	vcvttps2dq %ymm1,%ymm1
    1279:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    127e:	c4 c1 6c 58 d0       	vaddps %ymm8,%ymm2,%ymm2
    1283:	c5 fc 58 c6          	vaddps %ymm6,%ymm0,%ymm0
    1287:	c5 ec 58 d0          	vaddps %ymm0,%ymm2,%ymm2
    128b:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    1290:	c5 ec 58 15 20 00 00 	vaddps 0x20(%rip),%ymm2,%ymm2        # 12b8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd28>
    1297:	00 
    1298:	c5 fe 5b d2          	vcvttps2dq %ymm2,%ymm2
    129c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    12a1:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    12a6:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    12aa:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    12ae:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
    12b5:	00 00 00 
    12b8:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    12bc:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    12c2:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    12c7:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    12cc:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    12d0:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    12d7:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
    12de:	4c 39 d3             	cmp    %r10,%rbx
    12e1:	0f 85 91 f7 ff ff    	jne    a78 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4e8>
    12e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    12ee:	00 00 
    12f0:	c5 f8 77             	vzeroupper
    12f3:	c5 f8 28 b4 24 90 01 	vmovaps 0x190(%rsp),%xmm6
    12fa:	00 00 
    12fc:	c5 f8 28 bc 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm7
    1303:	00 00 
    1305:	c5 78 28 84 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm8
    130c:	00 00 
    130e:	c5 78 28 8c 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm9
    1315:	00 00 
    1317:	c5 78 28 94 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm10
    131e:	00 00 
    1320:	c5 78 28 9c 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm11
    1327:	00 00 
    1329:	c5 78 28 a4 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm12
    1330:	00 00 
    1332:	c5 78 28 ac 24 00 02 	vmovaps 0x200(%rsp),%xmm13
    1339:	00 00 
    133b:	c5 78 28 b4 24 10 02 	vmovaps 0x210(%rsp),%xmm14
    1342:	00 00 
    1344:	c5 78 28 bc 24 20 02 	vmovaps 0x220(%rsp),%xmm15
    134b:	00 00 
    134d:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
    1354:	5b                   	pop    %rbx
    1355:	5e                   	pop    %rsi
    1356:	5f                   	pop    %rdi
    1357:	5d                   	pop    %rbp
    1358:	41 5c                	pop    %r12
    135a:	41 5d                	pop    %r13
    135c:	c3                   	ret
    135d:	90                   	nop
    135e:	90                   	nop
    135f:	90                   	nop
