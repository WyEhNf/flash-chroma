file(REMOVE_RECURSE
  "CMakeFiles/jshc.dir/link.d"
  "CMakeFiles/jshc.dir/cpp/src/main.cpp.o"
  "CMakeFiles/jshc.dir/cpp/src/main.cpp.o.d"
  "jshc"
  "jshc.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
