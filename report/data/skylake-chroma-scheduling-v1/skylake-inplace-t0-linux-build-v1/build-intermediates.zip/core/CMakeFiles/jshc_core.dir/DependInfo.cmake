
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/f/Hackathon/projects/16-lut-color/portable/src/jshc_portable.c" "core/CMakeFiles/jshc_core.dir/portable/src/jshc_portable.c.o" "gcc" "core/CMakeFiles/jshc_core.dir/portable/src/jshc_portable.c.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/cpp/src/fit_r14.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/fit_r14.cpp.o" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/fit_r14.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/cpp/src/lut.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/lut.cpp.o" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/lut.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/cpp/src/lut_simd_avx2.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/lut_simd_avx2.cpp.o" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/lut_simd_avx2.cpp.o.d"
  "/mnt/f/Hackathon/projects/16-lut-color/cpp/src/portable_bridge.cpp" "core/CMakeFiles/jshc_core.dir/cpp/src/portable_bridge.cpp.o" "gcc" "core/CMakeFiles/jshc_core.dir/cpp/src/portable_bridge.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
