file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_reference.dir/link.d"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_reference.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/outplace_bench.cpp.o.d"
  "CMakeFiles/jshc_skylake_reference.dir/reference_to.cpp.o"
  "CMakeFiles/jshc_skylake_reference.dir/reference_to.cpp.o.d"
  "libjshc_skylake_reference.pdb"
  "libjshc_skylake_reference.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_reference.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
