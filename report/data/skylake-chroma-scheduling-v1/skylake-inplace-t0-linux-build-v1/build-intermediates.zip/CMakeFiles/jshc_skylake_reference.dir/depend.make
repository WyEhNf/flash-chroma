# Empty dependencies file for jshc_skylake_reference.
# This may be replaced when dependencies are built.
