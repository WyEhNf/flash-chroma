file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/link.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_chroma_batch4_io.dir/outplace_bench.cpp.o.d"
  "libjshc_skylake_chroma_batch4_io.pdb"
  "libjshc_skylake_chroma_batch4_io.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_chroma_batch4_io.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
