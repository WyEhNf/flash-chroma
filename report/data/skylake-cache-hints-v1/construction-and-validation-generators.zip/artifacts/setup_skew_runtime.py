"""冻结41：在38基础上用可逆xorshift置换精确索引，保持16MiB及缓存行分组。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-sourcehint-runtime';out=ROOT/'experiments/skylake-skew-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_sourcehint','skylake_skew').replace('avx2_chain_sourcehint','avx2_chain_skew')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 38;','jshc_cc_revision(void) {return 41;')
        s=s.replace('const uint32_t address=uint32_t(group)*4+k;\n          const size_t i=((address&255u)<<16)|(address&0xff00u)|(address>>16);', '''const uint32_t address=uint32_t(group)*4+k;
          const uint32_t code=address^(address>>10)^(address>>20);
          const size_t i=((code&255u)<<16)|(code&0xff00u)|(code>>16);''')
        s=s.replace('uint32_t(!h.direct_index.empty()),9,0,','uint32_t(!h.direct_index.empty()),10,0,')
    if p.name=='channel_avx2.cpp':
        assert s.count('reinterpret_cast<const uint8_t*>(table)[code]]')==2
        s=s.replace('reinterpret_cast<const uint8_t*>(table)[code]]', 'reinterpret_cast<const uint8_t*>(table)[code^(code>>10)]]')
        oldwide='uint32_t code;std::memcpy(&code,p+offset,4);return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code&0xffffff]]);'
        assert oldwide in s
        s=s.replace(oldwide,'uint32_t code;std::memcpy(&code,p+offset,4);code&=0xffffff;return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code^(code>>10)]]);')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-sourcehint-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；16MiB精确ID索引可逆置换，研究二次幂平面步长的组冲突',candidate='输入小端码c的地址h=c^(c>>10)，构造逆变换c=h^(h>>10)^(h>>20)；缓存行分组与容量不变，增加两个地址ALU操作',revisions={'reference':23,'candidate':41},cmake_project='experiments/skylake-skew-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_skew'])
plan['skew_policy']={'format':10,'table_bytes':2**24,'forward':'h=c^(c>>10)','inverse':'c=h^(h>>10)^(h>>20)','cacheline_mapping':'h>>6=(c>>6)^(c>>16)，18bit缓存行号可逆，组内只置换64字节','extra_address_alu':2,'choice':'一次固定可逆xorshift，分散B平面65536字节步长；不扫描hash参数','hypothesis':'常规低位组索引模型中缓解私有缓存冲突；实际CPU索引/缓存收益仍需测量，不预设效果'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-sourcehint-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-skew-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结41，未构建或计时')
