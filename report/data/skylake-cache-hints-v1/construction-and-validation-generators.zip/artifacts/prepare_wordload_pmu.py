"""冻结40/42配对计数；主词普通加载与字节索引直接比较，不生成墙钟成绩。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/profile_skylake_sourcehint_pmu.py').read_text(encoding='utf-8').replace('37/38','40/42')
s=s.replace("pages['bytes']==2**24", "pages['bytes']==(2**23 if label=='wordload42' else 2**24)")
new='scripts/profile_skylake_wordload_pmu.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference40','batchspan',40),('wordload42','wordload',42)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v{2 if name=="wordload" else 1}/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-wordload-v1.json');p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference40','wordload42']},{'threads':4,'variants':['wordload42','reference40']}]
p['purpose']='40直接对42主词普通加载的单次计数；1/4线程四配置，不替代ABBA速度，不与其他画像相除'
dest=ROOT/'experiments/skylake-wordload-pmu-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结42配对计数，未调用候选')
