"""冻结38/40直接计数，只考察工作块变化，不生成墙钟提速结论。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/profile_skylake_sourcehint_pmu.py').read_text(encoding='utf-8').replace('37/38','38/40')
new='scripts/profile_skylake_batchspan_pmu.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference38','sourcehint',38),('batchspan40','batchspan',40)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-batchspan-v1.json');p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference38','batchspan40']},{'threads':4,'variants':['batchspan40','reference38']}]
p['purpose']='38直接对40固定65536工作块的单次计数；两版1/4线程四配置，不替代ABBA速度，不与其他画像相除'
(ROOT/'experiments/skylake-batchspan-pmu-v1.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结40配对计数，未调用候选')
