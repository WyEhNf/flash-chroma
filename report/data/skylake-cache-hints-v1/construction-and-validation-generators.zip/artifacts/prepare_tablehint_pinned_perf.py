"""冻结39索引表提示首次固定绑定计时，不混入38数据。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_stream_pinned_linux.py').read_text(encoding='utf-8').replace('比较37与23','比较39与23').replace('bench_skylake_stream_pinned_linux.py','bench_skylake_tablehint_pinned_linux.py').replace('小端非临时输出索引','小端T0前瞻输出索引').replace('37首次计时','39首次计时')
new='scripts/bench_skylake_tablehint_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-stream-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-tablehint-v1.json','build':'artifacts/skylake-tablehint-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-tablehint-linux-full-v1/results.json','validation':'experiments/skylake-tablehint-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='39固定64像素索引T0前瞻，首次四物理核绑定直接对23；不叠加38源提示，不混算它的测量'
(ROOT/'experiments/skylake-tablehint-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结39首次绑定性能策略，未计时')
