"""冻结39完整色域、保护页和未来64像素索引地址验证。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_stream_linux.py').read_text(encoding='utf-8').replace('RGB24非临时写入及完整缓存行37','RGB24精确索引表T0前瞻39')
new='scripts/verify_skylake_tablehint_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'39完整16M表/24组色域、64偏移/别名与保护页，含127/128/129未来块边界及最后RGB精确3字节读取，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-tablehint-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-tablehint-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结39验证器，未运行')
