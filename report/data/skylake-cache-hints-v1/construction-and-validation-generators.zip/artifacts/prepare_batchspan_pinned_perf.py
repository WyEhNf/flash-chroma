"""冻结40首次固定绑定计时；块长唯一65536，不扫描。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_sourcehint_pinned_linux.py').read_text(encoding='utf-8').replace('比较38与23','比较40与23').replace('bench_skylake_sourcehint_pinned_linux.py','bench_skylake_batchspan_pinned_linux.py').replace('小端输入NTA输出索引','小端大工作块NTA输出索引').replace('38首次计时','40首次计时')
new='scripts/bench_skylake_batchspan_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-sourcehint-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-batchspan-v1.json','build':'artifacts/skylake-batchspan-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-batchspan-linux-full-v1/results.json','validation':'experiments/skylake-batchspan-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='40固定65536像素块，在38源提示基础上摊薄每块fence/前缀；首次四核绑定直接对23，像素分区不变，不扫描块长'
(ROOT/'experiments/skylake-batchspan-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结40首次绑定性能策略，未计时')
