"""冻结40大工作块验证；完整域每次四个65536块，额外跨65536/131072边界。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_sourcehint_linux.py').read_text(encoding='utf-8').replace('RGB24精确输入NTA提示38','RGB24精确大工作块40')
assert 'range(4097*3)' in s;s=s.replace('range(4097*3)','range(131073*3)')
a=s.index('            # 65536像素');b=s.index('            outputs =',a);block=s[a:b]
assert block.count('for red in range(256):')==1
block=block.replace('for red in range(256):','for red in range(0,256,4):')
old="source = bytearray(65536*3); source[0::3] = bytes([red])*65536"
assert old in block
block=block.replace(old,"source = bytearray(4*65536*3); source[0::3] = b''.join(bytes([r])*65536 for r in range(red,red+4))")
block=block.replace('source[1::3] = gb[0::2]; source[2::3] = gb[1::2]', 'source[1::3] = gb[0::2]*4; source[2::3] = gb[1::2]*4')
block=block.replace('counts[key] += 65536','counts[key] += 4*65536').replace('out_counts[key]+=65536','out_counts[key]+=4*65536')
block=block.replace('# 65536像素是4096批与8像素向量的整倍数；遍历所有RGB8输入一次。','# 262144像素覆盖四个新65536工作块，显式请求4可覆盖四块；RGB顺序完整遍历。')
s=s[:a]+block+s[b:]
s=s.replace("'finite_backend_offset_comparisons': finite", "'full_input_chunk_pixels':262144,'finite_backend_offset_comparisons': finite")
new='scripts/verify_skylake_batchspan_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'40大块边界/保护页与24组完整域；每次262144像素覆盖4新块，全部16M独立解码，65536/131072边界补验，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-batchspan-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-batchspan-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结40验证器，未运行')
