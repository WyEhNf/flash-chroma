"""冻结37与38的直接PMU比较，四配置仅一次计数，不产生新墙钟成绩。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/profile_skylake_pmu.py').read_text(encoding='utf-8').replace('23/33/35/37各一次计数','37/38各一次计数')
s=s.replace('assert len(records)==8','assert len(records)==4').replace("'candidate_warmup_calls':8", "'candidate_warmup_calls':4").replace("'candidate_counted_calls':8", "'candidate_counted_calls':4")
new='scripts/profile_skylake_sourcehint_pmu.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
policy=read('experiments/skylake-pmu-profile-v1.json');policy['cases']={}
for label,name,revision in [('reference37','stream',37),('sourcehint38','sourcehint',38)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    policy['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
policy['models_plan']=spec('experiments/skylake-sourcehint-v1.json');policy['script']=spec(new)
policy['python_sources']=[new if x=='scripts/profile_skylake_pmu.py' else x for x in policy['python_sources']]
policy['orders']=[{'threads':1,'variants':['reference37','sourcehint38']},{'threads':4,'variants':['sourcehint38','reference37']}]
policy['purpose']='37直接对38固定输入NTA提示的单次硬件计数；两版1/4线程共四配置，不重新生成墙钟速度；无论性能结果如何都保留'
policy['limits']=[x.replace('每配置一个预热与一个计数调用','每配置一个预热与一个计数调用（共4+4）') for x in policy['limits']]
(ROOT/'experiments/skylake-sourcehint-pmu-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结38配对计数，未调用候选')
