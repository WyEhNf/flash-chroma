"""冻结38首次固定绑定计时，包含全部源提示、前后缀和fence。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_stream_pinned_linux.py').read_text(encoding='utf-8').replace('比较37与23','比较38与23').replace('bench_skylake_stream_pinned_linux.py','bench_skylake_sourcehint_pinned_linux.py').replace('小端非临时输出索引','小端输入NTA输出索引').replace('37首次计时','38首次计时')
new='scripts/bench_skylake_sourcehint_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-stream-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-sourcehint-v1.json','build':'artifacts/skylake-sourcehint-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-sourcehint-linux-full-v1/results.json','validation':'experiments/skylake-sourcehint-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='38固定输入NTA提示，首次四物理核绑定直接对23；所有提示与fence计入真实API，不因计数画像而重测'
(ROOT/'experiments/skylake-sourcehint-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结38首次绑定性能策略，未计时')
