"""冻结39：从37独立派生，一块64像素前瞻的精确索引T0预取，不叠加38输入NTA。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-stream-runtime';out=ROOT/'experiments/skylake-tablehint-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_stream','skylake_tablehint').replace('avx2_chain_stream','avx2_chain_tablehint')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 37;','jshc_cc_revision(void) {return 39;')
    if p.name=='channel_avx2.cpp':
        marker='inline __attribute__((always_inline)) void run('
        s=s.replace(marker,'''// 未来块的全部64个精确字节索引；最后一个RGB只读3字节。
template<size_t Index>
inline __attribute__((always_inline)) void hint_one(const uint32_t* table,const uint8_t* source) {
  uint32_t code;
  if constexpr(Index==63) {uint16_t low;std::memcpy(&low,source+3*Index,2);code=uint32_t(low)|(uint32_t(source[3*Index+2])<<16);}
  else {std::memcpy(&code,source+3*Index,4);code&=0xffffff;}
  _mm_prefetch(reinterpret_cast<const char*>(reinterpret_cast<const uint8_t*>(table)+code),_MM_HINT_T0);
}
template<size_t Base>
inline __attribute__((always_inline)) void hint_eight(const uint32_t* table,const uint8_t* source) {
  hint_one<Base>(table,source);hint_one<Base+1>(table,source);hint_one<Base+2>(table,source);hint_one<Base+3>(table,source);
  hint_one<Base+4>(table,source);hint_one<Base+5>(table,source);hint_one<Base+6>(table,source);hint_one<Base+7>(table,source);
}
'''+marker,1)
        s=s.replace('  for(;p+72<=pixels;p+=64) {', '''  for(;p+72<=pixels;p+=64) {
    if(p+128<=pixels) {
      const uint8_t* future=source+3*(p+64);
      hint_eight<0>(table,future);hint_eight<8>(table,future);hint_eight<16>(table,future);hint_eight<24>(table,future);
      hint_eight<32>(table,future);hint_eight<40>(table,future);hint_eight<48>(table,future);hint_eight<56>(table,future);
    }''',1)
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-stream-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；独立研究精确ID表的固定T0前瞻，保持37输出方式',candidate='预读未来64像素输入码，为其64个精确ID地址发T0提示；不叠加38的源NTA，所有地址在本线程块内',base_commit='acaf2b2',revisions={'reference':23,'candidate':39},cmake_project='experiments/skylake-tablehint-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tablehint'])
plan['tablehint_policy']={'lookahead_pixels':64,'hint':'_MM_HINT_T0','hints_per_stream_block':64,'future_required_pixels':128,'last_future_rgb_read_bytes':3,'hint_may_be_ignored':True,'choice':'固定一个处理块前瞻，不扫描距离或采样密度','hypothesis':'在指令较少但周期未相应下降的画像后，验证提前发起独立查表请求是否有收益；不是已证瓶颈'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-stream-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-tablehint-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结39，未构建或计时')
