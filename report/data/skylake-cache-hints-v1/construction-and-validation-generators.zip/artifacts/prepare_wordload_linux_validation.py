"""冻结42验证：独立解码全部16M颜色和原精确主词对照，完整四线程大块边界。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_batchspan_linux.py').read_text(encoding='utf-8').replace('RGB24精确大工作块40','RGB24精确主词普通加载42')
s=s.replace("direct_state['format']!=9 or direct_state['entries']!=2**22 or direct_state['table_capacity_bytes']!=2**24","direct_state['format']!=11 or direct_state['entries']!=2**21 or direct_state['table_capacity_bytes']!=2**23")
s=s.replace("pages_state['bytes']!=2**24","pages_state['bytes']!=2**23").replace('words=(ct.c_uint32*(2**22))()','words=(ct.c_uint32*(2**21))()')
a=s.index('                    raw_table=ct.string_at(words,2**24)');b=s.index('                    guard=(ct.c_uint32*8)',a)
s=s[:a]+'''                    if bytes(words)!=bytes(old_words):raise AssertionError('THP主词与原23编码不一致')
                    pool=(ct.c_uint32*269708)();copy_pool=d.jshc_cc_copy_exceptions
                    copy_pool.argtypes=[ct.c_void_p,ct.POINTER(ct.c_uint32),ct.c_size_t];copy_pool.restype=ct.c_int
                    if copy_pool(h,pool,len(pool)) or pool[0] or pool[1]:raise AssertionError('例外池保护词不符')
                    for block,word in enumerate(words):
                        base=word%256
                        if base==255:
                            index=word//256
                            if index<2 or index+1>=len(pool):raise AssertionError('主词例外偏移越界')
                            packed=pool[index].to_bytes(4,'little')+pool[index+1].to_bytes(4,'little')
                            ids=tuple(packed)
                        else:
                            payload=word//256
                            ids=tuple(base+(payload//(8**k))%8 for k in range(8))
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('主词解码ID越界')
                        if b''.join(palette_rgb[i] for i in ids)!=cube[block*24:block*24+24]:raise AssertionError('独立整数除法主词完整域不符')
                    del old_words,pool
'''+s[b:]
new='scripts/verify_skylake_wordload_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def digest(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v={'purpose':'42主词GPR/向量解码、全部16M独立整数除法解码、原23主词字节对照，24组完整域和大块保护页，不计时','plan_sha256':digest('experiments/skylake-wordload-v1.json'),'source_sha256':{k:digest(k) for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
dest=ROOT/'experiments/skylake-wordload-validation-v1.json';assert not dest.exists();dest.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结42验证器，未调用像素入口')
