"""冻结40：在38基础上以65536像素工作块摊薄前缀、NTA启动与SFENCE；不扫描块长。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-sourcehint-runtime';out=ROOT/'experiments/skylake-batchspan-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_sourcehint','skylake_batchspan').replace('avx2_chain_sourcehint','avx2_chain_batchspan')
    if p.name=='channel_runtime.cpp':
        assert s.count('4096')==8
        s=s.replace('4096','65536').replace('jshc_cc_revision(void) {return 38;','jshc_cc_revision(void) {return 40;')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-sourcehint-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；输入NTA和精确37输出不变，工作块65536像素摊薄每块成本',candidate='工作块4096→65536；固定1024×768图的四线程连续像素分区相同，块数及每块fence/前缀减少16倍',revisions={'reference':23,'candidate':40},cmake_project='experiments/skylake-batchspan-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_batchspan'])
plan['batchspan_policy']={'work_block_pixels':65536,'old_block_pixels':4096,'fixed_image_pixels':1024*768,'blocks_per_image':12,'full_validation_chunk_pixels':262144,'choice':'只选择65536：每图12块、每核3块，四线程分区与旧4096块相同；不扫描块长','constructor_threads':4,'model_bytes_unchanged':True}
plan['contract']['lengths']=sorted(set(plan['contract']['lengths']+[65528,65535,65536,65537,65543,131071,131072,131073]))
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-sourcehint-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-batchspan-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结40，未构建或计时')
