"""冻结38：37的精确映射/非临时输出不变，添加固定1KiB输入流NTA预取。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-stream-runtime';out=ROOT/'experiments/skylake-sourcehint-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_stream','skylake_sourcehint').replace('avx2_chain_stream','avx2_chain_sourcehint')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 37;','jshc_cc_revision(void) {return 38;')
    if p.name=='channel_avx2.cpp':
        s=s.replace('  size_t p=0;\n  // 对齐', '''  size_t p=0;
  // 初始窗口只形成有效输入范围内的地址；NTA为提示，CPU可以忽略。
  const size_t initial=pixels*3<1024?pixels*3:1024;
  for(size_t offset=0;offset<initial;offset+=64)_mm_prefetch(reinterpret_cast<const char*>(source+offset),_MM_HINT_NTA);
  // 对齐''',1)
        s=s.replace('  for(;p+72<=pixels;p+=64) {', '''  for(;p+72<=pixels;p+=64) {
    // 固定16缓存行前瞻；四个地址覆盖未来192字节，包括非对齐源末行。
    if(p+406<=pixels) {
      const uint8_t* future=source+3*p+1024;
      _mm_prefetch(reinterpret_cast<const char*>(future),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+64),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+128),_MM_HINT_NTA);
      _mm_prefetch(reinterpret_cast<const char*>(future+191),_MM_HINT_NTA);
    }''',1)
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-stream-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；精确37基础上用固定输入流NTA提示研究缓存污染',candidate='源初始1KiB逐64字节预取，主体四地址前瞻1KiB；所有地址严格在本线程输入块内，不调参数择时',base_commit='acaf2b2',revisions={'reference':23,'candidate':38},cmake_project='experiments/skylake-sourcehint-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_sourcehint'])
plan['sourcehint_policy']={'lookahead_bytes':1024,'initial_window_max_bytes':1024,'cacheline_step':64,'hint':'_MM_HINT_NTA','future_offsets':[0,64,128,191],'future_required_pixels':406,'hint_may_be_ignored':True,'choice':'一次固定16缓存行策略，不扫描距离/层级后挑时间','hypothesis':'减少输入流缓存干扰，需真实计时与通用PMU事件分别核对，不预设效果'}
plan['contract']['lengths']=sorted(set(plan['contract']['lengths']+[341,342,343,405,406,407]))
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-stream-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-sourcehint-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结38，未构建或计时')
