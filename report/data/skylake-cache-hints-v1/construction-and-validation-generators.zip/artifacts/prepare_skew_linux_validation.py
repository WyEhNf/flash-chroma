"""冻结41独立按R/G/B坐标解码，不复用C++xorshift逆式。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_sourcehint_linux.py').read_text(encoding='utf-8').replace('RGB24精确输入NTA提示38','RGB24精确缓存组索引置换41')
s=s.replace("direct_state['format']!=9", "direct_state['format']!=10")
a=s.index('                    raw_table=ct.string_at(');b=s.index('                    guard=',a)
s=s[:a]+'''                    raw_table=ct.string_at(words,2**24)
                    # 独立拆分三通道位段；不调用构造器的逆变换。
                    bases=tuple(tuple((b<<16)|(((g&192)|((g&63)^(b>>2)))<<8)|((b&3)<<6) for b in range(256)) for g in range(256))
                    for r in range(256):
                        for g in range(256):
                            part=((r&63)^(g>>2))|((r>>6)<<6)
                            ids=bytes(raw_table[base^part] for base in bases[g])
                            if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('置换索引越过调色板')
                            start=(r*65536+g*256)*3
                            if b''.join(palette_rgb[i] for i in ids)!=cube[start:start+768]:raise AssertionError('独立三通道位段全表输出不符')
                    del old_words,raw_table,bases
'''+s[b:]
new='scripts/verify_skylake_skew_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'41按RGB位段独立重建16M表、24组完整域/保护页/64对齐；不复用xorshift逆式，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-skew-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-skew-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结41验证器，未运行')
