"""准备38—42阶段静态审计与协作检查，不调用像素或性能入口。"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'artifacts/skylake-cache-hints-delivery-v1'
s=(ROOT/'artifacts/skylake-load-packing-delivery-v1/check_remote.py').read_text(encoding='utf-8')
s=s.replace('skylake-threefold-delivery-v1/pre-create','skylake-load-packing-delivery-v1/pre-create').replace('report/data/skylake-threefold-v1/remote-check.json','report/data/skylake-load-packing-v1/remote-check.json')
s=s.replace("'b55a444']","'b55a444','acaf2b2']")
s=s.replace("'https://github.com/WyEhNf/flash-chroma/pull/47','status':'依赖b55a444检查点，正文与已发送文本逐字相同；没有评论/review/线程，常规CI成功不代替实验验收'","'https://github.com/WyEhNf/flash-chroma/pull/48','status':'依赖acaf2b2检查点；完整正文已读，新接口4线程3.0283倍为旧阶段单项证据；常规CI成功不代替实验验收'")
s=s.replace('相对23的3倍目标尚未达到，31—37仍未满足整体门槛；37仅四线程真实输出达到3.03倍','相对23的3倍整体目标仍未达到；38—42均保留全部门槛与失败，不以新接口单项达标代替整体')
(HERE/'check_remote.py').write_bytes(s.encode('utf-8'));compile(s,'check_remote.py','exec')
s=(ROOT/'artifacts/skylake-load-packing-delivery-v1/compare_refresh.py').read_text(encoding='utf-8').replace('新PR47','新PR48').replace('新增47','新增48').replace('包含47','包含48').replace('issues-47-','issues-48-').replace('pulls-47-','pulls-48-').replace("['p47']","['p48']").replace('41PR','42PR').replace('125组REST','128组REST').replace('report/data/skylake-load-packing-v1','report/data/skylake-cache-hints-v1')
(HERE/'compare_refresh.py').write_bytes(s.encode('utf-8'));compile(s,'compare_refresh.py','exec')
s=(ROOT/'scripts/audit_skylake_load_packing.py').read_text(encoding='utf-8')
s=s.replace('31—37、失败34与PMU画像','38—42、失败容量断言与五组配对PMU画像')
start=s.index('CASES=');end=s.index('\nEXPECTED=',start)
s=s[:start]+"CASES=[('sourcehint',38,1),('tablehint',39,1),('batchspan',40,1),('skew',41,1),('wordload',42,1)]"+s[end:]
s=s.replace("payload=2**22 if revision in (31,32) else 2**24", "payload=2**23 if revision==42 else 2**24")
s=s.replace("if revision==37:assert full['stream_alignment_comparisons']==1280", "assert full['stream_alignment_comparisons']==1280\n        assert full['independent_table_colors']==2**24\n        if revision in (40,42):assert full['full_input_chunk_pixels']==262144")
a=s.index('    failed=ROOT/');b=s.index("    a.output.write_text",a)
s=s[:a]+'''    failed=ROOT/'artifacts/skylake-wordload-linux-full-v1'
    assert not (failed/'results.json').exists() and read(failed/'failure-note.json')['exit_code']==1
    check_source(read(failed/'run.json'))
    pmustats=[]
    for name,_,_ in CASES:
        folder=ROOT/f'artifacts/skylake-{name}-pmu-v1';pmurun=read(folder/'run.json');pmu=read(folder/'results.json');check_source(pmurun)
        assert pmu['profile_completed'] and len(pmu['records'])==4 and pmu['candidate_wallclock_timing_calls']==0
        assert pmu['candidate_counted_calls']==4 and pmu['candidate_warmup_calls']==4
        for r in pmu['records']:
            assert r['output_sha256']==EXPECTED and r['multiplexing_acceptable'];tasks(r['tasks_before']);tasks(r['tasks_after'])
            assert {x['tid'] for x in r['tasks_before']}=={x['tid'] for x in r['tasks_after']}
            sums={key:sum(x['counts'][key] for x in r['thread_counters']) for key in r['sum_counts']};assert sums==r['sum_counts']
            assert r['cycles_per_pixel']==sums['cycles']/78643200 and r['instructions_per_pixel']==sums['instructions']/78643200
            pmustats.append({'profile':name,**{k:r[k] for k in ('variant','requested_threads','cycles_per_pixel','instructions_per_pixel','generic_cache_misses_per_pixel','multiplexing_acceptable')}})
    assert rounds==400
    a.output.parent.mkdir(parents=True,exist_ok=True);save={'pass':True,'purpose':__doc__,'cases':cases,'valid_mode_rounds':{'legacy':rounds,'outplace':rounds},'preserved_validation_failure':True,'pmu_sanity':pmustats,'new_native_calls':0,'new_performance_calls':0,'script_sha256':sha(__file__),'threefold_goal_completed':False}
'''+s[b:]
s=s.replace("print('31—37独立复核通过，完整模式轮次',2*rounds,'失败保留',2*partial_rounds,'PMU画像8项')", "print('38—42独立复核通过，完整模式轮次',2*rounds,'PMU画像',len(pmustats),'容量断言失败保留')")
new=ROOT/'scripts/audit_skylake_cache_hints.py';assert not new.exists();new.write_bytes(s.encode('utf-8'));compile(s,str(new),'exec')
# 档案核对源字节，不重新生成任何历史数据。
s=(ROOT/'scripts/audit_skylake_load_packing_archive.py').read_text(encoding='utf-8').replace('31—37','38—42').replace('失败保留、PMU源','容量断言失败保留、PMU源')
a=s.index('    full=[p for p in');b=s.index('    a.output.parent.mkdir',a)
s=s[:a]+'''    full=[p for p in a.archive.glob('*-full-v*/results.json')];assert len(full)==5 and all(read(p)['pass'] for p in full)
    audit=read(a.archive/'performance-audit.json');assert audit['pass'] and len(audit['cases'])==5
    assert audit['valid_mode_rounds']=={'legacy':400,'outplace':400} and audit['preserved_validation_failure']
    assert not (a.archive/'skylake-wordload-linux-full-v1/results.json').exists()
    assert read(a.archive/'skylake-wordload-linux-full-v1/failure-note.json')['exit_code']==1
    assert all(not read(p)['accepted_on_this_host'] for p in a.archive.glob('*-perf-v1/results.json'))
    pmus=[read(p) for p in a.archive.glob('*-pmu-v1/results.json')];assert len(pmus)==5
    assert all(x['profile_completed'] and len(x['records'])==4 and x['candidate_wallclock_timing_calls']==0 for x in pmus)
    result={'pass':True,'purpose':__doc__,'manifest_files':len(manifest['files']),'source_snapshots':snapshots,'source_members':members,'binary_members':binary_members,'full_domain_acceptances':len(full),'performance_comparisons':5,'preserved_failed_validations':1,'pmu_profiles':20,'threefold_goal_completed':False,'new_native_calls':0,'new_performance_calls':0,'script_sha256':sha(__file__)}
'''+s[b:]
new=ROOT/'scripts/audit_skylake_cache_hints_archive.py';assert not new.exists();new.write_bytes(s.encode('utf-8'));compile(s,str(new),'exec')
print('阶段审计与协作检查脚本已生成；尚未执行')
