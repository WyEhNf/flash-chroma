"""冻结41缓存行索引置换首次固定绑定计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_sourcehint_pinned_linux.py').read_text(encoding='utf-8').replace('比较38与23','比较41与23').replace('bench_skylake_sourcehint_pinned_linux.py','bench_skylake_skew_pinned_linux.py').replace('小端输入NTA输出索引','小端可逆置换输出索引').replace('38首次计时','41首次计时')
s=s.replace("state['format']!=9", "state['format']!=10")
new='scripts/bench_skylake_skew_pinned_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
policy=json.loads((ROOT/'experiments/skylake-sourcehint-linux-perf-v1.json').read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
for key,p in {'plan':'experiments/skylake-skew-v1.json','build':'artifacts/skylake-skew-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-skew-linux-full-v1/results.json','validation':'experiments/skylake-skew-validation-v1.json','benchmark_script':new}.items():policy[key]=spec(p)
policy['purpose']='41固定可逆缓存行置换，首次四核绑定直接对23；不改模型/容量，不扫描hash参数'
(ROOT/'experiments/skylake-skew-linux-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结41首次绑定性能策略，未计时')
