"""冻结42主词普通加载首次四进程计时，仍直接对23。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/bench_skylake_batchspan_pinned_linux.py').read_text(encoding='utf-8').replace('比较40与23','比较42与23').replace('bench_skylake_batchspan_pinned_linux.py','bench_skylake_wordload_pinned_linux.py').replace('40首次计时','42首次计时').replace('65536大工作块输出索引','8MiB精确主词普通加载')
s=s.replace("state['format']!=9", "state['format']!=11").replace("state['table_capacity_bytes']!=2**24", "state['table_capacity_bytes']!=2**23")
new='scripts/bench_skylake_wordload_pinned_linux.py';assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=json.loads((ROOT/'experiments/skylake-batchspan-linux-perf-v1.json').read_text(encoding='utf-8'))
for key,path in {'plan':'experiments/skylake-wordload-v1.json','build':'artifacts/skylake-wordload-linux-build-v1/build.json','full_acceptance':'artifacts/skylake-wordload-linux-full-v2/results.json','validation':'experiments/skylake-wordload-validation-v2.json','benchmark_script':new}.items():p[key]=spec(path)
p['purpose']='42固定8MiB主词GPR和精确向量解码，首次四核绑定直接对23，不扫描格式'
dest=ROOT/'experiments/skylake-wordload-linux-perf-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结42首次性能，未计时')
