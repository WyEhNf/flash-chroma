"""冻结37/39的直接硬件画像，独立于四进程墙钟比较。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/profile_skylake_sourcehint_pmu.py').read_text(encoding='utf-8').replace('37/38','37/39')
new='scripts/profile_skylake_tablehint_pmu.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference37','stream',37),('tablehint39','tablehint',39)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-tablehint-v1.json');p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference37','tablehint39']},{'threads':4,'variants':['tablehint39','reference37']}]
p['purpose']='37直接对39固定索引表T0前瞻的单次用户态计数，四配置不产生墙钟速度；全部保留，不与38混算'
(ROOT/'experiments/skylake-tablehint-pmu-v1.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结39配对计数，未调用候选')
