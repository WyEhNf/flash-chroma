"""冻结38完整域、保护页及NTA窗口边界检查。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_stream_linux.py').read_text(encoding='utf-8').replace('RGB24非临时写入及完整缓存行37','RGB24精确输入NTA提示38')
new='scripts/verify_skylake_sourcehint_linux.py';(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
v={'purpose':'38独立16M索引、24组完整域、64种目标偏移/别名与保护页，额外覆盖1KiB及406像素窗口边界，不计时','plan_sha256':hashlib.sha256((ROOT/'experiments/skylake-sourcehint-v1.json').read_bytes()).hexdigest(),'source_sha256':{k:hashlib.sha256((ROOT/k).read_bytes()).hexdigest() for k in (new,'scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')}}
(ROOT/'experiments/skylake-sourcehint-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结38验证器，未运行')
