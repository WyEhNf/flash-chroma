"""保留42首次验证失败，另立v2容量断言；不修改已执行源或库。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
old='scripts/verify_skylake_wordload_linux.py';new='scripts/verify_skylake_wordload_fixed_linux.py'
s=(ROOT/old).read_text(encoding='utf-8');assert s.count("memory['reference']['chain']==24+2**24")==1
s=s.replace("memory['reference']['chain']==24+2**24","memory['reference']['chain']==24+2**23").replace('核验LinuxRGB24精确主词普通加载42','核验LinuxRGB24精确主词普通加载42（容量修正v2）')
assert not (ROOT/new).exists();(ROOT/new).write_bytes(s.encode('utf-8'));compile(s,new,'exec')
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v=json.loads((ROOT/'experiments/skylake-wordload-validation-v1.json').read_text(encoding='utf-8'))
v['source_sha256']={new if k==old else k:sha(new if k==old else k) for k in v['source_sha256']}
v['purpose']+='；v2只修正结束容量断言16MiB→8MiB，v1失败保留'
(ROOT/'experiments/skylake-wordload-validation-v2.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('prepare_wordload_pinned_perf.py','prepare_wordload_pmu.py'):
    p=ROOT/'artifacts'/name;s=p.read_text(encoding='utf-8').replace('skylake-wordload-linux-full-v1','skylake-wordload-linux-full-v2').replace('skylake-wordload-validation-v1','skylake-wordload-validation-v2')
    # PMU目录通过循环动态生成，单独覆盖该构建的完整回执版本。
    if name=='prepare_wordload_pmu.py':s=s.replace("full=f'artifacts/skylake-{name}-linux-full-v1/results.json'","full=f'artifacts/skylake-{name}-linux-full-v{2 if name==\"wordload\" else 1}/results.json'")
    p.write_bytes(s.encode('utf-8'));compile(s,str(p),'exec')
note={'purpose':'记录首次42验收失败，不把退出码1写作通过','exit_code':1,'failed_assertion':"memory['candidate']['chain']-memory['reference']['chain']==24+2**24",'reason':'新8MiB主词表的预期仍沿用旧16MiB；仅验证器结束断言错误，原执行源/库不变','original_validation':old,'revised_validation':new,'original_complete_result_present':False,'performance_calls':0,'policy':'修正后在full-v2重新完整验收，full-v1不混算且不覆盖'}
(ROOT/'artifacts/skylake-wordload-linux-full-v1/failure-note.json').write_text(json.dumps(note,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结42容量修正验证，保留v1失败')
