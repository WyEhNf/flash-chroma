"""冻结42：主词8MiB普通加载，精确3bit/例外解码，保留40的大块和流式输出。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-wordload-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_wordload').replace('avx2_chain_batchspan','avx2_chain_wordload')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 42;')
        start=s.index('      // 四个输入ID');end=s.index('      info.temporary_peak_bytes+=h.direct_index.bytes();',start)
        s=s[:start]+'''      // 只复制已由四模型产生的原主词表；例外池和原诊断次序保持精确。
      h.direct_index.allocate(size_t{1}<<21);
      std::memcpy(h.direct_index.data(),h.compiled.data(),h.direct_index.bytes());
'''+s[end:]
        s=s.replace('h.direct_index.data(),h.output_palette.data(),','h.direct_index.data(),h.exceptions.data(),h.output_palette.data(),')
        s=s.replace('uint32_t(!h.direct_index.empty()),9,0,','uint32_t(!h.direct_index.empty()),11,0,')
    if p.name=='suffix_cache.hpp':
        s=s.replace('avx2_chain_wordload(const uint32_t*,const uint32_t*,uint8_t*','avx2_chain_wordload(const uint32_t*,const uint32_t*,const uint32_t*,uint8_t*')
        s=s.replace('avx2_chain_wordload_to(const uint32_t*,const uint32_t*,const uint8_t*','avx2_chain_wordload_to(const uint32_t*,const uint32_t*,const uint32_t*,const uint8_t*')
    if p.name=='channel_avx2.cpp':
        a=s.index('// 表按R低');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''// 首层用八个独立GPR加载，避免对8MiB主表执行硬件gather。
template<bool Wide> inline __attribute__((always_inline)) uint32_t word_at(const uint32_t* table,const uint8_t* p) {
  uint32_t code;
  if constexpr(Wide) {std::memcpy(&code,p,4);code=__builtin_bswap32(code)>>8;}
  else code=(uint32_t(p[0])<<16)|(uint32_t(p[1])<<8)|p[2];
  return table[code>>3];
}
template<bool Wide> inline __attribute__((always_inline)) __m256i read_words(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,const uint8_t* p) {
  const __m256i words=_mm256_setr_epi32(word_at<Wide>(table,p),word_at<Wide>(table,p+3),word_at<Wide>(table,p+6),word_at<Wide>(table,p+9),word_at<Wide>(table,p+12),word_at<Wide>(table,p+15),word_at<Wide>(table,p+18),word_at<Wide>(table,p+21));
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m256i raw=_mm256_inserti128_si256(_mm256_castsi128_si256(lo),_mm_alignr_epi8(last,lo,12),1);
  const __m256i code=_mm256_shuffle_epi8(raw,_mm256_setr_epi8(2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1,2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1));
  const __m256i mask255=_mm256_set1_epi32(255),base=_mm256_and_si256(words,mask255);
  const __m256i offset=_mm256_and_si256(code,_mm256_set1_epi32(7));
  const __m256i shift=_mm256_add_epi32(_mm256_add_epi32(offset,_mm256_slli_epi32(offset,1)),_mm256_set1_epi32(8));
  __m256i ids=_mm256_add_epi32(base,_mm256_and_si256(_mm256_srlv_epi32(words,shift),_mm256_set1_epi32(7)));
  const __m256i exceptional=_mm256_cmpeq_epi32(base,mask255);
  if(_mm256_movemask_epi8(exceptional)) {
    const __m256i index=_mm256_add_epi32(_mm256_and_si256(_mm256_srli_epi32(words,8),exceptional),_mm256_and_si256(_mm256_srli_epi32(code,2),_mm256_set1_epi32(1)));
    const __m256i packed=_mm256_i32gather_epi32(reinterpret_cast<const int*>(exceptions),index,4);
    const __m256i byte_shift=_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(3)),3);
    const __m256i exact=_mm256_and_si256(_mm256_srlv_epi32(packed,byte_shift),mask255);
    ids=_mm256_blendv_epi8(ids,exact,exceptional);
  }
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(palette),ids,4);
}
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,const uint8_t* p) {return read_words<false>(table,exceptions,palette,p);}
// 宽循环的最后一次4字节输入读取仍位于当前线程块内。
inline __attribute__((always_inline)) __m256i read_wide(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,const uint8_t* p) {return read_words<true>(table,exceptions,palette,p);}
'''+s[b:]
        a=s.index('inline __attribute__((always_inline)) void scalar_one');b=s.index('inline __attribute__((always_inline)) void run(',a)
        s=s[:a]+'''inline __attribute__((always_inline)) void scalar_one(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,const uint8_t* source,uint8_t* destination) {
  const uint32_t code=(uint32_t(source[0])<<16)|(uint32_t(source[1])<<8)|source[2],word=table[code>>3],base=word&255;
  const uint32_t id=base==255?((exceptions[(word>>8)+((code>>2)&1)]>>((code&3)*8))&255):base+((word>>(8+(code&7)*3))&7);
  const uint32_t value=palette[id];
  destination[0]=uint8_t(value);destination[1]=uint8_t(value>>8);destination[2]=uint8_t(value>>16);
}
'''+s[b:]
        s=s.replace('void run(const uint32_t* table,const uint32_t* palette,','void run(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,')
        s=s.replace('(table,palette,','(table,exceptions,palette,')
        s=s.replace('void avx2_chain_wordload(const uint32_t* table,const uint32_t* palette,','void avx2_chain_wordload(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,')
        s=s.replace('void avx2_chain_wordload_to(const uint32_t* table,const uint32_t* palette,','void avx2_chain_wordload_to(const uint32_t* table,const uint32_t* exceptions,const uint32_t* palette,')
        s=s.replace('// 精确全域字节索引：四包独立读取先行，按RGB24读取合法对齐词。','// 精确主词索引：GPR加载后用AVX2解码，例外池与调色板仍为精确读取。')
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对23的3倍目标；8MiB主词GPR加载加原精确解码，减少16MiB索引工作集',candidate='修订23主词字节复制到8MiB独立THP区，首层8个GPR加载；例外池及palette用AVX2 gather；沿用40输入NTA、65536块及完整缓存行NT输出',revisions={'reference':23,'candidate':42},cmake_project='experiments/skylake-wordload-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_wordload'])
plan['wordload_policy']={'format':11,'direct_words':2**21,'direct_bytes':2**23,'main_encoding':'原23，每块8颜色，低8bit为基ID，随后8个3bit差值；低字节255时高24bit为例外池偏移','source_index':'R<<16|G<<8|B，主词code>>3','original_compiled_copy_retained':True,'choice':'一次主词GPR+向量解码；不扫描格式参数','hypothesis':'减半索引工作集并避免首层大表gather；额外位运算和例外分支可能抵消收益'}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
dest=ROOT/'experiments/skylake-wordload-v1.json';assert not dest.exists();dest.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('冻结42，未构建或计时')
