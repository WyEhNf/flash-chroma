
artifacts\skylake-restrict-build-v1\CMakeFiles\jshc_skylake_restrict.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	41 57                	push   %r15
       2:	41 56                	push   %r14
       4:	41 55                	push   %r13
       6:	41 54                	push   %r12
       8:	55                   	push   %rbp
       9:	57                   	push   %rdi
       a:	56                   	push   %rsi
       b:	53                   	push   %rbx
       c:	48 81 ec e8 03 00 00 	sub    $0x3e8,%rsp
      13:	c5 f8 29 b4 24 40 03 	vmovaps %xmm6,0x340(%rsp)
      1a:	00 00 
      1c:	c5 f8 29 bc 24 50 03 	vmovaps %xmm7,0x350(%rsp)
      23:	00 00 
      25:	c5 78 29 84 24 60 03 	vmovaps %xmm8,0x360(%rsp)
      2c:	00 00 
      2e:	c5 78 29 8c 24 70 03 	vmovaps %xmm9,0x370(%rsp)
      35:	00 00 
      37:	c5 78 29 94 24 80 03 	vmovaps %xmm10,0x380(%rsp)
      3e:	00 00 
      40:	c5 78 29 9c 24 90 03 	vmovaps %xmm11,0x390(%rsp)
      47:	00 00 
      49:	c5 78 29 a4 24 a0 03 	vmovaps %xmm12,0x3a0(%rsp)
      50:	00 00 
      52:	c5 78 29 ac 24 b0 03 	vmovaps %xmm13,0x3b0(%rsp)
      59:	00 00 
      5b:	c5 78 29 b4 24 c0 03 	vmovaps %xmm14,0x3c0(%rsp)
      62:	00 00 
      64:	c5 78 29 bc 24 d0 03 	vmovaps %xmm15,0x3d0(%rsp)
      6b:	00 00 
      6d:	48 89 c8             	mov    %rcx,%rax
      70:	49 89 d2             	mov    %rdx,%r10
      73:	48 83 fa 04          	cmp    $0x4,%rdx
      77:	0f 84 14 09 00 00    	je     991 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x991>
      7d:	4d 85 c9             	test   %r9,%r9
      80:	0f 84 8e 08 00 00    	je     914 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x914>
      86:	49 ff c9             	dec    %r9
      89:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # 91 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x91>
      90:	00 
      91:	4d 89 c3             	mov    %r8,%r11
      94:	49 c1 e9 03          	shr    $0x3,%r9
      98:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
      9c:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
      a3:	00 00 
      a5:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # ed <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xed>
      ac:	00 
      ad:	4d 8d 4c d0 18       	lea    0x18(%r8,%rdx,8),%r9
      b2:	4f 8d 04 52          	lea    (%r10,%r10,2),%r8
      b6:	ba 00 80 00 00       	mov    $0x8000,%edx
      bb:	49 c1 e0 05          	shl    $0x5,%r8
      bf:	c5 f9 6e c2          	vmovd  %edx,%xmm0
      c3:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
      ca:	00 00 
      cc:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
      d0:	49 8d 1c 00          	lea    (%r8,%rax,1),%rbx
      d4:	c5 95 72 d6 18       	vpsrld $0x18,%ymm6,%ymm13
      d9:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
      de:	4d 89 c8             	mov    %r9,%r8
      e1:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
      e6:	49 89 d9             	mov    %rbx,%r9
      e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
      f0:	c4 c1 7a 6f 13       	vmovdqu (%r11),%xmm2
      f5:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
      fb:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
     101:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
     107:	c4 e2 6d 00 94 24 e0 	vpshufb 0x1e0(%rsp),%ymm2,%ymm2
     10e:	01 00 00 
     111:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
     116:	c4 c1 6d db c5       	vpand  %ymm13,%ymm2,%ymm0
     11b:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     120:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     125:	4d 85 d2             	test   %r10,%r10
     128:	0f 84 5a 08 00 00    	je     988 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x988>
     12e:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
     135:	00 00 
     137:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     13b:	48 89 c2             	mov    %rax,%rdx
     13e:	c5 fd 6f cc          	vmovdqa %ymm4,%ymm1
     142:	e9 2a 02 00 00       	jmp    371 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x371>
     147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     14e:	00 00 
     150:	c4 c1 5d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm4
     156:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
     15b:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     15f:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
     163:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
     167:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     16c:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     172:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
     177:	c5 dd fe ef          	vpaddd %ymm7,%ymm4,%ymm5
     17b:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
     182:	00 00 
     184:	c4 c1 55 72 e1 10    	vpsrad $0x10,%ymm9,%ymm5
     18a:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
     190:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     194:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
     19a:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
     1a0:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
     1a4:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
     1a8:	c5 b5 fe db          	vpaddd %ymm3,%ymm9,%ymm3
     1ac:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
     1b0:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
     1b5:	c5 75 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm8
     1b9:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
     1c0:	00 00 
     1c2:	c4 c1 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm2
     1c7:	c4 62 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm10
     1cc:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
     1d1:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
     1d5:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
     1da:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     1df:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
     1e3:	c4 63 1d 4c 44 24 60 	vpblendvb %ymm8,0x60(%rsp),%ymm12,%ymm8
     1ea:	80 
     1eb:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     1f1:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm8,%ymm8        # 21a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x21a>
     1f8:	00 00 20 
     1fb:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
     201:	c4 e3 1d 4c 4c 24 60 	vpblendvb %ymm1,0x60(%rsp),%ymm12,%ymm1
     208:	10 
     209:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 232 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x232>
     210:	00 00 a0 
     213:	c4 a2 0d 90 14 81    	vpgatherdd %ymm14,(%rcx,%ymm8,4),%ymm2
     219:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
     21d:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     221:	c4 e2 0d 90 1c 89    	vpgatherdd %ymm14,(%rcx,%ymm1,4),%ymm3
     227:	c5 fe 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm1
     22e:	00 00 
     230:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     235:	c4 62 5d 3d c7       	vpmaxsd %ymm7,%ymm4,%ymm8
     23a:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     23f:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     244:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     248:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     24d:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     252:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     256:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
     25a:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
     261:	00 00 
     263:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
     267:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     26c:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
     272:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     277:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
     27c:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
     281:	c4 62 35 39 d5       	vpminsd %ymm5,%ymm9,%ymm10
     286:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
     28a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     28e:	c5 c5 66 dc          	vpcmpgtd %ymm4,%ymm7,%ymm3
     292:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
     299:	00 00 
     29b:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     29f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     2a6:	00 00 
     2a8:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     2ac:	c4 c1 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm2
     2b1:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
     2b7:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
     2bd:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
     2c1:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
     2c6:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm4,%ymm4        # 2ef <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ef>
     2cd:	00 00 90 
     2d0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2d5:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
     2da:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm3,%ymm3        # 303 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x303>
     2e1:	00 00 20 
     2e4:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     2e8:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
     2ee:	c4 e2 0d 90 14 99    	vpgatherdd %ymm14,(%rcx,%ymm3,4),%ymm2
     2f4:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     2fa:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     2ff:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     303:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     308:	c4 e2 1d 90 1c a1    	vpgatherdd %ymm12,(%rcx,%ymm4,4),%ymm3
     30e:	c4 c1 45 fa e2       	vpsubd %ymm10,%ymm7,%ymm4
     313:	c5 fe 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm7
     31a:	00 00 
     31c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     321:	c5 dd fe ed          	vpaddd %ymm5,%ymm4,%ymm5
     325:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     32a:	c5 e5 fa e2          	vpsubd %ymm2,%ymm3,%ymm4
     32e:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
     332:	c4 e2 55 40 e4       	vpmulld %ymm4,%ymm5,%ymm4
     337:	c5 ed fa 94 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm2
     33e:	00 00 
     340:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     345:	48 83 c2 60          	add    $0x60,%rdx
     349:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     34e:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     352:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
     359:	00 00 
     35b:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
     35f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     364:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     368:	49 39 d1             	cmp    %rdx,%r9
     36b:	0f 84 46 05 00 00    	je     8b7 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8b7>
     371:	8b 72 54             	mov    0x54(%rdx),%esi
     374:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
     378:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     37f:	00 00 
     381:	c5 fd 6f c6          	vmovdqa %ymm6,%ymm0
     385:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
     38c:	00 00 
     38e:	8b 5a 50             	mov    0x50(%rdx),%ebx
     391:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     395:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
     399:	c5 f9 6e fe          	vmovd  %esi,%xmm7
     39d:	c4 e2 7d 90 14 89    	vpgatherdd %ymm0,(%rcx,%ymm1,4),%ymm2
     3a3:	48 8b 0a             	mov    (%rdx),%rcx
     3a6:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
     3aa:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     3af:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
     3b6:	00 00 
     3b8:	c5 79 6e e3          	vmovd  %ebx,%xmm12
     3bc:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
     3c1:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     3c7:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     3cc:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
     3d1:	8d 5c 1e 01          	lea    0x1(%rsi,%rbx,1),%ebx
     3d5:	c4 e2 65 90 04 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm0
     3db:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     3e0:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
     3e7:	00 00 
     3e9:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
     3ed:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
     3f2:	c4 a2 2d 90 1c 9f    	vpgatherdd %ymm10,(%rdi,%ymm11,4),%ymm3
     3f8:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 460 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x460>
     3ff:	00 
     400:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     405:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     40a:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 472 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x472>
     411:	00 
     412:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 47a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x47a>
     419:	00 
     41a:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
     41e:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
     422:	c4 62 6d 39 c0       	vpminsd %ymm0,%ymm2,%ymm8
     427:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     42b:	c5 f5 fe e5          	vpaddd %ymm5,%ymm1,%ymm4
     42f:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
     433:	c4 e2 75 90 2c a1    	vpgatherdd %ymm1,(%rcx,%ymm4,4),%ymm5
     439:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     43f:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
     444:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     449:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
     450:	00 00 
     452:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     457:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     45c:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
     463:	00 00 
     465:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
     46a:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     46f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     474:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
     47b:	00 00 
     47d:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     482:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     487:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
     48c:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
     493:	00 00 
     495:	c5 f9 6e cb          	vmovd  %ebx,%xmm1
     499:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     49e:	c5 75 fe dc          	vpaddd %ymm4,%ymm1,%ymm11
     4a2:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
     4a6:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
     4aa:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
     4b0:	c4 62 3d 39 c3       	vpminsd %ymm3,%ymm8,%ymm8
     4b5:	c4 22 75 90 14 99    	vpgatherdd %ymm1,(%rcx,%ymm11,4),%ymm10
     4bb:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
     4bf:	c4 e3 1d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm12,%ymm1
     4c5:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # 4ee <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ee>
     4cc:	00 00 40 
     4cf:	c5 ed 66 e0          	vpcmpgtd %ymm0,%ymm2,%ymm4
     4d3:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
     4d7:	c4 41 2d db dd       	vpand  %ymm13,%ymm10,%ymm11
     4dc:	c4 e2 35 90 3c 89    	vpgatherdd %ymm9,(%rcx,%ymm1,4),%ymm7
     4e2:	c5 0d fe 34 24       	vpaddd (%rsp),%ymm14,%ymm14
     4e7:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
     4eb:	c5 95 db cf          	vpand  %ymm7,%ymm13,%ymm1
     4ef:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
     4f6:	00 00 
     4f8:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
     4fe:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
     502:	c4 c2 25 40 f8       	vpmulld %ymm8,%ymm11,%ymm7
     507:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
     50b:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     512:	00 00 
     514:	c4 e2 6d 3d f8       	vpmaxsd %ymm0,%ymm2,%ymm7
     519:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
     51d:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
     522:	c5 3d fe ff          	vpaddd %ymm7,%ymm8,%ymm15
     526:	c4 41 65 fa ff       	vpsubd %ymm15,%ymm3,%ymm15
     52b:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm4,%ymm4        # 554 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x554>
     532:	00 00 90 
     535:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
     53b:	c4 62 25 90 0c a1    	vpgatherdd %ymm11,(%rcx,%ymm4,4),%ymm9
     541:	c5 6d fe d8          	vpaddd %ymm0,%ymm2,%ymm11
     545:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
     54a:	c4 41 05 fe db       	vpaddd %ymm11,%ymm15,%ymm11
     54f:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     553:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     557:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     55c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     561:	c5 dd fe a4 24 80 00 	vpaddd 0x80(%rsp),%ymm4,%ymm4
     568:	00 00 
     56a:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     56f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     573:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
     578:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
     57e:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     584:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
     58b:	00 00 
     58d:	c4 41 75 db fd       	vpand  %ymm13,%ymm1,%ymm15
     592:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     599:	00 00 
     59b:	c4 c1 2d db ed       	vpand  %ymm13,%ymm10,%ymm5
     5a0:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
     5a7:	00 00 
     5a9:	0f 85 49 02 00 00    	jne    7f8 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f8>
     5af:	48 8b 5a 28          	mov    0x28(%rdx),%rbx
     5b3:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
     5ba:	00 00 
     5bc:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5c0:	80 7a 59 00          	cmpb   $0x0,0x59(%rdx)
     5c4:	c4 62 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm9
     5ca:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
     5ce:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
     5d5:	00 00 
     5d7:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5db:	c4 e2 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm1
     5e1:	48 8b 5a 18          	mov    0x18(%rdx),%rbx
     5e5:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
     5ec:	00 00 
     5ee:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5f2:	c4 62 45 90 04 ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm8
     5f8:	0f 85 52 fb ff ff    	jne    150 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x150>
     5fe:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 666 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x666>
     605:	00 
     606:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 66e <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x66e>
     60d:	00 
     60e:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     612:	c5 b5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm3        # 67a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x67a>
     619:	00 
     61a:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
     620:	c4 e2 3d 3d e9       	vpmaxsd %ymm1,%ymm8,%ymm5
     625:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
     62a:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     630:	c4 e2 3d 39 e1       	vpminsd %ymm1,%ymm8,%ymm4
     635:	c5 e5 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm0
     639:	c4 e2 5d 39 fb       	vpminsd %ymm3,%ymm4,%ymm7
     63e:	c4 e2 55 3d eb       	vpmaxsd %ymm3,%ymm5,%ymm5
     643:	48 8b 5a 40          	mov    0x40(%rdx),%rbx
     647:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
     64b:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
     651:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm2,%ymm2        # 67a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x67a>
     658:	00 00 00 
     65b:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     660:	c4 e2 0d 90 04 91    	vpgatherdd %ymm14,(%rcx,%ymm2,4),%ymm0
     666:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
     66a:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     66e:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
     672:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
     677:	c5 d5 fe cf          	vpaddd %ymm7,%ymm5,%ymm1
     67b:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     67f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     684:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     688:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
     68e:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
     692:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 6bb <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6bb>
     699:	00 00 40 
     69c:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
     6a2:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
     6a6:	c4 e2 0d 90 24 91    	vpgatherdd %ymm14,(%rcx,%ymm2,4),%ymm4
     6ac:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     6b0:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     6b5:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     6ba:	c5 05 fa fc          	vpsubd %ymm4,%ymm15,%ymm15
     6be:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
     6c2:	c4 62 05 40 ff       	vpmulld %ymm7,%ymm15,%ymm15
     6c7:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     6ce:	00 00 
     6d0:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     6d5:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
     6dc:	00 00 
     6de:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
     6e5:	00 00 
     6e7:	c4 e2 65 90 24 bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm4
     6ed:	48 8b 5a 38          	mov    0x38(%rdx),%rbx
     6f1:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
     6f8:	00 00 
     6fa:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     6fe:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     703:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 76b <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x76b>
     70a:	00 
     70b:	c4 e2 65 90 2c bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm5
     711:	48 8b 5a 30          	mov    0x30(%rdx),%rbx
     715:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     719:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 781 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x781>
     720:	00 
     721:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
     726:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
     72b:	c4 e2 45 90 1c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm3
     731:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 799 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x799>
     738:	00 
     739:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
     740:	00 00 
     742:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     747:	c5 d5 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm7
     74b:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
     750:	c4 c1 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm2
     755:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
     75a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     75e:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     763:	c4 c3 1d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm12,%ymm7
     769:	c4 62 35 39 d4       	vpminsd %ymm4,%ymm9,%ymm10
     76e:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     772:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm7,%ymm7        # 79b <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x79b>
     779:	00 00 20 
     77c:	c5 35 66 cc          	vpcmpgtd %ymm4,%ymm9,%ymm9
     780:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     785:	c4 e2 0d 90 14 b9    	vpgatherdd %ymm14,(%rcx,%ymm7,4),%ymm2
     78b:	c5 e5 66 fd          	vpcmpgtd %ymm5,%ymm3,%ymm7
     78f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     793:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     798:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     79d:	c4 c3 1d 4c ff 70    	vpblendvb %ymm7,%ymm15,%ymm12,%ymm7
     7a3:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm7,%ymm7        # 7cc <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7cc>
     7aa:	00 00 90 
     7ad:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     7b3:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     7b7:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
     7bb:	c4 62 1d 90 0c b9    	vpgatherdd %ymm12,(%rcx,%ymm7,4),%ymm9
     7c1:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     7c6:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     7cc:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     7d0:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     7d5:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     7d9:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
     7dd:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
     7e2:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
     7e9:	00 00 
     7eb:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
     7f0:	e9 42 fb ff ff       	jmp    337 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x337>
     7f5:	0f 1f 00             	nopl   (%rax)
     7f8:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
     7ff:	00 00 
     801:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
     807:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     80d:	48 83 c2 60          	add    $0x60,%rdx
     811:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     816:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     81b:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
     820:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     825:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     82a:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     82f:	c5 85 fa c2          	vpsubd %ymm2,%ymm15,%ymm0
     833:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     837:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     83c:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     841:	c5 f5 fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm1,%ymm1
     848:	00 00 
     84a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     84f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     853:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
     85a:	00 00 
     85c:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     860:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
     865:	c5 35 fa 8c 24 40 01 	vpsubd 0x140(%rsp),%ymm9,%ymm9
     86c:	00 00 
     86e:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     873:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
     87a:	00 00 
     87c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     881:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
     886:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     88a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     88f:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     893:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     897:	c5 35 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm9,%ymm9
     89e:	00 00 
     8a0:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     8a5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8aa:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     8ae:	49 39 d1             	cmp    %rdx,%r9
     8b1:	0f 85 ba fa ff ff    	jne    371 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x371>
     8b7:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
     8bb:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
     8c2:	00 00 
     8c4:	c5 dd 72 f7 08       	vpslld $0x8,%ymm7,%ymm4
     8c9:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     8ce:	49 83 c3 18          	add    $0x18,%r11
     8d2:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
     8d6:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
     8da:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
     8e1:	02 00 00 
     8e4:	c5 f9 6f e0          	vmovdqa %xmm0,%xmm4
     8e8:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     8ee:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
     8f3:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     8f8:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
     8fc:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
     902:	c4 c1 7a 7f 53 e8    	vmovdqu %xmm2,-0x18(%r11)
     908:	4d 39 d8             	cmp    %r11,%r8
     90b:	0f 85 df f7 ff ff    	jne    f0 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf0>
     911:	c5 f8 77             	vzeroupper
     914:	c5 f8 28 b4 24 40 03 	vmovaps 0x340(%rsp),%xmm6
     91b:	00 00 
     91d:	c5 f8 28 bc 24 50 03 	vmovaps 0x350(%rsp),%xmm7
     924:	00 00 
     926:	c5 78 28 84 24 60 03 	vmovaps 0x360(%rsp),%xmm8
     92d:	00 00 
     92f:	c5 78 28 8c 24 70 03 	vmovaps 0x370(%rsp),%xmm9
     936:	00 00 
     938:	c5 78 28 94 24 80 03 	vmovaps 0x380(%rsp),%xmm10
     93f:	00 00 
     941:	c5 78 28 9c 24 90 03 	vmovaps 0x390(%rsp),%xmm11
     948:	00 00 
     94a:	c5 78 28 a4 24 a0 03 	vmovaps 0x3a0(%rsp),%xmm12
     951:	00 00 
     953:	c5 78 28 ac 24 b0 03 	vmovaps 0x3b0(%rsp),%xmm13
     95a:	00 00 
     95c:	c5 78 28 b4 24 c0 03 	vmovaps 0x3c0(%rsp),%xmm14
     963:	00 00 
     965:	c5 78 28 bc 24 d0 03 	vmovaps 0x3d0(%rsp),%xmm15
     96c:	00 00 
     96e:	48 81 c4 e8 03 00 00 	add    $0x3e8,%rsp
     975:	5b                   	pop    %rbx
     976:	5e                   	pop    %rsi
     977:	5f                   	pop    %rdi
     978:	5d                   	pop    %rbp
     979:	41 5c                	pop    %r12
     97b:	41 5d                	pop    %r13
     97d:	41 5e                	pop    %r14
     97f:	41 5f                	pop    %r15
     981:	c3                   	ret
     982:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     988:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
     98c:	e9 33 ff ff ff       	jmp    8c4 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c4>
     991:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     995:	0f 85 e2 f6 ff ff    	jne    7d <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     99b:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     9a2:	0f 84 d5 f6 ff ff    	je     7d <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     9a8:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     9af:	0f 84 c8 f6 ff ff    	je     7d <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     9b5:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     9bc:	0f 84 bb f6 ff ff    	je     7d <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     9c2:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     9c6:	0f 85 5b 0d 00 00    	jne    1727 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1727>
     9cc:	4d 85 c9             	test   %r9,%r9
     9cf:	0f 84 3f ff ff ff    	je     914 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x914>
     9d5:	48 8b 19             	mov    (%rcx),%rbx
     9d8:	44 8b 51 54          	mov    0x54(%rcx),%r10d
     9dc:	49 ff c9             	dec    %r9
     9df:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     9e4:	44 8b 98 b4 00 00 00 	mov    0xb4(%rax),%r11d
     9eb:	48 8b 50 48          	mov    0x48(%rax),%rdx
     9ef:	49 c1 e9 03          	shr    $0x3,%r9
     9f3:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
     9f9:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
     a00:	00 
     a01:	48 8b 59 08          	mov    0x8(%rcx),%rbx
     a05:	c4 c1 79 6e f2       	vmovd  %r10d,%xmm6
     a0a:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
     a0e:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     a13:	4c 8b 68 60          	mov    0x60(%rax),%r13
     a17:	48 89 9c 24 58 02 00 	mov    %rbx,0x258(%rsp)
     a1e:	00 
     a1f:	48 8b 59 10          	mov    0x10(%rcx),%rbx
     a23:	8b 49 50             	mov    0x50(%rcx),%ecx
     a26:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
     a2b:	48 89 9c 24 80 02 00 	mov    %rbx,0x280(%rsp)
     a32:	00 
     a33:	48 8b 58 28          	mov    0x28(%rax),%rbx
     a37:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
     a3b:	41 8d 4c 0a 01       	lea    0x1(%r10,%rcx,1),%ecx
     a40:	48 89 9c 24 88 02 00 	mov    %rbx,0x288(%rsp)
     a47:	00 
     a48:	48 8b 58 20          	mov    0x20(%rax),%rbx
     a4c:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     a51:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
     a57:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
     a5b:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
     a61:	48 89 9c 24 b0 02 00 	mov    %rbx,0x2b0(%rsp)
     a68:	00 
     a69:	48 8b 58 18          	mov    0x18(%rax),%rbx
     a6d:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     a72:	c5 fe 7f b4 24 60 02 	vmovdqu %ymm6,0x260(%rsp)
     a79:	00 00 
     a7b:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     a80:	48 89 9c 24 90 02 00 	mov    %rbx,0x290(%rsp)
     a87:	00 
     a88:	48 8b 58 40          	mov    0x40(%rax),%rbx
     a8c:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     a91:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
     a98:	00 00 
     a9a:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
     a9e:	41 8d 4c 0b 01       	lea    0x1(%r11,%rcx,1),%ecx
     aa3:	48 89 9c 24 b8 02 00 	mov    %rbx,0x2b8(%rsp)
     aaa:	00 
     aab:	48 8b 58 38          	mov    0x38(%rax),%rbx
     aaf:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     ab4:	48 89 9c 24 c0 02 00 	mov    %rbx,0x2c0(%rsp)
     abb:	00 
     abc:	48 8b 58 30          	mov    0x30(%rax),%rbx
     ac0:	48 89 9c 24 e0 02 00 	mov    %rbx,0x2e0(%rsp)
     ac7:	00 
     ac8:	48 8b 58 68          	mov    0x68(%rax),%rbx
     acc:	48 89 9c 24 c0 01 00 	mov    %rbx,0x1c0(%rsp)
     ad3:	00 
     ad4:	48 8b 58 70          	mov    0x70(%rax),%rbx
     ad8:	48 89 9c 24 28 02 00 	mov    %rbx,0x228(%rsp)
     adf:	00 
     ae0:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
     ae7:	00 00 
     ae9:	8b 98 14 01 00 00    	mov    0x114(%rax),%ebx
     aef:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
     af3:	44 8b 98 10 01 00 00 	mov    0x110(%rax),%r11d
     afa:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     aff:	4c 8b 90 a8 00 00 00 	mov    0xa8(%rax),%r10
     b06:	4c 8b b8 c0 00 00 00 	mov    0xc0(%rax),%r15
     b0d:	c5 fe 7f b4 24 30 02 	vmovdqu %ymm6,0x230(%rsp)
     b14:	00 00 
     b16:	c5 f9 6e f3          	vmovd  %ebx,%xmm6
     b1a:	48 8b a8 c8 00 00 00 	mov    0xc8(%rax),%rbp
     b21:	4c 8b a0 d0 00 00 00 	mov    0xd0(%rax),%r12
     b28:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     b2d:	48 8b 88 08 01 00 00 	mov    0x108(%rax),%rcx
     b34:	48 8b b8 20 01 00 00 	mov    0x120(%rax),%rdi
     b3b:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
     b42:	00 00 
     b44:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     b49:	46 8d 5c 1b 01       	lea    0x1(%rbx,%r11,1),%r11d
     b4e:	8b 98 74 01 00 00    	mov    0x174(%rax),%ebx
     b54:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     b59:	48 8b b0 28 01 00 00 	mov    0x128(%rax),%rsi
     b60:	4c 8b b0 30 01 00 00 	mov    0x130(%rax),%r14
     b67:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
     b6e:	00 00 
     b70:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     b75:	44 8b 98 70 01 00 00 	mov    0x170(%rax),%r11d
     b7c:	48 8b 80 68 01 00 00 	mov    0x168(%rax),%rax
     b83:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     b88:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
     b8f:	00 00 
     b91:	c5 f9 6e f3          	vmovd  %ebx,%xmm6
     b95:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     b9a:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
     ba0:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     ba5:	46 8d 5c 1b 01       	lea    0x1(%rbx,%r11,1),%r11d
     baa:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     baf:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
     bb5:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     bba:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
     bbf:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
     bc5:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     bca:	c5 fe 7f b4 24 80 01 	vmovdqu %ymm6,0x180(%rsp)
     bd1:	00 00 
     bd3:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # bdb <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbdb>
     bda:	00 
     bdb:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
     be2:	00 00 
     be4:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # c2c <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc2c>
     beb:	00 
     bec:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
     bf3:	00 00 
     bf5:	c4 c1 79 6e f1       	vmovd  %r9d,%xmm6
     bfa:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     bff:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
     c06:	00 00 
     c08:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     c0d:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     c13:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     c17:	49 83 c0 18          	add    $0x18,%r8
     c1b:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
     c22:	00 
     c23:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     c28:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     c2e:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     c34:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
     c3b:	01 00 00 
     c3e:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
     c43:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
     c48:	c4 c1 7d db fd       	vpand  %ymm13,%ymm0,%ymm7
     c4d:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     c54:	00 00 
     c56:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
     c5b:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     c5f:	c4 e2 4d 90 0c bb    	vpgatherdd %ymm6,(%rbx,%ymm7,4),%ymm1
     c65:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
     c6c:	00 
     c6d:	c5 dd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm4
     c72:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # cda <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcda>
     c79:	00 
     c7a:	c4 a2 7d 90 34 83    	vpgatherdd %ymm0,(%rbx,%ymm8,4),%ymm6
     c80:	48 8b 9c 24 80 02 00 	mov    0x280(%rsp),%rbx
     c87:	00 
     c88:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     c8c:	c4 e2 5d 40 64 24 20 	vpmulld 0x20(%rsp),%ymm4,%ymm4
     c93:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     c98:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # d00 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd00>
     c9f:	00 
     ca0:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
     ca5:	c4 a2 7d 90 1c 9b    	vpgatherdd %ymm0,(%rbx,%ymm11,4),%ymm3
     cab:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     caf:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     cb4:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # d1c <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd1c>
     cbb:	00 
     cbc:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     cc0:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     cc4:	c5 cd 66 e9          	vpcmpgtd %ymm1,%ymm6,%ymm5
     cc8:	c5 6d fe 8c 24 60 02 	vpaddd 0x260(%rsp),%ymm2,%ymm9
     ccf:	00 00 
     cd1:	c4 e2 7d 90 24 92    	vpgatherdd %ymm0,(%rdx,%ymm2,4),%ymm4
     cd7:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     cdb:	c4 a2 7d 90 3c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm7
     ce1:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
     ce7:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     cee:	00 00 
     cf0:	c4 e2 75 3d fe       	vpmaxsd %ymm6,%ymm1,%ymm7
     cf5:	c5 65 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm10
     cf9:	c4 c3 7d 4c ec 50    	vpblendvb %ymm5,%ymm12,%ymm0,%ymm5
     cff:	c4 41 5d db e5       	vpand  %ymm13,%ymm4,%ymm12
     d04:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # d2d <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd2d>
     d0b:	00 00 a0 
     d0e:	c4 62 45 3d d3       	vpmaxsd %ymm3,%ymm7,%ymm10
     d13:	c4 e2 75 39 fe       	vpminsd %ymm6,%ymm1,%ymm7
     d18:	c5 7e 7f 94 24 60 01 	vmovdqu %ymm10,0x160(%rsp)
     d1f:	00 00 
     d21:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     d25:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     d2a:	c4 e2 45 39 c3       	vpminsd %ymm3,%ymm7,%ymm0
     d2f:	c4 62 2d 90 34 aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm14
     d35:	c5 f5 66 ee          	vpcmpgtd %ymm6,%ymm1,%ymm5
     d39:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     d3f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     d43:	c5 c5 66 fb          	vpcmpgtd %ymm3,%ymm7,%ymm7
     d47:	c4 e3 2d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm10,%ymm5
     d4e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # d77 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd77>
     d55:	00 00 70 
     d58:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d5c:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     d60:	c4 62 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm10
     d66:	c4 c1 45 72 f4 10    	vpslld $0x10,%ymm12,%ymm7
     d6c:	c4 c1 0d db ed       	vpand  %ymm13,%ymm14,%ymm5
     d71:	48 8b 9c 24 88 02 00 	mov    0x288(%rsp),%rbx
     d78:	00 
     d79:	c5 7d fe b4 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm14
     d80:	00 00 
     d82:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
     d87:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
     d8c:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     d90:	c5 ad fa dd          	vpsubd %ymm5,%ymm10,%ymm3
     d94:	c4 e2 75 40 db       	vpmulld %ymm3,%ymm1,%ymm3
     d99:	c5 c5 fe 8c 24 40 01 	vpaddd 0x140(%rsp),%ymm7,%ymm1
     da0:	00 00 
     da2:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     da7:	c4 e2 55 40 ac 24 60 	vpmulld 0x160(%rsp),%ymm5,%ymm5
     dae:	01 00 00 
     db1:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     db5:	c5 95 db 9c 24 20 01 	vpand  0x120(%rsp),%ymm13,%ymm3
     dbc:	00 00 
     dbe:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     dc3:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
     dc8:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     dcc:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     dd0:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
     dd7:	00 00 
     dd9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     ddd:	c5 cd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm6
     de2:	c5 fe 7f b4 24 00 03 	vmovdqu %ymm6,0x300(%rsp)
     de9:	00 00 
     deb:	c4 a2 7d 90 1c 9b    	vpgatherdd %ymm0,(%rbx,%ymm11,4),%ymm3
     df1:	48 8b 9c 24 b0 02 00 	mov    0x2b0(%rsp),%rbx
     df8:	00 
     df9:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     dfd:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # e65 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe65>
     e04:	00 
     e05:	c4 a2 7d 90 3c 83    	vpgatherdd %ymm0,(%rbx,%ymm8,4),%ymm7
     e0b:	48 8b 9c 24 90 02 00 	mov    0x290(%rsp),%rbx
     e12:	00 
     e13:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     e17:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # e7f <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe7f>
     e1e:	00 
     e1f:	c4 e2 7d 90 0c ab    	vpgatherdd %ymm0,(%rbx,%ymm5,4),%ymm1
     e25:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
     e2b:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # e93 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe93>
     e32:	00 
     e33:	c4 e2 75 3d f7       	vpmaxsd %ymm7,%ymm1,%ymm6
     e38:	c5 c5 66 e9          	vpcmpgtd %ymm1,%ymm7,%ymm5
     e3c:	c5 65 66 d6          	vpcmpgtd %ymm6,%ymm3,%ymm10
     e40:	c4 e3 7d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm0,%ymm5
     e47:	c4 e2 4d 3d c3       	vpmaxsd %ymm3,%ymm6,%ymm0
     e4c:	c4 e2 75 39 f7       	vpminsd %ymm7,%ymm1,%ymm6
     e51:	c4 62 4d 39 e3       	vpminsd %ymm3,%ymm6,%ymm12
     e56:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
     e5a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # e83 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe83>
     e61:	00 00 a0 
     e64:	c5 7e 7f a4 24 60 01 	vmovdqu %ymm12,0x160(%rsp)
     e6b:	00 00 
     e6d:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     e71:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     e76:	c4 62 2d 90 24 aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm12
     e7c:	c5 f5 66 ef          	vpcmpgtd %ymm7,%ymm1,%ymm5
     e80:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     e86:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     e8a:	c4 e3 2d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm10,%ymm5
     e91:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     e96:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # ebf <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xebf>
     e9d:	00 00 60 
     ea0:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     ea4:	c4 e2 2d 90 34 aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm6
     eaa:	c5 7e 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm10
     eb1:	00 00 
     eb3:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
     eb8:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     ebd:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     ec2:	c4 41 55 db f5       	vpand  %ymm13,%ymm5,%ymm14
     ec7:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     ecd:	c4 c1 55 72 d4 08    	vpsrld $0x8,%ymm12,%ymm5
     ed3:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     ed8:	c5 7e 7f 94 24 20 03 	vmovdqu %ymm10,0x320(%rsp)
     edf:	00 00 
     ee1:	c5 7e 6f a4 24 60 01 	vmovdqu 0x160(%rsp),%ymm12
     ee8:	00 00 
     eea:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
     eef:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     ef4:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
     efa:	48 8b 9c 24 b8 02 00 	mov    0x2b8(%rsp),%rbx
     f01:	00 
     f02:	c5 fe 6f bc 24 00 01 	vmovdqu 0x100(%rsp),%ymm7
     f09:	00 00 
     f0b:	c5 1d fe e0          	vpaddd %ymm0,%ymm12,%ymm12
     f0f:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
     f14:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     f18:	c5 ad fa dd          	vpsubd %ymm5,%ymm10,%ymm3
     f1c:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     f21:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
     f26:	c5 cd fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm6,%ymm3
     f2d:	00 00 
     f2f:	c4 e2 55 40 e8       	vpmulld %ymm0,%ymm5,%ymm5
     f34:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     f38:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     f3d:	c5 f5 fe db          	vpaddd %ymm3,%ymm1,%ymm3
     f41:	c5 95 db 8c 24 20 03 	vpand  0x320(%rsp),%ymm13,%ymm1
     f48:	00 00 
     f4a:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
     f4f:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
     f54:	c4 e2 75 40 8c 24 60 	vpmulld 0x160(%rsp),%ymm1,%ymm1
     f5b:	01 00 00 
     f5e:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     f62:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     f66:	c5 9d 72 d3 10       	vpsrld $0x10,%ymm3,%ymm12
     f6b:	c4 a2 7d 90 1c 9b    	vpgatherdd %ymm0,(%rbx,%ymm11,4),%ymm3
     f71:	48 8b 9c 24 c0 02 00 	mov    0x2c0(%rsp),%rbx
     f78:	00 
     f79:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     f7d:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # fe5 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfe5>
     f84:	00 
     f85:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     f8b:	c4 a2 7d 90 2c 83    	vpgatherdd %ymm0,(%rbx,%ymm8,4),%ymm5
     f91:	48 8b 9c 24 e0 02 00 	mov    0x2e0(%rsp),%rbx
     f98:	00 
     f99:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     f9d:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1005 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1005>
     fa4:	00 
     fa5:	c4 e2 7d 90 0c bb    	vpgatherdd %ymm0,(%rbx,%ymm7,4),%ymm1
     fab:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
     fb2:	00 
     fb3:	c5 f5 db 05 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm0        # 101b <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x101b>
     fba:	00 
     fbb:	c4 e2 7d 3d f5       	vpmaxsd %ymm5,%ymm0,%ymm6
     fc0:	c5 d5 66 c8          	vpcmpgtd %ymm0,%ymm5,%ymm1
     fc4:	c5 e5 66 fe          	vpcmpgtd %ymm6,%ymm3,%ymm7
     fc8:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
     fcd:	c4 c3 25 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm11,%ymm1
     fd3:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # ffc <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xffc>
     fda:	00 00 70 
     fdd:	c4 e2 7d 39 fd       	vpminsd %ymm5,%ymm0,%ymm7
     fe2:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     fe6:	c4 62 45 39 c3       	vpminsd %ymm3,%ymm7,%ymm8
     feb:	c5 c5 66 fb          	vpcmpgtd %ymm3,%ymm7,%ymm7
     fef:	c4 e2 0d 90 0c 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm1
     ff5:	c5 fd 66 d5          	vpcmpgtd %ymm5,%ymm0,%ymm2
     ff9:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     ffd:	c5 7e 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm14
    1004:	00 00 
    1006:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    100b:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1010:	c4 c3 25 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm11,%ymm2
    1016:	c4 41 4d fe d0       	vpaddd %ymm8,%ymm6,%ymm10
    101b:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1044 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1044>
    1022:	00 00 70 
    1025:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    102a:	c5 b5 fa fa          	vpsubd %ymm2,%ymm9,%ymm7
    102e:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    1033:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    1037:	c4 e2 35 90 14 ba    	vpgatherdd %ymm9,(%rdx,%ymm7,4),%ymm2
    103d:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
    1044:	00 00 
    1046:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    104b:	c4 41 6d db cd       	vpand  %ymm13,%ymm2,%ymm9
    1050:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1055:	c5 b5 fa d9          	vpsubd %ymm1,%ymm9,%ymm3
    1059:	c5 ed 72 f4 10       	vpslld $0x10,%ymm4,%ymm2
    105e:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    1063:	c4 e2 7d 40 db       	vpmulld %ymm3,%ymm0,%ymm3
    1068:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
    106d:	c5 f5 fa c4          	vpsubd %ymm4,%ymm1,%ymm0
    1071:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    1076:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
    107b:	c5 fe 6f b4 24 00 03 	vmovdqu 0x300(%rsp),%ymm6
    1082:	00 00 
    1084:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    1089:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    108d:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1091:	c4 c2 65 90 4c b5 00 	vpgatherdd %ymm3,0x0(%r13,%ymm6,4),%ymm1
    1098:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
    109c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    10a0:	c4 a2 4d 90 24 a3    	vpgatherdd %ymm6,(%rbx,%ymm12,4),%ymm4
    10a6:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    10aa:	48 8b 9c 24 28 02 00 	mov    0x228(%rsp),%rbx
    10b1:	00 
    10b2:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    10b6:	c5 fd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm0
    10bb:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
    10c0:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1128 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1128>
    10c7:	00 
    10c8:	c5 7e 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm8
    10cf:	00 00 
    10d1:	c4 e2 4d 90 2c 83    	vpgatherdd %ymm6,(%rbx,%ymm0,4),%ymm5
    10d7:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    10dc:	c4 e2 65 40 9c 24 e0 	vpmulld 0xe0(%rsp),%ymm3,%ymm3
    10e3:	00 00 00 
    10e6:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 114e <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x114e>
    10ed:	00 
    10ee:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    10f3:	c4 e2 6d 40 94 24 c0 	vpmulld 0xc0(%rsp),%ymm2,%ymm2
    10fa:	00 00 00 
    10fd:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1101:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1105:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1109:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1171 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1171>
    1110:	00 
    1111:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
    1116:	c5 6d fe 9c 24 30 02 	vpaddd 0x230(%rsp),%ymm2,%ymm11
    111d:	00 00 
    111f:	c4 c2 4d 90 1c 92    	vpgatherdd %ymm6,(%r10,%ymm2,4),%ymm3
    1125:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1129:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    112e:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    1133:	c5 75 fe e4          	vpaddd %ymm4,%ymm1,%ymm12
    1137:	c4 82 4d 90 04 9a    	vpgatherdd %ymm6,(%r10,%ymm11,4),%ymm0
    113d:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
    1141:	c4 e3 3d 4c b4 24 c0 	vpblendvb %ymm6,0xc0(%rsp),%ymm8,%ymm6
    1148:	00 00 00 60 
    114c:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 1175 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1175>
    1153:	00 00 70 
    1156:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
    115b:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
    1160:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
    1164:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1168:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
    116d:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    1171:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    1176:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    117b:	c4 41 3d fe c4       	vpaddd %ymm12,%ymm8,%ymm8
    1180:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
    1185:	c4 c2 1d 90 34 92    	vpgatherdd %ymm12,(%r10,%ymm2,4),%ymm6
    118b:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
    1192:	00 00 
    1194:	c4 e3 6d 4c 8c 24 c0 	vpblendvb %ymm1,0xc0(%rsp),%ymm2,%ymm1
    119b:	00 00 00 10 
    119f:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # 11c8 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11c8>
    11a6:	00 00 70 
    11a9:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    11ad:	c5 a5 fa d1          	vpsubd %ymm1,%ymm11,%ymm2
    11b1:	c4 41 4d db dd       	vpand  %ymm13,%ymm6,%ymm11
    11b6:	c4 c2 45 90 0c 92    	vpgatherdd %ymm7,(%r10,%ymm2,4),%ymm1
    11bc:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    11c1:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
    11c6:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    11cb:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    11cf:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    11d4:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    11d8:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    11dd:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    11e2:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    11e7:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    11ec:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    11f1:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    11f6:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    11fb:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1200:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1204:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1208:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    120d:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1211:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1216:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    121b:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    1220:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1225:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    122a:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    122f:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1234:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    1238:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    123c:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    1241:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1246:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    124b:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1250:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    1255:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    125a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    125f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1264:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1269:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    126e:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1273:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1277:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    127b:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1280:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1284:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1289:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    128d:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    1292:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    1296:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    129b:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    12a0:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    12a5:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    12a9:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    12ae:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    12b2:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    12b6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    12ba:	c4 c2 4d 90 0c a7    	vpgatherdd %ymm6,(%r15,%ymm4,4),%ymm1
    12c0:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    12c4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12c9:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
    12ce:	c4 e2 4d 90 64 95 00 	vpgatherdd %ymm6,0x0(%rbp,%ymm2,4),%ymm4
    12d5:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    12d9:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    12de:	c4 e2 65 40 9c 24 a0 	vpmulld 0xa0(%rsp),%ymm3,%ymm3
    12e5:	00 00 00 
    12e8:	c4 c2 4d 90 2c 84    	vpgatherdd %ymm6,(%r12,%ymm0,4),%ymm5
    12ee:	c4 e2 6d 40 94 24 80 	vpmulld 0x80(%rsp),%ymm2,%ymm2
    12f5:	00 00 00 
    12f8:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    12fc:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1364 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1364>
    1303:	00 
    1304:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    1309:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1371 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1371>
    1310:	00 
    1311:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1315:	c5 7e 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm8
    131c:	00 00 
    131e:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1322:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 138a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138a>
    1329:	00 
    132a:	c5 6d fe 9c 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm2,%ymm11
    1331:	00 00 
    1333:	c4 e2 4d 90 1c 91    	vpgatherdd %ymm6,(%rcx,%ymm2,4),%ymm3
    1339:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    133d:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
    1342:	c5 75 fe e4          	vpaddd %ymm4,%ymm1,%ymm12
    1346:	c4 a2 4d 90 04 99    	vpgatherdd %ymm6,(%rcx,%ymm11,4),%ymm0
    134c:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
    1350:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    1355:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    135a:	c4 e3 3d 4c b4 24 80 	vpblendvb %ymm6,0x80(%rsp),%ymm8,%ymm6
    1361:	00 00 00 60 
    1365:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 138e <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138e>
    136c:	00 00 70 
    136f:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
    1374:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
    1379:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
    137d:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1381:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
    1386:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    138a:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    138f:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    1394:	c4 41 3d fe c4       	vpaddd %ymm12,%ymm8,%ymm8
    1399:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
    139e:	c4 e2 1d 90 34 91    	vpgatherdd %ymm12,(%rcx,%ymm2,4),%ymm6
    13a4:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
    13ab:	00 00 
    13ad:	c4 e3 6d 4c 8c 24 80 	vpblendvb %ymm1,0x80(%rsp),%ymm2,%ymm1
    13b4:	00 00 00 10 
    13b8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # 13e1 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13e1>
    13bf:	00 00 70 
    13c2:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    13c6:	c5 a5 fa d1          	vpsubd %ymm1,%ymm11,%ymm2
    13ca:	c4 41 4d db dd       	vpand  %ymm13,%ymm6,%ymm11
    13cf:	c4 e2 45 90 0c 91    	vpgatherdd %ymm7,(%rcx,%ymm2,4),%ymm1
    13d5:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    13da:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
    13df:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    13e4:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    13e8:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    13ed:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    13f1:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    13f6:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    13fb:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1400:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1405:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    140a:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    140f:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    1414:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1419:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    141d:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1421:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    1426:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    142a:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    142f:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    1434:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    1439:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    143e:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1443:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    1448:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    144d:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    1451:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1455:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    145a:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    145f:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1464:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1469:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    146e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1473:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1478:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    147d:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1482:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1487:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    148c:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1490:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1494:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1499:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    149d:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    14a2:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    14a6:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    14ab:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    14af:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    14b4:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    14b9:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    14be:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    14c2:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    14c7:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    14cb:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    14cf:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    14d3:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    14d8:	c4 e2 4d 90 04 a7    	vpgatherdd %ymm6,(%rdi,%ymm4,4),%ymm0
    14de:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    14e2:	c4 e2 4d 90 24 96    	vpgatherdd %ymm6,(%rsi,%ymm2,4),%ymm4
    14e8:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    14ed:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    14f1:	c4 c2 4d 90 2c 8e    	vpgatherdd %ymm6,(%r14,%ymm1,4),%ymm5
    14f7:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    14fc:	c4 e2 65 40 5c 24 60 	vpmulld 0x60(%rsp),%ymm3,%ymm3
    1503:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 156b <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x156b>
    150a:	00 
    150b:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    1510:	c4 e2 6d 40 54 24 40 	vpmulld 0x40(%rsp),%ymm2,%ymm2
    1517:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    151b:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1583 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1583>
    1522:	00 
    1523:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1527:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    152b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1593 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1593>
    1532:	00 
    1533:	c5 6d fe 9c 24 80 01 	vpaddd 0x180(%rsp),%ymm2,%ymm11
    153a:	00 00 
    153c:	c4 e2 4d 90 1c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm3
    1542:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1546:	c4 62 7d 3d cc       	vpmaxsd %ymm4,%ymm0,%ymm9
    154b:	c5 7d fe e4          	vpaddd %ymm4,%ymm0,%ymm12
    154f:	c4 a2 4d 90 0c 98    	vpgatherdd %ymm6,(%rax,%ymm11,4),%ymm1
    1555:	c5 dd 66 f0          	vpcmpgtd %ymm0,%ymm4,%ymm6
    1559:	c5 7e 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm8
    155f:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    1564:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    1569:	c4 e3 3d 4c 74 24 40 	vpblendvb %ymm6,0x40(%rsp),%ymm8,%ymm6
    1570:	60 
    1571:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 159a <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x159a>
    1578:	00 00 70 
    157b:	c4 e2 7d 39 fc       	vpminsd %ymm4,%ymm0,%ymm7
    1580:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
    1585:	c5 fd 66 c4          	vpcmpgtd %ymm4,%ymm0,%ymm0
    1589:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    158d:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
    1592:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    1596:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    159b:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    15a0:	c4 41 3d fe c4       	vpaddd %ymm12,%ymm8,%ymm8
    15a5:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
    15aa:	c4 e2 1d 90 34 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm6
    15b0:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    15b6:	c4 e3 6d 4c 44 24 40 	vpblendvb %ymm0,0x40(%rsp),%ymm2,%ymm0
    15bd:	00 
    15be:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm0,%ymm0        # 15e7 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15e7>
    15c5:	00 00 70 
    15c8:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    15cc:	c5 a5 fa c0          	vpsubd %ymm0,%ymm11,%ymm0
    15d0:	c4 41 4d db dd       	vpand  %ymm13,%ymm6,%ymm11
    15d5:	c4 e2 45 90 14 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm2
    15db:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    15e0:	c4 c1 75 db c5       	vpand  %ymm13,%ymm1,%ymm0
    15e5:	c4 c1 6d db e5       	vpand  %ymm13,%ymm2,%ymm4
    15ea:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    15ee:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    15f3:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    15f7:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    15fc:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    1601:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1606:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    160b:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    1610:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1615:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    161a:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    161f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1623:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1627:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    162c:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1630:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    1635:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    163a:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    163f:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    1644:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1649:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    164e:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1653:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    1657:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    165b:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    1660:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1665:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    166a:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    166f:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    1674:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1679:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    167e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1683:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1688:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    168d:	c5 95 db c9          	vpand  %ymm1,%ymm13,%ymm1
    1691:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1695:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    1699:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    169e:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    16a2:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    16a7:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    16ab:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    16b0:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    16b4:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    16b9:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    16be:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    16c3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    16c8:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    16cd:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    16d1:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    16d5:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    16d9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    16de:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    16e3:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    16e7:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    16eb:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    16f2:	02 00 00 
    16f5:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    16f9:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    16ff:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1704:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1709:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    170d:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    1713:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1719:	4d 39 c3             	cmp    %r8,%r11
    171c:	0f 85 e6 f4 ff ff    	jne    c08 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc08>
    1722:	e9 ea f1 ff ff       	jmp    911 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x911>
    1727:	4d 85 c9             	test   %r9,%r9
    172a:	0f 84 e4 f1 ff ff    	je     914 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x914>
    1730:	48 8b 19             	mov    (%rcx),%rbx
    1733:	44 8b 51 54          	mov    0x54(%rcx),%r10d
    1737:	49 ff c9             	dec    %r9
    173a:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    173f:	44 8b 98 b4 00 00 00 	mov    0xb4(%rax),%r11d
    1746:	48 8b 50 48          	mov    0x48(%rax),%rdx
    174a:	49 c1 e9 03          	shr    $0x3,%r9
    174e:	c4 c1 15 72 d2 18    	vpsrld $0x18,%ymm10,%ymm13
    1754:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
    175b:	00 
    175c:	48 8b 59 08          	mov    0x8(%rcx),%rbx
    1760:	c4 c1 79 6e f2       	vmovd  %r10d,%xmm6
    1765:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
    1769:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    176e:	4c 8b 68 60          	mov    0x60(%rax),%r13
    1772:	4c 8b b8 c0 00 00 00 	mov    0xc0(%rax),%r15
    1779:	48 8b a8 c8 00 00 00 	mov    0xc8(%rax),%rbp
    1780:	4c 8b a0 d0 00 00 00 	mov    0xd0(%rax),%r12
    1787:	48 89 9c 24 58 02 00 	mov    %rbx,0x258(%rsp)
    178e:	00 
    178f:	48 8b 59 10          	mov    0x10(%rcx),%rbx
    1793:	8b 49 50             	mov    0x50(%rcx),%ecx
    1796:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    179b:	48 89 9c 24 80 02 00 	mov    %rbx,0x280(%rsp)
    17a2:	00 
    17a3:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    17a7:	48 8b 58 18          	mov    0x18(%rax),%rbx
    17ab:	41 8d 4c 0a 01       	lea    0x1(%r10,%rcx,1),%ecx
    17b0:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    17b5:	4c 8b 90 a8 00 00 00 	mov    0xa8(%rax),%r10
    17bc:	48 89 9c 24 88 02 00 	mov    %rbx,0x288(%rsp)
    17c3:	00 
    17c4:	48 8b 58 20          	mov    0x20(%rax),%rbx
    17c8:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    17ce:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    17d2:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
    17d8:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    17dd:	48 89 9c 24 b0 02 00 	mov    %rbx,0x2b0(%rsp)
    17e4:	00 
    17e5:	48 8b 58 28          	mov    0x28(%rax),%rbx
    17e9:	c5 fe 7f b4 24 60 02 	vmovdqu %ymm6,0x260(%rsp)
    17f0:	00 00 
    17f2:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
    17f7:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    17fc:	48 89 9c 24 b8 02 00 	mov    %rbx,0x2b8(%rsp)
    1803:	00 
    1804:	48 8b 58 68          	mov    0x68(%rax),%rbx
    1808:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    180f:	00 00 
    1811:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    1815:	41 8d 4c 0b 01       	lea    0x1(%r11,%rcx,1),%ecx
    181a:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    181f:	48 89 9c 24 c0 01 00 	mov    %rbx,0x1c0(%rsp)
    1826:	00 
    1827:	48 8b 58 70          	mov    0x70(%rax),%rbx
    182b:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1832:	00 00 
    1834:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
    1838:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    183d:	48 89 9c 24 28 02 00 	mov    %rbx,0x228(%rsp)
    1844:	00 
    1845:	c5 fe 7f b4 24 30 02 	vmovdqu %ymm6,0x230(%rsp)
    184c:	00 00 
    184e:	8b 98 14 01 00 00    	mov    0x114(%rax),%ebx
    1854:	44 8b 98 10 01 00 00 	mov    0x110(%rax),%r11d
    185b:	48 8b 88 08 01 00 00 	mov    0x108(%rax),%rcx
    1862:	48 8b b8 20 01 00 00 	mov    0x120(%rax),%rdi
    1869:	c5 f9 6e f3          	vmovd  %ebx,%xmm6
    186d:	48 8b b0 28 01 00 00 	mov    0x128(%rax),%rsi
    1874:	4c 8b b0 30 01 00 00 	mov    0x130(%rax),%r14
    187b:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1880:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
    1887:	00 00 
    1889:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
    188e:	46 8d 5c 1b 01       	lea    0x1(%rbx,%r11,1),%r11d
    1893:	8b 98 74 01 00 00    	mov    0x174(%rax),%ebx
    1899:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    189e:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
    18a5:	00 00 
    18a7:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
    18ac:	44 8b 98 70 01 00 00 	mov    0x170(%rax),%r11d
    18b3:	48 8b 80 68 01 00 00 	mov    0x168(%rax),%rax
    18ba:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    18bf:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    18c6:	00 00 
    18c8:	c5 f9 6e f3          	vmovd  %ebx,%xmm6
    18cc:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    18d1:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    18d7:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
    18dc:	46 8d 5c 1b 01       	lea    0x1(%rbx,%r11,1),%r11d
    18e1:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    18e6:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
    18ec:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
    18f1:	4f 8d 5c c8 18       	lea    0x18(%r8,%r9,8),%r11
    18f6:	41 b9 00 80 00 00    	mov    $0x8000,%r9d
    18fc:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1901:	c5 fe 7f b4 24 80 01 	vmovdqu %ymm6,0x180(%rsp)
    1908:	00 00 
    190a:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # 1912 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1912>
    1911:	00 
    1912:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    1919:	00 00 
    191b:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # 1963 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1963>
    1922:	00 
    1923:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    192a:	00 00 
    192c:	c4 c1 79 6e f1       	vmovd  %r9d,%xmm6
    1931:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1936:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
    193d:	00 00 
    193f:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    1944:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
    194a:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    194e:	49 83 c0 18          	add    $0x18,%r8
    1952:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
    1959:	00 
    195a:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    195f:	c4 e3 69 0f d0 0c    	vpalignr $0xc,%xmm0,%xmm2,%xmm2
    1965:	c5 f9 6f c8          	vmovdqa %xmm0,%xmm1
    1969:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    196f:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
    1975:	c4 e2 75 00 8c 24 e0 	vpshufb 0x1e0(%rsp),%ymm1,%ymm1
    197c:	01 00 00 
    197f:	c5 c5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm7
    1984:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    1989:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    198e:	c4 e2 4d 90 1c 8b    	vpgatherdd %ymm6,(%rbx,%ymm1,4),%ymm3
    1994:	48 8b 9c 24 58 02 00 	mov    0x258(%rsp),%rbx
    199b:	00 
    199c:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    19a1:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    19a5:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    19aa:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1a12 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a12>
    19b1:	00 
    19b2:	c4 a2 4d 90 24 83    	vpgatherdd %ymm6,(%rbx,%ymm8,4),%ymm4
    19b8:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    19bd:	48 8b 9c 24 80 02 00 	mov    0x280(%rsp),%rbx
    19c4:	00 
    19c5:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    19c9:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    19ce:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1a36 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a36>
    19d5:	00 
    19d6:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    19db:	c4 e2 4d 90 2c bb    	vpgatherdd %ymm6,(%rbx,%ymm7,4),%ymm5
    19e1:	48 8b 9c 24 88 02 00 	mov    0x288(%rsp),%rbx
    19e8:	00 
    19e9:	c5 cd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm6
    19ee:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1a56 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a56>
    19f5:	00 
    19f6:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    19fa:	c5 fd fe d6          	vpaddd %ymm6,%ymm0,%ymm2
    19fe:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a02:	c5 6d fe 8c 24 60 02 	vpaddd 0x260(%rsp),%ymm2,%ymm9
    1a09:	00 00 
    1a0b:	c4 e2 7d 90 34 92    	vpgatherdd %ymm0,(%rdx,%ymm2,4),%ymm6
    1a11:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a15:	c5 7e 7f 8c 24 00 01 	vmovdqu %ymm9,0x100(%rsp)
    1a1c:	00 00 
    1a1e:	c4 22 7d 90 3c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm15
    1a24:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a28:	c5 7e 7f bc 24 20 01 	vmovdqu %ymm15,0x120(%rsp)
    1a2f:	00 00 
    1a31:	c4 62 7d 90 3c 8b    	vpgatherdd %ymm0,(%rbx,%ymm1,4),%ymm15
    1a37:	48 8b 9c 24 b0 02 00 	mov    0x2b0(%rsp),%rbx
    1a3e:	00 
    1a3f:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a43:	c4 a2 7d 90 0c 83    	vpgatherdd %ymm0,(%rbx,%ymm8,4),%ymm1
    1a49:	48 8b 9c 24 b8 02 00 	mov    0x2b8(%rsp),%rbx
    1a50:	00 
    1a51:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a55:	c4 62 65 3d c4       	vpmaxsd %ymm4,%ymm3,%ymm8
    1a5a:	c5 fe 7f 8c 24 90 02 	vmovdqu %ymm1,0x290(%rsp)
    1a61:	00 00 
    1a63:	c4 41 55 66 d8       	vpcmpgtd %ymm8,%ymm5,%ymm11
    1a68:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
    1a6d:	c4 e2 7d 90 0c bb    	vpgatherdd %ymm0,(%rbx,%ymm7,4),%ymm1
    1a73:	c5 dd 66 fb          	vpcmpgtd %ymm3,%ymm4,%ymm7
    1a77:	c5 7e 7f 84 24 c0 02 	vmovdqu %ymm8,0x2c0(%rsp)
    1a7e:	00 00 
    1a80:	c4 62 65 39 c4       	vpminsd %ymm4,%ymm3,%ymm8
    1a85:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1a89:	c4 c3 0d 4c fc 70    	vpblendvb %ymm7,%ymm12,%ymm14,%ymm7
    1a8f:	c4 62 3d 39 e5       	vpminsd %ymm5,%ymm8,%ymm12
    1a94:	c5 65 fe f4          	vpaddd %ymm4,%ymm3,%ymm14
    1a98:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm7,%ymm7        # 1ac1 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ac1>
    1a9f:	00 00 b0 
    1aa2:	c5 7e 7f a4 24 e0 02 	vmovdqu %ymm12,0x2e0(%rsp)
    1aa9:	00 00 
    1aab:	c5 3d 66 c5          	vpcmpgtd %ymm5,%ymm8,%ymm8
    1aaf:	c5 ed fe ff          	vpaddd %ymm7,%ymm2,%ymm7
    1ab3:	c5 7e 6f 8c 24 e0 02 	vmovdqu 0x2e0(%rsp),%ymm9
    1aba:	00 00 
    1abc:	c4 62 7d 90 24 ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm12
    1ac2:	c5 e5 66 fc          	vpcmpgtd %ymm4,%ymm3,%ymm7
    1ac6:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    1acc:	c4 e3 7d 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm0,%ymm7
    1ad3:	c5 fe 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm0
    1ada:	00 00 
    1adc:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm7,%ymm7        # 1b05 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b05>
    1ae3:	00 00 80 
    1ae6:	c4 41 1d db c5       	vpand  %ymm13,%ymm12,%ymm8
    1aeb:	c5 fd fa ff          	vpsubd %ymm7,%ymm0,%ymm7
    1aef:	c5 7d 7f d0          	vmovdqa %ymm10,%ymm0
    1af3:	c4 62 7d 90 1c ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm11
    1af9:	c4 c1 4d db fd       	vpand  %ymm13,%ymm6,%ymm7
    1afe:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    1b05:	00 00 
    1b07:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    1b0c:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    1b13:	00 00 
    1b15:	c5 c5 72 f0 10       	vpslld $0x10,%ymm0,%ymm7
    1b1a:	c5 fe 6f 84 24 c0 02 	vmovdqu 0x2c0(%rsp),%ymm0
    1b21:	00 00 
    1b23:	c5 c5 fe bc 24 40 01 	vpaddd 0x140(%rsp),%ymm7,%ymm7
    1b2a:	00 00 
    1b2c:	c5 35 fe e0          	vpaddd %ymm0,%ymm9,%ymm12
    1b30:	c4 41 55 fa e4       	vpsubd %ymm12,%ymm5,%ymm12
    1b35:	c4 41 1d fe f6       	vpaddd %ymm14,%ymm12,%ymm14
    1b3a:	c4 41 25 fa e0       	vpsubd %ymm8,%ymm11,%ymm12
    1b3f:	c4 42 0d 40 e4       	vpmulld %ymm12,%ymm14,%ymm12
    1b44:	c5 3d fa 84 24 60 01 	vpsubd 0x160(%rsp),%ymm8,%ymm8
    1b4b:	00 00 
    1b4d:	c4 62 3d 40 c0       	vpmulld %ymm0,%ymm8,%ymm8
    1b52:	c5 9d fe ff          	vpaddd %ymm7,%ymm12,%ymm7
    1b56:	c5 15 db a4 24 20 01 	vpand  0x120(%rsp),%ymm13,%ymm12
    1b5d:	00 00 
    1b5f:	c4 41 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm12
    1b64:	c4 42 1d 40 e1       	vpmulld %ymm9,%ymm12,%ymm12
    1b69:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    1b6e:	c4 41 1d fe e0       	vpaddd %ymm8,%ymm12,%ymm12
    1b73:	c4 c1 45 fe fc       	vpaddd %ymm12,%ymm7,%ymm7
    1b78:	c5 7e 6f a4 24 90 02 	vmovdqu 0x290(%rsp),%ymm12
    1b7f:	00 00 
    1b81:	c5 fd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm0
    1b86:	c4 c1 45 72 e7 10    	vpsrad $0x10,%ymm15,%ymm7
    1b8c:	c4 c1 25 72 e4 10    	vpsrad $0x10,%ymm12,%ymm11
    1b92:	c5 c5 fe fb          	vpaddd %ymm3,%ymm7,%ymm7
    1b96:	c5 fe 7f 84 24 c0 02 	vmovdqu %ymm0,0x2c0(%rsp)
    1b9d:	00 00 
    1b9f:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    1ba5:	c5 25 fe dc          	vpaddd %ymm4,%ymm11,%ymm11
    1ba9:	c4 41 45 fe c3       	vpaddd %ymm11,%ymm7,%ymm8
    1bae:	c5 7e 7f 84 24 90 02 	vmovdqu %ymm8,0x290(%rsp)
    1bb5:	00 00 
    1bb7:	c5 bd 72 e1 10       	vpsrad $0x10,%ymm1,%ymm8
    1bbc:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1bc1:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1bc6:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    1bca:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
    1bce:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
    1bd4:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1bd9:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1bdd:	c5 d5 fe e1          	vpaddd %ymm1,%ymm5,%ymm4
    1be1:	c5 fe 7f a4 24 60 01 	vmovdqu %ymm4,0x160(%rsp)
    1be8:	00 00 
    1bea:	c4 c1 5d 72 f7 10    	vpslld $0x10,%ymm15,%ymm4
    1bf0:	c5 85 72 d6 08       	vpsrld $0x8,%ymm6,%ymm15
    1bf5:	c5 dd 72 e4 10       	vpsrad $0x10,%ymm4,%ymm4
    1bfa:	c4 41 05 db fd       	vpand  %ymm13,%ymm15,%ymm15
    1bff:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    1c03:	c4 62 65 3d e1       	vpmaxsd %ymm1,%ymm3,%ymm12
    1c08:	c5 f5 66 e3          	vpcmpgtd %ymm3,%ymm1,%ymm4
    1c0c:	c4 41 55 66 f4       	vpcmpgtd %ymm12,%ymm5,%ymm14
    1c11:	c4 62 1d 3d e5       	vpmaxsd %ymm5,%ymm12,%ymm12
    1c16:	c4 e3 7d 4c 24 24 40 	vpblendvb %ymm4,(%rsp),%ymm0,%ymm4
    1c1d:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm4,%ymm4        # 1c46 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c46>
    1c24:	00 00 e0 
    1c27:	c4 62 65 39 f1       	vpminsd %ymm1,%ymm3,%ymm14
    1c2c:	c5 e5 66 c9          	vpcmpgtd %ymm1,%ymm3,%ymm1
    1c30:	c4 e2 0d 39 c5       	vpminsd %ymm5,%ymm14,%ymm0
    1c35:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    1c39:	c5 0d 66 f5          	vpcmpgtd %ymm5,%ymm14,%ymm14
    1c3d:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    1c43:	c5 fe 7f 84 24 e0 02 	vmovdqu %ymm0,0x2e0(%rsp)
    1c4a:	00 00 
    1c4c:	c4 e2 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm0
    1c52:	c4 e3 55 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm5,%ymm1
    1c59:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm1,%ymm1        # 1c82 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c82>
    1c60:	00 00 e0 
    1c63:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
    1c6a:	00 00 
    1c6c:	c5 7e 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm9
    1c73:	00 00 
    1c75:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
    1c7c:	00 
    1c7d:	c5 d5 fa e1          	vpsubd %ymm1,%ymm5,%ymm4
    1c81:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    1c87:	c5 7d 7f d5          	vmovdqa %ymm10,%ymm5
    1c8b:	c4 e2 55 90 0c a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm1
    1c91:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
    1c96:	c5 fe 6f 84 24 e0 02 	vmovdqu 0x2e0(%rsp),%ymm0
    1c9d:	00 00 
    1c9f:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
    1ca4:	c4 c1 55 72 f7 10    	vpslld $0x10,%ymm15,%ymm5
    1caa:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    1caf:	c4 41 75 db f5       	vpand  %ymm13,%ymm1,%ymm14
    1cb4:	c5 9d fe c8          	vpaddd %ymm0,%ymm12,%ymm1
    1cb8:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    1cbc:	c5 8d fa dc          	vpsubd %ymm4,%ymm14,%ymm3
    1cc0:	c5 f5 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm1,%ymm1
    1cc7:	00 00 
    1cc9:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    1cce:	c5 7e 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm15
    1cd4:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    1cd9:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    1cde:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    1ce3:	c5 d5 fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm5,%ymm3
    1cea:	00 00 
    1cec:	c5 f5 fe db          	vpaddd %ymm3,%ymm1,%ymm3
    1cf0:	c4 c1 15 db c9       	vpand  %ymm9,%ymm13,%ymm1
    1cf5:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    1cfa:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    1cff:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
    1d04:	c5 fe 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm0
    1d0b:	00 00 
    1d0d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1d11:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    1d15:	c5 a5 66 cf          	vpcmpgtd %ymm7,%ymm11,%ymm1
    1d19:	c5 8d 72 d3 10       	vpsrld $0x10,%ymm3,%ymm14
    1d1e:	c4 c2 45 3d db       	vpmaxsd %ymm11,%ymm7,%ymm3
    1d23:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
    1d27:	c4 c2 65 3d d8       	vpmaxsd %ymm8,%ymm3,%ymm3
    1d2c:	c4 c3 05 4c cc 10    	vpblendvb %ymm1,%ymm12,%ymm15,%ymm1
    1d32:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # 1d5b <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d5b>
    1d39:	00 00 40 
    1d3c:	c4 c2 45 39 e3       	vpminsd %ymm11,%ymm7,%ymm4
    1d41:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1d45:	c4 c2 5d 39 e8       	vpminsd %ymm8,%ymm4,%ymm5
    1d4a:	c4 c1 5d 66 e0       	vpcmpgtd %ymm8,%ymm4,%ymm4
    1d4f:	c4 e2 35 90 0c 92    	vpgatherdd %ymm9,(%rdx,%ymm2,4),%ymm1
    1d55:	c4 c1 45 66 d3       	vpcmpgtd %ymm11,%ymm7,%ymm2
    1d5a:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    1d5e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1d63:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1d68:	c4 c3 05 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm15,%ymm2
    1d6e:	c5 7e 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm15
    1d75:	00 00 
    1d77:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 1da0 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1da0>
    1d7e:	00 00 40 
    1d81:	c5 fd fa d2          	vpsubd %ymm2,%ymm0,%ymm2
    1d85:	c4 e2 45 90 24 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm4
    1d8b:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
    1d90:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
    1d97:	00 00 
    1d99:	c5 e5 fe fd          	vpaddd %ymm5,%ymm3,%ymm7
    1d9d:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1da2:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
    1da6:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1dab:	c5 fd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm0
    1db0:	c5 c5 fe bc 24 90 02 	vpaddd 0x290(%rsp),%ymm7,%ymm7
    1db7:	00 00 
    1db9:	c4 c1 5d db f5       	vpand  %ymm13,%ymm4,%ymm6
    1dbe:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1dc3:	c5 dd 72 f2 10       	vpslld $0x10,%ymm2,%ymm4
    1dc8:	c5 4d fa c1          	vpsubd %ymm1,%ymm6,%ymm8
    1dcc:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
    1dd0:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1dd4:	c4 42 45 40 c0       	vpmulld %ymm8,%ymm7,%ymm8
    1dd9:	c5 fe 6f b4 24 c0 02 	vmovdqu 0x2c0(%rsp),%ymm6
    1de0:	00 00 
    1de2:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    1de7:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    1dec:	c4 c1 5d fe e7       	vpaddd %ymm15,%ymm4,%ymm4
    1df1:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    1df5:	c5 bd fe e4          	vpaddd %ymm4,%ymm8,%ymm4
    1df9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1dfd:	c4 c2 65 90 4c b5 00 	vpgatherdd %ymm3,0x0(%r13,%ymm6,4),%ymm1
    1e04:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    1e08:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    1e0c:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
    1e11:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1e79 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1e79>
    1e18:	00 
    1e19:	c5 fd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm0
    1e1e:	c4 a2 4d 90 24 b3    	vpgatherdd %ymm6,(%rbx,%ymm14,4),%ymm4
    1e24:	48 8b 9c 24 28 02 00 	mov    0x228(%rsp),%rbx
    1e2b:	00 
    1e2c:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    1e30:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    1e35:	c4 e2 65 40 9c 24 e0 	vpmulld 0xe0(%rsp),%ymm3,%ymm3
    1e3c:	00 00 00 
    1e3f:	c4 e2 4d 90 2c 83    	vpgatherdd %ymm6,(%rbx,%ymm0,4),%ymm5
    1e45:	c4 e2 6d 40 94 24 c0 	vpmulld 0xc0(%rsp),%ymm2,%ymm2
    1e4c:	00 00 00 
    1e4f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1e53:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1ebb <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ebb>
    1e5a:	00 
    1e5b:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    1e60:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    1e64:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1ecc <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ecc>
    1e6b:	00 
    1e6c:	c5 7e 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm11
    1e73:	00 00 
    1e75:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1e79:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
    1e7e:	c5 6d fe a4 24 30 02 	vpaddd 0x230(%rsp),%ymm2,%ymm12
    1e85:	00 00 
    1e87:	c4 c2 4d 90 1c 92    	vpgatherdd %ymm6,(%r10,%ymm2,4),%ymm3
    1e8d:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    1e91:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    1e96:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    1e9b:	c5 75 fe f4          	vpaddd %ymm4,%ymm1,%ymm14
    1e9f:	c4 82 4d 90 04 a2    	vpgatherdd %ymm6,(%r10,%ymm12,4),%ymm0
    1ea5:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
    1ea9:	c4 e3 25 4c b4 24 c0 	vpblendvb %ymm6,0xc0(%rsp),%ymm11,%ymm6
    1eb0:	00 00 00 60 
    1eb4:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 1edd <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1edd>
    1ebb:	00 00 70 
    1ebe:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
    1ec3:	c4 62 45 39 dd       	vpminsd %ymm5,%ymm7,%ymm11
    1ec8:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
    1ecc:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1ed0:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1ed5:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    1ed9:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    1ede:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    1ee3:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1ee8:	c4 41 7d 6f f2       	vmovdqa %ymm10,%ymm14
    1eed:	c4 c2 0d 90 34 92    	vpgatherdd %ymm14,(%r10,%ymm2,4),%ymm6
    1ef3:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
    1efa:	00 00 
    1efc:	c4 e3 6d 4c 8c 24 c0 	vpblendvb %ymm1,0xc0(%rsp),%ymm2,%ymm1
    1f03:	00 00 00 10 
    1f07:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # 1f30 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f30>
    1f0e:	00 00 70 
    1f11:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    1f15:	c5 9d fa d1          	vpsubd %ymm1,%ymm12,%ymm2
    1f19:	c4 41 4d db e5       	vpand  %ymm13,%ymm6,%ymm12
    1f1e:	c4 c2 45 90 0c 92    	vpgatherdd %ymm7,(%r10,%ymm2,4),%ymm1
    1f24:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    1f29:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
    1f2e:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    1f33:	c5 9d fa ed          	vpsubd %ymm5,%ymm12,%ymm5
    1f37:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1f3c:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1f40:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    1f45:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    1f4a:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1f4f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1f54:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
    1f59:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1f5e:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    1f63:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    1f68:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1f6c:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1f70:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    1f75:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1f79:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1f7e:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    1f83:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    1f88:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1f8d:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1f92:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1f97:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1f9c:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    1fa0:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1fa4:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    1fa9:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1fae:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1fb3:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1fb8:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    1fbd:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1fc2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1fc7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1fcc:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1fd1:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1fd6:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1fdb:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1fdf:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1fe3:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    1fe8:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1fec:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1ff1:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1ff5:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    1ffa:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    1ffe:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    2003:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    2008:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    200d:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2011:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2016:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    201a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    201e:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2022:	c4 c2 4d 90 0c a7    	vpgatherdd %ymm6,(%r15,%ymm4,4),%ymm1
    2028:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    202c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2031:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
    2036:	c4 e2 4d 90 64 95 00 	vpgatherdd %ymm6,0x0(%rbp,%ymm2,4),%ymm4
    203d:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2041:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    2046:	c4 e2 65 40 9c 24 a0 	vpmulld 0xa0(%rsp),%ymm3,%ymm3
    204d:	00 00 00 
    2050:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 20b8 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20b8>
    2057:	00 
    2058:	c4 c2 4d 90 2c 84    	vpgatherdd %ymm6,(%r12,%ymm0,4),%ymm5
    205e:	c4 e2 6d 40 94 24 80 	vpmulld 0x80(%rsp),%ymm2,%ymm2
    2065:	00 00 00 
    2068:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    206c:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 20d4 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20d4>
    2073:	00 
    2074:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    2079:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    207d:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 20e5 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20e5>
    2084:	00 
    2085:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    2089:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
    208e:	c5 6d fe a4 24 a0 01 	vpaddd 0x1a0(%rsp),%ymm2,%ymm12
    2095:	00 00 
    2097:	c4 e2 4d 90 1c 91    	vpgatherdd %ymm6,(%rcx,%ymm2,4),%ymm3
    209d:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    20a1:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    20a6:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    20ab:	c5 75 fe f4          	vpaddd %ymm4,%ymm1,%ymm14
    20af:	c4 a2 4d 90 04 a1    	vpgatherdd %ymm6,(%rcx,%ymm12,4),%ymm0
    20b5:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
    20b9:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    20c0:	00 00 
    20c2:	c4 e3 25 4c b4 24 80 	vpblendvb %ymm6,0x80(%rsp),%ymm11,%ymm6
    20c9:	00 00 00 60 
    20cd:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 20f6 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20f6>
    20d4:	00 00 70 
    20d7:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
    20dc:	c4 62 45 39 dd       	vpminsd %ymm5,%ymm7,%ymm11
    20e1:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
    20e5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    20e9:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    20ee:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    20f2:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    20f7:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    20fc:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    2101:	c4 41 7d 6f f2       	vmovdqa %ymm10,%ymm14
    2106:	c4 e2 0d 90 34 91    	vpgatherdd %ymm14,(%rcx,%ymm2,4),%ymm6
    210c:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
    2113:	00 00 
    2115:	c4 e3 6d 4c 8c 24 80 	vpblendvb %ymm1,0x80(%rsp),%ymm2,%ymm1
    211c:	00 00 00 10 
    2120:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # 2149 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2149>
    2127:	00 00 70 
    212a:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    212e:	c5 9d fa d1          	vpsubd %ymm1,%ymm12,%ymm2
    2132:	c4 41 4d db e5       	vpand  %ymm13,%ymm6,%ymm12
    2137:	c4 e2 45 90 0c 91    	vpgatherdd %ymm7,(%rcx,%ymm2,4),%ymm1
    213d:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    2142:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
    2147:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    214c:	c5 9d fa ed          	vpsubd %ymm5,%ymm12,%ymm5
    2150:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    2155:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    2159:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    215e:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    2163:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    2168:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    216d:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
    2172:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    2177:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    217c:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    2181:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    2185:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2189:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    218e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2192:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    2197:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    219c:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    21a1:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    21a6:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    21ab:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    21b0:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    21b5:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    21b9:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    21bd:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    21c2:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    21c7:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    21cc:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    21d1:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    21d6:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    21db:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    21e0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    21e5:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    21ea:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    21ef:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    21f4:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    21f8:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    21fc:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    2201:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    2205:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    220a:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
    2210:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2214:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    2219:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    221d:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    2222:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    2227:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    222c:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2230:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2235:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2239:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    223d:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2241:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    2246:	c4 e2 4d 90 04 a7    	vpgatherdd %ymm6,(%rdi,%ymm4,4),%ymm0
    224c:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2250:	c4 e2 4d 90 24 96    	vpgatherdd %ymm6,(%rsi,%ymm2,4),%ymm4
    2256:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    225b:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    225f:	c4 c2 4d 90 2c 8e    	vpgatherdd %ymm6,(%r14,%ymm1,4),%ymm5
    2265:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    226a:	c4 e2 65 40 5c 24 60 	vpmulld 0x60(%rsp),%ymm3,%ymm3
    2271:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 22d9 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x22d9>
    2278:	00 
    2279:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    227e:	c4 e2 6d 40 54 24 40 	vpmulld 0x40(%rsp),%ymm2,%ymm2
    2285:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    2289:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 22f1 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x22f1>
    2290:	00 
    2291:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    2295:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2299:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2301 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2301>
    22a0:	00 
    22a1:	c5 6d fe a4 24 80 01 	vpaddd 0x180(%rsp),%ymm2,%ymm12
    22a8:	00 00 
    22aa:	c4 e2 4d 90 1c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm3
    22b0:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    22b4:	c4 62 7d 3d cc       	vpmaxsd %ymm4,%ymm0,%ymm9
    22b9:	c5 7d fe f4          	vpaddd %ymm4,%ymm0,%ymm14
    22bd:	c4 a2 4d 90 0c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm1
    22c3:	c5 dd 66 f0          	vpcmpgtd %ymm0,%ymm4,%ymm6
    22c7:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    22cc:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    22d1:	c4 e3 25 4c 74 24 40 	vpblendvb %ymm6,0x40(%rsp),%ymm11,%ymm6
    22d8:	60 
    22d9:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 2302 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2302>
    22e0:	00 00 70 
    22e3:	c4 e2 7d 39 fc       	vpminsd %ymm4,%ymm0,%ymm7
    22e8:	c4 62 45 39 dd       	vpminsd %ymm5,%ymm7,%ymm11
    22ed:	c5 fd 66 c4          	vpcmpgtd %ymm4,%ymm0,%ymm0
    22f1:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    22f5:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    22fa:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    22fe:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    2303:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    2308:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    230d:	c4 41 7d 6f f2       	vmovdqa %ymm10,%ymm14
    2312:	c4 e2 0d 90 34 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm6
    2318:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    231e:	c4 e3 6d 4c 44 24 40 	vpblendvb %ymm0,0x40(%rsp),%ymm2,%ymm0
    2325:	00 
    2326:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm0,%ymm0        # 234f <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x234f>
    232d:	00 00 70 
    2330:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    2334:	c5 9d fa c0          	vpsubd %ymm0,%ymm12,%ymm0
    2338:	c4 41 4d db e5       	vpand  %ymm13,%ymm6,%ymm12
    233d:	c4 e2 45 90 14 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm2
    2343:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    2348:	c4 c1 75 db c5       	vpand  %ymm13,%ymm1,%ymm0
    234d:	c4 c1 6d db e5       	vpand  %ymm13,%ymm2,%ymm4
    2352:	c5 9d fa ed          	vpsubd %ymm5,%ymm12,%ymm5
    2356:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    235b:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    235f:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    2364:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    2369:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    236e:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2373:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
    2378:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    237d:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    2382:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    2387:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    238b:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    238f:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    2394:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2398:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    239d:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    23a2:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    23a7:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    23ac:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    23b1:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    23b6:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    23bb:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    23bf:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    23c3:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    23c8:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    23cd:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    23d2:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    23d7:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    23dc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    23e1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    23e6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    23eb:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    23f0:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    23f5:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    23fa:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    23fe:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    2402:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    2407:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    240b:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    2410:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2414:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    2419:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    241d:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    2422:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    2427:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    242c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2431:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    2436:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    243a:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    243e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2442:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2447:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    244c:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2450:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    2454:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    245b:	02 00 00 
    245e:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2462:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2468:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    246d:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2472:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2476:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    247c:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    2482:	4d 39 c3             	cmp    %r8,%r11
    2485:	0f 85 b4 f4 ff ff    	jne    193f <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x193f>
    248b:	e9 81 e4 ff ff       	jmp    911 <jshc_restrict::avx2_chain(jshc_restrict::View const*, unsigned long long, unsigned char*, unsigned long long)+0x911>
