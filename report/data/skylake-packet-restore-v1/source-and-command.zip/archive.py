"""只读归档恢复回执和当前研究提交CI，不执行新数据恢复或数值。"""
import hashlib,json,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent;OUT=ROOT/'report/data/skylake-packet-restore-v1'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if OUT.exists():raise ValueError('不覆盖恢复归档')
receipt=ROOT/'artifacts/skylake-domain-server-restored v1.restore.json';record=read(receipt)
assert record['pass'] and record['verified_file_count']==114 and record['verified_payload_bytes']==339633805 and record['large_files_restored']==3
assert sha(ROOT/'scripts/restore_skylake_server_packet.py')==record['script_sha256']
assert record['native_calls']==record['performance_calls']==record['new_pixel_mappings']==0
OUT.mkdir();(OUT/'restore-results.json').write_bytes(receipt.read_bytes())
with zipfile.ZipFile(OUT/'source-and-command.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(ROOT/'scripts/restore_skylake_server_packet.py','scripts/restore_skylake_server_packet.py')
 z.write(Path(__file__),'archive.py')
 z.write(ROOT/'report/data/skylake-domain-server-v2/delivery-packet.json','delivery-packet.json')
save(OUT/'command.json',{'command':['artifacts/error-study-py312/Scripts/python.exe','-X','utf8','scripts/restore_skylake_server_packet.py',
 '--archive','report/data/skylake-domain-server-v2','--data-root','artifacts/skylake-layout-server-v2','--output','artifacts/skylake-domain-server-restored v1'],
 'head_before_phase_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'scope':'本条命令已执行一次，仅数据复制/落盘SHA，不触发目标端构建或性能'})
checks=sorted((ROOT/'artifacts/skylake-final-audit-v1').glob('checks-e155dc2a2c21-*.json'))
ci=read(checks[-1]);assert len(ci['checks'])==6 and all(x['head_sha']==ci['head'] and x['status']=='completed' and x['conclusion']=='success' for x in ci['checks'])
save(OUT/'prior-head-ci.json',{'checked_at_utc':ci['checked_at_utc'],'head':ci['head'],'draft':ci['pr_draft'],
 'checks':[{k:x[k] for k in ('id','name','status','conclusion','html_url')} for x in ci['checks']],
 'scope':'只证明先前性能提交的六项CI，不给随后新提交预授CI资格，也不代替研究库或Skylake实测'})
print('恢复与先前CI回执已归档',flush=True)
