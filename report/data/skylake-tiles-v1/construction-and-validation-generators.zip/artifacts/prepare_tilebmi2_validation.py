"""冻结47默认/强制线性两套全域验证，共用同一库；尚未执行像素。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/verify_skylake_batchspan_linux.py').read_text(encoding='utf-8').replace('RGB24精确大工作块40','RGB24可选BMI2分块47及通用AVX2回退')
s=s.replace("    args = p.parse_args()", "    p.add_argument('--force-linear-index',action='store_true',help='同库强制走40通用AVX2布局，不冒充无BMI2硬件')\n    args = p.parse_args()\n    if args.force_linear_index:os.environ['JSHC_CHANNEL_FORCE_LINEAR_INDEX']='1'\n    else:os.environ.pop('JSHC_CHANNEL_FORCE_LINEAR_INDEX',None)")
s=s.replace("direct_state['format']!=9", "direct_state['format']!=(9 if args.force_linear_index else 15)")
a=s.index('                    for red in range(256):');b=s.index('                    del old_words,raw_table',a)
s=s[:a]+'''                    # 按立方体号及块内坐标独立解码；不复用构造器的位段逆变换。
                    for red in range(256):
                        if args.force_linear_index:
                            plane=raw_table[red::256];ids=b''.join(plane[g::256] for g in range(256))
                        else:
                            ids=bytearray(65536)
                            for green in range(256):
                                tile_rg=(green//4*64+red//4)*64
                                within=green%4*4+red%4
                                for blue in range(256):
                                    address=(blue//4*4096*64)+tile_rg+blue%4*16+within
                                    ids[green*256+blue]=raw_table[address]
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                        start=red*65536
                        if b''.join(palette_rgb[i] for i in ids)!=cube[start*3:(start+65536)*3]:raise AssertionError('独立4立方体/线性解码全表不同')
'''+s[b:]
s=s.replace("'thread_environment': {", "'forced_linear_index':args.force_linear_index,\n        'thread_environment': {")
s=s.replace("'full_input_chunk_pixels':262144,", "'forced_linear_index':args.force_linear_index,'expected_direct_format':9 if args.force_linear_index else 15,'full_input_chunk_pixels':262144,")
s=s.replace("raise ValueError('新RGB32直表没有实际启用')", "raise ValueError('所请求的可选布局或通用回退未实际启用')")
new=ROOT/'scripts/verify_skylake_tilebmi2_linux.py';assert not new.exists();new.write_bytes(s.encode('utf-8'));compile(s,str(new),'exec')
def sha(p):return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
v={'purpose':'47同库默认BMI2格式15和强制通用AVX2格式9分别独立16M表解码及24组完整域、有限/保护页/全对齐；不计时','plan_sha256':sha('experiments/skylake-tilebmi2-v1.json'),'source_sha256':{k:sha(k) for k in ('scripts/verify_skylake_tilebmi2_linux.py','scripts/paged_table_support.py','scripts/outplace_support.py','scripts/guarded_buffer_support.py')},'executions':[{'output':'artifacts/skylake-tilebmi2-linux-full-v1','force_linear_index':False},{'output':'artifacts/skylake-tilebmi2-linux-fallback-full-v1','force_linear_index':True}]}
(ROOT/'experiments/skylake-tilebmi2-validation-v1.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('默认与通用回退验证源已冻结，未调用像素')
