"""冻结48：沿用47颜色分块，改为通用AVX2索引计算和GPR查表；不重测47。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-tilebmi2-runtime';out=ROOT/'experiments/skylake-tilevector-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    if p.name=='channel_bmi2.cpp':continue
    s=p.read_text(encoding='utf-8').replace('skylake_tilebmi2','skylake_tilevector').replace('avx2_chain_tilebmi2','avx2_chain_tilevector')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 47;','jshc_cc_revision(void) {return 48;')
        s=s.replace('__builtin_cpu_supports("bmi2") && ','')
        s=s.replace('只在CPU实际支持BMI2时使用可选指令','默认使用通用AVX2分块，强制线性标志仅用于回退验证')
    if p.name=='CMakeLists.txt':
        s=s.replace('channel_bmi2.cpp','channel_tilevector.cpp').replace(';-mbmi2;',';')
        s=s.replace('BMI2仅在独立TU中启用，调用由通用dispatcher的CPUID判断控制','索引和输出均为通用AVX2，独立TU便于核验原40回退')
    (out/p.name).write_bytes(s.encode('utf-8'))
s=(old/'channel_bmi2.cpp').read_text(encoding='utf-8').replace('avx2_chain_tilebmi2','avx2_chain_tilevector')
a=s.index('inline __attribute__((always_inline)) uint32_t index');b=s.index('inline __attribute__((always_inline)) void output(',a)
s=s[:a]+'''inline __attribute__((always_inline)) uint32_t index(uint32_t c) {
  return ((c&0xfcu)<<4)|((c&0xfc00u)<<2)|(c&0xfc0000u)|(c&3u)|((c>>6)&12u)|((c>>12)&48u);
}
inline __attribute__((always_inline)) __m256i input(const uint8_t* p) {
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m128i hi=_mm_alignr_epi8(last,lo,12);
  return _mm256_shuffle_epi8(_mm256_inserti128_si256(_mm256_castsi128_si256(lo),hi,1),
    _mm256_setr_epi8(0,1,2,-1,3,4,5,-1,6,7,8,-1,9,10,11,-1,0,1,2,-1,3,4,5,-1,6,7,8,-1,9,10,11,-1));
}
inline __attribute__((always_inline)) __m256i indices(__m256i c) {
  const __m256i a=_mm256_slli_epi32(_mm256_and_si256(c,_mm256_set1_epi32(0xfc)),4);
  const __m256i b=_mm256_slli_epi32(_mm256_and_si256(c,_mm256_set1_epi32(0xfc00)),2);
  const __m256i d=_mm256_and_si256(c,_mm256_set1_epi32(0xfc0000));
  const __m256i e=_mm256_and_si256(c,_mm256_set1_epi32(3));
  const __m256i f=_mm256_and_si256(_mm256_srli_epi32(c,6),_mm256_set1_epi32(12));
  const __m256i g=_mm256_and_si256(_mm256_srli_epi32(c,12),_mm256_set1_epi32(48));
  return _mm256_or_si256(_mm256_or_si256(a,b),_mm256_or_si256(_mm256_or_si256(d,e),_mm256_or_si256(f,g)));
}
// 先以AVX2计算8个地址，再用普通GPR字节加载，避免硬件gather及逐像素PEXT。
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  const __m256i code=indices(input(p));
  const auto value=[table,palette](uint32_t i) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[i]]);};
  return _mm256_setr_epi32(value(_mm256_extract_epi32(code,0)),value(_mm256_extract_epi32(code,1)),
    value(_mm256_extract_epi32(code,2)),value(_mm256_extract_epi32(code,3)),value(_mm256_extract_epi32(code,4)),
    value(_mm256_extract_epi32(code,5)),value(_mm256_extract_epi32(code,6)),value(_mm256_extract_epi32(code,7)));
}
inline __attribute__((always_inline)) __m256i read_wide(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  return read(table,palette,p);
}
'''+s[b:]
(out/'channel_tilevector.cpp').write_bytes(s.encode('utf-8'))
s=(ROOT/'scripts/build_skylake_tilebmi2.py').read_text(encoding='utf-8').replace('channel_bmi2.cpp','channel_tilevector.cpp')
s=s.replace("if ('-mbmi2' in command)!=(name=='channel_tilevector.cpp'):","if '-mbmi2' in command:")
s=s.replace('BMI2必须仅出现在可选独立TU','通用AVX2候选不得要求BMI2').replace('BMI2 TU数量不符','通用索引TU数量不符')
builder=ROOT/'scripts/build_skylake_tilevector.py';assert not builder.exists();builder.write_bytes(s.encode('utf-8'));compile(s,str(builder),'exec')
plan=json.loads((ROOT/'experiments/skylake-tilebmi2-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='48研究47同一缓存行分块的AVX2批量索引，保留GPR查表和40输出；无BMI2需求',candidate='以通用AVX2计算8个分块地址，提取lane后GPR加载u8 ID及调色板；表和65536工作块/NTA/NT64输出不变',revisions={'reference':23,'candidate':48},cmake_project='experiments/skylake-tilevector-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tilevector'])
policy=plan.pop('tilebmi2_policy');policy['dispatch']='默认AVX2批量索引；JSHC_CHANNEL_FORCE_LINEAR_INDEX=1仅用于同库40线性回退验证'
policy['hypothesis']='47单次计数generic miss约减半，但9.9指令/像素抵消收益；本版用向量计算减少逐像素重排开销，是否有效待测'
policy['choice']='沿用47唯一4立方体布局，单独改变索引实现；不扫描分块或PEXT参数'
plan['tilevector_policy']=policy
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-tilebmi2-runtime/') and k!='scripts/build_skylake_tilebmi2.py'}
for p in [*out.iterdir(),builder]:plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-tilevector-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结48通用AVX2索引和同一单次计数门槛，未构建或调用像素')
