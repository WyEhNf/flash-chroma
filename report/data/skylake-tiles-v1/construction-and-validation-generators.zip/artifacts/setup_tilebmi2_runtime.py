"""冻结47：4立方体缓存行分块、可选BMI2与通用AVX2线性回退；尚无性能结论。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-tilebmi2-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_tilebmi2')
    if p.name=='channel_runtime.cpp':
        s=s.replace('#include <cstdio>','#include <cstdio>\n#include <cstdlib>')
        s=s.replace('bool domain_proven = false;','bool domain_proven = false;\n  bool tiled_index = false;')
        s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 47;')
        s=s.replace('if(!h.direct_index.empty())jshc_channel::avx2_chain_batchspan(h.direct_index.data(),h.output_palette.data(),data,vectorized);', '''if(!h.direct_index.empty()) {
          if(h.tiled_index)jshc_channel::avx2_chain_tilebmi2(h.direct_index.data(),h.output_palette.data(),data,vectorized);
          else jshc_channel::avx2_chain_batchspan(h.direct_index.data(),h.output_palette.data(),data,vectorized);
        }''')
        s=s.replace('jshc_channel::avx2_chain_batchspan_to(h.direct_index.data(),h.output_palette.data(),in,target,vectorized);', '''if(h.tiled_index)jshc_channel::avx2_chain_tilebmi2_to(h.direct_index.data(),h.output_palette.data(),in,target,vectorized);
      else jshc_channel::avx2_chain_batchspan_to(h.direct_index.data(),h.output_palette.data(),in,target,vectorized);''')
        s=s.replace('h.direct_index.allocate(size_t{1}<<22);', '''// 在构造时冻结布局；只在CPU实际支持BMI2时使用可选指令。
      const char* force_linear=std::getenv("JSHC_CHANNEL_FORCE_LINEAR_INDEX");
      h.tiled_index=__builtin_cpu_supports("bmi2") && !(force_linear && std::strcmp(force_linear,"1")==0);
      h.direct_index.allocate(size_t{1}<<22);''')
        s=s.replace('const size_t i=((address&255u)<<16)|(address&0xff00u)|(address>>16);', '''// 独立位段逆变换，不在构造器使用PEXT或PDEP。
          const uint32_t r=(((address>>6)&63u)<<2)|(address&3u);
          const uint32_t g=(((address>>12)&63u)<<2)|((address>>2)&3u);
          const uint32_t b=(((address>>18)&63u)<<2)|((address>>4)&3u);
          const size_t i=h.tiled_index?((r<<16)|(g<<8)|b):(((address&255u)<<16)|(address&0xff00u)|(address>>16));''')
        s=s.replace('uint32_t(!h.direct_index.empty()),9,0,','uint32_t(!h.direct_index.empty()),uint32_t(h.tiled_index?15:9),0,')
    if p.name=='suffix_cache.hpp':
        s+='\nnamespace jshc_channel {\nvoid avx2_chain_tilebmi2(const uint32_t*,const uint32_t*,uint8_t*,size_t) noexcept;\nvoid avx2_chain_tilebmi2_to(const uint32_t*,const uint32_t*,const uint8_t*,uint8_t*,size_t) noexcept;\n}\n'
    if p.name=='CMakeLists.txt':
        s=s.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${JSHC_ROOT}', '"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${CMAKE_CURRENT_SOURCE_DIR}/channel_bmi2.cpp"\n  "${JSHC_ROOT}',1)
        s+='\n# BMI2仅在独立TU中启用，调用由通用dispatcher的CPUID判断控制。\nset_source_files_properties("${CMAKE_CURRENT_SOURCE_DIR}/channel_bmi2.cpp" PROPERTIES COMPILE_OPTIONS "-mavx2;-mbmi2;-mtune=skylake;-ffp-contract=off")\n'
    (out/p.name).write_bytes(s.encode('utf-8'))
s=(old/'channel_avx2.cpp').read_text(encoding='utf-8').replace('avx2_chain_batchspan','avx2_chain_tilebmi2')
s=s.replace('namespace {\n// 表按R低', '''namespace {
inline __attribute__((always_inline)) uint32_t index(uint32_t c) {
  return (_pext_u32(c,0xfcfcfcu)<<6)|_pext_u32(c,0x030303u);
}
// 每条64字节行保存4×4×4输入颜色；输出RGB32字节序保持原样。
// 原表按R低''',1)
s=s.replace('reinterpret_cast<const uint8_t*>(table)[code]]','reinterpret_cast<const uint8_t*>(table)[index(code)]]')
s=s.replace('reinterpret_cast<const uint8_t*>(table)[code&0xffffff]]','reinterpret_cast<const uint8_t*>(table)[index(code)]]')
(out/'channel_bmi2.cpp').write_bytes(s.encode('utf-8'))
# 扩展构建核查，严格限制BMI2只能出现在新TU，禁止泄漏到dispatcher。
s=(ROOT/'scripts/build_skylake_runtime.py').read_text(encoding='utf-8')
s=s.replace("if name != 'lut_simd_avx2.cpp' and name != 'channel_avx2.cpp' and '-mavx2' in command:","if name not in ('lut_simd_avx2.cpp','channel_avx2.cpp','channel_bmi2.cpp') and '-mavx2' in command:")
s=s.replace("if name in ('lut_simd_avx2.cpp', 'channel_avx2.cpp') and", "if name in ('lut_simd_avx2.cpp', 'channel_avx2.cpp','channel_bmi2.cpp') and")
s=s.replace('    files = {k:', '''        if ('-mbmi2' in command)!=(name=='channel_bmi2.cpp'):
            raise ValueError('BMI2必须仅出现在可选独立TU')
        if name=='channel_bmi2.cpp' and '-mavx2' not in command:
            raise ValueError('可选TU缺少显式AVX2')
    if sum(Path(x['file']).name=='channel_bmi2.cpp' for x in compile_commands)!=1:
        raise ValueError('BMI2 TU数量不符')
    files = {k:''')
builder=ROOT/'scripts/build_skylake_tilebmi2.py';assert not builder.exists();builder.write_bytes(s.encode('utf-8'));compile(s,str(builder),'exec')
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='47研究同容量16MiB表的4×4×4缓存行局部性；可选BMI2，缺失时保留40通用AVX2',candidate='有BMI2且未强制回退时，以两个PEXT重排输入索引；其他情况构造线性表并运行原40内核',base_commit='07c6e16e2adbd10c02172898c0ab7fce99b92ad9',revisions={'reference':23,'candidate':47},cmake_project='experiments/skylake-tilebmi2-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tilebmi2'])
plan['tilebmi2_policy']={'format':15,'fallback_format':9,'table_bytes':2**24,'tile':[4,4,4],'index':'(pext(c,0xfcfcfc)<<6)|pext(c,0x030303), c=R|(G<<8)|(B<<16)','choice':'固定4立方体恰占64字节，不扫描分块参数；既有30为向量gather与普通写，本版为40GPR查表与非临时写','dispatch':'构造期__builtin_cpu_supports(bmi2)，独立TU -mbmi2；无BMI2或JSHC_CHANNEL_FORCE_LINEAR_INDEX=1选择40线性表和通用AVX2','fallback_validation':'同一二进制分别执行默认和强制线性完整色域，强制回退不冒充无BMI2硬件实测','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':0.88,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止该布局，不产生完整性能分数或重复画像择优'},'hypothesis':'相邻颜色共享缓存行，可能抵消额外索引指令；尚未验证性能','sources':['https://www.intel.com/content/www/us/en/support/articles/000102715/processors/intel-xeon-processors.html','https://gcc.gnu.org/onlinedocs/gcc-11.2.0/gcc/x86-Built-in-Functions.html']}
plan['pageindex_policy']['scope_note']='该继承字段描述40线性回退；47可选布局以tilebmi2_policy为准'
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/') and k!='scripts/build_skylake_runtime.py'}
for p in [*out.iterdir(),builder]:plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-tilebmi2-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结47源码及计数筛选规则，未构建或调用像素')
