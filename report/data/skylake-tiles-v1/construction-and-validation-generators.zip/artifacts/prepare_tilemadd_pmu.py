"""在两种完整域均通过后冻结40/49单次配对计数，不产生墙钟成绩。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
normal=read('artifacts/skylake-tilemadd-linux-full-v1/results.json');fallback=read('artifacts/skylake-tilemadd-linux-fallback-full-v1/results.json')
assert normal['pass'] and fallback['pass'] and normal['libraries']==fallback['libraries']
assert not normal['forced_linear_index'] and fallback['forced_linear_index']
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference40','batchspan',40),('tilemadd49','tilemadd',49)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-tilemadd-v1.json');new='scripts/profile_skylake_tilemadd_pmu.py';p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference40','tilemadd49']},{'threads':4,'variants':['tilemadd49','reference40']}]
p['purpose']='40对49同容量颜色分块的单次用户态计数，先验门槛1线程周期比≤0.88且4线程≤1.05；失败则停止，不计墙钟速度'
p['screen']=read('experiments/skylake-tilemadd-v1.json')['tilemadd_policy']['pmu_screen']
p['fallback_full']=spec('artifacts/skylake-tilemadd-linux-fallback-full-v1/results.json')
dest=ROOT/'experiments/skylake-tilemadd-pmu-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('两种完整域均通过，49计数规则已冻结，未计数或计时')
