"""冻结49：以9条向量运算实现同一地址排列，替代48尚未执行的15操作草案。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-tilevector-runtime';out=ROOT/'experiments/skylake-tilemadd-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_tilevector','skylake_tilemadd').replace('avx2_chain_tilevector','avx2_chain_tilemadd').replace('channel_tilevector.cpp','channel_tilemadd.cpp')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 48;','jshc_cc_revision(void) {return 49;')
    if p.name=='channel_tilevector.cpp':
        a=s.index('inline __attribute__((always_inline)) __m256i indices(');b=s.index('// 先以AVX2计算8个地址',a)
        s=s[:a]+'''inline __attribute__((always_inline)) __m256i indices(__m256i c) {
  // R/G展开为无符号16位，再以64/4096系数组成索引高位；值均≤63。
  const __m256i rg=_mm256_shuffle_epi8(c,_mm256_setr_epi8(0,-1,1,-1,4,-1,5,-1,8,-1,9,-1,12,-1,13,-1,0,-1,1,-1,4,-1,5,-1,8,-1,9,-1,12,-1,13,-1));
  const __m256i high_rg=_mm256_madd_epi16(_mm256_srli_epi16(rg,2),_mm256_set1_epi32(0x10000040));
  // 低2位的加权和最大63，PMADDUBSW的两个16位部分和分别≤15及≤48，不饱和。
  const __m256i low=_mm256_madd_epi16(_mm256_maddubs_epi16(_mm256_and_si256(c,_mm256_set1_epi32(0x030303)),_mm256_set1_epi32(0x00100401)),_mm256_set1_epi16(1));
  const __m256i high_b=_mm256_and_si256(c,_mm256_set1_epi32(0xfc0000));
  return _mm256_or_si256(_mm256_or_si256(high_rg,high_b),low);
}
'''+s[b:]
    (out/('channel_tilemadd.cpp' if p.name=='channel_tilevector.cpp' else p.name)).write_bytes(s.encode('utf-8'))
s=(ROOT/'scripts/build_skylake_tilevector.py').read_text(encoding='utf-8').replace('channel_tilevector.cpp','channel_tilemadd.cpp')
builder=ROOT/'scripts/build_skylake_tilemadd.py';assert not builder.exists();builder.write_bytes(s.encode('utf-8'));compile(s,str(builder),'exec')
plan=json.loads((ROOT/'experiments/skylake-tilevector-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='49研究同容量颜色分块的整数向量加权索引；修订48在首次像素前停止，其冻结源与构建保留',candidate='AVX2 shuffle/word shift/PMADDWD合并R/G高位，AND/PMADDUBSW/PMADDWD合并低位，保留GPR查表、40输出与通用回退',revisions={'reference':23,'candidate':49},cmake_project='experiments/skylake-tilemadd-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tilemadd'])
policy=plan.pop('tilevector_policy');policy['choice']='47已测同容量布局减少generic miss但索引成本过高；48直接掩码方案尚未像素执行，本版先验用整数加权和降低运算数，不扫描参数或重测旧候选'
policy['hypothesis']='9条向量索引操作而非48的15条；实际指令、依赖延迟和缓存收益仍待测，不把符号计数当作速度'
policy['arithmetic_proof']='高R/G输入0..63，系数64/4096，32位和≤262080；低R/G/B均0..3，PMADDUBSW部分和≤15/48，第二级和≤63，既不饱和也不溢出；三部分位段不重叠'
plan['tilemadd_policy']=policy;plan['pageindex_policy']['scope_note']='该历史字段仅描述40线性回退；当前分块与索引以tilemadd_policy为准'
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-tilevector-runtime/') and k!='scripts/build_skylake_tilevector.py'}
for p in [*out.iterdir(),builder]:plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-tilemadd-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for channel in range(256):
    assert channel>>2<=63
for r in range(4):
 for g in range(4):
  for b in range(4):assert r+4*g<=15 and 16*b<=48 and r+4*g+16*b<=63
print('冻结49及饱和/溢出边界证明，未构建或执行像素')
