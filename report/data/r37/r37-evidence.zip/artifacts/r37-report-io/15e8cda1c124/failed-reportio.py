"""Atomic JSON publication and Windows readers that permit atomic replacement.

Only persistence changes here. A short-lived sharing/antivirus conflict may be
retried for at most five seconds; other errors propagate. Never switch to a
non-atomic truncate/write fallback, or suppress a failed publication.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile
import time


def _open_binary_shared_delete(path):
    if os.name != "nt":
        return Path(path).open("rb")
    import ctypes as ct
    from ctypes import wintypes as wt
    import msvcrt
    kernel = ct.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [wt.LPCWSTR, wt.DWORD, wt.DWORD, ct.c_void_p, wt.DWORD, wt.DWORD, wt.HANDLE]
    kernel.CreateFileW.restype = wt.HANDLE
    kernel.CloseHandle.argtypes = [wt.HANDLE]
    kernel.CloseHandle.restype = wt.BOOL
    # GENERIC_READ; SHARE_READ | SHARE_WRITE | SHARE_DELETE; OPEN_EXISTING.
    handle = kernel.CreateFileW(str(Path(path).resolve()), 0x80000000, 7, None, 3, 0x80, None)
    if handle == ct.c_void_p(-1).value:
        raise ct.WinError(ct.get_last_error())
    try:
        descriptor = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
    except BaseException:
        kernel.CloseHandle(handle)
        raise
    try:
        return os.fdopen(descriptor, "rb")
    except BaseException:
        os.close(descriptor)
        raise


def read_text_shared(path, *, encoding="utf-8", errors="strict"):
    """Read one stable opened snapshot while allowing a writer to rename it."""
    with _open_binary_shared_delete(path) as stream:
        return stream.read().decode(encoding, errors=errors)


def read_json(path):
    return json.loads(read_text_shared(path))


def write_report(path, value, *, retry_events=None):
    if path is None:
        return
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent,
                prefix=destination.name + ".", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
            stream.write("\n")
        started = time.monotonic()
        deadline = started + 5.
        delay = .005
        while True:
            try:
                os.replace(temporary, destination)
                break
            except PermissionError as error:
                remaining = deadline - time.monotonic()
                if os.name != "nt" or getattr(error, "winerror", None) not in (5, 32, 33) or remaining <= 0:
                    raise
                if retry_events is not None:
                    retry_events.append({"winerror": error.winerror, "elapsed_seconds": time.monotonic() - started})
                time.sleep(min(delay, remaining))
                delay = min(.1, delay * 2)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
