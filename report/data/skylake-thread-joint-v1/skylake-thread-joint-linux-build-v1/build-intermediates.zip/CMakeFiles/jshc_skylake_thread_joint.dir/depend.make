# Empty dependencies file for jshc_skylake_thread_joint.
# This may be replaced when dependencies are built.
