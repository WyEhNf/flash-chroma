"""冻结单元有符号证书、唯一候选和一次完整比较门槛。"""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':sha(ROOT/p)}
old=read(ROOT/'experiments/skylake-r-contiguous-v1.json')
plan={k:v for k,v in old.items() if k not in ('r_contiguous_policy','source_sha256')}
plan.update(purpose='逐单元有符号斜率/坐标区间证明首级完整输出被现有缓存覆盖，只对严格证明成功的句柄省范围判断',
 base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 candidate='准备时O(m³)有符号单元证明；成功用无范围分支模板，失败保留原检查/未命中回退；模型/表值/容量不变',
 cmake_project='experiments/skylake-domain-cache-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_domain_cache'],
 revisions={'reference':4,'candidate':15})
sources=[n for n in old['source_sha256'] if not n.startswith('experiments/skylake-r-contiguous-runtime/')]
sources += [p.relative_to(ROOT).as_posix() for p in (ROOT/'experiments/skylake-domain-cache-runtime').iterdir() if p.is_file()]
sources += ['scripts/domain_cache_support.py','scripts/verify_skylake_domain_cache.py']
plan['source_sha256']={n:sha(ROOT/n) for n in sorted(set(sources))}
plan['cache_policy']['lookup']='证明成功后无需逐包范围判断；任何可达单元的保守界不被现有缓存完整包含则原上下界检查与未命中回退，尾部原标量。'
plan['domain_cache_policy']={'cell_analysis':spec('artifacts/skylake-cell-certificate-profile-v1/results.json'),
 'all_cells':spec('artifacts/skylake-cell-certificate-profile-v1/all-cells.npz'),
 'global_analysis':spec('artifacts/skylake-domain-certificate-profile-v1/results.json'),
 'prior_output_analysis':spec('artifacts/skylake-cache-miss-analysis-v1/results.json'),
 'reference_static':spec('report/data/skylake-r-contiguous-v1/initial-static-results.json'),
 'reference_dispatch':spec('report/data/skylake-r-contiguous-v1/dispatch-proof-summary.json'),
 'actual_expected':{'eligible':1,'reachable_cells':32768,'unproven_cells':0,'dg_min':-15,'dg_max':2,'db_min':-35,'db_max':2},
 'persistent_model_byte_delta':0,'certificate_info_bytes':48,
 'static_gate':{'all_eight_hit_paths_cycles_and_throughput_ratio_max':1.03,
                'actual_proven_unshared_shared_cycles_ratio_max':.97,'cpus':['skylake','skylake-avx512'],
                'gathers_no_increase':True,'inner_loop_calls':0},
 'runtime_plan':'唯一基础55+6、缓存55及全部槽、8状态/实际区间/24诊断负例；通过后一次完整256³八组/100图；再唯一四进程ABBA×1/4线程×5完整百图，逐测量轮核对完整输出SHA。',
 'failure_policy':'任何门槛失败即保留停止，不改两码边界、预算、模型、编译属性或顺序寻求通过。'}
plan['performance']['verify_each_measured_round']=True
target=ROOT/'experiments/skylake-domain-cache-v1.json'
if target.exists():raise ValueError('不覆盖冻结计划')
target.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(sha(target))
