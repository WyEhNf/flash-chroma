"""派生域证明服务器入口，旧4/13入口和包保持原字节；不执行验证。"""
from pathlib import Path
ROOT=Path.cwd();p=ROOT/'scripts/run_skylake_domain_server.py';s=p.read_text(encoding='utf-8')
s=s.replace('r_contiguous','domain_isolated').replace("'domain_isolated':13","'domain_isolated':16")
s=s.replace("{'layout'}","{'domain'}").replace("plans['layout']","plans['domain']")
s=s.replace('布局双库','域证明双库').replace('布局子步骤','域证明子步骤').replace('物理缓存','原字典序缓存')
s=s.replace('完整物理缓存','完整原字典序缓存')
old="""    if role=='domain_isolated':
        stored,checks=table_bytes(d,h,info['entries'],physical=True,negative=negative)
        if stored!=physical:raise AssertionError('独立转置预期与实际原字典序缓存不同')
"""
assert old in s
s=s.replace(old,"""    if role=='domain_isolated':
        stored,checks=table_bytes(d,h,info['entries'],negative=negative)
        if stored!=canonical:raise AssertionError('独立整数预期与实际原字典序缓存不同')
""")
start=s.index('    storage_sha=None\n');end=s.index('\ndef validate(',start)
s=s[:start]+"""    certificate=None
    if role=='domain_isolated':
        certificate=domain_details(d,h)
        expected=bundle['domain_expected_actual' if count==4 else 'domain_expected_single']
        if any(certificate[k]!=v for k,v in expected.items()):raise ValueError('实际域证明/快路径状态不同')
    return {'coordinate_layouts':flag,'cache_info':info,'domain_certificate':certificate,'model_accounting_bytes':d.jshc_cc_model_bytes(h)}
"""+s[end:]
s=s.replace("'physical_export_checked':role=='domain_isolated'","'canonical_export_checked':True")
s=s.replace('finite=0;negative=0;memory=[];tables=[];prefixes=[]','finite=0;negative=0;memory=[];tables=[];prefixes=[];domains=[]')
anchor="            sizes={role:libs[role].jshc_cc_model_bytes(h) for role,h in handles.items()}"
assert anchor in s
s=s.replace(anchor,"""            detail=domain_details(libs['domain_isolated'],handles['domain_isolated'],negative=True)
            expected_domain=case.get('domain_certificate_expected')
            if expected_domain and any(detail[k]!=v for k,v in expected_domain.items()):raise AssertionError('有限域证明不同于已验独立区间')
            domains.append({'case':case['name'],**detail});negative+=detail['diagnostic_negative_checks']
"""+anchor)
s=s.replace("'cache_table_audits':tables,'first_stage_coverage':prefixes,","'cache_table_audits':tables,'first_stage_coverage':prefixes,'domain_diagnostics':domains,")
s=s.replace("or set(correctness['full_domain_pixels_per_configuration'].values())!={256**3} or len(correctness['photos'])!=8)",
 "or set(correctness['full_domain_pixels_per_configuration'].values())!={256**3} or len(correctness['photos'])!=8 or len(correctness['domain_diagnostics'])!=13)")
s=s.replace("f=getattr(d,'jshc_cc_copy_cache_storage' if physical else 'jshc_cc_copy_cache')","f=d.jshc_cc_copy_cache\n    if physical:raise ValueError('域证明包只使用原字典序u32缓存')")
header='''
class DomainInfo(ct.Structure):
    _fields_=[(n,ct.c_uint32) for n in ('version','eligible','cache_enabled','reserved')]
    _fields_ += [(n,ct.c_uint64) for n in ('reachable_cells','unproven_cells')]
    _fields_ += [(n,ct.c_int32) for n in ('dg_min','dg_max','db_min','db_max')]

def domain_details(d,h,negative=False):
    f=d.jshc_cc_get_domain_info;f.argtypes=[ct.c_void_p,ct.POINTER(DomainInfo),ct.c_size_t];f.restype=ct.c_int
    x=DomainInfo()
    if ct.sizeof(x)!=48 or f(h,ct.byref(x),ct.sizeof(x)) or x.version!=1 or x.reserved:raise ValueError('域证明只读ABI不同')
    fast=d.jshc_cc_domain_fast_enabled;fast.argtypes=[ct.c_void_p];fast.restype=ct.c_uint32
    result={n:getattr(x,n) for n,_ in x._fields_};result['fast_path_enabled']=int(fast(h));checks=0
    if result['fast_path_enabled'] and not result['eligible']:raise ValueError('未证明却启用快路径')
    if negative:
        guard=DomainInfo();ct.memset(ct.byref(guard),0xa7,ct.sizeof(guard));before=bytes(guard)
        for handle,output,size in ((h,ct.byref(guard),ct.sizeof(guard)-1),(None,ct.byref(guard),ct.sizeof(guard)),(h,None,ct.sizeof(guard))):
            if f(handle,output,size)!=1 or bytes(guard)!=before:raise AssertionError('域诊断拒绝保护不同')
            checks+=1
        if fast(None)!=0:raise AssertionError('空句柄快路径诊断不同')
        checks+=1
    result['diagnostic_negative_checks']=checks;return result

'''
s=s.replace('\ndef protocol():','\n'+header+'\ndef protocol():',1)
p.write_text(s,encoding='utf-8')
