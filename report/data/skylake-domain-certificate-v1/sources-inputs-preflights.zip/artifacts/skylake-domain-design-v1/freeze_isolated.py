"""冻结新隔离结构；修订15失败源/对象与结果保持原件。"""
import hashlib,json
from pathlib import Path
ROOT=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
plan=read(ROOT/'experiments/skylake-domain-cache-v1.json')
sources=[n for n in plan['source_sha256'] if not n.startswith('experiments/skylake-domain-cache-runtime/')]
sources += [p.relative_to(ROOT).as_posix() for p in (ROOT/'experiments/skylake-domain-isolated-runtime').iterdir() if p.is_file()]
plan['source_sha256']={n:sha(ROOT/n) for n in sorted(set(sources))}
plan.update(purpose='逐单元域证明的隔离快路径，未选择的全部原布局直接链接修订4原AVX2对象',
 candidate='新TU仅实现证明成功/首级非共享/后三共享的无检查路径；其余布局与证明失败直接调用原对象，不复制/重新组织回退内核',
 cmake_project='experiments/skylake-domain-isolated-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_domain_isolated'],
 revisions={'reference':4,'candidate':16})
policy=plan['domain_cache_policy'];policy['isolated_original_fallback']=True
policy['initial_failed_build']={'path':'artifacts/skylake-domain-cache-build-v1/build.json','sha256':sha(ROOT/'artifacts/skylake-domain-cache-build-v1/build.json')}
policy['initial_failed_static']={'path':'artifacts/skylake-domain-cache-static-v1/results.json','sha256':sha(ROOT/'artifacts/skylake-domain-cache-static-v1/results.json')}
policy['static_gate']={'legacy_fallback_object_byte_identical':True,
 'actual_proven_unshared_shared_cycles_ratio_max':.97,'actual_proven_unshared_shared_throughput_ratio_max':1.03,
 'inner_loop_calls':0,'gathers_no_increase':True,'cpus':['skylake','skylake-avx512'],
 'coverage':'原对象覆盖全部四种首级/后缀及未命中行为；唯一新增全命中路径单独建模，不能把准备/入口成本称为不变。'}
policy['failure_policy']='唯一隔离原型任何门槛失败即停止，不扫描内联、排列、位宽或条件，不删除修订15失败。'
target=ROOT/'experiments/skylake-domain-isolated-v1.json'
if target.exists():raise ValueError('不覆盖冻结计划')
target.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(sha(target))
