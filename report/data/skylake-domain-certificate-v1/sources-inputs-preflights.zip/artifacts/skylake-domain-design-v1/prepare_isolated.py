"""保留修订15失败原件；新修订16只增加隔离快路径并复用原对象，不调门槛或编译属性。"""
from pathlib import Path
ROOT=Path.cwd();folder=ROOT/'experiments/skylake-domain-isolated-runtime'
for name in ('channel_runtime.cpp','channel_views.hpp','suffix_cache.hpp'):
 p=folder/name;s=p.read_text(encoding='utf-8').replace('jshc_domain_cache','jshc_channel')
 if name=='channel_runtime.cpp':s=s.replace('return 15;}','return 16;}')
 p.write_text(s,encoding='utf-8')
p=folder/'CMakeLists.txt';s=p.read_text(encoding='utf-8').replace('skylake_domain_cache','skylake_domain_isolated')
s=s.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp")','"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")',1)
p.write_text(s,encoding='utf-8')
source=(ROOT/'experiments/skylake-domain-cache-runtime/channel_avx2.cpp').read_text(encoding='utf-8').replace('jshc_domain_cache','jshc_channel')
prefix=source[:source.index('template<bool FirstShared,bool SuffixShared,bool Proven>')]
body='''}
// 构造时证明完整输入域覆盖且首级非共享后使用；其他所有布局仍链接原修订4对象。
void avx2_chain_domain(const View* chain,const SuffixCacheView& cache,uint8_t* data,size_t pixels) noexcept {
  for(size_t p=0;p<pixels;p+=8) {
    Rgb rgb;load(data+3*p,rgb);transform<false>(chain[0],rgb);
    const __m256i dg=_mm256_sub_epi32(rgb.g,rgb.r),db=_mm256_sub_epi32(rgb.b,rgb.r);
    const __m256i index=_mm256_add_epi32(
        _mm256_mullo_epi32(_mm256_sub_epi32(rgb.r,_mm256_set1_epi32(cache.r_min)),_mm256_set1_epi32(cache.width_g*cache.width_b)),
        _mm256_add_epi32(_mm256_mullo_epi32(_mm256_sub_epi32(dg,_mm256_set1_epi32(cache.dg_min)),_mm256_set1_epi32(cache.width_b)),
            _mm256_sub_epi32(db,_mm256_set1_epi32(cache.db_min))));
    const __m256i value=gather(cache.table,index),mask=_mm256_set1_epi32(255);
    rgb.r=_mm256_and_si256(value,mask);rgb.g=_mm256_and_si256(_mm256_srli_epi32(value,8),mask);rgb.b=_mm256_srli_epi32(value,16);
    store(data+3*p,rgb);
  }
}
}
'''
(folder/'channel_avx2.cpp').write_text(prefix+body,encoding='utf-8')
