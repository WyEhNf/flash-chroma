"""只读归档证明、模板负结果与隔离版已完成验收，复核全部80轮输出，不执行新映射。"""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def copy(p,out,name=None):shutil.copyfile(p,out/(name or Path(p).name))
def zip_paths(target,paths):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for p,name in paths:z.write(p,name)

mathout=ROOT/'report/data/skylake-domain-certificate-v1';failed=ROOT/'report/data/skylake-domain-template-static-v1'
if mathout.exists() or failed.exists():raise ValueError('不覆盖证明/失败归档')
mathout.mkdir();failed.mkdir()
profiles=[('global','skylake-domain-certificate-profile-v1'),('cell','skylake-cell-certificate-profile-v1'),('observed','skylake-cache-miss-analysis-v1')]
for prefix,folder in profiles:
 copy(ROOT/'artifacts'/folder/'results.json',mathout,prefix+'-results.json')
copy(ROOT/'artifacts/skylake-cell-certificate-profile-v1/all-cells.npz',mathout)
assert not read(mathout/'global-results.json')['certificate_eligible']
assert read(mathout/'cell-results.json')['certificate_eligible']
assert read(mathout/'observed-results.json')['cache_miss_colours']==0
zpaths=[(p,p.relative_to(ROOT).as_posix()) for folder in ('artifacts/skylake-cache-miss-preflight-v1','artifacts/skylake-domain-design-v1')
 for p in (ROOT/folder).iterdir() if p.is_file()]
for name in ('analyze_skylake_domain_certificate.py','analyze_skylake_cell_certificate.py','analyze_skylake_cache_misses.py'):
 zpaths.append((ROOT/'scripts'/name,'scripts/'+name))
for name in ('base','sidecar'):
 spec=read(ROOT/'experiments/skylake-domain-isolated-v1.json')['fixed_inputs'][name];zpaths.append((ROOT/spec['path'],spec['path']))
zip_paths(mathout/'sources-inputs-preflights.zip',zpaths)

build15=ROOT/'artifacts/skylake-domain-cache-build-v1';static15=ROOT/'artifacts/skylake-domain-cache-static-v1'
initial=read(static15/'results.json');assert not initial['static_cost_gate_pass'] and not initial['selection_failures']
copy(ROOT/'experiments/skylake-domain-cache-v1.json',failed,'plan.json')
for p in build15.iterdir():
 if p.suffix in ('.json','.zip'):copy(p,failed,'build-'+p.name)
copy(static15/'results.json',failed,'analysis-results.json')
zip_paths(failed/'complete-analysis.zip',[(p,p.name) for p in sorted(static15.iterdir()) if p.is_file()])
zip_paths(failed/'built-not-executed.zip',[(p,p.relative_to(build15).as_posix()) for p in sorted(build15.rglob('*')) if p.is_file() and p.suffix in ('.dll','.obj')])
save(failed/'decision.json',{'purpose':'原模板方案未通过全族静态成本，不加载/验算/测速；隔离结构另立候选。',
 'candidate_revision':15,'native_calls':0,'performance_calls':0,'failed_static_gates':[x for x in initial['paired_cost_gates'] if not x['pass']],
 'actual_potential_gates':initial['actual_potential_gates'],'scope':'实际路径潜力不豁免其他家族失败；全部源、对象和日志保留，不能用隔离版正确性给修订15补发通过。'})

out=ROOT/'report/data/skylake-domain-isolated-v1';assert out.is_dir()
domain=ROOT/'artifacts/skylake-domain-isolated-domain-contract-v1'
for p in domain.iterdir():
 if p.is_file() and p.suffix in ('.json','.zip'):copy(p,out,'domain-contract-'+p.name)
static16=ROOT/'artifacts/skylake-domain-isolated-static-v1'
copy(static16/'results.json',out,'static-results.json')
zip_paths(out/'complete-static-analysis.zip',[(p,p.name) for p in sorted(static16.iterdir()) if p.is_file()])
build16=ROOT/'artifacts/skylake-domain-isolated-build-v1'
zip_paths(out/'objects-and-controller.zip',[(p,p.relative_to(build16).as_posix()) for p in sorted(build16.rglob('*')) if p.is_file() and (p.suffix=='.obj' or p.name=='validation-controller.py')])
zip_paths(out/'cache-fixture-bytes.zip',[(p,p.name) for p in sorted((ROOT/'artifacts/skylake-domain-isolated-cache-contract-v1').iterdir()) if p.suffix in ('.slut','.bin')])
full=read(out/'full-results.json');perf=read(out/'performance-results.json');domain_result=read(out/'domain-contract-results.json')
assert full['pass'] and domain_result['pass'] and perf['accepted_on_this_host'] and not perf['failed_gates']
hashes=0;records=0;source_sha='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
for index in range(4):
 worker=read(out/f'performance-worker{index}.json');assert worker['source_sha256']==source_sha and worker['actual_affinity']==[0,2,4,6]
 for record in worker['records']:
  records+=1;assert record['model_accounting_bytes']==1800836
  assert record['library_revision']==(16 if record['variant']=='candidate' else 4)
  expected=full['photos']['output_sha256'][record['variant']]
  assert len(record['per_round_output_sha256'])==5 and set(record['per_round_output_sha256'])=={expected}
  hashes+=len(record['per_round_output_sha256'])
  cache=record['suffix_cache_info'];assert cache['enabled'] and cache['entries']==185600 and cache['valid_entries']==171056 and cache['table_capacity_bytes']==742400
  info=record['cache_domain_certificate']
  if record['variant']=='candidate':assert info['eligible']==info['fast_path_enabled']==1 and info['unproven_cells']==0 and info['reachable_cells']==32768
  else:assert info is None
assert records==16 and hashes==80
save(out/'configuration-audit.json',{'purpose':'从4个原始进程逐项只读核对真实配置及每个测量轮输出，非重跑性能',
 'configurations_checked':records,'hundred_image_measured_rounds_hashed':hashes,'source_sha256':source_sha,
 'source_bytes':235929600,'model_bytes_both_roles':1800836,'table_bytes_both_roles':742400,
 'candidate_domain_proven_and_fast_enabled':True,'round_hash_mismatches':0,'new_pixel_mappings':0,'new_performance_calls':0,
 'scope':'完整域/百图资格来自原回执，此审计仅复核已保存SHA/配置；不补发未执行Skylake成绩。'})
save(out/'decision.json',{'purpose':'固定模型的逐单元域证明与隔离快路径，首次完整逐轮校验比较通过本机门槛',
 'candidate_revision':16,'reference_revision':4,'accepted_on_this_host':True,'paired':perf['paired'],
 'quality_changed':False,'model_memory_changed':False,'native_candidates_total':20,'timed_candidates':11,'static_stops':9,
 'first_template_revision15_static_stopped':True,'default_changed':False,'skylake_server_measured':False,
 'limitation':'固定已见100图、Windows/AMD、未锁频控温；四进程只作预声明描述性门槛，不作Holm/总体显著性，不叠乘历史收益。'})
print(json.dumps({'math':str(mathout),'static_failed':str(failed),'adopted_local':str(out),'records':records,'round_hashes':hashes},ensure_ascii=False))
