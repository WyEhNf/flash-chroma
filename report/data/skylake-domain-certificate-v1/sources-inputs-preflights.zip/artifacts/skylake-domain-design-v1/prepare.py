"""准备唯一的逐单元证明候选；不构建或运行。"""
from pathlib import Path
ROOT=Path.cwd();folder=ROOT/'experiments/skylake-domain-cache-runtime'
for name in ('channel_runtime.cpp','channel_avx2.cpp','suffix_cache.hpp','channel_views.hpp'):
 p=folder/name;s=p.read_text(encoding='utf-8').replace('jshc_channel','jshc_domain_cache')
 if name=='channel_runtime.cpp':s=s.replace('return 4;}','return 15;}')
 p.write_text(s,encoding='utf-8')
p=folder/'CMakeLists.txt';p.write_text(p.read_text(encoding='utf-8').replace('skylake_r_contiguous','skylake_domain_cache'),encoding='utf-8')
