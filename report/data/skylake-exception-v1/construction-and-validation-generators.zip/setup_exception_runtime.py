"""生成一次固定的精确例外池候选与22参考计划，不修改已有修订。"""
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'experiments/skylake-palette-runtime'; out=ROOT/'experiments/skylake-exception-runtime'
out.mkdir(exist_ok=False)
def write(name,text): (out/name).write_bytes(text.encode('utf-8'))
runtime=(old/'channel_runtime.cpp').read_text(encoding='utf-8')
runtime=runtime.replace('std::vector<uint32_t> compiled;', 'std::vector<uint32_t> compiled;\n  std::vector<uint32_t> exceptions;')
runtime=runtime.replace('avx2_chain_palette(h.views.data(),h.cache_view,h.compiled.data(),h.output_palette.data(),data,vectorized)',
    'avx2_chain_exception(h.compiled.data(),h.exceptions.data(),h.output_palette.data(),data,vectorized)')
runtime=runtime.replace('    info.blocks=packed.size();info.fast_blocks=good;', '''    // 两个零词保护混合包中的非例外lane；其索引固定落在0或1。
    std::vector<uint32_t> exception_words;
    exception_words.reserve(2+(packed.size()-good)*2);
    exception_words.push_back(0);exception_words.push_back(0);
    for(size_t block=0;block<packed.size();++block)if(packed[block]==255) {
      const size_t index=exception_words.size();
      if(index>0xffffff)throw std::runtime_error("例外索引超出24bit");
      packed[block]=(uint32_t(index)<<8)|255;
      for(unsigned half=0;half<2;++half) {
        uint32_t word=0;
        for(unsigned k=0;k<4;++k) {
          const size_t i=block*8+half*4+k;
          const uint32_t value=uint32_t(rgb[3*i])|(uint32_t(rgb[3*i+1])<<8)|(uint32_t(rgb[3*i+2])<<16);
          word|=uint32_t(lookup[value])<<(8*k);
        }
        exception_words.push_back(word);
      }
    }
    info.blocks=packed.size();info.fast_blocks=good;''')
runtime=runtime.replace('+info.table_capacity_bytes;', '+info.table_capacity_bytes+exception_words.capacity()*sizeof(uint32_t);')
runtime=runtime.replace('h.compiled.swap(packed);info.enabled=1;', 'h.compiled.swap(packed);h.exceptions.swap(exception_words);info.enabled=1;')
runtime=runtime.replace('swap(h.compiled);info.enabled=0;', 'swap(h.compiled);std::vector<uint32_t>().swap(h.exceptions);info.enabled=0;')
runtime=runtime.replace('jshc_cc_revision(void) {return 22;', 'jshc_cc_revision(void) {return 23;')
runtime=runtime.replace('h.compiled.capacity()*sizeof(uint32_t);', '(h.compiled.capacity()+h.exceptions.capacity())*sizeof(uint32_t);')
marker='uint32_t jshc_cc_domain_fast_enabled(const void* handle) {'
runtime=runtime.replace(marker, '''int jshc_cc_get_exception_info(const void* handle,jshc_cc_exception_info* output,size_t bytes) {
  if(!handle || !output || bytes!=sizeof(jshc_cc_exception_info))return 1;
  const auto& h=*static_cast<const Handle*>(handle);
  *output={1,h.palette_info.enabled,h.exceptions.size(),h.exceptions.capacity()*sizeof(uint32_t)};return 0;
}
int jshc_cc_copy_exceptions(const void* handle,uint32_t* output,size_t entries) {
  if(!handle)return 1;
  const auto& values=static_cast<const Handle*>(handle)->exceptions;
  if(entries!=values.size() || (entries && !output))return 1;
  if(entries)std::memcpy(output,values.data(),entries*sizeof(uint32_t));return 0;
}
'''+marker)
write('channel_runtime.cpp',runtime)
write('channel_views.hpp',(old/'channel_views.hpp').read_text(encoding='utf-8'))
header=(old/'suffix_cache.hpp').read_text(encoding='utf-8')
header+='''
namespace jshc_channel {
void avx2_chain_exception(const uint32_t*,const uint32_t*,const uint32_t*,uint8_t*,size_t) noexcept;
}
extern "C" {
// entries含两个零保护词；旧调色板ABI仍只描述主块表，不混入例外容量。
struct jshc_cc_exception_info {uint32_t version,enabled;uint64_t entries,table_capacity_bytes;};
JSHC_CC_API int jshc_cc_get_exception_info(const void*,jshc_cc_exception_info*,size_t);
JSHC_CC_API int jshc_cc_copy_exceptions(const void*,uint32_t*,size_t);
}
'''
write('suffix_cache.hpp',header)
write('channel_avx2.cpp','''// 修订23：原3bit块不变，例外块使用精确8bit ID池，混合包只增加一次gather。
#include "suffix_cache.hpp"
#include <immintrin.h>
namespace jshc_channel {
namespace {
inline __attribute__((always_inline)) __m256i gather(const uint32_t* data,__m256i index) {
  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(data),index,4);
}
}
void avx2_chain_exception(const uint32_t* blocks,const uint32_t* exceptions,const uint32_t* palette,
    uint8_t* data,size_t pixels) noexcept {
  const __m256i input_shuffle=_mm256_setr_epi8(2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1,2,1,0,-1,5,4,3,-1,8,7,6,-1,11,10,9,-1);
  const __m256i output_shuffle=_mm256_setr_epi8(0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1,0,1,2,4,5,6,8,9,10,12,13,14,-1,-1,-1,-1);
  const __m256i mask255=_mm256_set1_epi32(255);
  for(size_t p=0;p<pixels;p+=8) {
    uint8_t* dst=data+3*p;
    const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(dst));
    const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(dst+16));
    const __m128i hi=_mm_alignr_epi8(last,lo,12);
    const __m256i raw=_mm256_inserti128_si256(_mm256_castsi128_si256(lo),hi,1);
    const __m256i code=_mm256_shuffle_epi8(raw,input_shuffle);
    const __m256i words=gather(blocks,_mm256_srli_epi32(code,3));
    const __m256i base=_mm256_and_si256(words,mask255);
    const __m256i offset=_mm256_and_si256(code,_mm256_set1_epi32(7));
    const __m256i shift=_mm256_add_epi32(_mm256_add_epi32(offset,_mm256_slli_epi32(offset,1)),_mm256_set1_epi32(8));
    __m256i ids=_mm256_add_epi32(base,_mm256_and_si256(_mm256_srlv_epi32(words,shift),_mm256_set1_epi32(7)));
    const __m256i exceptional=_mm256_cmpeq_epi32(base,mask255);
    if(_mm256_movemask_epi8(exceptional)) {
      // 非例外lane只读两个零词，不使用主块载荷构造任意例外地址。
      const __m256i index=_mm256_add_epi32(_mm256_and_si256(_mm256_srli_epi32(words,8),exceptional),
          _mm256_and_si256(_mm256_srli_epi32(code,2),_mm256_set1_epi32(1)));
      const __m256i packed=gather(exceptions,index);
      const __m256i byte_shift=_mm256_slli_epi32(_mm256_and_si256(code,_mm256_set1_epi32(3)),3);
      const __m256i exact=_mm256_and_si256(_mm256_srlv_epi32(packed,byte_shift),mask255);
      ids=_mm256_blendv_epi8(ids,exact,exceptional);
    }
    const __m256i value=gather(palette,ids);
    const __m256i bytes=_mm256_shuffle_epi8(value,output_shuffle);
    const __m128i bottom=_mm256_castsi256_si128(bytes),top=_mm256_extracti128_si256(bytes,1);
    _mm_storeu_si128(reinterpret_cast<__m128i*>(dst),_mm_or_si128(bottom,_mm_slli_si128(top,12)));
    _mm_storel_epi64(reinterpret_cast<__m128i*>(dst+16),_mm_srli_si128(top,4));
  }
}
}
''')
cmake=(old/'CMakeLists.txt').read_text(encoding='utf-8').replace('project(jshc_skylake_palette','project(jshc_skylake_exception').replace('set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_palette)','set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_exception)')
cmake=cmake.replace('add_library(jshc_skylake_reference SHARED\n', 'add_library(jshc_skylake_reference SHARED\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_avx2.cpp"\n')
cmake=cmake.replace('add_library(jshc_skylake_reference SHARED\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_runtime.cpp"',
 'add_library(jshc_skylake_reference SHARED\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_avx2.cpp"')
cmake=cmake.replace('set_source_files_properties(\n','set_source_files_properties(\n  "${JSHC_ROOT}/experiments/skylake-palette-runtime/channel_avx2.cpp"\n')
write('CMakeLists.txt',cmake)
plan=json.loads((ROOT/'experiments/skylake-palette-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='相对最新已验22再提高至少50%吞吐；例外块的精确ID池代替插值回退',base_commit='b3d7f4c',
    candidate='保持原3bit主块，例外块低8位255/高24位为紧凑u32池偏移；每8输入存两个8bit ID词，前两个零词保护混合包')
plan['revisions']={'reference':22,'candidate':23}
plan['cmake_project']='experiments/skylake-exception-runtime'
plan['cmake_targets']=['jshc_skylake_reference','jshc_skylake_exception']
plan['exception_policy']={'block_pixels':8,'palette_max':255,'zero_guard_words':2,'source':'仅四个原稀疏模型，构造准备仍4线程',
    'actual_expected_exception_blocks':134853,'expected_words':269708,'expected_bytes':1078832,'metadata_delta_expected':24,
    'integer_contract':'全256³逐字节相同；原单级/未获证/大调色板回退保持',
    'performance_gate':'相对22的1/4线程apply和copy+apply配对中位均<=2/3，任一apply进程<=0.9；准备+首个已预热100图中位不退化',
    'scope':'本机固定模型；不是Skylake实测或任意模型相同加速保证'}
for p in out.iterdir():
    plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-exception-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('准备固定候选23及参考22；未运行像素核')
