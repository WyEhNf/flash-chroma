"""在数值调用前固定23对22的验证器；保留原22脚本及全部旧回执。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def source(name): return (ROOT/'scripts'/name).read_text(encoding='utf-8')
def save(name,text): (ROOT/'scripts'/name).write_bytes(text.encode('utf-8'))
extra='from exception_support import info as exception_info, table as exception_table, storage, ExceptionInfo\n'
for old,new in [('verify_skylake_palette_domain.py','verify_skylake_exception_domain.py'),
                ('verify_skylake_palette_signed.py','verify_skylake_exception_signed.py'),
                ('accept_skylake_palette.py','accept_skylake_exception.py')]:
    text=source(old).replace(old,new)
    text=text.replace('from palette_support import',extra+'from palette_support import',1)
    text=text.replace("'scripts/palette_support.py'", "'scripts/exception_support.py','scripts/palette_support.py'")
    if 'domain.py' in new:
        text=text.replace("extra_metadata+palette_info(candidate)['table_capacity_bytes']", "extra_metadata+storage(candidate)-storage(handles['reference'])")
        text=text.replace("'cache_info':cache}","'cache_info':cache,'exception_info':exception_info(candidate)}")
    elif 'signed.py' in new:
        text=text.replace('memory={};certificate=None','memory={};certificate=None;payload={};pool={}').replace("memory[role]=handle.model_bytes", "memory[role]=handle.model_bytes;payload[role]=storage(handle);pool[role]=exception_info(handle)")
        text=text.replace("extra_metadata+compiled_state['table_capacity_bytes']", "extra_metadata+payload['candidate']-payload['reference']")
        text=text.replace("'model_bytes':memory,", "'model_bytes':memory,'exception_info':pool,")
    else:
        text=text.replace('compiled_record = None', 'compiled_record = None; exception_record = None')
        text=text.replace("compiled_record={mode:palette_info(h) for mode,h in operators['candidate'].items()}",
            "compiled_record={mode:palette_info(h) for mode,h in operators['candidate'].items()};exception_record={mode:exception_info(h) for mode,h in operators['candidate'].items()}")
        text=text.replace("palette_info(operators['candidate'][mode])['table_capacity_bytes']", "storage(operators['candidate'][mode])-storage(operators['reference'][mode])")
        text=text.replace("'compiled_palette':compiled_record,", "'compiled_palette':compiled_record, 'compiled_exceptions':exception_record,")
    save(new,text)
text=source('verify_skylake_palette.py').replace('verify_skylake_palette.py','verify_skylake_exception.py')
text=text.replace('from palette_support import',extra+'from palette_support import',1)
text=text.replace("[*plan['source_sha256'],__file__,'scripts/palette_support.py'", "[*plan['source_sha256'],'scripts/verify_skylake_exception.py','scripts/exception_support.py','scripts/palette_support.py'")
text=text.replace("extra+state['table_capacity_bytes']", "extra+storage(cand)-storage(handles['reference'])")
text=text.replace('good=(words&255)!=255;good_count=0;decoded=0', 'pool=exception_table(cand);pool_state=exception_info(cand)\n        assert len(pool)>=2 and np.all(pool[:2]==0)\n        good=(words&255)!=255;good_count=0;decoded=0;exception_count=0')
text=text.replace("            if np.any(w[~mask]!=255):raise ValueError('拒绝块不是标准哨兵')", '''            addresses=w[~mask]>>8
            np.testing.assert_array_equal(addresses,2+2*(exception_count+np.arange(len(addresses),dtype=np.uint32)))
            independent_pool=np.zeros((len(addresses),2),np.uint32)
            for half in range(2):
                for k in range(4):independent_pool[:,half]|=ids[~mask,half*4+k]<<np.uint32(8*k)
            np.testing.assert_array_equal(pool[addresses[:,None]+np.array([0,1],np.uint32)],independent_pool)
            exact_ids=(pool[addresses[:,None]+np.arange(8,dtype=np.uint32)//4]>>((np.arange(8,dtype=np.uint32)%4)*8))&255
            np.testing.assert_array_equal(palette[exact_ids.ravel()],packed.reshape(-1,8)[~mask].ravel())
            exception_count+=len(addresses)''')
text=text.replace("        fast=np.flatnonzero(good)", "        assert len(pool)==2+2*exception_count and len(pool)*4==pool_state['table_capacity_bytes']\n        fast=np.flatnonzero(good)")
text=text.replace("        save(out/'results.json'", '''        ef=d.jshc_cc_get_exception_info;ei=ExceptionInfo();ct.memset(ct.byref(ei),0xa7,ct.sizeof(ei));eb=bytes(ei)
        for handle,output,size in [(None,ct.byref(ei),ct.sizeof(ei)),(cand.handle,None,ct.sizeof(ei)),(cand.handle,ct.byref(ei),ct.sizeof(ei)-1)]:
            if ef(handle,output,size)!=1 or bytes(ei)!=eb:raise ValueError('例外诊断拒绝写入')
            negative+=1
        ec=d.jshc_cc_copy_exceptions;eg=np.full(len(pool)+4,0xa7a7a7a7,np.uint32)
        for handle,entries,null in [(None,len(pool),False),(cand.handle,len(pool)-1,False),(cand.handle,len(pool),True)]:
            if ec(handle,None if null else eg.ctypes.data_as(ptr),entries)!=1 or np.any(eg!=0xa7a7a7a7):raise ValueError('例外表拒绝写入')
            negative+=1
        save(out/'results.json' ''')
text=text.replace("'palette':state,", "'palette':state,'exceptions':pool_state,'exception_blocks_checked':exception_count,'pool_sha256':__import__('hashlib').sha256(pool.tobytes()).hexdigest(),")
text=text.replace('独立解码全部8色/3bit块，核对实际快慢混合包、边界与诊断不写；不测速。','独立重建全部3bit主块与精确8bit例外池，核对混合包、边界和诊断不写；不测速。')
save('verify_skylake_exception.py',text)
plan=ROOT/'experiments/skylake-exception-v1.json'
old=json.loads((ROOT/'experiments/skylake-palette-validation-v3.json').read_text(encoding='utf-8'))
old['purpose']='相对修订22再提高50%吞吐；全部主块与例外池的独立完整域重建，先数值后唯一性能'
old['base_plan_sha256']=hashlib.sha256(plan.read_bytes()).hexdigest();old['revision']=1
old.pop('revision_reason',None)
old['actual_full_decode']='完整16M颜色，低8位255的主块地址必须按RGB顺序连续；两零词+每例外块两个精确8bit词独立重建'
old['resource']='候选与参考载荷分别核算主块/例外池，真实非四级句柄给出元数据差24字节；不能把参考已有8MiB算作新增加速'
old['source_sha256']={}
for name in ['exception_support.py','palette_support.py','verify_skylake_exception.py','verify_skylake_exception_domain.py','verify_skylake_exception_signed.py','accept_skylake_exception.py','bench_skylake_palette.py']:
    path=ROOT/'scripts'/name;compile(path.read_text(encoding='utf-8'),str(path),'exec')
    old['source_sha256']['scripts/'+name]=hashlib.sha256(path.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-exception-validation-v1.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('固定验证器与v1身份；尚未进行数值调用')
