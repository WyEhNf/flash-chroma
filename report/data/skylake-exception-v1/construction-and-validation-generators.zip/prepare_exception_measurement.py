"""准备大调色板补验、Linux入口和唯一比较策略；仅生成文件，不运行像素核或计时。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,text):path.write_bytes(text.encode('utf-8'))
def readscript(name):return (ROOT/'scripts'/name).read_text(encoding='utf-8')
s=readscript('verify_skylake_palette_fallback.py').replace('verify_skylake_palette_fallback.py','verify_skylake_exception_fallback.py')
s=s.replace('from palette_support import','from exception_support import info as exception_info, table as exception_table\nfrom palette_support import',1)
s=s.replace("'scripts/palette_support.py'", "'scripts/exception_support.py','scripts/palette_support.py'")
s=s.replace("'palette': palette_info(handle)","'palette': palette_info(handle),'exceptions': exception_info(handle)")
s=s.replace('== 1104','== 24')
s=s.replace("assert state['enabled'] == state['table_capacity_bytes'] == state['blocks'] == 0", "assert state['enabled'] == state['table_capacity_bytes'] == state['blocks'] == 0\n                pool=exception_info(handle);assert pool['enabled']==pool['entries']==pool['table_capacity_bytes']==0\n                assert exception_table(handle).size==0")
save(ROOT/'scripts/verify_skylake_exception_fallback.py',s)
s=readscript('verify_skylake_palette_linux.py')
s=s.replace('Linux调色板22','Linux调色板例外池23')
s=s.replace('compiled_states = {}','compiled_states = {}; exception_state = None')
s=s.replace("                for mode in operators[name]:",'''                if name=='candidate':
                    class ExceptionInfo(ct.Structure):
                        _fields_=[('version',ct.c_uint32),('enabled',ct.c_uint32),('entries',ct.c_uint64),('table_capacity_bytes',ct.c_uint64)]
                    f=d.jshc_cc_get_exception_info;f.argtypes=[ct.c_void_p,ct.POINTER(ExceptionInfo),ct.c_size_t];f.restype=ct.c_int
                    value=ExceptionInfo()
                    if f(operators[name]['chain'],ct.byref(value),ct.sizeof(value)):raise ValueError('Linux例外诊断失败')
                    exception_state={n:getattr(value,n) for n,_ in value._fields_}
                    if value.version!=1 or value.enabled!=1 or value.entries!=269708 or value.table_capacity_bytes!=1078832:
                        raise ValueError('Linux实际例外池与冻结模型不同')
                for mode in operators[name]:''')
s=s.replace("'compiled_palette':compiled_states,", "'compiled_palette':compiled_states,'compiled_exceptions':exception_state,")
save(ROOT/'scripts/verify_skylake_exception_linux.py',s)
s=readscript('bench_skylake_palette.py').replace('bench_skylake_palette.py','bench_skylake_exception.py')
s=s.replace('from palette_support import','from exception_support import info as exception_info\nfrom palette_support import',1)
s=s.replace('                compiled=palette_info(chain)', '                compiled=palette_info(chain);pool=exception_info(chain)')
s=s.replace("                if name=='candidate' and (compiled", "                if name=='candidate' and (pool is None or pool['enabled']!=1 or pool['entries']!=269708 or pool['table_capacity_bytes']!=1078832):raise ValueError('计时必须实际启用冻结例外池')\n                if name=='candidate' and (compiled")
s=s.replace("'compiled_palette':compiled,", "'compiled_palette':compiled,'compiled_exceptions':pool,")
s=s.replace("'scripts/bench_skylake_exception.py','scripts/palette_support.py'", "'scripts/bench_skylake_exception.py','scripts/exception_support.py','scripts/palette_support.py'")
save(ROOT/'scripts/bench_skylake_exception.py',s)
policy=json.loads((ROOT/'experiments/skylake-palette-perf-v1.json').read_text(encoding='utf-8'))
policy['purpose']='修订23直接对已验22的唯一80轮；要求1/4线程apply与copy+apply吞吐均再提高50%，准备成本单列'
def spec(path):return {'path':path,'sha256':digest(ROOT/path)}
policy['plan']=spec('experiments/skylake-exception-v1.json')
policy['build_path']='artifacts/skylake-exception-build-v1'
policy['build']=spec(policy['build_path']+'/build.json')
policy['full_acceptance']=spec('artifacts/skylake-exception-full-v1/results.json')
for field,name in [('domain_contract','domain'),('packed_contract','packed'),('signed_contract','signed')]:
    v=2 if name=='packed' else 1
    policy[field]=spec(f'artifacts/skylake-exception-{name}-contract-v{v}/results.json')
policy['validation']=spec('experiments/skylake-exception-validation-v2.json')
policy['benchmark_script']=spec('scripts/bench_skylake_exception.py')
policy['exception_support']=spec('scripts/exception_support.py')
policy['limits'].append('例外池实际269708个u32，1078832字节；任意模型容量不同，官方许可仍待确认')
(ROOT/'experiments/skylake-exception-perf-v1.json').write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ('verify_skylake_exception_fallback.py','verify_skylake_exception_linux.py','bench_skylake_exception.py'):
    compile(readscript(name),name,'exec')
print('已固定唯一80轮比较策略与新增入口；没有计时')
