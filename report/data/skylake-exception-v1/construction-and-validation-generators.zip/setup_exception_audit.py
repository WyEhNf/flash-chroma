"""从独立标准库复算器派生23对22的只读审计，不改变计时器或任何轮次。"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'scripts/audit_skylake_palette.py').read_text(encoding='utf-8')
s=s.replace('修订22的唯一性能记录','修订23对22的唯一性能记录')
s=s.replace("'packed_contract', 'signed_contract', 'validation')", "'packed_contract', 'signed_contract', 'validation', 'benchmark_script', 'exception_support')")
s=s.replace("{'reference': 16, 'candidate': 22}", "{'reference': 22, 'candidate': 23}")
s=s.replace("(1800836 if role == 'reference' else 10190548)", "(10190548 if role == 'reference' else 11269404)")
s=s.replace("            if role == 'candidate':\n                p = record['compiled_palette']", "            if role == 'candidate':\n                e=record['compiled_exceptions']\n                require(e['version']==1 and e['enabled']==1 and e['entries']==269708 and e['table_capacity_bytes']==1078832, '实际例外池不同')\n                p = record['compiled_palette']")
(ROOT/'scripts/audit_skylake_exception.py').write_bytes(s.encode('utf-8'))
compile(s,'audit_skylake_exception.py','exec')
print('只读复算器准备完成；未读取未完成的计时数据')
