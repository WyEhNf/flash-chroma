"""独立C++示例小型raw回放与拒绝合同；不作性能或正式精度评分。"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import flash_chroma_support as support

folder = ROOT / 'artifacts/event-cpp-smoke-20261029'
folder.mkdir()
exe = ROOT / 'artifacts/event-cpp-build/flash_chroma_run.exe'
library = support.Library(ROOT / 'artifacts/single-header-perf-build/libflash_chroma_bridge.dll')
manifest_path = ROOT / 'data/p16-frontier/models/manifest.json'
manifest, models = support.load_models(manifest_path, ['max_first'])
model = models['max_first']
root = manifest_path.parent / manifest.get('path_root', '.')
profile = manifest['profiles']['max_first']
model_paths = [str((root / row['path']).resolve()) for row in profile['models']]
side_paths = [str((root / row['path']).resolve()) if row else '-' for row in profile['sidecars']]
rng = np.random.default_rng(20261029)
source = rng.integers(0, 256, (2, 11, 19, 3), np.uint8)
source[0, 0, 0] = 0
source[-1, -1, -1] = 255
input_path = folder / 'input.rgb'
input_path.write_bytes(source.tobytes())
target = np.empty_like(source)
scalar = np.empty_like(source)
flat_source, flat_target = source.reshape(-1, 3), target.reshape(-1, 3)
with library.create(model, support.configuration(backend='avx2', threads=1)) as engine:
    engine.apply(flat_source, flat_target)
assert library.c_apply(model, flat_source, scalar.reshape(-1, 3)) == 0
np.testing.assert_array_equal(target, scalar)
base = [str(exe), '--models', *model_paths, '--sidecars', *side_paths, '--input', str(input_path)]
environment = dict(os.environ)
environment['PATH'] = 'E:/mingw64/bin;' + environment.get('PATH', '')
rows = []

def execute(name, extra, expected=0):
    command = base + extra
    result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True, encoding='utf-8',
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    rows.append({'name': name, 'command': command, 'returncode': result.returncode,
                 'stdout': result.stdout, 'stderr': result.stderr})
    assert (result.returncode == 0) == (expected == 0), (name, result.returncode, result.stderr)
    return result

output_path, report_path = folder / 'output.rgb', folder / 'run.json'
args = ['--output', str(output_path), '--report', str(report_path), '--width', '19', '--height', '11', '--count', '2', '--backend', 'avx2', '--threads', '1', '--block-pixels', '13']
success = execute('两帧非整8宽度及非整块边界', args)
actual = output_path.read_bytes()
assert actual == target.tobytes() == scalar.tobytes()
record = json.loads(report_path.read_text(encoding='utf-8'))
assert record['completed'] and record['frames_written'] == 2 and record['output_bytes_written'] == source.nbytes
assert json.loads(success.stdout) == record
assert record['quality_verified'] is False and record['official_score_available'] is False
assert all(value >= 0 for value in record['timings_ms'].values())
assert record['timings_ms']['whole_wall'] >= record['timings_ms']['prepare'] + record['timings_ms']['apply_only_sum']
before = hashlib.sha256(actual).hexdigest()
execute('拒绝覆盖既有raw与报告', args, 1)
assert hashlib.sha256(output_path.read_bytes()).hexdigest() == before

for name, flags in [
    ('拒绝零线程', ['--threads', '0']),
    ('拒绝尺寸乘积溢出', ['--width', str(2**64-1), '--height', '2']),
    ('拒绝输入长度不符', ['--width', '19', '--height', '11', '--count', '3']),
    ('拒绝未实现AVX512', ['--width', '19', '--height', '11', '--count', '2', '--backend', 'avx512']),
    ('拒绝工作区少于准备预算', ['--width', '19', '--height', '11', '--count', '2', '--backend', 'avx2', '--workspace-bytes', '1'])]:
    path = folder / (str(len(rows)) + '-rejected.rgb')
    execute(name, ['--output', str(path), *flags], 1)
    assert not path.exists()

existing_report = folder / 'existing.json'
existing_report.write_bytes(b'preserve-existing-report\n')
new_output = folder / 'report-rejected.rgb'
execute('既有报告不得被覆盖且raw不创建', ['--output', str(new_output), '--report', str(existing_report), '--width', '19', '--height', '11', '--count', '2'], 1)
assert existing_report.read_bytes() == b'preserve-existing-report\n' and not new_output.exists()

summary = {'passed': True, 'cases': len(rows), 'environment': support.native.environment(),
           'input_shape': list(source.shape), 'input_sha256': hashlib.sha256(source.tobytes()).hexdigest(),
           'output_sha256': before, 'ffi_and_independent_c99_equal': True,
           'library': library.record(), 'exe_sha256': support.digest(exe),
           'sources': {name: support.digest(ROOT / name) for name in ('single_header/event_run.cpp', 'single_header/CMakeLists.txt', 'include/flash_chroma.hpp')},
           'scope': 'Windows AMD64 / MinGW G++15.2 Release标准C++17小型连续raw输入；两帧逐字节比对与参数/覆盖拒绝；不赋新色差或性能资格。',
           'records': rows}
support.write_json(folder / 'results.json', summary)
print(json.dumps({'passed': True, 'cases': len(rows), 'output_sha256': before, 'scope': summary['scope']}, ensure_ascii=False))
