# Flash Chroma 本机离线调试包

本包包含当前独立hpp/h、维护源码、CMake/bridge/C++连续RGB8入口、照片工作台、17套组合、18份原始CUBE及许可、7套模型对象、100张1024×768真实PNG及来源。只复制明确清单中的公开项目文件，不包含Git、私密配置、RAW大素材、厂商解码工具或四张密集原LUT。

## 在同一电脑搬目录后运行

```powershell
.\start-local.ps1
.\start-local.ps1 -Mode doctor -Config event-demo.json
.\start-local.ps1 -Mode run -Config event-demo.json -Output my-debug-run -Limit 1
.\bin\flash_chroma_run.exe --help
```

默认打开Studio，只监听127.0.0.1。若端口占用会选新端口。图片和处理结果留在本机。RAW入口仅保留源代码和元数据；它所需的原素材、厂商解码器、WSL/OCIO/OpenEXR没有打入本包，不宣称RAW流程离线可用。

Python环境没有打包。LOCAL-RUNTIME.json记录本机实际Python/NumPy/Pillow和可选SciPy；默认复用该Python。搬到另一电脑应安装依赖并设置：

```powershell
$env:FLASH_CHROMA_PYTHON = '你已准备好的Python完整路径'
.\start-local.ps1 -Mode doctor -Config event-demo.json
```

原生DLL与C++exe附有递归核对的MinGW运行DLL及许可，不复制Windows系统DLL。此包是已测Windows同机包，不承诺跨系统、跨ABI或无依赖运行。需改C++时用single_header目录重新构建；原.hpp/.h及测试源都在包中。

## 明日正式数据

1. 用init新建配置，替换正式图片列表/image_root和四个source_luts。
2. 当前适配格式是每份50331648B、uint8[R,G,B,C]且B索引最快。正式文件位深、格式或轴序不同必须先显式适配，不能只改扩展名。
3. fit四原表生成新source-manifest.json及run-config.json，再用新配置run。四级m可不同，均17..33，整批固定。未知LUT默认Sparse；direct的容量资格由实际prepare决定。
4. 把赛方T填threshold，每图全像素mean RGB欧氏差严格<T；图数须符合expected_images。显式-Limit只用于调试，不能标成正式百图。没有密集参考/T就不声明质量过线。

```powershell
.\start-local.ps1 -Mode init -Output event-new.json
# 编辑event-new.json，填正式四原表及图片；不要沿用示例Cinema的manifest。
.\start-local.ps1 -Mode fit -Config event-new.json -Output fitted-new
.\start-local.ps1 -Mode run -Config fitted-new/run-config.json -Output official-debug
```

所有输出拒绝覆盖。GUI导出的创意组合JSON会被正式入口明确拒绝。逐图流式耗时与预载百图基准分列，不估算官方分数。更多实际参数见docs/event-quickstart.md。

event-demo.json是已见Cinema样例，source_luts为空、threshold=null，质量未验；独立C99只核对本图实现一致性。SELF-CHECK保存构建时从包目录实际doctor及限1图运行的原始回执、PNG和像素SHA；绝对路径仅反映那次运行，不是搬目录后的路径要求。

## 素材和只读核验

照片保留Kodak/DPED/DIV2K来源，其中DIV2K限学术研究；不能把本包或这些图片自动改授代码许可证。CUBE来自Striped Purple，保留MIT许可。各原说明在assets/photos与assets/LUT，模型许可在data/p16-frontier/models，MinGW许可在licenses/mingw。

```powershell
& $env:FLASH_CHROMA_PYTHON scripts/package_p16_event.py verify --package .
# 可额外 --zip 旁边的ZIP，核对全部ZIP成员原字节。
```

MANIFEST.json逐成员记录SHA256与尺寸，ZIP另有外部SHA回执。verify只读，不重写包或重新测速。用户后续运行生成的新输出不属于原包成员；原成员改动会被发现。PNG/资产没有上传到任何外部服务。
