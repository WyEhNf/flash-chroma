param(
    [ValidateSet('studio','doctor','init','fit','run')][string]$Mode = 'studio',
    [string]$Config = 'event-demo.json', [string]$Output, [string]$Library,
    [string]$Manifest, [string]$Images, [string]$ImageRoot,
    [Alias('Profile')][string]$ModelProfile, [int]$Limit, [double]$Threshold,
    [ValidateRange(0,65535)][int]$Port = 8765, [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$packetRoot = $PSScriptRoot
if (-not $env:FLASH_CHROMA_PYTHON) {
    $runtime = Get-Content -LiteralPath (Join-Path $packetRoot 'LOCAL-RUNTIME.json') -Raw | ConvertFrom-Json
    if (-not (Test-Path -LiteralPath $runtime.executable -PathType Leaf)) {
        throw '记录的本机Python不存在，请先设置FLASH_CHROMA_PYTHON为已安装NumPy/Pillow的Python完整路径。'
    }
    $env:FLASH_CHROMA_PYTHON = $runtime.executable
}
$arguments = @{}
foreach ($key in $PSBoundParameters.Keys) { $arguments[$key] = $PSBoundParameters[$key] }
$arguments['Mode'] = $Mode
$arguments['Config'] = $Config
Push-Location -LiteralPath $packetRoot
try { & (Join-Path $packetRoot 'start-event.ps1') @arguments }
finally { Pop-Location }
