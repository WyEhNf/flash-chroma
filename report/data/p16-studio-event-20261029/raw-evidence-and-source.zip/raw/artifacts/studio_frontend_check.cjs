/* 2026-10-29 最终前端检查的可复现保存件。
 * 原验收在工具中分两段执行：Node VM回调检查，再运行Python静态DOM检查。
 * 下方两个原始脚本按原样嵌入；外层只负责Node语法检查及顺序调用。
 * 从仓库根运行：node artifacts/studio_frontend_check.cjs
 * Python可由FLASH_CHROMA_PYTHON指定；默认使用PATH中的python。
 * 原始回执使用wx保护，已存在时拒绝覆盖。此脚本不调用浏览器或重建UI。
 */
"use strict";
const { execFileSync } = require("node:child_process");

const nodePhase = String.raw`
const fs=require('node:fs'); const vm=require('node:vm'); const crypto=require('node:crypto'); const assert=require('node:assert/strict');
const source=fs.readFileSync('gui/static/studio.js','utf8');
const lines=source.split(/\r?\n/).filter(line=>line.includes('$("copy-button").onclick ='));
assert.equal(lines.length,1); const callback=lines[0];
const actual={profile:'detail',weights:[.95,.35,.15],threads:4,m:[33,33,33,33],backend:'avx2',representation:'sparse'};
const old={profile:'compact',weights:[.3,.6,.95],threads:1,m:[17,17,17,17],backend:'scalar',representation:'sparse'};
async function check(label,flags,native=false){
  const writes=[]; const notices=[]; const button={};
  const ui={photo:{id:'photo-new'},preset:{id:native?'cinema-fixed':'look-new',native_profile:native?'max_first':undefined},stages:[{lut:'warm',strength:.3,enabled:true}],profile:'detail',weights:[.95,.35,.15],threads:4,
    busy:flags.busy,dirty:flags.dirty,result:flags.noResult?null:{config:flags.busy||flags.dirty?old:actual}};
  const before=JSON.stringify(ui);
  const scope=vm.createContext({$:id=>{assert.equal(id,'copy-button');return button;},ui,native:()=>native,navigator:{clipboard:{writeText:async value=>{writes.push(value);}}},toast:message=>notices.push(message)});
  vm.runInContext(callback,scope,{timeout:1000}); assert.equal(typeof button.onclick,'function'); await button.onclick();
  assert.equal(writes.length,1); const copied=JSON.parse(writes[0]); const fresh=Boolean(ui.result&&!flags.busy&&!flags.dirty);
  assert.equal(copied.result_current,fresh); assert.equal(copied.photo,'photo-new'); assert.equal(copied.preset,ui.preset.id);
  assert.equal(copied.profile,'detail'); assert.deepEqual(copied.weights,[.95,.35,.15]);
  if(fresh)assert.deepEqual(copied.actual_config,actual); else assert.equal(Object.hasOwn(copied,'actual_config'),false);
  if(native)assert.equal(Object.hasOwn(copied,'stages'),false); else assert.deepEqual(copied.stages,ui.stages);
  assert.equal(JSON.stringify(ui),before); assert.equal(notices.length,1);
  return {name:label,passed:true,result_current:copied.result_current,actual_config_included:Object.hasOwn(copied,'actual_config'),native};
}
(async()=>{
 const cases=[];
 cases.push(await check('新参数未计算：不复制旧actual_config',{dirty:true,busy:false}));
 cases.push(await check('处理中：不复制旧actual_config',{dirty:false,busy:true}));
 cases.push(await check('修改且处理中：不复制旧actual_config',{dirty:true,busy:true}));
 cases.push(await check('尚无结果：不宣称actual_config',{dirty:false,busy:false,noResult:true}));
 cases.push(await check('最新完成：复制当前实际配置',{dirty:false,busy:false}));
 cases.push(await check('最新Cinema完成：保留native身份，不伪造creative stages',{dirty:false,busy:false},true));
 const sha=path=>crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex');
 const result={passed:false,date:'2026-10-29',environment:{platform:process.platform,architecture:process.arch,node:process.version},
   purpose:'最终前端静态与离线复制回调检查；不调用浏览器、不重建UI、不执行图像或性能测试',
   node_syntax:{passed:true,command:'node --check gui/static/studio.js'},
   copy_callback:{passed:true,cases,source:'从最终studio.js抽取单一copy-button回调；Node VM仅绑定最小clipboard spy与参数夹具'},
   source_sha256:Object.fromEntries(['studio.js','studio.html','studio.css'].map(name=>[name,sha('gui/static/'+name)])),
   limitations:['未验证浏览器布局、原点权限或真实剪贴板/下载体验；未绕过此前浏览器原点权限拒绝。','离线回调检查仅证明pending/fresh复制字段绑定，不替代真实HTTP处理和PNG验证。']};
 fs.writeFileSync('artifacts/studio-frontend-final-check.json',JSON.stringify(result,null,2)+'\n',{encoding:'utf8',flag:'wx'});
 console.log('最终Node语法及6种复制状态检查通过');
})().catch(error=>{console.error(error);process.exitCode=1;});
`;

const pythonPhase = String.raw`
from pathlib import Path
from html.parser import HTMLParser
from collections import Counter
import re,json,hashlib
root=Path.cwd();paths={name:root/'gui/static'/name for name in ('studio.html','studio.js','studio.css')};values={name:p.read_text(encoding='utf-8') for name,p in paths.items()}
file=root/'artifacts/studio-frontend-final-check.json';result=json.loads(file.read_text(encoding='utf-8'))
assert result['source_sha256']=={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'检查期间前端来源改变'
class IDs(HTMLParser):
    def __init__(self):super().__init__();self.ids=[];self.resources=[];self.references=[]
    def handle_starttag(self,tag,attrs):
        data=dict(attrs)
        if 'id' in data:self.ids.append(data['id'])
        for key in ('aria-controls','aria-labelledby','for'):
            if key in data:self.references.extend(data[key].split())
        if tag=='use' and data.get('href','').startswith('#'):self.references.append(data['href'][1:])
        if tag in ('script','link') and data.get('src',data.get('href','')).startswith('/'):
            self.resources.append(data.get('src',data.get('href')))
p=IDs();p.feed(values['studio.html']);counts=Counter(p.ids);duplicates=[k for k,v in counts.items() if v>1]
js=values['studio.js'];refs=set(re.findall(r'\$\("([^"\n]+)"\)',js))|set(re.findall(r'text\("([^"\n]+)"\s*,',js))
dynamic=[f'weight-{key}{suffix}' for key in ('accuracy','speed','memory') for suffix in ('','-value')]+[f'{part}-{key}' for part in ('tab','panel') for key in ('chain','performance')]
missing=sorted((refs|set(dynamic)|set(p.references))-set(p.ids));assert not duplicates,duplicates;assert not missing,missing
for resource in p.resources:assert (root/'gui/static'/resource.lstrip('/')).is_file(),resource
css=re.sub(r'/\*.*?\*/','',values['studio.css'],flags=re.S);css=re.sub(r'([\"\'])(?:\\.|(?!\1).)*?\1','',css)
stack=[]
for ch in css:
    if ch in '{(':stack.append(ch)
    elif ch in '})':
        assert stack and stack[-1]=={'}':'{',')':'('}[ch],'CSS括号不匹配';stack.pop()
assert not stack,'CSS括号未闭合'
result['dom_static']={'passed':True,'html_ids':len(p.ids),'static_dom_references':len(refs),'dynamic_dom_references':len(dynamic),'html_aria_svg_references':len(p.references),'duplicate_ids':duplicates,'missing_references':missing,'resources':p.resources}
result['css_brackets']={'passed':True,'scope':'移除注释与字符串后核对花括号/圆括号闭合；不是浏览器CSS语义验证'}
result['passed']=True;file.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':True,'copy_cases':len(result['copy_callback']['cases']),'ids':len(p.ids),'source_sha256':result['source_sha256'],'receipt':str(file)},ensure_ascii=False))
`;

execFileSync(process.execPath, ["--check", "gui/static/studio.js"], { stdio: "inherit" });
execFileSync(process.execPath, ["-"], { input: nodePhase, stdio: ["pipe", "inherit", "inherit"] });
execFileSync(process.env.FLASH_CHROMA_PYTHON || "python", ["-X", "utf8", "-"], {
  input: pythonPhase, stdio: ["pipe", "inherit", "inherit"],
});
