"""冻结一次编译器调度比较；只读既有源码和包含路径。"""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((ROOT/'experiments/skylake-r-contiguous-v1.json').read_text(encoding='utf-8'))
paths=[n for n in old['source_sha256'] if n.startswith(('cpp/','portable/','experiments/channel-runtime/','experiments/skylake-suffix-cache-runtime/'))]
paths += ['scripts/inspect_skylake_server_tuning.py','scripts/inspect_skylake_avx2.py','scripts/inspect_skylake_preweight.py']
rsp=ROOT/'artifacts/skylake-r-contiguous-build-v1/CMakeFiles/jshc_skylake_reference.dir/includes_CXX.rsp'
plan={'schema':1,'purpose':'仅比较固定后缀缓存AVX2内核的Skylake客户端/服务器调度；若对象相同即停止，不进行重复性能测试。',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_sha256':{n:sha(ROOT/n) for n in sorted(set(paths))},
 'compiler':{'path':'E:/mingw64/bin/g++.exe','sha256':sha('E:/mingw64/bin/g++.exe')},
 'objdump':{'path':'E:/mingw64/bin/objdump.exe','sha256':sha('E:/mingw64/bin/objdump.exe')},
 'translation_unit':'experiments/skylake-suffix-cache-runtime/channel_avx2.cpp',
 'reference_build':'artifacts/skylake-r-contiguous-build-v1',
 'include_response':'CMakeFiles/jshc_skylake_reference.dir/includes_CXX.rsp',
 'include_response_sha256':sha(rsp),'include_response_text':rsp.read_text(encoding='utf-8'),
 'common_flags':['-DJSHC_CC_HAVE_AVX2=1','-Djshc_skylake_reference_EXPORTS','-O3','-DNDEBUG','-std=c++17','-Wall','-Wextra','-fvisibility=hidden','-fopenmp'],
 'only_changed_option':['-mtune=skylake','-mtune=skylake-avx512'],
 'reference_object_sha256':'823a27fa6b8018b969758d0e62597f3f60a2369a2be9018c34282769aee0d1d3',
 'policy':{'native_calls':0,'performance_calls':0,'no_isa_expansion':'保留-mavx2；无-march、-mavx512、FMA或fast-math；-mtune仅调度。',
 'if_objects_equal':'完整对象逐字节相同则无新实现，不链接/测速。',
 'if_objects_different':'先证明全部分派/回退路径的静态可观收益，未证明前不运行候选。'},
 'primary_source':'https://gcc.gnu.org/onlinedocs/gcc-15.2.0/gcc/x86-Options.html'}
target=ROOT/'experiments/skylake-server-tuning-v1.json'
if target.exists():raise ValueError('不覆盖冻结计划')
target.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(sha(target))
