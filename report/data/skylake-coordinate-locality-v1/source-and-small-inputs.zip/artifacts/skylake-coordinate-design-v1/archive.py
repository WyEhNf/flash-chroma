"""只读归档坐标资格、首级节点局部性及一次编译调度结果；不执行内核。"""
import hashlib,json,subprocess,zipfile
from pathlib import Path
import numpy as np
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
OUT=ROOT/'report/data/skylake-coordinate-locality-v1'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
if OUT.exists():raise ValueError('不覆盖归档')
profiles={'coordinate-reuse-results.json':ROOT/'artifacts/skylake-coordinate-reuse-profile-v1/results.json',
          'node-layout-results.json':ROOT/'artifacts/skylake-node-layout-profile-v1/results.json',
          'server-tuning-results.json':ROOT/'artifacts/skylake-server-tuning-static-v1/results.json'}
values={n:read(p) for n,p in profiles.items()}
a=values['coordinate-reuse-results.json'];b=values['node-layout-results.json'];c=values['server-tuning-results.json']
assert not a['geometry_profile_gate_pass'] and not a['endpoint_profile']['eligible']
assert not b['profile_gate_pass']
assert c['objects_byte_identical'] and c['parsed_instructions_identical'] and c['reference_matches_prior_object']
assert all(v['project_native_calls']==v['performance_calls']==0 for v in values.values())
assert a['photo_stream_sha256']==b['photo_stream_sha256']=='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
for file,result in (('scripts/profile_skylake_coordinate_reuse.py',a),('scripts/profile_skylake_node_layout.py',b)):
 assert sha(ROOT/file)==result['source_sha256']
plan=read(ROOT/'experiments/skylake-server-tuning-v1.json')
for file,expected in plan['source_sha256'].items():assert sha(ROOT/file)==expected
f=np.fromfile(ROOT/'artifacts/cinema-current-anchor-accept-v1/channel-frac.bin','<u4').reshape(3,3,256)
pair=(f[1]&65535)|((f[2]&65535)<<16);end=f[0]&65536
expanded=np.stack((f[0],(pair&65535)|end,(pair>>16)|end))
cases=[]
for axis,code in np.argwhere(((f[1]==65536)!=(f[0]==65536))|((f[2]==65536)!=(f[0]==65536))):
 cases.append({'axis':int(axis),'input_code':int(code),'original_channel_fractions':f[:,axis,code].tolist(),
               'incorrect_shared_endpoint_expansion':expanded[:,axis,code].tolist()})
OUT.mkdir()
for name,path in profiles.items():(OUT/name).write_bytes(path.read_bytes())
save(OUT/'endpoint-counterexamples.json',{'purpose':'完整九张坐标表中共享ONE标志不成立的全部轴/输入码；仅数学展开，不是原生错误。',
 'sidecar_sha256':sha(ROOT/'artifacts/cinema-current-anchor-accept-v1/channel-frac.bin'),
 'mismatched_axis_codes':cases,'mathematical_expansion_mismatches':int(np.count_nonzero(expanded!=f)),
 'project_native_calls':0,'performance_calls':0})
(OUT/'server-tuning-plan.json').write_bytes((ROOT/'experiments/skylake-server-tuning-v1.json').read_bytes())
with zipfile.ZipFile(OUT/'server-tuning-complete.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted((ROOT/'artifacts/skylake-server-tuning-static-v1').iterdir()):
  if path.is_file():z.write(path,path.name)
base=read(ROOT/'experiments/skylake-r-contiguous-v1.json')
files=set(plan['source_sha256'])|{'scripts/profile_skylake_coordinate_reuse.py','scripts/profile_skylake_node_layout.py',
 'experiments/skylake-server-tuning-v1.json','experiments/skylake-r-contiguous-v1.json',
 'python/lutlab/io.py','artifacts/skylake-coordinate-design-v1/freeze.py','artifacts/skylake-coordinate-design-v1/archive.py',
 'artifacts/skylake-r-contiguous-build-v1/CMakeFiles/jshc_skylake_reference.dir/includes_CXX.rsp'}
files|={base['fixed_inputs'][name]['path'] for name in ('base','sidecar','model','manifest')}
with zipfile.ZipFile(OUT/'source-and-small-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in sorted(files):z.write(ROOT/name,name)
save(OUT/'decision.json',{'purpose':'四项结构/调度假设的阶段停止；不构建新运行库、不重复性能。',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'geometry':{'same_order_pixels_fraction':a['same_order_pixel_fraction'],
             'all_eight_same_order_packets_fraction':a['same_order_packet_fraction'],'required':.60,'decision':'覆盖不足，未写共享顶点内核'},
 'endpoint':{'mismatched_axis_codes':len(cases),'expansion_mismatches':int(np.count_nonzero(expanded!=f)),
             'decision':'数学资格不成立，不写端点压缩实现；不以65535缺失绕开条件'},
 'first_node_layout':{'ratios':b['r_contiguous_over_b_contiguous'],'gate':b['gate_before_profile'],
                      'decision':'局部性收益不足，不实现首级节点重排'},
 'server_tuning':{'object_sha256':c['variants']['reference']['object_sha256'],'decision':'对象相同，不链接/加载/测速'},
 'native_candidate_count_unchanged':18,'prior_timed_candidates_unchanged':10,
 'new_library_builds':0,'new_object_compilations':2,'project_native_calls':0,'performance_calls':0,
 'scope':'仅已见100图的结构与本机MinGW对象，不是新质量、速度、独立验收或Skylake服务器成绩。'})
print(json.dumps({'endpoint_cases':cases,'node_ratios':b['r_contiguous_over_b_contiguous'],'out':str(OUT)},ensure_ascii=False))
