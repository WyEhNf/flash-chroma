"""冻结40的单次Zen4访存诊断政策及三个输入身份；不执行原生映射或计数。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def digest(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def spec(s):return {'path':s,'sha256':digest(ROOT/s)}
def read(s):return json.loads((ROOT/s).read_text(encoding='utf-8'))
def repeat_sha(b,n):
    size=1024*1024//len(b);chunk=b*size;h=hashlib.sha256();q,r=divmod(n,len(chunk))
    for _ in range(q):h.update(chunk)
    h.update(chunk[:r]);return h.hexdigest()
dest=ROOT/'experiments/skylake-lookup-diagnostic-v1.json';assert not dest.exists()
probe='artifacts/skylake-lookup-diagnostics-v1/raw-probe.json';assert read(probe)['available']
cube='artifacts/cinema-current-anchor-accept-v1/cube.rgb';assert digest(ROOT/cube)=='3c9ce8d98d8db454ce9337c50c2ecadb8ba59485d6bc3e6a42e3cc1dfe307c22'
rgb=[128,128,128];index=rgb[0]*65536+rgb[1]*256+rgb[2]
with (ROOT/cube).open('rb') as f:f.seek(3*index);output=f.read(3)
assert len(output)==3
source_names=['scripts/profile_skylake_lookup_diagnostic.py','scripts/lookup_pmu_support.py','scripts/probe_skylake_lookup_pmu.py','scripts/skylake_server_support.py','scripts/verify_skylake_linux_stdlib.py','scripts/outplace_support.py','scripts/pinned_openmp_support.py','scripts/paged_table_support.py','scripts/probe_skylake_pmu.py']
policy={'purpose':'仅诊断同一40对照片/固定灰色及原地/分离输出的Zen4用户态等待，不能作为吞吐验收或挑选旧候选','source':'https://github.com/torvalds/linux/tree/v6.18/tools/perf/pmu-events/arch/x86/amdzen4','event_sources':['https://github.com/torvalds/linux/blob/v6.18/tools/perf/pmu-events/arch/x86/amdzen4/core.json','https://github.com/torvalds/linux/blob/v6.18/tools/perf/pmu-events/arch/x86/amdzen4/memory.json','https://github.com/torvalds/linux/blob/v6.18/arch/x86/events/amd/core.c'],'cpu_family':25,'cpu_model':97,'perf_type':4,'events':[['cycles',118],['instructions',192],['l2_request_misses',2404],['oldest_not_complete',726],['oldest_load_not_complete',41686],['load_dispatch',297]],'affinity_cpus':[0,2,4,6],'threads':1,'pin_all_six':True,'exclude_kernel_hypervisor':True,'min_running_fraction':.99,'probe':spec(probe),'plan':spec('experiments/skylake-batchspan-v1.json'),'build':spec('artifacts/skylake-batchspan-linux-build-v1/build.json'),'full':spec('artifacts/skylake-batchspan-linux-full-v1/results.json'),'driver':spec('artifacts/skylake-domain-server-v2/artifacts/linux domain-v2/driver/libjshc_server_driver.so'),'photos':spec('artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'),'photo_output_sha256':'f3c0d9078bbcf069f33060a45021a28985b70c9616493ba9bea1ac2027858528','uniform_rgb':rgb,'uniform_single_pixel_output':list(output),'uniform_source_sha256':repeat_sha(bytes(rgb),235929600),'uniform_output_sha256':repeat_sha(output,235929600),'order':['photo_inplace','uniform_inplace','photo_outplace'],'warmup_per_case':1,'count_per_case':1,'wallclock_timing_calls':0,'source_hashes':{p:digest(ROOT/p) for p in source_names},'limitations':['单次异质工作负载只诊断本机，不能跨案例算相对23的提速','三个案例本身时间顺序固定，绝对周期受频率、宿主噪声和缓存状态影响','固定灰色不是自然照片，不按照片和内容设置运行时特判','原始事件映射来自Linux Zen4定义，WSL虚拟PMU语义未由宿主校准','比例只表示最老load阻塞退休的周期，不证明load请求并行度或真实Skylake瓶颈']}
dest.write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('单次40访存诊断冻结，灰色输出',list(output),'政策SHA',digest(dest),'未执行像素')
