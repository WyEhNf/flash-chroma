"""只读100图的64像素窗口，比较R低与B低两种表行地址；不映射或计时。"""
from pathlib import Path
import argparse,hashlib,json,platform
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
EXPECTED='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists();source=ROOT/'artifacts/skylake-server-matrix-v1/server-inputs/photos.rgb'
    with source.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    assert sha==EXPECTED
    images=np.memmap(source,dtype=np.uint8,mode='r',shape=(100,786432,3))
    totals={name:{'same_next':0,'sum_unique_64':0,'hist_unique_64':[0]*65} for name in ('R_low','B_low')}
    for image in images:
        r=image[:,0].astype(np.uint32);g=image[:,1].astype(np.uint32);b=image[:,2].astype(np.uint32)
        for name,low,high in (('R_low',r,b),('B_low',b,r)):
            line=(low>>6)|(g<<2)|(high<<10)
            group=np.sort(line.reshape(-1,64),axis=1)
            distinct=1+np.count_nonzero(group[:,1:]!=group[:,:-1],axis=1)
            hist=np.bincount(distinct,minlength=65);result=totals[name]
            result['same_next']+=int(np.count_nonzero(line[1:]==line[:-1]))
            result['sum_unique_64']+=int(distinct.sum())
            result['hist_unique_64']=[x+int(y) for x,y in zip(result['hist_unique_64'],hist)]
    windows=100*786432//64
    for item in totals.values():
        item['mean_unique_lines_per_64']=item['sum_unique_64']/windows
        item['same_next_fraction']=item['same_next']/(100*(786432-1))
        assert sum(item['hist_unique_64'])==windows
    result={'purpose':__doc__,'input_sha256':sha,'windows':windows,'cpu':'仅NumPy离线地址统计；未调用目标库','python':platform.python_version(),'numpy':np.__version__,'layouts':totals,'scope':'已见100图的短窗口集合，不等于缓存miss率；全RGB8均可逆置换，不用于改变模型或按图像选择路径','candidate_pixel_calls':0,'candidate_timing_calls':0,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print({k:{'mean_unique_lines_per_64':v['mean_unique_lines_per_64'],'same_next_fraction':v['same_next_fraction']} for k,v in totals.items()})
if __name__=='__main__':main()
