
artifacts\skylake-evex256-build-v1\CMakeFiles\jshc_skylake_evex256.dir\channel_dispatch.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_evex256::evex256_enabled()>:
   0:	48 83 ec 28          	sub    $0x28,%rsp
   4:	0f b6 05 00 00 00 00 	movzbl 0x0(%rip),%eax        # b <jshc_evex256::evex256_enabled()+0xb>
   b:	84 c0                	test   %al,%al
   d:	74 11                	je     20 <jshc_evex256::evex256_enabled()+0x20>
   f:	0f b6 05 08 00 00 00 	movzbl 0x8(%rip),%eax        # 1e <jshc_evex256::evex256_enabled()+0x1e>
  16:	48 83 c4 28          	add    $0x28,%rsp
  1a:	c3                   	ret
  1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  20:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 27 <jshc_evex256::evex256_enabled()+0x27>
  27:	e8 00 00 00 00       	call   2c <jshc_evex256::evex256_enabled()+0x2c>
  2c:	85 c0                	test   %eax,%eax
  2e:	74 df                	je     f <jshc_evex256::evex256_enabled()+0xf>
  30:	e8 00 00 00 00       	call   35 <jshc_evex256::evex256_enabled()+0x35>
  35:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 3c <jshc_evex256::evex256_enabled()+0x3c>
  3c:	31 d2                	xor    %edx,%edx
  3e:	8b 40 0c             	mov    0xc(%rax),%eax
  41:	f7 d0                	not    %eax
  43:	a9 00 80 70 00       	test   $0x708000,%eax
  48:	74 1e                	je     68 <jshc_evex256::evex256_enabled()+0x68>
  4a:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 51 <jshc_evex256::evex256_enabled()+0x51>
  51:	88 15 08 00 00 00    	mov    %dl,0x8(%rip)        # 5f <jshc_evex256::evex256_enabled()+0x5f>
  57:	e8 00 00 00 00       	call   5c <jshc_evex256::evex256_enabled()+0x5c>
  5c:	0f b6 05 08 00 00 00 	movzbl 0x8(%rip),%eax        # 6b <jshc_evex256::evex256_enabled()+0x6b>
  63:	48 83 c4 28          	add    $0x28,%rsp
  67:	c3                   	ret
  68:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 6f <jshc_evex256::evex256_enabled()+0x6f>
  6f:	e8 00 00 00 00       	call   74 <jshc_evex256::evex256_enabled()+0x74>
  74:	48 85 c0             	test   %rax,%rax
  77:	0f 94 c2             	sete   %dl
  7a:	eb ce                	jmp    4a <jshc_evex256::evex256_enabled()+0x4a>
  7c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000080 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)>:
  80:	53                   	push   %rbx
  81:	48 83 ec 40          	sub    $0x40,%rsp
  85:	0f b6 05 00 00 00 00 	movzbl 0x0(%rip),%eax        # 8c <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
  8c:	84 c0                	test   %al,%al
  8e:	48 89 cb             	mov    %rcx,%rbx
  91:	74 2d                	je     c0 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x40>
  93:	80 3d 07 00 00 00 00 	cmpb   $0x0,0x7(%rip)        # a1 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x21>
  9a:	48 89 d9             	mov    %rbx,%rcx
  9d:	74 11                	je     b0 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x30>
  9f:	48 83 c4 40          	add    $0x40,%rsp
  a3:	5b                   	pop    %rbx
  a4:	e9 00 00 00 00       	jmp    a9 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x29>
  a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  b0:	48 83 c4 40          	add    $0x40,%rsp
  b4:	5b                   	pop    %rbx
  b5:	e9 00 00 00 00       	jmp    ba <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3a>
  ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  c0:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # c7 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x47>
  c7:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
  cc:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
  d1:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  d6:	e8 00 00 00 00       	call   db <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5b>
  db:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  e0:	85 c0                	test   %eax,%eax
  e2:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  e7:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  ec:	74 a5                	je     93 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13>
  ee:	e8 00 00 00 00       	call   f3 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
  f3:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # fa <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7a>
  fa:	31 c9                	xor    %ecx,%ecx
  fc:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 101:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
 106:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
 10b:	8b 40 0c             	mov    0xc(%rax),%eax
 10e:	f7 d0                	not    %eax
 110:	a9 00 80 70 00       	test   $0x708000,%eax
 115:	74 35                	je     14c <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcc>
 117:	88 0d 08 00 00 00    	mov    %cl,0x8(%rip)        # 125 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa5>
 11d:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 124 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa4>
 124:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
 129:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
 12e:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
 133:	e8 00 00 00 00       	call   138 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb8>
 138:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
 13d:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
 142:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 147:	e9 47 ff ff ff       	jmp    93 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13>
 14c:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 153 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd3>
 153:	e8 00 00 00 00       	call   158 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
 158:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
 15d:	48 85 c0             	test   %rax,%rax
 160:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
 165:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 16a:	0f 94 c1             	sete   %cl
 16d:	eb a8                	jmp    117 <jshc_evex256::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x97>
 16f:	90                   	nop
