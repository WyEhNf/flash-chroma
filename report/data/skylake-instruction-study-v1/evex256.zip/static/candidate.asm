
artifacts\skylake-evex256-build-v1\CMakeFiles\jshc_skylake_evex256.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	57                   	push   %rdi
       1:	56                   	push   %rsi
       2:	53                   	push   %rbx
       3:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
       a:	c5 f8 29 34 24       	vmovaps %xmm6,(%rsp)
       f:	c5 f8 29 7c 24 10    	vmovaps %xmm7,0x10(%rsp)
      15:	c5 78 29 44 24 20    	vmovaps %xmm8,0x20(%rsp)
      1b:	c5 78 29 4c 24 30    	vmovaps %xmm9,0x30(%rsp)
      21:	c5 78 29 54 24 40    	vmovaps %xmm10,0x40(%rsp)
      27:	c5 78 29 5c 24 50    	vmovaps %xmm11,0x50(%rsp)
      2d:	c5 78 29 64 24 60    	vmovaps %xmm12,0x60(%rsp)
      33:	c5 78 29 6c 24 70    	vmovaps %xmm13,0x70(%rsp)
      39:	c5 78 29 b4 24 80 00 	vmovaps %xmm14,0x80(%rsp)
      40:	00 00 
      42:	c5 78 29 bc 24 90 00 	vmovaps %xmm15,0x90(%rsp)
      49:	00 00 
      4b:	49 89 ca             	mov    %rcx,%r10
      4e:	49 89 d3             	mov    %rdx,%r11
      51:	4c 89 c3             	mov    %r8,%rbx
      54:	48 83 fa 04          	cmp    $0x4,%rdx
      58:	0f 84 f5 07 00 00    	je     853 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x853>
      5e:	4d 85 c9             	test   %r9,%r9
      61:	0f 84 8f 07 00 00    	je     7f6 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f6>
      67:	49 ff c9             	dec    %r9
      6a:	62 a1 75 00 ef c9    	vpxord %xmm17,%xmm17,%xmm17
      70:	62 e1 fd 28 6f 25 00 	vmovdqa64 0x0(%rip),%ymm20        # 7a <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7a>
      77:	00 00 00 
      7a:	62 e1 fd 28 6f 1d 20 	vmovdqa64 0x20(%rip),%ymm19        # a4 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa4>
      81:	00 00 00 
      84:	49 c1 e9 03          	shr    $0x3,%r9
      88:	62 a3 75 20 25 c9 ff 	vpternlogd $0xff,%ymm17,%ymm17,%ymm17
      8f:	c5 f5 46 c9          	kxnorb %k1,%k1,%k1
      93:	62 b1 65 28 72 d1 18 	vpsrld $0x18,%ymm17,%ymm3
      9a:	62 b1 7d 20 72 d1 0f 	vpsrld $0xf,%ymm17,%ymm16
      a1:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
      a5:	4f 8d 0c 5b          	lea    (%r11,%r11,2),%r9
      a9:	48 8d 74 c3 18       	lea    0x18(%rbx,%rax,8),%rsi
      ae:	b8 00 80 00 00       	mov    $0x8000,%eax
      b3:	49 c1 e1 05          	shl    $0x5,%r9
      b7:	62 e2 7d 28 7c d0    	vpbroadcastd %eax,%ymm18
      bd:	4d 01 d1             	add    %r10,%r9
      c0:	c5 fa 6f 03          	vmovdqu (%rbx),%xmm0
      c4:	c5 fa 7e 4b 10       	vmovq  0x10(%rbx),%xmm1
      c9:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
      cf:	62 f3 fd 28 38 c1 01 	vinserti64x2 $0x1,%xmm1,%ymm0,%ymm0
      d6:	62 b2 7d 28 00 c4    	vpshufb %ymm20,%ymm0,%ymm0
      dc:	62 f1 55 20 72 d0 08 	vpsrld $0x8,%ymm0,%ymm21
      e3:	62 f1 fd 28 db cb    	vpandq %ymm3,%ymm0,%ymm1
      e9:	62 e1 d5 20 db eb    	vpandq %ymm3,%ymm21,%ymm21
      ef:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
      f4:	4d 85 db             	test   %r11,%r11
      f7:	0f 84 4b 07 00 00    	je     848 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x848>
      fd:	62 61 fd 28 6f c1    	vmovdqa64 %ymm1,%ymm24
     103:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     107:	4c 89 d0             	mov    %r10,%rax
     10a:	e9 fb 01 00 00       	jmp    30a <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x30a>
     10f:	90                   	nop
     110:	c5 ad 72 e6 10       	vpsrad $0x10,%ymm6,%ymm10
     115:	62 d1 0d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm30
     11c:	c5 f9 90 e9          	kmovb  %k1,%k5
     120:	c5 f9 90 f1          	kmovb  %k1,%k6
     124:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
     129:	c5 bd 72 e7 10       	vpsrad $0x10,%ymm7,%ymm8
     12e:	c5 2d fe d2          	vpaddd %ymm2,%ymm10,%ymm10
     132:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
     137:	62 91 0d 20 72 e6 10 	vpsrad $0x10,%ymm30,%ymm30
     13e:	62 31 3d 28 fe c6    	vpaddd %ymm22,%ymm8,%ymm8
     144:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     149:	c5 c5 72 e7 10       	vpsrad $0x10,%ymm7,%ymm7
     14e:	62 21 0d 20 fe f5    	vpaddd %ymm21,%ymm30,%ymm30
     154:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     158:	62 b1 45 28 fe fe    	vpaddd %ymm22,%ymm7,%ymm7
     15e:	c4 c1 35 72 e6 10    	vpsrad $0x10,%ymm14,%ymm9
     164:	62 f3 0d 20 1f de 06 	vpcmpnled %ymm6,%ymm30,%k3
     16b:	62 82 4d 28 3d f6    	vpmaxsd %ymm30,%ymm6,%ymm22
     171:	62 12 4d 28 39 fe    	vpminsd %ymm30,%ymm6,%ymm15
     177:	62 f3 4d 20 1f d7 01 	vpcmpltd %ymm7,%ymm22,%k2
     17e:	62 31 35 28 fe cd    	vpaddd %ymm21,%ymm9,%ymm9
     184:	62 e2 4d 20 3d f7    	vpmaxsd %ymm7,%ymm22,%ymm22
     18a:	62 81 45 28 fe ee    	vpaddd %ymm30,%ymm7,%ymm21
     190:	62 62 05 28 39 ef    	vpminsd %ymm7,%ymm15,%ymm29
     196:	62 92 55 2b 64 d4    	vpblendmd %ymm28,%ymm5,%ymm2{%k3}
     19c:	62 f3 0d 20 1f de 01 	vpcmpltd %ymm6,%ymm30,%k3
     1a3:	62 b1 4d 28 fa f6    	vpsubd %ymm22,%ymm6,%ymm6
     1a9:	62 b1 6d 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm2{%k2}
     1b0:	62 d3 45 28 1f d7 01 	vpcmpltd %ymm15,%ymm7,%k2
     1b7:	c4 c1 2d fe c1       	vpaddd %ymm9,%ymm10,%ymm0
     1bc:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     1c0:	62 72 7d 2d 90 34 92 	vpgatherdd (%rdx,%ymm2,4),%ymm14{%k5}
     1c7:	62 92 55 2b 64 d4    	vpblendmd %ymm28,%ymm5,%ymm2{%k3}
     1cd:	c5 f9 90 e9          	kmovb  %k1,%k5
     1d1:	62 b1 6d 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm2{%k2}
     1d8:	c4 c1 0d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm14
     1de:	62 f1 25 20 fa d2    	vpsubd %ymm2,%ymm27,%ymm2
     1e4:	62 d3 35 28 1f da 06 	vpcmpnled %ymm10,%ymm9,%k3
     1eb:	62 71 8d 28 db f3    	vpandq %ymm3,%ymm14,%ymm14
     1f1:	62 f2 7d 2e 90 3c 92 	vpgatherdd (%rdx,%ymm2,4),%ymm7{%k6}
     1f8:	62 91 55 20 fa d5    	vpsubd %ymm29,%ymm21,%ymm2
     1fe:	c5 f9 90 f1          	kmovb  %k1,%k6
     202:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
     207:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     20b:	62 f1 c5 28 db fb    	vpandq %ymm3,%ymm7,%ymm7
     211:	c4 c1 45 fa f6       	vpsubd %ymm14,%ymm7,%ymm6
     216:	c4 41 0d fa f3       	vpsubd %ymm11,%ymm14,%ymm14
     21b:	62 12 55 2b 64 dc    	vpblendmd %ymm28,%ymm5,%ymm11{%k3}
     221:	62 32 0d 28 40 f6    	vpmulld %ymm22,%ymm14,%ymm14
     227:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
     22c:	c4 c2 2d 3d f1       	vpmaxsd %ymm9,%ymm10,%ymm6
     231:	62 d3 4d 28 1f d0 01 	vpcmpltd %ymm8,%ymm6,%k2
     238:	62 d3 35 28 1f da 01 	vpcmpltd %ymm10,%ymm9,%k3
     23f:	c5 95 fa ff          	vpsubd %ymm7,%ymm13,%ymm7
     243:	62 92 45 28 40 fd    	vpmulld %ymm29,%ymm7,%ymm7
     249:	c4 c2 4d 3d f0       	vpmaxsd %ymm8,%ymm6,%ymm6
     24e:	62 b1 25 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm11{%k2}
     255:	62 91 7d 2b 6f ec    	vmovdqa32 %ymm28,%ymm5{%k3}
     25b:	c4 41 0d fe f4       	vpaddd %ymm12,%ymm14,%ymm14
     260:	c4 42 2d 39 e1       	vpminsd %ymm9,%ymm10,%ymm12
     265:	62 d3 3d 28 1f d4 01 	vpcmpltd %ymm12,%ymm8,%k2
     26c:	c5 25 fe dc          	vpaddd %ymm4,%ymm11,%ymm11
     270:	62 b2 7d 2d 90 24 9a 	vpgatherdd (%rdx,%ymm11,4),%ymm4{%k5}
     277:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     27b:	c4 c2 1d 39 f8       	vpminsd %ymm8,%ymm12,%ymm7
     280:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     285:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
     289:	c5 fd fa c7          	vpsubd %ymm7,%ymm0,%ymm0
     28d:	62 b1 55 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm5{%k2}
     294:	62 f1 dd 28 db e3    	vpandq %ymm3,%ymm4,%ymm4
     29a:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     29f:	62 71 25 20 fa cd    	vpsubd %ymm5,%ymm27,%ymm9
     2a5:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
     2aa:	62 b2 7d 2e 90 2c 8a 	vpgatherdd (%rdx,%ymm9,4),%ymm5{%k6}
     2b1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     2b6:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     2bb:	62 e1 fd 28 6f ea    	vmovdqa64 %ymm2,%ymm21
     2c1:	62 f1 d5 28 db eb    	vpandq %ymm3,%ymm5,%ymm5
     2c7:	c5 55 fa c4          	vpsubd %ymm4,%ymm5,%ymm8
     2cb:	62 f1 2d 20 fa ed    	vpsubd %ymm5,%ymm26,%ymm5
     2d1:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     2d6:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     2db:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     2df:	62 b1 5d 28 fa e7    	vpsubd %ymm23,%ymm4,%ymm4
     2e5:	48 83 c0 60          	add    $0x60,%rax
     2e9:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
     2ee:	62 91 5d 28 fe e1    	vpaddd %ymm25,%ymm4,%ymm4
     2f4:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     2f8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2fd:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     301:	49 39 c1             	cmp    %rax,%r9
     304:	0f 84 a0 04 00 00    	je     7aa <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7aa>
     30a:	48 8b 50 08          	mov    0x8(%rax),%rdx
     30e:	62 31 7d 28 6f d5    	vmovdqa32 %ymm21,%ymm10
     314:	c5 f9 90 e1          	kmovb  %k1,%k4
     318:	44 8b 40 54          	mov    0x54(%rax),%r8d
     31c:	8b 48 50             	mov    0x50(%rax),%ecx
     31f:	c5 f9 90 e9          	kmovb  %k1,%k5
     323:	48 8b 78 10          	mov    0x10(%rax),%rdi
     327:	c5 f9 90 f1          	kmovb  %k1,%k6
     32b:	62 a2 7d 2c 90 2c 92 	vpgatherdd (%rdx,%ymm10,4),%ymm21{%k4}
     332:	48 8b 10             	mov    (%rax),%rdx
     335:	62 42 7d 28 7c e0    	vpbroadcastd %r8d,%ymm28
     33b:	62 11 7d 28 6f c8    	vmovdqa32 %ymm24,%ymm9
     341:	62 f2 7d 28 7c e9    	vpbroadcastd %ecx,%ymm5
     347:	62 b1 5d 28 72 d5 11 	vpsrld $0x11,%ymm21,%ymm4
     34e:	62 a2 7d 2e 90 34 87 	vpgatherdd (%rdi,%ymm8,4),%ymm22{%k6}
     355:	c5 f9 90 f9          	kmovb  %k1,%k7
     359:	62 b2 7d 25 90 14 82 	vpgatherdd (%rdx,%ymm24,4),%ymm2{%k5}
     360:	62 92 5d 28 40 e4    	vpmulld %ymm28,%ymm4,%ymm4
     366:	62 a1 d5 20 db e8    	vpandq %ymm16,%ymm21,%ymm21
     36c:	48 8b 50 48          	mov    0x48(%rax),%rdx
     370:	c5 fd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm0
     375:	62 b1 ed 28 db d0    	vpandq %ymm16,%ymm2,%ymm2
     37b:	41 8d 4c 08 01       	lea    0x1(%r8,%rcx,1),%ecx
     380:	c5 f9 90 e9          	kmovb  %k1,%k5
     384:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     389:	62 b1 75 28 72 d6 11 	vpsrld $0x11,%ymm22,%ymm1
     390:	62 62 55 20 39 fa    	vpminsd %ymm2,%ymm21,%ymm31
     396:	c5 f9 90 e1          	kmovb  %k1,%k4
     39a:	62 a1 cd 20 db f0    	vpandq %ymm16,%ymm22,%ymm22
     3a0:	62 b3 6d 28 1f dd 06 	vpcmpnled %ymm21,%ymm2,%k3
     3a7:	62 62 55 20 3d ea    	vpmaxsd %ymm2,%ymm21,%ymm29
     3ad:	c5 f9 90 f1          	kmovb  %k1,%k6
     3b1:	62 93 4d 20 1f d7 01 	vpcmpltd %ymm31,%ymm22,%k2
     3b8:	62 62 7d 28 7c d9    	vpbroadcastd %ecx,%ymm27
     3be:	62 22 05 20 39 fe    	vpminsd %ymm22,%ymm31,%ymm31
     3c4:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     3c8:	62 71 55 20 fe fa    	vpaddd %ymm2,%ymm21,%ymm15
     3ce:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
     3d2:	62 92 55 2b 64 c4    	vpblendmd %ymm28,%ymm5,%ymm0{%k3}
     3d8:	62 b3 6d 28 1f dd 01 	vpcmpltd %ymm21,%ymm2,%k3
     3df:	62 b1 7d 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm0{%k2}
     3e6:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     3ea:	62 93 4d 20 1f d5 06 	vpcmpnled %ymm29,%ymm22,%k2
     3f1:	62 61 25 20 fe dc    	vpaddd %ymm4,%ymm27,%ymm27
     3f7:	62 22 15 20 3d ee    	vpmaxsd %ymm22,%ymm29,%ymm29
     3fd:	62 f1 25 20 fa c0    	vpsubd %ymm0,%ymm27,%ymm0
     403:	62 62 7d 2f 90 04 a2 	vpgatherdd (%rdx,%ymm4,4),%ymm24{%k7}
     40a:	62 22 7d 24 90 14 9a 	vpgatherdd (%rdx,%ymm27,4),%ymm26{%k4}
     411:	62 f2 7d 2d 90 3c 82 	vpgatherdd (%rdx,%ymm0,4),%ymm7{%k5}
     418:	62 92 55 2b 64 c4    	vpblendmd %ymm28,%ymm5,%ymm0{%k3}
     41e:	62 01 05 20 fe f5    	vpaddd %ymm29,%ymm31,%ymm30
     424:	62 b1 7d 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm0{%k2}
     42b:	62 91 25 28 72 d0 08 	vpsrld $0x8,%ymm24,%ymm11
     432:	62 f1 c5 28 db cb    	vpandq %ymm3,%ymm7,%ymm1
     438:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     43c:	62 91 45 20 72 d0 10 	vpsrld $0x10,%ymm24,%ymm23
     443:	62 71 ad 20 db eb    	vpandq %ymm3,%ymm26,%ymm13
     449:	62 f2 7d 2e 90 34 82 	vpgatherdd (%rdx,%ymm0,4),%ymm6{%k6}
     450:	62 61 bd 20 db c3    	vpandq %ymm3,%ymm24,%ymm24
     456:	62 01 4d 20 fa f6    	vpsubd %ymm30,%ymm22,%ymm30
     45c:	62 f1 cd 28 db c3    	vpandq %ymm3,%ymm6,%ymm0
     462:	c5 15 fa e9          	vpsubd %ymm1,%ymm13,%ymm13
     466:	62 41 0d 20 fe f7    	vpaddd %ymm15,%ymm30,%ymm30
     46c:	c5 f5 fa c8          	vpsubd %ymm0,%ymm1,%ymm1
     470:	62 91 7d 28 fa c0    	vpsubd %ymm24,%ymm0,%ymm0
     476:	62 12 15 28 40 ef    	vpmulld %ymm31,%ymm13,%ymm13
     47c:	62 92 75 28 40 ce    	vpmulld %ymm30,%ymm1,%ymm1
     482:	62 92 7d 28 40 c5    	vpmulld %ymm29,%ymm0,%ymm0
     488:	62 71 a5 28 db db    	vpandq %ymm3,%ymm11,%ymm11
     48e:	62 91 0d 28 72 f0 10 	vpslld $0x10,%ymm24,%ymm14
     495:	c4 c1 1d 72 f3 10    	vpslld $0x10,%ymm11,%ymm12
     49b:	62 e1 c5 20 db fb    	vpandq %ymm3,%ymm23,%ymm23
     4a1:	62 31 0d 28 fe f2    	vpaddd %ymm18,%ymm14,%ymm14
     4a7:	62 b1 35 20 72 f7 10 	vpslld $0x10,%ymm23,%ymm25
     4ae:	62 31 1d 28 fe e2    	vpaddd %ymm18,%ymm12,%ymm12
     4b4:	62 21 35 20 fe ca    	vpaddd %ymm18,%ymm25,%ymm25
     4ba:	c4 c1 7d fe c5       	vpaddd %ymm13,%ymm0,%ymm0
     4bf:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     4c4:	62 91 15 28 72 d2 08 	vpsrld $0x8,%ymm26,%ymm13
     4cb:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     4cf:	62 91 2d 20 72 d2 10 	vpsrld $0x10,%ymm26,%ymm26
     4d6:	62 71 95 28 db eb    	vpandq %ymm3,%ymm13,%ymm13
     4dc:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     4e1:	62 61 ad 20 db d3    	vpandq %ymm3,%ymm26,%ymm26
     4e7:	62 61 fd 28 6f c1    	vmovdqa64 %ymm1,%ymm24
     4ed:	0f 85 0d 02 00 00    	jne    700 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x700>
     4f3:	48 8b 48 28          	mov    0x28(%rax),%rcx
     4f7:	c5 f9 90 f9          	kmovb  %k1,%k7
     4fb:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
     4ff:	c5 f9 90 e1          	kmovb  %k1,%k4
     503:	62 b2 7d 2f 90 3c 81 	vpgatherdd (%rcx,%ymm8,4),%ymm7{%k7}
     50a:	48 8b 48 20          	mov    0x20(%rax),%rcx
     50e:	c5 f9 90 f9          	kmovb  %k1,%k7
     512:	62 32 7d 2f 90 34 91 	vpgatherdd (%rcx,%ymm10,4),%ymm14{%k7}
     519:	48 8b 48 18          	mov    0x18(%rax),%rcx
     51d:	62 b2 7d 2c 90 34 89 	vpgatherdd (%rcx,%ymm9,4),%ymm6{%k4}
     524:	0f 85 e6 fb ff ff    	jne    110 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x110>
     52a:	62 31 8d 28 db f0    	vpandq %ymm16,%ymm14,%ymm14
     530:	62 b1 cd 28 db d0    	vpandq %ymm16,%ymm6,%ymm2
     536:	62 b1 c5 28 db c0    	vpandq %ymm16,%ymm7,%ymm0
     53c:	c5 f9 90 f9          	kmovb  %k1,%k7
     540:	62 f3 0d 28 1f da 06 	vpcmpnled %ymm2,%ymm14,%k3
     547:	c4 c2 6d 3d f6       	vpmaxsd %ymm14,%ymm2,%ymm6
     54c:	c4 42 6d 39 fe       	vpminsd %ymm14,%ymm2,%ymm15
     551:	c5 f9 90 e1          	kmovb  %k1,%k4
     555:	62 f3 4d 28 1f d0 01 	vpcmpltd %ymm0,%ymm6,%k2
     55c:	62 e2 05 28 39 f0    	vpminsd %ymm0,%ymm15,%ymm22
     562:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
     567:	48 8b 48 40          	mov    0x40(%rax),%rcx
     56b:	c5 f9 90 e9          	kmovb  %k1,%k5
     56f:	c5 f9 90 f1          	kmovb  %k1,%k6
     573:	62 82 55 2b 64 ec    	vpblendmd %ymm28,%ymm5,%ymm21{%k3}
     579:	62 f3 0d 28 1f da 01 	vpcmpltd %ymm2,%ymm14,%k3
     580:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
     585:	62 b1 55 22 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm21{%k2}
     58c:	62 d3 7d 28 1f d7 01 	vpcmpltd %ymm15,%ymm0,%k2
     593:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     597:	62 e1 55 20 fe ec    	vpaddd %ymm4,%ymm21,%ymm21
     59d:	62 b1 4d 28 fe c6    	vpaddd %ymm22,%ymm6,%ymm0
     5a3:	62 02 55 2b 64 ec    	vpblendmd %ymm28,%ymm5,%ymm29{%k3}
     5a9:	62 f2 7d 27 90 3c aa 	vpgatherdd (%rdx,%ymm21,4),%ymm7{%k7}
     5b0:	c5 ed fa d0          	vpsubd %ymm0,%ymm2,%ymm2
     5b4:	c5 f9 90 f9          	kmovb  %k1,%k7
     5b8:	62 b1 15 22 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm29{%k2}
     5bf:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
     5c4:	62 01 25 20 fa ed    	vpsubd %ymm29,%ymm27,%ymm29
     5ca:	62 f1 c5 28 db fb    	vpandq %ymm3,%ymm7,%ymm7
     5d0:	62 a2 7d 24 90 2c aa 	vpgatherdd (%rdx,%ymm29,4),%ymm21{%k4}
     5d7:	c5 f9 90 e1          	kmovb  %k1,%k4
     5db:	62 b1 55 20 72 d5 08 	vpsrld $0x8,%ymm21,%ymm21
     5e2:	62 e1 d5 20 db eb    	vpandq %ymm3,%ymm21,%ymm21
     5e8:	62 f1 55 20 fa c7    	vpsubd %ymm7,%ymm21,%ymm0
     5ee:	62 31 15 28 fa ed    	vpsubd %ymm21,%ymm13,%ymm13
     5f4:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     5f9:	62 32 15 28 40 ee    	vpmulld %ymm22,%ymm13,%ymm13
     5ff:	c4 c1 45 fa c3       	vpsubd %ymm11,%ymm7,%ymm0
     604:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     609:	c4 c1 6d fe d5       	vpaddd %ymm13,%ymm2,%ymm2
     60e:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
     613:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     617:	62 b2 7d 2d 90 04 81 	vpgatherdd (%rcx,%ymm8,4),%ymm0{%k5}
     61e:	48 8b 48 38          	mov    0x38(%rax),%rcx
     622:	c5 f9 90 e9          	kmovb  %k1,%k5
     626:	62 b1 fd 28 db c0    	vpandq %ymm16,%ymm0,%ymm0
     62c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     631:	62 b2 7d 2e 90 34 91 	vpgatherdd (%rcx,%ymm10,4),%ymm6{%k6}
     638:	48 8b 48 30          	mov    0x30(%rax),%rcx
     63c:	62 e1 fd 28 6f ea    	vmovdqa64 %ymm2,%ymm21
     642:	62 31 cd 28 db d0    	vpandq %ymm16,%ymm6,%ymm10
     648:	62 b2 7d 2f 90 34 89 	vpgatherdd (%rcx,%ymm9,4),%ymm6{%k7}
     64f:	62 31 cd 28 db c8    	vpandq %ymm16,%ymm6,%ymm9
     655:	62 d3 2d 28 1f d9 06 	vpcmpnled %ymm9,%ymm10,%k3
     65c:	c4 c2 35 3d f2       	vpmaxsd %ymm10,%ymm9,%ymm6
     661:	c4 42 35 39 da       	vpminsd %ymm10,%ymm9,%ymm11
     666:	62 f3 4d 28 1f d0 01 	vpcmpltd %ymm0,%ymm6,%k2
     66d:	c4 62 25 39 c0       	vpminsd %ymm0,%ymm11,%ymm8
     672:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
     677:	62 92 55 2b 64 fc    	vpblendmd %ymm28,%ymm5,%ymm7{%k3}
     67d:	62 d3 2d 28 1f d9 01 	vpcmpltd %ymm9,%ymm10,%k3
     684:	62 b1 45 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm7{%k2}
     68b:	62 d3 7d 28 1f d3 01 	vpcmpltd %ymm11,%ymm0,%k2
     692:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     696:	62 91 7d 2b 6f ec    	vmovdqa32 %ymm28,%ymm5{%k3}
     69c:	62 f2 7d 2c 90 24 ba 	vpgatherdd (%rdx,%ymm7,4),%ymm4{%k4}
     6a3:	62 b1 55 2a 72 d1 1f 	vpsrld $0x1f,%ymm17,%ymm5{%k2}
     6aa:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     6af:	62 61 25 20 fa dd    	vpsubd %ymm5,%ymm27,%ymm27
     6b5:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
     6ba:	62 f1 dd 28 db e3    	vpandq %ymm3,%ymm4,%ymm4
     6c0:	62 b2 7d 25 90 3c 9a 	vpgatherdd (%rdx,%ymm27,4),%ymm7{%k5}
     6c7:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
     6cb:	c4 c1 35 fe ea       	vpaddd %ymm10,%ymm9,%ymm5
     6d0:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     6d5:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     6d9:	62 f1 c5 28 db fb    	vpandq %ymm3,%ymm7,%ymm7
     6df:	c5 c5 fa ec          	vpsubd %ymm4,%ymm7,%ymm5
     6e3:	62 61 2d 20 fa d7    	vpsubd %ymm7,%ymm26,%ymm26
     6e9:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     6ee:	62 42 2d 20 40 d0    	vpmulld %ymm8,%ymm26,%ymm26
     6f4:	62 91 7d 28 fe c2    	vpaddd %ymm26,%ymm0,%ymm0
     6fa:	e9 e0 fb ff ff       	jmp    2df <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2df>
     6ff:	90                   	nop
     700:	c5 fd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm0
     705:	c5 ed 72 d7 08       	vpsrld $0x8,%ymm7,%ymm2
     70a:	48 83 c0 60          	add    $0x60,%rax
     70e:	62 f1 ed 28 db d3    	vpandq %ymm3,%ymm2,%ymm2
     714:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     719:	62 f1 fd 28 db c3    	vpandq %ymm3,%ymm0,%ymm0
     71f:	c5 15 fa ea          	vpsubd %ymm2,%ymm13,%ymm13
     723:	c5 ed fa d0          	vpsubd %ymm0,%ymm2,%ymm2
     727:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     72c:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     731:	62 92 6d 28 40 d6    	vpmulld %ymm30,%ymm2,%ymm2
     737:	62 f1 c5 28 db fb    	vpandq %ymm3,%ymm7,%ymm7
     73d:	62 12 15 28 40 ef    	vpmulld %ymm31,%ymm13,%ymm13
     743:	62 92 7d 28 40 c5    	vpmulld %ymm29,%ymm0,%ymm0
     749:	62 f1 cd 28 db f3    	vpandq %ymm3,%ymm6,%ymm6
     74f:	c5 15 fe ea          	vpaddd %ymm2,%ymm13,%ymm13
     753:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
     758:	c5 15 fe e8          	vpaddd %ymm0,%ymm13,%ymm13
     75c:	62 f1 2d 20 fa c7    	vpsubd %ymm7,%ymm26,%ymm0
     762:	62 92 7d 28 40 c7    	vpmulld %ymm31,%ymm0,%ymm0
     768:	c4 c1 6d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm2
     76e:	c5 c5 fa fe          	vpsubd %ymm6,%ymm7,%ymm7
     772:	62 b1 4d 28 fa f7    	vpsubd %ymm23,%ymm6,%ymm6
     778:	62 92 45 28 40 fe    	vpmulld %ymm30,%ymm7,%ymm7
     77e:	62 e1 fd 28 6f ea    	vmovdqa64 %ymm2,%ymm21
     784:	62 92 4d 28 40 f5    	vpmulld %ymm29,%ymm6,%ymm6
     78a:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     78e:	62 91 4d 28 fe f1    	vpaddd %ymm25,%ymm6,%ymm6
     794:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     798:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     79d:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     7a1:	49 39 c1             	cmp    %rax,%r9
     7a4:	0f 85 60 fb ff ff    	jne    30a <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x30a>
     7aa:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     7af:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
     7b4:	48 83 c3 18          	add    $0x18,%rbx
     7b8:	62 f3 ed 28 25 c8 fe 	vpternlogq $0xfe,%ymm0,%ymm2,%ymm1
     7bf:	62 b2 75 28 00 cb    	vpshufb %ymm19,%ymm1,%ymm1
     7c5:	c5 f9 6f d1          	vmovdqa %xmm1,%xmm2
     7c9:	62 f3 fd 28 39 c9 01 	vextracti64x2 $0x1,%ymm1,%xmm1
     7d0:	c5 f9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm0
     7d5:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     7da:	62 f1 fd 08 eb c2    	vporq  %xmm2,%xmm0,%xmm0
     7e0:	c5 f9 d6 4b f8       	vmovq  %xmm1,-0x8(%rbx)
     7e5:	c5 fa 7f 43 e8       	vmovdqu %xmm0,-0x18(%rbx)
     7ea:	48 39 de             	cmp    %rbx,%rsi
     7ed:	0f 85 cd f8 ff ff    	jne    c0 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc0>
     7f3:	c5 f8 77             	vzeroupper
     7f6:	c5 f8 28 34 24       	vmovaps (%rsp),%xmm6
     7fb:	c5 f8 28 7c 24 10    	vmovaps 0x10(%rsp),%xmm7
     801:	c5 78 28 44 24 20    	vmovaps 0x20(%rsp),%xmm8
     807:	c5 78 28 4c 24 30    	vmovaps 0x30(%rsp),%xmm9
     80d:	c5 78 28 54 24 40    	vmovaps 0x40(%rsp),%xmm10
     813:	c5 78 28 5c 24 50    	vmovaps 0x50(%rsp),%xmm11
     819:	c5 78 28 64 24 60    	vmovaps 0x60(%rsp),%xmm12
     81f:	c5 78 28 6c 24 70    	vmovaps 0x70(%rsp),%xmm13
     825:	c5 78 28 b4 24 80 00 	vmovaps 0x80(%rsp),%xmm14
     82c:	00 00 
     82e:	c5 78 28 bc 24 90 00 	vmovaps 0x90(%rsp),%xmm15
     835:	00 00 
     837:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
     83e:	5b                   	pop    %rbx
     83f:	5e                   	pop    %rsi
     840:	5f                   	pop    %rdi
     841:	c3                   	ret
     842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     848:	62 b1 7d 28 6f d5    	vmovdqa32 %ymm21,%ymm2
     84e:	e9 57 ff ff ff       	jmp    7aa <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7aa>
     853:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     857:	0f 85 01 f8 ff ff    	jne    5e <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5e>
     85d:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     864:	0f 84 f4 f7 ff ff    	je     5e <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5e>
     86a:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     871:	0f 84 e7 f7 ff ff    	je     5e <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5e>
     877:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     87e:	0f 84 da f7 ff ff    	je     5e <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5e>
     884:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     888:	0f 85 9d 0b 00 00    	jne    142b <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x142b>
     88e:	4d 85 c9             	test   %r9,%r9
     891:	0f 84 5f ff ff ff    	je     7f6 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f6>
     897:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     89b:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
     89f:	62 e1 fd 28 6f 25 00 	vmovdqa64 0x0(%rip),%ymm20        # 8a9 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8a9>
     8a6:	00 00 00 
     8a9:	62 e1 fd 28 6f 1d 20 	vmovdqa64 0x20(%rip),%ymm19        # 8d3 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8d3>
     8b0:	00 00 00 
     8b3:	c5 fd 72 d4 18       	vpsrld $0x18,%ymm4,%ymm0
     8b8:	48 c1 e8 03          	shr    $0x3,%rax
     8bc:	c5 ed 72 d4 0f       	vpsrld $0xf,%ymm4,%ymm2
     8c1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
     8c5:	49 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%rcx
     8ca:	b8 00 80 00 00       	mov    $0x8000,%eax
     8cf:	62 f2 7d 28 7c d8    	vpbroadcastd %eax,%ymm3
     8d5:	c5 7a 6f 0b          	vmovdqu (%rbx),%xmm9
     8d9:	c5 fa 7e 6b 10       	vmovq  0x10(%rbx),%xmm5
     8de:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     8e2:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     8e6:	49 8b 02             	mov    (%r10),%rax
     8e9:	41 8b 52 54          	mov    0x54(%r10),%edx
     8ed:	48 83 c3 18          	add    $0x18,%rbx
     8f1:	c4 c3 51 0f e9 0c    	vpalignr $0xc,%xmm9,%xmm5,%xmm5
     8f7:	49 8b 72 48          	mov    0x48(%r10),%rsi
     8fb:	62 73 b5 28 38 cd 01 	vinserti64x2 $0x1,%xmm5,%ymm9,%ymm9
     902:	62 72 7d 28 7c ea    	vpbroadcastd %edx,%ymm13
     908:	62 32 35 28 00 cc    	vpshufb %ymm20,%ymm9,%ymm9
     90e:	c4 c1 0d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm14
     914:	c4 c1 05 72 d1 08    	vpsrld $0x8,%ymm9,%ymm15
     91a:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
     920:	62 b2 7d 2f 90 3c 88 	vpgatherdd (%rax,%ymm9,4),%ymm7{%k7}
     927:	49 8b 42 08          	mov    0x8(%r10),%rax
     92b:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
     931:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     935:	c5 d5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm5
     93a:	62 f1 c5 28 db fa    	vpandq %ymm2,%ymm7,%ymm7
     940:	62 a2 7d 2e 90 04 b8 	vpgatherdd (%rax,%ymm15,4),%ymm16{%k6}
     947:	49 8b 42 10          	mov    0x10(%r10),%rax
     94b:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     94f:	62 b1 2d 28 72 d0 11 	vpsrld $0x11,%ymm16,%ymm10
     956:	62 e1 fd 20 db c2    	vpandq %ymm2,%ymm16,%ymm16
     95c:	62 b2 7d 2f 90 0c b0 	vpgatherdd (%rax,%ymm14,4),%ymm1{%k7}
     963:	41 8b 42 50          	mov    0x50(%r10),%eax
     967:	c4 42 2d 40 d5       	vpmulld %ymm13,%ymm10,%ymm10
     96c:	62 a2 45 28 3d c8    	vpmaxsd %ymm16,%ymm7,%ymm17
     972:	62 f3 7d 20 1f df 06 	vpcmpnled %ymm7,%ymm16,%k3
     979:	c5 bd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm8
     97e:	62 f1 f5 28 db ca    	vpandq %ymm2,%ymm1,%ymm1
     984:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     988:	62 f2 7d 28 7c f0    	vpbroadcastd %eax,%ymm6
     98e:	62 f3 75 20 1f d1 01 	vpcmpltd %ymm1,%ymm17,%k2
     995:	62 a2 45 28 39 f0    	vpminsd %ymm16,%ymm7,%ymm22
     99b:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
     9a0:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
     9a4:	62 e2 4d 20 39 e9    	vpminsd %ymm1,%ymm22,%ymm21
     9aa:	62 c2 4d 2b 64 d5    	vpblendmd %ymm13,%ymm6,%ymm18{%k3}
     9b0:	62 f3 7d 20 1f df 01 	vpcmpltd %ymm7,%ymm16,%k3
     9b7:	62 72 7d 28 7c d8    	vpbroadcastd %eax,%ymm11
     9bd:	49 8b 42 28          	mov    0x28(%r10),%rax
     9c1:	62 f1 6d 22 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm18{%k2}
     9c8:	62 b3 75 28 1f d6 01 	vpcmpltd %ymm22,%ymm1,%k2
     9cf:	62 e2 75 20 3d c9    	vpmaxsd %ymm1,%ymm17,%ymm17
     9d5:	62 21 75 20 fe c5    	vpaddd %ymm21,%ymm17,%ymm24
     9db:	62 b1 45 28 fe f8    	vpaddd %ymm16,%ymm7,%ymm7
     9e1:	62 91 75 28 fa c8    	vpsubd %ymm24,%ymm1,%ymm1
     9e7:	c5 2d fe d5          	vpaddd %ymm5,%ymm10,%ymm10
     9eb:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     9ef:	c4 41 2d fe d0       	vpaddd %ymm8,%ymm10,%ymm10
     9f4:	62 c1 6d 20 fe d2    	vpaddd %ymm10,%ymm18,%ymm18
     9fa:	62 32 7d 2e 90 24 96 	vpgatherdd (%rsi,%ymm10,4),%ymm12{%k6}
     a01:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     a05:	c4 41 25 fe da       	vpaddd %ymm10,%ymm11,%ymm11
     a0a:	62 72 7d 26 90 04 96 	vpgatherdd (%rsi,%ymm18,4),%ymm8{%k6}
     a11:	62 c2 4d 2b 64 d5    	vpblendmd %ymm13,%ymm6,%ymm18{%k3}
     a17:	62 b2 7d 2f 90 2c 9e 	vpgatherdd (%rsi,%ymm11,4),%ymm5{%k7}
     a1e:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     a22:	62 f1 6d 22 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm18{%k2}
     a29:	62 71 bd 28 db c0    	vpandq %ymm0,%ymm8,%ymm8
     a2f:	62 e1 9d 28 db f0    	vpandq %ymm0,%ymm12,%ymm22
     a35:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     a39:	62 a1 25 28 fa d2    	vpsubd %ymm18,%ymm11,%ymm18
     a3f:	62 d1 3d 20 72 d4 08 	vpsrld $0x8,%ymm12,%ymm24
     a46:	62 e2 7d 27 90 3c 96 	vpgatherdd (%rsi,%ymm18,4),%ymm23{%k7}
     a4d:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     a51:	62 61 bd 20 db c0    	vpandq %ymm0,%ymm24,%ymm24
     a57:	62 e1 c5 20 db d0    	vpandq %ymm0,%ymm23,%ymm18
     a5d:	62 b1 45 20 72 f6 10 	vpslld $0x10,%ymm22,%ymm23
     a64:	62 d1 6d 20 fa f8    	vpsubd %ymm8,%ymm18,%ymm7
     a6a:	62 31 3d 28 fa c6    	vpsubd %ymm22,%ymm8,%ymm8
     a70:	62 91 2d 20 72 f0 10 	vpslld $0x10,%ymm24,%ymm26
     a77:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     a7c:	62 32 3d 28 40 c1    	vpmulld %ymm17,%ymm8,%ymm8
     a82:	62 f1 45 20 fe fb    	vpaddd %ymm3,%ymm23,%ymm7
     a88:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     a8c:	62 f1 d5 28 db f8    	vpandq %ymm0,%ymm5,%ymm7
     a92:	62 b1 45 28 fa fa    	vpsubd %ymm18,%ymm7,%ymm7
     a98:	62 b2 45 28 40 fd    	vpmulld %ymm21,%ymm7,%ymm7
     a9e:	c4 c1 45 fe f8       	vpaddd %ymm8,%ymm7,%ymm7
     aa3:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     aa7:	c5 c5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm7
     aac:	62 b2 7d 2e 90 0c b0 	vpgatherdd (%rax,%ymm14,4),%ymm1{%k6}
     ab3:	49 8b 42 20          	mov    0x20(%r10),%rax
     ab7:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     abb:	62 f1 f5 28 db ca    	vpandq %ymm2,%ymm1,%ymm1
     ac1:	62 a2 7d 2f 90 2c b8 	vpgatherdd (%rax,%ymm15,4),%ymm21{%k7}
     ac8:	49 8b 42 18          	mov    0x18(%r10),%rax
     acc:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     ad0:	62 e1 d5 20 db ea    	vpandq %ymm2,%ymm21,%ymm21
     ad6:	62 a2 7d 2e 90 04 88 	vpgatherdd (%rax,%ymm9,4),%ymm16{%k6}
     add:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     ae1:	49 8b 42 40          	mov    0x40(%r10),%rax
     ae5:	62 e1 fd 20 db ca    	vpandq %ymm2,%ymm16,%ymm17
     aeb:	62 b3 55 20 1f d9 06 	vpcmpnled %ymm17,%ymm21,%k3
     af2:	62 a2 75 20 3d fd    	vpmaxsd %ymm21,%ymm17,%ymm23
     af8:	62 a2 75 20 39 d5    	vpminsd %ymm21,%ymm17,%ymm18
     afe:	62 f3 45 20 1f d1 01 	vpcmpltd %ymm1,%ymm23,%k2
     b05:	62 62 6d 20 39 c9    	vpminsd %ymm1,%ymm18,%ymm25
     b0b:	62 e2 45 20 3d f9    	vpmaxsd %ymm1,%ymm23,%ymm23
     b11:	62 52 4d 2b 64 c5    	vpblendmd %ymm13,%ymm6,%ymm8{%k3}
     b17:	62 b3 55 20 1f d9 01 	vpcmpltd %ymm17,%ymm21,%k3
     b1e:	62 f1 3d 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm8{%k2}
     b25:	62 b3 75 28 1f d2 01 	vpcmpltd %ymm18,%ymm1,%k2
     b2c:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     b31:	62 a2 7d 2f 90 04 86 	vpgatherdd (%rsi,%ymm8,4),%ymm16{%k7}
     b38:	62 52 4d 2b 64 c5    	vpblendmd %ymm13,%ymm6,%ymm8{%k3}
     b3e:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     b42:	62 f1 3d 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm8{%k2}
     b49:	62 b1 7d 20 72 d0 08 	vpsrld $0x8,%ymm16,%ymm16
     b50:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
     b55:	62 e1 fd 20 db d0    	vpandq %ymm0,%ymm16,%ymm18
     b5b:	62 81 45 20 fe c1    	vpaddd %ymm25,%ymm23,%ymm16
     b61:	62 a2 7d 2e 90 34 86 	vpgatherdd (%rsi,%ymm8,4),%ymm22{%k6}
     b68:	c5 bd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm8
     b6d:	62 b1 75 28 fa c8    	vpsubd %ymm16,%ymm1,%ymm1
     b73:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     b77:	62 b1 4d 20 72 d6 08 	vpsrld $0x8,%ymm22,%ymm22
     b7e:	62 a1 75 20 fe c5    	vpaddd %ymm21,%ymm17,%ymm16
     b84:	62 71 bd 28 db c0    	vpandq %ymm0,%ymm8,%ymm8
     b8a:	62 e1 cd 20 db f0    	vpandq %ymm0,%ymm22,%ymm22
     b90:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     b95:	62 b1 75 28 fe c8    	vpaddd %ymm16,%ymm1,%ymm1
     b9b:	62 a1 4d 20 fa c2    	vpsubd %ymm18,%ymm22,%ymm16
     ba1:	62 31 3d 28 fa c6    	vpsubd %ymm22,%ymm8,%ymm8
     ba7:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
     bad:	62 b2 75 28 40 c8    	vpmulld %ymm16,%ymm1,%ymm1
     bb3:	62 12 3d 28 40 c1    	vpmulld %ymm25,%ymm8,%ymm8
     bb9:	62 e1 2d 20 fe c3    	vpaddd %ymm3,%ymm26,%ymm16
     bbf:	62 b1 75 28 fe c8    	vpaddd %ymm16,%ymm1,%ymm1
     bc5:	62 81 6d 20 fa c0    	vpsubd %ymm24,%ymm18,%ymm16
     bcb:	62 a2 7d 20 40 c7    	vpmulld %ymm23,%ymm16,%ymm16
     bd1:	62 31 3d 28 fe c0    	vpaddd %ymm16,%ymm8,%ymm8
     bd7:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
     bdc:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
     be1:	62 b2 7d 2f 90 0c b0 	vpgatherdd (%rax,%ymm14,4),%ymm1{%k7}
     be8:	49 8b 42 38          	mov    0x38(%r10),%rax
     bec:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     bf0:	62 f1 f5 28 db ca    	vpandq %ymm2,%ymm1,%ymm1
     bf6:	62 a2 7d 2e 90 0c b8 	vpgatherdd (%rax,%ymm15,4),%ymm17{%k6}
     bfd:	49 8b 42 30          	mov    0x30(%r10),%rax
     c01:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     c05:	62 e1 f5 20 db ca    	vpandq %ymm2,%ymm17,%ymm17
     c0b:	62 a2 7d 2f 90 04 88 	vpgatherdd (%rax,%ymm9,4),%ymm16{%k7}
     c12:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     c16:	49 8b 42 60          	mov    0x60(%r10),%rax
     c1a:	62 e1 fd 20 db c2    	vpandq %ymm2,%ymm16,%ymm16
     c20:	62 b3 75 20 1f d8 06 	vpcmpnled %ymm16,%ymm17,%k3
     c27:	62 32 7d 20 3d f1    	vpmaxsd %ymm17,%ymm16,%ymm14
     c2d:	62 a2 7d 20 39 d1    	vpminsd %ymm17,%ymm16,%ymm18
     c33:	62 f3 0d 28 1f d1 01 	vpcmpltd %ymm1,%ymm14,%k2
     c3a:	62 72 6d 20 39 f9    	vpminsd %ymm1,%ymm18,%ymm15
     c40:	c4 62 0d 3d f1       	vpmaxsd %ymm1,%ymm14,%ymm14
     c45:	62 52 4d 2b 64 cd    	vpblendmd %ymm13,%ymm6,%ymm9{%k3}
     c4b:	62 b3 75 20 1f d8 01 	vpcmpltd %ymm16,%ymm17,%k3
     c52:	62 f1 35 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm9{%k2}
     c59:	62 b3 75 28 1f d2 01 	vpcmpltd %ymm18,%ymm1,%k2
     c60:	c4 41 35 fe d2       	vpaddd %ymm10,%ymm9,%ymm10
     c65:	62 d1 7d 2b 6f f5    	vmovdqa32 %ymm13,%ymm6{%k3}
     c6b:	62 32 7d 2e 90 0c 96 	vpgatherdd (%rsi,%ymm10,4),%ymm9{%k6}
     c72:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     c76:	62 f1 4d 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm6{%k2}
     c7d:	c4 c1 2d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm10
     c83:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
     c87:	62 71 ad 28 db d0    	vpandq %ymm0,%ymm10,%ymm10
     c8d:	62 72 7d 2f 90 1c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm11{%k7}
     c94:	c4 c1 4d 72 d1 10    	vpsrld $0x10,%ymm9,%ymm6
     c9a:	c4 41 0d fe cf       	vpaddd %ymm15,%ymm14,%ymm9
     c9f:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     ca3:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
     ca9:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
     caf:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     cb4:	62 71 a5 28 db d8    	vpandq %ymm0,%ymm11,%ymm11
     cba:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
     cc0:	62 31 7d 20 fe c9    	vpaddd %ymm17,%ymm16,%ymm9
     cc6:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
     ccb:	c5 25 fa ce          	vpsubd %ymm6,%ymm11,%ymm9
     ccf:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     cd4:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     cd9:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     cde:	c4 c2 4d 40 f6       	vpmulld %ymm14,%ymm6,%ymm6
     ce3:	c4 c2 55 40 ef       	vpmulld %ymm15,%ymm5,%ymm5
     ce8:	c5 1d fe cb          	vpaddd %ymm3,%ymm12,%ymm9
     cec:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
     cf1:	62 72 7d 2e 90 0c b8 	vpgatherdd (%rax,%ymm7,4),%ymm9{%k6}
     cf8:	49 8b 42 68          	mov    0x68(%r10),%rax
     cfc:	41 8b 92 b4 00 00 00 	mov    0xb4(%r10),%edx
     d03:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     d07:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     d0b:	49 8b b2 a8 00 00 00 	mov    0xa8(%r10),%rsi
     d12:	62 b2 7d 2f 90 34 80 	vpgatherdd (%rax,%ymm8,4),%ymm6{%k7}
     d19:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     d1d:	49 8b 42 70          	mov    0x70(%r10),%rax
     d21:	62 e2 7d 28 7c ca    	vpbroadcastd %edx,%ymm17
     d27:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     d2c:	c5 d5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm5
     d31:	62 71 cd 28 db c2    	vpandq %ymm2,%ymm6,%ymm8
     d37:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     d3b:	62 72 7d 2e 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k6}
     d42:	41 8b 82 b0 00 00 00 	mov    0xb0(%r10),%eax
     d49:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
     d4f:	62 71 b5 28 db ca    	vpandq %ymm2,%ymm9,%ymm9
     d55:	62 b2 55 28 40 e9    	vpmulld %ymm17,%ymm5,%ymm5
     d5b:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
     d62:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
     d67:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     d6b:	62 e2 7d 28 7c c0    	vpbroadcastd %eax,%ymm16
     d71:	c4 c1 45 72 d6 11    	vpsrld $0x11,%ymm14,%ymm7
     d77:	62 71 8d 28 db f2    	vpandq %ymm2,%ymm14,%ymm14
     d7d:	62 b2 75 28 40 c8    	vpmulld %ymm16,%ymm1,%ymm1
     d83:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
     d8a:	62 c2 35 28 39 d0    	vpminsd %ymm8,%ymm9,%ymm18
     d90:	62 32 7d 23 64 f9    	vpblendmd %ymm17,%ymm16,%ymm15{%k3}
     d96:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
     d9d:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
     da1:	41 8b 92 14 01 00 00 	mov    0x114(%r10),%edx
     da8:	62 52 6d 20 39 e6    	vpminsd %ymm14,%ymm18,%ymm12
     dae:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
     db3:	62 f1 05 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm15{%k2}
     dba:	62 b3 0d 28 1f d2 01 	vpcmpltd %ymm18,%ymm14,%k2
     dc1:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
     dc6:	c4 41 35 fe e8       	vpaddd %ymm8,%ymm9,%ymm13
     dcb:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
     dd0:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
     dd4:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     dd9:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     ddd:	62 f2 7d 28 7c f8    	vpbroadcastd %eax,%ymm7
     de3:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
     dea:	62 f2 7d 2f 90 34 ae 	vpgatherdd (%rsi,%ymm5,4),%ymm6{%k7}
     df1:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
     df5:	c5 05 fe fd          	vpaddd %ymm5,%ymm15,%ymm15
     df9:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     dfd:	62 b2 7d 23 64 e9    	vpblendmd %ymm17,%ymm16,%ymm5{%k3}
     e03:	62 f2 7d 2e 90 0c be 	vpgatherdd (%rsi,%ymm7,4),%ymm1{%k6}
     e0a:	62 32 7d 2f 90 2c be 	vpgatherdd (%rsi,%ymm15,4),%ymm13{%k7}
     e11:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     e15:	62 f1 55 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm5{%k2}
     e1c:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
     e22:	62 71 cd 28 db c8    	vpandq %ymm0,%ymm6,%ymm9
     e28:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     e2c:	c5 c5 fa fd          	vpsubd %ymm5,%ymm7,%ymm7
     e30:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
     e36:	62 e2 7d 28 7c ca    	vpbroadcastd %edx,%ymm17
     e3c:	62 f2 7d 2e 90 2c be 	vpgatherdd (%rsi,%ymm7,4),%ymm5{%k6}
     e43:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
     e49:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
     e4e:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     e52:	62 f1 d5 28 db f8    	vpandq %ymm0,%ymm5,%ymm7
     e58:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
     e5d:	49 8b b2 08 01 00 00 	mov    0x108(%r10),%rsi
     e64:	c5 3d fa c7          	vpsubd %ymm7,%ymm8,%ymm8
     e68:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
     e6d:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
     e73:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
     e78:	c4 c2 45 40 fa       	vpmulld %ymm10,%ymm7,%ymm7
     e7d:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
     e83:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     e88:	c5 0d fe cb          	vpaddd %ymm3,%ymm14,%ymm9
     e8c:	c5 8d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm14
     e91:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     e96:	c5 b5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm9
     e9b:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
     ea1:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
     ea5:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     eaa:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
     eb0:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
     eb7:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
     ebd:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
     ec2:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
     ec7:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     ecc:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     ed1:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     ed6:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
     edb:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
     ee1:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
     ee6:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     eeb:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ef0:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     ef6:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
     efc:	62 f1 f5 28 db c8    	vpandq %ymm0,%ymm1,%ymm1
     f02:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     f06:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     f0b:	62 71 7d 20 fe f3    	vpaddd %ymm3,%ymm16,%ymm14
     f11:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     f16:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
     f1b:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     f20:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
     f26:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
     f2b:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     f30:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
     f36:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
     f3a:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
     f3f:	62 32 7d 2f 90 0c 80 	vpgatherdd (%rax,%ymm8,4),%ymm9{%k7}
     f46:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
     f4d:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
     f52:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     f57:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     f5b:	62 72 7d 2e 90 04 b8 	vpgatherdd (%rax,%ymm7,4),%ymm8{%k6}
     f62:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
     f69:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
     f6d:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     f71:	c5 95 fe f3          	vpaddd %ymm3,%ymm13,%ymm6
     f75:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     f79:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     f7d:	c4 c1 55 72 d0 11    	vpsrld $0x11,%ymm8,%ymm5
     f83:	62 71 bd 28 db c2    	vpandq %ymm2,%ymm8,%ymm8
     f89:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     f8e:	62 b2 55 28 40 e9    	vpmulld %ymm17,%ymm5,%ymm5
     f94:	62 72 7d 2f 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k7}
     f9b:	41 8b 82 10 01 00 00 	mov    0x110(%r10),%eax
     fa2:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
     fa8:	62 71 b5 28 db ca    	vpandq %ymm2,%ymm9,%ymm9
     fae:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
     fb5:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
     fba:	62 c2 35 28 39 d0    	vpminsd %ymm8,%ymm9,%ymm18
     fc0:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
     fc4:	62 e2 7d 28 7c c0    	vpbroadcastd %eax,%ymm16
     fca:	c4 c1 4d 72 d6 11    	vpsrld $0x11,%ymm14,%ymm6
     fd0:	62 71 8d 28 db f2    	vpandq %ymm2,%ymm14,%ymm14
     fd6:	62 b2 75 28 40 c8    	vpmulld %ymm16,%ymm1,%ymm1
     fdc:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
     fe3:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
     fe7:	41 8b 92 74 01 00 00 	mov    0x174(%r10),%edx
     fee:	62 32 7d 23 64 f9    	vpblendmd %ymm17,%ymm16,%ymm15{%k3}
     ff4:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
     ffb:	62 f2 7d 28 7c f8    	vpbroadcastd %eax,%ymm7
    1001:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    1008:	62 52 6d 20 39 e6    	vpminsd %ymm14,%ymm18,%ymm12
    100e:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
    1013:	62 f1 05 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm15{%k2}
    101a:	62 b3 0d 28 1f d2 01 	vpcmpltd %ymm18,%ymm14,%k2
    1021:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
    1026:	c4 41 35 fe e8       	vpaddd %ymm8,%ymm9,%ymm13
    102b:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
    1030:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    1034:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    1039:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    103d:	62 f2 7d 2e 90 34 ae 	vpgatherdd (%rsi,%ymm5,4),%ymm6{%k6}
    1044:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
    1048:	c5 05 fe fd          	vpaddd %ymm5,%ymm15,%ymm15
    104c:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1050:	62 b2 7d 23 64 e9    	vpblendmd %ymm17,%ymm16,%ymm5{%k3}
    1056:	62 f2 7d 2f 90 0c be 	vpgatherdd (%rsi,%ymm7,4),%ymm1{%k7}
    105d:	62 32 7d 2e 90 2c be 	vpgatherdd (%rsi,%ymm15,4),%ymm13{%k6}
    1064:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1068:	62 f1 55 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm5{%k2}
    106f:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
    1075:	62 71 cd 28 db c8    	vpandq %ymm0,%ymm6,%ymm9
    107b:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    107f:	c5 c5 fa fd          	vpsubd %ymm5,%ymm7,%ymm7
    1083:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
    1089:	62 e2 7d 28 7c ca    	vpbroadcastd %edx,%ymm17
    108f:	62 f2 7d 2f 90 2c be 	vpgatherdd (%rsi,%ymm7,4),%ymm5{%k7}
    1096:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
    109c:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
    10a1:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    10a5:	62 f1 d5 28 db f8    	vpandq %ymm0,%ymm5,%ymm7
    10ab:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
    10b0:	c5 3d fa c7          	vpsubd %ymm7,%ymm8,%ymm8
    10b4:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
    10b9:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
    10bf:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    10c4:	c4 c2 45 40 fa       	vpmulld %ymm10,%ymm7,%ymm7
    10c9:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    10cf:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    10d4:	c5 0d fe cb          	vpaddd %ymm3,%ymm14,%ymm9
    10d8:	c5 8d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm14
    10dd:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    10e2:	c5 b5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm9
    10e7:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
    10ed:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    10f1:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
    10f6:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    10fc:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
    1103:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1109:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
    110e:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
    1113:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1118:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
    111d:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
    1122:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
    1127:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
    112d:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
    1132:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1137:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    113c:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1142:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
    1148:	62 f1 f5 28 db c8    	vpandq %ymm0,%ymm1,%ymm1
    114e:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1152:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    1157:	62 71 7d 20 fe f3    	vpaddd %ymm3,%ymm16,%ymm14
    115d:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1162:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1167:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    116c:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
    1172:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    1177:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    117c:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1182:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    1186:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    118b:	62 32 7d 2e 90 0c 80 	vpgatherdd (%rax,%ymm8,4),%ymm9{%k6}
    1192:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    1199:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    119e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    11a3:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    11a7:	62 72 7d 2f 90 04 b8 	vpgatherdd (%rax,%ymm7,4),%ymm8{%k7}
    11ae:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    11b5:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    11b9:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    11bd:	c5 95 fe f3          	vpaddd %ymm3,%ymm13,%ymm6
    11c1:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    11c5:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    11c9:	c4 c1 55 72 d0 11    	vpsrld $0x11,%ymm8,%ymm5
    11cf:	62 71 bd 28 db c2    	vpandq %ymm2,%ymm8,%ymm8
    11d5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    11da:	62 b2 55 28 40 e9    	vpmulld %ymm17,%ymm5,%ymm5
    11e0:	62 72 7d 2e 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k6}
    11e7:	41 8b 82 70 01 00 00 	mov    0x170(%r10),%eax
    11ee:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
    11f4:	62 71 b5 28 db ca    	vpandq %ymm2,%ymm9,%ymm9
    11fa:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
    1201:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
    1206:	62 c2 35 28 39 d0    	vpminsd %ymm8,%ymm9,%ymm18
    120c:	49 8b b2 68 01 00 00 	mov    0x168(%r10),%rsi
    1213:	62 e2 7d 28 7c c0    	vpbroadcastd %eax,%ymm16
    1219:	c4 c1 4d 72 d6 11    	vpsrld $0x11,%ymm14,%ymm6
    121f:	62 71 8d 28 db f2    	vpandq %ymm2,%ymm14,%ymm14
    1225:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1229:	62 b2 75 28 40 c8    	vpmulld %ymm16,%ymm1,%ymm1
    122f:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
    1236:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    123a:	62 32 7d 23 64 f9    	vpblendmd %ymm17,%ymm16,%ymm15{%k3}
    1240:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
    1247:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
    124c:	62 52 6d 20 39 e6    	vpminsd %ymm14,%ymm18,%ymm12
    1252:	c4 41 35 fe e8       	vpaddd %ymm8,%ymm9,%ymm13
    1257:	62 f1 05 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm15{%k2}
    125e:	62 b3 0d 28 1f d2 01 	vpcmpltd %ymm18,%ymm14,%k2
    1265:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
    126a:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
    126f:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    1273:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    1278:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    127c:	62 f2 7d 28 7c f0    	vpbroadcastd %eax,%ymm6
    1282:	62 f2 7d 2f 90 3c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm7{%k7}
    1289:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    128d:	c5 05 fe fd          	vpaddd %ymm5,%ymm15,%ymm15
    1291:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1295:	62 b2 7d 23 64 e9    	vpblendmd %ymm17,%ymm16,%ymm5{%k3}
    129b:	62 f2 7d 2e 90 0c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm1{%k6}
    12a2:	62 32 7d 2f 90 2c be 	vpgatherdd (%rsi,%ymm15,4),%ymm13{%k7}
    12a9:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    12ad:	62 f1 55 2a 72 d4 1f 	vpsrld $0x1f,%ymm4,%ymm5{%k2}
    12b4:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
    12ba:	62 71 c5 28 db c8    	vpandq %ymm0,%ymm7,%ymm9
    12c0:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    12c4:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
    12ca:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
    12d0:	62 f2 7d 2e 90 34 ae 	vpgatherdd (%rsi,%ymm5,4),%ymm6{%k6}
    12d7:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
    12dc:	62 f1 cd 28 db e8    	vpandq %ymm0,%ymm6,%ymm5
    12e2:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
    12e7:	c5 3d fa c5          	vpsubd %ymm5,%ymm8,%ymm8
    12eb:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    12f0:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
    12f6:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    12fb:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1300:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    1306:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    130b:	c5 0d fe cb          	vpaddd %ymm3,%ymm14,%ymm9
    130f:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    1314:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    1319:	c5 b5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm9
    131e:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
    1324:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    1328:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    132d:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1333:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
    133a:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
    1340:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
    1345:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
    134a:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    134f:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1354:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
    1359:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
    135e:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1364:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
    1369:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    136e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1373:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1379:	62 f1 fd 28 db f6    	vpandq %ymm6,%ymm0,%ymm6
    137f:	62 f1 fd 28 db c9    	vpandq %ymm1,%ymm0,%ymm1
    1385:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1389:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    138e:	62 71 7d 20 fe f3    	vpaddd %ymm3,%ymm16,%ymm14
    1394:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1399:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    139e:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    13a3:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
    13a9:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    13ae:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    13b3:	62 51 fd 28 db c9    	vpandq %ymm9,%ymm0,%ymm9
    13b9:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    13bd:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    13c2:	c5 d5 72 f5 08       	vpslld $0x8,%ymm5,%ymm5
    13c7:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    13cc:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    13d1:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    13d5:	c5 95 fe fb          	vpaddd %ymm3,%ymm13,%ymm7
    13d9:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    13dd:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    13e1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    13e6:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    13eb:	62 d3 f5 28 25 e8 fe 	vpternlogq $0xfe,%ymm8,%ymm1,%ymm5
    13f2:	62 b2 55 28 00 cb    	vpshufb %ymm19,%ymm5,%ymm1
    13f8:	c5 f9 6f f1          	vmovdqa %xmm1,%xmm6
    13fc:	62 f3 fd 28 39 c9 01 	vextracti64x2 $0x1,%ymm1,%xmm1
    1403:	c5 d1 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm5
    1408:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    140d:	62 f1 d5 08 eb ee    	vporq  %xmm6,%xmm5,%xmm5
    1413:	c5 f9 d6 4b f8       	vmovq  %xmm1,-0x8(%rbx)
    1418:	c5 fa 7f 6b e8       	vmovdqu %xmm5,-0x18(%rbx)
    141d:	48 39 d9             	cmp    %rbx,%rcx
    1420:	0f 85 af f4 ff ff    	jne    8d5 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8d5>
    1426:	e9 c8 f3 ff ff       	jmp    7f3 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f3>
    142b:	4d 85 c9             	test   %r9,%r9
    142e:	0f 84 c2 f3 ff ff    	je     7f6 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f6>
    1434:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    1438:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
    143c:	62 e1 fd 28 6f 25 00 	vmovdqa64 0x0(%rip),%ymm20        # 1446 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1446>
    1443:	00 00 00 
    1446:	62 e1 fd 28 6f 1d 20 	vmovdqa64 0x20(%rip),%ymm19        # 1470 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1470>
    144d:	00 00 00 
    1450:	c5 fd 72 d3 18       	vpsrld $0x18,%ymm3,%ymm0
    1455:	48 c1 e8 03          	shr    $0x3,%rax
    1459:	c5 dd 72 d3 0f       	vpsrld $0xf,%ymm3,%ymm4
    145e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    1462:	49 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%rcx
    1467:	b8 00 80 00 00       	mov    $0x8000,%eax
    146c:	62 f2 7d 28 7c d0    	vpbroadcastd %eax,%ymm2
    1472:	c5 fa 6f 0b          	vmovdqu (%rbx),%xmm1
    1476:	c5 fa 7e 6b 10       	vmovq  0x10(%rbx),%xmm5
    147b:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    147f:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1483:	49 8b 02             	mov    (%r10),%rax
    1486:	41 8b 52 54          	mov    0x54(%r10),%edx
    148a:	48 83 c3 18          	add    $0x18,%rbx
    148e:	c4 e3 51 0f e9 0c    	vpalignr $0xc,%xmm1,%xmm5,%xmm5
    1494:	49 8b 72 48          	mov    0x48(%r10),%rsi
    1498:	62 f3 f5 28 38 cd 01 	vinserti64x2 $0x1,%xmm5,%ymm1,%ymm1
    149f:	62 72 7d 28 7c f2    	vpbroadcastd %edx,%ymm14
    14a5:	62 b2 75 28 00 cc    	vpshufb %ymm20,%ymm1,%ymm1
    14ab:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
    14b0:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
    14b5:	62 f1 f5 28 db e8    	vpandq %ymm0,%ymm1,%ymm5
    14bb:	62 e2 7d 2e 90 0c a8 	vpgatherdd (%rax,%ymm5,4),%ymm17{%k6}
    14c2:	49 8b 42 08          	mov    0x8(%r10),%rax
    14c6:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    14cc:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    14d0:	62 b1 75 28 72 d1 11 	vpsrld $0x11,%ymm17,%ymm1
    14d7:	62 e1 f5 20 db cc    	vpandq %ymm4,%ymm17,%ymm17
    14dd:	62 e2 7d 2e 90 2c b8 	vpgatherdd (%rax,%ymm7,4),%ymm21{%k6}
    14e4:	49 8b 42 10          	mov    0x10(%r10),%rax
    14e8:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    14ec:	62 b1 15 28 72 d5 11 	vpsrld $0x11,%ymm21,%ymm13
    14f3:	62 e1 d5 20 db ec    	vpandq %ymm4,%ymm21,%ymm21
    14f9:	62 a2 7d 2e 90 34 80 	vpgatherdd (%rax,%ymm8,4),%ymm22{%k6}
    1500:	41 8b 42 50          	mov    0x50(%r10),%eax
    1504:	c4 42 15 40 ee       	vpmulld %ymm14,%ymm13,%ymm13
    1509:	62 a2 75 20 3d c5    	vpmaxsd %ymm21,%ymm17,%ymm16
    150f:	62 b1 4d 28 72 d6 11 	vpsrld $0x11,%ymm22,%ymm6
    1516:	62 b3 55 20 1f d9 06 	vpcmpnled %ymm17,%ymm21,%k3
    151d:	62 e1 cd 20 db f4    	vpandq %ymm4,%ymm22,%ymm22
    1523:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1527:	62 72 7d 28 7c d0    	vpbroadcastd %eax,%ymm10
    152d:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    1531:	62 32 75 20 39 cd    	vpminsd %ymm21,%ymm17,%ymm9
    1537:	41 8b 92 b4 00 00 00 	mov    0xb4(%r10),%edx
    153e:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1543:	62 72 7d 28 7c d8    	vpbroadcastd %eax,%ymm11
    1549:	49 8b 42 18          	mov    0x18(%r10),%rax
    154d:	62 a2 35 28 39 d6    	vpminsd %ymm22,%ymm9,%ymm18
    1553:	62 b3 7d 20 1f d6 01 	vpcmpltd %ymm22,%ymm16,%k2
    155a:	62 a2 7d 20 3d c6    	vpmaxsd %ymm22,%ymm16,%ymm16
    1560:	62 21 75 20 fe cd    	vpaddd %ymm21,%ymm17,%ymm25
    1566:	c5 15 fe e9          	vpaddd %ymm1,%ymm13,%ymm13
    156a:	62 f2 7d 2f 90 0c a8 	vpgatherdd (%rax,%ymm5,4),%ymm1{%k7}
    1571:	49 8b 42 20          	mov    0x20(%r10),%rax
    1575:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1579:	c5 15 fe ee          	vpaddd %ymm6,%ymm13,%ymm13
    157d:	c4 41 25 fe dd       	vpaddd %ymm13,%ymm11,%ymm11
    1582:	62 32 7d 2e 90 24 ae 	vpgatherdd (%rsi,%ymm13,4),%ymm12{%k6}
    1589:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    158d:	62 b2 7d 2e 90 34 9e 	vpgatherdd (%rsi,%ymm11,4),%ymm6{%k6}
    1594:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1598:	62 f2 7d 2e 90 2c b8 	vpgatherdd (%rax,%ymm7,4),%ymm5{%k6}
    159f:	49 8b 42 28          	mov    0x28(%r10),%rax
    15a3:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    15a7:	62 61 9d 28 db c0    	vpandq %ymm0,%ymm12,%ymm24
    15ad:	62 b2 7d 2f 90 3c 80 	vpgatherdd (%rax,%ymm8,4),%ymm7{%k7}
    15b4:	62 52 2d 2b 64 c6    	vpblendmd %ymm14,%ymm10,%ymm8{%k3}
    15ba:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    15be:	49 8b 42 60          	mov    0x60(%r10),%rax
    15c2:	62 b3 55 20 1f d9 01 	vpcmpltd %ymm17,%ymm21,%k3
    15c9:	62 f1 3d 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm8{%k2}
    15d0:	62 d3 4d 20 1f d1 01 	vpcmpltd %ymm9,%ymm22,%k2
    15d7:	62 91 35 28 72 f0 10 	vpslld $0x10,%ymm24,%ymm9
    15de:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    15e3:	62 32 7d 2e 90 3c 86 	vpgatherdd (%rsi,%ymm8,4),%ymm15{%k6}
    15ea:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
    15ee:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    15f2:	62 52 2d 2b 64 c6    	vpblendmd %ymm14,%ymm10,%ymm8{%k3}
    15f8:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    15fe:	62 f1 3d 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm8{%k2}
    1605:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    160a:	62 a2 7d 2f 90 3c 86 	vpgatherdd (%rsi,%ymm8,4),%ymm23{%k7}
    1611:	62 31 7d 20 fe c2    	vpaddd %ymm18,%ymm16,%ymm8
    1617:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    161b:	62 e1 c5 20 db f8    	vpandq %ymm0,%ymm23,%ymm23
    1621:	62 51 4d 20 fa c0    	vpsubd %ymm8,%ymm22,%ymm8
    1627:	62 11 3d 28 fe c1    	vpaddd %ymm25,%ymm8,%ymm8
    162d:	62 41 45 20 fa cf    	vpsubd %ymm15,%ymm23,%ymm25
    1633:	62 12 3d 28 40 c1    	vpmulld %ymm25,%ymm8,%ymm8
    1639:	62 11 05 28 fa f8    	vpsubd %ymm24,%ymm15,%ymm15
    163f:	62 32 05 28 40 f8    	vpmulld %ymm16,%ymm15,%ymm15
    1645:	62 f1 7d 20 72 e5 10 	vpsrad $0x10,%ymm5,%ymm16
    164c:	c5 d5 72 f5 10       	vpslld $0x10,%ymm5,%ymm5
    1651:	62 a1 7d 20 fe c5    	vpaddd %ymm21,%ymm16,%ymm16
    1657:	c5 d5 72 e5 10       	vpsrad $0x10,%ymm5,%ymm5
    165c:	62 b1 55 28 fe ed    	vpaddd %ymm21,%ymm5,%ymm5
    1662:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    1667:	62 71 cd 28 db c8    	vpandq %ymm0,%ymm6,%ymm9
    166d:	62 31 35 28 fa cf    	vpsubd %ymm23,%ymm9,%ymm9
    1673:	62 32 35 28 40 ca    	vpmulld %ymm18,%ymm9,%ymm9
    1679:	62 f1 6d 20 72 e1 10 	vpsrad $0x10,%ymm1,%ymm18
    1680:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1685:	62 a1 6d 20 fe d1    	vpaddd %ymm17,%ymm18,%ymm18
    168b:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1690:	62 b1 75 28 fe c9    	vpaddd %ymm17,%ymm1,%ymm1
    1696:	62 f3 55 28 1f d9 06 	vpcmpnled %ymm1,%ymm5,%k3
    169d:	62 62 75 28 39 cd    	vpminsd %ymm5,%ymm1,%ymm25
    16a3:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    16a8:	62 31 6d 20 fe f8    	vpaddd %ymm16,%ymm18,%ymm15
    16ae:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    16b3:	c4 c1 35 72 d0 10    	vpsrld $0x10,%ymm8,%ymm9
    16b9:	c5 bd 72 e7 10       	vpsrad $0x10,%ymm7,%ymm8
    16be:	62 c2 2d 2b 64 ce    	vpblendmd %ymm14,%ymm10,%ymm17{%k3}
    16c4:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
    16c9:	62 f3 55 28 1f d9 01 	vpcmpltd %ymm1,%ymm5,%k3
    16d0:	62 31 3d 28 fe c6    	vpaddd %ymm22,%ymm8,%ymm8
    16d6:	c5 c5 72 e7 10       	vpsrad $0x10,%ymm7,%ymm7
    16db:	62 b1 45 28 fe fe    	vpaddd %ymm22,%ymm7,%ymm7
    16e1:	62 e2 75 28 3d f5    	vpmaxsd %ymm5,%ymm1,%ymm22
    16e7:	62 f3 4d 20 1f d7 01 	vpcmpltd %ymm7,%ymm22,%k2
    16ee:	62 61 45 28 fe c5    	vpaddd %ymm5,%ymm7,%ymm24
    16f4:	62 d2 2d 2b 64 ee    	vpblendmd %ymm14,%ymm10,%ymm5{%k3}
    16fa:	62 e2 4d 20 3d f7    	vpmaxsd %ymm7,%ymm22,%ymm22
    1700:	62 e2 35 20 39 ff    	vpminsd %ymm7,%ymm25,%ymm23
    1706:	62 b3 7d 20 1f da 06 	vpcmpnled %ymm18,%ymm16,%k3
    170d:	62 f1 75 22 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm17{%k2}
    1714:	62 93 45 28 1f d1 01 	vpcmpltd %ymm25,%ymm7,%k2
    171b:	62 c1 75 20 fe cd    	vpaddd %ymm13,%ymm17,%ymm17
    1721:	62 d1 35 20 72 d4 08 	vpsrld $0x8,%ymm12,%ymm25
    1728:	62 e2 7d 26 90 2c 8e 	vpgatherdd (%rsi,%ymm17,4),%ymm21{%k6}
    172f:	62 61 b5 20 db c8    	vpandq %ymm0,%ymm25,%ymm25
    1735:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1739:	62 f1 55 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm5{%k2}
    1740:	62 b1 45 28 72 d5 08 	vpsrld $0x8,%ymm21,%ymm7
    1747:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    174b:	62 91 2d 20 72 f1 10 	vpslld $0x10,%ymm25,%ymm26
    1752:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1758:	62 e2 7d 2f 90 0c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm17{%k7}
    175f:	62 b1 4d 20 fe ef    	vpaddd %ymm23,%ymm22,%ymm5
    1765:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1769:	62 b1 55 20 72 d1 08 	vpsrld $0x8,%ymm17,%ymm21
    1770:	62 f1 75 20 72 d6 08 	vpsrld $0x8,%ymm6,%ymm17
    1777:	c5 f5 fa ed          	vpsubd %ymm5,%ymm1,%ymm5
    177b:	62 e1 d5 20 db e8    	vpandq %ymm0,%ymm21,%ymm21
    1781:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1786:	62 91 55 28 fe e8    	vpaddd %ymm24,%ymm5,%ymm5
    178c:	62 f1 55 20 fa cf    	vpsubd %ymm7,%ymm21,%ymm1
    1792:	62 91 45 28 fa f9    	vpsubd %ymm25,%ymm7,%ymm7
    1798:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
    179e:	c4 e2 55 40 e9       	vpmulld %ymm1,%ymm5,%ymm5
    17a3:	62 b2 45 28 40 fe    	vpmulld %ymm22,%ymm7,%ymm7
    17a9:	62 f1 2d 20 fe ca    	vpaddd %ymm2,%ymm26,%ymm1
    17af:	62 a2 6d 20 39 f0    	vpminsd %ymm16,%ymm18,%ymm22
    17b5:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    17b9:	62 f1 f5 20 db c8    	vpandq %ymm0,%ymm17,%ymm1
    17bf:	62 a2 6d 20 3d c8    	vpmaxsd %ymm16,%ymm18,%ymm17
    17c5:	62 b1 75 28 fa cd    	vpsubd %ymm21,%ymm1,%ymm1
    17cb:	62 d3 75 20 1f d0 01 	vpcmpltd %ymm8,%ymm17,%k2
    17d2:	62 c2 4d 20 39 e8    	vpminsd %ymm8,%ymm22,%ymm21
    17d8:	62 b2 75 28 40 cf    	vpmulld %ymm23,%ymm1,%ymm1
    17de:	62 c2 75 20 3d c8    	vpmaxsd %ymm8,%ymm17,%ymm17
    17e4:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    17e8:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    17ec:	62 d2 2d 2b 64 ce    	vpblendmd %ymm14,%ymm10,%ymm1{%k3}
    17f2:	62 b3 7d 20 1f da 01 	vpcmpltd %ymm18,%ymm16,%k3
    17f9:	62 f1 75 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm1{%k2}
    1800:	62 e2 7d 28 7c c2    	vpbroadcastd %edx,%ymm16
    1806:	62 b3 3d 28 1f d6 01 	vpcmpltd %ymm22,%ymm8,%k2
    180d:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1812:	c4 c1 75 fe cd       	vpaddd %ymm13,%ymm1,%ymm1
    1817:	62 f2 7d 2e 90 3c 8e 	vpgatherdd (%rsi,%ymm1,4),%ymm7{%k6}
    181e:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1822:	62 d2 2d 2b 64 ce    	vpblendmd %ymm14,%ymm10,%ymm1{%k3}
    1828:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    182d:	62 f1 75 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm1{%k2}
    1834:	c4 c1 2d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm10
    183a:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1840:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    1844:	62 71 ad 28 db d0    	vpandq %ymm0,%ymm10,%ymm10
    184a:	62 72 7d 2f 90 1c 8e 	vpgatherdd (%rsi,%ymm1,4),%ymm11{%k7}
    1851:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    1857:	62 b1 75 20 fe cd    	vpaddd %ymm21,%ymm17,%ymm1
    185d:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1861:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    1867:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    186b:	62 71 a5 28 db d8    	vpandq %ymm0,%ymm11,%ymm11
    1871:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    1876:	c5 25 fa c7          	vpsubd %ymm7,%ymm11,%ymm8
    187a:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    187f:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    1884:	c4 c1 45 fa fa       	vpsubd %ymm10,%ymm7,%ymm7
    1889:	c5 1d fe c2          	vpaddd %ymm2,%ymm12,%ymm8
    188d:	62 b2 45 28 40 f9    	vpmulld %ymm17,%ymm7,%ymm7
    1893:	62 b2 4d 28 40 f5    	vpmulld %ymm21,%ymm6,%ymm6
    1899:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    189e:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    18a2:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    18a6:	62 b2 7d 2e 90 34 88 	vpgatherdd (%rax,%ymm9,4),%ymm6{%k6}
    18ad:	49 8b 42 68          	mov    0x68(%r10),%rax
    18b1:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    18b5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    18ba:	62 71 cd 28 db cc    	vpandq %ymm4,%ymm6,%ymm9
    18c0:	62 72 7d 2f 90 04 a8 	vpgatherdd (%rax,%ymm5,4),%ymm8{%k7}
    18c7:	49 8b 42 70          	mov    0x70(%r10),%rax
    18cb:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    18cf:	c4 c1 55 72 d0 11    	vpsrld $0x11,%ymm8,%ymm5
    18d5:	62 71 bd 28 db c4    	vpandq %ymm4,%ymm8,%ymm8
    18db:	62 72 7d 2e 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k6}
    18e2:	41 8b 82 b0 00 00 00 	mov    0xb0(%r10),%eax
    18e9:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    18ee:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
    18f3:	62 b2 55 28 40 e8    	vpmulld %ymm16,%ymm5,%ymm5
    18f9:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
    1900:	49 8b b2 a8 00 00 00 	mov    0xa8(%r10),%rsi
    1907:	62 c2 35 28 39 c8    	vpminsd %ymm8,%ymm9,%ymm17
    190d:	62 72 7d 28 7c f8    	vpbroadcastd %eax,%ymm15
    1913:	c4 c1 45 72 d6 11    	vpsrld $0x11,%ymm14,%ymm7
    1919:	62 71 8d 28 db f4    	vpandq %ymm4,%ymm14,%ymm14
    191f:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1923:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
    1928:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
    192f:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    1933:	41 8b 92 14 01 00 00 	mov    0x114(%r10),%edx
    193a:	62 32 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm13{%k3}
    1940:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
    1947:	62 f2 7d 28 7c f0    	vpbroadcastd %eax,%ymm6
    194d:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    1954:	62 52 75 20 39 e6    	vpminsd %ymm14,%ymm17,%ymm12
    195a:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
    195f:	62 f1 15 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm13{%k2}
    1966:	62 b3 0d 28 1f d1 01 	vpcmpltd %ymm17,%ymm14,%k2
    196d:	62 c1 35 28 fe d0    	vpaddd %ymm8,%ymm9,%ymm18
    1973:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
    1978:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    197c:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
    1981:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1985:	62 31 2d 28 fe d2    	vpaddd %ymm18,%ymm10,%ymm10
    198b:	62 f2 7d 2f 90 3c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm7{%k7}
    1992:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1996:	c5 95 fe ed          	vpaddd %ymm5,%ymm13,%ymm5
    199a:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    199e:	62 72 7d 2f 90 2c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm13{%k7}
    19a5:	62 b2 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm5{%k3}
    19ab:	62 f2 7d 2e 90 0c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm1{%k6}
    19b2:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    19b6:	62 f1 55 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm5{%k2}
    19bd:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
    19c3:	62 71 c5 28 db c8    	vpandq %ymm0,%ymm7,%ymm9
    19c9:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    19cd:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    19d1:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
    19d7:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
    19dd:	62 f2 7d 2e 90 2c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm5{%k6}
    19e4:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
    19e9:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    19ed:	49 8b b2 08 01 00 00 	mov    0x108(%r10),%rsi
    19f4:	62 f1 d5 28 db f0    	vpandq %ymm0,%ymm5,%ymm6
    19fa:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
    19ff:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
    1a03:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    1a08:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
    1a0e:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    1a13:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1a18:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    1a1e:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    1a23:	c5 0d fe ca          	vpaddd %ymm2,%ymm14,%ymm9
    1a27:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    1a2c:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1a31:	c5 b5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm9
    1a36:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
    1a3c:	c5 3d fe c6          	vpaddd %ymm6,%ymm8,%ymm8
    1a40:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    1a45:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1a4b:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
    1a52:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
    1a58:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
    1a5d:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
    1a62:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1a67:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    1a6c:	c4 c2 4d 40 f4       	vpmulld %ymm12,%ymm6,%ymm6
    1a71:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
    1a76:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1a7c:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
    1a81:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1a86:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1a8b:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1a91:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
    1a97:	62 f1 f5 28 db c8    	vpandq %ymm0,%ymm1,%ymm1
    1a9d:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1aa1:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1aa6:	62 71 7d 20 fe f2    	vpaddd %ymm2,%ymm16,%ymm14
    1aac:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1ab1:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1ab6:	62 e2 7d 28 7c c2    	vpbroadcastd %edx,%ymm16
    1abc:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1ac1:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
    1ac7:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    1acc:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1ad1:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1ad7:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    1adb:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1ae0:	62 32 7d 2f 90 0c 80 	vpgatherdd (%rax,%ymm8,4),%ymm9{%k7}
    1ae7:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    1aee:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    1af3:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1af8:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1afc:	62 72 7d 2e 90 04 b0 	vpgatherdd (%rax,%ymm6,4),%ymm8{%k6}
    1b03:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    1b0a:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1b0e:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1b12:	c5 95 fe fa          	vpaddd %ymm2,%ymm13,%ymm7
    1b16:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1b1a:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1b1e:	c4 c1 55 72 d0 11    	vpsrld $0x11,%ymm8,%ymm5
    1b24:	62 71 bd 28 db c4    	vpandq %ymm4,%ymm8,%ymm8
    1b2a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1b2f:	62 b2 55 28 40 e8    	vpmulld %ymm16,%ymm5,%ymm5
    1b35:	62 72 7d 2f 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k7}
    1b3c:	41 8b 82 10 01 00 00 	mov    0x110(%r10),%eax
    1b43:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
    1b49:	62 71 b5 28 db cc    	vpandq %ymm4,%ymm9,%ymm9
    1b4f:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
    1b56:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
    1b5b:	62 c2 35 28 39 c8    	vpminsd %ymm8,%ymm9,%ymm17
    1b61:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1b65:	62 72 7d 28 7c f8    	vpbroadcastd %eax,%ymm15
    1b6b:	c4 c1 4d 72 d6 11    	vpsrld $0x11,%ymm14,%ymm6
    1b71:	62 71 8d 28 db f4    	vpandq %ymm4,%ymm14,%ymm14
    1b77:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
    1b7c:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
    1b83:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    1b87:	41 8b 92 74 01 00 00 	mov    0x174(%r10),%edx
    1b8e:	62 32 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm13{%k3}
    1b94:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
    1b9b:	62 52 75 20 39 e6    	vpminsd %ymm14,%ymm17,%ymm12
    1ba1:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
    1ba6:	62 c1 35 28 fe d0    	vpaddd %ymm8,%ymm9,%ymm18
    1bac:	62 f1 15 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm13{%k2}
    1bb3:	62 b3 0d 28 1f d1 01 	vpcmpltd %ymm17,%ymm14,%k2
    1bba:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
    1bbf:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
    1bc4:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    1bc8:	62 31 2d 28 fe d2    	vpaddd %ymm18,%ymm10,%ymm10
    1bce:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1bd2:	62 f2 7d 28 7c f0    	vpbroadcastd %eax,%ymm6
    1bd8:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    1bdf:	62 f2 7d 2e 90 3c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm7{%k6}
    1be6:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1bea:	c5 95 fe ed          	vpaddd %ymm5,%ymm13,%ymm5
    1bee:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1bf2:	62 72 7d 2e 90 2c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm13{%k6}
    1bf9:	62 b2 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm5{%k3}
    1bff:	62 f2 7d 2f 90 0c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm1{%k7}
    1c06:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1c0a:	62 f1 55 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm5{%k2}
    1c11:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
    1c17:	62 71 c5 28 db c8    	vpandq %ymm0,%ymm7,%ymm9
    1c1d:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1c21:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    1c25:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
    1c2b:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
    1c31:	62 f2 7d 2f 90 2c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm5{%k7}
    1c38:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
    1c3d:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1c41:	49 8b b2 68 01 00 00 	mov    0x168(%r10),%rsi
    1c48:	62 f1 d5 28 db f0    	vpandq %ymm0,%ymm5,%ymm6
    1c4e:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
    1c53:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
    1c57:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    1c5c:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
    1c62:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    1c67:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1c6c:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    1c72:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    1c77:	c5 0d fe ca          	vpaddd %ymm2,%ymm14,%ymm9
    1c7b:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    1c80:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1c85:	c5 b5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm9
    1c8a:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
    1c90:	c5 3d fe c6          	vpaddd %ymm6,%ymm8,%ymm8
    1c94:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    1c99:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1c9f:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
    1ca6:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
    1cac:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
    1cb1:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
    1cb6:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1cbb:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    1cc0:	c4 c2 4d 40 f4       	vpmulld %ymm12,%ymm6,%ymm6
    1cc5:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
    1cca:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1cd0:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
    1cd5:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1cda:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1cdf:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1ce5:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
    1ceb:	62 f1 f5 28 db c8    	vpandq %ymm0,%ymm1,%ymm1
    1cf1:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1cf5:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1cfa:	62 71 7d 20 fe f2    	vpaddd %ymm2,%ymm16,%ymm14
    1d00:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1d05:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1d0a:	62 e2 7d 28 7c c2    	vpbroadcastd %edx,%ymm16
    1d10:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1d15:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
    1d1b:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    1d20:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1d25:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1d2b:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    1d2f:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1d34:	62 32 7d 2e 90 0c 80 	vpgatherdd (%rax,%ymm8,4),%ymm9{%k6}
    1d3b:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    1d42:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    1d47:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1d4c:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1d50:	62 72 7d 2f 90 04 b0 	vpgatherdd (%rax,%ymm6,4),%ymm8{%k7}
    1d57:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    1d5e:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1d62:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1d66:	c5 95 fe fa          	vpaddd %ymm2,%ymm13,%ymm7
    1d6a:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1d6e:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1d72:	c4 c1 55 72 d0 11    	vpsrld $0x11,%ymm8,%ymm5
    1d78:	62 71 bd 28 db c4    	vpandq %ymm4,%ymm8,%ymm8
    1d7e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1d83:	62 b2 55 28 40 e8    	vpmulld %ymm16,%ymm5,%ymm5
    1d89:	62 72 7d 2e 90 34 88 	vpgatherdd (%rax,%ymm1,4),%ymm14{%k6}
    1d90:	41 8b 82 70 01 00 00 	mov    0x170(%r10),%eax
    1d97:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
    1d9d:	62 71 b5 28 db cc    	vpandq %ymm4,%ymm9,%ymm9
    1da3:	62 d3 3d 28 1f d9 06 	vpcmpnled %ymm9,%ymm8,%k3
    1daa:	c4 42 35 3d d8       	vpmaxsd %ymm8,%ymm9,%ymm11
    1daf:	62 c2 35 28 39 c8    	vpminsd %ymm8,%ymm9,%ymm17
    1db5:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1db9:	62 72 7d 28 7c f8    	vpbroadcastd %eax,%ymm15
    1dbf:	c4 c1 4d 72 d6 11    	vpsrld $0x11,%ymm14,%ymm6
    1dc5:	62 71 8d 28 db f4    	vpandq %ymm4,%ymm14,%ymm14
    1dcb:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
    1dd0:	62 d3 25 28 1f d6 01 	vpcmpltd %ymm14,%ymm11,%k2
    1dd7:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    1ddb:	62 32 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm13{%k3}
    1de1:	62 d3 3d 28 1f d9 01 	vpcmpltd %ymm9,%ymm8,%k3
    1de8:	c4 42 25 3d de       	vpmaxsd %ymm14,%ymm11,%ymm11
    1ded:	62 52 75 20 39 e6    	vpminsd %ymm14,%ymm17,%ymm12
    1df3:	62 c1 35 28 fe d0    	vpaddd %ymm8,%ymm9,%ymm18
    1df9:	62 f1 15 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm13{%k2}
    1e00:	62 b3 0d 28 1f d1 01 	vpcmpltd %ymm17,%ymm14,%k2
    1e07:	c4 41 25 fe d4       	vpaddd %ymm12,%ymm11,%ymm10
    1e0c:	c4 41 0d fa d2       	vpsubd %ymm10,%ymm14,%ymm10
    1e11:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    1e15:	62 31 2d 28 fe d2    	vpaddd %ymm18,%ymm10,%ymm10
    1e1b:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1e1f:	62 f2 7d 28 7c f0    	vpbroadcastd %eax,%ymm6
    1e25:	62 f2 7d 2f 90 3c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm7{%k7}
    1e2c:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1e30:	c5 95 fe ed          	vpaddd %ymm5,%ymm13,%ymm5
    1e34:	c5 c5 46 ff          	kxnorb %k7,%k7,%k7
    1e38:	62 72 7d 2f 90 2c ae 	vpgatherdd (%rsi,%ymm5,4),%ymm13{%k7}
    1e3f:	62 b2 05 2b 64 e8    	vpblendmd %ymm16,%ymm15,%ymm5{%k3}
    1e45:	62 f2 7d 2e 90 0c b6 	vpgatherdd (%rsi,%ymm6,4),%ymm1{%k6}
    1e4c:	c5 cd 46 f6          	kxnorb %k6,%k6,%k6
    1e50:	62 f1 55 2a 72 d3 1f 	vpsrld $0x1f,%ymm3,%ymm5{%k2}
    1e57:	62 71 95 28 db f8    	vpandq %ymm0,%ymm13,%ymm15
    1e5d:	62 71 c5 28 db c8    	vpandq %ymm0,%ymm7,%ymm9
    1e63:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    1e67:	c4 c1 0d 72 f1 10    	vpslld $0x10,%ymm9,%ymm14
    1e6d:	62 71 f5 28 db c0    	vpandq %ymm0,%ymm1,%ymm8
    1e73:	62 f2 7d 2e 90 34 ae 	vpgatherdd (%rsi,%ymm5,4),%ymm6{%k6}
    1e7a:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
    1e7f:	62 f1 cd 28 db e8    	vpandq %ymm0,%ymm6,%ymm5
    1e85:	c4 42 35 40 cb       	vpmulld %ymm11,%ymm9,%ymm9
    1e8a:	c5 3d fa c5          	vpsubd %ymm5,%ymm8,%ymm8
    1e8e:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    1e93:	c4 c1 05 72 d5 08    	vpsrld $0x8,%ymm13,%ymm15
    1e99:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    1e9e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1ea3:	62 71 85 28 db f8    	vpandq %ymm0,%ymm15,%ymm15
    1ea9:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
    1eae:	c5 0d fe ca          	vpaddd %ymm2,%ymm14,%ymm9
    1eb2:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
    1eb7:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    1ebc:	c5 b5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm9
    1ec1:	62 71 8d 28 db f0    	vpandq %ymm0,%ymm14,%ymm14
    1ec7:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    1ecb:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1ed0:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1ed6:	62 d1 7d 20 72 f6 10 	vpslld $0x10,%ymm14,%ymm16
    1edd:	62 f1 d5 28 db e8    	vpandq %ymm0,%ymm5,%ymm5
    1ee3:	c4 41 05 fa f6       	vpsubd %ymm14,%ymm15,%ymm14
    1ee8:	c4 42 0d 40 f3       	vpmulld %ymm11,%ymm14,%ymm14
    1eed:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1ef2:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    1ef7:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
    1efc:	c4 41 35 fa cf       	vpsubd %ymm15,%ymm9,%ymm9
    1f01:	62 f1 c5 28 db f8    	vpandq %ymm0,%ymm7,%ymm7
    1f07:	c4 42 35 40 ca       	vpmulld %ymm10,%ymm9,%ymm9
    1f0c:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1f11:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1f16:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1f1c:	62 f1 cd 28 db f0    	vpandq %ymm0,%ymm6,%ymm6
    1f22:	62 f1 fd 28 db c9    	vpandq %ymm1,%ymm0,%ymm1
    1f28:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1f2c:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    1f31:	62 71 7d 20 fe f2    	vpaddd %ymm2,%ymm16,%ymm14
    1f37:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1f3c:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1f41:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    1f46:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
    1f4c:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    1f51:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1f56:	62 71 b5 28 db c8    	vpandq %ymm0,%ymm9,%ymm9
    1f5c:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
    1f60:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    1f65:	c5 d5 72 f5 08       	vpslld $0x8,%ymm5,%ymm5
    1f6a:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    1f6f:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1f74:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1f78:	c5 95 fe fa          	vpaddd %ymm2,%ymm13,%ymm7
    1f7c:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1f80:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    1f84:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1f89:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1f8e:	62 d3 f5 28 25 e8 fe 	vpternlogq $0xfe,%ymm8,%ymm1,%ymm5
    1f95:	62 b2 55 28 00 cb    	vpshufb %ymm19,%ymm5,%ymm1
    1f9b:	c5 f9 6f f1          	vmovdqa %xmm1,%xmm6
    1f9f:	62 f3 fd 28 39 c9 01 	vextracti64x2 $0x1,%ymm1,%xmm1
    1fa6:	c5 d1 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm5
    1fab:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    1fb0:	62 f1 d5 08 eb ee    	vporq  %xmm6,%xmm5,%xmm5
    1fb6:	c5 fa 7f 6b e8       	vmovdqu %xmm5,-0x18(%rbx)
    1fbb:	c5 f9 d6 4b f8       	vmovq  %xmm1,-0x8(%rbx)
    1fc0:	48 39 d9             	cmp    %rbx,%rcx
    1fc3:	0f 85 a9 f4 ff ff    	jne    1472 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1472>
    1fc9:	e9 25 e8 ff ff       	jmp    7f3 <jshc_evex256::evex256_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7f3>
    1fce:	90                   	nop
    1fcf:	90                   	nop
