"""生成独立EVEX-256实验；保留原AVX2对象作为运行时回退。"""
from pathlib import Path
import hashlib
import json
root=Path(__file__).resolve().parents[1]
out=root/'experiments/skylake-evex256-runtime'
out.mkdir(exist_ok=False)
base=root/'experiments/skylake-delta16-runtime'
source=(base/'channel_avx2.cpp').read_text(encoding='utf-8').replace('namespace jshc_delta16 {','namespace jshc_evex256 {')
source=source.replace('void avx2_chain(', 'void evex256_chain(')
source=source.replace('_mm256_i32gather_epi32(reinterpret_cast<const int*>(data),index,4)',
    '_mm256_mmask_i32gather_epi32(_mm256_setzero_si256(),0xff,index,reinterpret_cast<const int*>(data),4)')
source=source.replace('// 有界有符号坐标差减少三次dword gather；RGB节点、Q16权重和逐级舍入保持精确。',
    '// 仍为8像素256位整数；EVEX掩码gather与扩展寄存器减少读写栈，算法沿用修订5。')
(out/'channel_avx2.cpp').write_text(source,encoding='utf-8',newline='\n')
source=(base/'channel_runtime.cpp').read_text(encoding='utf-8').replace('jshc_delta16','jshc_evex256').replace('return 5;', 'return 18;')
source=source.replace('uint32_t jshc_cc_revision(void)',
    'uint32_t jshc_cc_evex256_enabled(void) {return jshc_evex256::evex256_enabled()?1:0;}\nuint32_t jshc_cc_revision(void)')
(out/'channel_runtime.cpp').write_text(source,encoding='utf-8',newline='\n')
(out/'channel_views.hpp').write_text('''#pragma once
#include "../skylake-delta16-runtime/channel_views.hpp"
namespace jshc_evex256 {
using View=jshc_delta16::View;
bool evex256_enabled() noexcept;
void evex256_chain(const View*,size_t,uint8_t*,size_t) noexcept;
void avx2_chain(const View*,size_t,uint8_t*,size_t) noexcept;
}
''',encoding='utf-8',newline='\n')
(out/'channel_dispatch.cpp').write_text('''// 此TU保持通用ISA。GCC内建检测包含CPU及OS的扩展状态支持；关闭变量用于回退合同。
#include "channel_views.hpp"
#include <cstdlib>
namespace jshc_evex256 {
bool evex256_enabled() noexcept {
  static const bool enabled=[] {
    __builtin_cpu_init();
    return __builtin_cpu_supports("avx512f") && __builtin_cpu_supports("avx512vl")
        && __builtin_cpu_supports("avx512bw") && __builtin_cpu_supports("avx512dq")
        && std::getenv("JSHC_EVEX256_DISABLE")==nullptr;
  }();
  return enabled;
}
void avx2_chain(const View* v,size_t stages,uint8_t* data,size_t pixels) noexcept {
  if(evex256_enabled())evex256_chain(v,stages,data,pixels);
  else jshc_delta16::avx2_chain(v,stages,data,pixels);
}
}
''',encoding='utf-8',newline='\n')
cmake=(root/'experiments/skylake-geometry-runtime/CMakeLists.txt').read_text(encoding='utf-8')
cmake=cmake.replace('jshc_skylake_geometry','jshc_skylake_evex256')
cmake=cmake.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp")',
    '"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${CMAKE_CURRENT_SOURCE_DIR}/channel_dispatch.cpp"\n  "${JSHC_ROOT}/experiments/skylake-delta16-runtime/channel_avx2.cpp")',1)
cmake=cmake.replace('set_property(SOURCE "${JSHC_ROOT}/cpp/src/lut_simd_avx2.cpp"',
    'set_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp" APPEND PROPERTY COMPILE_OPTIONS\n  -mavx512f -mavx512vl -mavx512bw -mavx512dq -mprefer-vector-width=256)\nset_property(SOURCE "${JSHC_ROOT}/cpp/src/lut_simd_avx2.cpp"')
(out/'CMakeLists.txt').write_text(cmake,encoding='utf-8',newline='\n')
# 原builder不放宽；新入口只允许这个TU拥有明确的AVX512子集。
builder=(root/'scripts/build_skylake_runtime.py').read_text(encoding='utf-8')
builder=builder.replace('按冻结输入同时构建Skylake调度的参考库与独立候选，不覆盖既有构建。',
    '构建隔离EVEX-256与原AVX2回退；逐TU核验ISA，不覆盖旧构建。')
builder=builder.replace("'-mavx512', ", '')
needle="        if name != 'lut_simd_avx2.cpp'"
pos=builder.index(needle)
builder=builder[:pos]+'''        evex = 'skylake-evex256-runtime/channel_avx2.cpp' in item['file'].replace('\\\\','/')
        flags = [flag for flag in command.split() if flag.startswith('-mavx512')]
        allowed = ['-mavx512f', '-mavx512vl', '-mavx512bw', '-mavx512dq']
        if flags != (allowed if evex else []):
            raise ValueError('AVX512子集只允许在独立EVEX-256翻译单元')
        if evex and '-mprefer-vector-width=256' not in command:
            raise ValueError('EVEX后端必须请求256位向量宽度')
'''+builder[pos:]
(root/'scripts/build_skylake_evex256.py').write_text(builder,encoding='utf-8',newline='\n')
plan=json.loads((root/'experiments/skylake-delta16-v2.json').read_text(encoding='utf-8'))
plan.pop('deadline_shanghai',None);plan.pop('test_plan_revision_reason',None)
plan['purpose']='隔离EVEX-256八像素整数映射对比修订5；保留AVX2回退，不增加派生缓存'
plan['base_commit']='860d6bf';plan['remote_snapshot']='b19c5a0'
plan['candidate']='原Q16整数算法，EVEX掩码gather和高YMM寄存器；算法/排序/内存表/向量宽度/块大小不变'
plan['cmake_project']='experiments/skylake-evex256-runtime'
plan['cmake_targets']=['jshc_skylake_reference','jshc_skylake_evex256']
plan['revisions']={'reference':5,'candidate':18};plan['test_plan_revision']=1
plan['compile_policy']['simd']='独立TU -mavx2 -mavx512f -mavx512vl -mavx512bw -mavx512dq -mprefer-vector-width=256 -mtune=skylake -ffp-contract=off；其他TU沿用通用或原AVX2'
plan['compile_policy']['forbidden']=['全局-march','AVX512泄漏到dispatcher或原AVX2','ZMM指令','FMA','fast-math']
plan['contract']['oracle']='独立uint64凸重心逐级RGB8，两个库逐字节比较'
plan['contract']['acceptance']='有限合同、坐标差边界、完整256³及100图全部字节一致；关闭EVEX后单独确认回退'
plan['evex256_policy']={
 'required_features':['avx512f','avx512vl','avx512bw','avx512dq'],
 'dispatch':'GCC builtin CPU+OS检测；每进程首次缓存；环境变量JSHC_EVEX256_DISABLE存在时强制原AVX2；无AVX2时沿用标量',
 'static_gate':'35gather实际固定四级循环：无调用、无ZMM、使用YMM16..31、rsp不增、skylake-avx512模型周期至少下降5%；回退对象同字节',
 'numerical':'基础合同后、差值边界、CPU关闭回退、单级/四级全色域、100照片；不重新拟合',
 'performance':'唯一4进程AB/BA/BA/AB；各1/4线程顺序平衡，各5轮100图；每轮SHA核验；中位>=3%收益，任一进程不退化超过2%，copy+apply不退化',
 'stop':'失败保留，不扫描指令集子集、宽度、块、线程数或重测',
 'limits':['只适用实际CPUID+OS支持的Skylake-SP/X；其他Skylake回退','256位也不保证没有AVX频率影响','GDS和服务器实测单独记录，AMD不作服务器成绩']}
names=set(plan['source_sha256'])|{p.relative_to(root).as_posix() for p in out.iterdir()}|{'scripts/build_skylake_evex256.py'}
plan['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
(root/'experiments/skylake-evex256-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('EVEX-256候选/分派/冻结计划已生成；数值内核调用0')
