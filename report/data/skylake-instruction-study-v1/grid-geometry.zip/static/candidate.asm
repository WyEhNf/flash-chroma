
artifacts\skylake-grid-geometry-build-v1\CMakeFiles\jshc_skylake_grid_geometry.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)>:
       0:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
       7:	c5 f8 29 b4 24 20 01 	vmovaps %xmm6,0x120(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 30 01 	vmovaps %xmm7,0x130(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 40 01 	vmovaps %xmm8,0x140(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 50 01 	vmovaps %xmm9,0x150(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 60 01 	vmovaps %xmm10,0x160(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 70 01 	vmovaps %xmm11,0x170(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 80 01 	vmovaps %xmm12,0x180(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 90 01 	vmovaps %xmm13,0x190(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 a0 01 	vmovaps %xmm14,0x1a0(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 b0 01 	vmovaps %xmm15,0x1b0(%rsp)
      5f:	00 00 
      61:	48 89 c8             	mov    %rcx,%rax
      64:	4d 85 c0             	test   %r8,%r8
      67:	0f 84 86 0b 00 00    	je     bf3 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xbf3>
      6d:	49 ff c8             	dec    %r8
      70:	48 89 d1             	mov    %rdx,%rcx
      73:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      78:	49 c1 e8 03          	shr    $0x3,%r8
      7c:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
      82:	4b 8d 14 40          	lea    (%r8,%r8,2),%rdx
      86:	4c 8d 44 d1 18       	lea    0x18(%rcx,%rdx,8),%r8
      8b:	ba 63 04 00 00       	mov    $0x463,%edx
      90:	c5 f9 6e f2          	vmovd  %edx,%xmm6
      94:	ba 21 00 00 00       	mov    $0x21,%edx
      99:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      9e:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
      a5:	00 00 
      a7:	c5 f9 6e f2          	vmovd  %edx,%xmm6
      ab:	ba 41 04 00 00       	mov    $0x441,%edx
      b0:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      b5:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
      ba:	c5 f9 6e f2          	vmovd  %edx,%xmm6
      be:	ba 00 80 00 00       	mov    $0x8000,%edx
      c3:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      c8:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
      ce:	c5 f9 6e f2          	vmovd  %edx,%xmm6
      d2:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      d7:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
      dd:	0f 1f 00             	nopl   (%rax)
      e0:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
      e4:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
      e9:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
      ed:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
      f1:	48 8b 10             	mov    (%rax),%rdx
      f4:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
      f9:	4c 8b 48 18          	mov    0x18(%rax),%r9
      fd:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     102:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     108:	48 83 c1 18          	add    $0x18,%rcx
     10c:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     112:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 11b <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x11b>
     119:	00 00 
     11b:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
     120:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     125:	c4 c1 7d db cd       	vpand  %ymm13,%ymm0,%ymm1
     12a:	c4 e2 4d 90 2c 8a    	vpgatherdd %ymm6,(%rdx,%ymm1,4),%ymm5
     130:	48 8b 50 08          	mov    0x8(%rax),%rdx
     134:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     139:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
     13e:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1a6 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1a6>
     145:	00 
     146:	c4 e2 45 90 34 a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm6
     14c:	48 8b 50 10          	mov    0x10(%rax),%rdx
     150:	c5 ad 72 f0 06       	vpslld $0x6,%ymm0,%ymm10
     155:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     159:	c5 bd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm8
     15e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1c6 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1c6>
     165:	00 
     166:	c4 e2 45 90 14 9a    	vpgatherdd %ymm7,(%rdx,%ymm3,4),%ymm2
     16c:	c5 c5 72 f0 0a       	vpslld $0xa,%ymm0,%ymm7
     171:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     176:	48 8b 50 48          	mov    0x48(%rax),%rdx
     17a:	c5 a5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm11
     17f:	c4 c1 35 72 f0 05    	vpslld $0x5,%ymm8,%ymm9
     185:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     18a:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     18f:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     194:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     199:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     19d:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     1a2:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 20a <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x20a>
     1a9:	00 
     1aa:	c4 e2 2d 90 3c 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm7
     1b0:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     1b7:	00 00 
     1b9:	c5 fd fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm0,%ymm7
     1c0:	00 00 
     1c2:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     1c8:	c4 62 1d 90 14 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm10
     1ce:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     1d3:	c4 e2 55 39 fe       	vpminsd %ymm6,%ymm5,%ymm7
     1d8:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
     1df:	00 00 
     1e1:	c4 42 1d 90 0c 89    	vpgatherdd %ymm12,(%r9,%ymm1,4),%ymm9
     1e7:	4c 8b 48 20          	mov    0x20(%rax),%r9
     1eb:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
     1f2:	00 00 
     1f4:	c4 c2 3d 90 0c a1    	vpgatherdd %ymm8,(%r9,%ymm4,4),%ymm1
     1fa:	c4 62 55 3d c6       	vpmaxsd %ymm6,%ymm5,%ymm8
     1ff:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     203:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
     20a:	00 00 
     20c:	4c 8b 48 28          	mov    0x28(%rax),%r9
     210:	c4 62 3d 3d e2       	vpmaxsd %ymm2,%ymm8,%ymm12
     215:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     21b:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
     220:	c4 c2 5d 90 0c 99    	vpgatherdd %ymm4,(%r9,%ymm3,4),%ymm1
     226:	c5 cd 66 e5          	vpcmpgtd %ymm5,%ymm6,%ymm4
     22a:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     230:	c4 62 45 39 e2       	vpminsd %ymm2,%ymm7,%ymm12
     235:	c4 c1 6d 66 d8       	vpcmpgtd %ymm8,%ymm2,%ymm3
     23a:	c4 62 3d 39 c2       	vpminsd %ymm2,%ymm8,%ymm8
     23f:	c4 42 45 3d c0       	vpmaxsd %ymm8,%ymm7,%ymm8
     244:	c5 c5 66 fa          	vpcmpgtd %ymm2,%ymm7,%ymm7
     248:	c4 63 25 4c 0c 24 40 	vpblendvb %ymm4,(%rsp),%ymm11,%ymm9
     24f:	c4 c3 2d 4c e3 40    	vpblendvb %ymm4,%ymm11,%ymm10,%ymm4
     255:	c5 15 db 94 24 a0 00 	vpand  0xa0(%rsp),%ymm13,%ymm10
     25c:	00 00 
     25e:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm9,%ymm9        # 287 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x287>
     265:	00 00 30 
     268:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm4,%ymm4        # 291 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x291>
     26f:	00 00 70 
     272:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
     278:	c4 41 7d fe c9       	vpaddd %ymm9,%ymm0,%ymm9
     27d:	c4 a2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm9,4),%ymm3
     283:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
     289:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     28e:	c5 c5 fa e4          	vpsubd %ymm4,%ymm7,%ymm4
     292:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     297:	c5 35 fe 4c 24 40    	vpaddd 0x40(%rsp),%ymm9,%ymm9
     29d:	c4 e2 0d 90 3c a2    	vpgatherdd %ymm14,(%rdx,%ymm4,4),%ymm7
     2a3:	c5 95 db a4 24 c0 00 	vpand  0xc0(%rsp),%ymm13,%ymm4
     2aa:	00 00 
     2ac:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     2b1:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     2b5:	c5 c5 fa fb          	vpsubd %ymm3,%ymm7,%ymm7
     2b9:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
     2be:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     2c3:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     2c8:	c4 e2 65 40 5c 24 20 	vpmulld 0x20(%rsp),%ymm3,%ymm3
     2cf:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
     2d4:	c5 7e 6f 8c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm9
     2db:	00 00 
     2dd:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     2e3:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     2e9:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     2ee:	c4 c1 3d 72 e1 10    	vpsrad $0x10,%ymm9,%ymm8
     2f4:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     2f8:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     2fc:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
     301:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     305:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     30a:	c5 fe 6f 9c 24 00 01 	vmovdqu 0x100(%rsp),%ymm3
     311:	00 00 
     313:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
     317:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
     31c:	c5 9d 72 d4 10       	vpsrld $0x10,%ymm4,%ymm12
     321:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     325:	c5 dd 72 e3 10       	vpsrad $0x10,%ymm3,%ymm4
     32a:	c4 c1 6d 72 f1 10    	vpslld $0x10,%ymm9,%ymm2
     330:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
     335:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     339:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
     33e:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     343:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     347:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     34b:	c5 e5 66 ea          	vpcmpgtd %ymm2,%ymm3,%ymm5
     34f:	c4 e2 6d 3d f3       	vpmaxsd %ymm3,%ymm2,%ymm6
     354:	c4 e2 6d 39 d3       	vpminsd %ymm3,%ymm2,%ymm2
     359:	c4 62 4d 3d d1       	vpmaxsd %ymm1,%ymm6,%ymm10
     35e:	c5 f5 66 de          	vpcmpgtd %ymm6,%ymm1,%ymm3
     362:	c4 e2 4d 39 f1       	vpminsd %ymm1,%ymm6,%ymm6
     367:	c4 e2 6d 3d f6       	vpmaxsd %ymm6,%ymm2,%ymm6
     36c:	c4 63 0d 4c 0c 24 50 	vpblendvb %ymm5,(%rsp),%ymm14,%ymm9
     373:	c4 62 6d 39 f1       	vpminsd %ymm1,%ymm2,%ymm14
     378:	c5 ed 66 d1          	vpcmpgtd %ymm1,%ymm2,%ymm2
     37c:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
     381:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm9,%ymm9        # 3aa <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x3aa>
     388:	00 00 30 
     38b:	c4 41 7d fe c9       	vpaddd %ymm9,%ymm0,%ymm9
     390:	c4 e3 75 4c 6c 24 20 	vpblendvb %ymm5,0x20(%rsp),%ymm1,%ymm5
     397:	50 
     398:	c4 a2 25 90 1c 8a    	vpgatherdd %ymm11,(%rdx,%ymm9,4),%ymm3
     39e:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     3a3:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 3cc <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x3cc>
     3aa:	00 00 20 
     3ad:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
     3b3:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     3b8:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     3bd:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     3c1:	c4 e2 25 90 0c aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm1
     3c7:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
     3ce:	00 00 
     3d0:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
     3d7:	00 00 
     3d9:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     3de:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     3e4:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
     3e9:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     3ee:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     3f3:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     3f8:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     3fd:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     401:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
     405:	c5 b5 72 f5 10       	vpslld $0x10,%ymm5,%ymm9
     40a:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
     40f:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     413:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     418:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     41d:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     422:	c5 7e 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm10
     428:	c4 41 35 fe ca       	vpaddd %ymm10,%ymm9,%ymm9
     42d:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
     432:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
     436:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     43a:	c4 e2 3d 3d d4       	vpmaxsd %ymm4,%ymm8,%ymm2
     43f:	c4 c1 5d 66 d8       	vpcmpgtd %ymm8,%ymm4,%ymm3
     444:	c5 c5 66 ea          	vpcmpgtd %ymm2,%ymm7,%ymm5
     448:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     44d:	c4 e2 3d 39 e4       	vpminsd %ymm4,%ymm8,%ymm4
     452:	c4 e2 5d 39 f7       	vpminsd %ymm7,%ymm4,%ymm6
     457:	c4 63 25 4c 04 24 30 	vpblendvb %ymm3,(%rsp),%ymm11,%ymm8
     45e:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm8,%ymm8        # 487 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x487>
     465:	00 00 50 
     468:	c4 e2 6d 3d ef       	vpmaxsd %ymm7,%ymm2,%ymm5
     46d:	c4 e2 6d 39 d7       	vpminsd %ymm7,%ymm2,%ymm2
     472:	c4 41 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm8
     477:	c4 e2 5d 3d d2       	vpmaxsd %ymm2,%ymm4,%ymm2
     47c:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     480:	c4 a2 0d 90 04 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm0
     486:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
     48b:	c4 c3 0d 4c db 30    	vpblendvb %ymm3,%ymm11,%ymm14,%ymm3
     491:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     496:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm3,%ymm3        # 4bf <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4bf>
     49d:	00 00 40 
     4a0:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
     4a6:	c5 dd fa db          	vpsubd %ymm3,%ymm4,%ymm3
     4aa:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
     4b1:	00 00 
     4b3:	c4 62 0d 90 04 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm8
     4b9:	48 8b 50 60          	mov    0x60(%rax),%rdx
     4bd:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     4c2:	c5 e5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm3
     4c7:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
     4cc:	c5 fe 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm0
     4d3:	00 00 
     4d5:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     4db:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     4e0:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     4e5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     4ea:	c5 c5 72 f3 10       	vpslld $0x10,%ymm3,%ymm7
     4ef:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
     4f4:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     4f9:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     4fe:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
     503:	c5 3d fa c4          	vpsubd %ymm4,%ymm8,%ymm8
     507:	c4 62 3d 40 c2       	vpmulld %ymm2,%ymm8,%ymm8
     50c:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     511:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     515:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
     51a:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     51e:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     522:	c4 a2 4d 90 14 a2    	vpgatherdd %ymm6,(%rdx,%ymm12,4),%ymm2
     528:	48 8b 50 68          	mov    0x68(%rax),%rdx
     52c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     530:	c4 e2 55 90 1c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm3
     536:	48 8b 50 70          	mov    0x70(%rax),%rdx
     53a:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
     53f:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     544:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     548:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     54c:	c5 dd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm4
     551:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 5b9 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5b9>
     558:	00 
     559:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     55e:	c5 d5 72 f4 05       	vpslld $0x5,%ymm4,%ymm5
     563:	c4 62 4d 90 04 82    	vpgatherdd %ymm6,(%rdx,%ymm0,4),%ymm8
     569:	c5 cd 72 f1 06       	vpslld $0x6,%ymm1,%ymm6
     56e:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     575:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
     57a:	c4 c1 45 72 d0 11    	vpsrld $0x11,%ymm8,%ymm7
     580:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     584:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     588:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     58c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     590:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     594:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     598:	c5 f5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm1,%ymm7
     59f:	00 00 
     5a1:	c4 e2 4d 90 2c 8a    	vpgatherdd %ymm6,(%rdx,%ymm1,4),%ymm5
     5a7:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     5ab:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
     5b0:	c4 e2 4d 90 04 ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm0
     5b6:	c5 ed db 35 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm6        # 61e <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x61e>
     5bd:	00 
     5be:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
     5c3:	c5 65 66 ce          	vpcmpgtd %ymm6,%ymm3,%ymm9
     5c7:	c4 e2 4d 39 d3       	vpminsd %ymm3,%ymm6,%ymm2
     5cc:	c4 e2 4d 3d e3       	vpmaxsd %ymm3,%ymm6,%ymm4
     5d1:	c5 bd db 1d 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm3        # 639 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x639>
     5d8:	00 
     5d9:	c5 e5 66 f4          	vpcmpgtd %ymm4,%ymm3,%ymm6
     5dd:	c4 63 25 4c 14 24 90 	vpblendvb %ymm9,(%rsp),%ymm11,%ymm10
     5e4:	c4 62 6d 39 c3       	vpminsd %ymm3,%ymm2,%ymm8
     5e9:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
     5ee:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     5f3:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     5f8:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm10,%ymm10        # 621 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x621>
     5ff:	00 00 60 
     602:	c4 e2 5d 3d f3       	vpmaxsd %ymm3,%ymm4,%ymm6
     607:	c4 e2 5d 39 e3       	vpminsd %ymm3,%ymm4,%ymm4
     60c:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
     611:	c4 e2 6d 3d e4       	vpmaxsd %ymm4,%ymm2,%ymm4
     616:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
     61a:	c4 62 0d 90 14 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm10
     620:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
     625:	c4 c1 7d db dd       	vpand  %ymm13,%ymm0,%ymm3
     62a:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
     630:	c4 e3 75 4c 4c 24 20 	vpblendvb %ymm9,0x20(%rsp),%ymm1,%ymm1
     637:	90 
     638:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # 661 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x661>
     63f:	00 00 20 
     642:	c4 c1 2d db cd       	vpand  %ymm13,%ymm10,%ymm1
     647:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
     64b:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     64f:	c4 62 6d 90 0c ba    	vpgatherdd %ymm2,(%rdx,%ymm7,4),%ymm9
     655:	c4 c1 45 72 f3 10    	vpslld $0x10,%ymm11,%ymm7
     65b:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
     662:	c4 c1 35 db d5       	vpand  %ymm13,%ymm9,%ymm2
     667:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     66c:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     670:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     674:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
     679:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
     67e:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     683:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     688:	c4 c1 25 72 d1 08    	vpsrld $0x8,%ymm9,%ymm11
     68e:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     693:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     699:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     69e:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     6a2:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     6a7:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     6ab:	c4 c1 45 72 d2 08    	vpsrld $0x8,%ymm10,%ymm7
     6b1:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     6b6:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     6bb:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
     6c0:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     6c4:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
     6ca:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     6cf:	c5 25 fa df          	vpsubd %ymm7,%ymm11,%ymm11
     6d3:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
     6d8:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     6dd:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     6e2:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
     6e7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     6ec:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
     6f1:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     6f6:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     6fb:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     700:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     705:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     70a:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
     70e:	c4 c1 75 72 d2 10    	vpsrld $0x10,%ymm10,%ymm1
     714:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     719:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     71d:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     722:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     727:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
     72b:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     72f:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     734:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     738:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     73d:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     742:	c4 e2 55 90 34 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm6
     748:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
     74f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     753:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     759:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
     75f:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
     766:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     76a:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
     76f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 7d7 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x7d7>
     776:	00 
     777:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
     77c:	c5 dd 72 f2 05       	vpslld $0x5,%ymm2,%ymm4
     781:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     785:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     789:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     78e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 7f6 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x7f6>
     795:	00 
     796:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     79b:	c4 62 55 90 04 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm8
     7a1:	c5 d5 72 f1 06       	vpslld $0x6,%ymm1,%ymm5
     7a6:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
     7ad:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
     7b2:	c4 c1 45 72 d0 11    	vpsrld $0x11,%ymm8,%ymm7
     7b8:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     7bc:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     7c0:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     7c4:	c5 65 66 ce          	vpcmpgtd %ymm6,%ymm3,%ymm9
     7c8:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     7cc:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     7d0:	c4 e2 4d 39 d3       	vpminsd %ymm3,%ymm6,%ymm2
     7d5:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     7d9:	c5 f5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm1,%ymm7
     7e0:	00 00 
     7e2:	c4 e2 5d 90 2c 8a    	vpgatherdd %ymm4,(%rdx,%ymm1,4),%ymm5
     7e8:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     7ec:	c4 63 0d 4c 14 24 90 	vpblendvb %ymm9,(%rsp),%ymm14,%ymm10
     7f3:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     7f8:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
     7fd:	c4 e2 5d 90 04 ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm0
     803:	c4 e2 4d 3d e3       	vpmaxsd %ymm3,%ymm6,%ymm4
     808:	c5 bd db 1d 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm3        # 870 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x870>
     80f:	00 
     810:	c5 e5 66 f4          	vpcmpgtd %ymm4,%ymm3,%ymm6
     814:	c4 62 6d 39 c3       	vpminsd %ymm3,%ymm2,%ymm8
     819:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm10,%ymm10        # 842 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x842>
     820:	00 00 60 
     823:	c4 e2 5d 3d f3       	vpmaxsd %ymm3,%ymm4,%ymm6
     828:	c4 e2 5d 39 e3       	vpminsd %ymm3,%ymm4,%ymm4
     82d:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
     832:	c4 e2 6d 3d e4       	vpmaxsd %ymm4,%ymm2,%ymm4
     837:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
     83b:	c4 62 0d 90 14 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm10
     841:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
     846:	c4 c1 7d db dd       	vpand  %ymm13,%ymm0,%ymm3
     84b:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
     850:	c4 e3 75 4c 4c 24 20 	vpblendvb %ymm9,0x20(%rsp),%ymm1,%ymm1
     857:	90 
     858:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # 881 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x881>
     85f:	00 00 20 
     862:	c4 c1 2d db cd       	vpand  %ymm13,%ymm10,%ymm1
     867:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
     86b:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     86f:	c4 62 6d 90 0c ba    	vpgatherdd %ymm2,(%rdx,%ymm7,4),%ymm9
     875:	c4 c1 45 72 f3 10    	vpslld $0x10,%ymm11,%ymm7
     87b:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
     882:	c4 c1 35 db d5       	vpand  %ymm13,%ymm9,%ymm2
     887:	c4 c1 45 fe fc       	vpaddd %ymm12,%ymm7,%ymm7
     88c:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     890:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     894:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
     899:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     89e:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
     8a3:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
     8a8:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
     8ad:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     8b2:	c4 c1 25 72 d1 08    	vpsrld $0x8,%ymm9,%ymm11
     8b8:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     8bd:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     8c2:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     8c8:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     8cd:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     8d2:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     8d6:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     8da:	c4 c1 45 72 d2 08    	vpsrld $0x8,%ymm10,%ymm7
     8e0:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     8e5:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     8ea:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     8ee:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
     8f4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     8f9:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     8fe:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
     903:	c5 25 fa df          	vpsubd %ymm7,%ymm11,%ymm11
     907:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     90c:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
     911:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     916:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     91b:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
     920:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     925:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     92a:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     92f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     934:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
     939:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
     93d:	c4 c1 75 72 d2 10    	vpsrld $0x10,%ymm10,%ymm1
     943:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     948:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     94e:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     953:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     957:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     95c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     961:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
     965:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     969:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     96e:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     972:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     977:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     97c:	c4 e2 55 90 34 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm6
     982:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
     989:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     98d:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     992:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
     998:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
     99f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     9a3:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
     9a8:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # a10 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa10>
     9af:	00 
     9b0:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
     9b5:	c5 dd 72 f2 05       	vpslld $0x5,%ymm2,%ymm4
     9ba:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     9be:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     9c2:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     9c7:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # a2f <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa2f>
     9ce:	00 
     9cf:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     9d4:	c4 62 55 90 04 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm8
     9da:	c5 d5 72 f1 06       	vpslld $0x6,%ymm1,%ymm5
     9df:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
     9e6:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
     9eb:	c4 c1 45 72 d0 11    	vpsrld $0x11,%ymm8,%ymm7
     9f1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     9f5:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     9f9:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     9fd:	c5 3d db 15 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm10        # a65 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa65>
     a04:	00 
     a05:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     a09:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     a0d:	c4 e2 4d 39 d3       	vpminsd %ymm3,%ymm6,%ymm2
     a12:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     a16:	c5 65 66 ce          	vpcmpgtd %ymm6,%ymm3,%ymm9
     a1a:	c4 42 6d 39 c2       	vpminsd %ymm10,%ymm2,%ymm8
     a1f:	c5 f5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm1,%ymm7
     a26:	00 00 
     a28:	c4 e2 5d 90 2c 8a    	vpgatherdd %ymm4,(%rdx,%ymm1,4),%ymm5
     a2e:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     a32:	c4 e2 5d 90 04 ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm0
     a38:	c4 e2 4d 3d e3       	vpmaxsd %ymm3,%ymm6,%ymm4
     a3d:	c4 e3 25 4c 1c 24 90 	vpblendvb %ymm9,(%rsp),%ymm11,%ymm3
     a44:	c5 ad 66 f4          	vpcmpgtd %ymm4,%ymm10,%ymm6
     a48:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # a71 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa71>
     a4f:	00 00 60 
     a52:	c4 c2 5d 3d f2       	vpmaxsd %ymm10,%ymm4,%ymm6
     a57:	c4 c2 5d 39 e2       	vpminsd %ymm10,%ymm4,%ymm4
     a5c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     a60:	c4 e2 6d 3d e4       	vpmaxsd %ymm4,%ymm2,%ymm4
     a65:	c4 c1 6d 66 d2       	vpcmpgtd %ymm10,%ymm2,%ymm2
     a6a:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
     a70:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
     a75:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
     a7a:	c4 c3 75 4c cb 90    	vpblendvb %ymm9,%ymm11,%ymm1,%ymm1
     a80:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
     a85:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # aae <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xaae>
     a8c:	00 00 20 
     a8f:	c4 c1 2d 72 f3 10    	vpslld $0x10,%ymm11,%ymm10
     a95:	c4 c1 65 db cd       	vpand  %ymm13,%ymm3,%ymm1
     a9a:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
     a9e:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     aa2:	c4 41 2d fe d4       	vpaddd %ymm12,%ymm10,%ymm10
     aa7:	c4 62 6d 90 0c ba    	vpgatherdd %ymm2,(%rdx,%ymm7,4),%ymm9
     aad:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
     ab2:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
     ab7:	c4 c1 35 db fd       	vpand  %ymm13,%ymm9,%ymm7
     abc:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     ac1:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
     ac6:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
     aca:	c5 c5 fa f9          	vpsubd %ymm1,%ymm7,%ymm7
     ace:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     ad3:	c4 e2 45 40 fc       	vpmulld %ymm4,%ymm7,%ymm7
     ad8:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     add:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     ae2:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     ae7:	c4 c1 25 72 d1 08    	vpsrld $0x8,%ymm9,%ymm11
     aed:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
     af2:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     af8:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     afd:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     b01:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
     b06:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
     b0b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     b10:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     b15:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     b19:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     b1e:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     b23:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     b28:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
     b2e:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     b33:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     b38:	c5 25 fa df          	vpsubd %ymm7,%ymm11,%ymm11
     b3c:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     b41:	c4 c1 45 fa fc       	vpsubd %ymm12,%ymm7,%ymm7
     b46:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     b4b:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     b50:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     b55:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
     b5a:	c5 35 fa cb          	vpsubd %ymm3,%ymm9,%ymm9
     b5e:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     b62:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     b67:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
     b6c:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     b71:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
     b76:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b7b:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     b80:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     b85:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     b89:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     b8e:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     b93:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
     b98:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b9d:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     ba1:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
     ba6:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     baa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     baf:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     bb4:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
     bb8:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     bbc:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # c05 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xc05>
     bc3:	00 00 
     bc5:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     bc9:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     bcf:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     bd4:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     bd9:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     bdd:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
     be2:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
     be7:	49 39 c8             	cmp    %rcx,%r8
     bea:	0f 85 f0 f4 ff ff    	jne    e0 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xe0>
     bf0:	c5 f8 77             	vzeroupper
     bf3:	c5 f8 28 b4 24 20 01 	vmovaps 0x120(%rsp),%xmm6
     bfa:	00 00 
     bfc:	c5 f8 28 bc 24 30 01 	vmovaps 0x130(%rsp),%xmm7
     c03:	00 00 
     c05:	c5 78 28 84 24 40 01 	vmovaps 0x140(%rsp),%xmm8
     c0c:	00 00 
     c0e:	c5 78 28 8c 24 50 01 	vmovaps 0x150(%rsp),%xmm9
     c15:	00 00 
     c17:	c5 78 28 94 24 60 01 	vmovaps 0x160(%rsp),%xmm10
     c1e:	00 00 
     c20:	c5 78 28 9c 24 70 01 	vmovaps 0x170(%rsp),%xmm11
     c27:	00 00 
     c29:	c5 78 28 a4 24 80 01 	vmovaps 0x180(%rsp),%xmm12
     c30:	00 00 
     c32:	c5 78 28 ac 24 90 01 	vmovaps 0x190(%rsp),%xmm13
     c39:	00 00 
     c3b:	c5 78 28 b4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm14
     c42:	00 00 
     c44:	c5 78 28 bc 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm15
     c4b:	00 00 
     c4d:	48 81 c4 c8 01 00 00 	add    $0x1c8,%rsp
     c54:	c3                   	ret
     c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     c5c:	00 00 00 00 

0000000000000c60 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)>:
     c60:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
     c67:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
     c6e:	00 00 
     c70:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
     c77:	00 00 
     c79:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
     c80:	00 00 
     c82:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
     c89:	00 00 
     c8b:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
     c92:	00 00 
     c94:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
     c9b:	00 00 
     c9d:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
     ca4:	00 00 
     ca6:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
     cad:	00 00 
     caf:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
     cb6:	00 00 
     cb8:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
     cbf:	00 00 
     cc1:	48 89 c8             	mov    %rcx,%rax
     cc4:	4d 85 c0             	test   %r8,%r8
     cc7:	0f 84 6a 0b 00 00    	je     1837 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xbd7>
     ccd:	49 ff c8             	dec    %r8
     cd0:	48 89 d1             	mov    %rdx,%rcx
     cd3:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     cd8:	49 c1 e8 03          	shr    $0x3,%r8
     cdc:	c4 c1 05 72 d5 18    	vpsrld $0x18,%ymm13,%ymm15
     ce2:	4b 8d 14 40          	lea    (%r8,%r8,2),%rdx
     ce6:	4c 8d 44 d1 18       	lea    0x18(%rcx,%rdx,8),%r8
     ceb:	ba 63 04 00 00       	mov    $0x463,%edx
     cf0:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     cf4:	ba 21 00 00 00       	mov    $0x21,%edx
     cf9:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     cfe:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
     d04:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     d08:	ba 41 04 00 00       	mov    $0x441,%edx
     d0d:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     d12:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
     d17:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     d1b:	ba 00 80 00 00       	mov    $0x8000,%edx
     d20:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     d25:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
     d2b:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     d2f:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     d34:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
     d3b:	00 00 
     d3d:	0f 1f 00             	nopl   (%rax)
     d40:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
     d44:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
     d49:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     d4d:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     d51:	48 8b 10             	mov    (%rax),%rdx
     d54:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
     d59:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     d5e:	48 83 c1 18          	add    $0x18,%rcx
     d62:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     d68:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     d6e:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # d77 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x117>
     d75:	00 00 
     d77:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     d7c:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
     d81:	c4 41 7d db df       	vpand  %ymm15,%ymm0,%ymm11
     d86:	c4 a2 45 90 24 9a    	vpgatherdd %ymm7,(%rdx,%ymm11,4),%ymm4
     d8c:	48 8b 50 08          	mov    0x8(%rax),%rdx
     d90:	c4 c1 75 db ff       	vpand  %ymm15,%ymm1,%ymm7
     d95:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     d9c:	00 00 
     d9e:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
     da3:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # e0b <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1ab>
     daa:	00 
     dab:	c4 e2 55 90 0c ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm1
     db1:	48 8b 50 10          	mov    0x10(%rax),%rdx
     db5:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
     dbc:	00 00 
     dbe:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     dc2:	c5 c5 72 f3 06       	vpslld $0x6,%ymm3,%ymm7
     dc7:	c5 fd 72 f3 0a       	vpslld $0xa,%ymm3,%ymm0
     dcc:	c4 e2 55 90 14 b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm2
     dd2:	c5 d5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm5
     dd7:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     ddb:	48 8b 50 48          	mov    0x48(%rax),%rdx
     ddf:	c5 bd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm8
     de4:	c5 cd 72 f5 05       	vpslld $0x5,%ymm5,%ymm6
     de9:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     ded:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     df1:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
     df6:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # e5e <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1fe>
     dfd:	00 
     dfe:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
     e02:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # e6a <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x20a>
     e09:	00 
     e0a:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     e0e:	c5 e5 fe 44 24 60    	vpaddd 0x60(%rsp),%ymm3,%ymm0
     e14:	c4 e2 55 90 34 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm6
     e1a:	c4 e2 5d 3d f9       	vpmaxsd %ymm1,%ymm4,%ymm7
     e1f:	c5 f5 66 ec          	vpcmpgtd %ymm4,%ymm1,%ymm5
     e23:	c4 e2 5d 39 e1       	vpminsd %ymm1,%ymm4,%ymm4
     e28:	c4 62 45 3d ca       	vpmaxsd %ymm2,%ymm7,%ymm9
     e2d:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     e33:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
     e37:	c4 62 5d 39 d2       	vpminsd %ymm2,%ymm4,%ymm10
     e3c:	c4 e2 45 39 fa       	vpminsd %ymm2,%ymm7,%ymm7
     e41:	c4 62 1d 90 04 82    	vpgatherdd %ymm12,(%rdx,%ymm0,4),%ymm8
     e47:	c5 dd 66 d2          	vpcmpgtd %ymm2,%ymm4,%ymm2
     e4b:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     e50:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
     e56:	c5 7e 7f 84 24 a0 00 	vmovdqu %ymm8,0xa0(%rsp)
     e5d:	00 00 
     e5f:	c4 e2 5d 3d ff       	vpmaxsd %ymm7,%ymm4,%ymm7
     e64:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
     e68:	c4 43 7d 4c c4 50    	vpblendvb %ymm5,%ymm12,%ymm0,%ymm8
     e6e:	c4 e3 1d 4c e8 50    	vpblendvb %ymm5,%ymm0,%ymm12,%ymm5
     e74:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
     e78:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # ea1 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x241>
     e7f:	00 00 20 
     e82:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     e88:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # eb1 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x251>
     e8f:	00 00 10 
     e92:	c4 41 65 fe c0       	vpaddd %ymm8,%ymm3,%ymm8
     e97:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     e9b:	c4 a2 0d 90 0c 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm1
     ea1:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     ea6:	c4 e2 5d 90 14 aa    	vpgatherdd %ymm4,(%rdx,%ymm5,4),%ymm2
     eac:	c5 85 db a4 24 a0 00 	vpand  0xa0(%rsp),%ymm15,%ymm4
     eb3:	00 00 
     eb5:	c4 c1 4d db ef       	vpand  %ymm15,%ymm6,%ymm5
     eba:	4c 8b 48 28          	mov    0x28(%rax),%r9
     ebe:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     ec3:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
     ec8:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     ecd:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     ed1:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     ed5:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     ed9:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     ede:	c5 3d fe 84 24 e0 00 	vpaddd 0xe0(%rsp),%ymm8,%ymm8
     ee5:	00 00 
     ee7:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
     eee:	00 00 
     ef0:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     ef5:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
     efa:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
     efe:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
     f03:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     f07:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
     f0e:	00 00 
     f10:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     f15:	c4 c2 0d 90 24 89    	vpgatherdd %ymm14,(%r9,%ymm1,4),%ymm4
     f1b:	4c 8b 48 20          	mov    0x20(%rax),%r9
     f1f:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     f24:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # f8c <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x32c>
     f2b:	00 
     f2c:	c4 82 0d 90 0c 91    	vpgatherdd %ymm14,(%r9,%ymm10,4),%ymm1
     f32:	4c 8b 48 18          	mov    0x18(%rax),%r9
     f36:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     f3b:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # fa3 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x343>
     f42:	00 
     f43:	c4 82 0d 90 2c 99    	vpgatherdd %ymm14,(%r9,%ymm11,4),%ymm5
     f49:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     f4f:	4c 8b 48 40          	mov    0x40(%rax),%r9
     f53:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # fbb <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x35b>
     f5a:	00 
     f5b:	c5 f5 66 fd          	vpcmpgtd %ymm5,%ymm1,%ymm7
     f5f:	c4 62 55 3d c1       	vpmaxsd %ymm1,%ymm5,%ymm8
     f64:	c4 e2 55 39 e9       	vpminsd %ymm1,%ymm5,%ymm5
     f69:	c4 c1 5d 66 c8       	vpcmpgtd %ymm8,%ymm4,%ymm1
     f6e:	c4 62 3d 3d d4       	vpmaxsd %ymm4,%ymm8,%ymm10
     f73:	c4 62 3d 39 c4       	vpminsd %ymm4,%ymm8,%ymm8
     f78:	c4 42 55 3d c0       	vpmaxsd %ymm8,%ymm5,%ymm8
     f7d:	c4 43 0d 4c cc 70    	vpblendvb %ymm7,%ymm12,%ymm14,%ymm9
     f83:	c4 62 55 39 f4       	vpminsd %ymm4,%ymm5,%ymm14
     f88:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm9,%ymm9        # fb1 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x351>
     f8f:	00 00 10 
     f92:	c5 d5 66 e4          	vpcmpgtd %ymm4,%ymm5,%ymm4
     f96:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
     f9d:	00 00 
     f9f:	c4 41 65 fe c9       	vpaddd %ymm9,%ymm3,%ymm9
     fa4:	c4 a2 7d 90 0c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm1
     faa:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
     faf:	c5 b5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm9
     fb4:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     fb9:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     fbe:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
     fc3:	c4 e3 7d 4c 7c 24 20 	vpblendvb %ymm7,0x20(%rsp),%ymm0,%ymm7
     fca:	70 
     fcb:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
     fd1:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
     fd7:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     fdc:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm7,%ymm7        # 1005 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x3a5>
     fe3:	00 00 40 
     fe6:	c5 1d fe a4 24 e0 00 	vpaddd 0xe0(%rsp),%ymm12,%ymm12
     fed:	00 00 
     fef:	c5 fd fa ff          	vpsubd %ymm7,%ymm0,%ymm7
     ff3:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
     ff7:	c4 e2 7d 90 24 ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm4
     ffd:	c5 c5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm7
    1002:	c4 c1 75 db ef       	vpand  %ymm15,%ymm1,%ymm5
    1007:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    100c:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1011:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    1015:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    101a:	c5 c5 fa fc          	vpsubd %ymm4,%ymm7,%ymm7
    101e:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    1022:	c4 c2 45 40 fe       	vpmulld %ymm14,%ymm7,%ymm7
    1027:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    102c:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    1031:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1036:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    103b:	c5 c5 fe e4          	vpaddd %ymm4,%ymm7,%ymm4
    103f:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    1044:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1048:	c5 f5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm1
    104d:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    1054:	00 00 
    1056:	c4 c2 7d 90 3c a1    	vpgatherdd %ymm0,(%r9,%ymm4,4),%ymm7
    105c:	4c 8b 48 38          	mov    0x38(%rax),%r9
    1060:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    1067:	00 00 
    1069:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    106d:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 10d5 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x475>
    1074:	00 
    1075:	c5 7e 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm12
    107c:	00 00 
    107e:	c4 02 7d 90 0c 91    	vpgatherdd %ymm0,(%r9,%ymm10,4),%ymm9
    1084:	4c 8b 48 30          	mov    0x30(%rax),%r9
    1088:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    108c:	c5 35 db 0d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm9        # 10f4 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x494>
    1093:	00 
    1094:	c4 82 7d 90 24 99    	vpgatherdd %ymm0,(%r9,%ymm11,4),%ymm4
    109a:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    10a0:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1108 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4a8>
    10a7:	00 
    10a8:	c4 c2 5d 3d e9       	vpmaxsd %ymm9,%ymm4,%ymm5
    10ad:	c5 35 66 c4          	vpcmpgtd %ymm4,%ymm9,%ymm8
    10b1:	c4 c2 5d 39 e1       	vpminsd %ymm9,%ymm4,%ymm4
    10b6:	c5 45 66 d5          	vpcmpgtd %ymm5,%ymm7,%ymm10
    10ba:	c4 62 5d 39 df       	vpminsd %ymm7,%ymm4,%ymm11
    10bf:	c4 63 7d 4c 0c 24 80 	vpblendvb %ymm8,(%rsp),%ymm0,%ymm9
    10c6:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    10ca:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm9,%ymm9        # 10f3 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x493>
    10d1:	00 00 a0 
    10d4:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    10d9:	c4 e2 55 39 ef       	vpminsd %ymm7,%ymm5,%ymm5
    10de:	c4 41 65 fe c9       	vpaddd %ymm9,%ymm3,%ymm9
    10e3:	c4 e2 5d 3d ed       	vpmaxsd %ymm5,%ymm4,%ymm5
    10e8:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
    10ec:	c4 a2 7d 90 1c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm3
    10f2:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
    10f7:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    10fc:	c4 63 7d 4c 44 24 20 	vpblendvb %ymm8,0x20(%rsp),%ymm0,%ymm8
    1103:	80 
    1104:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
    110a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    110f:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm8,%ymm8        # 1138 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4d8>
    1116:	00 00 40 
    1119:	c4 c1 7d fa e0       	vpsubd %ymm8,%ymm0,%ymm4
    111e:	c5 7e 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm8
    1125:	00 00 
    1127:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    112b:	c4 e2 7d 90 3c a2    	vpgatherdd %ymm0,(%rdx,%ymm4,4),%ymm7
    1131:	48 8b 50 60          	mov    0x60(%rax),%rdx
    1135:	c5 dd 72 f6 10       	vpslld $0x10,%ymm6,%ymm4
    113a:	c4 c1 7d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm0
    1140:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1145:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    114a:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    114f:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1154:	c5 fd fa c7          	vpsubd %ymm7,%ymm0,%ymm0
    1158:	c5 c5 fa fb          	vpsubd %ymm3,%ymm7,%ymm7
    115c:	c4 e2 45 40 fd       	vpmulld %ymm5,%ymm7,%ymm7
    1161:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1166:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    116a:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    116f:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    1173:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    1177:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    117b:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    117f:	c4 e2 4d 90 24 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm4
    1185:	48 8b 50 68          	mov    0x68(%rax),%rdx
    1189:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    118d:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1191:	c4 e2 4d 90 1c 8a    	vpgatherdd %ymm6,(%rdx,%ymm1,4),%ymm3
    1197:	48 8b 50 70          	mov    0x70(%rax),%rdx
    119b:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    11a0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    11a5:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    11aa:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    11b0:	c5 c5 72 f1 06       	vpslld $0x6,%ymm1,%ymm7
    11b5:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 121d <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5bd>
    11bc:	00 
    11bd:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    11c4:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
    11c9:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1231 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5d1>
    11d0:	00 
    11d1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    11d5:	c5 d5 72 f2 05       	vpslld $0x5,%ymm2,%ymm5
    11da:	c5 bd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm8
    11df:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    11e3:	c5 65 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm11
    11e7:	c4 e2 5d 39 d3       	vpminsd %ymm3,%ymm4,%ymm2
    11ec:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    11f0:	c4 e2 5d 3d eb       	vpmaxsd %ymm3,%ymm4,%ymm5
    11f5:	c5 cd db 1d 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm3        # 125d <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5fd>
    11fc:	00 
    11fd:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    1203:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1208:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    120c:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    1210:	c5 e5 66 f5          	vpcmpgtd %ymm5,%ymm3,%ymm6
    1214:	c4 e3 5d 4c 24 24 b0 	vpblendvb %ymm11,(%rsp),%ymm4,%ymm4
    121b:	c4 62 6d 39 c3       	vpminsd %ymm3,%ymm2,%ymm8
    1220:	c4 e2 7d 90 3c 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm7
    1226:	c5 75 fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm1,%ymm9
    122c:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 1255 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5f5>
    1233:	00 00 60 
    1236:	c4 e2 55 3d f3       	vpmaxsd %ymm3,%ymm5,%ymm6
    123b:	c4 e2 55 39 eb       	vpminsd %ymm3,%ymm5,%ymm5
    1240:	c4 e2 6d 3d ed       	vpmaxsd %ymm5,%ymm2,%ymm5
    1245:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    1249:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    124e:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1252:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    1256:	c4 a2 0d 90 04 8a    	vpgatherdd %ymm14,(%rdx,%ymm9,4),%ymm0
    125c:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    1261:	c4 62 5d 90 14 8a    	vpgatherdd %ymm4,(%rdx,%ymm1,4),%ymm10
    1267:	c4 e3 65 4c 4c 24 20 	vpblendvb %ymm11,0x20(%rsp),%ymm3,%ymm1
    126e:	b0 
    126f:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    1273:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # 129c <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x63c>
    127a:	00 00 20 
    127d:	c4 41 45 db df       	vpand  %ymm15,%ymm7,%ymm11
    1282:	c4 c1 2d db cf       	vpand  %ymm15,%ymm10,%ymm1
    1287:	c5 35 fa ca          	vpsubd %ymm2,%ymm9,%ymm9
    128b:	c4 a2 5d 90 1c 8a    	vpgatherdd %ymm4,(%rdx,%ymm9,4),%ymm3
    1291:	c4 c1 35 72 f3 10    	vpslld $0x10,%ymm11,%ymm9
    1297:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    129c:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    12a3:	c4 c1 65 db d7       	vpand  %ymm15,%ymm3,%ymm2
    12a8:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    12ad:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    12b1:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    12b5:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    12ba:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    12bf:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    12c4:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    12c9:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    12ce:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    12d3:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    12d8:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    12dd:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    12e2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    12e7:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    12ec:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    12f1:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    12f6:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    12fa:	c4 c1 35 72 d2 08    	vpsrld $0x8,%ymm10,%ymm9
    1300:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1305:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    130a:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    130e:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
    1314:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1319:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    131e:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1323:	c4 41 25 fa d9       	vpsubd %ymm9,%ymm11,%ymm11
    1328:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    132d:	c4 41 35 fa cc       	vpsubd %ymm12,%ymm9,%ymm9
    1332:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    1337:	c4 62 25 40 dd       	vpmulld %ymm5,%ymm11,%ymm11
    133c:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    1341:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    1346:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    134a:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    134f:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1354:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
    1358:	c4 c1 75 72 d2 10    	vpsrld $0x10,%ymm10,%ymm1
    135e:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    1363:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1368:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    136d:	c5 b5 72 f7 10       	vpslld $0x10,%ymm7,%ymm9
    1372:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1377:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    137b:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    137f:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    1384:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1389:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    138e:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    1392:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1396:	c4 e2 4d 90 2c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm5
    139c:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    13a3:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    13a7:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    13ab:	c4 e2 4d 90 1c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm3
    13b1:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    13b8:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    13bd:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    13c2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    13c6:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    13cb:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    13d0:	c5 dd 72 f2 05       	vpslld $0x5,%ymm2,%ymm4
    13d5:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    13db:	c5 c5 72 f1 06       	vpslld $0x6,%ymm1,%ymm7
    13e0:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    13e7:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
    13ec:	c5 bd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm8
    13f1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    13f5:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    13f9:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    13fe:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1402:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    1406:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    140a:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    140e:	c4 e2 7d 90 3c 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm7
    1414:	c5 75 fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm1,%ymm9
    141a:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1482 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x822>
    1421:	00 
    1422:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    1427:	c4 a2 5d 90 04 8a    	vpgatherdd %ymm4,(%rdx,%ymm9,4),%ymm0
    142d:	c5 d5 db 25 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm4        # 1495 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x835>
    1434:	00 
    1435:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    143a:	c5 65 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm11
    143e:	c4 e2 5d 3d eb       	vpmaxsd %ymm3,%ymm4,%ymm5
    1443:	c4 e2 5d 39 d3       	vpminsd %ymm3,%ymm4,%ymm2
    1448:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    144e:	c5 cd db 1d 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm3        # 14b6 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x856>
    1455:	00 
    1456:	c5 e5 66 f5          	vpcmpgtd %ymm5,%ymm3,%ymm6
    145a:	c4 e3 5d 4c 24 24 b0 	vpblendvb %ymm11,(%rsp),%ymm4,%ymm4
    1461:	c4 62 6d 39 c3       	vpminsd %ymm3,%ymm2,%ymm8
    1466:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 148f <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x82f>
    146d:	00 00 60 
    1470:	c4 e2 55 3d f3       	vpmaxsd %ymm3,%ymm5,%ymm6
    1475:	c4 e2 55 39 eb       	vpminsd %ymm3,%ymm5,%ymm5
    147a:	c4 e2 6d 3d ed       	vpmaxsd %ymm5,%ymm2,%ymm5
    147f:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
    1483:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
    1488:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    148c:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    1490:	c4 62 5d 90 14 8a    	vpgatherdd %ymm4,(%rdx,%ymm1,4),%ymm10
    1496:	c4 e3 65 4c 4c 24 20 	vpblendvb %ymm11,0x20(%rsp),%ymm3,%ymm1
    149d:	b0 
    149e:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    14a2:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # 14cb <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x86b>
    14a9:	00 00 20 
    14ac:	c4 41 45 db df       	vpand  %ymm15,%ymm7,%ymm11
    14b1:	c4 c1 2d db cf       	vpand  %ymm15,%ymm10,%ymm1
    14b6:	c5 35 fa ca          	vpsubd %ymm2,%ymm9,%ymm9
    14ba:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    14bf:	c4 a2 5d 90 1c 8a    	vpgatherdd %ymm4,(%rdx,%ymm9,4),%ymm3
    14c5:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    14ca:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    14cf:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    14d6:	c4 c1 65 db d7       	vpand  %ymm15,%ymm3,%ymm2
    14db:	c4 c1 35 72 f3 10    	vpslld $0x10,%ymm11,%ymm9
    14e1:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    14e5:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    14e9:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    14ee:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    14f3:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    14f8:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    14fd:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1502:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    1507:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    150c:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1511:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1516:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    151b:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    151f:	c4 c1 35 72 d2 08    	vpsrld $0x8,%ymm10,%ymm9
    1525:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    152a:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    152f:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1533:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
    1539:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    153e:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1543:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1548:	c4 41 25 fa d9       	vpsubd %ymm9,%ymm11,%ymm11
    154d:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1552:	c4 41 35 fa cc       	vpsubd %ymm12,%ymm9,%ymm9
    1557:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    155c:	c4 62 25 40 dd       	vpmulld %ymm5,%ymm11,%ymm11
    1561:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    1566:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    156b:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    156f:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    1574:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1579:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    157e:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
    1582:	c4 c1 75 72 d2 10    	vpsrld $0x10,%ymm10,%ymm1
    1588:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    158d:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1592:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1597:	c5 b5 72 f7 10       	vpslld $0x10,%ymm7,%ymm9
    159c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    15a1:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    15a5:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    15a9:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    15ae:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    15b3:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    15b8:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    15bc:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    15c0:	c4 e2 4d 90 2c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm5
    15c6:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    15cd:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    15d1:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    15d6:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    15da:	c4 e2 4d 90 1c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm3
    15e0:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    15e7:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    15ec:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    15f1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    15f5:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    15fa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    15ff:	c5 dd 72 f2 05       	vpslld $0x5,%ymm2,%ymm4
    1604:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    160a:	c5 c5 72 f1 06       	vpslld $0x6,%ymm1,%ymm7
    160f:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    1616:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
    161b:	c5 bd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm8
    1620:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1624:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    1628:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    162d:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    1631:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1635:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1639:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    163d:	c5 75 fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm1,%ymm9
    1643:	c4 e2 7d 90 3c 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm7
    1649:	c4 a2 6d 90 04 8a    	vpgatherdd %ymm2,(%rdx,%ymm9,4),%ymm0
    164f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 16b7 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa57>
    1656:	00 
    1657:	c5 d5 db 25 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm4        # 16bf <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa5f>
    165e:	00 
    165f:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
    1664:	c5 65 66 d4          	vpcmpgtd %ymm4,%ymm3,%ymm10
    1668:	c4 e2 5d 3d eb       	vpmaxsd %ymm3,%ymm4,%ymm5
    166d:	c4 e2 5d 39 d3       	vpminsd %ymm3,%ymm4,%ymm2
    1672:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1678:	c5 cd db 25 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm4        # 16e0 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa80>
    167f:	00 
    1680:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    1684:	c4 c3 65 4c db a0    	vpblendvb %ymm10,%ymm11,%ymm3,%ymm3
    168a:	c4 62 6d 39 c4       	vpminsd %ymm4,%ymm2,%ymm8
    168f:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # 16b8 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa58>
    1696:	00 00 60 
    1699:	c4 e2 55 3d f4       	vpmaxsd %ymm4,%ymm5,%ymm6
    169e:	c4 e2 55 39 ec       	vpminsd %ymm4,%ymm5,%ymm5
    16a3:	c4 e2 6d 3d ed       	vpmaxsd %ymm5,%ymm2,%ymm5
    16a8:	c5 ed 66 d4          	vpcmpgtd %ymm4,%ymm2,%ymm2
    16ac:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    16b0:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
    16b6:	c4 e3 25 4c 4c 24 20 	vpblendvb %ymm10,0x20(%rsp),%ymm11,%ymm1
    16bd:	a0 
    16be:	c4 41 45 db df       	vpand  %ymm15,%ymm7,%ymm11
    16c3:	c4 c1 2d 72 f3 10    	vpslld $0x10,%ymm11,%ymm10
    16c9:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    16ce:	c4 e3 75 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm2        # 16f7 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa97>
    16d5:	00 00 20 
    16d8:	c4 c1 65 db cf       	vpand  %ymm15,%ymm3,%ymm1
    16dd:	c4 41 2d fe d4       	vpaddd %ymm12,%ymm10,%ymm10
    16e2:	c5 35 fa ca          	vpsubd %ymm2,%ymm9,%ymm9
    16e6:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
    16eb:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    16ef:	c4 a2 6d 90 24 8a    	vpgatherdd %ymm2,(%rdx,%ymm9,4),%ymm4
    16f5:	c4 c1 7d db d7       	vpand  %ymm15,%ymm0,%ymm2
    16fa:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    16ff:	c4 41 5d db cf       	vpand  %ymm15,%ymm4,%ymm9
    1704:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1709:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    170e:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
    1712:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1717:	c4 62 35 40 cd       	vpmulld %ymm5,%ymm9,%ymm9
    171c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    1721:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    1726:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    172b:	c5 a5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm11
    1730:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1735:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    173a:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    173f:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1744:	c5 b5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm9
    1749:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    174e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1753:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    1758:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    175c:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1761:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1766:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    176b:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    1771:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1776:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    177b:	c4 41 25 fa d9       	vpsubd %ymm9,%ymm11,%ymm11
    1780:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1785:	c4 41 35 fa cc       	vpsubd %ymm12,%ymm9,%ymm9
    178a:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    178f:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    1793:	c4 62 25 40 dd       	vpmulld %ymm5,%ymm11,%ymm11
    1798:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
    179d:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    17a1:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    17a5:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    17aa:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    17af:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
    17b4:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    17b9:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    17be:	c4 41 35 fe ca       	vpaddd %ymm10,%ymm9,%ymm9
    17c3:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    17c8:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    17cd:	c5 b5 72 f7 10       	vpslld $0x10,%ymm7,%ymm9
    17d2:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    17d7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    17db:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    17e0:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
    17e5:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    17ea:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    17ee:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    17f3:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    17f8:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    17fc:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1800:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 1849 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xbe9>
    1807:	00 00 
    1809:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    180d:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1813:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1818:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    181d:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1821:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
    1826:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
    182b:	49 39 c8             	cmp    %rcx,%r8
    182e:	0f 85 0c f5 ff ff    	jne    d40 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xe0>
    1834:	c5 f8 77             	vzeroupper
    1837:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
    183e:	00 00 
    1840:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
    1847:	00 00 
    1849:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
    1850:	00 00 
    1852:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
    1859:	00 00 
    185b:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
    1862:	00 00 
    1864:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
    186b:	00 00 
    186d:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
    1874:	00 00 
    1876:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
    187d:	00 00 
    187f:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
    1886:	00 00 
    1888:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
    188f:	00 00 
    1891:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
    1898:	c3                   	ret
    1899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000018a0 <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    18a0:	48 89 d0             	mov    %rdx,%rax
    18a3:	4c 89 c2             	mov    %r8,%rdx
    18a6:	48 83 f8 04          	cmp    $0x4,%rax
    18aa:	74 14                	je     18c0 <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20>
    18ac:	49 89 d0             	mov    %rdx,%r8
    18af:	48 89 c2             	mov    %rax,%rdx
    18b2:	e9 00 00 00 00       	jmp    18b7 <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17>
    18b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    18be:	00 00 
    18c0:	81 79 50 41 04 00 00 	cmpl   $0x441,0x50(%rcx)
    18c7:	75 e3                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18c9:	83 79 54 21          	cmpl   $0x21,0x54(%rcx)
    18cd:	75 dd                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18cf:	81 b9 b0 00 00 00 41 	cmpl   $0x441,0xb0(%rcx)
    18d6:	04 00 00 
    18d9:	75 d1                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18db:	83 b9 b4 00 00 00 21 	cmpl   $0x21,0xb4(%rcx)
    18e2:	75 c8                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18e4:	81 b9 10 01 00 00 41 	cmpl   $0x441,0x110(%rcx)
    18eb:	04 00 00 
    18ee:	75 bc                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18f0:	83 b9 14 01 00 00 21 	cmpl   $0x21,0x114(%rcx)
    18f7:	75 b3                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    18f9:	81 b9 70 01 00 00 41 	cmpl   $0x441,0x170(%rcx)
    1900:	04 00 00 
    1903:	75 a7                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    1905:	83 b9 74 01 00 00 21 	cmpl   $0x21,0x174(%rcx)
    190c:	75 9e                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    190e:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    1912:	75 98                	jne    18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    1914:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    191b:	74 8f                	je     18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    191d:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    1924:	74 86                	je     18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    1926:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    192d:	0f 84 79 ff ff ff    	je     18ac <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    1933:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    1937:	4d 89 c8             	mov    %r9,%r8
    193a:	74 05                	je     1941 <jshc_grid_geometry::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa1>
    193c:	e9 bf e6 ff ff       	jmp    0 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)>
    1941:	e9 1a f3 ff ff       	jmp    c60 <void jshc_grid_geometry::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)>
    1946:	90                   	nop
    1947:	90                   	nop
    1948:	90                   	nop
    1949:	90                   	nop
    194a:	90                   	nop
    194b:	90                   	nop
    194c:	90                   	nop
    194d:	90                   	nop
    194e:	90                   	nop
    194f:	90                   	nop
