"""组合两个互补静态信号：常量地址缩短依赖，中值网络减少临时寄存器。"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];out=root/'experiments/skylake-grid-geometry-runtime';out.mkdir(exist_ok=False)
base=root/'experiments/skylake-grid33-runtime'
for name in ('channel_avx2.cpp','channel_runtime.cpp','channel_views.hpp','CMakeLists.txt'):
    source=(base/name).read_text(encoding='utf-8').replace('jshc_grid33','jshc_grid_geometry').replace('jshc_skylake_grid33','jshc_skylake_grid_geometry')
    if name=='channel_runtime.cpp':source=source.replace('return 19;','return 20;')
    if name=='channel_avx2.cpp':
        a=source.index('  first=_mm256_blendv_epi8(sr,sg,_mm256_cmpgt_epi32(y,x))')
        b=source.index('\n}',a)
        geo=(root/'experiments/skylake-geometry-runtime/channel_avx2.cpp').read_text(encoding='utf-8')
        c=geo.index('  const __m256i xy=_mm256_cmpgt_epi32(y,x)');d=geo.index('\n}',c)
        source=source[:a]+geo[c:d]+source[b:]
    (out/name).write_text(source,encoding='utf-8',newline='\n')
plan=json.loads((root/'experiments/skylake-grid33-v1.json').read_text(encoding='utf-8'))
plan['purpose']='组合一次固定33³地址与已冻结中值网络，针对二者相反的寄存器压力结果；非参数扫描'
plan['candidate']='仅组合修订17和19的源变更；不再改变排序网络、移位表达式、网格或表内容；其他网格直接原AVX2对象'
plan['cmake_project']='experiments/skylake-grid-geometry-runtime';plan['cmake_targets']=['jshc_skylake_reference','jshc_skylake_grid_geometry']
plan['revisions']={'reference':5,'candidate':20}
plan['grid33_policy']['combination_evidence']={
 'geometry':'575→541指令，rsp41→30，周期44732→43633；未达3%单独停止，无数值调用',
 'grid33':'周期44732→40733，rsp41→49；栈门槛失败单独停止，无数值调用',
 'hypothesis':'前者减少临时寄存器可抵消后者常量表达式的活跃区间；组合只一次，两家族仍须原3%周期且rsp不增',
 'stop':'本组合若失败就结束此三方向研究，不添加组合、变体或数值计时'}
plan['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(plan['source_sha256'])|{p.relative_to(root).as_posix() for p in out.iterdir()})}
(root/'experiments/skylake-grid-geometry-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('固定组合候选已生成；数值调用0')
