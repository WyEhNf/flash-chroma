
artifacts\skylake-domain-delta-build-v1\CMakeFiles\jshc_skylake_domain_delta.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)>:
   0:	57                   	push   %rdi
   1:	56                   	push   %rsi
   2:	53                   	push   %rbx
   3:	48 81 ec e0 01 00 00 	sub    $0x1e0,%rsp
   a:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
  11:	00 00 
  13:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
  1a:	00 00 
  1c:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
  23:	00 00 
  25:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
  2c:	00 00 
  2e:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
  35:	00 00 
  37:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
  3e:	00 00 
  40:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
  47:	00 00 
  49:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
  50:	00 00 
  52:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
  59:	00 00 
  5b:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
  62:	00 00 
  64:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  6b:	00 
  6c:	48 85 c0             	test   %rax,%rax
  6f:	0f 84 98 05 00 00    	je     60d <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x60d>
  75:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
  7a:	49 8d b8 00 04 00 00 	lea    0x400(%r8),%rdi
  81:	49 8d b0 00 08 00 00 	lea    0x800(%r8),%rsi
  88:	48 ff c8             	dec    %rax
  8b:	48 c1 e8 03          	shr    $0x3,%rax
  8f:	c4 c1 0d 72 d4 18    	vpsrld $0x18,%ymm12,%ymm14
  95:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  99:	49 8d 5c c1 18       	lea    0x18(%r9,%rax,8),%rbx
  9e:	b8 00 80 00 00       	mov    $0x8000,%eax
  a3:	c5 f9 6e e0          	vmovd  %eax,%xmm4
  a7:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
  ac:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
  b3:	00 00 
  b5:	0f 1f 00             	nopl   (%rax)
  b8:	c4 c1 7a 6f 01       	vmovdqu (%r9),%xmm0
  bd:	c4 c1 7a 7e 49 10    	vmovq  0x10(%r9),%xmm1
  c3:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
  c7:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
  cb:	48 8b 01             	mov    (%rcx),%rax
  ce:	44 8b 59 54          	mov    0x54(%rcx),%r11d
  d2:	49 83 c1 18          	add    $0x18,%r9
  d6:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
  dc:	44 8b 51 50          	mov    0x50(%rcx),%r10d
  e0:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
  e6:	c4 41 79 6e fb       	vmovd  %r11d,%xmm15
  eb:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # f4 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0xf4>
  f2:	00 00 
  f4:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
  f9:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
  fe:	c5 95 72 d0 10       	vpsrld $0x10,%ymm0,%ymm13
 103:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
 108:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
 10d:	c4 e2 5d 90 1c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm3
 113:	48 8b 41 08          	mov    0x8(%rcx),%rax
 117:	c4 41 75 db de       	vpand  %ymm14,%ymm1,%ymm11
 11c:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
 121:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
 126:	47 8d 54 13 01       	lea    0x1(%r11,%r10,1),%r10d
 12b:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 193 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x193>
 132:	00 
 133:	c4 a2 45 90 24 98    	vpgatherdd %ymm7,(%rax,%ymm11,4),%ymm4
 139:	c4 e2 4d 40 f2       	vpmulld %ymm2,%ymm6,%ymm6
 13e:	48 8b 41 10          	mov    0x10(%rcx),%rax
 142:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 146:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
 14b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1b3 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x1b3>
 152:	00 
 153:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
 158:	c4 a2 45 90 2c a8    	vpgatherdd %ymm7,(%rax,%ymm13,4),%ymm5
 15e:	48 8b 41 48          	mov    0x48(%rcx),%rax
 162:	c5 c5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm7
 167:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1cf <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x1cf>
 16e:	00 
 16f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
 173:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
 177:	c5 75 fe d7          	vpaddd %ymm7,%ymm1,%ymm10
 17b:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
 180:	c4 a2 4d 90 3c 90    	vpgatherdd %ymm6,(%rax,%ymm10,4),%ymm7
 186:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
 18b:	c4 41 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm9
 190:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
 196:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
 19a:	c4 e2 65 3d fc       	vpmaxsd %ymm4,%ymm3,%ymm7
 19f:	c4 a2 75 90 34 88    	vpgatherdd %ymm1,(%rax,%ymm9,4),%ymm6
 1a5:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
 1aa:	c5 d5 66 cf          	vpcmpgtd %ymm7,%ymm5,%ymm1
 1ae:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
 1b5:	00 00 
 1b7:	c5 dd 66 f3          	vpcmpgtd %ymm3,%ymm4,%ymm6
 1bb:	c5 7e 6f 04 24       	vmovdqu (%rsp),%ymm8
 1c0:	c5 7e 7f 54 24 20    	vmovdqu %ymm10,0x20(%rsp)
 1c6:	c4 c3 3d 4c f7 60    	vpblendvb %ymm6,%ymm15,%ymm8,%ymm6
 1cc:	c4 62 65 39 c4       	vpminsd %ymm4,%ymm3,%ymm8
 1d1:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm6,%ymm6        # 1fa <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x1fa>
 1d8:	00 00 10 
 1db:	c4 e2 45 3d cd       	vpmaxsd %ymm5,%ymm7,%ymm1
 1e0:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 1e4:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
 1e9:	c5 fe 7f 8c 24 e0 00 	vmovdqu %ymm1,0xe0(%rsp)
 1f0:	00 00 
 1f2:	c4 e2 3d 39 d5       	vpminsd %ymm5,%ymm8,%ymm2
 1f7:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
 1fc:	c4 e2 45 90 0c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm1
 202:	c5 e5 66 f4          	vpcmpgtd %ymm4,%ymm3,%ymm6
 206:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 20a:	c5 3d 66 c5          	vpcmpgtd %ymm5,%ymm8,%ymm8
 20e:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
 213:	c4 c3 2d 4c f7 60    	vpblendvb %ymm6,%ymm15,%ymm10,%ymm6
 219:	c5 65 fe d4          	vpaddd %ymm4,%ymm3,%ymm10
 21d:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm6,%ymm6        # 246 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x246>
 224:	00 00 80 
 227:	c5 7e 7f 4c 24 60    	vmovdqu %ymm9,0x60(%rsp)
 22d:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
 231:	c5 7d 6f ca          	vmovdqa %ymm2,%ymm9
 235:	c4 62 45 90 04 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm8
 23b:	c5 fe 7f 94 24 c0 00 	vmovdqu %ymm2,0xc0(%rsp)
 242:	00 00 
 244:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
 24b:	00 00 
 24d:	c5 8d db 7c 24 40    	vpand  0x40(%rsp),%ymm14,%ymm7
 253:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
 258:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
 25c:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
 261:	c4 41 55 fa c9       	vpsubd %ymm9,%ymm5,%ymm9
 266:	c5 cd fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm6,%ymm6
 26d:	00 00 
 26f:	c4 41 35 fe d2       	vpaddd %ymm10,%ymm9,%ymm10
 274:	c5 3d fa c9          	vpsubd %ymm1,%ymm8,%ymm9
 278:	c4 42 2d 40 c9       	vpmulld %ymm9,%ymm10,%ymm9
 27d:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
 281:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 285:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
 28a:	c5 fe 6f 14 24       	vmovdqu (%rsp),%ymm2
 28f:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
 293:	c5 0d db 8c 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm9
 29a:	00 00 
 29c:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
 2a1:	c4 62 35 40 8c 24 c0 	vpmulld 0xc0(%rsp),%ymm9,%ymm9
 2a8:	00 00 00 
 2ab:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
 2af:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
 2b4:	c5 bd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm8
 2b9:	c5 7e 7f 84 24 20 01 	vmovdqu %ymm8,0x120(%rsp)
 2c0:	00 00 
 2c2:	c4 c2 45 90 0c 80    	vpgatherdd %ymm7,(%r8,%ymm0,4),%ymm1
 2c8:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 2cc:	c4 22 45 90 0c 9f    	vpgatherdd %ymm7,(%rdi,%ymm11,4),%ymm9
 2d2:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
 2d6:	c4 22 45 90 1c ae    	vpgatherdd %ymm7,(%rsi,%ymm13,4),%ymm11
 2dc:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
 2e2:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
 2e9:	00 00 
 2eb:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
 2f0:	c4 c1 4d 72 f3 10    	vpslld $0x10,%ymm11,%ymm6
 2f6:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
 2fd:	00 00 
 2ff:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
 304:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
 309:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
 30d:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
 311:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
 316:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
 31a:	c4 62 75 3d c0       	vpmaxsd %ymm0,%ymm1,%ymm8
 31f:	c5 7d 66 d9          	vpcmpgtd %ymm1,%ymm0,%ymm11
 323:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
 328:	c4 62 75 39 e8       	vpminsd %ymm0,%ymm1,%ymm13
 32d:	c5 4d fe d0          	vpaddd %ymm0,%ymm6,%ymm10
 331:	c5 f5 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm0
 335:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
 33a:	c4 43 6d 4c df b0    	vpblendvb %ymm11,%ymm15,%ymm2,%ymm11
 340:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
 344:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm11,%ymm11        # 36d <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x36d>
 34b:	00 00 70 
 34e:	c4 e2 15 39 fe       	vpminsd %ymm6,%ymm13,%ymm7
 353:	c5 25 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm11,%ymm11
 359:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
 360:	00 00 
 362:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
 366:	c5 fe 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm6
 36c:	c4 a2 6d 90 3c 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm7
 372:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
 377:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
 37b:	c5 c5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm7
 380:	c4 c3 25 4c c7 00    	vpblendvb %ymm0,%ymm15,%ymm11,%ymm0
 386:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
 38b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 3b4 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x3b4>
 392:	00 00 d0 
 395:	c5 cd fa c0          	vpsubd %ymm0,%ymm6,%ymm0
 399:	c4 62 6d 90 1c 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm11
 39f:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
 3a5:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
 3ab:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
 3b0:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
 3b7:	00 00 
 3b9:	c5 bd fe 94 24 00 01 	vpaddd 0x100(%rsp),%ymm8,%ymm2
 3c0:	00 00 
 3c2:	c4 41 25 db de       	vpand  %ymm14,%ymm11,%ymm11
 3c7:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
 3cc:	44 8b 52 20          	mov    0x20(%rdx),%r10d
 3d0:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
 3d5:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
 3db:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
 3df:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
 3e4:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
 3e9:	c5 25 fa d7          	vpsubd %ymm7,%ymm11,%ymm10
 3ed:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
 3f2:	c5 7e 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm11
 3f9:	00 00 
 3fb:	c4 c1 45 fa fd       	vpsubd %ymm13,%ymm7,%ymm7
 400:	c4 42 75 40 d2       	vpmulld %ymm10,%ymm1,%ymm10
 405:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
 40a:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
 411:	00 00 
 413:	c4 e2 4d 40 b4 24 00 	vpmulld 0x100(%rsp),%ymm6,%ymm6
 41a:	01 00 00 
 41d:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
 422:	c4 c1 75 72 e3 10    	vpsrad $0x10,%ymm11,%ymm1
 428:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
 42c:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
 430:	c4 c1 75 72 e1 10    	vpsrad $0x10,%ymm9,%ymm1
 436:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
 43a:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
 441:	00 00 
 443:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
 447:	c5 55 fe cc          	vpaddd %ymm4,%ymm5,%ymm9
 44b:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
 450:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
 454:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
 458:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
 45c:	c4 e2 75 3d fc       	vpmaxsd %ymm4,%ymm1,%ymm7
 461:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
 465:	c4 62 75 39 c4       	vpminsd %ymm4,%ymm1,%ymm8
 46a:	c5 d5 66 df          	vpcmpgtd %ymm7,%ymm5,%ymm3
 46e:	c5 f5 66 e4          	vpcmpgtd %ymm4,%ymm1,%ymm4
 472:	c4 62 3d 39 d5       	vpminsd %ymm5,%ymm8,%ymm10
 477:	c5 3d 66 c5          	vpcmpgtd %ymm5,%ymm8,%ymm8
 47b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
 480:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
 485:	c4 c3 15 4c f7 60    	vpblendvb %ymm6,%ymm15,%ymm13,%ymm6
 48b:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm6,%ymm6        # 4b4 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x4b4>
 492:	00 00 30 
 495:	c5 cd fe 74 24 20    	vpaddd 0x20(%rsp),%ymm6,%ymm6
 49b:	c4 e2 6d 90 1c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm3
 4a1:	c4 c3 15 4c d7 40    	vpblendvb %ymm4,%ymm15,%ymm13,%ymm2
 4a7:	c5 fe 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm6
 4ad:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
 4b3:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm2,%ymm2        # 4dc <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x4dc>
 4ba:	00 00 80 
 4bd:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
 4c2:	c4 41 45 fe c2       	vpaddd %ymm10,%ymm7,%ymm8
 4c7:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
 4cb:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
 4d2:	00 00 
 4d4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
 4d9:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
 4de:	c4 e2 15 90 2c 90    	vpgatherdd %ymm13,(%rax,%ymm2,4),%ymm5
 4e4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
 4e9:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
 4ee:	8b 42 24             	mov    0x24(%rdx),%eax
 4f1:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
 4f6:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
 4fb:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
 500:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
 505:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
 50a:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
 50f:	c5 55 fa c3          	vpsubd %ymm3,%ymm5,%ymm8
 513:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
 517:	c5 fe 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm5
 51e:	00 00 
 520:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
 525:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
 529:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
 52e:	c5 cd fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm6,%ymm6
 535:	00 00 
 537:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
 53c:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
 541:	44 0f af d0          	imul   %eax,%r10d
 545:	c5 ed fe db          	vpaddd %ymm3,%ymm2,%ymm3
 549:	c4 e2 7d 58 52 10    	vpbroadcastd 0x10(%rdx),%ymm2
 54f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
 553:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
 557:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
 55b:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
 55f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
 564:	c5 f9 6e d0          	vmovd  %eax,%xmm2
 568:	48 8b 02             	mov    (%rdx),%rax
 56b:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
 570:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
 574:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
 579:	c4 e2 7d 58 52 18    	vpbroadcastd 0x18(%rdx),%ymm2
 57f:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
 583:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
 588:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
 58d:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
 591:	c4 e2 7d 58 4a 08    	vpbroadcastd 0x8(%rdx),%ymm1
 597:	c5 d5 fa c9          	vpsubd %ymm1,%ymm5,%ymm1
 59b:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
 5a0:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
 5a4:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
 5a8:	c4 e2 65 90 0c 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm1
 5ae:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
 5b3:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
 5b8:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
 5bd:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
 5c2:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
 5c7:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
 5cc:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
 5d0:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
 5d4:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 61d <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0x61d>
 5db:	00 00 
 5dd:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
 5e1:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
 5e7:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
 5ec:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
 5f1:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
 5f5:	c4 c1 79 d6 41 f8    	vmovq  %xmm0,-0x8(%r9)
 5fb:	c4 c1 7a 7f 49 e8    	vmovdqu %xmm1,-0x18(%r9)
 601:	4c 39 cb             	cmp    %r9,%rbx
 604:	0f 85 ae fa ff ff    	jne    b8 <jshc_channel::avx2_chain_domain_delta(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned int const*, unsigned char*, unsigned long long)+0xb8>
 60a:	c5 f8 77             	vzeroupper
 60d:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
 614:	00 00 
 616:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
 61d:	00 00 
 61f:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
 626:	00 00 
 628:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
 62f:	00 00 
 631:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
 638:	00 00 
 63a:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
 641:	00 00 
 643:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
 64a:	00 00 
 64c:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
 653:	00 00 
 655:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
 65c:	00 00 
 65e:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
 665:	00 00 
 667:	48 81 c4 e0 01 00 00 	add    $0x1e0,%rsp
 66e:	5b                   	pop    %rbx
 66f:	5e                   	pop    %rsi
 670:	5f                   	pop    %rdi
 671:	c3                   	ret
 672:	90                   	nop
 673:	90                   	nop
 674:	90                   	nop
 675:	90                   	nop
 676:	90                   	nop
 677:	90                   	nop
 678:	90                   	nop
 679:	90                   	nop
 67a:	90                   	nop
 67b:	90                   	nop
 67c:	90                   	nop
 67d:	90                   	nop
 67e:	90                   	nop
 67f:	90                   	nop
