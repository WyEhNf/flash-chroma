"""生成获证快路径的坐标差组合；原始坐标与两个回退对象完全保留。"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];base=root/'experiments/skylake-domain-isolated-runtime'
out=root/'experiments/skylake-domain-delta-runtime';out.mkdir(exist_ok=False)
for name in ('channel_views.hpp','suffix_cache.hpp'):
 s=(base/name).read_text(encoding='utf-8')
 if name=='suffix_cache.hpp':s += '\nnamespace jshc_channel {\nvoid avx2_chain_domain_delta(const View*,const SuffixCacheView&,const uint32_t*,uint8_t*,size_t) noexcept;\n}\n'
 (out/name).write_text(s,encoding='utf-8',newline='\n')
s=(base/'channel_avx2.cpp').read_text(encoding='utf-8')
s=s.replace('void transform(const View& v,Rgb& rgb)', 'void transform(const View& v,const uint32_t* deltas,Rgb& rgb)')
a=s.index('  const __m256i r=channel<0>');b=s.index('\n  rgb.r=r;rgb.g=g;rgb.b=b;',a)
replacement='''  const __m256i r=channel<0>(v,base,n0,n3,x,y,z);
  const __m256i dr=gather(deltas,rgb.r),dg=gather(deltas+256,rgb.g),db=gather(deltas+512,rgb.b);
  const __m256i g=channel<1>(v,base,n0,n3,
      _mm256_add_epi32(x,_mm256_srai_epi32(_mm256_slli_epi32(dr,16),16)),
      _mm256_add_epi32(y,_mm256_srai_epi32(_mm256_slli_epi32(dg,16),16)),
      _mm256_add_epi32(z,_mm256_srai_epi32(_mm256_slli_epi32(db,16),16)));
  const __m256i b=channel<2>(v,base,n0,n3,_mm256_add_epi32(x,_mm256_srai_epi32(dr,16)),
      _mm256_add_epi32(y,_mm256_srai_epi32(dg,16)),_mm256_add_epi32(z,_mm256_srai_epi32(db,16)));'''
s=s[:a]+replacement+s[b:]
s=s.replace('void avx2_chain_domain(const View* chain,const SuffixCacheView& cache,uint8_t* data,size_t pixels)',
    'void avx2_chain_domain_delta(const View* chain,const SuffixCacheView& cache,const uint32_t* deltas,uint8_t* data,size_t pixels)')
s=s.replace('transform<false>(chain[0],rgb)','transform<false>(chain[0],deltas,rgb)')
(out/'channel_avx2.cpp').write_text(s,encoding='utf-8',newline='\n')
s=(base/'channel_runtime.cpp').read_text(encoding='utf-8')
s=s.replace('  bool domain_proven = false;','  bool domain_proven = false;\n  std::vector<uint32_t> coordinate_deltas;')
s=s.replace('sizeof(Handle)==248','sizeof(Handle)==272').replace('域证明标志必须使用原Handle尾部填充','增加一个owned差值表vector，原View与回退描述符不变')
needle='  info.prepare_seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();'
insert='''  // 证书先按原九表完成；新表只服务已经获证的原固定布局，原表/标量/尾部保持原样。
  if(domain_fast_enabled(h)) {
    const auto& v=h.views[0];bool eligible=true;
    for(int a=0;a<3;++a)for(int code=0;code<256;++code)for(int c=1;c<3;++c) {
      const int d=int(v.axes[c][a][code]&0x1ffff)-int(v.axes[0][a][code]&0x1ffff);
      eligible=eligible && d>=-32768 && d<=32767;
    }
    if(eligible)try {
      h.coordinate_deltas.resize(768);
      for(int a=0;a<3;++a)for(int code=0;code<256;++code) {
        const int r=int(v.axes[0][a][code]&0x1ffff);
        const uint32_t g=uint32_t(int(v.axes[1][a][code]&0x1ffff)-r)&65535;
        const uint32_t b=uint32_t(int(v.axes[2][a][code]&0x1ffff)-r)&65535;
        h.coordinate_deltas[a*256+code]=g|(b<<16);
      }
    }catch(const std::bad_alloc&) {std::vector<uint32_t>().swap(h.coordinate_deltas);}
  }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
needle='if(domain_fast)jshc_channel::avx2_chain_domain(h.views.data(),h.cache_view,data,vectorized);'
s=s.replace(needle,'''if(domain_fast && !h.coordinate_deltas.empty())jshc_channel::avx2_chain_domain_delta(h.views.data(),h.cache_view,h.coordinate_deltas.data(),data,vectorized);
        else if(domain_fast)jshc_channel::avx2_chain_domain(h.views.data(),h.cache_view,data,vectorized);''')
s=s.replace('return 16;','return 21;')
s=s.replace('uint32_t jshc_cc_revision(void)', 'uint32_t jshc_cc_domain_delta_enabled(const void* handle) {return handle && !static_cast<const Handle*>(handle)->coordinate_deltas.empty()?1:0;}\nuint32_t jshc_cc_revision(void)')
s=s.replace('bytes+=h.cache.capacity()*sizeof(uint32_t);','bytes+=h.cache.capacity()*sizeof(uint32_t)+h.coordinate_deltas.capacity()*sizeof(uint32_t);')
(out/'channel_runtime.cpp').write_text(s,encoding='utf-8',newline='\n')
cmake=(base/'CMakeLists.txt').read_text(encoding='utf-8').replace('jshc_skylake_domain_isolated','jshc_skylake_domain_delta')
cmake=cmake.replace('"${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")',
    '"${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")')
cmake=cmake.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")',
    '"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp")')
cmake=cmake.replace('set_source_files_properties(\n', 'set_source_files_properties(\n  "${JSHC_ROOT}/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp"\n')
(out/'CMakeLists.txt').write_text(cmake,encoding='utf-8',newline='\n')
plan=json.loads((root/'experiments/skylake-domain-isolated-v1.json').read_text(encoding='utf-8'))
plan.pop('deadline_shanghai',None)
plan['purpose']='以当前较快的修订16为参考，仅为完整域已获证的非共享首级加无损双差值表；实测组合，不相乘历史收益'
plan['base_commit']='bdddc44';plan['candidate']='额外3072字节只读坐标差表；不改原坐标或View，原两个AVX2对象直接保留，失败回退修订16'
plan['cmake_project']='experiments/skylake-domain-delta-runtime';plan['cmake_targets']=['jshc_skylake_reference','jshc_skylake_domain_delta'];plan['revisions']={'reference':16,'candidate':21}
plan['domain_delta_policy']={'eligible':'先按原九表完成域证书/布局证明，再完整检查三轴256码值G-R/B-R在int16范围；否则走原16',
 'additional_capacity':'Handle增加24字节，启用时额外768*u32=3072字节；分配失败原16，临时异常回退未故障注入',
 'static_gate':'18→15gather唯一实际循环；Skylake周期至少下降3%，吞吐比不高于1.03，rsp最多增加10%；两个原对象同字节',
 'numerical':'基础55+6、缓存槽/命中、域状态/范围、正负斜率四网格及int16边界/越界的获证分派；再完整单级/四级256³和100照片',
 'performance':'唯一四进程AB/BA/BA/AB，1/4线程平衡，每配置5轮100图；每轮外部SHA；中位至少3%提速，最差进程不退化2%，copy+apply与准备+100图不退化',
 'stop':'候选一次冻结；任一门槛失败保留，不追加参数或重测；不把AMD当Skylake成绩'}
plan['domain_cache_policy']['persistent_model_byte_delta']='新阶段：Handle+24；差值表启用另+3072，不沿用原容量相等断言'
names=set(plan['source_sha256'])|{p.relative_to(root).as_posix() for p in out.iterdir()}
plan['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
(root/'experiments/skylake-domain-delta-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('获证坐标差候选已冻结；新增数值调用0')
