
artifacts\skylake-grid33-build-v1\CMakeFiles\jshc_skylake_grid33.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)>:
       0:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
       7:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
      5f:	00 00 
      61:	48 89 c8             	mov    %rcx,%rax
      64:	4d 85 c0             	test   %r8,%r8
      67:	0f 84 d7 0b 00 00    	je     c44 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xc44>
      6d:	49 ff c8             	dec    %r8
      70:	48 89 d1             	mov    %rdx,%rcx
      73:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
      78:	49 c1 e8 03          	shr    $0x3,%r8
      7c:	c4 c1 2d 72 d6 18    	vpsrld $0x18,%ymm14,%ymm10
      82:	4b 8d 14 40          	lea    (%r8,%r8,2),%rdx
      86:	4c 8d 44 d1 18       	lea    0x18(%rcx,%rdx,8),%r8
      8b:	ba 63 04 00 00       	mov    $0x463,%edx
      90:	c5 f9 6e da          	vmovd  %edx,%xmm3
      94:	ba 21 00 00 00       	mov    $0x21,%edx
      99:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      9e:	c5 fe 7f 5c 24 60    	vmovdqu %ymm3,0x60(%rsp)
      a4:	c5 f9 6e da          	vmovd  %edx,%xmm3
      a8:	ba 41 04 00 00       	mov    $0x441,%edx
      ad:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      b2:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
      b7:	c5 f9 6e da          	vmovd  %edx,%xmm3
      bb:	ba 00 80 00 00       	mov    $0x8000,%edx
      c0:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      c5:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
      cb:	c5 f9 6e da          	vmovd  %edx,%xmm3
      cf:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      d4:	c5 fe 7f 9c 24 e0 00 	vmovdqu %ymm3,0xe0(%rsp)
      db:	00 00 
      dd:	0f 1f 00             	nopl   (%rax)
      e0:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
      e4:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
      e9:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
      ed:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
      f1:	48 8b 10             	mov    (%rax),%rdx
      f4:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
      f9:	4c 8b 48 18          	mov    0x18(%rax),%r9
      fd:	48 83 c1 18          	add    $0x18,%rcx
     101:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     107:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     10d:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 116 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x116>
     114:	00 00 
     116:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
     11b:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     120:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     125:	c4 e2 55 90 1c 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm3
     12b:	48 8b 50 08          	mov    0x8(%rax),%rdx
     12f:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     134:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     138:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     13d:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1a5 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1a5>
     144:	00 
     145:	c4 e2 55 90 24 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm4
     14b:	48 8b 50 10          	mov    0x10(%rax),%rdx
     14f:	c5 a5 72 f1 06       	vpslld $0x6,%ymm1,%ymm11
     154:	c5 bd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm8
     159:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1c1 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1c1>
     160:	00 
     161:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
     167:	c5 c5 72 f1 0a       	vpslld $0xa,%ymm1,%ymm7
     16c:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
     171:	48 8b 50 48          	mov    0x48(%rax),%rdx
     175:	c5 9d 72 d5 11       	vpsrld $0x11,%ymm5,%ymm12
     17a:	c4 c1 35 72 f0 05    	vpslld $0x5,%ymm8,%ymm9
     180:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     185:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     18a:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
     18f:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     194:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     198:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 200 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x200>
     19f:	00 
     1a0:	c5 65 fe e4          	vpaddd %ymm4,%ymm3,%ymm12
     1a4:	c4 e2 15 90 3c 8a    	vpgatherdd %ymm13,(%rdx,%ymm1,4),%ymm7
     1aa:	c5 75 fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm1,%ymm11
     1b0:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     1b6:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     1bd:	00 00 
     1bf:	c5 dd 66 fb          	vpcmpgtd %ymm3,%ymm4,%ymm7
     1c3:	c4 22 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm13
     1c9:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     1ce:	c5 7e 7f ac 24 c0 00 	vmovdqu %ymm13,0xc0(%rsp)
     1d5:	00 00 
     1d7:	c4 42 3d 90 3c 81    	vpgatherdd %ymm8,(%r9,%ymm0,4),%ymm15
     1dd:	4c 8b 48 20          	mov    0x20(%rax),%r9
     1e1:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     1e6:	c4 c2 3d 90 04 91    	vpgatherdd %ymm8,(%r9,%ymm2,4),%ymm0
     1ec:	4c 8b 48 28          	mov    0x28(%rax),%r9
     1f0:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     1f5:	c4 c2 3d 90 14 b1    	vpgatherdd %ymm8,(%r9,%ymm6,4),%ymm2
     1fb:	c4 62 65 3d c4       	vpmaxsd %ymm4,%ymm3,%ymm8
     200:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
     206:	c5 2d db ac 24 80 00 	vpand  0x80(%rsp),%ymm10,%ymm13
     20d:	00 00 
     20f:	c4 c1 55 66 f0       	vpcmpgtd %ymm8,%ymm5,%ymm6
     214:	c4 e2 3d 3d cd       	vpmaxsd %ymm5,%ymm8,%ymm1
     219:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     21e:	c4 e3 35 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm9,%ymm7
     225:	c4 62 65 39 cc       	vpminsd %ymm4,%ymm3,%ymm9
     22a:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm7,%ymm7        # 253 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x253>
     231:	00 00 60 
     234:	c4 e2 35 39 f5       	vpminsd %ymm5,%ymm9,%ymm6
     239:	c5 c5 fe 7c 24 40    	vpaddd 0x40(%rsp),%ymm7,%ymm7
     23f:	c5 fe 7f b4 24 00 01 	vmovdqu %ymm6,0x100(%rsp)
     246:	00 00 
     248:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
     24c:	c4 e2 3d 90 34 ba    	vpgatherdd %ymm8,(%rdx,%ymm7,4),%ymm6
     252:	c5 e5 66 fc          	vpcmpgtd %ymm4,%ymm3,%ymm7
     256:	c5 7e 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm8
     25c:	c5 7e 7f 9c 24 a0 00 	vmovdqu %ymm11,0xa0(%rsp)
     263:	00 00 
     265:	c4 c1 4d db f2       	vpand  %ymm10,%ymm6,%ymm6
     26a:	c4 e3 3d 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm8,%ymm7
     271:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     276:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm7,%ymm7        # 29f <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x29f>
     27d:	00 00 90 
     280:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
     284:	c4 62 3d 90 0c ba    	vpgatherdd %ymm8,(%rdx,%ymm7,4),%ymm9
     28a:	c5 7e 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm8
     291:	00 00 
     293:	c4 c1 45 72 f5 10    	vpslld $0x10,%ymm13,%ymm7
     299:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
     29e:	c5 c5 fe bc 24 e0 00 	vpaddd 0xe0(%rsp),%ymm7,%ymm7
     2a5:	00 00 
     2a7:	c4 41 75 fe d8       	vpaddd %ymm8,%ymm1,%ymm11
     2ac:	c4 41 55 fa db       	vpsubd %ymm11,%ymm5,%ymm11
     2b1:	c4 41 25 fe e4       	vpaddd %ymm12,%ymm11,%ymm12
     2b6:	c5 35 fa de          	vpsubd %ymm6,%ymm9,%ymm11
     2ba:	c4 42 1d 40 db       	vpmulld %ymm11,%ymm12,%ymm11
     2bf:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
     2c4:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
     2ca:	c4 e2 4d 40 f1       	vpmulld %ymm1,%ymm6,%ymm6
     2cf:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     2d3:	c5 a5 fe ff          	vpaddd %ymm7,%ymm11,%ymm7
     2d7:	c5 2d db 9c 24 c0 00 	vpand  0xc0(%rsp),%ymm10,%ymm11
     2de:	00 00 
     2e0:	c4 41 25 fa d9       	vpsubd %ymm9,%ymm11,%ymm11
     2e5:	c4 42 25 40 d8       	vpmulld %ymm8,%ymm11,%ymm11
     2ea:	c5 bd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm8
     2ef:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     2f4:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     2f8:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
     2fd:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     301:	c4 c1 5d 72 f7 10    	vpslld $0x10,%ymm15,%ymm4
     307:	c5 dd 72 e4 10       	vpsrad $0x10,%ymm4,%ymm4
     30c:	c5 25 fe de          	vpaddd %ymm6,%ymm11,%ymm11
     310:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     315:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
     31a:	c4 c1 45 72 e7 10    	vpsrad $0x10,%ymm15,%ymm7
     320:	c5 c5 fe fb          	vpaddd %ymm3,%ymm7,%ymm7
     324:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
     32b:	00 00 
     32d:	c5 cd 72 e2 10       	vpsrad $0x10,%ymm2,%ymm6
     332:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     336:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     33b:	c4 41 45 fe c8       	vpaddd %ymm8,%ymm7,%ymm9
     340:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
     344:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     349:	c5 7e 7f 8c 24 00 01 	vmovdqu %ymm9,0x100(%rsp)
     350:	00 00 
     352:	c5 7d 66 e3          	vpcmpgtd %ymm3,%ymm0,%ymm12
     356:	c4 62 65 3d c8       	vpmaxsd %ymm0,%ymm3,%ymm9
     35b:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     35f:	c4 c1 6d 66 e1       	vpcmpgtd %ymm9,%ymm2,%ymm4
     364:	c5 ed fe e8          	vpaddd %ymm0,%ymm2,%ymm5
     368:	c4 62 35 3d ca       	vpmaxsd %ymm2,%ymm9,%ymm9
     36d:	c4 63 15 4c 24 24 c0 	vpblendvb %ymm12,(%rsp),%ymm13,%ymm12
     374:	c4 62 65 39 e8       	vpminsd %ymm0,%ymm3,%ymm13
     379:	c5 e5 66 c0          	vpcmpgtd %ymm0,%ymm3,%ymm0
     37d:	c4 62 15 39 da       	vpminsd %ymm2,%ymm13,%ymm11
     382:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm12,%ymm12        # 3ab <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x3ab>
     389:	00 00 40 
     38c:	c5 15 66 ea          	vpcmpgtd %ymm2,%ymm13,%ymm13
     390:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
     397:	00 00 
     399:	c4 41 35 fe fb       	vpaddd %ymm11,%ymm9,%ymm15
     39e:	c5 1d fe 64 24 40    	vpaddd 0x40(%rsp),%ymm12,%ymm12
     3a4:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
     3a9:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     3ad:	c4 a2 75 90 24 a2    	vpgatherdd %ymm1,(%rdx,%ymm12,4),%ymm4
     3b3:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
     3b9:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     3be:	c4 e3 75 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm1,%ymm0
     3c5:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     3c9:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
     3ce:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 3f7 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x3f7>
     3d5:	00 00 d0 
     3d8:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
     3dc:	c4 62 75 90 24 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm12
     3e2:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
     3e9:	00 00 
     3eb:	c5 7e 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm15
     3f2:	00 00 
     3f4:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
     3fa:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
     3ff:	c5 fe 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm0
     406:	00 00 
     408:	c4 41 1d db e2       	vpand  %ymm10,%ymm12,%ymm12
     40d:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
     412:	c5 9d fa ec          	vpsubd %ymm4,%ymm12,%ymm5
     416:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     41b:	c4 e2 65 40 ed       	vpmulld %ymm5,%ymm3,%ymm5
     420:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
     425:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     42a:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     42f:	c4 c2 45 3d d8       	vpmaxsd %ymm8,%ymm7,%ymm3
     434:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     439:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
     43f:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
     445:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     44a:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     44f:	c4 c1 7d fe c7       	vpaddd %ymm15,%ymm0,%ymm0
     454:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     459:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     45d:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     461:	c5 cd 66 e3          	vpcmpgtd %ymm3,%ymm6,%ymm4
     465:	c4 e2 65 3d de       	vpmaxsd %ymm6,%ymm3,%ymm3
     46a:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     46e:	c5 bd 66 d7          	vpcmpgtd %ymm7,%ymm8,%ymm2
     472:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     477:	c4 c3 1d 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm12,%ymm2
     47d:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 4a6 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4a6>
     484:	00 00 40 
     487:	c4 c2 45 39 e0       	vpminsd %ymm8,%ymm7,%ymm4
     48c:	c4 c1 45 66 f8       	vpcmpgtd %ymm8,%ymm7,%ymm7
     491:	c4 e2 5d 39 ee       	vpminsd %ymm6,%ymm4,%ymm5
     496:	c5 ed fe 54 24 40    	vpaddd 0x40(%rsp),%ymm2,%ymm2
     49c:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     4a0:	c4 41 7d 6f c6       	vmovdqa %ymm14,%ymm8
     4a5:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
     4a9:	c4 e2 25 90 0c 92    	vpgatherdd %ymm11,(%rdx,%ymm2,4),%ymm1
     4af:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
     4b6:	00 00 
     4b8:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
     4bd:	c4 c3 1d 4c fd 70    	vpblendvb %ymm7,%ymm13,%ymm12,%ymm7
     4c3:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     4c8:	c5 cd fe b4 24 00 01 	vpaddd 0x100(%rsp),%ymm6,%ymm6
     4cf:	00 00 
     4d1:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm7,%ymm7        # 4fa <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4fa>
     4d8:	00 00 40 
     4db:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     4e2:	00 00 
     4e4:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     4e9:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
     4ed:	c4 e2 3d 90 3c 92    	vpgatherdd %ymm8,(%rdx,%ymm2,4),%ymm7
     4f3:	c5 ed 72 d4 10       	vpsrld $0x10,%ymm4,%ymm2
     4f8:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
     4ff:	00 00 
     501:	48 8b 50 60          	mov    0x60(%rax),%rdx
     505:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     50a:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     50f:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     514:	c5 bd 72 f2 10       	vpslld $0x10,%ymm2,%ymm8
     519:	c4 c1 45 db fa       	vpand  %ymm10,%ymm7,%ymm7
     51e:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
     523:	c5 45 fa c9          	vpsubd %ymm1,%ymm7,%ymm9
     527:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     52b:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     52f:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     534:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
     539:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
     53e:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     543:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     547:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
     54c:	c5 dd fe c9          	vpaddd %ymm1,%ymm4,%ymm1
     550:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
     554:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
     559:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
     560:	00 00 
     562:	c4 e2 55 90 0c b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm1
     568:	48 8b 50 68          	mov    0x68(%rax),%rdx
     56c:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     570:	c4 e2 55 90 34 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm6
     576:	48 8b 50 70          	mov    0x70(%rax),%rdx
     57a:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     57e:	c5 e5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm3
     583:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 5eb <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5eb>
     58a:	00 
     58b:	c4 62 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm11
     591:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
     596:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     59d:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 605 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x605>
     5a4:	00 
     5a5:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
     5aa:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
     5af:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     5b3:	c4 c1 45 72 d3 11    	vpsrld $0x11,%ymm11,%ymm7
     5b9:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
     5be:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     5c2:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     5c6:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     5ca:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     5ce:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     5d2:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 63a <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x63a>
     5d9:	00 
     5da:	c4 e2 75 3d e6       	vpmaxsd %ymm6,%ymm1,%ymm4
     5df:	c4 62 55 90 04 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm8
     5e5:	c5 6d fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm9
     5eb:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     5ef:	c5 cd 66 f9          	vpcmpgtd %ymm1,%ymm6,%ymm7
     5f3:	c5 a5 66 dc          	vpcmpgtd %ymm4,%ymm11,%ymm3
     5f7:	c4 62 75 39 e6       	vpminsd %ymm6,%ymm1,%ymm12
     5fc:	c4 a2 55 90 04 8a    	vpgatherdd %ymm5,(%rdx,%ymm9,4),%ymm0
     602:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     608:	c4 c2 5d 3d e3       	vpmaxsd %ymm11,%ymm4,%ymm4
     60d:	c5 75 fe ee          	vpaddd %ymm6,%ymm1,%ymm13
     611:	c5 f5 66 ce          	vpcmpgtd %ymm6,%ymm1,%ymm1
     615:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     61b:	c4 e3 55 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm5,%ymm7
     622:	c4 c2 1d 39 eb       	vpminsd %ymm11,%ymm12,%ymm5
     627:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm7,%ymm7        # 650 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x650>
     62e:	00 00 30 
     631:	c5 dd fe dd          	vpaddd %ymm5,%ymm4,%ymm3
     635:	c5 a5 fa db          	vpsubd %ymm3,%ymm11,%ymm3
     639:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     63d:	c4 e3 4d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm6,%ymm1
     644:	c4 c1 65 fe dd       	vpaddd %ymm13,%ymm3,%ymm3
     649:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
     64e:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     652:	c4 e2 15 90 3c 92    	vpgatherdd %ymm13,(%rdx,%ymm2,4),%ymm7
     658:	c4 c1 1d 66 d3       	vpcmpgtd %ymm11,%ymm12,%ymm2
     65d:	c4 41 45 db e2       	vpand  %ymm10,%ymm7,%ymm12
     662:	c5 95 72 d7 08       	vpsrld $0x8,%ymm7,%ymm13
     667:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
     66c:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     671:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 69a <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x69a>
     678:	00 00 20 
     67b:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
     67f:	c4 a2 4d 90 0c 8a    	vpgatherdd %ymm6,(%rdx,%ymm9,4),%ymm1
     685:	c4 41 3d db ca       	vpand  %ymm10,%ymm8,%ymm9
     68a:	c4 c1 7d db f2       	vpand  %ymm10,%ymm0,%ymm6
     68f:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
     696:	c4 c1 75 db d2       	vpand  %ymm10,%ymm1,%ymm2
     69b:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
     6a1:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
     6a6:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
     6aa:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     6af:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     6b4:	c4 e2 4d 40 f5       	vpmulld %ymm5,%ymm6,%ymm6
     6b9:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     6be:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     6c3:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     6c8:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
     6cd:	c4 c1 25 72 d0 08    	vpsrld $0x8,%ymm8,%ymm11
     6d3:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     6d7:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
     6dc:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
     6e1:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     6e6:	c4 c1 1d 72 f3 10    	vpslld $0x10,%ymm11,%ymm12
     6ec:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
     6f1:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     6f6:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     6fb:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
     700:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     705:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     70b:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     710:	c4 41 35 fa cd       	vpsubd %ymm13,%ymm9,%ymm9
     715:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
     71a:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
     71f:	c4 62 35 40 cb       	vpmulld %ymm3,%ymm9,%ymm9
     724:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     729:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     72e:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     733:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     738:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     73d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     741:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     746:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     74b:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     74f:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     754:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     759:	c4 41 45 db ca       	vpand  %ymm10,%ymm7,%ymm9
     75e:	c4 c1 45 72 f0 10    	vpslld $0x10,%ymm8,%ymm7
     764:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     769:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
     76e:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
     773:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     778:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
     77d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     782:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     786:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     78b:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     78f:	c4 e2 55 90 0c b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm1
     795:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
     79c:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     7a0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     7a5:	c4 62 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm11
     7ab:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
     7b2:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
     7b7:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     7bb:	c4 c1 65 72 d3 11    	vpsrld $0x11,%ymm11,%ymm3
     7c1:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 829 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x829>
     7c8:	00 
     7c9:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 831 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x831>
     7d0:	00 
     7d1:	c4 62 55 90 24 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm12
     7d7:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
     7dc:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
     7e3:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
     7e8:	c4 c1 4d 72 d4 11    	vpsrld $0x11,%ymm12,%ymm6
     7ee:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     7f2:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
     7f7:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     7fb:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     7ff:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     803:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # 86b <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x86b>
     80a:	00 
     80b:	c4 c2 75 3d e3       	vpmaxsd %ymm11,%ymm1,%ymm4
     810:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     814:	c5 a5 66 f1          	vpcmpgtd %ymm1,%ymm11,%ymm6
     818:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     81c:	c5 6d fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm9
     822:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     826:	c4 62 55 90 04 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm8
     82c:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     832:	c4 42 75 39 eb       	vpminsd %ymm11,%ymm1,%ymm13
     837:	c4 c1 75 fe fb       	vpaddd %ymm11,%ymm1,%ymm7
     83c:	c4 c1 75 66 cb       	vpcmpgtd %ymm11,%ymm1,%ymm1
     841:	c4 a2 65 90 04 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm0
     847:	c5 9d 66 dc          	vpcmpgtd %ymm4,%ymm12,%ymm3
     84b:	c4 e3 55 4c 34 24 60 	vpblendvb %ymm6,(%rsp),%ymm5,%ymm6
     852:	c4 c2 5d 3d e4       	vpmaxsd %ymm12,%ymm4,%ymm4
     857:	c4 c2 15 39 ec       	vpminsd %ymm12,%ymm13,%ymm5
     85c:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm6,%ymm6        # 885 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x885>
     863:	00 00 30 
     866:	c5 dd fe dd          	vpaddd %ymm5,%ymm4,%ymm3
     86a:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     86e:	c5 9d fa db          	vpsubd %ymm3,%ymm12,%ymm3
     872:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     876:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     87a:	c4 e2 4d 90 3c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm7
     880:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     886:	c4 c1 15 66 d4       	vpcmpgtd %ymm12,%ymm13,%ymm2
     88b:	c5 95 72 d7 08       	vpsrld $0x8,%ymm7,%ymm13
     890:	c4 41 45 db e2       	vpand  %ymm10,%ymm7,%ymm12
     895:	c4 e3 4d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm6,%ymm1
     89c:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     8a0:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
     8a5:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     8aa:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 8d3 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x8d3>
     8b1:	00 00 20 
     8b4:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
     8b8:	c4 a2 4d 90 0c 8a    	vpgatherdd %ymm6,(%rdx,%ymm9,4),%ymm1
     8be:	c4 41 3d db ca       	vpand  %ymm10,%ymm8,%ymm9
     8c3:	c4 c1 7d db f2       	vpand  %ymm10,%ymm0,%ymm6
     8c8:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
     8cf:	c4 c1 75 db d2       	vpand  %ymm10,%ymm1,%ymm2
     8d4:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
     8da:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
     8df:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
     8e3:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     8e8:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     8ed:	c4 e2 4d 40 f5       	vpmulld %ymm5,%ymm6,%ymm6
     8f2:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     8f7:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     8fc:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     901:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
     906:	c4 c1 25 72 d0 08    	vpsrld $0x8,%ymm8,%ymm11
     90c:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     910:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
     915:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
     91a:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     91f:	c4 c1 1d 72 f3 10    	vpslld $0x10,%ymm11,%ymm12
     925:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
     92a:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     92f:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     934:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
     939:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     93e:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     944:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     949:	c4 41 35 fa cd       	vpsubd %ymm13,%ymm9,%ymm9
     94e:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
     953:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
     958:	c4 62 35 40 cb       	vpmulld %ymm3,%ymm9,%ymm9
     95d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     962:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     967:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     96c:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     971:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     976:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     97a:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     97f:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     984:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     988:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     98d:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     992:	c4 41 45 db ca       	vpand  %ymm10,%ymm7,%ymm9
     997:	c4 c1 45 72 f0 10    	vpslld $0x10,%ymm8,%ymm7
     99d:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     9a2:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
     9a7:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
     9ac:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     9b1:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
     9b6:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     9ba:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     9bf:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     9c3:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     9c8:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     9cc:	c4 e2 65 90 0c b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm1
     9d2:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
     9d9:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     9dd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     9e2:	c4 62 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm11
     9e8:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
     9ef:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
     9f4:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # a5c <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa5c>
     9fb:	00 
     9fc:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
     a01:	c4 62 65 90 24 82    	vpgatherdd %ymm3,(%rdx,%ymm0,4),%ymm12
     a07:	c4 c1 65 72 d3 11    	vpsrld $0x11,%ymm11,%ymm3
     a0d:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # a75 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa75>
     a14:	00 
     a15:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
     a1c:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
     a21:	c4 c1 4d 72 d4 11    	vpsrld $0x11,%ymm12,%ymm6
     a27:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a2b:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
     a30:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     a34:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     a38:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     a3c:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # aa4 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xaa4>
     a43:	00 
     a44:	c4 c2 75 3d e3       	vpmaxsd %ymm11,%ymm1,%ymm4
     a49:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     a4d:	c5 a5 66 f1          	vpcmpgtd %ymm1,%ymm11,%ymm6
     a51:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     a55:	c5 6d fe 4c 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm9
     a5b:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     a5f:	c4 62 55 90 04 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm8
     a65:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     a6b:	c4 42 75 39 eb       	vpminsd %ymm11,%ymm1,%ymm13
     a70:	c4 c1 75 fe fb       	vpaddd %ymm11,%ymm1,%ymm7
     a75:	c4 c1 75 66 cb       	vpcmpgtd %ymm11,%ymm1,%ymm1
     a7a:	c4 a2 65 90 04 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm0
     a80:	c5 9d 66 dc          	vpcmpgtd %ymm4,%ymm12,%ymm3
     a84:	c4 e3 55 4c 34 24 60 	vpblendvb %ymm6,(%rsp),%ymm5,%ymm6
     a8b:	c4 c2 5d 3d e4       	vpmaxsd %ymm12,%ymm4,%ymm4
     a90:	c4 c2 15 39 ec       	vpminsd %ymm12,%ymm13,%ymm5
     a95:	c4 41 15 66 ec       	vpcmpgtd %ymm12,%ymm13,%ymm13
     a9a:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm6,%ymm6        # ac3 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xac3>
     aa1:	00 00 30 
     aa4:	c5 dd fe dd          	vpaddd %ymm5,%ymm4,%ymm3
     aa8:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     aac:	c5 9d fa db          	vpsubd %ymm3,%ymm12,%ymm3
     ab0:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     ab4:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     ab8:	c4 e2 4d 90 3c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm7
     abe:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     ac4:	c4 c1 7d db d2       	vpand  %ymm10,%ymm0,%ymm2
     ac9:	c4 41 45 db e2       	vpand  %ymm10,%ymm7,%ymm12
     ace:	c4 e3 4d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm6,%ymm1
     ad5:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm1,%ymm1        # afe <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xafe>
     adc:	00 00 d0 
     adf:	c5 95 72 d7 08       	vpsrld $0x8,%ymm7,%ymm13
     ae4:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
     ae8:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     aec:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
     af1:	c4 a2 75 90 34 8a    	vpgatherdd %ymm1,(%rdx,%ymm9,4),%ymm6
     af7:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     afc:	c4 41 3d db ca       	vpand  %ymm10,%ymm8,%ymm9
     b01:	c4 c1 4d db ca       	vpand  %ymm10,%ymm6,%ymm1
     b06:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
     b0c:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
     b11:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     b15:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     b1a:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     b1f:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
     b24:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     b29:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
     b2e:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     b33:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     b38:	c4 c1 25 72 d0 08    	vpsrld $0x8,%ymm8,%ymm11
     b3e:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     b42:	c5 b5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm9
     b47:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
     b4c:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     b51:	c4 c1 1d 72 f3 10    	vpslld $0x10,%ymm11,%ymm12
     b57:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
     b5c:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     b61:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     b66:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
     b6b:	c4 62 25 40 dc       	vpmulld %ymm4,%ymm11,%ymm11
     b70:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     b76:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     b7b:	c4 41 35 fa cd       	vpsubd %ymm13,%ymm9,%ymm9
     b80:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     b85:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
     b8a:	c4 62 35 40 cb       	vpmulld %ymm3,%ymm9,%ymm9
     b8f:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     b94:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     b99:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b9e:	c4 c1 4d db f2       	vpand  %ymm10,%ymm6,%ymm6
     ba3:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     ba8:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
     bac:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     bb1:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     bb6:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     bbb:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
     bc0:	c4 41 45 db ca       	vpand  %ymm10,%ymm7,%ymm9
     bc5:	c4 c1 45 72 f0 10    	vpslld $0x10,%ymm8,%ymm7
     bcb:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
     bd0:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
     bd5:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
     bda:	c4 e2 4d 40 f3       	vpmulld %ymm3,%ymm6,%ymm6
     bdf:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
     be4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     be9:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
     bee:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     bf3:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     bf7:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     bfb:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     c00:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     c05:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
     c09:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     c0d:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # c56 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xc56>
     c14:	00 00 
     c16:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     c1a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     c20:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     c25:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     c2a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     c2e:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
     c33:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
     c38:	49 39 c8             	cmp    %rcx,%r8
     c3b:	0f 85 9f f4 ff ff    	jne    e0 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xe0>
     c41:	c5 f8 77             	vzeroupper
     c44:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
     c4b:	00 00 
     c4d:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
     c54:	00 00 
     c56:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
     c5d:	00 00 
     c5f:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
     c66:	00 00 
     c68:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
     c6f:	00 00 
     c71:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
     c78:	00 00 
     c7a:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
     c81:	00 00 
     c83:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
     c8a:	00 00 
     c8c:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
     c93:	00 00 
     c95:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
     c9c:	00 00 
     c9e:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
     ca5:	c3                   	ret
     ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     cad:	00 00 00 

0000000000000cb0 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)>:
     cb0:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
     cb7:	c5 f8 29 b4 24 20 01 	vmovaps %xmm6,0x120(%rsp)
     cbe:	00 00 
     cc0:	c5 f8 29 bc 24 30 01 	vmovaps %xmm7,0x130(%rsp)
     cc7:	00 00 
     cc9:	c5 78 29 84 24 40 01 	vmovaps %xmm8,0x140(%rsp)
     cd0:	00 00 
     cd2:	c5 78 29 8c 24 50 01 	vmovaps %xmm9,0x150(%rsp)
     cd9:	00 00 
     cdb:	c5 78 29 94 24 60 01 	vmovaps %xmm10,0x160(%rsp)
     ce2:	00 00 
     ce4:	c5 78 29 9c 24 70 01 	vmovaps %xmm11,0x170(%rsp)
     ceb:	00 00 
     ced:	c5 78 29 a4 24 80 01 	vmovaps %xmm12,0x180(%rsp)
     cf4:	00 00 
     cf6:	c5 78 29 ac 24 90 01 	vmovaps %xmm13,0x190(%rsp)
     cfd:	00 00 
     cff:	c5 78 29 b4 24 a0 01 	vmovaps %xmm14,0x1a0(%rsp)
     d06:	00 00 
     d08:	c5 78 29 bc 24 b0 01 	vmovaps %xmm15,0x1b0(%rsp)
     d0f:	00 00 
     d11:	48 89 c8             	mov    %rcx,%rax
     d14:	4d 85 c0             	test   %r8,%r8
     d17:	0f 84 d9 0b 00 00    	je     18f6 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xc46>
     d1d:	49 ff c8             	dec    %r8
     d20:	48 89 d1             	mov    %rdx,%rcx
     d23:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     d28:	49 c1 e8 03          	shr    $0x3,%r8
     d2c:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
     d32:	4b 8d 14 40          	lea    (%r8,%r8,2),%rdx
     d36:	4c 8d 44 d1 18       	lea    0x18(%rcx,%rdx,8),%r8
     d3b:	ba 63 04 00 00       	mov    $0x463,%edx
     d40:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     d44:	ba 21 00 00 00       	mov    $0x21,%edx
     d49:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     d4e:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     d54:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     d58:	ba 41 04 00 00       	mov    $0x441,%edx
     d5d:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     d62:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     d67:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     d6b:	ba 00 80 00 00       	mov    $0x8000,%edx
     d70:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     d75:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
     d7b:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     d7f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     d84:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     d90:	c5 fa 6f 01          	vmovdqu (%rcx),%xmm0
     d94:	c5 fa 7e 49 10       	vmovq  0x10(%rcx),%xmm1
     d99:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     d9d:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     da2:	48 8b 10             	mov    (%rax),%rdx
     da5:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     dab:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     db0:	48 83 c1 18          	add    $0x18,%rcx
     db4:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     dba:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     dc0:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # dc9 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x119>
     dc7:	00 00 
     dc9:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     dce:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
     dd3:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     dd8:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     ddf:	00 00 
     de1:	c4 c1 75 db f5       	vpand  %ymm13,%ymm1,%ymm6
     de6:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     dea:	c4 e2 65 90 14 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm2
     df0:	48 8b 50 08          	mov    0x8(%rax),%rdx
     df4:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
     dfb:	00 00 
     dfd:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     e01:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
     e06:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # e6e <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1be>
     e0d:	00 
     e0e:	c4 e2 65 90 2c b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm5
     e14:	48 8b 50 10          	mov    0x10(%rax),%rdx
     e18:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     e1f:	00 00 
     e21:	c5 dd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm4
     e26:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # e8e <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1de>
     e2d:	00 
     e2e:	c4 e2 7d 90 1c ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm3
     e34:	c5 c5 72 f1 06       	vpslld $0x6,%ymm1,%ymm7
     e39:	48 8b 50 48          	mov    0x48(%rax),%rdx
     e3d:	c5 fd 72 f1 0a       	vpslld $0xa,%ymm1,%ymm0
     e42:	c5 bd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm8
     e47:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # eaf <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x1ff>
     e4e:	00 
     e4f:	c5 cd 72 f4 05       	vpslld $0x5,%ymm4,%ymm6
     e54:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     e58:	c4 e2 6d 3d fd       	vpmaxsd %ymm5,%ymm2,%ymm7
     e5d:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     e61:	c5 d5 66 f2          	vpcmpgtd %ymm2,%ymm5,%ymm6
     e65:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     e69:	c5 e5 66 e7          	vpcmpgtd %ymm7,%ymm3,%ymm4
     e6d:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
     e72:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
     e77:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     e7b:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
     e80:	c4 e3 2d 4c 34 24 60 	vpblendvb %ymm6,(%rsp),%ymm10,%ymm6
     e87:	c4 e2 35 90 04 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm0
     e8d:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
     e92:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm6,%ymm6        # ebb <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x20b>
     e99:	00 00 40 
     e9c:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     ea3:	00 00 
     ea5:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
     ea9:	c5 75 fe 64 24 60    	vpaddd 0x60(%rsp),%ymm1,%ymm12
     eaf:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
     eb3:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     eb8:	c4 41 45 fe da       	vpaddd %ymm10,%ymm7,%ymm11
     ebd:	c4 e2 0d 90 24 b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm4
     ec3:	c5 ed 66 f5          	vpcmpgtd %ymm5,%ymm2,%ymm6
     ec7:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     ecd:	c4 a2 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm12,4),%ymm0
     ed3:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     ed8:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     edd:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     ee1:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     ee5:	c4 e3 0d 4c 34 24 60 	vpblendvb %ymm6,(%rsp),%ymm14,%ymm6
     eec:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     ef1:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm6,%ymm6        # f1a <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x26a>
     ef8:	00 00 80 
     efb:	c5 15 db 8c 24 c0 00 	vpand  0xc0(%rsp),%ymm13,%ymm9
     f02:	00 00 
     f04:	4c 8b 48 28          	mov    0x28(%rax),%r9
     f08:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
     f0c:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     f12:	c4 62 0d 90 04 b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm8
     f18:	c4 c1 4d 72 f1 10    	vpslld $0x10,%ymm9,%ymm6
     f1e:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
     f23:	c5 cd fe 74 24 40    	vpaddd 0x40(%rsp),%ymm6,%ymm6
     f29:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
     f2d:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
     f32:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     f37:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
     f3c:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     f41:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
     f46:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
     f4b:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     f50:	c5 e5 fe f6          	vpaddd %ymm6,%ymm3,%ymm6
     f54:	c5 fe 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm3
     f5b:	00 00 
     f5d:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     f61:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     f65:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
     f69:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     f6d:	c5 8d 72 d6 10       	vpsrld $0x10,%ymm6,%ymm14
     f72:	c5 7e 7f b4 24 00 01 	vmovdqu %ymm14,0x100(%rsp)
     f79:	00 00 
     f7b:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     f80:	c4 c2 6d 90 34 99    	vpgatherdd %ymm2,(%r9,%ymm3,4),%ymm6
     f86:	4c 8b 48 20          	mov    0x20(%rax),%r9
     f8a:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
     f91:	00 00 
     f93:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # ffb <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x34b>
     f9a:	00 
     f9b:	c4 c2 5d 90 3c 91    	vpgatherdd %ymm4,(%r9,%ymm2,4),%ymm7
     fa1:	4c 8b 48 18          	mov    0x18(%rax),%r9
     fa5:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     fac:	00 00 
     fae:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 1016 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x366>
     fb5:	00 
     fb6:	c4 c2 35 90 14 a1    	vpgatherdd %ymm9,(%r9,%ymm4,4),%ymm2
     fbc:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1024 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x374>
     fc3:	00 
     fc4:	c4 62 6d 3d cf       	vpmaxsd %ymm7,%ymm2,%ymm9
     fc9:	c5 c5 66 e2          	vpcmpgtd %ymm2,%ymm7,%ymm4
     fcd:	c4 e2 6d 39 ef       	vpminsd %ymm7,%ymm2,%ymm5
     fd2:	c4 c1 4d 66 d9       	vpcmpgtd %ymm9,%ymm6,%ymm3
     fd7:	c4 62 35 3d ce       	vpmaxsd %ymm6,%ymm9,%ymm9
     fdc:	c4 e3 25 4c 24 24 40 	vpblendvb %ymm4,(%rsp),%ymm11,%ymm4
     fe3:	c4 62 55 39 de       	vpminsd %ymm6,%ymm5,%ymm11
     fe8:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 1011 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x361>
     fef:	00 00 30 
     ff2:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
     ff6:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
     ffa:	c4 e2 0d 90 1c a2    	vpgatherdd %ymm14,(%rdx,%ymm4,4),%ymm3
    1000:	c5 ed 66 e7          	vpcmpgtd %ymm7,%ymm2,%ymm4
    1004:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    100a:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    100e:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    1013:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1018:	c4 e3 0d 4c 24 24 40 	vpblendvb %ymm4,(%rsp),%ymm14,%ymm4
    101f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1024:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 104d <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x39d>
    102b:	00 00 50 
    102e:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    1033:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    1037:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    103c:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1041:	c4 62 0d 90 04 a2    	vpgatherdd %ymm14,(%rdx,%ymm4,4),%ymm8
    1047:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    104e:	00 00 
    1050:	c4 41 35 fe f3       	vpaddd %ymm11,%ymm9,%ymm14
    1055:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    105a:	c4 c1 3d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm8
    1060:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    1065:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    106a:	c5 ad 72 d4 08       	vpsrld $0x8,%ymm4,%ymm10
    106f:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    1074:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    1078:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    107d:	c5 bd fa f3          	vpsubd %ymm3,%ymm8,%ymm6
    1081:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    1086:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    108b:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    1090:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    1095:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    109a:	c4 c1 5d 72 f2 10    	vpslld $0x10,%ymm10,%ymm4
    10a0:	c5 dd fe 64 24 40    	vpaddd 0x40(%rsp),%ymm4,%ymm4
    10a6:	4c 8b 48 40          	mov    0x40(%rax),%r9
    10aa:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    10ae:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    10b5:	00 00 
    10b7:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    10bb:	c5 fe 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm3
    10c2:	00 00 
    10c4:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    10c8:	c4 c2 0d 90 14 99    	vpgatherdd %ymm14,(%r9,%ymm3,4),%ymm2
    10ce:	4c 8b 48 38          	mov    0x38(%rax),%r9
    10d2:	c5 fe 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm3
    10d9:	00 00 
    10db:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    10e0:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1148 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x498>
    10e7:	00 
    10e8:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    10ed:	c4 c2 0d 90 2c 99    	vpgatherdd %ymm14,(%r9,%ymm3,4),%ymm5
    10f3:	4c 8b 48 30          	mov    0x30(%rax),%r9
    10f7:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    10fc:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1164 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4b4>
    1103:	00 
    1104:	c4 c2 0d 90 1c b1    	vpgatherdd %ymm14,(%r9,%ymm6,4),%ymm3
    110a:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    1110:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1178 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4c8>
    1117:	00 
    1118:	c4 e2 65 3d fd       	vpmaxsd %ymm5,%ymm3,%ymm7
    111d:	c5 d5 66 f3          	vpcmpgtd %ymm3,%ymm5,%ymm6
    1121:	c5 6d 66 c7          	vpcmpgtd %ymm7,%ymm2,%ymm8
    1125:	c4 e2 45 3d fa       	vpmaxsd %ymm2,%ymm7,%ymm7
    112a:	c4 e3 0d 4c 34 24 60 	vpblendvb %ymm6,(%rsp),%ymm14,%ymm6
    1131:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1136:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm6,%ymm6        # 115f <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x4af>
    113d:	00 00 80 
    1140:	c4 62 65 39 c5       	vpminsd %ymm5,%ymm3,%ymm8
    1145:	c4 62 3d 39 ca       	vpminsd %ymm2,%ymm8,%ymm9
    114a:	c5 3d 66 d2          	vpcmpgtd %ymm2,%ymm8,%ymm10
    114e:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
    1152:	c5 65 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm8
    1156:	c4 e2 0d 90 0c b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm1
    115c:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    1162:	c4 41 45 fe d9       	vpaddd %ymm9,%ymm7,%ymm11
    1167:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    116c:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    1170:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1175:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    117a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    117e:	c4 e3 0d 4c 34 24 80 	vpblendvb %ymm8,(%rsp),%ymm14,%ymm6
    1185:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    118a:	c4 63 4d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm6,%ymm8        # 11b3 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x503>
    1191:	00 00 a0 
    1194:	c4 c1 1d fa f0       	vpsubd %ymm8,%ymm12,%ymm6
    1199:	c4 62 0d 90 04 b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm8
    119f:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    11a6:	00 00 
    11a8:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
    11af:	00 00 
    11b1:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    11b7:	48 8b 50 60          	mov    0x60(%rax),%rdx
    11bb:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    11c0:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    11c5:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
    11ca:	c5 bd fa d9          	vpsubd %ymm1,%ymm8,%ymm3
    11ce:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
    11d3:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    11d8:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    11dd:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    11e1:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    11e6:	c5 ad 72 f6 10       	vpslld $0x10,%ymm6,%ymm10
    11eb:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    11ef:	c5 2d fe 54 24 40    	vpaddd 0x40(%rsp),%ymm10,%ymm10
    11f5:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    11fa:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    11fe:	c4 a2 4d 90 0c b2    	vpgatherdd %ymm6,(%rdx,%ymm14,4),%ymm1
    1204:	48 8b 50 68          	mov    0x68(%rax),%rdx
    1208:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    120c:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1210:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    1216:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    121b:	c4 62 4d 90 04 a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm8
    1221:	48 8b 50 70          	mov    0x70(%rax),%rdx
    1225:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    122a:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    122e:	c4 c1 65 72 d0 11    	vpsrld $0x11,%ymm8,%ymm3
    1234:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 129c <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x5ec>
    123b:	00 
    123c:	c4 62 5d 90 14 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm10
    1242:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
    1247:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    124e:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 12b6 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x606>
    1255:	00 
    1256:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
    125b:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
    1260:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1264:	c4 c1 4d 72 d2 11    	vpsrld $0x11,%ymm10,%ymm6
    126a:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
    126f:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1273:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1277:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    127b:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    127f:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1283:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 12eb <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x63b>
    128a:	00 
    128b:	c4 c2 75 3d f8       	vpmaxsd %ymm8,%ymm1,%ymm7
    1290:	c4 e2 5d 90 1c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm3
    1296:	c5 ed fe 64 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm4
    129c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    12a0:	c5 bd 66 e9          	vpcmpgtd %ymm1,%ymm8,%ymm5
    12a4:	c4 42 75 39 d8       	vpminsd %ymm8,%ymm1,%ymm11
    12a9:	c4 41 75 fe e0       	vpaddd %ymm8,%ymm1,%ymm12
    12ae:	c4 e2 4d 90 04 a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm0
    12b4:	c5 ad 66 f7          	vpcmpgtd %ymm7,%ymm10,%ymm6
    12b8:	c4 c2 45 3d fa       	vpmaxsd %ymm10,%ymm7,%ymm7
    12bd:	c4 c1 75 66 c8       	vpcmpgtd %ymm8,%ymm1,%ymm1
    12c2:	c4 41 65 db c5       	vpand  %ymm13,%ymm3,%ymm8
    12c7:	c4 e3 35 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm9,%ymm5
    12ce:	c4 42 25 39 ca       	vpminsd %ymm10,%ymm11,%ymm9
    12d3:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 12fc <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x64c>
    12da:	00 00 60 
    12dd:	c4 41 25 66 da       	vpcmpgtd %ymm10,%ymm11,%ymm11
    12e2:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    12e7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    12eb:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    12ef:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
    12f5:	c4 e2 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm5
    12fb:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    1301:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1306:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
    130c:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    1311:	c4 e3 6d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm2,%ymm1
    1318:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    131c:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1321:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 134a <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x69a>
    1328:	00 00 b0 
    132b:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
    1330:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    1335:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1339:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    133e:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1343:	c4 e2 6d 90 0c a2    	vpgatherdd %ymm2,(%rdx,%ymm4,4),%ymm1
    1349:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
    134e:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1353:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    135a:	c4 c1 75 db d5       	vpand  %ymm13,%ymm1,%ymm2
    135f:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    1364:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1368:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    136d:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    1372:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    1377:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    137c:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    1381:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1386:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    138b:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1390:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    1395:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    139a:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    139e:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    13a3:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    13a8:	c4 c1 2d 72 f3 10    	vpslld $0x10,%ymm11,%ymm10
    13ae:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    13b3:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    13b8:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    13bd:	c4 41 3d fa c4       	vpsubd %ymm12,%ymm8,%ymm8
    13c2:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    13c7:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    13cc:	c4 62 3d 40 c6       	vpmulld %ymm6,%ymm8,%ymm8
    13d1:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    13d6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    13db:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    13e0:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    13e5:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    13ea:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    13ef:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    13f3:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    13f7:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    13fc:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1401:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1406:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    140b:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1410:	c5 bd 72 f3 10       	vpslld $0x10,%ymm3,%ymm8
    1415:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    1419:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    141e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1423:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1428:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    142d:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1432:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1436:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    143a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    143e:	c4 e2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm4,4),%ymm1
    1444:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    144b:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    144f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1454:	c4 62 5d 90 04 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm8
    145a:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    1461:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
    1466:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    146a:	c4 c1 65 72 d0 11    	vpsrld $0x11,%ymm8,%ymm3
    1470:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
    1475:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 14dd <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x82d>
    147c:	00 
    147d:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    1483:	c4 62 5d 90 14 82    	vpgatherdd %ymm4,(%rdx,%ymm0,4),%ymm10
    1489:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
    148e:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1492:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    1499:	c4 c1 4d 72 d2 11    	vpsrld $0x11,%ymm10,%ymm6
    149f:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
    14a4:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    14a8:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    14ac:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    14b0:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1518 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x868>
    14b7:	00 
    14b8:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    14bc:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    14c0:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 1528 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x878>
    14c7:	00 
    14c8:	c4 e2 5d 90 1c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm3
    14ce:	c5 ed fe 64 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm4
    14d4:	c4 c2 75 3d f8       	vpmaxsd %ymm8,%ymm1,%ymm7
    14d9:	c5 bd 66 e9          	vpcmpgtd %ymm1,%ymm8,%ymm5
    14dd:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    14e1:	c4 42 75 39 d8       	vpminsd %ymm8,%ymm1,%ymm11
    14e6:	c4 e2 4d 90 04 a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm0
    14ec:	c5 ad 66 f7          	vpcmpgtd %ymm7,%ymm10,%ymm6
    14f0:	c4 41 75 fe e0       	vpaddd %ymm8,%ymm1,%ymm12
    14f5:	c4 c1 75 66 c8       	vpcmpgtd %ymm8,%ymm1,%ymm1
    14fa:	c4 c2 45 3d fa       	vpmaxsd %ymm10,%ymm7,%ymm7
    14ff:	c4 41 65 db c5       	vpand  %ymm13,%ymm3,%ymm8
    1504:	c4 e3 35 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm9,%ymm5
    150b:	c4 42 25 39 ca       	vpminsd %ymm10,%ymm11,%ymm9
    1510:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 1539 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x889>
    1517:	00 00 60 
    151a:	c4 41 25 66 da       	vpcmpgtd %ymm10,%ymm11,%ymm11
    151f:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    1524:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1528:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    152c:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
    1532:	c4 e2 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm5
    1538:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    153e:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1543:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
    1549:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    154e:	c4 e3 6d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm2,%ymm1
    1555:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    1559:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    155e:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 1587 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0x8d7>
    1565:	00 00 b0 
    1568:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
    156d:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    1572:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1576:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    157b:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1580:	c4 e2 6d 90 0c a2    	vpgatherdd %ymm2,(%rdx,%ymm4,4),%ymm1
    1586:	c4 c1 7d db e5       	vpand  %ymm13,%ymm0,%ymm4
    158b:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    1590:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    1597:	c4 c1 75 db d5       	vpand  %ymm13,%ymm1,%ymm2
    159c:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    15a1:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    15a5:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    15aa:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    15af:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    15b4:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    15b9:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    15be:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    15c3:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    15c8:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    15cd:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    15d2:	c5 bd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm8
    15d7:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    15db:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    15e0:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    15e5:	c4 c1 2d 72 f3 10    	vpslld $0x10,%ymm11,%ymm10
    15eb:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    15f0:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    15f5:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    15fa:	c4 41 3d fa c4       	vpsubd %ymm12,%ymm8,%ymm8
    15ff:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    1604:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1609:	c4 62 3d 40 c6       	vpmulld %ymm6,%ymm8,%ymm8
    160e:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1613:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1618:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    161d:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1622:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1627:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    162c:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1630:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1634:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1639:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    163e:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1643:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    1648:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    164d:	c5 bd 72 f3 10       	vpslld $0x10,%ymm3,%ymm8
    1652:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    1656:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    165b:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1660:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1664:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1669:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    166e:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1673:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1677:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    167b:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    167f:	c4 e2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm4,4),%ymm1
    1685:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    168c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1690:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1695:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    1699:	c4 62 65 90 04 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm8
    169f:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    16a6:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
    16ab:	c4 c1 65 72 d0 11    	vpsrld $0x11,%ymm8,%ymm3
    16b1:	c5 d5 72 f2 06       	vpslld $0x6,%ymm2,%ymm5
    16b6:	c4 62 5d 90 14 82    	vpgatherdd %ymm4,(%rdx,%ymm0,4),%ymm10
    16bc:	c5 fd 72 f2 0a       	vpslld $0xa,%ymm2,%ymm0
    16c1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    16c5:	c4 c1 4d 72 d2 11    	vpsrld $0x11,%ymm10,%ymm6
    16cb:	c5 dd 72 f3 05       	vpslld $0x5,%ymm3,%ymm4
    16d0:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    16d4:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    16d8:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    16dc:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1744 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xa94>
    16e3:	00 
    16e4:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    16eb:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    16ef:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1757 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xaa7>
    16f6:	00 
    16f7:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 175f <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xaaf>
    16fe:	00 
    16ff:	c5 ed fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm2,%ymm3
    1705:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1709:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    170f:	c5 bd 66 e9          	vpcmpgtd %ymm1,%ymm8,%ymm5
    1713:	c4 e2 4d 90 24 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm4
    1719:	c4 42 75 39 d8       	vpminsd %ymm8,%ymm1,%ymm11
    171e:	c4 e2 45 90 04 9a    	vpgatherdd %ymm7,(%rdx,%ymm3,4),%ymm0
    1724:	c4 c2 75 3d f8       	vpmaxsd %ymm8,%ymm1,%ymm7
    1729:	c4 41 75 fe e0       	vpaddd %ymm8,%ymm1,%ymm12
    172e:	c5 ad 66 f7          	vpcmpgtd %ymm7,%ymm10,%ymm6
    1732:	c4 c1 75 66 c8       	vpcmpgtd %ymm8,%ymm1,%ymm1
    1737:	c4 c2 45 3d fa       	vpmaxsd %ymm10,%ymm7,%ymm7
    173c:	c4 e3 35 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm9,%ymm5
    1743:	c4 42 25 39 ca       	vpminsd %ymm10,%ymm11,%ymm9
    1748:	c4 41 5d db c5       	vpand  %ymm13,%ymm4,%ymm8
    174d:	c4 41 25 66 da       	vpcmpgtd %ymm10,%ymm11,%ymm11
    1752:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 177b <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xacb>
    1759:	00 00 60 
    175c:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    1761:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1765:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    1769:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
    176f:	c4 e2 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm5
    1775:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    177b:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1780:	c5 7e 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm14
    1786:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    178b:	c4 e3 6d 4c 0c 24 10 	vpblendvb %ymm1,(%rsp),%ymm2,%ymm1
    1792:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    1796:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    179b:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 17c4 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xb14>
    17a2:	00 00 b0 
    17a5:	c4 41 55 db dd       	vpand  %ymm13,%ymm5,%ymm11
    17aa:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    17af:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    17b3:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    17b8:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    17bd:	c4 e2 6d 90 1c 8a    	vpgatherdd %ymm2,(%rdx,%ymm1,4),%ymm3
    17c3:	c4 c1 7d db d5       	vpand  %ymm13,%ymm0,%ymm2
    17c8:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    17cd:	c4 c1 65 db cd       	vpand  %ymm13,%ymm3,%ymm1
    17d2:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    17d7:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    17db:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    17e0:	c5 a5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm11
    17e5:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    17ea:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    17ef:	c4 41 25 db dd       	vpand  %ymm13,%ymm11,%ymm11
    17f4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    17f9:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    17fe:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1803:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1808:	c5 bd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm8
    180d:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1811:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1816:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
    181b:	c4 c1 2d 72 f3 10    	vpslld $0x10,%ymm11,%ymm10
    1821:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1826:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    182b:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    1830:	c4 41 3d fa c4       	vpsubd %ymm12,%ymm8,%ymm8
    1835:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    183a:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    183f:	c4 62 3d 40 c6       	vpmulld %ymm6,%ymm8,%ymm8
    1844:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1849:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    184e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1853:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    1858:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    185d:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    1862:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1866:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    186a:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    186f:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    1874:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1879:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    187e:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1883:	c5 bd 72 f4 10       	vpslld $0x10,%ymm4,%ymm8
    1888:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    188c:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1891:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1896:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    189b:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    18a0:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    18a5:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    18a9:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    18ad:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    18b2:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    18b7:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    18bb:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    18bf:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 1908 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xc58>
    18c6:	00 00 
    18c8:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    18cc:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    18d2:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    18d7:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    18dc:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    18e0:	c5 f9 d6 41 f8       	vmovq  %xmm0,-0x8(%rcx)
    18e5:	c5 fa 7f 49 e8       	vmovdqu %xmm1,-0x18(%rcx)
    18ea:	49 39 c8             	cmp    %rcx,%r8
    18ed:	0f 85 9d f4 ff ff    	jne    d90 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)+0xe0>
    18f3:	c5 f8 77             	vzeroupper
    18f6:	c5 f8 28 b4 24 20 01 	vmovaps 0x120(%rsp),%xmm6
    18fd:	00 00 
    18ff:	c5 f8 28 bc 24 30 01 	vmovaps 0x130(%rsp),%xmm7
    1906:	00 00 
    1908:	c5 78 28 84 24 40 01 	vmovaps 0x140(%rsp),%xmm8
    190f:	00 00 
    1911:	c5 78 28 8c 24 50 01 	vmovaps 0x150(%rsp),%xmm9
    1918:	00 00 
    191a:	c5 78 28 94 24 60 01 	vmovaps 0x160(%rsp),%xmm10
    1921:	00 00 
    1923:	c5 78 28 9c 24 70 01 	vmovaps 0x170(%rsp),%xmm11
    192a:	00 00 
    192c:	c5 78 28 a4 24 80 01 	vmovaps 0x180(%rsp),%xmm12
    1933:	00 00 
    1935:	c5 78 28 ac 24 90 01 	vmovaps 0x190(%rsp),%xmm13
    193c:	00 00 
    193e:	c5 78 28 b4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm14
    1945:	00 00 
    1947:	c5 78 28 bc 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm15
    194e:	00 00 
    1950:	48 81 c4 c8 01 00 00 	add    $0x1c8,%rsp
    1957:	c3                   	ret
    1958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    195f:	00 

0000000000001960 <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    1960:	48 89 d0             	mov    %rdx,%rax
    1963:	4c 89 c2             	mov    %r8,%rdx
    1966:	48 83 f8 04          	cmp    $0x4,%rax
    196a:	74 14                	je     1980 <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20>
    196c:	49 89 d0             	mov    %rdx,%r8
    196f:	48 89 c2             	mov    %rax,%rdx
    1972:	e9 00 00 00 00       	jmp    1977 <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17>
    1977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    197e:	00 00 
    1980:	81 79 50 41 04 00 00 	cmpl   $0x441,0x50(%rcx)
    1987:	75 e3                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    1989:	83 79 54 21          	cmpl   $0x21,0x54(%rcx)
    198d:	75 dd                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    198f:	81 b9 b0 00 00 00 41 	cmpl   $0x441,0xb0(%rcx)
    1996:	04 00 00 
    1999:	75 d1                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    199b:	83 b9 b4 00 00 00 21 	cmpl   $0x21,0xb4(%rcx)
    19a2:	75 c8                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19a4:	81 b9 10 01 00 00 41 	cmpl   $0x441,0x110(%rcx)
    19ab:	04 00 00 
    19ae:	75 bc                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19b0:	83 b9 14 01 00 00 21 	cmpl   $0x21,0x114(%rcx)
    19b7:	75 b3                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19b9:	81 b9 70 01 00 00 41 	cmpl   $0x441,0x170(%rcx)
    19c0:	04 00 00 
    19c3:	75 a7                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19c5:	83 b9 74 01 00 00 21 	cmpl   $0x21,0x174(%rcx)
    19cc:	75 9e                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19ce:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    19d2:	75 98                	jne    196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19d4:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    19db:	74 8f                	je     196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19dd:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    19e4:	74 86                	je     196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19e6:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    19ed:	0f 84 79 ff ff ff    	je     196c <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc>
    19f3:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    19f7:	4d 89 c8             	mov    %r9,%r8
    19fa:	74 05                	je     1a01 <jshc_grid33::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa1>
    19fc:	e9 ff e5 ff ff       	jmp    0 <void jshc_grid33::(anonymous namespace)::fixed_four<true>(jshc_delta16::View const*, unsigned char*, unsigned long long)>
    1a01:	e9 aa f2 ff ff       	jmp    cb0 <void jshc_grid33::(anonymous namespace)::fixed_four<false>(jshc_delta16::View const*, unsigned char*, unsigned long long)>
    1a06:	90                   	nop
    1a07:	90                   	nop
    1a08:	90                   	nop
    1a09:	90                   	nop
    1a0a:	90                   	nop
    1a0b:	90                   	nop
    1a0c:	90                   	nop
    1a0d:	90                   	nop
    1a0e:	90                   	nop
    1a0f:	90                   	nop
