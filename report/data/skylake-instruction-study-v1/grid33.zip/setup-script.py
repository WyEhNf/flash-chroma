"""生成独立33³常量地址候选；其他布局直接调用原AVX2对象。"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];out=root/'experiments/skylake-grid33-runtime';out.mkdir(exist_ok=False)
base=root/'experiments/skylake-delta16-runtime'
source=(base/'channel_avx2.cpp').read_text(encoding='utf-8').replace('namespace jshc_delta16 {','namespace jshc_grid33 {')
source=source.replace('_mm256_set1_epi32(v.sr+v.sg+1)','_mm256_set1_epi32(1123)')
source=source.replace('_mm256_set1_epi32(v.sr)','_mm256_set1_epi32(1089)').replace('_mm256_set1_epi32(v.sg)','_mm256_set1_epi32(33)')
old='''  const __m256i base=_mm256_add_epi32(_mm256_mullo_epi32(_mm256_srli_epi32(ar,17),_mm256_set1_epi32(1089)),
      _mm256_add_epi32(_mm256_mullo_epi32(_mm256_srli_epi32(ag,17),_mm256_set1_epi32(33)),_mm256_srli_epi32(ab,17)));'''
new='''  const __m256i ir=_mm256_srli_epi32(ar,17),ig=_mm256_srli_epi32(ag,17),ib=_mm256_srli_epi32(ab,17);
  const __m256i rbase=_mm256_add_epi32(ir,_mm256_add_epi32(_mm256_slli_epi32(ir,10),_mm256_slli_epi32(ir,6)));
  const __m256i gbase=_mm256_add_epi32(ig,_mm256_slli_epi32(ig,5));
  const __m256i base=_mm256_add_epi32(rbase,_mm256_add_epi32(gbase,ib));'''
assert source.count(old)==1;source=source.replace(old,new)
source=source.replace('// 有界有符号坐标差减少三次dword gather；RGB节点、Q16权重和逐级舍入保持精确。',
    '// 只为33³固定四级路径使用精确常量地址；节点、坐标和Q16算法不变。')
start=source.index('void avx2_chain(')
source=source[:start]+'''void avx2_chain(const View* chain,size_t stages,uint8_t* data,size_t pixels) noexcept {
  bool eligible=stages==4;
  if(eligible)for(size_t s=0;s<4;++s)eligible=eligible && chain[s].sr==1089 && chain[s].sg==33;
  if(eligible && !chain[0].shared && chain[1].shared && chain[2].shared && chain[3].shared) {
    if(chain[0].delta16)fixed_four<true>(chain,data,pixels);else fixed_four<false>(chain,data,pixels);
    return;
  }
  jshc_delta16::avx2_chain(chain,stages,data,pixels);
}
}
'''
(out/'channel_avx2.cpp').write_text(source,encoding='utf-8',newline='\n')
source=(base/'channel_runtime.cpp').read_text(encoding='utf-8').replace('jshc_delta16','jshc_grid33').replace('return 5;','return 19;')
(out/'channel_runtime.cpp').write_text(source,encoding='utf-8',newline='\n')
(out/'channel_views.hpp').write_text('''#pragma once
#include "../skylake-delta16-runtime/channel_views.hpp"
namespace jshc_grid33 {
using View=jshc_delta16::View;
void avx2_chain(const View*,size_t,uint8_t*,size_t) noexcept;
}
''',encoding='utf-8',newline='\n')
cmake=(root/'experiments/skylake-geometry-runtime/CMakeLists.txt').read_text(encoding='utf-8').replace('jshc_skylake_geometry','jshc_skylake_grid33')
cmake=cmake.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp")',
    '"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"\n  "${JSHC_ROOT}/experiments/skylake-delta16-runtime/channel_avx2.cpp")',1)
(out/'CMakeLists.txt').write_text(cmake,encoding='utf-8',newline='\n')
plan=json.loads((root/'experiments/skylake-geometry-v1.json').read_text(encoding='utf-8'));plan.pop('geometry_policy')
plan['purpose']='33³常量地址专门化对比坐标差修订5；不新增表或编码，其他网格直接链接原对象'
plan['candidate']='固定四级33³首级非共享/后三共享时，idx*1089用(<<10)+(<<6)+idx，idx*33用(<<5)+idx；stride与末角偏移常量化'
plan['cmake_project']='experiments/skylake-grid33-runtime';plan['cmake_targets']=['jshc_skylake_reference','jshc_skylake_grid33']
plan['revisions']={'reference':5,'candidate':19}
plan['grid33_policy']={'gate':'35/38gather两条实际四级循环各自Skylake周期至少下降3%；无调用、rsp不增加；回退对象同字节',
    'correctness':'原有限合同/差值边界之外，新增真实33³四级路径有限合同后，完整256³及100图逐字节一致',
    'performance':'唯一4进程AB/BA/BA/AB，各1/4线程平衡，每配置5轮100图；每轮SHA，中位至少3%收益、任一进程不退化超过2%、copy+apply不退化',
    'stop':'失败保留，不扫描网格尺寸、移位加法变体、宽度、块或重测'}
plan['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(set(plan['source_sha256'])|{p.relative_to(root).as_posix() for p in out.iterdir()})}
(root/'experiments/skylake-grid33-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('33³候选与计划已生成；数值调用0')
