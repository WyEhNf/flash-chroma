
artifacts\skylake-geometry-build-v1\CMakeFiles\jshc_skylake_reference.dir\F_\Hackathon\projects\16-lut-color\experiments\skylake-delta16-runtime\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	57                   	push   %rdi
       1:	56                   	push   %rsi
       2:	53                   	push   %rbx
       3:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
       a:	c5 f8 29 b4 24 20 02 	vmovaps %xmm6,0x220(%rsp)
      11:	00 00 
      13:	c5 f8 29 bc 24 30 02 	vmovaps %xmm7,0x230(%rsp)
      1a:	00 00 
      1c:	c5 78 29 84 24 40 02 	vmovaps %xmm8,0x240(%rsp)
      23:	00 00 
      25:	c5 78 29 8c 24 50 02 	vmovaps %xmm9,0x250(%rsp)
      2c:	00 00 
      2e:	c5 78 29 94 24 60 02 	vmovaps %xmm10,0x260(%rsp)
      35:	00 00 
      37:	c5 78 29 9c 24 70 02 	vmovaps %xmm11,0x270(%rsp)
      3e:	00 00 
      40:	c5 78 29 a4 24 80 02 	vmovaps %xmm12,0x280(%rsp)
      47:	00 00 
      49:	c5 78 29 ac 24 90 02 	vmovaps %xmm13,0x290(%rsp)
      50:	00 00 
      52:	c5 78 29 b4 24 a0 02 	vmovaps %xmm14,0x2a0(%rsp)
      59:	00 00 
      5b:	c5 78 29 bc 24 b0 02 	vmovaps %xmm15,0x2b0(%rsp)
      62:	00 00 
      64:	49 89 d3             	mov    %rdx,%r11
      67:	48 83 fa 04          	cmp    $0x4,%rdx
      6b:	0f 84 f8 08 00 00    	je     969 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x969>
      71:	4d 85 c9             	test   %r9,%r9
      74:	0f 84 7a 08 00 00    	je     8f4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
      7a:	49 ff c9             	dec    %r9
      7d:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # 85 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x85>
      84:	00 
      85:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
      89:	49 c1 e9 03          	shr    $0x3,%r9
      8d:	49 c1 e2 05          	shl    $0x5,%r10
      91:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
      95:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
      9c:	00 00 
      9e:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # e6 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe6>
      a5:	00 
      a6:	49 01 ca             	add    %rcx,%r10
      a9:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
      ae:	b8 00 80 00 00       	mov    $0x8000,%eax
      b3:	c5 f9 6e c0          	vmovd  %eax,%xmm0
      b7:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
      be:	00 00 
      c0:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
      c4:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
      c9:	c5 95 72 d6 18       	vpsrld $0x18,%ymm6,%ymm13
      ce:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
      d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
      d8:	c4 c1 7a 6f 10       	vmovdqu (%r8),%xmm2
      dd:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
      e3:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
      e9:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
      ef:	c4 e2 6d 00 94 24 e0 	vpshufb 0x1e0(%rsp),%ymm2,%ymm2
      f6:	01 00 00 
      f9:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
      fe:	c4 c1 6d db c5       	vpand  %ymm13,%ymm2,%ymm0
     103:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     108:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     10d:	4d 85 db             	test   %r11,%r11
     110:	0f 84 4a 08 00 00    	je     960 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x960>
     116:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
     11d:	00 00 
     11f:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     123:	48 89 c8             	mov    %rcx,%rax
     126:	c5 fd 6f cc          	vmovdqa %ymm4,%ymm1
     12a:	e9 22 02 00 00       	jmp    351 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
     12f:	90                   	nop
     130:	c4 c1 5d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm4
     136:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
     13b:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     13f:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
     143:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
     147:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     14c:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     152:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
     157:	c5 dd fe ef          	vpaddd %ymm7,%ymm4,%ymm5
     15b:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
     162:	00 00 
     164:	c4 c1 55 72 e1 10    	vpsrad $0x10,%ymm9,%ymm5
     16a:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
     170:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     174:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
     17a:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
     180:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
     184:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
     188:	c5 b5 fe db          	vpaddd %ymm3,%ymm9,%ymm3
     18c:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
     190:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
     195:	c5 75 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm8
     199:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
     1a0:	00 00 
     1a2:	c4 c1 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm2
     1a7:	c4 62 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm10
     1ac:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
     1b1:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
     1b5:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
     1ba:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     1bf:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
     1c3:	c4 63 1d 4c 44 24 60 	vpblendvb %ymm8,0x60(%rsp),%ymm12,%ymm8
     1ca:	80 
     1cb:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     1d1:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm8,%ymm8        # 1fa <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fa>
     1d8:	00 00 20 
     1db:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
     1e1:	c4 e3 1d 4c 4c 24 60 	vpblendvb %ymm1,0x60(%rsp),%ymm12,%ymm1
     1e8:	10 
     1e9:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 212 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x212>
     1f0:	00 00 a0 
     1f3:	c4 a2 0d 90 14 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm2
     1f9:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
     1fd:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     201:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
     207:	c5 fe 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm1
     20e:	00 00 
     210:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     215:	c4 62 5d 3d c7       	vpmaxsd %ymm7,%ymm4,%ymm8
     21a:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     21f:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     224:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     228:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     22d:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     232:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     236:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
     23a:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
     241:	00 00 
     243:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
     247:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     24c:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
     252:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     257:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
     25c:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
     261:	c4 62 35 39 d5       	vpminsd %ymm5,%ymm9,%ymm10
     266:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
     26a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     26e:	c5 c5 66 dc          	vpcmpgtd %ymm4,%ymm7,%ymm3
     272:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
     279:	00 00 
     27b:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     27f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     286:	00 00 
     288:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     28c:	c4 c1 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm2
     291:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
     297:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
     29d:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
     2a1:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
     2a6:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm4,%ymm4        # 2cf <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2cf>
     2ad:	00 00 90 
     2b0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2b5:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
     2ba:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm3,%ymm3        # 2e3 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2e3>
     2c1:	00 00 20 
     2c4:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     2c8:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
     2ce:	c4 e2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm2
     2d4:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     2da:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     2df:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     2e3:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     2e8:	c4 e2 1d 90 1c a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm3
     2ee:	c4 c1 45 fa e2       	vpsubd %ymm10,%ymm7,%ymm4
     2f3:	c5 fe 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm7
     2fa:	00 00 
     2fc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     301:	c5 dd fe ed          	vpaddd %ymm5,%ymm4,%ymm5
     305:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     30a:	c5 e5 fa e2          	vpsubd %ymm2,%ymm3,%ymm4
     30e:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
     312:	c4 e2 55 40 e4       	vpmulld %ymm4,%ymm5,%ymm4
     317:	c5 ed fa 94 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm2
     31e:	00 00 
     320:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     325:	48 83 c0 60          	add    $0x60,%rax
     329:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     32e:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     332:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
     339:	00 00 
     33b:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
     33f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     344:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     348:	49 39 c2             	cmp    %rax,%r10
     34b:	0f 84 46 05 00 00    	je     897 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x897>
     351:	8b 58 54             	mov    0x54(%rax),%ebx
     354:	48 8b 50 08          	mov    0x8(%rax),%rdx
     358:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     35f:	00 00 
     361:	c5 fd 6f c6          	vmovdqa %ymm6,%ymm0
     365:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
     36c:	00 00 
     36e:	8b 70 50             	mov    0x50(%rax),%esi
     371:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     375:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
     379:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
     37d:	c4 e2 7d 90 14 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm2
     383:	48 8b 10             	mov    (%rax),%rdx
     386:	48 8b 78 10          	mov    0x10(%rax),%rdi
     38a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     38f:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
     396:	00 00 
     398:	c5 79 6e e6          	vmovd  %esi,%xmm12
     39c:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
     3a1:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     3a7:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     3ac:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
     3b1:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
     3b5:	c4 e2 65 90 04 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm0
     3bb:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     3c0:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
     3c7:	00 00 
     3c9:	48 8b 50 48          	mov    0x48(%rax),%rdx
     3cd:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
     3d2:	c4 a2 2d 90 1c 9f    	vpgatherdd %ymm10,(%rdi,%ymm11,4),%ymm3
     3d8:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 440 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x440>
     3df:	00 
     3e0:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     3e5:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     3ea:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 452 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x452>
     3f1:	00 
     3f2:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 45a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x45a>
     3f9:	00 
     3fa:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
     3fe:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
     402:	c4 62 6d 39 c0       	vpminsd %ymm0,%ymm2,%ymm8
     407:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     40b:	c5 f5 fe e5          	vpaddd %ymm5,%ymm1,%ymm4
     40f:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
     413:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
     419:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     41f:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
     424:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     429:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
     430:	00 00 
     432:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     437:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     43c:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
     443:	00 00 
     445:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
     44a:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
     44f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     454:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
     45b:	00 00 
     45d:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     462:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     467:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
     46c:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
     473:	00 00 
     475:	c5 f9 6e ce          	vmovd  %esi,%xmm1
     479:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     47e:	c5 75 fe dc          	vpaddd %ymm4,%ymm1,%ymm11
     482:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
     486:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
     48a:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
     490:	c4 62 3d 39 c3       	vpminsd %ymm3,%ymm8,%ymm8
     495:	c4 22 75 90 14 9a    	vpgatherdd %ymm1,(%rdx,%ymm11,4),%ymm10
     49b:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
     49f:	c4 e3 1d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm12,%ymm1
     4a5:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # 4ce <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ce>
     4ac:	00 00 40 
     4af:	c5 ed 66 e0          	vpcmpgtd %ymm0,%ymm2,%ymm4
     4b3:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
     4b7:	c4 41 2d db dd       	vpand  %ymm13,%ymm10,%ymm11
     4bc:	c4 e2 35 90 3c 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm7
     4c2:	c5 0d fe 34 24       	vpaddd (%rsp),%ymm14,%ymm14
     4c7:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     4cb:	c5 95 db cf          	vpand  %ymm7,%ymm13,%ymm1
     4cf:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
     4d6:	00 00 
     4d8:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
     4de:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
     4e2:	c4 c2 25 40 f8       	vpmulld %ymm8,%ymm11,%ymm7
     4e7:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
     4eb:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     4f2:	00 00 
     4f4:	c4 e2 6d 3d f8       	vpmaxsd %ymm0,%ymm2,%ymm7
     4f9:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
     4fd:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
     502:	c5 3d fe ff          	vpaddd %ymm7,%ymm8,%ymm15
     506:	c4 41 65 fa ff       	vpsubd %ymm15,%ymm3,%ymm15
     50b:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm4,%ymm4        # 534 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x534>
     512:	00 00 90 
     515:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
     51b:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
     521:	c5 6d fe d8          	vpaddd %ymm0,%ymm2,%ymm11
     525:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
     52a:	c4 41 05 fe db       	vpaddd %ymm11,%ymm15,%ymm11
     52f:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     533:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     537:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     53c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     541:	c5 dd fe a4 24 80 00 	vpaddd 0x80(%rsp),%ymm4,%ymm4
     548:	00 00 
     54a:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
     54f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     553:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
     558:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
     55e:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     564:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
     56b:	00 00 
     56d:	c4 41 75 db fd       	vpand  %ymm13,%ymm1,%ymm15
     572:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     579:	00 00 
     57b:	c4 c1 2d db ed       	vpand  %ymm13,%ymm10,%ymm5
     580:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
     587:	00 00 
     589:	0f 85 49 02 00 00    	jne    7d8 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d8>
     58f:	48 8b 58 28          	mov    0x28(%rax),%rbx
     593:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
     59a:	00 00 
     59c:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5a0:	48 8b 78 18          	mov    0x18(%rax),%rdi
     5a4:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
     5a8:	c4 62 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm9
     5ae:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
     5b5:	00 00 
     5b7:	48 8b 58 20          	mov    0x20(%rax),%rbx
     5bb:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5bf:	c4 e2 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm1
     5c5:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
     5cc:	00 00 
     5ce:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     5d2:	c4 62 45 90 04 af    	vpgatherdd %ymm7,(%rdi,%ymm5,4),%ymm8
     5d8:	0f 85 52 fb ff ff    	jne    130 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
     5de:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 646 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x646>
     5e5:	00 
     5e6:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 64e <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x64e>
     5ed:	00 
     5ee:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     5f2:	c5 b5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm3        # 65a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x65a>
     5f9:	00 
     5fa:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
     600:	c4 e2 3d 3d e9       	vpmaxsd %ymm1,%ymm8,%ymm5
     605:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
     60a:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
     610:	c4 e2 3d 39 e1       	vpminsd %ymm1,%ymm8,%ymm4
     615:	c5 e5 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm0
     619:	c4 e2 5d 39 fb       	vpminsd %ymm3,%ymm4,%ymm7
     61e:	c4 e2 55 3d eb       	vpmaxsd %ymm3,%ymm5,%ymm5
     623:	48 8b 58 40          	mov    0x40(%rax),%rbx
     627:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
     62b:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
     631:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm2,%ymm2        # 65a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x65a>
     638:	00 00 00 
     63b:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
     640:	c4 e2 0d 90 04 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm0
     646:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
     64a:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     64e:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
     652:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
     657:	c5 d5 fe cf          	vpaddd %ymm7,%ymm5,%ymm1
     65b:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     65f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
     664:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     668:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
     66e:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
     672:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 69b <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x69b>
     679:	00 00 40 
     67c:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
     682:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
     686:	c4 e2 0d 90 24 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm4
     68c:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
     690:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     695:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     69a:	c5 05 fa fc          	vpsubd %ymm4,%ymm15,%ymm15
     69e:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
     6a2:	c4 62 05 40 ff       	vpmulld %ymm7,%ymm15,%ymm15
     6a7:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     6ae:	00 00 
     6b0:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     6b5:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
     6bc:	00 00 
     6be:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
     6c5:	00 00 
     6c7:	c4 e2 65 90 24 bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm4
     6cd:	48 8b 58 38          	mov    0x38(%rax),%rbx
     6d1:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
     6d8:	00 00 
     6da:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     6de:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     6e3:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 74b <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x74b>
     6ea:	00 
     6eb:	c4 e2 65 90 2c bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm5
     6f1:	48 8b 58 30          	mov    0x30(%rax),%rbx
     6f5:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     6f9:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 761 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x761>
     700:	00 
     701:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
     706:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
     70b:	c4 e2 45 90 1c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm3
     711:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 779 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x779>
     718:	00 
     719:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
     720:	00 00 
     722:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     727:	c5 d5 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm7
     72b:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
     730:	c4 c1 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm2
     735:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
     73a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     73e:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     743:	c4 c3 1d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm12,%ymm7
     749:	c4 62 35 39 d4       	vpminsd %ymm4,%ymm9,%ymm10
     74e:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     752:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm7,%ymm7        # 77b <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x77b>
     759:	00 00 20 
     75c:	c5 35 66 cc          	vpcmpgtd %ymm4,%ymm9,%ymm9
     760:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     765:	c4 e2 0d 90 14 ba    	vpgatherdd %ymm14,(%rdx,%ymm7,4),%ymm2
     76b:	c5 e5 66 fd          	vpcmpgtd %ymm5,%ymm3,%ymm7
     76f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     773:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     778:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     77d:	c4 c3 1d 4c ff 70    	vpblendvb %ymm7,%ymm15,%ymm12,%ymm7
     783:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm7,%ymm7        # 7ac <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7ac>
     78a:	00 00 90 
     78d:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     793:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     797:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
     79b:	c4 62 1d 90 0c ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm9
     7a1:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     7a6:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     7ac:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     7b0:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     7b5:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     7b9:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
     7bd:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
     7c2:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
     7c9:	00 00 
     7cb:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
     7d0:	e9 42 fb ff ff       	jmp    317 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x317>
     7d5:	0f 1f 00             	nopl   (%rax)
     7d8:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
     7df:	00 00 
     7e1:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
     7e7:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     7ed:	48 83 c0 60          	add    $0x60,%rax
     7f1:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     7f6:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     7fb:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
     800:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     805:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
     80a:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     80f:	c5 85 fa c2          	vpsubd %ymm2,%ymm15,%ymm0
     813:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     817:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     81c:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     821:	c5 f5 fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm1,%ymm1
     828:	00 00 
     82a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     82f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     833:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
     83a:	00 00 
     83c:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     840:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
     845:	c5 35 fa 8c 24 40 01 	vpsubd 0x140(%rsp),%ymm9,%ymm9
     84c:	00 00 
     84e:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     853:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
     85a:	00 00 
     85c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     861:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
     866:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     86a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     86f:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     873:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     877:	c5 35 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm9,%ymm9
     87e:	00 00 
     880:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     885:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     88a:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
     88e:	49 39 c2             	cmp    %rax,%r10
     891:	0f 85 ba fa ff ff    	jne    351 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
     897:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
     89b:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
     8a2:	00 00 
     8a4:	c5 dd 72 f7 08       	vpslld $0x8,%ymm7,%ymm4
     8a9:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     8ae:	49 83 c0 18          	add    $0x18,%r8
     8b2:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
     8b6:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
     8ba:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
     8c1:	02 00 00 
     8c4:	c5 f9 6f e0          	vmovdqa %xmm0,%xmm4
     8c8:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     8ce:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
     8d3:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     8d8:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
     8dc:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     8e2:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     8e8:	4d 39 c1             	cmp    %r8,%r9
     8eb:	0f 85 e7 f7 ff ff    	jne    d8 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
     8f1:	c5 f8 77             	vzeroupper
     8f4:	c5 f8 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm6
     8fb:	00 00 
     8fd:	c5 f8 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm7
     904:	00 00 
     906:	c5 78 28 84 24 40 02 	vmovaps 0x240(%rsp),%xmm8
     90d:	00 00 
     90f:	c5 78 28 8c 24 50 02 	vmovaps 0x250(%rsp),%xmm9
     916:	00 00 
     918:	c5 78 28 94 24 60 02 	vmovaps 0x260(%rsp),%xmm10
     91f:	00 00 
     921:	c5 78 28 9c 24 70 02 	vmovaps 0x270(%rsp),%xmm11
     928:	00 00 
     92a:	c5 78 28 a4 24 80 02 	vmovaps 0x280(%rsp),%xmm12
     931:	00 00 
     933:	c5 78 28 ac 24 90 02 	vmovaps 0x290(%rsp),%xmm13
     93a:	00 00 
     93c:	c5 78 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm14
     943:	00 00 
     945:	c5 78 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm15
     94c:	00 00 
     94e:	48 81 c4 c0 02 00 00 	add    $0x2c0,%rsp
     955:	5b                   	pop    %rbx
     956:	5e                   	pop    %rsi
     957:	5f                   	pop    %rdi
     958:	c3                   	ret
     959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     960:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
     964:	e9 3b ff ff ff       	jmp    8a4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8a4>
     969:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     96d:	0f 85 fe f6 ff ff    	jne    71 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     973:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     97a:	0f 84 f1 f6 ff ff    	je     71 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     980:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     987:	0f 84 e4 f6 ff ff    	je     71 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     98d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     994:	0f 84 d7 f6 ff ff    	je     71 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     99a:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     99e:	0f 85 ff 0b 00 00    	jne    15a3 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15a3>
     9a4:	4d 85 c9             	test   %r9,%r9
     9a7:	0f 84 47 ff ff ff    	je     8f4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
     9ad:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # 9b5 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9b5>
     9b4:	00 
     9b5:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     9b9:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     9be:	48 c1 e8 03          	shr    $0x3,%rax
     9c2:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
     9c8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
     9cc:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
     9d3:	00 00 
     9d5:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # a1d <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa1d>
     9dc:	00 
     9dd:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
     9e2:	b8 00 80 00 00       	mov    $0x8000,%eax
     9e7:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
     9ee:	00 00 
     9f0:	c5 f9 6e f0          	vmovd  %eax,%xmm6
     9f4:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     9f9:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
     9fe:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     a03:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     a09:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a0d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     a12:	48 8b 01             	mov    (%rcx),%rax
     a15:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     a19:	49 83 c0 18          	add    $0x18,%r8
     a1d:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     a23:	8b 51 50             	mov    0x50(%rcx),%edx
     a26:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     a2c:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
     a31:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
     a38:	01 00 00 
     a3b:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     a3f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     a44:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
     a49:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
     a4e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     a53:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
     a59:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
     a5e:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
     a63:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     a68:	c4 e2 65 90 04 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm0
     a6e:	48 8b 41 08          	mov    0x8(%rcx),%rax
     a72:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     a78:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a7c:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
     a82:	48 8b 41 10          	mov    0x10(%rcx),%rax
     a86:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     a8a:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     a8f:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # af7 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xaf7>
     a96:	00 
     a97:	c4 a2 65 90 24 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm4
     a9d:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
     aa2:	48 8b 41 48          	mov    0x48(%rcx),%rax
     aa6:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # b0e <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb0e>
     aad:	00 
     aae:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
     ab3:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     ab8:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
     abd:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # b25 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb25>
     ac4:	00 
     ac5:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
     aca:	c4 62 3d 3d f4       	vpmaxsd %ymm4,%ymm8,%ymm14
     acf:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     ad3:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     ad7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     adb:	c4 62 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm12
     ae1:	c5 f9 6e da          	vmovd  %edx,%xmm3
     ae5:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     aea:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     aee:	c4 e2 2d 90 2c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm5
     af4:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
     af9:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
     b00:	00 00 
     b02:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
     b07:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     b0e:	00 00 
     b10:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
     b14:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
     b19:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
     b1d:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
     b23:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # b4c <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb4c>
     b2a:	00 00 a0 
     b2d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     b32:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     b36:	c4 62 2d 90 34 a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm14
     b3c:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
     b40:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     b44:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
     b4a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # b73 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb73>
     b51:	00 00 80 
     b54:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     b59:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     b5d:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
     b63:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
     b69:	c4 c1 0d db ed       	vpand  %ymm13,%ymm14,%ymm5
     b6e:	c5 35 fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm14
     b75:	00 00 
     b77:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
     b7c:	c5 15 db 64 24 60    	vpand  0x60(%rsp),%ymm13,%ymm12
     b82:	48 8b 51 28          	mov    0x28(%rcx),%rdx
     b86:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
     b8b:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     b91:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     b95:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
     b99:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
     b9f:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
     ba4:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
     ba9:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     bae:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
     bb5:	00 00 00 
     bb8:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     bbd:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     bc1:	c5 95 db a4 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm4
     bc8:	00 00 
     bca:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     bcf:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     bd4:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     bd9:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     bdd:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     be1:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
     be7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     bec:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     bf3:	00 00 
     bf5:	c4 a2 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm5
     bfb:	48 8b 51 20          	mov    0x20(%rcx),%rdx
     bff:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # c67 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc67>
     c06:	00 
     c07:	c4 62 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm8
     c0d:	48 8b 51 18          	mov    0x18(%rcx),%rdx
     c11:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     c16:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # c7e <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc7e>
     c1d:	00 
     c1e:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
     c24:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # c8c <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc8c>
     c2b:	00 
     c2c:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
     c31:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
     c35:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
     c39:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
     c3e:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
     c43:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
     c49:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # c72 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc72>
     c50:	00 00 a0 
     c53:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
     c58:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
     c5f:	00 00 
     c61:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
     c65:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
     c69:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     c6e:	c4 62 2d 90 24 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm12
     c74:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
     c79:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     c7e:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     c83:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     c88:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
     c8e:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # cb7 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcb7>
     c95:	00 00 60 
     c98:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     c9c:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
     ca2:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
     ca8:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
     caf:	00 00 
     cb1:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     cb6:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     cbb:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     cc1:	c4 41 5d db f5       	vpand  %ymm13,%ymm4,%ymm14
     cc6:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
     ccc:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
     cd3:	00 00 
     cd5:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
     cdc:	00 00 
     cde:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
     ce3:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
     ce8:	c4 41 1d fe e1       	vpaddd %ymm9,%ymm12,%ymm12
     ced:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
     cf3:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     cf8:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     cfc:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
     d00:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     d05:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
     d0a:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
     d0f:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     d14:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
     d18:	c5 95 db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm13,%ymm0
     d1f:	00 00 
     d21:	48 8b 51 40          	mov    0x40(%rcx),%rdx
     d25:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     d2b:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
     d30:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
     d37:	00 00 00 
     d3a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     d3e:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
     d44:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
     d48:	c4 a2 3d 90 04 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm0
     d4e:	48 8b 51 38          	mov    0x38(%rcx),%rdx
     d52:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     d57:	c5 9d 72 d5 10       	vpsrld $0x10,%ymm5,%ymm12
     d5c:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # dc4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdc4>
     d63:	00 
     d64:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     d69:	c4 e2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm4,4),%ymm5
     d6f:	48 8b 51 30          	mov    0x30(%rcx),%rdx
     d73:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     d78:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # de0 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde0>
     d7f:	00 
     d80:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
     d86:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # dee <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdee>
     d8d:	00 
     d8e:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
     d93:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
     d97:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
     d9c:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
     da1:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
     da7:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # dd0 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdd0>
     dae:	00 00 90 
     db1:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     db6:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
     dba:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
     dbf:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
     dc3:	c4 e2 25 90 14 b0    	vpgatherdd %ymm11,(%rax,%ymm6,4),%ymm2
     dc9:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
     dcd:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     dd1:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
     dd7:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     ddb:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # e04 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe04>
     de2:	00 00 90 
     de5:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
     dea:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
     dee:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
     df3:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     df8:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
     dfe:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
     e03:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
     e09:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     e0d:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
     e12:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     e19:	00 00 
     e1b:	48 8b 41 60          	mov    0x60(%rcx),%rax
     e1f:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
     e24:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     e29:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
     e2d:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     e32:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
     e37:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     e3c:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
     e41:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
     e45:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
     e4a:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     e4f:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     e53:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     e57:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
     e5c:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     e63:	00 00 
     e65:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
     e69:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     e6d:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     e72:	c4 e2 65 90 24 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm4
     e78:	48 8b 41 68          	mov    0x68(%rcx),%rax
     e7c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     e80:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     e84:	c4 a2 4d 90 2c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm5
     e8a:	48 8b 41 70          	mov    0x70(%rcx),%rax
     e8e:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
     e95:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
     e9b:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
     ea0:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
     ea4:	c5 79 6e ca          	vmovd  %edx,%xmm9
     ea8:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     ead:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     eb1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     eb6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     ebb:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
     ec2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ec7:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     ecc:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # f34 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf34>
     ed3:	00 
     ed4:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
     eda:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
     edf:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
     ee6:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # f4e <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf4e>
     eed:	00 
     eee:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     ef3:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
     ef8:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     efd:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # f65 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf65>
     f04:	00 
     f05:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
     f0a:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
     f0f:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
     f13:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
     f18:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
     f1c:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     f20:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     f24:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     f28:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
     f2e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     f32:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     f37:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     f3b:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
     f41:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     f45:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
     f4b:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
     f4f:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     f54:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     f58:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     f5d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     f61:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
     f67:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # f90 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf90>
     f6e:	00 00 70 
     f71:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     f76:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     f7a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     f7e:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     f84:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
     f89:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
     f8e:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
     f94:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
     f9a:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
     f9f:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
     fa4:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
     fa9:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
     fae:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm2,%ymm2        # fd7 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfd7>
     fb5:	00 00 b0 
     fb8:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
     fbc:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
     fc1:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
     fc6:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
     fcc:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
     fd1:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
     fd5:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
     fdc:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
     fe1:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     fe6:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
     feb:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
     fef:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
     ff4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ff9:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     ffe:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1003:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1007:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    100c:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    1011:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    1015:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    101a:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    101f:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1024:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1029:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    102e:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    1034:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    1039:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    103e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1042:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    1047:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    104c:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1051:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1056:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    105b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1060:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1065:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    106a:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    106f:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    1074:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    1079:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    107e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1082:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    1087:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    108c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1091:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    1096:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    109b:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    10a0:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    10a4:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    10a8:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    10ad:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    10b1:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    10b6:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    10bb:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    10bf:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    10c4:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    10c8:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    10cc:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    10d2:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    10d9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    10dd:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    10e1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    10e5:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    10e9:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    10ef:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    10f6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    10fb:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1100:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1106:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    110c:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1111:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    1118:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    111d:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    1122:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 118a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x118a>
    1129:	00 
    112a:	c5 79 6e ca          	vmovd  %edx,%xmm9
    112e:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1133:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 119b <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x119b>
    113a:	00 
    113b:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    1142:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1147:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 11af <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11af>
    114e:	00 
    114f:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1154:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    1159:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    115e:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    1163:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    1167:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    116b:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    116f:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    1173:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1177:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    117d:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1181:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    1187:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    118c:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1190:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1196:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    119a:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    11a0:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    11a4:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    11a9:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    11ad:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    11b2:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    11b6:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    11bc:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 11e5 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11e5>
    11c3:	00 00 70 
    11c6:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    11cb:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    11cf:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    11d3:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    11d9:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    11de:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    11e3:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    11e9:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    11ef:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    11f4:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    11f9:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    11fe:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    1203:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm2,%ymm2        # 122c <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x122c>
    120a:	00 00 b0 
    120d:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    1211:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    1216:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    121b:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    1221:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    1226:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    122a:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    1231:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    1236:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    123b:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    1240:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1244:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1249:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    124e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1253:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1258:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    125c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1261:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    1266:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    126a:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    126f:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    1274:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1279:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    127e:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    1283:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    1289:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    128e:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    1293:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1297:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    129c:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    12a1:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    12a6:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    12ab:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    12b0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12b5:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    12ba:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    12bf:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    12c4:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    12c9:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    12ce:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    12d3:	c5 79 6e ca          	vmovd  %edx,%xmm9
    12d7:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    12db:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    12e0:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    12e5:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    12ea:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    12ef:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    12f4:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    12f9:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    12fe:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    1302:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1306:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    130b:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    130f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1314:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1319:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    131d:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    1322:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1327:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    132b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    132f:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    1335:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    133c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1340:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1344:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1348:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    134c:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    1352:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    1359:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    135e:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1363:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 13cb <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13cb>
    136a:	00 
    136b:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1371:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1376:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 13de <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13de>
    137d:	00 
    137e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1383:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    1388:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    138d:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 13f5 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13f5>
    1394:	00 
    1395:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    139c:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    13a1:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    13a6:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    13aa:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    13af:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    13b3:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    13b7:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    13bb:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    13bf:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    13c5:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    13c9:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    13ce:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    13d2:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    13d8:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    13dc:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    13e2:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    13e6:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    13eb:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    13ef:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    13f4:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    13fa:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 1423 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1423>
    1401:	00 00 70 
    1404:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    1409:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    140d:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1411:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1417:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    141c:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1421:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    1427:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    142d:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    1432:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1437:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    143c:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    1441:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm2,%ymm2        # 146a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x146a>
    1448:	00 00 b0 
    144b:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    144f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1453:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    1458:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    145e:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    1463:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    1467:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    146c:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1471:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    1476:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    147a:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    147f:	c4 41 15 db e4       	vpand  %ymm12,%ymm13,%ymm12
    1484:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    1489:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    148e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1493:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1498:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    149c:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    14a1:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    14a5:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    14aa:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    14af:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    14b4:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    14ba:	c5 95 db f6          	vpand  %ymm6,%ymm13,%ymm6
    14be:	c5 95 db d2          	vpand  %ymm2,%ymm13,%ymm2
    14c2:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    14c7:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    14cc:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    14d1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    14d6:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    14da:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    14df:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    14e4:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    14e9:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    14ee:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    14f3:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    14f8:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    14fd:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    1502:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    1506:	c4 c1 75 db f5       	vpand  %ymm13,%ymm1,%ymm6
    150b:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    1510:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1515:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    151a:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    151f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    1524:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    1528:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    152c:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1530:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1535:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    153a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    153f:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    1544:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    1549:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    154d:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1551:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1555:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    155a:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    155f:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    1563:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    1567:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    156e:	02 00 00 
    1571:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1575:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    157b:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1580:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1585:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1589:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    158f:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1595:	4d 39 c2             	cmp    %r8,%r10
    1598:	0f 85 60 f4 ff ff    	jne    9fe <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9fe>
    159e:	e9 4e f3 ff ff       	jmp    8f1 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    15a3:	4d 85 c9             	test   %r9,%r9
    15a6:	0f 84 48 f3 ff ff    	je     8f4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    15ac:	c5 fd 6f 35 00 00 00 	vmovdqa 0x0(%rip),%ymm6        # 15b4 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15b4>
    15b3:	00 
    15b4:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    15b8:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    15bd:	48 c1 e8 03          	shr    $0x3,%rax
    15c1:	c4 c1 35 72 d7 18    	vpsrld $0x18,%ymm15,%ymm9
    15c7:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    15cb:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    15d2:	00 00 
    15d4:	c5 fd 6f 35 40 00 00 	vmovdqa 0x40(%rip),%ymm6        # 161c <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x161c>
    15db:	00 
    15dc:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    15e1:	b8 00 80 00 00       	mov    $0x8000,%eax
    15e6:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    15ed:	00 00 
    15ef:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    15f3:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    15f8:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    15fd:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    1602:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    1608:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    160c:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    1611:	48 8b 01             	mov    (%rcx),%rax
    1614:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    1618:	49 83 c0 18          	add    $0x18,%r8
    161c:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1622:	8b 51 50             	mov    0x50(%rcx),%edx
    1625:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    162b:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    1630:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    1637:	01 00 00 
    163a:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    163e:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    1643:	c4 c1 7d db d9       	vpand  %ymm9,%ymm0,%ymm3
    1648:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    164d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1652:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    1658:	48 8b 41 08          	mov    0x8(%rcx),%rax
    165c:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    1661:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1665:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    166a:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    166f:	c4 a2 4d 90 14 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm2
    1675:	48 8b 41 10          	mov    0x10(%rcx),%rax
    1679:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    167d:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
    1682:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 16ea <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16ea>
    1689:	00 
    168a:	c4 e2 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm0
    1690:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    1695:	48 8b 41 48          	mov    0x48(%rcx),%rax
    1699:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 1701 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1701>
    16a0:	00 
    16a1:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
    16a6:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    16ab:	c5 ad 72 d0 11       	vpsrld $0x11,%ymm0,%ymm10
    16b0:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1718 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1718>
    16b7:	00 
    16b8:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    16bc:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    16c0:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    16c5:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    16ca:	c4 62 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm12
    16d0:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    16d4:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    16d8:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    16dd:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    16e3:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    16e7:	c4 62 15 90 24 b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm12
    16ed:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    16f2:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    16f8:	c4 62 15 90 34 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm14
    16fe:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    1702:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1706:	c4 22 65 90 2c 82    	vpgatherdd %ymm3,(%rdx,%ymm8,4),%ymm13
    170c:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    1710:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    1717:	00 00 
    1719:	c4 e2 2d 90 1c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm3
    171f:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
    1723:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    172a:	00 00 
    172c:	c4 e2 45 3d da       	vpmaxsd %ymm2,%ymm7,%ymm3
    1731:	c5 7d 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm8
    1735:	c4 62 65 3d e8       	vpmaxsd %ymm0,%ymm3,%ymm13
    173a:	c4 e2 45 39 da       	vpminsd %ymm2,%ymm7,%ymm3
    173f:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    1745:	c4 62 65 39 d0       	vpminsd %ymm0,%ymm3,%ymm10
    174a:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    174e:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm1,%ymm1        # 1777 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1777>
    1755:	00 00 80 
    1758:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    175d:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    1761:	c4 62 3d 90 24 88    	vpgatherdd %ymm8,(%rax,%ymm1,4),%ymm12
    1767:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
    176b:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    1771:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    1777:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm1,%ymm1        # 17a0 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17a0>
    177e:	00 00 30 
    1781:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1785:	c5 cd fa c9          	vpsubd %ymm1,%ymm6,%ymm1
    1789:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    178d:	c4 62 65 90 04 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm8
    1793:	c5 b5 db 4c 24 20    	vpand  0x20(%rsp),%ymm9,%ymm1
    1799:	c4 c1 1d db d9       	vpand  %ymm9,%ymm12,%ymm3
    179e:	c4 41 2d fe e5       	vpaddd %ymm13,%ymm10,%ymm12
    17a3:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    17a8:	c5 45 fe ea          	vpaddd %ymm2,%ymm7,%ymm13
    17ac:	c4 41 7d fa e4       	vpsubd %ymm12,%ymm0,%ymm12
    17b1:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
    17b8:	00 00 
    17ba:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
    17bf:	c5 3d fa e3          	vpsubd %ymm3,%ymm8,%ymm12
    17c3:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    17ca:	00 00 
    17cc:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
    17d1:	c5 e5 fa 9c 24 80 00 	vpsubd 0x80(%rsp),%ymm3,%ymm3
    17d8:	00 00 
    17da:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    17e1:	00 00 
    17e3:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    17e8:	c5 f5 fe 0c 24       	vpaddd (%rsp),%ymm1,%ymm1
    17ed:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    17f2:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    17f6:	c5 9d fe c9          	vpaddd %ymm1,%ymm12,%ymm1
    17fa:	c5 35 db 64 24 60    	vpand  0x60(%rsp),%ymm9,%ymm12
    1800:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    1805:	c4 c1 1d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm12
    180b:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    1810:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    1814:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    1818:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    181f:	00 00 
    1821:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1826:	c4 c1 3d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm8
    182c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1831:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    1835:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    183c:	00 00 
    183e:	c5 f5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm1
    1843:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    1848:	c4 41 3d fe d4       	vpaddd %ymm12,%ymm8,%ymm10
    184d:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1852:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1856:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    185d:	00 00 
    185f:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    1863:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    1869:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    186e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1872:	c5 e5 fe d0          	vpaddd %ymm0,%ymm3,%ymm2
    1876:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    187d:	00 00 
    187f:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
    1885:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    188a:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    188e:	c4 62 6d 3d e8       	vpmaxsd %ymm0,%ymm2,%ymm13
    1893:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
    1897:	c4 41 65 66 f5       	vpcmpgtd %ymm13,%ymm3,%ymm14
    189c:	c4 62 15 3d d3       	vpmaxsd %ymm3,%ymm13,%ymm10
    18a1:	c4 62 6d 39 e8       	vpminsd %ymm0,%ymm2,%ymm13
    18a6:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    18aa:	c4 c3 5d 4c fb 70    	vpblendvb %ymm7,%ymm11,%ymm4,%ymm7
    18b0:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm7,%ymm7        # 18d9 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18d9>
    18b7:	00 00 e0 
    18ba:	c4 62 15 39 f3       	vpminsd %ymm3,%ymm13,%ymm14
    18bf:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    18c3:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    18ca:	00 00 
    18cc:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    18d0:	c4 c3 5d 4c c3 00    	vpblendvb %ymm0,%ymm11,%ymm4,%ymm0
    18d6:	c4 62 4d 90 34 b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm14
    18dc:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    18e2:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    18e6:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 190f <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x190f>
    18ed:	00 00 d0 
    18f0:	c5 cd fa d8          	vpsubd %ymm0,%ymm6,%ymm3
    18f4:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    18f8:	c4 e2 4d 90 04 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm0
    18fe:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1904:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    1909:	c4 41 7d db e9       	vpand  %ymm9,%ymm0,%ymm13
    190e:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    1915:	00 00 
    1917:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    191c:	c4 41 65 db f1       	vpand  %ymm9,%ymm3,%ymm14
    1921:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    1926:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    192c:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
    1931:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    1936:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    193a:	c5 95 fa d3          	vpsubd %ymm3,%ymm13,%ymm2
    193e:	c5 cd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm6
    1943:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
    194a:	00 00 
    194c:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    1951:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
    1957:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    195e:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1963:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    1969:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    196e:	c5 c5 fe 14 24       	vpaddd (%rsp),%ymm7,%ymm2
    1973:	c4 c2 3d 39 fc       	vpminsd %ymm12,%ymm8,%ymm7
    1978:	c5 79 6e d2          	vmovd  %edx,%xmm10
    197c:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1981:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1986:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    198a:	c5 b5 db c6          	vpand  %ymm6,%ymm9,%ymm0
    198e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1992:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    1997:	c4 62 45 39 e9       	vpminsd %ymm1,%ymm7,%ymm13
    199c:	c5 c5 66 f9          	vpcmpgtd %ymm1,%ymm7,%ymm7
    19a0:	c4 e2 7d 40 84 24 80 	vpmulld 0x80(%rsp),%ymm0,%ymm0
    19a7:	00 00 00 
    19aa:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    19ae:	c4 c2 3d 3d dc       	vpmaxsd %ymm12,%ymm8,%ymm3
    19b3:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    19b7:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
    19bb:	c4 e2 65 3d d9       	vpmaxsd %ymm1,%ymm3,%ymm3
    19c0:	c5 8d 72 d2 10       	vpsrld $0x10,%ymm2,%ymm14
    19c5:	c4 c1 1d 66 d0       	vpcmpgtd %ymm8,%ymm12,%ymm2
    19ca:	c4 41 3d 66 c4       	vpcmpgtd %ymm12,%ymm8,%ymm8
    19cf:	c4 c3 5d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm4,%ymm2
    19d5:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm2,%ymm2        # 19fe <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19fe>
    19dc:	00 00 00 
    19df:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    19e3:	c4 e2 4d 90 04 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm0
    19e9:	c4 c3 5d 4c d3 80    	vpblendvb %ymm8,%ymm11,%ymm4,%ymm2
    19ef:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    19f5:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1a1e <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a1e>
    19fc:	00 00 70 
    19ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1a04:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    1a0a:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    1a0e:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    1a12:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    1a18:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    1a1d:	c4 c1 65 fe c5       	vpaddd %ymm13,%ymm3,%ymm0
    1a22:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1a28:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    1a2c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1a31:	48 8b 41 60          	mov    0x60(%rcx),%rax
    1a35:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    1a3a:	c5 dd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm4
    1a3f:	c5 fd fe 84 24 e0 00 	vpaddd 0xe0(%rsp),%ymm0,%ymm0
    1a46:	00 00 
    1a48:	c5 d5 fa ca          	vpsubd %ymm2,%ymm5,%ymm1
    1a4c:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    1a51:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1a56:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    1a5b:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    1a60:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1a64:	c5 c5 fe 0c 24       	vpaddd (%rsp),%ymm7,%ymm1
    1a69:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    1a6e:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1a72:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1a76:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1a7a:	c4 c1 4d db c9       	vpand  %ymm9,%ymm6,%ymm1
    1a7f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1a83:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1a87:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    1a8c:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    1a91:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    1a96:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1a9a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1a9e:	c5 fe 6f 8c 24 00 01 	vmovdqu 0x100(%rsp),%ymm1
    1aa5:	00 00 
    1aa7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1aac:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    1ab2:	48 8b 41 68          	mov    0x68(%rcx),%rax
    1ab6:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1aba:	c4 a2 4d 90 2c b0    	vpgatherdd %ymm6,(%rax,%ymm14,4),%ymm5
    1ac0:	48 8b 41 70          	mov    0x70(%rcx),%rax
    1ac4:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1ac9:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1b31 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b31>
    1ad0:	00 
    1ad1:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1ad7:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1adc:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    1ae3:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1b4b <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b4b>
    1aea:	00 
    1aeb:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1af0:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1af5:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    1afa:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1b62 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b62>
    1b01:	00 
    1b02:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    1b07:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    1b0c:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    1b10:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    1b15:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1b19:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1b1d:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    1b21:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1b25:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    1b2b:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1b2f:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1b34:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1b38:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    1b3c:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1b42:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    1b49:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    1b4f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    1b55:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    1b59:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1b5e:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    1b62:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    1b67:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    1b6b:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    1b71:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 1b9a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b9a>
    1b78:	00 00 70 
    1b7b:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    1b80:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1b84:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1b88:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1b8e:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    1b93:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1b98:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    1b9e:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    1ba4:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    1ba9:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1bae:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    1bb3:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    1bb8:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1be1 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1be1>
    1bbf:	00 00 c0 
    1bc2:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    1bc6:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    1bcb:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1bd0:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    1bd6:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    1bdb:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    1bdf:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    1be6:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    1beb:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1bf0:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    1bf5:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1bf9:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    1bfe:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1c03:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1c08:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1c0d:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1c11:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1c16:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    1c1b:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    1c1f:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    1c24:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1c29:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1c2e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1c33:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    1c38:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    1c3e:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    1c43:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    1c48:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1c4c:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    1c51:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    1c56:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1c5b:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1c60:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    1c65:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1c6a:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1c6f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    1c74:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    1c79:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    1c7e:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    1c83:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1c88:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1c8c:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1c90:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    1c95:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1c9a:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    1c9f:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    1ca4:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1ca9:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    1cae:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1cb3:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    1cb7:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1cbb:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1cc0:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1cc4:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1cc9:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1cce:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1cd2:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    1cd7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1cdc:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1ce0:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1ce4:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    1cea:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    1cf1:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1cf5:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1cf9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1cfd:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1d01:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    1d07:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    1d0e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1d13:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1d18:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1d80 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d80>
    1d1f:	00 
    1d20:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1d26:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1d2b:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    1d32:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1d9a <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d9a>
    1d39:	00 
    1d3a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1d3f:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1d44:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    1d49:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1db1 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1db1>
    1d50:	00 
    1d51:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    1d56:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    1d5b:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    1d5f:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    1d64:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1d68:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1d6c:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    1d70:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1d74:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    1d7a:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1d7e:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1d83:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1d87:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1d8d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    1d91:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    1d97:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    1d9b:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1da0:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    1da4:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    1da9:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    1dad:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    1db3:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 1ddc <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ddc>
    1dba:	00 00 70 
    1dbd:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    1dc2:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1dc6:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1dca:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    1dcf:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    1dd4:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    1dda:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1de0:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    1de6:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    1deb:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1e14 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1e14>
    1df2:	00 00 c0 
    1df5:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    1dfa:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1dff:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    1e06:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    1e0b:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    1e0f:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    1e13:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    1e19:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    1e1f:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    1e24:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1e29:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    1e30:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1e35:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    1e3a:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    1e3f:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1e43:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    1e48:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    1e4d:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1e52:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1e57:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1e5c:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1e61:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1e65:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    1e6a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    1e6e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    1e73:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    1e78:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1e7d:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    1e83:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1e88:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    1e8d:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    1e92:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    1e97:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    1e9c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1ea1:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    1ea5:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1eaa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1eaf:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    1eb4:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1eb9:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    1ebe:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    1ec3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1ec8:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    1ecd:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1ed2:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1ed6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1edb:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    1ee0:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1ee5:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1ee9:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    1eee:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    1ef3:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1ef8:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    1efd:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1f02:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    1f07:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    1f0b:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1f0f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1f14:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1f18:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1f1d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1f22:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1f26:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    1f2b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1f2f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1f33:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    1f39:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    1f40:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1f44:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1f48:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1f4c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1f50:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    1f56:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    1f5d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1f62:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1f67:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1fcf <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fcf>
    1f6e:	00 
    1f6f:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1f75:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1f7a:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    1f81:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1fe9 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fe9>
    1f88:	00 
    1f89:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1f8e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1f93:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    1f98:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2000 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2000>
    1f9f:	00 
    1fa0:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    1fa5:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    1faa:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    1fae:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    1fb3:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1fb7:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1fbb:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    1fbf:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1fc3:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    1fc9:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1fcd:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1fd2:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1fd6:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    1fdc:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    1fe0:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    1fe6:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    1fea:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1fef:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    1ff3:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    1ff8:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    1ffe:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 2027 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2027>
    2005:	00 00 70 
    2008:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    200d:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2011:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    2015:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    201b:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    2020:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    2025:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    202b:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    2031:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    2036:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    203b:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    2040:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 2069 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2069>
    2047:	00 00 c0 
    204a:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    204e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    2052:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    2057:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    205d:	c4 c1 7d db f1       	vpand  %ymm9,%ymm0,%ymm6
    2062:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    2066:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    206b:	c4 c1 55 db d1       	vpand  %ymm9,%ymm5,%ymm2
    2070:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2075:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    207a:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    207e:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    2083:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2088:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    208d:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    2092:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    2097:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    209c:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    20a0:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    20a5:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    20a9:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    20ae:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    20b3:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    20b8:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    20be:	c5 b5 db f6          	vpand  %ymm6,%ymm9,%ymm6
    20c2:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    20c7:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    20cc:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    20d1:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    20d6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    20db:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    20df:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    20e4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    20e9:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    20ee:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    20f3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    20f8:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    20fd:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    2102:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    2107:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    210b:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    2110:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    2115:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    211a:	c4 c1 65 db e9       	vpand  %ymm9,%ymm3,%ymm5
    211f:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    2124:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    2129:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    212d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2131:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    2135:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    213a:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    213f:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2144:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    2149:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    214e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2152:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    2156:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    215a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    215f:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    2164:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    2168:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    216c:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    2173:	02 00 00 
    2176:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    217a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2180:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2185:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    218a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    218e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2194:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    219a:	4d 39 c2             	cmp    %r8,%r10
    219d:	0f 85 5a f4 ff ff    	jne    15fd <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15fd>
    21a3:	e9 49 e7 ff ff       	jmp    8f1 <jshc_delta16::avx2_chain(jshc_delta16::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    21a8:	90                   	nop
    21a9:	90                   	nop
    21aa:	90                   	nop
    21ab:	90                   	nop
    21ac:	90                   	nop
    21ad:	90                   	nop
    21ae:	90                   	nop
    21af:	90                   	nop
