
artifacts\skylake-geometry-build-v1\CMakeFiles\jshc_skylake_geometry.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	57                   	push   %rdi
       1:	56                   	push   %rsi
       2:	53                   	push   %rbx
       3:	48 81 ec e0 02 00 00 	sub    $0x2e0,%rsp
       a:	c5 f8 29 b4 24 40 02 	vmovaps %xmm6,0x240(%rsp)
      11:	00 00 
      13:	c5 f8 29 bc 24 50 02 	vmovaps %xmm7,0x250(%rsp)
      1a:	00 00 
      1c:	c5 78 29 84 24 60 02 	vmovaps %xmm8,0x260(%rsp)
      23:	00 00 
      25:	c5 78 29 8c 24 70 02 	vmovaps %xmm9,0x270(%rsp)
      2c:	00 00 
      2e:	c5 78 29 94 24 80 02 	vmovaps %xmm10,0x280(%rsp)
      35:	00 00 
      37:	c5 78 29 9c 24 90 02 	vmovaps %xmm11,0x290(%rsp)
      3e:	00 00 
      40:	c5 78 29 a4 24 a0 02 	vmovaps %xmm12,0x2a0(%rsp)
      47:	00 00 
      49:	c5 78 29 ac 24 b0 02 	vmovaps %xmm13,0x2b0(%rsp)
      50:	00 00 
      52:	c5 78 29 b4 24 c0 02 	vmovaps %xmm14,0x2c0(%rsp)
      59:	00 00 
      5b:	c5 78 29 bc 24 d0 02 	vmovaps %xmm15,0x2d0(%rsp)
      62:	00 00 
      64:	49 89 d3             	mov    %rdx,%r11
      67:	48 83 fa 04          	cmp    $0x4,%rdx
      6b:	0f 84 d0 08 00 00    	je     941 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x941>
      71:	4d 85 c9             	test   %r9,%r9
      74:	0f 84 92 07 00 00    	je     80c <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x80c>
      7a:	49 ff c9             	dec    %r9
      7d:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 85 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x85>
      84:	00 
      85:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
      89:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      8e:	49 c1 e9 03          	shr    $0x3,%r9
      92:	49 c1 e2 05          	shl    $0x5,%r10
      96:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
      9a:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
      a1:	00 00 
      a3:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # eb <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xeb>
      aa:	00 
      ab:	49 01 ca             	add    %rcx,%r10
      ae:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
      b3:	b8 00 80 00 00       	mov    $0x8000,%eax
      b8:	c5 f9 6e e8          	vmovd  %eax,%xmm5
      bc:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
      c3:	00 00 
      c5:	c4 c1 45 72 d7 18    	vpsrld $0x18,%ymm15,%ymm7
      cb:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
      d0:	c5 fe 7f 6c 24 60    	vmovdqu %ymm5,0x60(%rsp)
      d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
      dd:	00 00 00 
      e0:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
      e5:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
      eb:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
      f1:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
      f7:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
      fe:	02 00 00 
     101:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     106:	c5 fd db cf          	vpand  %ymm7,%ymm0,%ymm1
     10a:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     10e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     113:	4d 85 db             	test   %r11,%r11
     116:	0f 84 1c 08 00 00    	je     938 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x938>
     11c:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     122:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     126:	48 89 c8             	mov    %rcx,%rax
     129:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
     12d:	e9 ed 01 00 00       	jmp    31f <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31f>
     132:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     138:	c4 c1 35 72 e0 10    	vpsrad $0x10,%ymm8,%ymm9
     13e:	c4 c1 5d 72 e2 10    	vpsrad $0x10,%ymm10,%ymm4
     144:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     149:	c5 cd 72 e1 10       	vpsrad $0x10,%ymm1,%ymm6
     14e:	c4 c1 2d 72 f2 10    	vpslld $0x10,%ymm10,%ymm10
     154:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     158:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     15d:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     163:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
     167:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
     16d:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
     172:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
     176:	c4 c1 2d 72 e2 10    	vpsrad $0x10,%ymm10,%ymm10
     17c:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     180:	c5 bd fe c2          	vpaddd %ymm2,%ymm8,%ymm0
     184:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
     188:	c4 42 7d 3d c2       	vpmaxsd %ymm10,%ymm0,%ymm8
     18d:	c5 ad 66 d8          	vpcmpgtd %ymm0,%ymm10,%ymm3
     191:	c4 c2 7d 39 c2       	vpminsd %ymm10,%ymm0,%ymm0
     196:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
     19b:	c4 62 3d 3d d9       	vpmaxsd %ymm1,%ymm8,%ymm11
     1a0:	c4 62 3d 39 c1       	vpminsd %ymm1,%ymm8,%ymm8
     1a5:	c4 42 7d 3d c0       	vpmaxsd %ymm8,%ymm0,%ymm8
     1aa:	c4 43 55 4c d5 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm10
     1b0:	c4 e3 15 4c dd 30    	vpblendvb %ymm3,%ymm5,%ymm13,%ymm3
     1b6:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm10,%ymm10        # 1df <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1df>
     1bd:	00 00 20 
     1c0:	c4 e2 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm2
     1c5:	c5 fd 66 c1          	vpcmpgtd %ymm1,%ymm0,%ymm0
     1c9:	c5 2d fe 94 24 e0 00 	vpaddd 0xe0(%rsp),%ymm10,%ymm10
     1d0:	00 00 
     1d2:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
     1d7:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     1dd:	c4 a2 1d 90 14 92    	vpgatherdd %ymm12,(%rdx,%ymm10,4),%ymm2
     1e3:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     1e8:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm3,%ymm3        # 211 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x211>
     1ef:	00 00 00 
     1f2:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     1f7:	c5 f5 fa db          	vpsubd %ymm3,%ymm1,%ymm3
     1fb:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     1ff:	c4 e2 1d 90 04 9a    	vpgatherdd %ymm12,(%rdx,%ymm3,4),%ymm0
     205:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     20a:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
     20f:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     213:	c5 0d fa f0          	vpsubd %ymm0,%ymm14,%ymm14
     217:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
     21b:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
     222:	00 00 
     224:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     229:	c4 62 0d 40 74 24 20 	vpmulld 0x20(%rsp),%ymm14,%ymm14
     230:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     235:	c5 0d fe f0          	vpaddd %ymm0,%ymm14,%ymm14
     239:	c4 e2 35 3d c4       	vpmaxsd %ymm4,%ymm9,%ymm0
     23e:	c5 cd 66 d8          	vpcmpgtd %ymm0,%ymm6,%ymm3
     242:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
     247:	c4 e2 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm0
     24c:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
     253:	00 00 
     255:	c5 0d fe f2          	vpaddd %ymm2,%ymm14,%ymm14
     259:	c4 c1 5d 66 d1       	vpcmpgtd %ymm9,%ymm4,%ymm2
     25e:	c4 e2 35 39 e4       	vpminsd %ymm4,%ymm9,%ymm4
     263:	c4 62 5d 39 ce       	vpminsd %ymm6,%ymm4,%ymm9
     268:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
     26e:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     272:	c4 43 55 4c d5 20    	vpblendvb %ymm2,%ymm13,%ymm5,%ymm10
     278:	c4 e3 15 4c d5 20    	vpblendvb %ymm2,%ymm5,%ymm13,%ymm2
     27e:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
     283:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm10,%ymm10        # 2ac <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ac>
     28a:	00 00 30 
     28d:	c4 e2 5d 3d d8       	vpmaxsd %ymm0,%ymm4,%ymm3
     292:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     296:	c5 2d fe 94 24 e0 00 	vpaddd 0xe0(%rsp),%ymm10,%ymm10
     29d:	00 00 
     29f:	c4 a2 1d 90 04 92    	vpgatherdd %ymm12,(%rdx,%ymm10,4),%ymm0
     2a5:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 2ce <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ce>
     2ac:	00 00 40 
     2af:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2b4:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     2b8:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     2bc:	c4 e2 55 90 24 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm4
     2c2:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
     2c9:	00 00 
     2cb:	c5 fd db d7          	vpand  %ymm7,%ymm0,%ymm2
     2cf:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     2d4:	c5 dd db e7          	vpand  %ymm7,%ymm4,%ymm4
     2d8:	c5 d5 fa c4          	vpsubd %ymm4,%ymm5,%ymm0
     2dc:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     2e0:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     2e5:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
     2ea:	c5 fd fe dc          	vpaddd %ymm4,%ymm0,%ymm3
     2ee:	c5 ed fa 84 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm0
     2f5:	00 00 
     2f7:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     2fc:	c5 fd fe 84 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm0
     303:	00 00 
     305:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     309:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     30e:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     312:	48 83 c0 60          	add    $0x60,%rax
     316:	49 39 c2             	cmp    %rax,%r10
     319:	0f 84 93 04 00 00    	je     7b2 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7b2>
     31f:	48 8b 70 08          	mov    0x8(%rax),%rsi
     323:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
     32a:	00 00 
     32c:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
     332:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     336:	8b 58 54             	mov    0x54(%rax),%ebx
     339:	48 8b 78 10          	mov    0x10(%rax),%rdi
     33d:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     342:	c4 e2 4d 90 1c 8e    	vpgatherdd %ymm6,(%rsi,%ymm1,4),%ymm3
     348:	48 8b 30             	mov    (%rax),%rsi
     34b:	c5 fe 7f ac 24 a0 00 	vmovdqu %ymm5,0xa0(%rsp)
     352:	00 00 
     354:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     358:	c5 79 6e eb          	vmovd  %ebx,%xmm13
     35c:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     361:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3c9 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3c9>
     368:	00 
     369:	48 8b 50 48          	mov    0x48(%rax),%rdx
     36d:	c4 e2 4d 90 14 ae    	vpgatherdd %ymm6,(%rsi,%ymm5,4),%ymm2
     373:	8b 70 50             	mov    0x50(%rax),%esi
     376:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     37b:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
     382:	00 00 
     384:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
     389:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
     38e:	c4 a2 1d 90 04 97    	vpgatherdd %ymm12,(%rdi,%ymm10,4),%ymm0
     394:	c5 f9 6e ee          	vmovd  %esi,%xmm5
     398:	c5 cd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm6
     39d:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
     3a1:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     3a6:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 40e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x40e>
     3ad:	00 
     3ae:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 416 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x416>
     3b5:	00 
     3b6:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
     3bb:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     3c0:	c4 62 65 39 c2       	vpminsd %ymm2,%ymm3,%ymm8
     3c5:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     3c9:	c5 75 fe de          	vpaddd %ymm6,%ymm1,%ymm11
     3cd:	c5 bd 66 f0          	vpcmpgtd %ymm0,%ymm8,%ymm6
     3d1:	c5 f9 6e ce          	vmovd  %esi,%xmm1
     3d5:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     3da:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
     3e1:	00 00 
     3e3:	c4 41 75 fe f3       	vpaddd %ymm11,%ymm1,%ymm14
     3e8:	c5 e5 66 ca          	vpcmpgtd %ymm2,%ymm3,%ymm1
     3ec:	c5 7e 7f 34 24       	vmovdqu %ymm14,(%rsp)
     3f1:	c4 e3 15 4c e5 10    	vpblendvb %ymm1,%ymm5,%ymm13,%ymm4
     3f7:	c4 c3 55 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm5,%ymm1
     3fd:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 426 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x426>
     404:	00 00 60 
     407:	c5 8d fa e4          	vpsubd %ymm4,%ymm14,%ymm4
     40b:	c4 e2 1d 90 34 a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm6
     411:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
     416:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
     41d:	00 00 
     41f:	c5 c5 db e6          	vpand  %ymm6,%ymm7,%ymm4
     423:	c4 e2 65 3d f2       	vpmaxsd %ymm2,%ymm3,%ymm6
     428:	c5 7d 66 ce          	vpcmpgtd %ymm6,%ymm0,%ymm9
     42c:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # 455 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x455>
     433:	00 00 90 
     436:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     43b:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     440:	c4 62 25 90 0c 8a    	vpgatherdd %ymm11,(%rdx,%ymm1,4),%ymm9
     446:	c4 62 4d 39 d8       	vpminsd %ymm0,%ymm6,%ymm11
     44b:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
     450:	c4 42 3d 3d db       	vpmaxsd %ymm11,%ymm8,%ymm11
     455:	c5 7e 7f 8c 24 c0 01 	vmovdqu %ymm9,0x1c0(%rsp)
     45c:	00 00 
     45e:	c4 c1 45 db c9       	vpand  %ymm9,%ymm7,%ymm1
     463:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     468:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     46e:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
     473:	c4 62 3d 39 c0       	vpminsd %ymm0,%ymm8,%ymm8
     478:	c4 22 35 90 14 a2    	vpgatherdd %ymm9,(%rdx,%ymm12,4),%ymm10
     47e:	c5 2d db e7          	vpand  %ymm7,%ymm10,%ymm12
     482:	c4 c1 35 72 f4 10    	vpslld $0x10,%ymm12,%ymm9
     488:	c5 7e 7f 4c 24 40    	vmovdqu %ymm9,0x40(%rsp)
     48e:	c4 22 25 90 0c b2    	vpgatherdd %ymm11,(%rdx,%ymm14,4),%ymm9
     494:	c4 c1 0d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm14
     49a:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     49e:	c5 0d db f7          	vpand  %ymm7,%ymm14,%ymm14
     4a2:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     4a8:	c5 7e 7f b4 24 00 01 	vmovdqu %ymm14,0x100(%rsp)
     4af:	00 00 
     4b1:	c4 c1 0d 72 f6 10    	vpslld $0x10,%ymm14,%ymm14
     4b7:	c5 2d db d7          	vpand  %ymm7,%ymm10,%ymm10
     4bb:	c5 0d fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm14,%ymm11
     4c1:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     4c7:	c5 7e 7f 94 24 40 01 	vmovdqu %ymm10,0x140(%rsp)
     4ce:	00 00 
     4d0:	c4 c1 2d 72 f2 10    	vpslld $0x10,%ymm10,%ymm10
     4d6:	c5 7e 7f 9c 24 20 01 	vmovdqu %ymm11,0x120(%rsp)
     4dd:	00 00 
     4df:	c4 41 2d fe de       	vpaddd %ymm14,%ymm10,%ymm11
     4e4:	c5 35 db d7          	vpand  %ymm7,%ymm9,%ymm10
     4e8:	c5 2d fa d4          	vpsubd %ymm4,%ymm10,%ymm10
     4ec:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
     4f0:	c5 7e 7f 9c 24 60 01 	vmovdqu %ymm11,0x160(%rsp)
     4f7:	00 00 
     4f9:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     4fe:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
     503:	c5 0d fe 64 24 40    	vpaddd 0x40(%rsp),%ymm14,%ymm12
     509:	c4 e2 5d 40 64 24 20 	vpmulld 0x20(%rsp),%ymm4,%ymm4
     510:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     515:	c5 2d fe d4          	vpaddd %ymm4,%ymm10,%ymm10
     519:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
     51e:	c5 2d fe d1          	vpaddd %ymm1,%ymm10,%ymm10
     522:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
     528:	c4 c1 5d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm4
     52e:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     534:	c5 75 db f7          	vpand  %ymm7,%ymm1,%ymm14
     538:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
     53f:	00 00 
     541:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     547:	c5 b5 db e7          	vpand  %ymm7,%ymm9,%ymm4
     54b:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
     552:	00 00 
     554:	0f 85 1e 03 00 00    	jne    878 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x878>
     55a:	48 8b 58 28          	mov    0x28(%rax),%rbx
     55e:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
     565:	00 00 
     567:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     56b:	48 8b 78 18          	mov    0x18(%rax),%rdi
     56f:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
     573:	c4 e2 4d 90 0c a3    	vpgatherdd %ymm6,(%rbx,%ymm4,4),%ymm1
     579:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     580:	00 00 
     582:	48 8b 58 20          	mov    0x20(%rax),%rbx
     586:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     58a:	c4 62 4d 90 14 a3    	vpgatherdd %ymm6,(%rbx,%ymm4,4),%ymm10
     590:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
     597:	00 00 
     599:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     59d:	c4 62 4d 90 04 a7    	vpgatherdd %ymm6,(%rdi,%ymm4,4),%ymm8
     5a3:	0f 85 8f fb ff ff    	jne    138 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138>
     5a9:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 611 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x611>
     5b0:	00 
     5b1:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 619 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x619>
     5b8:	00 
     5b9:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     5be:	48 83 c0 60          	add    $0x60,%rax
     5c2:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 62a <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x62a>
     5c9:	00 
     5ca:	c5 7e 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm11
     5d1:	00 00 
     5d3:	c4 c2 3d 3d da       	vpmaxsd %ymm10,%ymm8,%ymm3
     5d8:	c4 c1 2d 66 d0       	vpcmpgtd %ymm8,%ymm10,%ymm2
     5dd:	c4 42 3d 39 c2       	vpminsd %ymm10,%ymm8,%ymm8
     5e2:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
     5e6:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
     5ea:	c4 e2 65 3d f1       	vpmaxsd %ymm1,%ymm3,%ymm6
     5ef:	c4 62 3d 39 c9       	vpminsd %ymm1,%ymm8,%ymm9
     5f4:	c4 e2 65 39 d9       	vpminsd %ymm1,%ymm3,%ymm3
     5f9:	c5 bd 66 c9          	vpcmpgtd %ymm1,%ymm8,%ymm1
     5fd:	c4 c3 55 4c e5 20    	vpblendvb %ymm2,%ymm13,%ymm5,%ymm4
     603:	c4 e3 15 4c d5 20    	vpblendvb %ymm2,%ymm5,%ymm13,%ymm2
     609:	c4 e2 3d 3d db       	vpmaxsd %ymm3,%ymm8,%ymm3
     60e:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm4,%ymm4        # 637 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x637>
     615:	00 00 00 
     618:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
     61d:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
     622:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm2,%ymm2        # 64b <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x64b>
     629:	00 00 10 
     62c:	c4 e2 1d 90 04 a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm0
     632:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     637:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     63c:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
     641:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
     645:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     649:	c4 e2 3d 90 0c 92    	vpgatherdd %ymm8,(%rdx,%ymm2,4),%ymm1
     64f:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
     656:	00 00 
     658:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     65d:	c5 f5 db cf          	vpand  %ymm7,%ymm1,%ymm1
     661:	c5 0d fa f1          	vpsubd %ymm1,%ymm14,%ymm14
     665:	c5 f5 fa c8          	vpsubd %ymm0,%ymm1,%ymm1
     669:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     66e:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
     675:	00 00 
     677:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     67b:	c4 42 0d 40 f1       	vpmulld %ymm9,%ymm14,%ymm14
     680:	c4 e2 65 90 24 93    	vpgatherdd %ymm3,(%rbx,%ymm2,4),%ymm4
     686:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
     68a:	c5 fe 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm2
     691:	00 00 
     693:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     698:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     69c:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
     6a3:	00 00 
     6a5:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 70d <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70d>
     6ac:	00 
     6ad:	c5 0d fe f1          	vpaddd %ymm1,%ymm14,%ymm14
     6b1:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
     6b8:	00 00 
     6ba:	c5 0d fe f0          	vpaddd %ymm0,%ymm14,%ymm14
     6be:	c4 e2 65 90 04 93    	vpgatherdd %ymm3,(%rbx,%ymm2,4),%ymm0
     6c4:	48 8b 58 d0          	mov    -0x30(%rax),%rbx
     6c8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     6cc:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 734 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x734>
     6d3:	00 
     6d4:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
     6da:	c4 e2 65 90 14 b3    	vpgatherdd %ymm3,(%rbx,%ymm6,4),%ymm2
     6e0:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     6e4:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 74c <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x74c>
     6eb:	00 
     6ec:	c5 7d 66 c2          	vpcmpgtd %ymm2,%ymm0,%ymm8
     6f0:	c4 e2 6d 3d d8       	vpmaxsd %ymm0,%ymm2,%ymm3
     6f5:	c4 e2 6d 39 d0       	vpminsd %ymm0,%ymm2,%ymm2
     6fa:	c5 dd 66 c3          	vpcmpgtd %ymm3,%ymm4,%ymm0
     6fe:	c4 62 65 3d cc       	vpmaxsd %ymm4,%ymm3,%ymm9
     703:	c4 e2 65 39 dc       	vpminsd %ymm4,%ymm3,%ymm3
     708:	c4 62 6d 39 d4       	vpminsd %ymm4,%ymm2,%ymm10
     70d:	c4 e2 6d 3d db       	vpmaxsd %ymm3,%ymm2,%ymm3
     712:	c5 ed 66 d4          	vpcmpgtd %ymm4,%ymm2,%ymm2
     716:	c4 c3 55 4c f5 80    	vpblendvb %ymm8,%ymm13,%ymm5,%ymm6
     71c:	c4 e3 15 4c e5 80    	vpblendvb %ymm8,%ymm5,%ymm13,%ymm4
     722:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     726:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm0,0x1f(%rip),%ymm6,%ymm6        # 74f <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x74f>
     72d:	00 00 00 
     730:	c4 c1 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm6
     735:	c4 e3 5d 4c 15 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm4,%ymm2        # 75e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x75e>
     73c:	00 00 20 
     73f:	c4 e2 1d 90 04 b2    	vpgatherdd %ymm12,(%rdx,%ymm6,4),%ymm0
     745:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     74a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     74f:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
     753:	c4 e2 55 90 24 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm4
     759:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
     760:	00 00 
     762:	c5 fd db d7          	vpand  %ymm7,%ymm0,%ymm2
     766:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     76b:	c5 dd db e7          	vpand  %ymm7,%ymm4,%ymm4
     76f:	c5 d5 fa c4          	vpsubd %ymm4,%ymm5,%ymm0
     773:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     777:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     77c:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
     781:	c5 fd fe dc          	vpaddd %ymm4,%ymm0,%ymm3
     785:	c5 ed fa 84 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm0
     78c:	00 00 
     78e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     793:	c5 fd fe 84 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm0
     79a:	00 00 
     79c:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     7a0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     7a5:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     7a9:	49 39 c2             	cmp    %rax,%r10
     7ac:	0f 85 6d fb ff ff    	jne    31f <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31f>
     7b2:	c5 fe 6f 8c 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm1
     7b9:	00 00 
     7bb:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     7c0:	c4 c1 0d 72 f6 08    	vpslld $0x8,%ymm14,%ymm14
     7c6:	49 83 c0 18          	add    $0x18,%r8
     7ca:	c5 8d eb c0          	vpor   %ymm0,%ymm14,%ymm0
     7ce:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     7d2:	c4 e2 7d 00 84 24 20 	vpshufb 0x220(%rsp),%ymm0,%ymm0
     7d9:	02 00 00 
     7dc:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     7e0:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     7e6:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     7eb:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     7f0:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     7f4:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     7fa:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     800:	4d 39 c1             	cmp    %r8,%r9
     803:	0f 85 d7 f8 ff ff    	jne    e0 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
     809:	c5 f8 77             	vzeroupper
     80c:	c5 f8 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm6
     813:	00 00 
     815:	c5 f8 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm7
     81c:	00 00 
     81e:	c5 78 28 84 24 60 02 	vmovaps 0x260(%rsp),%xmm8
     825:	00 00 
     827:	c5 78 28 8c 24 70 02 	vmovaps 0x270(%rsp),%xmm9
     82e:	00 00 
     830:	c5 78 28 94 24 80 02 	vmovaps 0x280(%rsp),%xmm10
     837:	00 00 
     839:	c5 78 28 9c 24 90 02 	vmovaps 0x290(%rsp),%xmm11
     840:	00 00 
     842:	c5 78 28 a4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm12
     849:	00 00 
     84b:	c5 78 28 ac 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm13
     852:	00 00 
     854:	c5 78 28 b4 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm14
     85b:	00 00 
     85d:	c5 78 28 bc 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm15
     864:	00 00 
     866:	48 81 c4 e0 02 00 00 	add    $0x2e0,%rsp
     86d:	5b                   	pop    %rbx
     86e:	5e                   	pop    %rsi
     86f:	5f                   	pop    %rdi
     870:	c3                   	ret
     871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     878:	c5 fe 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm5
     87f:	00 00 
     881:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
     888:	00 00 
     88a:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     890:	c5 fd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm0
     895:	c5 f5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm1
     89a:	c5 f5 db cf          	vpand  %ymm7,%ymm1,%ymm1
     89e:	c5 ed 72 d3 10       	vpsrld $0x10,%ymm3,%ymm2
     8a3:	c5 fd db c7          	vpand  %ymm7,%ymm0,%ymm0
     8a7:	c5 0d fa f1          	vpsubd %ymm1,%ymm14,%ymm14
     8ab:	c5 f5 fa c8          	vpsubd %ymm0,%ymm1,%ymm1
     8af:	c5 ed db d7          	vpand  %ymm7,%ymm2,%ymm2
     8b3:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
     8b8:	c4 42 0d 40 f0       	vpmulld %ymm8,%ymm14,%ymm14
     8bd:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
     8c4:	00 00 
     8c6:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     8cb:	c5 0d fe f1          	vpaddd %ymm1,%ymm14,%ymm14
     8cf:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
     8d6:	00 00 
     8d8:	c5 0d fe f0          	vpaddd %ymm0,%ymm14,%ymm14
     8dc:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
     8e1:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
     8e8:	00 00 
     8ea:	c5 fd db df          	vpand  %ymm7,%ymm0,%ymm3
     8ee:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
     8f4:	c5 d5 fa c2          	vpsubd %ymm2,%ymm5,%ymm0
     8f8:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     8fc:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     900:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     905:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
     90a:	c5 e5 fa 9c 24 40 01 	vpsubd 0x140(%rsp),%ymm3,%ymm3
     911:	00 00 
     913:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
     918:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     91c:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
     921:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     925:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     92a:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     92e:	e9 df f9 ff ff       	jmp    312 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x312>
     933:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     938:	c5 7d 6f f2          	vmovdqa %ymm2,%ymm14
     93c:	e9 7a fe ff ff       	jmp    7bb <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7bb>
     941:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     945:	0f 85 26 f7 ff ff    	jne    71 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     94b:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     952:	0f 84 19 f7 ff ff    	je     71 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     958:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     95f:	0f 84 0c f7 ff ff    	je     71 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     965:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     96c:	0f 84 ff f6 ff ff    	je     71 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     972:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     976:	0f 85 64 0b 00 00    	jne    14e0 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14e0>
     97c:	4d 85 c9             	test   %r9,%r9
     97f:	0f 84 87 fe ff ff    	je     80c <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x80c>
     985:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 98d <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x98d>
     98c:	00 
     98d:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     991:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     996:	48 c1 e8 03          	shr    $0x3,%rax
     99a:	c4 c1 2d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm10
     9a0:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
     9a4:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
     9ab:	00 00 
     9ad:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 9f5 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9f5>
     9b4:	00 
     9b5:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
     9ba:	b8 00 80 00 00       	mov    $0x8000,%eax
     9bf:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
     9c6:	00 00 
     9c8:	c5 f9 6e f8          	vmovd  %eax,%xmm7
     9cc:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     9d1:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     9d6:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     9db:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     9e1:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     9e5:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     9ea:	48 8b 01             	mov    (%rcx),%rax
     9ed:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     9f1:	49 83 c0 18          	add    $0x18,%r8
     9f5:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     9fb:	8b 51 50             	mov    0x50(%rcx),%edx
     9fe:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     a04:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
     a09:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
     a10:	02 00 00 
     a13:	c5 79 6e c2          	vmovd  %edx,%xmm8
     a17:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     a1c:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
     a21:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
     a26:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     a2b:	c4 e2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm5
     a31:	48 8b 41 08          	mov    0x8(%rcx),%rax
     a35:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
     a3a:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a3e:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     a43:	c5 e5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm3
     a48:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     a4d:	c4 22 45 90 24 88    	vpgatherdd %ymm7,(%rax,%ymm9,4),%ymm12
     a53:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
     a58:	48 8b 41 10          	mov    0x10(%rcx),%rax
     a5c:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a60:	c4 c1 6d 72 d4 11    	vpsrld $0x11,%ymm12,%ymm2
     a66:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # ace <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xace>
     a6d:	00 
     a6e:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # ad6 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xad6>
     a75:	00 
     a76:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
     a7b:	c4 a2 45 90 24 98    	vpgatherdd %ymm7,(%rax,%ymm11,4),%ymm4
     a81:	48 8b 41 48          	mov    0x48(%rcx),%rax
     a85:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a89:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
     a8e:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # af6 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xaf6>
     a95:	00 
     a96:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a9a:	c5 f9 6e da          	vmovd  %edx,%xmm3
     a9e:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     aa2:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     aa7:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     aab:	c4 e2 45 90 34 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm6
     ab1:	c4 e2 15 90 3c 98    	vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm7
     ab7:	c4 42 55 3d ec       	vpmaxsd %ymm12,%ymm5,%ymm13
     abc:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
     ac2:	c5 9d 66 fd          	vpcmpgtd %ymm5,%ymm12,%ymm7
     ac6:	c4 41 5d 66 f5       	vpcmpgtd %ymm13,%ymm4,%ymm14
     acb:	c4 c2 55 39 ec       	vpminsd %ymm12,%ymm5,%ymm5
     ad0:	c4 63 3d 4c e1 70    	vpblendvb %ymm7,%ymm1,%ymm8,%ymm12
     ad6:	c4 c3 75 4c f8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm7
     adc:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm12,%ymm12        # b05 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb05>
     ae3:	00 00 e0 
     ae6:	c4 62 15 3d f4       	vpmaxsd %ymm4,%ymm13,%ymm14
     aeb:	c4 62 15 39 ec       	vpminsd %ymm4,%ymm13,%ymm13
     af0:	c5 7e 7f 74 24 40    	vmovdqu %ymm14,0x40(%rsp)
     af6:	c4 62 55 39 f4       	vpminsd %ymm4,%ymm5,%ymm14
     afb:	c5 d5 66 e4          	vpcmpgtd %ymm4,%ymm5,%ymm4
     aff:	c4 42 55 3d ed       	vpmaxsd %ymm13,%ymm5,%ymm13
     b04:	c5 7e 7f ac 24 80 00 	vmovdqu %ymm13,0x80(%rsp)
     b0b:	00 00 
     b0d:	c4 41 6d fe e4       	vpaddd %ymm12,%ymm2,%ymm12
     b12:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     b17:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     b1d:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm7,%ymm7        # b46 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb46>
     b24:	00 00 40 
     b27:	c4 22 15 90 34 a0    	vpgatherdd %ymm13,(%rax,%ymm12,4),%ymm14
     b2d:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     b32:	c5 e5 fa ef          	vpsubd %ymm7,%ymm3,%ymm5
     b36:	c4 e2 1d 90 24 a8    	vpgatherdd %ymm12,(%rax,%ymm5,4),%ymm4
     b3c:	c4 41 4d db e2       	vpand  %ymm10,%ymm6,%ymm12
     b41:	c5 ad db 7c 24 20    	vpand  0x20(%rsp),%ymm10,%ymm7
     b47:	48 8b 51 28          	mov    0x28(%rcx),%rdx
     b4b:	c4 c1 15 72 f4 10    	vpslld $0x10,%ymm12,%ymm13
     b51:	c4 c1 0d db ea       	vpand  %ymm10,%ymm14,%ymm5
     b56:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
     b5b:	c5 15 fe 2c 24       	vpaddd (%rsp),%ymm13,%ymm13
     b60:	c5 c5 fa fc          	vpsubd %ymm4,%ymm7,%ymm7
     b64:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     b68:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     b6d:	c4 e2 45 40 7c 24 60 	vpmulld 0x60(%rsp),%ymm7,%ymm7
     b74:	c4 e2 5d 40 a4 24 80 	vpmulld 0x80(%rsp),%ymm4,%ymm4
     b7b:	00 00 00 
     b7e:	c4 e2 55 40 6c 24 40 	vpmulld 0x40(%rsp),%ymm5,%ymm5
     b85:	c5 c5 fe e4          	vpaddd %ymm4,%ymm7,%ymm4
     b89:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
     b8e:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     b92:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     b97:	c5 d5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm5
     b9c:	c5 fe 7f 6c 24 40    	vmovdqu %ymm5,0x40(%rsp)
     ba2:	c4 22 15 90 24 9a    	vpgatherdd %ymm13,(%rdx,%ymm11,4),%ymm12
     ba8:	48 8b 51 20          	mov    0x20(%rcx),%rdx
     bac:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     bb1:	c4 a2 15 90 24 8a    	vpgatherdd %ymm13,(%rdx,%ymm9,4),%ymm4
     bb7:	48 8b 51 18          	mov    0x18(%rcx),%rdx
     bbb:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     bc0:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # c28 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc28>
     bc7:	00 
     bc8:	c4 e2 15 90 2c 82    	vpgatherdd %ymm13,(%rdx,%ymm0,4),%ymm5
     bce:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # c36 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc36>
     bd5:	00 
     bd6:	c4 62 55 3d ec       	vpmaxsd %ymm4,%ymm5,%ymm13
     bdb:	c5 dd 66 fd          	vpcmpgtd %ymm5,%ymm4,%ymm7
     bdf:	c4 e2 55 39 ec       	vpminsd %ymm4,%ymm5,%ymm5
     be4:	c5 9d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm4        # c4c <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc4c>
     beb:	00 
     bec:	c4 41 5d 66 f5       	vpcmpgtd %ymm13,%ymm4,%ymm14
     bf1:	c4 63 3d 4c e1 70    	vpblendvb %ymm7,%ymm1,%ymm8,%ymm12
     bf7:	c4 c3 75 4c f8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm7
     bfd:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm12,%ymm12        # c26 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc26>
     c04:	00 00 e0 
     c07:	c4 62 15 3d f4       	vpmaxsd %ymm4,%ymm13,%ymm14
     c0c:	c4 62 15 39 ec       	vpminsd %ymm4,%ymm13,%ymm13
     c11:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     c17:	c4 62 55 39 f4       	vpminsd %ymm4,%ymm5,%ymm14
     c1c:	c5 d5 66 e4          	vpcmpgtd %ymm4,%ymm5,%ymm4
     c20:	c4 42 55 3d ed       	vpmaxsd %ymm13,%ymm5,%ymm13
     c25:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
     c2c:	00 00 
     c2e:	c4 41 6d fe e4       	vpaddd %ymm12,%ymm2,%ymm12
     c33:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     c38:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
     c3f:	00 00 
     c41:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm7,%ymm7        # c6a <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc6a>
     c48:	00 00 40 
     c4b:	c4 22 15 90 34 a0    	vpgatherdd %ymm13,(%rax,%ymm12,4),%ymm14
     c51:	c5 e5 fa ef          	vpsubd %ymm7,%ymm3,%ymm5
     c55:	c5 9d 72 d6 08       	vpsrld $0x8,%ymm6,%ymm12
     c5a:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     c5e:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
     c64:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
     c6a:	c4 41 1d db e2       	vpand  %ymm10,%ymm12,%ymm12
     c6f:	c5 c5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm7
     c74:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     c7a:	c4 c1 15 72 f4 10    	vpslld $0x10,%ymm12,%ymm13
     c80:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
     c85:	c4 c1 45 db fa       	vpand  %ymm10,%ymm7,%ymm7
     c8a:	c5 15 fe 2c 24       	vpaddd (%rsp),%ymm13,%ymm13
     c8f:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     c94:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
     c99:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     c9d:	c5 c5 fa fd          	vpsubd %ymm5,%ymm7,%ymm7
     ca1:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     ca6:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     cad:	00 00 00 
     cb0:	c4 e2 5d 40 a4 24 80 	vpmulld 0x80(%rsp),%ymm4,%ymm4
     cb7:	00 00 00 
     cba:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     cbe:	c4 e2 55 40 6c 24 60 	vpmulld 0x60(%rsp),%ymm5,%ymm5
     cc5:	48 8b 51 40          	mov    0x40(%rcx),%rdx
     cc9:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
     cce:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     cd3:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     cd7:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
     cde:	c4 a2 15 90 2c 9a    	vpgatherdd %ymm13,(%rdx,%ymm11,4),%ymm5
     ce4:	48 8b 51 38          	mov    0x38(%rcx),%rdx
     ce8:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     ced:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     cf2:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # d5a <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd5a>
     cf9:	00 
     cfa:	c4 22 15 90 1c 8a    	vpgatherdd %ymm13,(%rdx,%ymm9,4),%ymm11
     d00:	48 8b 51 30          	mov    0x30(%rcx),%rdx
     d04:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
     d09:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # d71 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd71>
     d10:	00 
     d11:	c4 e2 15 90 24 82    	vpgatherdd %ymm13,(%rdx,%ymm0,4),%ymm4
     d17:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
     d1d:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # d85 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd85>
     d24:	00 
     d25:	c5 25 66 cc          	vpcmpgtd %ymm4,%ymm11,%ymm9
     d29:	c4 c2 5d 3d c3       	vpmaxsd %ymm11,%ymm4,%ymm0
     d2e:	c4 c2 5d 39 e3       	vpminsd %ymm11,%ymm4,%ymm4
     d33:	c5 55 66 d8          	vpcmpgtd %ymm0,%ymm5,%ymm11
     d37:	c4 62 7d 3d f5       	vpmaxsd %ymm5,%ymm0,%ymm14
     d3c:	c4 e2 7d 39 c5       	vpminsd %ymm5,%ymm0,%ymm0
     d41:	c4 62 5d 3d e8       	vpmaxsd %ymm0,%ymm4,%ymm13
     d46:	c4 63 3d 4c e1 90    	vpblendvb %ymm9,%ymm1,%ymm8,%ymm12
     d4c:	c4 c3 75 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm1,%ymm1
     d52:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm12,%ymm12        # d7b <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd7b>
     d59:	00 00 b0 
     d5c:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
     d61:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     d65:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
     d6a:	c4 41 7d 6f e7       	vmovdqa %ymm15,%ymm12
     d6f:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
     d75:	c4 e2 1d 90 04 90    	vpgatherdd %ymm12,(%rax,%ymm2,4),%ymm0
     d7b:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     d7f:	c5 79 6e e2          	vmovd  %edx,%xmm12
     d83:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     d88:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     d8d:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm1,%ymm1        # db6 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdb6>
     d94:	00 00 40 
     d97:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     d9d:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
     da1:	c4 e2 6d 90 1c 88    	vpgatherdd %ymm2,(%rax,%ymm1,4),%ymm3
     da7:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     dac:	48 8b 41 60          	mov    0x60(%rcx),%rax
     db0:	c5 fd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm0
     db5:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     dba:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     dbf:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
     dc4:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
     dc9:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     dce:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     dd3:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     dd7:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
     ddb:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
     de0:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     de5:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     de9:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
     dee:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
     df3:	c5 dd 72 f2 10       	vpslld $0x10,%ymm2,%ymm4
     df8:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     dfc:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
     e01:	c4 c1 5d fe e6       	vpaddd %ymm14,%ymm4,%ymm4
     e06:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
     e0b:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     e0f:	c4 e2 6d 90 1c a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm3
     e15:	48 8b 41 68          	mov    0x68(%rcx),%rax
     e19:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     e1d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     e21:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     e25:	c4 e2 55 90 14 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm2
     e2b:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     e2f:	48 8b 41 70          	mov    0x70(%rcx),%rax
     e33:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     e37:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     e3c:	c5 bd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm8
     e41:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     e46:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
     e4c:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     e51:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
     e58:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     e5c:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     e61:	c4 42 3d 40 c3       	vpmulld %ymm11,%ymm8,%ymm8
     e66:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # ece <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xece>
     e6d:	00 
     e6e:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
     e75:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     e7a:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # ee2 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xee2>
     e81:	00 
     e82:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
     e88:	c5 6d 66 eb          	vpcmpgtd %ymm3,%ymm2,%ymm13
     e8c:	c5 3d fe c0          	vpaddd %ymm0,%ymm8,%ymm8
     e90:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
     e94:	c4 c1 5d fe c8       	vpaddd %ymm8,%ymm4,%ymm1
     e99:	c4 a2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm8,4),%ymm5
     e9f:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     ea3:	c5 fe 7f 0c 24       	vmovdqu %ymm1,(%rsp)
     ea8:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     eac:	c4 e2 45 90 04 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm0
     eb2:	c4 e2 65 39 ca       	vpminsd %ymm2,%ymm3,%ymm1
     eb7:	c4 e2 65 3d fa       	vpmaxsd %ymm2,%ymm3,%ymm7
     ebc:	c5 cd db 15 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm2        # f24 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf24>
     ec3:	00 
     ec4:	c4 c3 1d 4c db d0    	vpblendvb %ymm13,%ymm11,%ymm12,%ymm3
     eca:	c5 ed 66 f7          	vpcmpgtd %ymm7,%ymm2,%ymm6
     ece:	c4 62 75 39 ca       	vpminsd %ymm2,%ymm1,%ymm9
     ed3:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # efc <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xefc>
     eda:	00 00 60 
     edd:	c4 e2 45 3d f2       	vpmaxsd %ymm2,%ymm7,%ymm6
     ee2:	c4 e2 45 39 fa       	vpminsd %ymm2,%ymm7,%ymm7
     ee7:	c5 f5 66 d2          	vpcmpgtd %ymm2,%ymm1,%ymm2
     eeb:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
     eef:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
     ef4:	c4 62 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm8
     efa:	c4 c3 25 4c cc d0    	vpblendvb %ymm13,%ymm12,%ymm11,%ymm1
     f00:	c5 fe 6f 1c 24       	vmovdqu (%rsp),%ymm3
     f05:	c4 41 55 db e2       	vpand  %ymm10,%ymm5,%ymm12
     f0a:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
     f10:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
     f15:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # f3e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf3e>
     f1c:	00 00 20 
     f1f:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     f23:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
     f28:	c5 e5 fa e1          	vpsubd %ymm1,%ymm3,%ymm4
     f2c:	c4 c1 3d db ca       	vpand  %ymm10,%ymm8,%ymm1
     f31:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
     f36:	c4 e2 6d 90 1c a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm3
     f3c:	c4 c1 7d db e2       	vpand  %ymm10,%ymm0,%ymm4
     f41:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
     f48:	c5 7e 7f 34 24       	vmovdqu %ymm14,(%rsp)
     f4d:	c4 c1 65 db d2       	vpand  %ymm10,%ymm3,%ymm2
     f52:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f57:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     f5b:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     f5f:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
     f64:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     f69:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     f6e:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     f73:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     f78:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
     f7d:	c4 41 1d db e2       	vpand  %ymm10,%ymm12,%ymm12
     f82:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     f87:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
     f8c:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
     f90:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
     f95:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     f9a:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
     fa0:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
     fa5:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     fa9:	c4 c1 75 72 d0 08    	vpsrld $0x8,%ymm8,%ymm1
     faf:	c5 15 fa ea          	vpsubd %ymm2,%ymm13,%ymm13
     fb3:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
     fb8:	c4 42 15 40 e9       	vpmulld %ymm9,%ymm13,%ymm13
     fbd:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
     fc2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     fc7:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     fcc:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     fd0:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
     fd5:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     fda:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
     fdf:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     fe4:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     fe8:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
     fed:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     ff2:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     ff7:	c5 95 fe d2          	vpaddd %ymm2,%ymm13,%ymm2
     ffb:	c5 79 6e ea          	vmovd  %edx,%xmm13
     fff:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1004:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    1009:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    100e:	c5 79 6e da          	vmovd  %edx,%xmm11
    1012:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1016:	c4 c1 75 72 d0 10    	vpsrld $0x10,%ymm8,%ymm1
    101c:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    1021:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1026:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    102b:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    1030:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    1034:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1038:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    103d:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1042:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1047:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    104b:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1050:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1054:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1058:	c4 e2 45 90 0c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm1
    105e:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    1065:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1069:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    106e:	c4 e2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm3
    1074:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    107b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    107f:	c5 dd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm4
    1084:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
    108a:	c5 fd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm0
    108f:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    1096:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    109a:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    109f:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    10a4:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    10a9:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    10ad:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    10b1:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    10b7:	c5 25 fe dc          	vpaddd %ymm4,%ymm11,%ymm11
    10bb:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    10bf:	c4 a2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm11,4),%ymm0
    10c5:	c5 e5 db 15 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm2        # 112d <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x112d>
    10cc:	00 
    10cd:	c5 f5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm3        # 1135 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1135>
    10d4:	00 
    10d5:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    10dc:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    10e2:	c4 e2 65 39 ca       	vpminsd %ymm2,%ymm3,%ymm1
    10e7:	c4 e2 65 3d fa       	vpmaxsd %ymm2,%ymm3,%ymm7
    10ec:	c5 6d 66 f3          	vpcmpgtd %ymm3,%ymm2,%ymm14
    10f0:	c5 cd db 15 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm2        # 1158 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1158>
    10f7:	00 
    10f8:	c5 ed 66 f7          	vpcmpgtd %ymm7,%ymm2,%ymm6
    10fc:	c4 c3 15 4c dc e0    	vpblendvb %ymm14,%ymm12,%ymm13,%ymm3
    1102:	c4 62 75 39 ca       	vpminsd %ymm2,%ymm1,%ymm9
    1107:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # 1130 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1130>
    110e:	00 00 60 
    1111:	c4 e2 45 3d f2       	vpmaxsd %ymm2,%ymm7,%ymm6
    1116:	c4 e2 45 39 fa       	vpminsd %ymm2,%ymm7,%ymm7
    111b:	c5 f5 66 d2          	vpcmpgtd %ymm2,%ymm1,%ymm2
    111f:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
    1124:	c4 c3 1d 4c cd e0    	vpblendvb %ymm14,%ymm13,%ymm12,%ymm1
    112a:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    112f:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    1133:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1137:	c4 41 55 db e2       	vpand  %ymm10,%ymm5,%ymm12
    113c:	c4 62 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm8
    1142:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    1147:	c4 c1 7d db e2       	vpand  %ymm10,%ymm0,%ymm4
    114c:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 1175 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1175>
    1153:	00 00 20 
    1156:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    115a:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
    115f:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    1163:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1168:	c4 c1 3d db ca       	vpand  %ymm10,%ymm8,%ymm1
    116d:	c4 a2 6d 90 1c 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm3
    1173:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
    1179:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    117e:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    1185:	c4 c1 65 db d2       	vpand  %ymm10,%ymm3,%ymm2
    118a:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    118f:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1193:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    1197:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    119c:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    11a1:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    11a6:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    11ab:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    11b0:	c4 41 1d db e2       	vpand  %ymm10,%ymm12,%ymm12
    11b5:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    11ba:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    11bf:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    11c3:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
    11c8:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    11cd:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
    11d3:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
    11d8:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    11dc:	c4 c1 75 72 d0 08    	vpsrld $0x8,%ymm8,%ymm1
    11e2:	c5 15 fa ea          	vpsubd %ymm2,%ymm13,%ymm13
    11e6:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    11eb:	c4 42 15 40 e9       	vpmulld %ymm9,%ymm13,%ymm13
    11f0:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    11f5:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    11fa:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    11ff:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    1203:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1208:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    120d:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    1212:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1217:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    121b:	c5 79 6e e2          	vmovd  %edx,%xmm12
    121f:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1224:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    1229:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    122e:	c5 95 fe d2          	vpaddd %ymm2,%ymm13,%ymm2
    1232:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    1237:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    123c:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1240:	c4 c1 75 72 d0 10    	vpsrld $0x10,%ymm8,%ymm1
    1246:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    124b:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1250:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1255:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    125a:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    125e:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1262:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1267:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    126c:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1271:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1275:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    127a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    127e:	c5 79 6e c2          	vmovd  %edx,%xmm8
    1282:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1286:	c4 e2 45 90 0c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm1
    128c:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    1293:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1297:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    129c:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    12a1:	c4 e2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm3
    12a7:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    12ae:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    12b2:	c5 dd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm4
    12b7:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
    12bd:	c5 fd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm0
    12c2:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    12c9:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    12cd:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    12d2:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    12d7:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    12dc:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    12e0:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    12e4:	c5 bd fe d4          	vpaddd %ymm4,%ymm8,%ymm2
    12e8:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    12ee:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    12f2:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    12f8:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    12fd:	c4 e2 45 90 04 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm0
    1303:	c5 e5 db 15 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm2        # 136b <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x136b>
    130a:	00 
    130b:	c5 f5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm3        # 1373 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1373>
    1312:	00 
    1313:	c4 e2 65 39 ca       	vpminsd %ymm2,%ymm3,%ymm1
    1318:	c4 e2 65 3d fa       	vpmaxsd %ymm2,%ymm3,%ymm7
    131d:	c5 6d 66 eb          	vpcmpgtd %ymm3,%ymm2,%ymm13
    1321:	c5 cd db 1d 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm3        # 1389 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1389>
    1328:	00 
    1329:	c5 e5 66 f7          	vpcmpgtd %ymm7,%ymm3,%ymm6
    132d:	c4 c3 1d 4c d3 d0    	vpblendvb %ymm13,%ymm11,%ymm12,%ymm2
    1333:	c4 62 75 39 cb       	vpminsd %ymm3,%ymm1,%ymm9
    1338:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm2,%ymm2        # 1361 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1361>
    133f:	00 00 60 
    1342:	c4 e2 45 3d f3       	vpmaxsd %ymm3,%ymm7,%ymm6
    1347:	c4 e2 45 39 fb       	vpminsd %ymm3,%ymm7,%ymm7
    134c:	c5 f5 66 db          	vpcmpgtd %ymm3,%ymm1,%ymm3
    1350:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
    1355:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    1359:	c4 c3 25 4c cc d0    	vpblendvb %ymm13,%ymm12,%ymm11,%ymm1
    135f:	c4 e2 3d 90 14 a0    	vpgatherdd %ymm8,(%rax,%ymm4,4),%ymm2
    1365:	c4 41 55 db e2       	vpand  %ymm10,%ymm5,%ymm12
    136a:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
    1370:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    1375:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm1,%ymm1        # 139e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x139e>
    137c:	00 00 30 
    137f:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1385:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    138a:	c4 41 2d db ed       	vpand  %ymm13,%ymm10,%ymm13
    138f:	c5 65 fa c1          	vpsubd %ymm1,%ymm3,%ymm8
    1393:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1397:	c4 c1 6d db ca       	vpand  %ymm10,%ymm2,%ymm1
    139c:	c4 a2 65 90 24 80    	vpgatherdd %ymm3,(%rax,%ymm8,4),%ymm4
    13a2:	c4 41 7d db c2       	vpand  %ymm10,%ymm0,%ymm8
    13a7:	c4 c1 5d db da       	vpand  %ymm10,%ymm4,%ymm3
    13ac:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    13b1:	c5 3d fa c3          	vpsubd %ymm3,%ymm8,%ymm8
    13b5:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    13b9:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    13be:	c4 42 3d 40 c1       	vpmulld %ymm9,%ymm8,%ymm8
    13c3:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    13c8:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    13cd:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    13d2:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    13d7:	c4 41 1d db e2       	vpand  %ymm10,%ymm12,%ymm12
    13dc:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    13e1:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    13e6:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    13ea:	c5 bd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm8
    13ef:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    13f4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    13f9:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
    13fe:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    1402:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    1407:	c4 41 15 fa e8       	vpsubd %ymm8,%ymm13,%ymm13
    140c:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    1411:	c4 42 15 40 e9       	vpmulld %ymm9,%ymm13,%ymm13
    1416:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
    141b:	c5 3d fa c1          	vpsubd %ymm1,%ymm8,%ymm8
    141f:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1424:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1429:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    142e:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1433:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
    1438:	c4 c1 25 72 f4 10    	vpslld $0x10,%ymm12,%ymm11
    143e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1443:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    1447:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    144b:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    144f:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1454:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1459:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    145e:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    1463:	c4 41 15 fe c0       	vpaddd %ymm8,%ymm13,%ymm8
    1468:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    146d:	c5 bd fe c9          	vpaddd %ymm1,%ymm8,%ymm1
    1471:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1476:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    147b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1480:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    1485:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1489:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    148e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1492:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1497:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    149c:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    14a0:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    14a4:	c4 e2 7d 00 84 24 20 	vpshufb 0x220(%rsp),%ymm0,%ymm0
    14ab:	02 00 00 
    14ae:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    14b2:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    14b8:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    14bd:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    14c2:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    14c6:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    14cc:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    14d2:	4d 39 c2             	cmp    %r8,%r10
    14d5:	0f 85 fb f4 ff ff    	jne    9d6 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9d6>
    14db:	e9 29 f3 ff ff       	jmp    809 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x809>
    14e0:	4d 85 c9             	test   %r9,%r9
    14e3:	0f 84 23 f3 ff ff    	je     80c <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x80c>
    14e9:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 14f1 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14f1>
    14f0:	00 
    14f1:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    14f5:	48 c1 e8 03          	shr    $0x3,%rax
    14f9:	c5 fe 7f bc 24 00 02 	vmovdqu %ymm7,0x200(%rsp)
    1500:	00 00 
    1502:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 154a <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x154a>
    1509:	00 
    150a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    150e:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    1513:	b8 00 80 00 00       	mov    $0x8000,%eax
    1518:	c5 fe 7f bc 24 20 02 	vmovdqu %ymm7,0x220(%rsp)
    151f:	00 00 
    1521:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    1525:	c5 85 72 d7 18       	vpsrld $0x18,%ymm7,%ymm15
    152a:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    152e:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1533:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    1538:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    153d:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    1543:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    1547:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
    154b:	48 8b 01             	mov    (%rcx),%rax
    154e:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    1552:	49 83 c0 18          	add    $0x18,%r8
    1556:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    155c:	8b 51 50             	mov    0x50(%rcx),%edx
    155f:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1565:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    156a:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    1571:	02 00 00 
    1574:	c5 79 6e e2          	vmovd  %edx,%xmm12
    1578:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    157d:	c4 c1 7d db cf       	vpand  %ymm15,%ymm0,%ymm1
    1582:	c5 ad 72 d0 08       	vpsrld $0x8,%ymm0,%ymm10
    1587:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    158c:	c4 62 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm8
    1592:	48 8b 41 08          	mov    0x8(%rcx),%rax
    1596:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    159b:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    159f:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    15a4:	c4 c1 7d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm0
    15aa:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    15af:	c4 22 55 90 0c 90    	vpgatherdd %ymm5,(%rax,%ymm10,4),%ymm9
    15b5:	48 8b 41 10          	mov    0x10(%rcx),%rax
    15b9:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    15be:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1626 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1626>
    15c5:	00 
    15c6:	c4 e2 65 90 2c b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm5
    15cc:	c4 c1 65 72 d1 11    	vpsrld $0x11,%ymm9,%ymm3
    15d2:	48 8b 41 48          	mov    0x48(%rcx),%rax
    15d6:	c5 35 db 0d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm9        # 163e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x163e>
    15dd:	00 
    15de:	c4 e2 65 40 da       	vpmulld %ymm2,%ymm3,%ymm3
    15e3:	c5 dd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm4
    15e8:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1650 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1650>
    15ef:	00 
    15f0:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    15f4:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    15f8:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    15fc:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    1600:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    1604:	c4 e2 5d 90 3c 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm7
    160a:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    160e:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    1612:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    1617:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    161c:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    1620:	c4 62 7d 90 1c a0    	vpgatherdd %ymm0,(%rax,%ymm4,4),%ymm11
    1626:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    162c:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    1631:	c4 e2 15 90 04 8a    	vpgatherdd %ymm13,(%rdx,%ymm1,4),%ymm0
    1637:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    163b:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    1641:	c4 22 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm10,4),%ymm13
    1647:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    164b:	c4 42 3d 39 d1       	vpminsd %ymm9,%ymm8,%ymm10
    1650:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
    1656:	c4 42 3d 3d e9       	vpmaxsd %ymm9,%ymm8,%ymm13
    165b:	c4 e2 2d 39 c5       	vpminsd %ymm5,%ymm10,%ymm0
    1660:	c4 e2 25 90 0c b2    	vpgatherdd %ymm11,(%rdx,%ymm6,4),%ymm1
    1666:	c4 c1 35 66 f0       	vpcmpgtd %ymm8,%ymm9,%ymm6
    166b:	c5 fe 7f 84 24 a0 00 	vmovdqu %ymm0,0xa0(%rsp)
    1672:	00 00 
    1674:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    1678:	c4 41 55 66 f5       	vpcmpgtd %ymm13,%ymm5,%ymm14
    167d:	c4 63 1d 4c da 60    	vpblendvb %ymm6,%ymm2,%ymm12,%ymm11
    1683:	c4 c3 6d 4c f4 60    	vpblendvb %ymm6,%ymm12,%ymm2,%ymm6
    1689:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm11,%ymm11        # 16b2 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16b2>
    1690:	00 00 e0 
    1693:	c4 62 15 3d f5       	vpmaxsd %ymm5,%ymm13,%ymm14
    1698:	c4 62 15 39 ed       	vpminsd %ymm5,%ymm13,%ymm13
    169d:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    16a4:	00 00 
    16a6:	c4 42 2d 3d f5       	vpmaxsd %ymm13,%ymm10,%ymm14
    16ab:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    16af:	c4 41 65 fe db       	vpaddd %ymm11,%ymm3,%ymm11
    16b4:	c5 7e 7f b4 24 c0 00 	vmovdqu %ymm14,0xc0(%rsp)
    16bb:	00 00 
    16bd:	c4 41 45 db f7       	vpand  %ymm15,%ymm7,%ymm14
    16c2:	c4 22 7d 90 2c 98    	vpgatherdd %ymm0,(%rax,%ymm11,4),%ymm13
    16c8:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    16cc:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm6,%ymm6        # 16f5 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16f5>
    16d3:	00 00 a0 
    16d6:	c4 41 15 db d7       	vpand  %ymm15,%ymm13,%ymm10
    16db:	c5 dd fa f6          	vpsubd %ymm6,%ymm4,%ymm6
    16df:	c4 c1 15 72 f6 10    	vpslld $0x10,%ymm14,%ymm13
    16e5:	c4 62 7d 90 1c b0    	vpgatherdd %ymm0,(%rax,%ymm6,4),%ymm11
    16eb:	c5 85 db 74 24 20    	vpand  0x20(%rsp),%ymm15,%ymm6
    16f1:	c5 15 fe 2c 24       	vpaddd (%rsp),%ymm13,%ymm13
    16f6:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    16fb:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
    1701:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    1706:	c4 41 25 fa da       	vpsubd %ymm10,%ymm11,%ymm11
    170b:	c4 41 2d fa d6       	vpsubd %ymm14,%ymm10,%ymm10
    1710:	c4 e2 4d 40 b4 24 a0 	vpmulld 0xa0(%rsp),%ymm6,%ymm6
    1717:	00 00 00 
    171a:	c4 62 25 40 9c 24 c0 	vpmulld 0xc0(%rsp),%ymm11,%ymm11
    1721:	00 00 00 
    1724:	c4 c1 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm6
    1729:	c4 62 2d 40 94 24 80 	vpmulld 0x80(%rsp),%ymm10,%ymm10
    1730:	00 00 00 
    1733:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    1738:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    173e:	c5 a5 72 e0 10       	vpsrad $0x10,%ymm0,%ymm11
    1743:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    1748:	c5 ad 72 e1 10       	vpsrad $0x10,%ymm1,%ymm10
    174d:	c4 41 25 fe d8       	vpaddd %ymm8,%ymm11,%ymm11
    1752:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1757:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    175c:	c5 2d fe d5          	vpaddd %ymm5,%ymm10,%ymm10
    1760:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1765:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
    176c:	00 00 
    176e:	c4 c1 4d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm6
    1774:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
    1778:	c4 c1 75 72 f5 10    	vpslld $0x10,%ymm13,%ymm1
    177e:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    1783:	c5 95 72 f0 10       	vpslld $0x10,%ymm0,%ymm13
    1788:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    178d:	c4 c1 15 72 e5 10    	vpsrad $0x10,%ymm13,%ymm13
    1793:	c4 41 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm9
    1798:	c4 c1 15 fe c8       	vpaddd %ymm8,%ymm13,%ymm1
    179d:	c5 35 66 f1          	vpcmpgtd %ymm1,%ymm9,%ymm14
    17a1:	c4 42 75 3d e9       	vpmaxsd %ymm9,%ymm1,%ymm13
    17a6:	c4 c2 75 39 c9       	vpminsd %ymm9,%ymm1,%ymm1
    17ab:	c4 41 55 66 cd       	vpcmpgtd %ymm13,%ymm5,%ymm9
    17b0:	c4 e2 15 3d c5       	vpmaxsd %ymm5,%ymm13,%ymm0
    17b5:	c4 62 15 39 ed       	vpminsd %ymm5,%ymm13,%ymm13
    17ba:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    17c0:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    17c4:	c4 63 1d 4c c2 e0    	vpblendvb %ymm14,%ymm2,%ymm12,%ymm8
    17ca:	c4 43 6d 4c f4 e0    	vpblendvb %ymm14,%ymm12,%ymm2,%ymm14
    17d0:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm8,%ymm8        # 17f9 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x17f9>
    17d7:	00 00 90 
    17da:	c4 62 75 39 cd       	vpminsd %ymm5,%ymm1,%ymm9
    17df:	c5 7e 7f 4c 24 60    	vmovdqu %ymm9,0x60(%rsp)
    17e5:	c4 42 75 3d cd       	vpmaxsd %ymm13,%ymm1,%ymm9
    17ea:	c5 f5 66 cd          	vpcmpgtd %ymm5,%ymm1,%ymm1
    17ee:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    17f4:	c5 7e 7f 8c 24 a0 00 	vmovdqu %ymm9,0xa0(%rsp)
    17fb:	00 00 
    17fd:	c4 41 65 fe c8       	vpaddd %ymm8,%ymm3,%ymm9
    1802:	c4 22 7d 90 04 88    	vpgatherdd %ymm0,(%rax,%ymm9,4),%ymm8
    1808:	c5 b5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm9
    180d:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    1811:	c4 63 0d 4c 35 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm14,%ymm14        # 183a <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x183a>
    1818:	00 00 10 
    181b:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    1820:	c4 c1 5d fa ee       	vpsubd %ymm14,%ymm4,%ymm5
    1825:	c4 e2 7d 90 0c a8    	vpgatherdd %ymm0,(%rax,%ymm5,4),%ymm1
    182b:	c4 c1 55 72 d0 08    	vpsrld $0x8,%ymm8,%ymm5
    1831:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
    1836:	c4 c1 3d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm8
    183c:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1841:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1846:	c4 c1 15 72 f1 10    	vpslld $0x10,%ymm9,%ymm13
    184c:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1851:	c5 3d fa c1          	vpsubd %ymm1,%ymm8,%ymm8
    1855:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1859:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    185e:	c4 62 3d 40 44 24 60 	vpmulld 0x60(%rsp),%ymm8,%ymm8
    1865:	c4 e2 75 40 8c 24 a0 	vpmulld 0xa0(%rsp),%ymm1,%ymm1
    186c:	00 00 00 
    186f:	c5 bd fe c9          	vpaddd %ymm1,%ymm8,%ymm1
    1873:	c4 e2 55 40 6c 24 40 	vpmulld 0x40(%rsp),%ymm5,%ymm5
    187a:	c5 15 fe 2c 24       	vpaddd (%rsp),%ymm13,%ymm13
    187f:	c4 41 4d 66 cb       	vpcmpgtd %ymm11,%ymm6,%ymm9
    1884:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    188b:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    1891:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    1896:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    189a:	c4 63 1d 4c ea 90    	vpblendvb %ymm9,%ymm2,%ymm12,%ymm13
    18a0:	c4 c3 6d 4c d4 90    	vpblendvb %ymm9,%ymm12,%ymm2,%ymm2
    18a6:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
    18ab:	c4 e2 25 3d ce       	vpmaxsd %ymm6,%ymm11,%ymm1
    18b0:	c4 e2 25 39 f6       	vpminsd %ymm6,%ymm11,%ymm6
    18b5:	c5 ad 66 e9          	vpcmpgtd %ymm1,%ymm10,%ymm5
    18b9:	c4 42 75 3d f2       	vpmaxsd %ymm10,%ymm1,%ymm14
    18be:	c4 c2 75 39 ca       	vpminsd %ymm10,%ymm1,%ymm1
    18c3:	c4 42 4d 39 da       	vpminsd %ymm10,%ymm6,%ymm11
    18c8:	c5 79 6e e2          	vmovd  %edx,%xmm12
    18cc:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    18d1:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    18d6:	c4 63 15 4c 2d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm13,%ymm13        # 18ff <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18ff>
    18dd:	00 00 50 
    18e0:	c4 e2 4d 3d e9       	vpmaxsd %ymm1,%ymm6,%ymm5
    18e5:	c4 c1 4d 66 f2       	vpcmpgtd %ymm10,%ymm6,%ymm6
    18ea:	c4 c1 65 fe dd       	vpaddd %ymm13,%ymm3,%ymm3
    18ef:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    18f4:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
    18f8:	c5 79 6e d2          	vmovd  %edx,%xmm10
    18fc:	c4 e2 7d 90 0c 98    	vpgatherdd %ymm0,(%rax,%ymm3,4),%ymm1
    1902:	c5 e5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm3
    1907:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    190c:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm2,%ymm2        # 1935 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1935>
    1913:	00 00 60 
    1916:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    191a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    191f:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1923:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1928:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    192c:	c4 e2 15 90 14 a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm2
    1932:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    1938:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    193d:	48 8b 41 60          	mov    0x60(%rcx),%rax
    1941:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1946:	c5 fd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm0
    194b:	c5 dd 72 f3 10       	vpslld $0x10,%ymm3,%ymm4
    1950:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1955:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    195a:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    195f:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    1963:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    1967:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    196c:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1971:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    1975:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
    197c:	00 00 
    197e:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    1983:	c5 7d 6f f7          	vmovdqa %ymm7,%ymm14
    1987:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    198c:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    1991:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1995:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    1999:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    199f:	48 8b 41 68          	mov    0x68(%rcx),%rax
    19a3:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    19a7:	c4 a2 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm8,4),%ymm3
    19ad:	48 8b 41 70          	mov    0x70(%rcx),%rax
    19b1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    19b6:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    19ba:	c5 bd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm8
    19bf:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1a27 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a27>
    19c6:	00 
    19c7:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    19cb:	c4 e2 0d 90 14 80    	vpgatherdd %ymm14,(%rax,%ymm0,4),%ymm2
    19d1:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    19d6:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    19dd:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1a45 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a45>
    19e4:	00 
    19e5:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    19ea:	c4 42 3d 40 c3       	vpmulld %ymm11,%ymm8,%ymm8
    19ef:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    19f4:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    19f9:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1a61 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a61>
    1a00:	00 
    1a01:	c5 3d fe c0          	vpaddd %ymm0,%ymm8,%ymm8
    1a05:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    1a09:	c4 e2 5d 39 cb       	vpminsd %ymm3,%ymm4,%ymm1
    1a0e:	c4 41 2d fe d0       	vpaddd %ymm8,%ymm10,%ymm10
    1a13:	c4 a2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm8,4),%ymm5
    1a19:	c4 e2 5d 3d fb       	vpmaxsd %ymm3,%ymm4,%ymm7
    1a1e:	c4 a2 15 90 04 90    	vpgatherdd %ymm13,(%rax,%ymm10,4),%ymm0
    1a24:	c5 65 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm13
    1a28:	c4 e2 45 3d f2       	vpmaxsd %ymm2,%ymm7,%ymm6
    1a2d:	c5 ed 66 e7          	vpcmpgtd %ymm7,%ymm2,%ymm4
    1a31:	c4 62 75 39 ca       	vpminsd %ymm2,%ymm1,%ymm9
    1a36:	c4 e2 45 39 fa       	vpminsd %ymm2,%ymm7,%ymm7
    1a3b:	c5 f5 66 d2          	vpcmpgtd %ymm2,%ymm1,%ymm2
    1a3f:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
    1a44:	c4 c3 1d 4c db d0    	vpblendvb %ymm13,%ymm11,%ymm12,%ymm3
    1a4a:	c4 c3 25 4c cc d0    	vpblendvb %ymm13,%ymm12,%ymm11,%ymm1
    1a50:	c4 41 55 db df       	vpand  %ymm15,%ymm5,%ymm11
    1a55:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm3,%ymm3        # 1a7e <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a7e>
    1a5c:	00 00 40 
    1a5f:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    1a64:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    1a68:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    1a6c:	c5 7d 6f ec          	vmovdqa %ymm4,%ymm13
    1a70:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    1a75:	c4 62 0d 90 04 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm8
    1a7b:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 1aa4 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1aa4>
    1a82:	00 00 20 
    1a85:	c5 7d 6f f4          	vmovdqa %ymm4,%ymm14
    1a89:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    1a90:	c5 2d fa d1          	vpsubd %ymm1,%ymm10,%ymm10
    1a94:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1a99:	c4 c1 3d db cf       	vpand  %ymm15,%ymm8,%ymm1
    1a9e:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    1aa4:	c4 c1 6d 72 f3 10    	vpslld $0x10,%ymm11,%ymm2
    1aaa:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1aaf:	c4 a2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm10,4),%ymm3
    1ab5:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1aba:	c4 41 65 db d7       	vpand  %ymm15,%ymm3,%ymm10
    1abf:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1ac4:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    1acb:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1ad0:	c5 2d fa d1          	vpsubd %ymm1,%ymm10,%ymm10
    1ad4:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    1ad9:	c4 62 2d 40 d7       	vpmulld %ymm7,%ymm10,%ymm10
    1ade:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    1ae3:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    1ae8:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1aed:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    1af2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1af7:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1afc:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1b01:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1b05:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    1b0a:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1b0f:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1b13:	c4 c1 75 72 d0 08    	vpsrld $0x8,%ymm8,%ymm1
    1b19:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1b1e:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1b23:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    1b29:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1b2e:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    1b32:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1b37:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1b3c:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    1b41:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1b46:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1b4b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1b50:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1b55:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1b5a:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1b5e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1b63:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1b68:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    1b6d:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
    1b72:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1b76:	c4 c1 75 72 d0 10    	vpsrld $0x10,%ymm8,%ymm1
    1b7c:	c5 79 6e da          	vmovd  %edx,%xmm11
    1b80:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1b85:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1b8a:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1b8f:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    1b93:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1b97:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1b9c:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1ba1:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1ba6:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1baa:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1baf:	c4 e2 15 90 34 a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm6
    1bb5:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    1bbc:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    1bc0:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    1bc5:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1bca:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    1bce:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1bd3:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1bd8:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1bdc:	c4 e2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm3
    1be2:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    1be9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1bed:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1bf1:	c5 e5 db 15 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm2        # 1c59 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c59>
    1bf8:	00 
    1bf9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1bfe:	c5 bd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm8
    1c03:	c5 cd db 1d 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm3        # 1c6b <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c6b>
    1c0a:	00 
    1c0b:	c4 62 15 90 0c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm9
    1c11:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    1c16:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    1c1d:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    1c21:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1c26:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    1c2b:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    1c30:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
    1c36:	c5 6d 66 e3          	vpcmpgtd %ymm3,%ymm2,%ymm12
    1c3a:	c5 3d fe c0          	vpaddd %ymm0,%ymm8,%ymm8
    1c3e:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    1c42:	c4 e2 65 39 ca       	vpminsd %ymm2,%ymm3,%ymm1
    1c47:	c4 a2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm8,4),%ymm5
    1c4d:	c4 c1 5d fe e0       	vpaddd %ymm8,%ymm4,%ymm4
    1c52:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1c56:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    1c5c:	c4 e2 65 3d fa       	vpmaxsd %ymm2,%ymm3,%ymm7
    1c61:	c5 b5 db 15 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm2        # 1cc9 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1cc9>
    1c68:	00 
    1c69:	c4 c3 25 4c da c0    	vpblendvb %ymm12,%ymm10,%ymm11,%ymm3
    1c6f:	c5 ed 66 f7          	vpcmpgtd %ymm7,%ymm2,%ymm6
    1c73:	c4 62 75 39 ca       	vpminsd %ymm2,%ymm1,%ymm9
    1c78:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # 1ca1 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ca1>
    1c7f:	00 00 60 
    1c82:	c4 e2 45 3d f2       	vpmaxsd %ymm2,%ymm7,%ymm6
    1c87:	c4 e2 45 39 fa       	vpminsd %ymm2,%ymm7,%ymm7
    1c8c:	c5 f5 66 d2          	vpcmpgtd %ymm2,%ymm1,%ymm2
    1c90:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
    1c95:	c4 c3 2d 4c cb c0    	vpblendvb %ymm12,%ymm11,%ymm10,%ymm1
    1c9b:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    1c9f:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    1ca4:	c4 41 55 db df       	vpand  %ymm15,%ymm5,%ymm11
    1ca9:	c4 62 0d 90 04 98    	vpgatherdd %ymm14,(%rax,%ymm3,4),%ymm8
    1caf:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1cb4:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1cb9:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    1cbe:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm1,%ymm1        # 1ce7 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ce7>
    1cc5:	00 00 20 
    1cc8:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
    1ccc:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1cd1:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1cd5:	c4 c1 3d db cf       	vpand  %ymm15,%ymm8,%ymm1
    1cda:	c4 e2 6d 90 1c a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm3
    1ce0:	c4 c1 6d 72 f3 10    	vpslld $0x10,%ymm11,%ymm2
    1ce6:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1ceb:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    1cf2:	c4 41 65 db d7       	vpand  %ymm15,%ymm3,%ymm10
    1cf7:	c4 c1 6d fe d6       	vpaddd %ymm14,%ymm2,%ymm2
    1cfc:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1d01:	c5 2d fa d1          	vpsubd %ymm1,%ymm10,%ymm10
    1d05:	c4 62 2d 40 d7       	vpmulld %ymm7,%ymm10,%ymm10
    1d0a:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    1d0f:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    1d14:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1d19:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    1d1e:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1d23:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1d28:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1d2d:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    1d32:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    1d38:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1d3c:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1d41:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    1d46:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1d4a:	c4 c1 75 72 d0 08    	vpsrld $0x8,%ymm8,%ymm1
    1d50:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1d55:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1d5a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1d5f:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1d64:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    1d68:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1d6d:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1d72:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    1d77:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1d7c:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1d81:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1d85:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1d8a:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1d8f:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1d94:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    1d99:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1d9d:	c4 c1 75 72 d0 10    	vpsrld $0x10,%ymm8,%ymm1
    1da3:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1da8:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1dad:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1db2:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    1db6:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1dba:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1dbf:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1dc4:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1dc8:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    1dcd:	c4 e2 15 90 34 a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm6
    1dd3:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    1dda:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    1de1:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    1de7:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    1deb:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1def:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1df4:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1df9:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1dfd:	c4 e2 45 90 1c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm3
    1e03:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    1e0a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1e0e:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
    1e13:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1e17:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1e1c:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    1e21:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1e26:	c4 62 15 90 0c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm9
    1e2c:	c5 a5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm11
    1e31:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    1e35:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    1e3c:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    1e41:	c4 42 25 40 d8       	vpmulld %ymm8,%ymm11,%ymm11
    1e46:	c5 e5 db 15 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm2        # 1eae <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1eae>
    1e4d:	00 
    1e4e:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1e53:	c4 c1 75 72 d1 11    	vpsrld $0x11,%ymm9,%ymm1
    1e59:	c5 cd db 1d 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm3        # 1ec1 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ec1>
    1e60:	00 
    1e61:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1e66:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    1e6a:	c5 6d 66 e3          	vpcmpgtd %ymm3,%ymm2,%ymm12
    1e6e:	c5 25 fe d8          	vpaddd %ymm0,%ymm11,%ymm11
    1e72:	c5 25 fe d9          	vpaddd %ymm1,%ymm11,%ymm11
    1e76:	c4 e2 65 39 ca       	vpminsd %ymm2,%ymm3,%ymm1
    1e7b:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    1e80:	c4 a2 15 90 2c 98    	vpgatherdd %ymm13,(%rax,%ymm11,4),%ymm5
    1e86:	c5 7d 6f ef          	vmovdqa %ymm7,%ymm13
    1e8a:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    1e90:	c4 e2 65 3d fa       	vpmaxsd %ymm2,%ymm3,%ymm7
    1e95:	c5 b5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm3        # 1efd <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1efd>
    1e9c:	00 
    1e9d:	c4 c3 2d 4c d0 c0    	vpblendvb %ymm12,%ymm8,%ymm10,%ymm2
    1ea3:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
    1ea8:	c5 e5 66 f7          	vpcmpgtd %ymm7,%ymm3,%ymm6
    1eac:	c4 62 75 39 cb       	vpminsd %ymm3,%ymm1,%ymm9
    1eb1:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm2,%ymm2        # 1eda <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1eda>
    1eb8:	00 00 60 
    1ebb:	c4 e2 45 3d f3       	vpmaxsd %ymm3,%ymm7,%ymm6
    1ec0:	c4 e2 45 39 fb       	vpminsd %ymm3,%ymm7,%ymm7
    1ec5:	c5 f5 66 db          	vpcmpgtd %ymm3,%ymm1,%ymm3
    1ec9:	c4 e2 75 3d ff       	vpmaxsd %ymm7,%ymm1,%ymm7
    1ece:	c4 c3 3d 4c ca c0    	vpblendvb %ymm12,%ymm10,%ymm8,%ymm1
    1ed4:	c5 25 fe da          	vpaddd %ymm2,%ymm11,%ymm11
    1ed8:	c5 9d 72 d5 08       	vpsrld $0x8,%ymm5,%ymm12
    1edd:	c4 a2 0d 90 14 98    	vpgatherdd %ymm14,(%rax,%ymm11,4),%ymm2
    1ee3:	c4 41 55 db df       	vpand  %ymm15,%ymm5,%ymm11
    1ee8:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    1eed:	c4 c1 3d 72 f3 10    	vpslld $0x10,%ymm11,%ymm8
    1ef3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1ef8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm1,%ymm1        # 1f21 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f21>
    1eff:	00 00 30 
    1f02:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1f06:	c4 c1 6d db cf       	vpand  %ymm15,%ymm2,%ymm1
    1f0b:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1f10:	c4 e2 15 90 1c a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm3
    1f16:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1f1b:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    1f20:	c4 41 65 db d7       	vpand  %ymm15,%ymm3,%ymm10
    1f25:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1f2a:	c5 2d fa d1          	vpsubd %ymm1,%ymm10,%ymm10
    1f2e:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    1f33:	c4 62 2d 40 d7       	vpmulld %ymm7,%ymm10,%ymm10
    1f38:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    1f3d:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    1f42:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1f47:	c5 a5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm11
    1f4c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1f51:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1f56:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1f5b:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1f60:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    1f65:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    1f6a:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    1f6e:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    1f73:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1f78:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1f7d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1f82:	c4 41 3d fa c3       	vpsubd %ymm11,%ymm8,%ymm8
    1f87:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    1f8b:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1f90:	c4 42 3d 40 c1       	vpmulld %ymm9,%ymm8,%ymm8
    1f95:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    1f9a:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1f9f:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1fa4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1fa9:	c4 c1 2d 72 f4 10    	vpslld $0x10,%ymm12,%ymm10
    1faf:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1fb4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1fb9:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    1fbe:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1fc2:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    1fc6:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1fcb:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1fd0:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1fd4:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    1fd9:	c4 41 3d fe c3       	vpaddd %ymm11,%ymm8,%ymm8
    1fde:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1fe3:	c5 bd fe c9          	vpaddd %ymm1,%ymm8,%ymm1
    1fe7:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    1fec:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    1ff1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1ff6:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
    1ffb:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1fff:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    2004:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2008:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    200d:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    2012:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    2016:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    201a:	c4 e2 7d 00 84 24 20 	vpshufb 0x220(%rsp),%ymm0,%ymm0
    2021:	02 00 00 
    2024:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2028:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    202e:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2033:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2038:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    203c:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2042:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    2048:	4d 39 c2             	cmp    %r8,%r10
    204b:	0f 85 e7 f4 ff ff    	jne    1538 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1538>
    2051:	e9 b3 e7 ff ff       	jmp    809 <jshc_geometry::avx2_chain(jshc_geometry::View const*, unsigned long long, unsigned char*, unsigned long long)+0x809>
    2056:	90                   	nop
    2057:	90                   	nop
    2058:	90                   	nop
    2059:	90                   	nop
    205a:	90                   	nop
    205b:	90                   	nop
    205c:	90                   	nop
    205d:	90                   	nop
    205e:	90                   	nop
    205f:	90                   	nop
