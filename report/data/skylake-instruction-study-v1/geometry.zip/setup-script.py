"""一次性生成独立坐标排序候选与冻结计划；不执行数值内核。"""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
folder = root/'experiments/skylake-geometry-runtime'
folder.mkdir(exist_ok=False)
for name in ('channel_avx2.cpp', 'channel_runtime.cpp', 'channel_views.hpp'):
    source = (root/'experiments/skylake-delta16-runtime'/name).read_text(encoding='utf-8')
    source = source.replace('jshc_delta16', 'jshc_geometry')
    if name == 'channel_runtime.cpp':
        assert 'return 5;' in source
        source = source.replace('return 5;', 'return 17;')
    if name == 'channel_avx2.cpp':
        old = '''  first=_mm256_blendv_epi8(sr,sg,_mm256_cmpgt_epi32(y,x));high=_mm256_max_epi32(x,y);
  first=_mm256_blendv_epi8(first,one,_mm256_cmpgt_epi32(z,high));high=_mm256_max_epi32(high,z);
  last=_mm256_blendv_epi8(sr,sg,_mm256_cmpgt_epi32(x,y));low=_mm256_min_epi32(x,y);
  last=_mm256_blendv_epi8(last,one,_mm256_cmpgt_epi32(low,z));low=_mm256_min_epi32(low,z);
  middle=_mm256_sub_epi32(_mm256_add_epi32(_mm256_add_epi32(x,y),z),_mm256_add_epi32(high,low));'''
        new = '''  const __m256i xy=_mm256_cmpgt_epi32(y,x),maxxy=_mm256_max_epi32(x,y),minxy=_mm256_min_epi32(x,y);
  first=_mm256_blendv_epi8(sr,sg,xy);
  first=_mm256_blendv_epi8(first,one,_mm256_cmpgt_epi32(z,maxxy));high=_mm256_max_epi32(maxxy,z);
  // x==y时低轴改选G；零重心权重使这个等值轴换序保持精确。
  last=_mm256_blendv_epi8(sg,sr,xy);
  last=_mm256_blendv_epi8(last,one,_mm256_cmpgt_epi32(minxy,z));low=_mm256_min_epi32(minxy,z);
  middle=_mm256_max_epi32(minxy,_mm256_min_epi32(maxxy,z));'''
        assert source.count(old) == 1
        source = source.replace(old, new)
        source = source.replace('// 有界有符号坐标差减少三次dword gather；RGB节点、Q16权重和逐级舍入保持精确。',
                                '// 精确中值网络与比较掩码复用；坐标差编码、节点和逐级舍入保持原样。')
    (folder/name).write_text(source, encoding='utf-8', newline='\n')

cmake = (root/'experiments/skylake-common.cmake').read_text(encoding='utf-8')
cmake = cmake.replace('${CMAKE_CURRENT_LIST_DIR}/.."', '${CMAKE_CURRENT_LIST_DIR}/../.."')
cmake = cmake.replace('experiments/channel-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/channel-runtime-specialized/channel_avx2.cpp',
                      'experiments/skylake-delta16-runtime/channel_runtime.cpp"\n  "${JSHC_ROOT}/experiments/skylake-delta16-runtime/channel_avx2.cpp')
cmake = cmake.replace('"${JSHC_ROOT}/experiments/channel-runtime-specialized/channel_avx2.cpp"',
                      '"${JSHC_ROOT}/experiments/skylake-delta16-runtime/channel_avx2.cpp"')
cmake = '''cmake_minimum_required(VERSION 3.24)
project(jshc_skylake_geometry LANGUAGES CXX C)
set(SKYLAKE_CANDIDATE_TARGET jshc_skylake_geometry)
set(SKYLAKE_RUNTIME_SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/channel_runtime.cpp")
''' + cmake
(folder/'CMakeLists.txt').write_text(cmake, encoding='utf-8', newline='\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
plan = json.loads((root/'experiments/skylake-delta16-v2.json').read_text(encoding='utf-8'))
plan.pop('deadline_shanghai', None)
plan.pop('test_plan_revision_reason', None)
plan['purpose'] = '固定坐标差修订5与精确中值网络修订17比较；不新增缓存，不改变模型或容量'
plan['base_commit'] = '860d6bf'
plan['remote_snapshot'] = 'b19c5a0'
plan['candidate'] = 'middle=max(min(x,y),min(max(x,y),z))；共享y>x掩码选高低轴，等值时只交换零权重顶点'
plan['cmake_project'] = 'experiments/skylake-geometry-runtime'
plan['cmake_targets'] = ['jshc_skylake_reference', 'jshc_skylake_geometry']
plan['revisions'] = {'reference': 5, 'candidate': 17}
plan['test_plan_revision'] = 1
plan['contract']['oracle'] = '独立uint64凸重心逐级RGB8，与两个原生库逐字节比较'
plan['contract']['acceptance'] = '全部字节一致且越界哨兵不变；有限合同后完整256³与100图'
plan['geometry_policy'] = {
    'domain': 'Q16闭区间[0,65536]，整数运算；重复坐标对应零重心权重',
    'static_gate': '原8次gather实际四级热循环无调用；Skylake总周期至少下降3%，栈操作数不增加超过10%；失败即保留静态结果停止',
    'performance_gate': '沿用3%中位收益、任一进程不退化2%、copy+apply中位不退化；唯一AB/BA/BA/AB，每配置5轮；每轮外部核对SHA',
    'stop': '不扫描排序网络、线程数、块大小或编译选项；失败不重复计时'
}
names = set(plan['source_sha256']) | {p.relative_to(root).as_posix() for p in folder.iterdir()}
plan['source_sha256'] = {n: sha(root/n) for n in sorted(names)}
(root/'experiments/skylake-geometry-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('独立候选和冻结计划已生成；数值调用为0')
