import concurrent.futures as cf
import json,subprocess,urllib.request,urllib.error,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
cred_proc=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',text=True,capture_output=True,check=True)
cred=dict(line.split('=',1) for line in cred_proc.stdout.splitlines() if '=' in line)
headers={'Authorization':'Bearer '+cred['password'],'Accept':'application/vnd.github+json','User-Agent':'flash-chroma-stage-audit'}
base='https://api.github.com/repos/WyEhNf/flash-chroma/'
def request(url,data=None):
 req=urllib.request.Request(url,headers=headers,data=None if data is None else json.dumps(data).encode(),method=None if data is None else 'POST')
 with urllib.request.urlopen(req,timeout=60) as r:
  return json.load(r),r.headers.get('Link','')
def pages(endpoint):
 url=base+endpoint+('&' if '?' in endpoint else '?')+'per_page=100';items=[];count=0
 while url:
  data,link=request(url);items.extend(data);count+=1
  m=re.search(r'<([^>]+)>; rel="next"',link);url=m.group(1) if m else None
 return {'endpoint':endpoint,'pages':count,'items':items}
def scrub(value):
 if isinstance(value,dict):return {k:scrub(v) for k,v in value.items() if k!="temp_clone_token"}
 if isinstance(value,list):return [scrub(v) for v in value]
 return value

def save(name,value):
 value=scrub(value)
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
prs=pages('pulls?state=all');issues=pages('issues?state=all');repo,_=request(base.rstrip('/'));save('prs.json',prs);save('issues.json',issues);save('repo.json',repo)
nums=[p['number'] for p in prs['items']]
endpoints=[f'issues/{n}/comments' for n in sorted({p['number'] for p in issues['items']})]
endpoints += [f'pulls/{n}/{kind}' for n in nums for kind in ('reviews','comments')]
records=[]
with cf.ThreadPoolExecutor(max_workers=6) as pool:
 for value in pool.map(pages,endpoints):
  records.append(value)
  save(value['endpoint'].replace('/','-')+'.json',value)
aliases=[]
for n in nums:
 aliases.append('p'+str(n)+':pullRequest(number:'+str(n)+'){number reviewThreads(first:20){pageInfo{hasNextPage endCursor} nodes{id isResolved isOutdated path line comments(first:100){pageInfo{hasNextPage endCursor} nodes{id url body author{login}}}}}}')
query='query { repository(owner:"WyEhNf",name:"flash-chroma") {'+' '.join(aliases)+' discussions(first:20){pageInfo{hasNextPage endCursor} nodes{id number url title body comments(first:100){pageInfo{hasNextPage endCursor} nodes{id url body author{login} replies(first:100){pageInfo{hasNextPage endCursor} nodes{id url body author{login}}}}}}}}}'
gql,_=request('https://api.github.com/graphql',{'query':query});save('graphql.json',gql)
if gql.get('errors'):raise RuntimeError('GraphQL读取失败，原始错误已保存')
def complete(value):
 if isinstance(value,dict):
  if value.get('pageInfo',{}).get('hasNextPage'):raise RuntimeError('GraphQL存在未读分页，不得据此操作PR')
  for x in value.values():complete(x)
 elif isinstance(value,list):
  for x in value:complete(x)
complete(gql)
summary={'prs':len(nums),'independent_issues':len([x for x in issues['items'] if 'pull_request' not in x]),'rest_groups':len(records),'nonempty':{x['endpoint']:len(x['items']) for x in records if x['items']},'review_threads':sum(len(x['reviewThreads']['nodes']) for k,x in gql['data']['repository'].items() if k.startswith('p')),'discussions':len(gql['data']['repository']['discussions']['nodes']),'all_pages_read':True}
save('summary.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
