"""只归档已完成的Linux布局入口验证；不运行模型或性能，检查原始字节和完整覆盖。"""
from pathlib import Path
import hashlib,json,zipfile,shutil,platform,sys
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent;bundle=ROOT/'artifacts/skylake-layout-server-v2';run=bundle/'artifacts/linux layout-v1'
out=ROOT/'report/data/skylake-layout-server-v2'
if out.exists():raise ValueError('不覆盖归档')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def localpath(value):
 if value.startswith('/mnt/f/'):return Path('F:/'+value[len('/mnt/f/'):])
 raise ValueError('不归档包外系统库：'+value)
b=read(bundle/'bundle-manifest.json');r=read(run/'results.json');c=read(run/'correctness.json');policy=read(run/'policy.json')
assert r['pass'] and r['correctness_passed'] and not r['performance_measured'] and r['adoption_by_comparison'] is None
assert r['bundle_sha256']==sha(bundle/'bundle-manifest.json') and r['correctness_sha256']==sha(run/'correctness.json')
assert r['policy_sha256']==sha(run/'policy.json')==c['policy_sha256']
assert not read(run/'run.json')['performance_requested']
assert not (run/'performance.json').exists() and not any(run.glob('worker[0-3].json'))
assert c['pass'] and c['finite_backend_offset_comparisons']==3432 and c['diagnostic_negative_checks']==20
assert len(c['full_domain_pixels_per_configuration'])==12 and set(c['full_domain_pixels_per_configuration'].values())=={256**3}
for key,v in c['full_output_sha256'].items():
 assert v==('7837c93f7b177a93e4bfb9afe8381e22eb24bdcca16009d6042e5f5b840ff146' if '_single_' in key else '3c9ce8d98d8db454ce9337c50c2ecadb8ba59485d6bc3e6a42e3cc1dfe307c22')
assert len(c['photos'])==8 and all(x['validation_rounds']==2 and x['round_output_sha256']==[b['photo_output_sha256']]*2 for x in c['photos'])
assert len(c['driver_negative_contract'])==14 and c['driver_callback_failure_aborted']
assert sum(x['entries'] for x in c['cache_table_audits'] if x['physical_export_checked'])==209600
assert all(c['teams'][str(n)]['actual']==n for n in (1,4))
assert c['teams']['4']['cpus']==[0,2,4,6]
for mode in ('single','chain'):assert c['actual_models']['cache'][mode]['model_accounting_bytes']==c['actual_models']['r_contiguous'][mode]['model_accounting_bytes']
for name,spec in b['files'].items():
 path=bundle/name
 if sha(path)!=spec['sha256'] or path.stat().st_size!=spec['bytes']:raise ValueError('包输入变化：'+name)
for name,value in b['source_sha256'].items():assert sha(ROOT/name)==value
build=read(localpath(policy['builds']['layout']['path']))
assert build['plan_sha256']==policy['plans']['layout']['sha256']
for role,key in (('cache','reference'),('r_contiguous','candidate')):
 spec=build['libraries'][key]
 assert c['libraries'][role]==spec and sha(localpath(spec['path']))==spec['sha256']
source_plan=read(ROOT/'experiments/skylake-r-contiguous-v1.json');derived=read(bundle/b['plans']['layout'])
native={n:v for n,v in derived['source_sha256'].items() if not n.startswith('scripts/')}
assert all(source_plan['source_sha256'][n]==v for n,v in native.items())
out.mkdir()
for p in sorted(run.glob('*.json')):shutil.copyfile(p,out/p.name)
shutil.copyfile(bundle/'bundle-manifest.json',out/'bundle-manifest.json')
shutil.copyfile(bundle/'SERVER_LAYOUT_README.md',out/'SERVER_LAYOUT_README.md')
with zipfile.ZipFile(out/'fixed-small-packet.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,spec in b['files'].items():
  if spec['bytes']<=1024*1024:z.write(bundle/name,name)
 z.write(bundle/'bundle-manifest.json','bundle-manifest.json')
with zipfile.ZipFile(out/'linux-builds-and-binaries.zip','w',zipfile.ZIP_DEFLATED) as z:
 for directory in ('backend-layout','driver'):
  for p in sorted((run/directory).rglob('*')):
   if p.is_file() and (p.suffix in ('.so','.a') or p.name in ('build.json','build-log.json','compile_commands.json','measured-source.zip','libraries-Release.json','driver-Release.json')):
    z.write(p,p.relative_to(run).as_posix())
with zipfile.ZipFile(out/'import-preflight.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (ROOT/'artifacts/skylake-layout-server-preflight-v1').iterdir():
  if p.is_file():z.write(p,'preflight/'+p.name)
 failed=ROOT/'artifacts/skylake-layout-server-v1'
 z.write(failed/'bundle-manifest.json','failed-v1/bundle-manifest.json')
 for p in (failed/'scripts').glob('*.py'):z.write(p,'failed-v1/scripts/'+p.name)
with zipfile.ZipFile(out/'archive-source.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(Path(__file__),'archive.py')
summary={'purpose':__doc__,'pass':True,'environment':{'platform':platform.platform(),'python':sys.version},
 'bundle_sha256':sha(bundle/'bundle-manifest.json'),'full_zip':{'local_path':'artifacts/skylake-layout-server-v2.zip','sha256':sha(Path(str(bundle)+'.zip')),'bytes':Path(str(bundle)+'.zip').stat().st_size},
 'large_inputs_omitted_from_git':{n:v for n,v in b['files'].items() if v['bytes']>1024*1024},
 'native_source_unchanged':True,'native_source_sha256':native,'finite_backend_offset_comparisons':3432,'full_domain_configurations':12,'physical_words_checked':209600,
 'diagnostic_negative_checks':20,'photo_configurations':8,'driver_validation_hundred_image_groups':16,'every_validation_round_output_checked':True,
 'driver_negative_cases':14,'callback_failure_aborted':True,'formal_performance_groups':0,'performance_branch_executed':False,
 'scope':'AMD/WSL协议验证与归档，原生4/13代码未改，Windows80组失败未覆盖；160组正式性能及Skylake仍未执行，不能推断采用通过。',
 'new_native_calls':0,'new_performance_calls':0}
save(out/'archive-verification.json',summary)
save(out/'manifest.json',{'purpose':__doc__,'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()},
 'scope':'只归档已完成正确性；完整大流包本地保留，小包需补齐列出的固定大流才能运行。'})
print(json.dumps({'out':str(out),'full_zip':summary['full_zip'],'files':len(list(out.iterdir())),'native_sources':len(native)},ensure_ascii=False))
