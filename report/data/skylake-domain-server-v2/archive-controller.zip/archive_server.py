"""归档一次修正后的WSL正确性及初版元数据失败；不重跑目标端或性能。"""
import hashlib,json,shutil,zipfile
from pathlib import Path
ROOT=Path.cwd();OLD=ROOT/'artifacts/skylake-domain-server-v1';PACK=ROOT/'artifacts/skylake-domain-server-v2'
RUN=PACK/'artifacts/linux domain-v2';FAILED=OLD/'artifacts/linux domain-v1';OUT=ROOT/'report/data/skylake-domain-server-v2'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def local(path):
 if not path.startswith('/mnt/f/'):raise ValueError('只归档工作区内自建库')
 p=Path('F:/'+path[len('/mnt/f/'):]).resolve()
 if ROOT.resolve() not in p.parents:raise ValueError('库不在项目内')
 return p
if OUT.exists():raise ValueError('不覆盖目标端档案')
bundle=read(PACK/'bundle-manifest.json');old=read(OLD/'bundle-manifest.json');result=read(RUN/'results.json');correct=read(RUN/'correctness.json');policy=read(RUN/'policy.json')
assert result['pass'] and result['correctness_passed'] and result['performance_measured'] is False and result['adoption_by_comparison'] is None
assert sha(RUN/'correctness.json')==result['correctness_sha256'] and sha(RUN/'policy.json')==result['policy_sha256'] and sha(PACK/'bundle-manifest.json')==result['bundle_sha256']
assert correct['pass'] and correct['finite_backend_offset_comparisons']==3432 and correct['diagnostic_negative_checks']==72
assert len(correct['full_domain_pixels_per_configuration'])==12 and set(correct['full_domain_pixels_per_configuration'].values())=={256**3}
assert len(correct['photos'])==8 and len(correct['domain_diagnostics'])==13 and len(correct['driver_negative_contract'])==14
assert correct['byte_mismatches']==correct['sentinel_mismatches']==0 and correct['performance_comparison_performed'] is False
assert correct['teams']['4']['actual']==4 and correct['teams']['4']['cpus']==[0,2,4,6]
for row in correct['photos']:assert row['validation_rounds']==2 and row['round_output_sha256']==[bundle['photo_output_sha256']]*2
assert correct['photo_source_sha256']=='e13278cfc91c3411b3c242232239f9ea6fbda3bf5d18c3f17c41a4dedf57defd'
assert correct['actual_models']['domain_isolated']['chain']['domain_certificate']['fast_path_enabled']==1
assert all(correct['actual_models'][role]['chain']['model_accounting_bytes']==1800836 for role in ('cache','domain_isolated'))
assert (OLD/'server-inputs/plans/domain.json').read_bytes()==(PACK/'server-inputs/plans/domain.json').read_bytes()
native=read(PACK/'server-inputs/plans/domain.json')['source_sha256']
assert all(sha(OLD/name)==expected==sha(PACK/name) for name,expected in native.items())
fixtures=read(PACK/bundle['fixture_manifest']);assert sum('domain_certificate_expected' in row for row in fixtures['cases'])==5
assert all(row['name'].startswith('cache_') for row in fixtures['cases'] if 'domain_certificate_expected' in row)
OUT.mkdir()
for p in RUN.iterdir():
 if p.is_file() and p.suffix=='.json':shutil.copyfile(p,OUT/('linux-'+p.name))
shutil.copyfile(PACK/'bundle-manifest.json',OUT/'bundle-manifest.json')
oldcases=read(OLD/old['fixture_manifest'])['cases'];legacy=next(c for c in oldcases if c['name']=='equal_changed_shared');narrow=next(c for c in oldcases if c['name']=='cache_equal_changed_shared')
audit={'purpose':'首包因同名不同模型误绑域诊断而拒绝；修正仅限夹具身份绑定，原生及数值预期不变',
 'first_failure':read(FAILED/'correctness-command.json'),'old_bundle_sha256':sha(OLD/'bundle-manifest.json'),
 'new_bundle_sha256':sha(PACK/'bundle-manifest.json'),'legacy_model_sha256':sha(OLD/legacy['models'][0]),
 'narrow_model_sha256':sha(OLD/narrow['models'][0]),'models_are_different':sha(OLD/legacy['models'][0])!=sha(OLD/narrow['models'][0]),
 'native_and_derived_plan_bytes_unchanged':True,'new_bindings':bundle['domain_fixture_identity_bindings'],
 'finite_output_bytes_regenerated':False,'native_calls_in_this_archiver':0,'performance_calls':0}
assert audit['models_are_different'];save(OUT/'initial-failure-and-fix.json',audit)
with zipfile.ZipFile(OUT/'initial-failed-packet-small.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in old['files']:
  if name not in (old['photo_pixels'],old['single_oracle_stream'],'artifacts/cinema-current-anchor-accept-v1/cube.rgb'):z.write(OLD/name,name)
 z.write(OLD/'bundle-manifest.json','bundle-manifest.json')
 for p in FAILED.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.so','.zip'):z.write(p,'failed-run/'+p.relative_to(FAILED).as_posix())
large={bundle['photo_pixels'],bundle['single_oracle_stream'],'artifacts/cinema-current-anchor-accept-v1/cube.rgb'}
with zipfile.ZipFile(OUT/'server-packet-small.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,entry in bundle['files'].items():
  if sha(PACK/name)!=entry['sha256']:raise ValueError('冻结包文件变化：'+name)
  if name not in large:z.write(PACK/name,name)
 z.write(PACK/'bundle-manifest.json','bundle-manifest.json')
libraries=read(RUN/'backend-domain/build.json')['libraries']
with zipfile.ZipFile(OUT/'linux-built-libraries.zip','w',zipfile.ZIP_DEFLATED) as z:
 for role,spec in libraries.items():z.write(local(spec['path']),role+'/'+Path(spec['path']).name)
 z.write(local(policy['driver']['path']),'driver/'+Path(policy['driver']['path']).name)
with zipfile.ZipFile(OUT/'linux-build-details.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('backend-domain','driver'):
  for p in (RUN/folder).iterdir():
   if p.is_file() and p.suffix in ('.json','.zip'):z.write(p,folder+'/'+p.name)
objects=list((RUN/'backend-domain').rglob('channel_avx2.cpp.o'))
ref=next(p for p in objects if 'jshc_skylake_reference.dir' in p.parts)
fallback=next(p for p in objects if 'jshc_skylake_domain_isolated.dir' in p.parts and 'skylake-suffix-cache-runtime' in p.parts)
save(OUT/'linux-fallback-object-proof.json',{'reference_sha256':sha(ref),'candidate_fallback_sha256':sha(fallback),
 'byte_identical':sha(ref)==sha(fallback),'scope':'只读实际Linux对象，不证明新增准备/入口没有成本，未进行性能比较'})
assert sha(ref)==sha(fallback)
fullzip=Path(str(PACK)+'.zip')
save(OUT/'delivery-packet.json',{'purpose':'冻结完整传输包及小包的精确身份，旧四方案/4对13包保持不变',
 'bundle_manifest_sha256':sha(PACK/'bundle-manifest.json'),'full_zip':{'path':str(fullzip),'sha256':sha(fullzip),'bytes':fullzip.stat().st_size},
 'small_packet_sha256':sha(OUT/'server-packet-small.zip'),'large_files_omitted_from_small':{n:bundle['files'][n] for n in sorted(large)},
 'future_performance_hundred_groups':policy['protocol']['hundred_image_groups'],'performance_measured':False,
 'correctness_sha256':sha(RUN/'correctness.json'),'native_files_unchanged_from_windows':True,
 'scope':'WSL/AMD移植正确性，不是实际Skylake；完整原字节流不入Git，小包需要按清单恢复三个原流'})
print(json.dumps({'bundle':sha(PACK/'bundle-manifest.json'),'full_zip_sha256':sha(fullzip),'full_zip_bytes':fullzip.stat().st_size,
 'linux_correctness':sha(RUN/'correctness.json'),'linux_fallback_equal':sha(ref)==sha(fallback),'performance':False},ensure_ascii=False))
