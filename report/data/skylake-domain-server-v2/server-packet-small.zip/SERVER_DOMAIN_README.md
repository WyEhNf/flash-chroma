# 域证明4/16服务器验收

目标Linux x86_64需Python3.11+标准库、CMake3.24+、GNU C/C++及OpenMP；无需NumPy/Pillow。默认仅正确性：

```sh
python3 scripts/run_skylake_domain_server.py --bundle bundle-manifest.json --output artifacts/domain-server-v1 --compiler /usr/bin/g++ --c-compiler /usr/bin/gcc
```

正式Skylake先核对实际SKU/系统/微码/GDS/NUMA及同L3不同物理核，可加--expected-cpu完整型号及--cpus四个核号，再显式加--measure。四串行新进程AB/BA/BA/AB，1/4线程及整批/逐图，每配置5轮，共160组百图；每轮输出SHA在原生计时外核验。四种场景全部达到中位改善3%、最差apply进程回退不超2%、copy+apply和准备加已预热首轮不退化才通过，不重试或扫描。

先执行3432项有限字节比较、域证明诊断/拒绝、原缓存全槽、12组完整256³、8个调度配置各两轮百图、14项计时器拒绝及回调中止。正确性阶段调用计时器，但时长不作性能比较。

Windows/AMD的7.07%/5.10%是该轮同机描述，不代替Skylake结果；Linux新编译必须重验。原回退内核逐字节保留只证明其对象，不表示新准备/入口成本为零。默认、模型、题目误差口径不变；官方数据、Threshold和派生缓存许可待取得，不改安全或频率设置。
