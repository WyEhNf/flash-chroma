
F:\Hackathon\projects\16-lut-color\artifacts\skylake-madd-build-v1\CMakeFiles\jshc_skylake_madd16.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
       7:	c5 f8 29 b4 24 40 01 	vmovaps %xmm6,0x140(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 50 01 	vmovaps %xmm7,0x150(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 60 01 	vmovaps %xmm8,0x160(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 70 01 	vmovaps %xmm9,0x170(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 80 01 	vmovaps %xmm10,0x180(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 90 01 	vmovaps %xmm11,0x190(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 a0 01 	vmovaps %xmm12,0x1a0(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 b0 01 	vmovaps %xmm13,0x1b0(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 c0 01 	vmovaps %xmm14,0x1c0(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 d0 01 	vmovaps %xmm15,0x1d0(%rsp)
      5f:	00 00 
      61:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      65:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      69:	c5 95 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm13
      6e:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
      72:	48 89 d0             	mov    %rdx,%rax
      75:	48 8b 11             	mov    (%rcx),%rdx
      78:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      7c:	c5 fd 6f 38          	vmovdqa (%rax),%ymm7
      80:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      84:	c5 fd 6f 68 40       	vmovdqa 0x40(%rax),%ymm5
      89:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
      8e:	c4 e2 5d 90 14 ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm2
      94:	48 8b 51 08          	mov    0x8(%rcx),%rdx
      98:	c5 fd 6f 78 20       	vmovdqa 0x20(%rax),%ymm7
      9d:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
      a1:	c4 41 79 6e f8       	vmovd  %r8d,%xmm15
      a6:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
      ab:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
      b0:	c4 e2 5d 90 1c ba    	vpgatherdd %ymm4,(%rdx,%ymm7,4),%ymm3
      b6:	48 8b 51 10          	mov    0x10(%rcx),%rdx
      ba:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
      be:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
      c3:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
      c8:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
      cd:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
      d3:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
      d8:	48 8b 51 48          	mov    0x48(%rcx),%rdx
      dc:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
      e1:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
      e6:	c4 c2 75 40 cf       	vpmulld %ymm15,%ymm1,%ymm1
      eb:	c4 62 6d 3d c3       	vpmaxsd %ymm3,%ymm2,%ymm8
      f0:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
      f5:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
      fa:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
      fe:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     102:	c5 75 fe de          	vpaddd %ymm6,%ymm1,%ymm11
     106:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     10b:	c4 e2 6d 39 f3       	vpminsd %ymm3,%ymm2,%ymm6
     110:	41 b8 00 80 00 00    	mov    $0x8000,%r8d
     116:	c4 a2 55 90 3c 9a    	vpgatherdd %ymm5,(%rdx,%ymm11,4),%ymm7
     11c:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     121:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     126:	c4 41 75 fe e3       	vpaddd %ymm11,%ymm1,%ymm12
     12b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     12f:	c4 a2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm12,4),%ymm5
     135:	c4 c1 5d 66 c8       	vpcmpgtd %ymm8,%ymm4,%ymm1
     13a:	c5 7e 7f 4c 24 40    	vmovdqu %ymm9,0x40(%rsp)
     140:	c4 62 4d 39 cc       	vpminsd %ymm4,%ymm6,%ymm9
     145:	c5 7d 6f f5          	vmovdqa %ymm5,%ymm14
     149:	c5 e5 66 ea          	vpcmpgtd %ymm2,%ymm3,%ymm5
     14d:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
     152:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
     159:	00 00 
     15b:	c5 cd 66 f4          	vpcmpgtd %ymm4,%ymm6,%ymm6
     15f:	c4 c1 3d fe f9       	vpaddd %ymm9,%ymm8,%ymm7
     164:	c5 dd fa ff          	vpsubd %ymm7,%ymm4,%ymm7
     168:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
     16c:	c4 e3 05 4c 6c 24 40 	vpblendvb %ymm5,0x40(%rsp),%ymm15,%ymm5
     173:	50 
     174:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm5,%ymm5        # 17d <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x17d>
     17b:	ff ff 10 
     17e:	c5 ed fe cb          	vpaddd %ymm3,%ymm2,%ymm1
     182:	c5 ed 66 d3          	vpcmpgtd %ymm3,%ymm2,%ymm2
     186:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
     18b:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
     18f:	c4 e2 2d 90 0c aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm1
     195:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
     19b:	c4 e3 05 4c 54 24 40 	vpblendvb %ymm2,0x40(%rsp),%ymm15,%ymm2
     1a2:	20 
     1a3:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm2,%ymm2        # 1ac <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x1ac>
     1aa:	ff ff 60 
     1ad:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
     1b1:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     1b6:	c4 62 5d 90 1c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm11
     1bc:	c5 ed 72 d0 18       	vpsrld $0x18,%ymm0,%ymm2
     1c1:	c5 7e 7f 74 24 20    	vmovdqu %ymm14,0x20(%rsp)
     1c7:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     1cb:	c5 ed db 6c 24 20    	vpand  0x20(%rsp),%ymm2,%ymm5
     1d1:	c5 a5 db e2          	vpand  %ymm2,%ymm11,%ymm4
     1d5:	c5 f5 db da          	vpand  %ymm2,%ymm1,%ymm3
     1d9:	c5 5d fa d3          	vpsubd %ymm3,%ymm4,%ymm10
     1dd:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     1e1:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
     1e6:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
     1ea:	c4 c1 2d 72 f2 10    	vpslld $0x10,%ymm10,%ymm10
     1f0:	c5 b5 db f4          	vpand  %ymm4,%ymm9,%ymm6
     1f4:	c5 d5 f5 f6          	vpmaddwd %ymm6,%ymm5,%ymm6
     1f8:	c5 ed db 2c 24       	vpand  (%rsp),%ymm2,%ymm5
     1fd:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     201:	c5 bd db ec          	vpand  %ymm4,%ymm8,%ymm5
     205:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     209:	c4 c1 55 eb ec       	vpor   %ymm12,%ymm5,%ymm5
     20e:	c4 c1 65 eb da       	vpor   %ymm10,%ymm3,%ymm3
     213:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
     218:	c5 e5 f5 dd          	vpmaddwd %ymm5,%ymm3,%ymm3
     21c:	c5 d5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm5
     221:	c5 3d 66 c5          	vpcmpgtd %ymm5,%ymm8,%ymm8
     225:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
     229:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     22d:	c5 fd 6f 70 20       	vmovdqa 0x20(%rax),%ymm6
     232:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
     236:	c4 e3 2d 4c c9 80    	vpblendvb %ymm8,%ymm1,%ymm10,%ymm1
     23c:	c5 7d 6f 00          	vmovdqa (%rax),%ymm8
     240:	c4 c3 75 4c cb 70    	vpblendvb %ymm7,%ymm11,%ymm1,%ymm1
     246:	c4 c1 79 6e f8       	vmovd  %r8d,%xmm7
     24b:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     24f:	c4 e3 75 4c 4c 24 20 	vpblendvb %ymm9,0x20(%rsp),%ymm1,%ymm1
     256:	90 
     257:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     25c:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
     260:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
     264:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     26b:	00 00 
     26d:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     272:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     276:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     27a:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
     27f:	c5 fd 6f 48 40       	vmovdqa 0x40(%rax),%ymm1
     284:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
     28b:	00 00 
     28d:	c4 42 35 90 14 88    	vpgatherdd %ymm9,(%r8,%ymm1,4),%ymm10
     293:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     297:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     29b:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
     2a0:	c4 42 75 90 0c b0    	vpgatherdd %ymm1,(%r8,%ymm6,4),%ymm9
     2a6:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     2aa:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     2ae:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     2b3:	c4 82 75 90 34 80    	vpgatherdd %ymm1,(%r8,%ymm8,4),%ymm6
     2b9:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     2be:	c4 c2 4d 3d d9       	vpmaxsd %ymm9,%ymm6,%ymm3
     2c3:	c5 35 66 de          	vpcmpgtd %ymm6,%ymm9,%ymm11
     2c7:	c4 42 4d 39 e1       	vpminsd %ymm9,%ymm6,%ymm12
     2cc:	c5 ad 66 cb          	vpcmpgtd %ymm3,%ymm10,%ymm1
     2d0:	c4 c2 1d 39 fa       	vpminsd %ymm10,%ymm12,%ymm7
     2d5:	c4 c2 65 3d da       	vpmaxsd %ymm10,%ymm3,%ymm3
     2da:	c4 41 1d 66 e2       	vpcmpgtd %ymm10,%ymm12,%ymm12
     2df:	c5 65 fe c7          	vpaddd %ymm7,%ymm3,%ymm8
     2e3:	c4 63 05 4c 5c 24 40 	vpblendvb %ymm11,0x40(%rsp),%ymm15,%ymm11
     2ea:	b0 
     2eb:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
     2f0:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     2f6:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm11,%ymm11        # 2ff <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x2ff>
     2fd:	ff ff 10 
     300:	c4 c1 4d fe c9       	vpaddd %ymm9,%ymm6,%ymm1
     305:	c4 c1 4d 66 f1       	vpcmpgtd %ymm9,%ymm6,%ymm6
     30a:	c5 25 fe 9c 24 80 00 	vpaddd 0x80(%rsp),%ymm11,%ymm11
     311:	00 00 
     313:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
     317:	c4 a2 0d 90 0c 9a    	vpgatherdd %ymm14,(%rdx,%ymm11,4),%ymm1
     31d:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     321:	c4 e3 05 4c 74 24 40 	vpblendvb %ymm6,0x40(%rsp),%ymm15,%ymm6
     328:	60 
     329:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 332 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x332>
     330:	ff ff c0 
     333:	c5 7e 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm12
     339:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
     33d:	c4 62 0d 90 24 b2    	vpgatherdd %ymm14,(%rdx,%ymm6,4),%ymm12
     343:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     348:	c5 8d 72 d1 08       	vpsrld $0x8,%ymm1,%ymm14
     34d:	c4 c1 35 72 d4 08    	vpsrld $0x8,%ymm12,%ymm9
     353:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
     35a:	00 00 
     35c:	c4 c1 35 72 d2 08    	vpsrld $0x8,%ymm10,%ymm9
     362:	c5 45 66 d5          	vpcmpgtd %ymm5,%ymm7,%ymm10
     366:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
     36a:	c5 7e 7f 8c 24 00 01 	vmovdqu %ymm9,0x100(%rsp)
     371:	00 00 
     373:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
     378:	c5 3d 66 cd          	vpcmpgtd %ymm5,%ymm8,%ymm9
     37c:	c5 25 db da          	vpand  %ymm2,%ymm11,%ymm11
     380:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     386:	c5 7e 7f 94 24 20 01 	vmovdqu %ymm10,0x120(%rsp)
     38d:	00 00 
     38f:	c5 65 66 d5          	vpcmpgtd %ymm5,%ymm3,%ymm10
     393:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     398:	4c 8b 41 40          	mov    0x40(%rcx),%r8
     39c:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     3a0:	c4 c1 65 eb d8       	vpor   %ymm8,%ymm3,%ymm3
     3a5:	c4 e3 4d 4c c9 a0    	vpblendvb %ymm10,%ymm1,%ymm6,%ymm1
     3ab:	c5 6d db 94 24 e0 00 	vpand  0xe0(%rsp),%ymm2,%ymm10
     3b2:	00 00 
     3b4:	c4 c1 6d db f6       	vpand  %ymm14,%ymm2,%ymm6
     3b9:	c4 c3 75 4c cc 90    	vpblendvb %ymm9,%ymm12,%ymm1,%ymm1
     3bf:	c5 7e 6f a4 24 20 01 	vmovdqu 0x120(%rsp),%ymm12
     3c6:	00 00 
     3c8:	c5 6d db 8c 24 00 01 	vpand  0x100(%rsp),%ymm2,%ymm9
     3cf:	00 00 
     3d1:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     3d5:	c4 e3 75 4c 4c 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm1,%ymm1
     3dc:	c0 
     3dd:	c4 41 35 fa ca       	vpsubd %ymm10,%ymm9,%ymm9
     3e2:	c5 2d fa e6          	vpsubd %ymm6,%ymm10,%ymm12
     3e6:	c5 7d 6f 50 40       	vmovdqa 0x40(%rax),%ymm10
     3eb:	c5 35 db cc          	vpand  %ymm4,%ymm9,%ymm9
     3ef:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     3f4:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
     3f9:	c5 b5 f5 ff          	vpmaddwd %ymm7,%ymm9,%ymm7
     3fd:	c4 02 0d 90 0c 90    	vpgatherdd %ymm14,(%r8,%ymm10,4),%ymm9
     403:	4c 8b 41 38          	mov    0x38(%rcx),%r8
     407:	c5 7d 6f 50 20       	vmovdqa 0x20(%rax),%ymm10
     40c:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     410:	48 8b 49 30          	mov    0x30(%rcx),%rcx
     414:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
     418:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
     41c:	c4 02 0d 90 04 90    	vpgatherdd %ymm14,(%r8,%ymm10,4),%ymm8
     422:	c4 c1 1d 72 f4 10    	vpslld $0x10,%ymm12,%ymm12
     428:	c5 7d 6f 10          	vmovdqa (%rax),%ymm10
     42c:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     430:	c4 c1 4d eb f4       	vpor   %ymm12,%ymm6,%ymm6
     435:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     43a:	c4 41 3d db c5       	vpand  %ymm13,%ymm8,%ymm8
     43f:	c5 f5 fe 8c 24 a0 00 	vpaddd 0xa0(%rsp),%ymm1,%ymm1
     446:	00 00 
     448:	c5 cd f5 db          	vpmaddwd %ymm3,%ymm6,%ymm3
     44c:	c4 a2 0d 90 34 91    	vpgatherdd %ymm14,(%rcx,%ymm10,4),%ymm6
     452:	c4 c1 4d db f5       	vpand  %ymm13,%ymm6,%ymm6
     457:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     45b:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
     460:	c5 3d 66 d6          	vpcmpgtd %ymm6,%ymm8,%ymm10
     464:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     468:	c4 c2 4d 3d d8       	vpmaxsd %ymm8,%ymm6,%ymm3
     46d:	c5 b5 66 fb          	vpcmpgtd %ymm3,%ymm9,%ymm7
     471:	c4 42 4d 39 e0       	vpminsd %ymm8,%ymm6,%ymm12
     476:	c4 41 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm13
     47b:	c4 c1 4d 66 f0       	vpcmpgtd %ymm8,%ymm6,%ymm6
     480:	c4 42 1d 39 d9       	vpminsd %ymm9,%ymm12,%ymm11
     485:	c4 c2 65 3d d9       	vpmaxsd %ymm9,%ymm3,%ymm3
     48a:	c4 41 1d 66 e1       	vpcmpgtd %ymm9,%ymm12,%ymm12
     48f:	c4 63 05 4c 54 24 40 	vpblendvb %ymm10,0x40(%rsp),%ymm15,%ymm10
     496:	a0 
     497:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     49b:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm10,%ymm10        # 4a4 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x4a4>
     4a2:	ff ff 70 
     4a5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     4aa:	c4 c1 65 fe fb       	vpaddd %ymm11,%ymm3,%ymm7
     4af:	c4 e3 05 4c 74 24 40 	vpblendvb %ymm6,0x40(%rsp),%ymm15,%ymm6
     4b6:	60 
     4b7:	c5 2d fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm10,%ymm10
     4be:	00 00 
     4c0:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     4c4:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
     4c9:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm6,%ymm6        # 4d2 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)+0x4d2>
     4d0:	ff ff c0 
     4d3:	c5 7e 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm12
     4d9:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     4de:	c4 22 0d 90 2c 92    	vpgatherdd %ymm14,(%rdx,%ymm10,4),%ymm13
     4e4:	c5 45 66 f5          	vpcmpgtd %ymm5,%ymm7,%ymm14
     4e8:	c4 c1 35 72 d7 10    	vpsrld $0x10,%ymm15,%ymm9
     4ee:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
     4f3:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
     4f7:	c5 25 66 e5          	vpcmpgtd %ymm5,%ymm11,%ymm12
     4fb:	c5 e5 66 ed          	vpcmpgtd %ymm5,%ymm3,%ymm5
     4ff:	c4 62 7d 90 14 b2    	vpgatherdd %ymm0,(%rdx,%ymm6,4),%ymm10
     505:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     50b:	c4 c1 7d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm0
     511:	c4 c1 3d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm8
     517:	c5 35 db ca          	vpand  %ymm2,%ymm9,%ymm9
     51b:	c5 3d db c2          	vpand  %ymm2,%ymm8,%ymm8
     51f:	c5 fd db c2          	vpand  %ymm2,%ymm0,%ymm0
     523:	c5 e5 db dc          	vpand  %ymm4,%ymm3,%ymm3
     527:	c4 c3 05 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm15,%ymm5
     52d:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     532:	c5 25 db dc          	vpand  %ymm4,%ymm11,%ymm11
     536:	c4 c3 55 4c ea e0    	vpblendvb %ymm14,%ymm10,%ymm5,%ymm5
     53c:	c5 cd db f2          	vpand  %ymm2,%ymm6,%ymm6
     540:	c5 3d fa d0          	vpsubd %ymm0,%ymm8,%ymm10
     544:	c4 e3 55 4c 6c 24 20 	vpblendvb %ymm12,0x20(%rsp),%ymm5,%ymm5
     54b:	c0 
     54c:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     551:	c4 c1 4d fa f0       	vpsubd %ymm8,%ymm6,%ymm6
     556:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     55b:	c4 c1 2d 72 f2 10    	vpslld $0x10,%ymm10,%ymm10
     561:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
     565:	c5 d5 db ea          	vpand  %ymm2,%ymm5,%ymm5
     569:	c5 e5 eb df          	vpor   %ymm7,%ymm3,%ymm3
     56d:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
     571:	c4 c1 7d eb c2       	vpor   %ymm10,%ymm0,%ymm0
     576:	c5 d5 72 f5 10       	vpslld $0x10,%ymm5,%ymm5
     57b:	c4 c1 4d f5 f3       	vpmaddwd %ymm11,%ymm6,%ymm6
     580:	c5 d5 fe ac 24 a0 00 	vpaddd 0xa0(%rsp),%ymm5,%ymm5
     587:	00 00 
     589:	c5 fd f5 c3          	vpmaddwd %ymm3,%ymm0,%ymm0
     58d:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
     594:	00 00 
     596:	c5 fd 7f 48 20       	vmovdqa %ymm1,0x20(%rax)
     59b:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     59f:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     5a3:	c5 fd 7f 18          	vmovdqa %ymm3,(%rax)
     5a7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     5ac:	c5 fd 7f 40 40       	vmovdqa %ymm0,0x40(%rax)
     5b1:	c5 f8 77             	vzeroupper
     5b4:	c5 f8 28 b4 24 40 01 	vmovaps 0x140(%rsp),%xmm6
     5bb:	00 00 
     5bd:	c5 f8 28 bc 24 50 01 	vmovaps 0x150(%rsp),%xmm7
     5c4:	00 00 
     5c6:	c5 78 28 84 24 60 01 	vmovaps 0x160(%rsp),%xmm8
     5cd:	00 00 
     5cf:	c5 78 28 8c 24 70 01 	vmovaps 0x170(%rsp),%xmm9
     5d6:	00 00 
     5d8:	c5 78 28 94 24 80 01 	vmovaps 0x180(%rsp),%xmm10
     5df:	00 00 
     5e1:	c5 78 28 9c 24 90 01 	vmovaps 0x190(%rsp),%xmm11
     5e8:	00 00 
     5ea:	c5 78 28 a4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm12
     5f1:	00 00 
     5f3:	c5 78 28 ac 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm13
     5fa:	00 00 
     5fc:	c5 78 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm14
     603:	00 00 
     605:	c5 78 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm15
     60c:	00 00 
     60e:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
     615:	c3                   	ret
     616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     61d:	00 00 00 

0000000000000620 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     620:	41 55                	push   %r13
     622:	41 54                	push   %r12
     624:	55                   	push   %rbp
     625:	57                   	push   %rdi
     626:	56                   	push   %rsi
     627:	53                   	push   %rbx
     628:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
     62f:	c5 f8 29 b4 24 f0 01 	vmovaps %xmm6,0x1f0(%rsp)
     636:	00 00 
     638:	c5 f8 29 bc 24 00 02 	vmovaps %xmm7,0x200(%rsp)
     63f:	00 00 
     641:	c5 78 29 84 24 10 02 	vmovaps %xmm8,0x210(%rsp)
     648:	00 00 
     64a:	c5 78 29 8c 24 20 02 	vmovaps %xmm9,0x220(%rsp)
     651:	00 00 
     653:	c5 78 29 94 24 30 02 	vmovaps %xmm10,0x230(%rsp)
     65a:	00 00 
     65c:	c5 78 29 9c 24 40 02 	vmovaps %xmm11,0x240(%rsp)
     663:	00 00 
     665:	c5 78 29 a4 24 50 02 	vmovaps %xmm12,0x250(%rsp)
     66c:	00 00 
     66e:	c5 78 29 ac 24 60 02 	vmovaps %xmm13,0x260(%rsp)
     675:	00 00 
     677:	c5 78 29 b4 24 70 02 	vmovaps %xmm14,0x270(%rsp)
     67e:	00 00 
     680:	c5 78 29 bc 24 80 02 	vmovaps %xmm15,0x280(%rsp)
     687:	00 00 
     689:	4c 8d 9c 24 3f 01 00 	lea    0x13f(%rsp),%r11
     690:	00 
     691:	48 89 cd             	mov    %rcx,%rbp
     694:	48 89 d6             	mov    %rdx,%rsi
     697:	4d 89 c4             	mov    %r8,%r12
     69a:	49 83 e3 e0          	and    $0xffffffffffffffe0,%r11
     69e:	48 83 fa 04          	cmp    $0x4,%rdx
     6a2:	0f 84 0b 04 00 00    	je     ab3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x493>
     6a8:	4d 85 c9             	test   %r9,%r9
     6ab:	0f 84 32 0e 00 00    	je     14e3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xec3>
     6b1:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # 719 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf9>
     6b8:	00 
     6b9:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
     6bd:	45 31 ed             	xor    %r13d,%r13d
     6c0:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     6c5:	48 c1 ef 03          	shr    $0x3,%rdi
     6c9:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     6d0:	00 00 
     6d2:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 75a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13a>
     6d9:	00 
     6da:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     6e1:	00 00 
     6e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     6e8:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     6ee:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     6f5:	c4 c1 6d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm2
     6fb:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     701:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     707:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
     70e:	00 00 00 
     711:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
     716:	c5 fd db ca          	vpand  %ymm2,%ymm0,%ymm1
     71a:	c5 d5 db ea          	vpand  %ymm2,%ymm5,%ymm5
     71e:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     723:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
     727:	48 85 f6             	test   %rsi,%rsi
     72a:	0f 84 2c 03 00 00    	je     a5c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x43c>
     730:	c4 c1 45 72 d7 1f    	vpsrld $0x1f,%ymm15,%ymm7
     736:	c5 7d 6f d9          	vmovdqa %ymm1,%ymm11
     73a:	49 89 ea             	mov    %rbp,%r10
     73d:	31 db                	xor    %ebx,%ebx
     73f:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     745:	e9 c2 02 00 00       	jmp    a0c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ec>
     74a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     750:	49 8b 02             	mov    (%r10),%rax
     753:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     757:	41 8b 4a 54          	mov    0x54(%r10),%ecx
     75b:	48 ff c3             	inc    %rbx
     75e:	41 8b 52 50          	mov    0x50(%r10),%edx
     762:	49 83 c2 60          	add    $0x60,%r10
     766:	c4 a2 65 90 14 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm2
     76c:	49 8b 42 a8          	mov    -0x58(%r10),%rax
     770:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     774:	c5 79 6e e1          	vmovd  %ecx,%xmm12
     778:	c5 79 6e da          	vmovd  %edx,%xmm11
     77c:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     781:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     785:	c4 e2 65 90 3c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm7
     78b:	49 8b 42 b0          	mov    -0x50(%r10),%rax
     78f:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     793:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
     798:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
     79d:	c5 f9 6e f2          	vmovd  %edx,%xmm6
     7a1:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 7c9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1a9>
     7a8:	00 
     7a9:	c4 62 65 90 14 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm10
     7af:	c5 fd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm0
     7b4:	49 8b 42 e8          	mov    -0x18(%r10),%rax
     7b8:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 7e0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1c0>
     7bf:	00 
     7c0:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     7c5:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     7ca:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     7cf:	c4 c1 65 72 d2 11    	vpsrld $0x11,%ymm10,%ymm3
     7d5:	c5 2d db 15 20 00 00 	vpand  0x20(%rip),%ymm10,%ymm10        # 7fd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1dd>
     7dc:	00 
     7dd:	c4 62 6d 39 ef       	vpminsd %ymm7,%ymm2,%ymm13
     7e2:	c4 c2 15 39 ea       	vpminsd %ymm10,%ymm13,%ymm5
     7e7:	c4 41 15 66 ea       	vpcmpgtd %ymm10,%ymm13,%ymm13
     7ec:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     7f0:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
     7f4:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     7f8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7fc:	c4 62 65 90 0c 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm9
     802:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
     806:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     80a:	c4 62 65 90 34 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm14
     810:	c4 e2 6d 3d df       	vpmaxsd %ymm7,%ymm2,%ymm3
     815:	c4 c3 25 4c cc 10    	vpblendvb %ymm1,%ymm12,%ymm11,%ymm1
     81b:	c5 ad 66 e3          	vpcmpgtd %ymm3,%ymm10,%ymm4
     81f:	c4 c2 65 3d da       	vpmaxsd %ymm10,%ymm3,%ymm3
     824:	c5 65 fe c5          	vpaddd %ymm5,%ymm3,%ymm8
     828:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
     82d:	c4 e3 75 4c 4c 24 40 	vpblendvb %ymm4,0x40(%rsp),%ymm1,%ymm1
     834:	40 
     835:	c5 ed fe e7          	vpaddd %ymm7,%ymm2,%ymm4
     839:	c5 ed 66 d7          	vpcmpgtd %ymm7,%ymm2,%ymm2
     83d:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     841:	c5 fd fe e1          	vpaddd %ymm1,%ymm0,%ymm4
     845:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
     849:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
     84f:	c4 e2 7d 90 0c a0    	vpgatherdd %ymm0,(%rax,%ymm4,4),%ymm1
     855:	c4 c3 25 4c c4 20    	vpblendvb %ymm2,%ymm12,%ymm11,%ymm0
     85b:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
     85f:	c4 e3 7d 4c 44 24 40 	vpblendvb %ymm13,0x40(%rsp),%ymm0,%ymm0
     866:	d0 
     867:	c5 cd fa f0          	vpsubd %ymm0,%ymm6,%ymm6
     86b:	c4 c1 7d 72 d7 11    	vpsrld $0x11,%ymm15,%ymm0
     871:	c4 e2 6d 90 3c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm7
     877:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
     87b:	b8 00 80 00 00       	mov    $0x8000,%eax
     880:	c5 d5 66 d0          	vpcmpgtd %ymm0,%ymm5,%ymm2
     884:	c5 e5 66 c0          	vpcmpgtd %ymm0,%ymm3,%ymm0
     888:	c4 c1 3d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm8
     88e:	c5 9d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm12
     893:	c4 c1 65 db d8       	vpand  %ymm8,%ymm3,%ymm3
     898:	c4 41 55 db e8       	vpand  %ymm8,%ymm5,%ymm13
     89d:	c4 e3 35 4c c1 00    	vpblendvb %ymm0,%ymm1,%ymm9,%ymm0
     8a3:	c4 c1 65 eb da       	vpor   %ymm10,%ymm3,%ymm3
     8a8:	c5 7e 7f 6c 24 20    	vmovdqu %ymm13,0x20(%rsp)
     8ae:	c4 e3 7d 4c c7 40    	vpblendvb %ymm4,%ymm7,%ymm0,%ymm0
     8b4:	c4 c3 7d 4c c6 20    	vpblendvb %ymm2,%ymm14,%ymm0,%ymm0
     8ba:	c4 c1 6d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm2
     8c0:	c5 45 db da          	vpand  %ymm2,%ymm7,%ymm11
     8c4:	c5 f5 db e2          	vpand  %ymm2,%ymm1,%ymm4
     8c8:	c5 35 db d2          	vpand  %ymm2,%ymm9,%ymm10
     8cc:	c5 8d db ea          	vpand  %ymm2,%ymm14,%ymm5
     8d0:	c5 a5 fa f4          	vpsubd %ymm4,%ymm11,%ymm6
     8d4:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     8d9:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     8de:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
     8e3:	c4 c1 5d db e0       	vpand  %ymm8,%ymm4,%ymm4
     8e8:	c4 c1 55 db e8       	vpand  %ymm8,%ymm5,%ymm5
     8ed:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
     8f1:	c5 6d db d8          	vpand  %ymm0,%ymm2,%ymm11
     8f5:	c5 d5 f5 6c 24 20    	vpmaddwd 0x20(%rsp),%ymm5,%ymm5
     8fb:	c5 79 6e d0          	vmovd  %eax,%xmm10
     8ff:	c5 dd f5 e3          	vpmaddwd %ymm3,%ymm4,%ymm4
     903:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     908:	c4 c1 25 72 f3 10    	vpslld $0x10,%ymm11,%ymm11
     90e:	c5 1d db e2          	vpand  %ymm2,%ymm12,%ymm12
     912:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     916:	c4 c1 4d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm6
     91c:	c4 41 25 fe da       	vpaddd %ymm10,%ymm11,%ymm11
     921:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
     927:	c4 c1 4d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm6
     92d:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
     932:	c5 25 fe dc          	vpaddd %ymm4,%ymm11,%ymm11
     936:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     93b:	c5 cd db f2          	vpand  %ymm2,%ymm6,%ymm6
     93f:	c5 d5 db ea          	vpand  %ymm2,%ymm5,%ymm5
     943:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
     947:	c5 d5 72 f5 10       	vpslld $0x10,%ymm5,%ymm5
     94c:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     951:	c5 1d fa ec          	vpsubd %ymm4,%ymm12,%ymm13
     955:	c5 6d db 64 24 60    	vpand  0x60(%rsp),%ymm2,%ymm12
     95b:	c4 c1 4d db f0       	vpand  %ymm8,%ymm6,%ymm6
     960:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
     966:	c5 cd f5 74 24 20    	vpmaddwd 0x20(%rsp),%ymm6,%ymm6
     96c:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
     971:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     977:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     97c:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
     981:	c4 c1 5d db e0       	vpand  %ymm8,%ymm4,%ymm4
     986:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     98b:	c5 f5 db ca          	vpand  %ymm2,%ymm1,%ymm1
     98f:	c4 c1 5d eb e5       	vpor   %ymm13,%ymm4,%ymm4
     994:	c5 c5 db fa          	vpand  %ymm2,%ymm7,%ymm7
     998:	c5 35 db ca          	vpand  %ymm2,%ymm9,%ymm9
     99c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     9a1:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
     9a7:	c5 dd f5 e3          	vpmaddwd %ymm3,%ymm4,%ymm4
     9ab:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     9af:	c5 c5 fa f1          	vpsubd %ymm1,%ymm7,%ymm6
     9b3:	c5 fd db c2          	vpand  %ymm2,%ymm0,%ymm0
     9b7:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     9bb:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     9c1:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     9c6:	c5 dd db e2          	vpand  %ymm2,%ymm4,%ymm4
     9ca:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
     9cf:	c4 c1 75 db c8       	vpand  %ymm8,%ymm1,%ymm1
     9d4:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
     9d8:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     9dd:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
     9e1:	c4 c1 5d db e0       	vpand  %ymm8,%ymm4,%ymm4
     9e6:	c5 f5 f5 cb          	vpmaddwd %ymm3,%ymm1,%ymm1
     9ea:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
     9ef:	c5 dd f5 64 24 20    	vpmaddwd 0x20(%rsp),%ymm4,%ymm4
     9f5:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     9fa:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     9fe:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     a02:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     a07:	48 39 de             	cmp    %rbx,%rsi
     a0a:	74 4c                	je     a58 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x438>
     a0c:	41 80 7a 58 00       	cmpb   $0x0,0x58(%r10)
     a11:	0f 85 39 fd ff ff    	jne    750 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
     a17:	c4 41 7d 7f 1b       	vmovdqa %ymm11,(%r11)
     a1c:	4c 89 d1             	mov    %r10,%rcx
     a1f:	4c 89 da             	mov    %r11,%rdx
     a22:	c4 c1 7d 7f 6b 20    	vmovdqa %ymm5,0x20(%r11)
     a28:	c4 c1 7d 7f 43 40    	vmovdqa %ymm0,0x40(%r11)
     a2e:	c5 f8 77             	vzeroupper
     a31:	e8 ca f5 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     a36:	48 ff c3             	inc    %rbx
     a39:	c4 41 7d 6f 1b       	vmovdqa (%r11),%ymm11
     a3e:	c4 c1 7d 6f 6b 20    	vmovdqa 0x20(%r11),%ymm5
     a44:	c4 c1 7d 6f 43 40    	vmovdqa 0x40(%r11),%ymm0
     a4a:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     a4f:	49 83 c2 60          	add    $0x60,%r10
     a53:	48 39 de             	cmp    %rbx,%rsi
     a56:	75 b4                	jne    a0c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3ec>
     a58:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
     a5c:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     a61:	c5 d5 72 f5 08       	vpslld $0x8,%ymm5,%ymm5
     a66:	49 83 c4 18          	add    $0x18,%r12
     a6a:	c5 d5 eb c0          	vpor   %ymm0,%ymm5,%ymm0
     a6e:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     a72:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
     a79:	00 00 00 
     a7c:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     a80:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     a86:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     a8b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     a90:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     a94:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
     a9b:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
     aa2:	4c 39 ef             	cmp    %r13,%rdi
     aa5:	0f 84 35 0a 00 00    	je     14e0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xec0>
     aab:	49 ff c5             	inc    %r13
     aae:	e9 35 fc ff ff       	jmp    6e8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc8>
     ab3:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     ab7:	0f 85 eb fb ff ff    	jne    6a8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     abd:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     ac4:	0f 84 de fb ff ff    	je     6a8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     aca:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     ad1:	0f 84 d1 fb ff ff    	je     6a8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     ad7:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     ade:	0f 84 c4 fb ff ff    	je     6a8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x88>
     ae4:	4d 85 c9             	test   %r9,%r9
     ae7:	0f 84 f6 09 00 00    	je     14e3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xec3>
     aed:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # b55 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x535>
     af4:	00 
     af5:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     af9:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
     afd:	45 31 d2             	xor    %r10d,%r10d
     b00:	48 c1 e8 03          	shr    $0x3,%rax
     b04:	c5 9d 72 d6 18       	vpsrld $0x18,%ymm6,%ymm12
     b09:	49 8d 73 60          	lea    0x60(%r11),%rsi
     b0d:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     b14:	00 00 
     b16:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # b9e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x57e>
     b1d:	00 
     b1e:	48 8d 58 01          	lea    0x1(%rax),%rbx
     b22:	b8 00 80 00 00       	mov    $0x8000,%eax
     b27:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     b2e:	00 00 
     b30:	c5 f9 6e f8          	vmovd  %eax,%xmm7
     b34:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     b39:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
     b3f:	c4 c1 7a 6f 04 24    	vmovdqu (%r12),%xmm0
     b45:	c4 c1 7a 7e 4c 24 10 	vmovq  0x10(%r12),%xmm1
     b4c:	48 89 f2             	mov    %rsi,%rdx
     b4f:	48 89 e9             	mov    %rbp,%rcx
     b52:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     b58:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     b5e:	c4 e2 7d 00 84 24 80 	vpshufb 0x80(%rsp),%ymm0,%ymm0
     b65:	00 00 00 
     b68:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     b6d:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     b72:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
     b77:	c4 c1 7d 7f 43 60    	vmovdqa %ymm0,0x60(%r11)
     b7d:	c4 c1 75 db c4       	vpand  %ymm12,%ymm1,%ymm0
     b82:	c4 c1 7d 7f 83 80 00 	vmovdqa %ymm0,0x80(%r11)
     b89:	00 00 
     b8b:	c4 c1 7d 7f 93 a0 00 	vmovdqa %ymm2,0xa0(%r11)
     b92:	00 00 
     b94:	c5 f8 77             	vzeroupper
     b97:	e8 64 f4 ff ff       	call   0 <void jshc_channel::(anonymous namespace)::transform<false>(jshc_channel::View const&, jshc_channel::(anonymous namespace)::Rgb&)>
     b9c:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
     ba0:	48 8b 45 60          	mov    0x60(%rbp),%rax
     ba4:	c4 c1 7d 6f 43 60    	vmovdqa 0x60(%r11),%ymm0
     baa:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     bae:	8b 8d b4 00 00 00    	mov    0xb4(%rbp),%ecx
     bb4:	c5 d5 72 d6 0f       	vpsrld $0xf,%ymm6,%ymm5
     bb9:	8b 95 b0 00 00 00    	mov    0xb0(%rbp),%edx
     bbf:	49 ff c2             	inc    %r10
     bc2:	49 83 c4 18          	add    $0x18,%r12
     bc6:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
     bcc:	48 8b 45 68          	mov    0x68(%rbp),%rax
     bd0:	c4 c1 7d 6f 83 80 00 	vmovdqa 0x80(%r11),%ymm0
     bd7:	00 00 
     bd9:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     bdd:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     be1:	c5 ed 72 d1 11       	vpsrld $0x11,%ymm1,%ymm2
     be6:	c5 79 6e da          	vmovd  %edx,%xmm11
     bea:	c4 62 45 90 04 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm8
     bf0:	48 8b 45 70          	mov    0x70(%rbp),%rax
     bf4:	c4 c1 7d 6f 83 a0 00 	vmovdqa 0xa0(%r11),%ymm0
     bfb:	00 00 
     bfd:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     c01:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     c06:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
     c0b:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     c0f:	c4 62 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm9
     c15:	c4 c1 7d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm0
     c1b:	48 8b 85 a8 00 00 00 	mov    0xa8(%rbp),%rax
     c22:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     c26:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     c2b:	c4 c2 7d 40 c6       	vpmulld %ymm14,%ymm0,%ymm0
     c30:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
     c34:	c4 c1 65 72 d1 11    	vpsrld $0x11,%ymm9,%ymm3
     c3a:	c5 f5 db cd          	vpand  %ymm5,%ymm1,%ymm1
     c3e:	c5 35 db cd          	vpand  %ymm5,%ymm9,%ymm9
     c42:	c4 41 75 fe d0       	vpaddd %ymm8,%ymm1,%ymm10
     c47:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     c4b:	c5 f9 6e d2          	vmovd  %edx,%xmm2
     c4f:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     c53:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     c58:	c4 e2 45 90 24 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
     c5e:	c5 ed fe f8          	vpaddd %ymm0,%ymm2,%ymm7
     c62:	c5 fd 6f d6          	vmovdqa %ymm6,%ymm2
     c66:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     c6c:	c4 e2 6d 90 1c b8    	vpgatherdd %ymm2,(%rax,%ymm7,4),%ymm3
     c72:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
     c76:	c4 c2 75 3d f8       	vpmaxsd %ymm8,%ymm1,%ymm7
     c7b:	c5 35 66 ef          	vpcmpgtd %ymm7,%ymm9,%ymm13
     c7f:	c4 42 45 3d e1       	vpmaxsd %ymm9,%ymm7,%ymm12
     c84:	c4 c3 25 4c d6 20    	vpblendvb %ymm2,%ymm14,%ymm11,%ymm2
     c8a:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm2,%ymm2        # c93 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x673>
     c91:	ff ff d0 
     c94:	c4 42 75 39 e8       	vpminsd %ymm8,%ymm1,%ymm13
     c99:	c4 42 15 39 f9       	vpminsd %ymm9,%ymm13,%ymm15
     c9e:	c4 c1 75 66 c8       	vpcmpgtd %ymm8,%ymm1,%ymm1
     ca3:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     ca7:	c4 c1 05 fe fc       	vpaddd %ymm12,%ymm15,%ymm7
     cac:	c4 41 15 66 e9       	vpcmpgtd %ymm9,%ymm13,%ymm13
     cb1:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     cb5:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
     cba:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
     cbe:	c4 e2 2d 90 14 80    	vpgatherdd %ymm10,(%rax,%ymm0,4),%ymm2
     cc4:	c4 c3 25 4c c6 10    	vpblendvb %ymm1,%ymm14,%ymm11,%ymm0
     cca:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
     cd0:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # cd9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6b9>
     cd7:	ff ff d0 
     cda:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
     cde:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
     ce2:	c4 62 75 90 1c 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm11
     ce8:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
     ced:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     cf3:	c5 1d 66 c0          	vpcmpgtd %ymm0,%ymm12,%ymm8
     cf7:	c5 45 66 c8          	vpcmpgtd %ymm0,%ymm7,%ymm9
     cfb:	c5 7d 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm12        # d43 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x723>
     d02:	00 
     d03:	c5 85 66 c8          	vpcmpgtd %ymm0,%ymm15,%ymm1
     d07:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
     d0c:	c4 41 25 db ec       	vpand  %ymm12,%ymm11,%ymm13
     d11:	c4 41 65 db f4       	vpand  %ymm12,%ymm3,%ymm14
     d16:	c4 63 5d 4c c2 80    	vpblendvb %ymm8,%ymm2,%ymm4,%ymm8
     d1c:	c4 43 3d 4c c3 90    	vpblendvb %ymm9,%ymm11,%ymm8,%ymm8
     d22:	c4 41 6d db cc       	vpand  %ymm12,%ymm2,%ymm9
     d27:	c4 63 3d 4c c3 10    	vpblendvb %ymm1,%ymm3,%ymm8,%ymm8
     d2d:	c4 c1 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm1
     d32:	c4 41 0d fa ed       	vpsubd %ymm13,%ymm14,%ymm13
     d37:	c5 ad 72 f1 10       	vpslld $0x10,%ymm1,%ymm10
     d3c:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
     d41:	c5 05 db f9          	vpand  %ymm1,%ymm15,%ymm15
     d45:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     d49:	c4 41 15 f5 f7       	vpmaddwd %ymm15,%ymm13,%ymm14
     d4e:	c5 75 db 6c 24 40    	vpand  0x40(%rsp),%ymm1,%ymm13
     d54:	c5 15 eb ef          	vpor   %ymm7,%ymm13,%ymm13
     d58:	c4 c1 5d db fc       	vpand  %ymm12,%ymm4,%ymm7
     d5d:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     d61:	c5 7e 7f 6c 24 40    	vmovdqu %ymm13,0x40(%rsp)
     d67:	c4 c1 15 72 d0 08    	vpsrld $0x8,%ymm8,%ymm13
     d6d:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     d71:	c4 c1 45 eb fa       	vpor   %ymm10,%ymm7,%ymm7
     d76:	c5 45 f5 4c 24 40    	vpmaddwd 0x40(%rsp),%ymm7,%ymm9
     d7c:	c4 c1 1d db f8       	vpand  %ymm8,%ymm12,%ymm7
     d81:	c5 7e 7f ac 24 c0 00 	vmovdqu %ymm13,0xc0(%rsp)
     d88:	00 00 
     d8a:	48 8b 85 c0 00 00 00 	mov    0xc0(%rbp),%rax
     d91:	c5 c5 72 f7 10       	vpslld $0x10,%ymm7,%ymm7
     d96:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     d9c:	8b 8d 14 01 00 00    	mov    0x114(%rbp),%ecx
     da2:	8b 95 10 01 00 00    	mov    0x110(%rbp),%edx
     da8:	c5 c5 fe 7c 24 20    	vpaddd 0x20(%rsp),%ymm7,%ymm7
     dae:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
     db3:	c4 c1 0d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm14
     db9:	c4 41 0d db f4       	vpand  %ymm12,%ymm14,%ymm14
     dbe:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
     dc4:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     dc9:	c5 b5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm9
     dce:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
     dd3:	c5 ad 72 d7 10       	vpsrld $0x10,%ymm7,%ymm10
     dd8:	c5 c5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm7
     ddd:	c4 41 35 db cc       	vpand  %ymm12,%ymm9,%ymm9
     de2:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     de8:	c5 c5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm7
     ded:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     df2:	c4 41 35 fa ce       	vpsubd %ymm14,%ymm9,%ymm9
     df7:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
     dfc:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
     e00:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
     e05:	c5 0d fa ef          	vpsubd %ymm7,%ymm14,%ymm13
     e09:	c5 1d db 74 24 60    	vpand  0x60(%rsp),%ymm12,%ymm14
     e0f:	c4 41 35 f5 cf       	vpmaddwd %ymm15,%ymm9,%ymm9
     e14:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
     e1a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e1f:	c4 c1 45 fa fe       	vpsubd %ymm14,%ymm7,%ymm7
     e24:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     e29:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
     e2e:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     e34:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     e38:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
     e3d:	c4 c1 45 eb fd       	vpor   %ymm13,%ymm7,%ymm7
     e42:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     e47:	c5 1d db ac 24 c0 00 	vpand  0xc0(%rsp),%ymm12,%ymm13
     e4e:	00 00 
     e50:	c5 c5 f5 7c 24 40    	vpmaddwd 0x40(%rsp),%ymm7,%ymm7
     e56:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
     e5a:	c4 c1 65 f5 df       	vpmaddwd %ymm15,%ymm3,%ymm3
     e5f:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
     e65:	c5 79 6e f9          	vmovd  %ecx,%xmm15
     e69:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     e6e:	c5 25 fa ca          	vpsubd %ymm2,%ymm11,%ymm9
     e72:	c5 79 6e da          	vmovd  %edx,%xmm11
     e76:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     e7a:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
     e80:	c4 c1 3d db e4       	vpand  %ymm12,%ymm8,%ymm4
     e85:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     e89:	c5 dd 72 f4 10       	vpslld $0x10,%ymm4,%ymm4
     e8e:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
     e93:	c4 c1 6d eb d1       	vpor   %ymm9,%ymm2,%ymm2
     e98:	c4 c1 5d fe e6       	vpaddd %ymm14,%ymm4,%ymm4
     e9d:	c5 95 fe ff          	vpaddd %ymm7,%ymm13,%ymm7
     ea1:	c5 ed f5 54 24 40    	vpmaddwd 0x40(%rsp),%ymm2,%ymm2
     ea7:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     eac:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
     eb1:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
     eb6:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     eba:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     ebe:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     ec2:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
     ec6:	c4 a2 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm10,4),%ymm4
     ecc:	48 8b 85 c8 00 00 00 	mov    0xc8(%rbp),%rax
     ed3:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
     ed7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     edc:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
     ee0:	c4 62 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm8
     ee6:	48 8b 85 d0 00 00 00 	mov    0xd0(%rbp),%rax
     eed:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
     ef1:	c4 c1 65 72 d0 11    	vpsrld $0x11,%ymm8,%ymm3
     ef7:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
     efb:	c4 62 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm9
     f01:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
     f06:	48 8b 85 08 01 00 00 	mov    0x108(%rbp),%rax
     f0d:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
     f13:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     f18:	c4 c2 65 40 df       	vpmulld %ymm15,%ymm3,%ymm3
     f1d:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
     f21:	c4 c1 45 72 d1 11    	vpsrld $0x11,%ymm9,%ymm7
     f27:	c5 3d 66 dc          	vpcmpgtd %ymm4,%ymm8,%ymm11
     f2b:	c5 35 db cd          	vpand  %ymm5,%ymm9,%ymm9
     f2f:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     f33:	c5 fd 6f d6          	vmovdqa %ymm6,%ymm2
     f37:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     f3b:	c4 e2 6d 90 3c 98    	vpgatherdd %ymm2,(%rax,%ymm3,4),%ymm7
     f41:	c5 f9 6e d2          	vmovd  %edx,%xmm2
     f45:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     f4a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     f4e:	c5 fe 7f 94 24 c0 00 	vmovdqu %ymm2,0xc0(%rsp)
     f55:	00 00 
     f57:	c5 7d 6f ea          	vmovdqa %ymm2,%ymm13
     f5b:	c4 a2 2d 90 14 a8    	vpgatherdd %ymm10,(%rax,%ymm13,4),%ymm2
     f61:	c4 42 5d 3d e8       	vpmaxsd %ymm8,%ymm4,%ymm13
     f66:	c5 7e 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm10
     f6c:	c5 7e 7f bc 24 e0 00 	vmovdqu %ymm15,0xe0(%rsp)
     f73:	00 00 
     f75:	c4 41 35 66 f5       	vpcmpgtd %ymm13,%ymm9,%ymm14
     f7a:	c4 42 15 3d f9       	vpmaxsd %ymm9,%ymm13,%ymm15
     f7f:	c4 42 5d 39 e8       	vpminsd %ymm8,%ymm4,%ymm13
     f84:	c4 63 2d 4c 9c 24 e0 	vpblendvb %ymm11,0xe0(%rsp),%ymm10,%ymm11
     f8b:	00 00 00 b0 
     f8f:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
     f93:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm11,%ymm11        # f9c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x97c>
     f9a:	ff ff e0 
     f9d:	c4 42 15 39 f1       	vpminsd %ymm9,%ymm13,%ymm14
     fa2:	c5 7e 7f 7c 24 60    	vmovdqu %ymm15,0x60(%rsp)
     fa8:	c5 7e 7f b4 24 00 01 	vmovdqu %ymm14,0x100(%rsp)
     faf:	00 00 
     fb1:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
     fb6:	c4 41 5d fe f8       	vpaddd %ymm8,%ymm4,%ymm15
     fbb:	c4 c1 5d 66 e0       	vpcmpgtd %ymm8,%ymm4,%ymm4
     fc0:	c4 41 15 66 e9       	vpcmpgtd %ymm9,%ymm13,%ymm13
     fc5:	c4 41 35 fa f6       	vpsubd %ymm14,%ymm9,%ymm14
     fca:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
     fd0:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
     fd5:	c4 62 2d 90 1c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm11
     fdb:	c4 41 0d fe ff       	vpaddd %ymm15,%ymm14,%ymm15
     fe0:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
     fe7:	00 00 
     fe9:	c4 e3 35 4c 9c 24 e0 	vpblendvb %ymm4,0xe0(%rsp),%ymm9,%ymm3
     ff0:	00 00 00 40 
     ff4:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
     ffb:	00 00 
     ffd:	c5 05 66 c8          	vpcmpgtd %ymm0,%ymm15,%ymm9
    1001:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm3,%ymm3        # 100a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9ea>
    1008:	ff ff d0 
    100b:	c4 c1 2d 72 f7 10    	vpslld $0x10,%ymm15,%ymm10
    1011:	c4 41 75 db fe       	vpand  %ymm14,%ymm1,%ymm15
    1016:	c5 dd fa db          	vpsubd %ymm3,%ymm4,%ymm3
    101a:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    101e:	c4 62 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm8
    1024:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    102a:	c5 8d 66 e0          	vpcmpgtd %ymm0,%ymm14,%ymm4
    102e:	c4 41 6d db f4       	vpand  %ymm12,%ymm2,%ymm14
    1033:	48 8b 85 20 01 00 00 	mov    0x120(%rbp),%rax
    103a:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    103e:	c4 c3 45 4c db 30    	vpblendvb %ymm3,%ymm11,%ymm7,%ymm3
    1044:	c4 c3 65 4c d8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm3
    104a:	c4 41 3d db cc       	vpand  %ymm12,%ymm8,%ymm9
    104f:	c4 e3 65 4c da 40    	vpblendvb %ymm4,%ymm2,%ymm3,%ymm3
    1055:	c4 c1 25 db e4       	vpand  %ymm12,%ymm11,%ymm4
    105a:	c5 35 fa ec          	vpsubd %ymm4,%ymm9,%ymm13
    105e:	c4 41 0d fa c9       	vpsubd %ymm9,%ymm14,%ymm9
    1063:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    1067:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    106d:	c4 41 35 f5 f7       	vpmaddwd %ymm15,%ymm9,%ymm14
    1072:	c5 75 db 4c 24 60    	vpand  0x60(%rsp),%ymm1,%ymm9
    1078:	c4 41 35 eb d2       	vpor   %ymm10,%ymm9,%ymm10
    107d:	c4 41 45 db cc       	vpand  %ymm12,%ymm7,%ymm9
    1082:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    1087:	c5 7e 7f 54 24 40    	vmovdqu %ymm10,0x40(%rsp)
    108d:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    1091:	c4 c1 5d eb e5       	vpor   %ymm13,%ymm4,%ymm4
    1096:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    109b:	c5 5d f5 4c 24 40    	vpmaddwd 0x40(%rsp),%ymm4,%ymm9
    10a1:	c5 9d db e3          	vpand  %ymm3,%ymm12,%ymm4
    10a5:	c5 7e 7f ac 24 c0 00 	vmovdqu %ymm13,0xc0(%rsp)
    10ac:	00 00 
    10ae:	c5 dd 72 f4 10       	vpslld $0x10,%ymm4,%ymm4
    10b3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    10b8:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    10be:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    10c3:	c4 c1 0d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm14
    10c9:	c4 41 0d db f4       	vpand  %ymm12,%ymm14,%ymm14
    10ce:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    10d4:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    10d9:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    10de:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    10e3:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
    10e8:	c5 ad 72 d4 10       	vpsrld $0x10,%ymm4,%ymm10
    10ed:	c5 dd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm4
    10f2:	c4 41 35 db cc       	vpand  %ymm12,%ymm9,%ymm9
    10f7:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
    10fd:	c4 c1 5d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm4
    1103:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1108:	c4 41 35 fa ce       	vpsubd %ymm14,%ymm9,%ymm9
    110d:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    1112:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    1116:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
    111b:	c5 0d fa ec          	vpsubd %ymm4,%ymm14,%ymm13
    111f:	c5 1d db 74 24 60    	vpand  0x60(%rsp),%ymm12,%ymm14
    1125:	c4 41 35 f5 cf       	vpmaddwd %ymm15,%ymm9,%ymm9
    112a:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    1130:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    1136:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    113b:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1140:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    1145:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
    114b:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    114f:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    1154:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    1159:	c4 c1 5d eb e5       	vpor   %ymm13,%ymm4,%ymm4
    115e:	c5 1d db ac 24 c0 00 	vpand  0xc0(%rsp),%ymm12,%ymm13
    1165:	00 00 
    1167:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    116c:	c5 dd f5 64 24 40    	vpmaddwd 0x40(%rsp),%ymm4,%ymm4
    1172:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    1178:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    117d:	c4 41 3d fa cb       	vpsubd %ymm11,%ymm8,%ymm9
    1182:	c4 41 6d fa c0       	vpsubd %ymm8,%ymm2,%ymm8
    1187:	c5 a5 fa d7          	vpsubd %ymm7,%ymm11,%ymm2
    118b:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    1191:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
    1195:	c5 3d db c1          	vpand  %ymm1,%ymm8,%ymm8
    1199:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    119e:	c4 c1 6d eb d1       	vpor   %ymm9,%ymm2,%ymm2
    11a3:	c4 41 3d f5 c7       	vpmaddwd %ymm15,%ymm8,%ymm8
    11a8:	c5 95 fe e4          	vpaddd %ymm4,%ymm13,%ymm4
    11ac:	c5 ed f5 54 24 40    	vpmaddwd 0x40(%rsp),%ymm2,%ymm2
    11b2:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    11b7:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    11bc:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    11c0:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    11c4:	c4 a2 65 90 3c 90    	vpgatherdd %ymm3,(%rax,%ymm10,4),%ymm7
    11ca:	48 8b 85 28 01 00 00 	mov    0x128(%rbp),%rax
    11d1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    11d6:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    11da:	c4 62 65 90 1c a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm11
    11e0:	8b 8d 74 01 00 00    	mov    0x174(%rbp),%ecx
    11e6:	8b 95 70 01 00 00    	mov    0x170(%rbp),%edx
    11ec:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    11f0:	48 8b 85 30 01 00 00 	mov    0x130(%rbp),%rax
    11f7:	c5 79 6e fa          	vmovd  %edx,%xmm15
    11fb:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    11ff:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1203:	c4 62 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm13
    1209:	c4 42 7d 58 ff       	vpbroadcastd %xmm15,%ymm15
    120e:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1213:	48 8b 85 68 01 00 00 	mov    0x168(%rbp),%rax
    121a:	c4 c1 6d 72 d3 11    	vpsrld $0x11,%ymm11,%ymm2
    1220:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    1225:	c5 25 db dd          	vpand  %ymm5,%ymm11,%ymm11
    1229:	c4 c2 65 40 df       	vpmulld %ymm15,%ymm3,%ymm3
    122e:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1233:	c5 c5 db fd          	vpand  %ymm5,%ymm7,%ymm7
    1237:	c4 c1 5d 72 d5 11    	vpsrld $0x11,%ymm13,%ymm4
    123d:	c5 15 db ed          	vpand  %ymm5,%ymm13,%ymm13
    1241:	c4 41 45 fe d3       	vpaddd %ymm11,%ymm7,%ymm10
    1246:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    124a:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    124e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1252:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    1256:	c4 62 65 90 04 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm8
    125c:	c5 f9 6e da          	vmovd  %edx,%xmm3
    1260:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    1265:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1269:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    126f:	c5 fd 6f eb          	vmovdqa %ymm3,%ymm5
    1273:	c4 e2 5d 90 1c a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm3
    1279:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
    127d:	c4 c2 45 3d eb       	vpmaxsd %ymm11,%ymm7,%ymm5
    1282:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
    1288:	c5 15 66 cd          	vpcmpgtd %ymm5,%ymm13,%ymm9
    128c:	c4 42 45 39 f3       	vpminsd %ymm11,%ymm7,%ymm14
    1291:	c4 c1 45 66 fb       	vpcmpgtd %ymm11,%ymm7,%ymm7
    1296:	c4 e3 05 4c 64 24 60 	vpblendvb %ymm4,0x60(%rsp),%ymm15,%ymm4
    129d:	40 
    129e:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 12a7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc87>
    12a5:	ff ff 90 
    12a8:	c4 42 55 3d cd       	vpmaxsd %ymm13,%ymm5,%ymm9
    12ad:	c4 c2 0d 39 ed       	vpminsd %ymm13,%ymm14,%ymm5
    12b2:	c5 7e 7f 8c 24 c0 00 	vmovdqu %ymm9,0xc0(%rsp)
    12b9:	00 00 
    12bb:	c4 41 55 fe c9       	vpaddd %ymm9,%ymm5,%ymm9
    12c0:	c4 41 0d 66 f5       	vpcmpgtd %ymm13,%ymm14,%ymm14
    12c5:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    12c9:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    12ce:	c4 41 35 fe ca       	vpaddd %ymm10,%ymm9,%ymm9
    12d3:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    12d7:	c4 e2 2d 90 14 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm2
    12dd:	c5 35 66 d8          	vpcmpgtd %ymm0,%ymm9,%ymm11
    12e1:	c4 e3 05 4c 64 24 60 	vpblendvb %ymm7,0x60(%rsp),%ymm15,%ymm4
    12e8:	70 
    12e9:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    12ef:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
    12f6:	00 00 
    12f8:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm4,%ymm4        # 1301 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xce1>
    12ff:	ff ff e0 
    1302:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    1308:	c5 c5 fa e4          	vpsubd %ymm4,%ymm7,%ymm4
    130c:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    1310:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1316:	c4 62 45 90 14 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm10
    131c:	c5 85 66 e0          	vpcmpgtd %ymm0,%ymm15,%ymm4
    1320:	c5 d5 66 f8          	vpcmpgtd %ymm0,%ymm5,%ymm7
    1324:	c4 c1 6d db c4       	vpand  %ymm12,%ymm2,%ymm0
    1329:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    132d:	c4 e3 3d 4c e2 40    	vpblendvb %ymm4,%ymm2,%ymm8,%ymm4
    1333:	c4 c3 5d 4c e2 b0    	vpblendvb %ymm11,%ymm10,%ymm4,%ymm4
    1339:	c4 41 65 db dc       	vpand  %ymm12,%ymm3,%ymm11
    133e:	c4 e3 5d 4c e3 70    	vpblendvb %ymm7,%ymm3,%ymm4,%ymm4
    1344:	c4 c1 2d db fc       	vpand  %ymm12,%ymm10,%ymm7
    1349:	c5 45 fa e8          	vpsubd %ymm0,%ymm7,%ymm13
    134d:	c5 25 fa df          	vpsubd %ymm7,%ymm11,%ymm11
    1351:	c4 c1 75 db ff       	vpand  %ymm15,%ymm1,%ymm7
    1356:	c4 c1 45 eb f9       	vpor   %ymm9,%ymm7,%ymm7
    135b:	c4 41 3d db cc       	vpand  %ymm12,%ymm8,%ymm9
    1360:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
    1364:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    1369:	c4 c1 15 72 f5 10    	vpslld $0x10,%ymm13,%ymm13
    136f:	c5 1d db cc          	vpand  %ymm4,%ymm12,%ymm9
    1373:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1377:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    137d:	c5 25 f5 dd          	vpmaddwd %ymm5,%ymm11,%ymm11
    1381:	c4 c1 7d eb c5       	vpor   %ymm13,%ymm0,%ymm0
    1386:	c4 c1 05 72 d0 08    	vpsrld $0x8,%ymm8,%ymm15
    138c:	c5 35 fe ce          	vpaddd %ymm6,%ymm9,%ymm9
    1390:	c5 fd f5 c7          	vpmaddwd %ymm7,%ymm0,%ymm0
    1394:	c4 c1 15 72 d2 08    	vpsrld $0x8,%ymm10,%ymm13
    139a:	c4 41 05 db fc       	vpand  %ymm12,%ymm15,%ymm15
    139f:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
    13a4:	c5 a5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm11
    13a9:	c4 41 15 db ec       	vpand  %ymm12,%ymm13,%ymm13
    13ae:	c5 b5 fe c0          	vpaddd %ymm0,%ymm9,%ymm0
    13b2:	c5 b5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm9
    13b7:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    13bc:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    13c1:	c4 c1 25 72 f3 10    	vpslld $0x10,%ymm11,%ymm11
    13c7:	c4 41 35 db cc       	vpand  %ymm12,%ymm9,%ymm9
    13cc:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    13d2:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
    13d7:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    13dd:	c4 41 35 fa cd       	vpsubd %ymm13,%ymm9,%ymm9
    13e2:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    13e7:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    13eb:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
    13f0:	c5 15 fa f0          	vpsubd %ymm0,%ymm13,%ymm14
    13f4:	c4 c1 7d fa c7       	vpsubd %ymm15,%ymm0,%ymm0
    13f9:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    13fe:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1402:	c4 c1 0d 72 f6 10    	vpslld $0x10,%ymm14,%ymm14
    1408:	c5 35 f5 cd          	vpmaddwd %ymm5,%ymm9,%ymm9
    140c:	c4 c1 7d eb c6       	vpor   %ymm14,%ymm0,%ymm0
    1411:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1416:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    141b:	c5 fd f5 c7          	vpmaddwd %ymm7,%ymm0,%ymm0
    141f:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1424:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    1429:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    142e:	c5 25 fe ce          	vpaddd %ymm6,%ymm11,%ymm9
    1432:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    1437:	c4 c1 35 72 d2 10    	vpsrld $0x10,%ymm10,%ymm9
    143d:	c4 41 35 db cc       	vpand  %ymm12,%ymm9,%ymm9
    1442:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1447:	c5 35 fa d2          	vpsubd %ymm2,%ymm9,%ymm10
    144b:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    1450:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    1455:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    145a:	c4 c1 2d 72 f2 10    	vpslld $0x10,%ymm10,%ymm10
    1460:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    1464:	c5 ed db c9          	vpand  %ymm1,%ymm2,%ymm1
    1468:	c4 c1 5d db d4       	vpand  %ymm12,%ymm4,%ymm2
    146d:	c5 e5 f5 dd          	vpmaddwd %ymm5,%ymm3,%ymm3
    1471:	c4 c1 75 eb ca       	vpor   %ymm10,%ymm1,%ymm1
    1476:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    147b:	c5 f5 f5 cf          	vpmaddwd %ymm7,%ymm1,%ymm1
    147f:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1483:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1487:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    148b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1490:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1495:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1499:	c5 fd eb 44 24 40    	vpor   0x40(%rsp),%ymm0,%ymm0
    149f:	c4 e2 7d 00 84 24 a0 	vpshufb 0xa0(%rsp),%ymm0,%ymm0
    14a6:	00 00 00 
    14a9:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    14ad:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    14b3:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    14b8:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    14bd:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    14c1:	c4 c1 79 d6 44 24 f8 	vmovq  %xmm0,-0x8(%r12)
    14c8:	c4 c1 7a 7f 4c 24 e8 	vmovdqu %xmm1,-0x18(%r12)
    14cf:	4c 39 d3             	cmp    %r10,%rbx
    14d2:	0f 85 67 f6 ff ff    	jne    b3f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x51f>
    14d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    14df:	00 
    14e0:	c5 f8 77             	vzeroupper
    14e3:	c5 f8 28 b4 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm6
    14ea:	00 00 
    14ec:	c5 f8 28 bc 24 00 02 	vmovaps 0x200(%rsp),%xmm7
    14f3:	00 00 
    14f5:	c5 78 28 84 24 10 02 	vmovaps 0x210(%rsp),%xmm8
    14fc:	00 00 
    14fe:	c5 78 28 8c 24 20 02 	vmovaps 0x220(%rsp),%xmm9
    1505:	00 00 
    1507:	c5 78 28 94 24 30 02 	vmovaps 0x230(%rsp),%xmm10
    150e:	00 00 
    1510:	c5 78 28 9c 24 40 02 	vmovaps 0x240(%rsp),%xmm11
    1517:	00 00 
    1519:	c5 78 28 a4 24 50 02 	vmovaps 0x250(%rsp),%xmm12
    1520:	00 00 
    1522:	c5 78 28 ac 24 60 02 	vmovaps 0x260(%rsp),%xmm13
    1529:	00 00 
    152b:	c5 78 28 b4 24 70 02 	vmovaps 0x270(%rsp),%xmm14
    1532:	00 00 
    1534:	c5 78 28 bc 24 80 02 	vmovaps 0x280(%rsp),%xmm15
    153b:	00 00 
    153d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    1544:	5b                   	pop    %rbx
    1545:	5e                   	pop    %rsi
    1546:	5f                   	pop    %rdi
    1547:	5d                   	pop    %rbp
    1548:	41 5c                	pop    %r12
    154a:	41 5d                	pop    %r13
    154c:	c3                   	ret
    154d:	90                   	nop
    154e:	90                   	nop
    154f:	90                   	nop
