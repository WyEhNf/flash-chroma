Recovered random/adversarial m33 model; not an accuracy-qualified model.
CPU, CUDA and this compiled C99 ROM produce the same full RGB8 cube.
Mean RGB distance: 128.83916568095952; max: 413.07868499839105.
The observed mean champion remains adaptive_bins/m17; the max/p99 champion remains adaptive_bins/m25.
Host check: cc -std=c99 -O2 -Iinclude -I. flash_chroma.c src/jshc_portable.c host/verify_exported_rom.c -o verify
Run: ./verify cube output.rgb
Firmware uses const ROM arrays plus caller-owned workspace; host/ is only a verification example.
The 64-bit host measured 12560 workspace bytes; this is not a phone memory/performance measurement.
