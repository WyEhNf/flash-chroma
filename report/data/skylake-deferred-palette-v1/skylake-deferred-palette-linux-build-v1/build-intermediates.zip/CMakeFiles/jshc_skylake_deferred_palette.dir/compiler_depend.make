# Empty compiler generated dependencies file for jshc_skylake_deferred_palette.
# This may be replaced when dependencies are built.
