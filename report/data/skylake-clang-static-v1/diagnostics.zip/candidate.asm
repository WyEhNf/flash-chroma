
artifacts\skylake-clang-probe-v1\channel_clang.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	41 56                	push   %r14
       2:	56                   	push   %rsi
       3:	57                   	push   %rdi
       4:	53                   	push   %rbx
       5:	48 81 ec 48 03 00 00 	sub    $0x348,%rsp
       c:	c5 79 7f bc 24 30 03 	vmovdqa %xmm15,0x330(%rsp)
      13:	00 00 
      15:	c5 79 7f b4 24 20 03 	vmovdqa %xmm14,0x320(%rsp)
      1c:	00 00 
      1e:	c5 78 29 ac 24 10 03 	vmovaps %xmm13,0x310(%rsp)
      25:	00 00 
      27:	c5 79 7f a4 24 00 03 	vmovdqa %xmm12,0x300(%rsp)
      2e:	00 00 
      30:	c5 79 7f 9c 24 f0 02 	vmovdqa %xmm11,0x2f0(%rsp)
      37:	00 00 
      39:	c5 79 7f 94 24 e0 02 	vmovdqa %xmm10,0x2e0(%rsp)
      40:	00 00 
      42:	c5 79 7f 8c 24 d0 02 	vmovdqa %xmm9,0x2d0(%rsp)
      49:	00 00 
      4b:	c5 79 7f 84 24 c0 02 	vmovdqa %xmm8,0x2c0(%rsp)
      52:	00 00 
      54:	c5 f9 7f bc 24 b0 02 	vmovdqa %xmm7,0x2b0(%rsp)
      5b:	00 00 
      5d:	c5 f9 7f b4 24 a0 02 	vmovdqa %xmm6,0x2a0(%rsp)
      64:	00 00 
      66:	48 83 fa 04          	cmp    $0x4,%rdx
      6a:	0f 85 3d 0c 00 00    	jne    cad <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcad>
      70:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
      74:	0f 85 33 0c 00 00    	jne    cad <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcad>
      7a:	80 b9 b8 00 00 00 01 	cmpb   $0x1,0xb8(%rcx)
      81:	0f 85 26 0c 00 00    	jne    cad <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcad>
      87:	80 b9 18 01 00 00 01 	cmpb   $0x1,0x118(%rcx)
      8e:	0f 85 19 0c 00 00    	jne    cad <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcad>
      94:	80 b9 78 01 00 00 01 	cmpb   $0x1,0x178(%rcx)
      9b:	0f 85 0c 0c 00 00    	jne    cad <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcad>
      a1:	4d 85 c9             	test   %r9,%r9
      a4:	0f 84 2f 14 00 00    	je     14d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d9>
      aa:	49 83 c0 10          	add    $0x10,%r8
      ae:	31 c0                	xor    %eax,%eax
      b0:	c4 e2 7d 18 05 20 00 	vbroadcastss 0x20(%rip),%ymm0        # d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd9>
      b7:	00 00 
      b9:	c5 fc 11 04 24       	vmovups %ymm0,(%rsp)
      be:	c4 e2 7d 18 05 60 00 	vbroadcastss 0x60(%rip),%ymm0        # 127 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x127>
      c5:	00 00 
      c7:	c5 fc 11 84 24 80 00 	vmovups %ymm0,0x80(%rsp)
      ce:	00 00 
      d0:	c4 e2 7d 18 05 64 00 	vbroadcastss 0x64(%rip),%ymm0        # 13d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13d>
      d7:	00 00 
      d9:	c5 fc 11 44 24 60    	vmovups %ymm0,0x60(%rsp)
      df:	c4 e2 7d 58 05 68 00 	vpbroadcastd 0x68(%rip),%ymm0        # 150 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x150>
      e6:	00 00 
      e8:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
      ef:	00 00 
      f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
      f8:	0f 1f 84 00 00 00 00 
      ff:	00 
     100:	c4 c1 7a 7e 00       	vmovq  (%r8),%xmm0
     105:	c4 c1 7a 6f 48 f0    	vmovdqu -0x10(%r8),%xmm1
     10b:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
     111:	c4 e3 75 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
     117:	c4 e2 7d 00 15 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm2        # 120 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120>
     11e:	00 00 
     120:	c5 ed db 34 24       	vpand  (%rsp),%ymm2,%ymm6
     125:	48 8b 11             	mov    (%rcx),%rdx
     128:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     12c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     130:	c4 e2 75 90 04 b2    	vpgatherdd %ymm1,(%rdx,%ymm6,4),%ymm0
     136:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
     13c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
     140:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 188 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x188>
     147:	00 
     148:	c4 62 6d 00 e9       	vpshufb %ymm1,%ymm2,%ymm13
     14d:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     151:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     155:	c4 a2 65 90 0c aa    	vpgatherdd %ymm3,(%rdx,%ymm13,4),%ymm1
     15b:	c5 b5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm9
     160:	48 8b 51 10          	mov    0x10(%rcx),%rdx
     164:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     168:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     16c:	c4 a2 6d 90 1c 8a    	vpgatherdd %ymm2,(%rdx,%ymm9,4),%ymm3
     172:	c5 ed 72 d0 11       	vpsrld $0x11,%ymm0,%ymm2
     177:	44 8b 51 50          	mov    0x50(%rcx),%r10d
     17b:	c4 c1 79 6e e2       	vmovd  %r10d,%xmm4
     180:	c4 62 7d 58 d4       	vpbroadcastd %xmm4,%ymm10
     185:	c4 e2 2d 40 d2       	vpmulld %ymm2,%ymm10,%ymm2
     18a:	c5 dd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm4
     18f:	44 8b 59 54          	mov    0x54(%rcx),%r11d
     193:	c4 c1 79 6e eb       	vmovd  %r11d,%xmm5
     198:	c4 62 7d 58 dd       	vpbroadcastd %xmm5,%ymm11
     19d:	c4 e2 25 40 e4       	vpmulld %ymm4,%ymm11,%ymm4
     1a2:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     1a7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     1ab:	c5 6d fe e4          	vpaddd %ymm4,%ymm2,%ymm12
     1af:	48 8b 51 48          	mov    0x48(%rcx),%rdx
     1b3:	47 8d 54 1a 01       	lea    0x1(%r10,%r11,1),%r10d
     1b8:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
     1bd:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     1c2:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
     1c9:	00 00 
     1cb:	c5 7d db fd          	vpand  %ymm5,%ymm0,%ymm15
     1cf:	c5 75 db f5          	vpand  %ymm5,%ymm1,%ymm14
     1d3:	c5 e5 db fd          	vpand  %ymm5,%ymm3,%ymm7
     1d7:	c4 c1 0d 66 c7       	vpcmpgtd %ymm15,%ymm14,%ymm0
     1dc:	c4 c3 2d 4a c3 00    	vblendvps %ymm0,%ymm11,%ymm10,%ymm0
     1e2:	c4 c2 05 3f ce       	vpmaxud %ymm14,%ymm15,%ymm1
     1e7:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
     1ee:	00 00 
     1f0:	c5 c5 66 c9          	vpcmpgtd %ymm1,%ymm7,%ymm1
     1f4:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     1fa:	c5 fc 10 64 24 60    	vmovups 0x60(%rsp),%ymm4
     200:	c4 e3 7d 4a c4 10    	vblendvps %ymm1,%ymm4,%ymm0,%ymm0
     206:	c5 9d fe da          	vpaddd %ymm2,%ymm12,%ymm3
     20a:	c4 c1 05 66 ce       	vpcmpgtd %ymm14,%ymm15,%ymm1
     20f:	c4 c3 2d 4a cb 10    	vblendvps %ymm1,%ymm11,%ymm10,%ymm1
     215:	c5 9d fe c0          	vpaddd %ymm0,%ymm12,%ymm0
     219:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     21d:	c4 41 39 ef c0       	vpxor  %xmm8,%xmm8,%xmm8
     222:	c4 62 6d 90 04 82    	vpgatherdd %ymm2,(%rdx,%ymm0,4),%ymm8
     228:	c5 7e 7f 84 24 00 01 	vmovdqu %ymm8,0x100(%rsp)
     22f:	00 00 
     231:	c4 c2 05 3b c6       	vpminud %ymm14,%ymm15,%ymm0
     236:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     23d:	00 00 
     23f:	c5 fd 66 c7          	vpcmpgtd %ymm7,%ymm0,%ymm0
     243:	c4 e3 75 4a c4 00    	vblendvps %ymm0,%ymm4,%ymm1,%ymm0
     249:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
     24d:	c5 7d 6f c3          	vmovdqa %ymm3,%ymm8
     251:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     255:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     259:	c4 e2 75 90 14 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm2
     25f:	c5 fe 7f 94 24 e0 00 	vmovdqu %ymm2,0xe0(%rsp)
     266:	00 00 
     268:	4c 8b 51 18          	mov    0x18(%rcx),%r10
     26c:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     270:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     274:	c4 c2 7d 90 0c b2    	vpgatherdd %ymm0,(%r10,%ymm6,4),%ymm1
     27a:	4c 8b 51 20          	mov    0x20(%rcx),%r10
     27e:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     282:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     286:	c4 82 7d 90 14 aa    	vpgatherdd %ymm0,(%r10,%ymm13,4),%ymm2
     28c:	4c 8b 51 28          	mov    0x28(%rcx),%r10
     290:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     294:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     298:	c4 82 7d 90 1c 8a    	vpgatherdd %ymm0,(%r10,%ymm9,4),%ymm3
     29e:	c5 fd 6f c5          	vmovdqa %ymm5,%ymm0
     2a2:	c5 f5 db f5          	vpand  %ymm5,%ymm1,%ymm6
     2a6:	c5 ed db ed          	vpand  %ymm5,%ymm2,%ymm5
     2aa:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     2ae:	c5 d5 66 c6          	vpcmpgtd %ymm6,%ymm5,%ymm0
     2b2:	c4 c3 2d 4a c3 00    	vblendvps %ymm0,%ymm11,%ymm10,%ymm0
     2b8:	c4 e2 4d 3f cd       	vpmaxud %ymm5,%ymm6,%ymm1
     2bd:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     2c4:	00 00 
     2c6:	c5 e5 66 c9          	vpcmpgtd %ymm1,%ymm3,%ymm1
     2ca:	c4 e3 7d 4a c4 10    	vblendvps %ymm1,%ymm4,%ymm0,%ymm0
     2d0:	c5 9d fe c0          	vpaddd %ymm0,%ymm12,%ymm0
     2d4:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     2d8:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     2dc:	c4 e2 75 90 14 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm2
     2e2:	c5 fe 7f 94 24 00 02 	vmovdqu %ymm2,0x200(%rsp)
     2e9:	00 00 
     2eb:	c5 cd 66 c5          	vpcmpgtd %ymm5,%ymm6,%ymm0
     2ef:	c4 c3 2d 4a c3 00    	vblendvps %ymm0,%ymm11,%ymm10,%ymm0
     2f5:	c4 e2 4d 3b cd       	vpminud %ymm5,%ymm6,%ymm1
     2fa:	c5 fe 7f 8c 24 c0 01 	vmovdqu %ymm1,0x1c0(%rsp)
     301:	00 00 
     303:	c5 f5 66 cb          	vpcmpgtd %ymm3,%ymm1,%ymm1
     307:	c4 e3 7d 4a c4 10    	vblendvps %ymm1,%ymm4,%ymm0,%ymm0
     30d:	c5 bd fa c0          	vpsubd %ymm0,%ymm8,%ymm0
     311:	c5 7e 7f 84 24 a0 01 	vmovdqu %ymm8,0x1a0(%rsp)
     318:	00 00 
     31a:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     31e:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     322:	c4 e2 75 90 14 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm2
     328:	c5 fe 7f 94 24 e0 01 	vmovdqu %ymm2,0x1e0(%rsp)
     32f:	00 00 
     331:	4c 8b 51 30          	mov    0x30(%rcx),%r10
     335:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     339:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     33d:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
     343:	c4 c2 7d 90 3c 8a    	vpgatherdd %ymm0,(%r10,%ymm1,4),%ymm7
     349:	4c 8b 51 38          	mov    0x38(%rcx),%r10
     34d:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     351:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     355:	c4 82 7d 90 14 aa    	vpgatherdd %ymm0,(%r10,%ymm13,4),%ymm2
     35b:	4c 8b 51 40          	mov    0x40(%rcx),%r10
     35f:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     363:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     367:	c4 82 7d 90 0c 8a    	vpgatherdd %ymm0,(%r10,%ymm9,4),%ymm1
     36d:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     371:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
     376:	c4 22 7d 90 0c a2    	vpgatherdd %ymm0,(%rdx,%ymm12,4),%ymm9
     37c:	c5 7e 7f 8c 24 60 01 	vmovdqu %ymm9,0x160(%rsp)
     383:	00 00 
     385:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
     38c:	00 00 
     38e:	c5 45 db c8          	vpand  %ymm0,%ymm7,%ymm9
     392:	c5 ed db f8          	vpand  %ymm0,%ymm2,%ymm7
     396:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     39a:	c4 c1 45 66 d1       	vpcmpgtd %ymm9,%ymm7,%ymm2
     39f:	c4 c3 2d 4a d3 20    	vblendvps %ymm2,%ymm11,%ymm10,%ymm2
     3a5:	c4 e2 35 3f c7       	vpmaxud %ymm7,%ymm9,%ymm0
     3aa:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
     3b0:	c5 75 66 e8          	vpcmpgtd %ymm0,%ymm1,%ymm13
     3b4:	c4 e3 6d 4a d4 d0    	vblendvps %ymm13,%ymm4,%ymm2,%ymm2
     3ba:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
     3be:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     3c3:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     3c7:	c4 a2 15 90 14 a2    	vpgatherdd %ymm13,(%rdx,%ymm12,4),%ymm2
     3cd:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     3d2:	c4 41 19 ef e4       	vpxor  %xmm12,%xmm12,%xmm12
     3d7:	c4 22 15 90 24 82    	vpgatherdd %ymm13,(%rdx,%ymm8,4),%ymm12
     3dd:	c5 35 66 ef          	vpcmpgtd %ymm7,%ymm9,%ymm13
     3e1:	c4 c3 2d 4a c3 d0    	vblendvps %ymm13,%ymm11,%ymm10,%ymm0
     3e7:	c5 fc 11 84 24 80 01 	vmovups %ymm0,0x180(%rsp)
     3ee:	00 00 
     3f0:	c4 41 0d fe c7       	vpaddd %ymm15,%ymm14,%ymm8
     3f5:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
     3fb:	c4 62 7d 3f 9c 24 20 	vpmaxud 0x120(%rsp),%ymm0,%ymm11
     402:	01 00 00 
     405:	c4 62 7d 3b ac 24 c0 	vpminud 0xc0(%rsp),%ymm0,%ymm13
     40c:	00 00 00 
     40f:	c5 3d fe c0          	vpaddd %ymm0,%ymm8,%ymm8
     413:	c4 41 15 fe f3       	vpaddd %ymm11,%ymm13,%ymm14
     418:	c4 41 3d fa c6       	vpsubd %ymm14,%ymm8,%ymm8
     41d:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
     422:	c5 7d db b4 24 00 01 	vpand  0x100(%rsp),%ymm0,%ymm14
     429:	00 00 
     42b:	c5 fe 6f a4 24 60 01 	vmovdqu 0x160(%rsp),%ymm4
     432:	00 00 
     434:	c5 5d db f8          	vpand  %ymm0,%ymm4,%ymm15
     438:	c4 41 0d fa d7       	vpsubd %ymm15,%ymm14,%ymm10
     43d:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
     442:	c4 c1 25 72 f7 10    	vpslld $0x10,%ymm15,%ymm11
     448:	c4 41 2d fe d3       	vpaddd %ymm11,%ymm10,%ymm10
     44d:	c5 7d db 9c 24 e0 00 	vpand  0xe0(%rsp),%ymm0,%ymm11
     454:	00 00 
     456:	c4 41 25 fa f6       	vpsubd %ymm14,%ymm11,%ymm14
     45b:	c4 42 0d 40 c0       	vpmulld %ymm8,%ymm14,%ymm8
     460:	c5 1d db f0          	vpand  %ymm0,%ymm12,%ymm14
     464:	c4 41 0d fa db       	vpsubd %ymm11,%ymm14,%ymm11
     469:	c4 42 25 40 dd       	vpmulld %ymm13,%ymm11,%ymm11
     46e:	c4 41 2d fe c0       	vpaddd %ymm8,%ymm10,%ymm8
     473:	c5 7e 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm14
     47a:	00 00 
     47c:	c4 41 25 fe d6       	vpaddd %ymm14,%ymm11,%ymm10
     481:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     486:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     48a:	c4 e2 65 3f b4 24 a0 	vpmaxud 0xa0(%rsp),%ymm3,%ymm6
     491:	00 00 00 
     494:	c4 62 65 3b 94 24 c0 	vpminud 0x1c0(%rsp),%ymm3,%ymm10
     49b:	01 00 00 
     49e:	c5 d5 fe db          	vpaddd %ymm3,%ymm5,%ymm3
     4a2:	c5 ad fe ee          	vpaddd %ymm6,%ymm10,%ymm5
     4a6:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     4aa:	c5 fd 6f 05 40 00 00 	vmovdqa 0x40(%rip),%ymm0        # 4f2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4f2>
     4b1:	00 
     4b2:	c4 e2 5d 00 e8       	vpshufb %ymm0,%ymm4,%ymm5
     4b7:	c5 7d 6f fc          	vmovdqa %ymm4,%ymm15
     4bb:	c5 fe 6f a4 24 00 02 	vmovdqu 0x200(%rsp),%ymm4
     4c2:	00 00 
     4c4:	c4 62 5d 00 d8       	vpshufb %ymm0,%ymm4,%ymm11
     4c9:	c5 25 fa ed          	vpsubd %ymm5,%ymm11,%ymm13
     4cd:	c4 e2 15 40 f6       	vpmulld %ymm6,%ymm13,%ymm6
     4d2:	c5 d5 72 f5 10       	vpslld $0x10,%ymm5,%ymm5
     4d7:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
     4db:	c5 fe 6f a4 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm4
     4e2:	00 00 
     4e4:	c4 e2 5d 00 e0       	vpshufb %ymm0,%ymm4,%ymm4
     4e9:	c4 c1 5d fa f3       	vpsubd %ymm11,%ymm4,%ymm6
     4ee:	c4 e2 4d 40 db       	vpmulld %ymm3,%ymm6,%ymm3
     4f3:	c4 e2 1d 00 f0       	vpshufb %ymm0,%ymm12,%ymm6
     4f8:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     4fc:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     501:	c5 d5 fe db          	vpaddd %ymm3,%ymm5,%ymm3
     505:	c4 e2 35 3b ef       	vpminud %ymm7,%ymm9,%ymm5
     50a:	c5 d5 66 f1          	vpcmpgtd %ymm1,%ymm5,%ymm6
     50e:	c5 7c 10 5c 24 60    	vmovups 0x60(%rsp),%ymm11
     514:	c5 fc 10 84 24 80 01 	vmovups 0x180(%rsp),%ymm0
     51b:	00 00 
     51d:	c4 c3 7d 4a f3 60    	vblendvps %ymm6,%ymm11,%ymm0,%ymm6
     523:	c5 8d fe e4          	vpaddd %ymm4,%ymm14,%ymm4
     527:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     52b:	c4 c1 5d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm4
     531:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     536:	c4 62 75 3f 44 24 20 	vpmaxud 0x20(%rsp),%ymm1,%ymm8
     53d:	c4 e2 55 3b e9       	vpminud %ymm1,%ymm5,%ymm5
     542:	c5 b5 fe c7          	vpaddd %ymm7,%ymm9,%ymm0
     546:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     54a:	c5 bd fe cd          	vpaddd %ymm5,%ymm8,%ymm1
     54e:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     552:	c5 fe 6f 8c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm1
     559:	00 00 
     55b:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     55f:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
     563:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     567:	c4 e2 4d 90 3c 8a    	vpgatherdd %ymm6,(%rdx,%ymm1,4),%ymm7
     56d:	c5 7d 6f 2d 80 00 00 	vmovdqa 0x80(%rip),%ymm13        # 5f5 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5f5>
     574:	00 
     575:	c4 c2 05 00 cd       	vpshufb %ymm13,%ymm15,%ymm1
     57a:	c5 cd 72 f1 10       	vpslld $0x10,%ymm1,%ymm6
     57f:	c4 c2 6d 00 d5       	vpshufb %ymm13,%ymm2,%ymm2
     584:	c5 ed fa c9          	vpsubd %ymm1,%ymm2,%ymm1
     588:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     58d:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     591:	c4 c2 45 00 f5       	vpshufb %ymm13,%ymm7,%ymm6
     596:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
     59a:	c4 e2 6d 40 c0       	vpmulld %ymm0,%ymm2,%ymm0
     59f:	48 8b 51 60          	mov    0x60(%rcx),%rdx
     5a3:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
     5a7:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     5ab:	c4 e2 45 90 14 a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm2
     5b1:	c4 c2 1d 00 e5       	vpshufb %ymm13,%ymm12,%ymm4
     5b6:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     5ba:	c4 e2 5d 40 e5       	vpmulld %ymm5,%ymm4,%ymm4
     5bf:	48 8b 51 68          	mov    0x68(%rcx),%rdx
     5c3:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
     5c7:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     5cb:	c4 e2 55 90 3c 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm7
     5d1:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     5d5:	c5 8d fe cc          	vpaddd %ymm4,%ymm14,%ymm1
     5d9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     5dd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     5e2:	48 8b 51 70          	mov    0x70(%rcx),%rdx
     5e6:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     5ea:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     5ee:	c4 e2 75 90 1c 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm3
     5f4:	c5 fd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm0
     5f9:	44 8b 91 b0 00 00 00 	mov    0xb0(%rcx),%r10d
     600:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
     605:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     60a:	c4 e2 75 40 c0       	vpmulld %ymm0,%ymm1,%ymm0
     60f:	c5 d5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm5
     614:	44 8b 99 b4 00 00 00 	mov    0xb4(%rcx),%r11d
     61b:	c4 c1 79 6e e3       	vmovd  %r11d,%xmm4
     620:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     625:	c4 e2 5d 40 ed       	vpmulld %ymm5,%ymm4,%ymm5
     62a:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
     62f:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     633:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
     637:	48 8b 91 a8 00 00 00 	mov    0xa8(%rcx),%rdx
     63e:	47 8d 54 1a 01       	lea    0x1(%r10,%r11,1),%r10d
     643:	c4 c1 79 6e c2       	vmovd  %r10d,%xmm0
     648:	c4 e2 7d 58 f0       	vpbroadcastd %xmm0,%ymm6
     64d:	c5 55 fe c6          	vpaddd %ymm6,%ymm5,%ymm8
     651:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     656:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     65a:	c4 a2 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm8,4),%ymm0
     660:	c5 7e 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm13
     667:	00 00 
     669:	c5 15 db c7          	vpand  %ymm7,%ymm13,%ymm8
     66d:	c5 15 db ca          	vpand  %ymm2,%ymm13,%ymm9
     671:	c4 c1 3d 66 d1       	vpcmpgtd %ymm9,%ymm8,%ymm2
     676:	c4 e3 75 4a d4 20    	vblendvps %ymm2,%ymm4,%ymm1,%ymm2
     67c:	c4 42 35 3f d0       	vpmaxud %ymm8,%ymm9,%ymm10
     681:	c5 95 db fb          	vpand  %ymm3,%ymm13,%ymm7
     685:	c4 c1 45 66 da       	vpcmpgtd %ymm10,%ymm7,%ymm3
     68a:	c4 41 7c 28 fb       	vmovaps %ymm11,%ymm15
     68f:	c4 c3 6d 4a d3 30    	vblendvps %ymm3,%ymm11,%ymm2,%ymm2
     695:	c5 d5 fe da          	vpaddd %ymm2,%ymm5,%ymm3
     699:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     69e:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     6a2:	c4 e2 25 90 14 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm2
     6a8:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     6ad:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     6b1:	c4 e2 25 90 1c aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm3
     6b7:	c4 41 35 66 d8       	vpcmpgtd %ymm8,%ymm9,%ymm11
     6bc:	c4 e3 75 4a cc b0    	vblendvps %ymm11,%ymm4,%ymm1,%ymm1
     6c2:	c4 42 35 3b d8       	vpminud %ymm8,%ymm9,%ymm11
     6c7:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
     6cb:	c4 43 75 4a e7 40    	vblendvps %ymm4,%ymm15,%ymm1,%ymm12
     6d1:	c4 e2 2d 3f e7       	vpmaxud %ymm7,%ymm10,%ymm4
     6d6:	c4 e2 25 3b cf       	vpminud %ymm7,%ymm11,%ymm1
     6db:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     6e0:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     6e5:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
     6e9:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     6ee:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
     6f2:	c4 e2 35 90 2c b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm5
     6f8:	c5 bd fe f7          	vpaddd %ymm7,%ymm8,%ymm6
     6fc:	c5 dd fe f9          	vpaddd %ymm1,%ymm4,%ymm7
     700:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
     704:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
     709:	c5 ad db fb          	vpand  %ymm3,%ymm10,%ymm7
     70d:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
     712:	c5 2d db ca          	vpand  %ymm2,%ymm10,%ymm9
     716:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     71a:	c4 e2 45 40 fc       	vpmulld %ymm4,%ymm7,%ymm7
     71f:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     723:	c5 2d db c5          	vpand  %ymm5,%ymm10,%ymm8
     727:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     72c:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
     731:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     735:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
     73a:	c4 62 3d 40 c1       	vpmulld %ymm1,%ymm8,%ymm8
     73f:	c4 41 35 fe c0       	vpaddd %ymm8,%ymm9,%ymm8
     744:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     748:	c5 8d fe ff          	vpaddd %ymm7,%ymm14,%ymm7
     74c:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     751:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 799 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x799>
     758:	00 
     759:	c4 42 65 00 c3       	vpshufb %ymm11,%ymm3,%ymm8
     75e:	c4 42 6d 00 cb       	vpshufb %ymm11,%ymm2,%ymm9
     763:	c4 42 55 00 d3       	vpshufb %ymm11,%ymm5,%ymm10
     768:	c4 42 7d 00 db       	vpshufb %ymm11,%ymm0,%ymm11
     76d:	c4 41 25 fa da       	vpsubd %ymm10,%ymm11,%ymm11
     772:	c4 41 2d fa d1       	vpsubd %ymm9,%ymm10,%ymm10
     777:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
     77c:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     782:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     787:	c4 62 2d 40 d6       	vpmulld %ymm6,%ymm10,%ymm10
     78c:	c4 62 25 40 d9       	vpmulld %ymm1,%ymm11,%ymm11
     791:	c4 41 35 fe c0       	vpaddd %ymm8,%ymm9,%ymm8
     796:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
     79b:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     7a0:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
     7a5:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     7ab:	c5 7d 6f 15 80 00 00 	vmovdqa 0x80(%rip),%ymm10        # 833 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x833>
     7b2:	00 
     7b3:	c4 c2 65 00 da       	vpshufb %ymm10,%ymm3,%ymm3
     7b8:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
     7bd:	c4 c2 6d 00 d2       	vpshufb %ymm10,%ymm2,%ymm2
     7c2:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
     7c6:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
     7cb:	c5 b5 fe e3          	vpaddd %ymm3,%ymm9,%ymm4
     7cf:	c4 c2 55 00 da       	vpshufb %ymm10,%ymm5,%ymm3
     7d4:	c5 e5 fa d2          	vpsubd %ymm2,%ymm3,%ymm2
     7d8:	c4 e2 6d 40 ee       	vpmulld %ymm6,%ymm2,%ymm5
     7dd:	48 8b 91 c0 00 00 00 	mov    0xc0(%rcx),%rdx
     7e4:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
     7e8:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     7ec:	c4 e2 4d 90 14 ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm2
     7f2:	c4 c2 7d 00 c2       	vpshufb %ymm10,%ymm0,%ymm0
     7f7:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     7fb:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     800:	48 8b 91 c8 00 00 00 	mov    0xc8(%rcx),%rdx
     807:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     80b:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     80f:	c4 a2 75 90 1c 82    	vpgatherdd %ymm1,(%rdx,%ymm8,4),%ymm3
     815:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     819:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     81d:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
     821:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     826:	48 8b 91 d0 00 00 00 	mov    0xd0(%rcx),%rdx
     82d:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
     831:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     835:	c4 e2 75 90 3c 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm7
     83b:	c5 fd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm0
     840:	44 8b 91 10 01 00 00 	mov    0x110(%rcx),%r10d
     847:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
     84c:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     851:	c4 e2 75 40 c0       	vpmulld %ymm0,%ymm1,%ymm0
     856:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     85b:	44 8b 99 14 01 00 00 	mov    0x114(%rcx),%r11d
     862:	c4 c1 79 6e e3       	vmovd  %r11d,%xmm4
     867:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     86c:	c4 e2 5d 40 ed       	vpmulld %ymm5,%ymm4,%ymm5
     871:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
     876:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     87a:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
     87e:	48 8b 91 08 01 00 00 	mov    0x108(%rcx),%rdx
     885:	47 8d 54 1a 01       	lea    0x1(%r10,%r11,1),%r10d
     88a:	c4 c1 79 6e c2       	vmovd  %r10d,%xmm0
     88f:	c4 e2 7d 58 f0       	vpbroadcastd %xmm0,%ymm6
     894:	c5 55 fe c6          	vpaddd %ymm6,%ymm5,%ymm8
     898:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     89d:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     8a1:	c4 a2 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm8,4),%ymm0
     8a7:	c5 15 db c3          	vpand  %ymm3,%ymm13,%ymm8
     8ab:	c5 15 db ca          	vpand  %ymm2,%ymm13,%ymm9
     8af:	c4 c1 3d 66 d1       	vpcmpgtd %ymm9,%ymm8,%ymm2
     8b4:	c4 e3 75 4a d4 20    	vblendvps %ymm2,%ymm4,%ymm1,%ymm2
     8ba:	c4 42 35 3f d0       	vpmaxud %ymm8,%ymm9,%ymm10
     8bf:	c5 95 db ff          	vpand  %ymm7,%ymm13,%ymm7
     8c3:	c4 c1 45 66 da       	vpcmpgtd %ymm10,%ymm7,%ymm3
     8c8:	c4 c3 6d 4a d7 30    	vblendvps %ymm3,%ymm15,%ymm2,%ymm2
     8ce:	c5 d5 fe da          	vpaddd %ymm2,%ymm5,%ymm3
     8d2:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     8d7:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     8db:	c4 e2 25 90 14 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm2
     8e1:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     8e6:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     8ea:	c4 e2 25 90 1c aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm3
     8f0:	c4 41 35 66 d8       	vpcmpgtd %ymm8,%ymm9,%ymm11
     8f5:	c4 e3 75 4a cc b0    	vblendvps %ymm11,%ymm4,%ymm1,%ymm1
     8fb:	c4 42 35 3b d8       	vpminud %ymm8,%ymm9,%ymm11
     900:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
     904:	c4 43 75 4a e7 40    	vblendvps %ymm4,%ymm15,%ymm1,%ymm12
     90a:	c4 e2 2d 3f e7       	vpmaxud %ymm7,%ymm10,%ymm4
     90f:	c4 e2 25 3b cf       	vpminud %ymm7,%ymm11,%ymm1
     914:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     919:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     91e:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
     922:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     927:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
     92b:	c4 e2 35 90 2c b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm5
     931:	c5 bd fe f7          	vpaddd %ymm7,%ymm8,%ymm6
     935:	c5 dd fe f9          	vpaddd %ymm1,%ymm4,%ymm7
     939:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
     93d:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
     942:	c5 9d db fb          	vpand  %ymm3,%ymm12,%ymm7
     946:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
     94b:	c5 1d db ca          	vpand  %ymm2,%ymm12,%ymm9
     94f:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     953:	c4 e2 45 40 fc       	vpmulld %ymm4,%ymm7,%ymm7
     958:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     95c:	c5 1d db c5          	vpand  %ymm5,%ymm12,%ymm8
     960:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     965:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
     96a:	c5 1d db d0          	vpand  %ymm0,%ymm12,%ymm10
     96e:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
     973:	c4 62 3d 40 c1       	vpmulld %ymm1,%ymm8,%ymm8
     978:	c4 41 35 fe c0       	vpaddd %ymm8,%ymm9,%ymm8
     97d:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     981:	c5 8d fe ff          	vpaddd %ymm7,%ymm14,%ymm7
     985:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     98a:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 9d2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9d2>
     991:	00 
     992:	c4 42 65 00 c7       	vpshufb %ymm15,%ymm3,%ymm8
     997:	c4 42 6d 00 cf       	vpshufb %ymm15,%ymm2,%ymm9
     99c:	c4 42 55 00 d7       	vpshufb %ymm15,%ymm5,%ymm10
     9a1:	c4 42 7d 00 df       	vpshufb %ymm15,%ymm0,%ymm11
     9a6:	c4 41 25 fa da       	vpsubd %ymm10,%ymm11,%ymm11
     9ab:	c4 41 2d fa d1       	vpsubd %ymm9,%ymm10,%ymm10
     9b0:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
     9b5:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     9bb:	c4 62 35 40 cc       	vpmulld %ymm4,%ymm9,%ymm9
     9c0:	c4 62 2d 40 d6       	vpmulld %ymm6,%ymm10,%ymm10
     9c5:	c4 62 25 40 d9       	vpmulld %ymm1,%ymm11,%ymm11
     9ca:	c4 41 35 fe c0       	vpaddd %ymm8,%ymm9,%ymm8
     9cf:	c4 41 2d fe cb       	vpaddd %ymm11,%ymm10,%ymm9
     9d4:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     9d9:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
     9de:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     9e4:	c5 7d 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm15        # a6c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa6c>
     9eb:	00 
     9ec:	c4 c2 65 00 df       	vpshufb %ymm15,%ymm3,%ymm3
     9f1:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
     9f6:	c4 c2 6d 00 d7       	vpshufb %ymm15,%ymm2,%ymm2
     9fb:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
     9ff:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
     a04:	c5 b5 fe e3          	vpaddd %ymm3,%ymm9,%ymm4
     a08:	c4 c2 55 00 ef       	vpshufb %ymm15,%ymm5,%ymm5
     a0d:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     a11:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
     a16:	48 8b 91 20 01 00 00 	mov    0x120(%rcx),%rdx
     a1d:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
     a21:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
     a25:	c4 e2 4d 90 1c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm3
     a2b:	c4 c2 7d 00 c7       	vpshufb %ymm15,%ymm0,%ymm0
     a30:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
     a34:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
     a39:	48 8b 91 28 01 00 00 	mov    0x128(%rcx),%rdx
     a40:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
     a44:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     a48:	c4 a2 55 90 0c 82    	vpgatherdd %ymm5,(%rdx,%ymm8,4),%ymm1
     a4e:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     a52:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     a56:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
     a5a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     a5f:	48 8b 91 30 01 00 00 	mov    0x130(%rcx),%rdx
     a66:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     a6a:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
     a6e:	c4 e2 6d 90 24 82    	vpgatherdd %ymm2,(%rdx,%ymm0,4),%ymm4
     a74:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     a79:	44 8b 91 70 01 00 00 	mov    0x170(%rcx),%r10d
     a80:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
     a85:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     a8a:	c4 e2 6d 40 c0       	vpmulld %ymm0,%ymm2,%ymm0
     a8f:	c5 d5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm5
     a94:	44 8b 99 74 01 00 00 	mov    0x174(%rcx),%r11d
     a9b:	c4 c1 79 6e f3       	vmovd  %r11d,%xmm6
     aa0:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     aa5:	c4 e2 4d 40 ed       	vpmulld %ymm5,%ymm6,%ymm5
     aaa:	c5 c5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm7
     aaf:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     ab3:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
     ab7:	48 8b 91 68 01 00 00 	mov    0x168(%rcx),%rdx
     abe:	47 8d 54 1a 01       	lea    0x1(%r10,%r11,1),%r10d
     ac3:	c4 c1 79 6e c2       	vmovd  %r10d,%xmm0
     ac8:	c4 e2 7d 58 f8       	vpbroadcastd %xmm0,%ymm7
     acd:	c5 55 fe c7          	vpaddd %ymm7,%ymm5,%ymm8
     ad1:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     ad6:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     ada:	c4 a2 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm8,4),%ymm0
     ae0:	c5 15 db c1          	vpand  %ymm1,%ymm13,%ymm8
     ae4:	c5 15 db cb          	vpand  %ymm3,%ymm13,%ymm9
     ae8:	c4 c1 3d 66 c9       	vpcmpgtd %ymm9,%ymm8,%ymm1
     aed:	c4 e3 6d 4a ce 10    	vblendvps %ymm1,%ymm6,%ymm2,%ymm1
     af3:	c4 c2 35 3f d8       	vpmaxud %ymm8,%ymm9,%ymm3
     af8:	c5 15 db d4          	vpand  %ymm4,%ymm13,%ymm10
     afc:	c5 ad 66 e3          	vpcmpgtd %ymm3,%ymm10,%ymm4
     b00:	c5 7c 10 6c 24 60    	vmovups 0x60(%rsp),%ymm13
     b06:	c4 c3 75 4a cd 40    	vblendvps %ymm4,%ymm13,%ymm1,%ymm1
     b0c:	c5 d5 fe e1          	vpaddd %ymm1,%ymm5,%ymm4
     b10:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     b15:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     b19:	c4 e2 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm1
     b1f:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     b24:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
     b28:	c4 e2 25 90 24 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm4
     b2e:	c4 c2 65 3f da       	vpmaxud %ymm10,%ymm3,%ymm3
     b33:	c4 41 35 66 d8       	vpcmpgtd %ymm8,%ymm9,%ymm11
     b38:	c4 e3 6d 4a d6 b0    	vblendvps %ymm11,%ymm6,%ymm2,%ymm2
     b3e:	c4 c2 35 3b f0       	vpminud %ymm8,%ymm9,%ymm6
     b43:	c4 41 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm11
     b48:	c4 43 6d 4a dd b0    	vblendvps %ymm11,%ymm13,%ymm2,%ymm11
     b4e:	c4 c2 4d 3b d2       	vpminud %ymm10,%ymm6,%ymm2
     b53:	c4 c1 3d fe f1       	vpaddd %ymm9,%ymm8,%ymm6
     b58:	c5 ad fe f6          	vpaddd %ymm6,%ymm10,%ymm6
     b5c:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     b61:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
     b65:	c4 41 3d 76 c0       	vpcmpeqd %ymm8,%ymm8,%ymm8
     b6a:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
     b6e:	c4 e2 3d 90 2c ba    	vpgatherdd %ymm8,(%rdx,%ymm7,4),%ymm5
     b74:	c5 e5 fe fa          	vpaddd %ymm2,%ymm3,%ymm7
     b78:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
     b7c:	c5 9d db fc          	vpand  %ymm4,%ymm12,%ymm7
     b80:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
     b85:	c5 1d db c9          	vpand  %ymm1,%ymm12,%ymm9
     b89:	c5 b5 fa ff          	vpsubd %ymm7,%ymm9,%ymm7
     b8d:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
     b92:	c5 1d db d5          	vpand  %ymm5,%ymm12,%ymm10
     b96:	c4 41 2d fa c9       	vpsubd %ymm9,%ymm10,%ymm9
     b9b:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
     ba0:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     ba4:	c5 1d db c0          	vpand  %ymm0,%ymm12,%ymm8
     ba8:	c4 41 3d fa c2       	vpsubd %ymm10,%ymm8,%ymm8
     bad:	c4 62 3d 40 c2       	vpmulld %ymm2,%ymm8,%ymm8
     bb2:	c4 41 35 fe c0       	vpaddd %ymm8,%ymm9,%ymm8
     bb7:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     bbb:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # c03 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc03>
     bc2:	00 
     bc3:	c4 42 5d 00 c3       	vpshufb %ymm11,%ymm4,%ymm8
     bc8:	c4 42 75 00 cb       	vpshufb %ymm11,%ymm1,%ymm9
     bcd:	c4 41 35 fa d0       	vpsubd %ymm8,%ymm9,%ymm10
     bd2:	c4 62 2d 40 d3       	vpmulld %ymm3,%ymm10,%ymm10
     bd7:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
     bdd:	c4 41 2d fe c0       	vpaddd %ymm8,%ymm10,%ymm8
     be2:	c4 42 55 00 d3       	vpshufb %ymm11,%ymm5,%ymm10
     be7:	c4 41 2d fa c9       	vpsubd %ymm9,%ymm10,%ymm9
     bec:	c4 42 7d 00 db       	vpshufb %ymm11,%ymm0,%ymm11
     bf1:	c4 41 25 fa d2       	vpsubd %ymm10,%ymm11,%ymm10
     bf6:	c4 62 35 40 ce       	vpmulld %ymm6,%ymm9,%ymm9
     bfb:	c4 62 2d 40 d2       	vpmulld %ymm2,%ymm10,%ymm10
     c00:	c4 41 35 fe ca       	vpaddd %ymm10,%ymm9,%ymm9
     c05:	c4 41 3d fe c1       	vpaddd %ymm9,%ymm8,%ymm8
     c0a:	c4 c2 5d 00 e7       	vpshufb %ymm15,%ymm4,%ymm4
     c0f:	c4 c2 75 00 cf       	vpshufb %ymm15,%ymm1,%ymm1
     c14:	c5 75 fa cc          	vpsubd %ymm4,%ymm1,%ymm9
     c18:	c4 e2 35 40 db       	vpmulld %ymm3,%ymm9,%ymm3
     c1d:	c5 dd 72 f4 10       	vpslld $0x10,%ymm4,%ymm4
     c22:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     c26:	c4 c2 55 00 e7       	vpshufb %ymm15,%ymm5,%ymm4
     c2b:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
     c2f:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     c34:	c4 c2 7d 00 c7       	vpshufb %ymm15,%ymm0,%ymm0
     c39:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
     c3d:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
     c42:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     c46:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     c4a:	c5 8d fe cf          	vpaddd %ymm7,%ymm14,%ymm1
     c4e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     c53:	c4 c1 3d fe d6       	vpaddd %ymm14,%ymm8,%ymm2
     c58:	c4 e2 6d 00 15 a0 00 	vpshufb 0xa0(%rip),%ymm2,%ymm2        # d01 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd01>
     c5f:	00 00 
     c61:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
     c65:	c4 e3 75 0e c0 aa    	vpblendw $0xaa,%ymm0,%ymm1,%ymm0
     c6b:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
     c6f:	c4 e2 7d 00 05 c0 00 	vpshufb 0xc0(%rip),%ymm0,%ymm0        # d38 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd38>
     c76:	00 00 
     c78:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
     c7e:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     c83:	c5 f9 eb c2          	vpor   %xmm2,%xmm0,%xmm0
     c87:	c4 c1 7a 7f 40 f0    	vmovdqu %xmm0,-0x10(%r8)
     c8d:	c5 f9 70 c1 e9       	vpshufd $0xe9,%xmm1,%xmm0
     c92:	c4 c1 79 d6 00       	vmovq  %xmm0,(%r8)
     c97:	48 83 c0 08          	add    $0x8,%rax
     c9b:	49 83 c0 18          	add    $0x18,%r8
     c9f:	4c 39 c8             	cmp    %r9,%rax
     ca2:	0f 82 58 f4 ff ff    	jb     100 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x100>
     ca8:	e9 2c 08 00 00       	jmp    14d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d9>
     cad:	4d 85 c9             	test   %r9,%r9
     cb0:	0f 84 23 08 00 00    	je     14d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d9>
     cb6:	48 85 d2             	test   %rdx,%rdx
     cb9:	0f 84 13 07 00 00    	je     13d2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13d2>
     cbf:	48 83 c1 58          	add    $0x58,%rcx
     cc3:	31 c0                	xor    %eax,%eax
     cc5:	c4 e2 7d 58 05 20 00 	vpbroadcastd 0x20(%rip),%ymm0        # cee <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcee>
     ccc:	00 00 
     cce:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
     cd3:	c5 7d 6f 15 40 00 00 	vmovdqa 0x40(%rip),%ymm10        # d1b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd1b>
     cda:	00 
     cdb:	c5 7d 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm12        # d63 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd63>
     ce2:	00 
     ce3:	c4 62 7d 58 0d 68 00 	vpbroadcastd 0x68(%rip),%ymm9        # d54 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd54>
     cea:	00 00 
     cec:	c5 7e 7f 8c 24 a0 00 	vmovdqu %ymm9,0xa0(%rsp)
     cf3:	00 00 
     cf5:	eb 58                	jmp    d4f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd4f>
     cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     cfe:	00 00 
     d00:	c4 c1 75 72 f7 08    	vpslld $0x8,%ymm15,%ymm1
     d06:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     d0a:	c4 e3 6d 0e c0 aa    	vpblendw $0xaa,%ymm0,%ymm2,%ymm0
     d10:	c5 8d eb c0          	vpor   %ymm0,%ymm14,%ymm0
     d14:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
     d18:	c4 e2 7d 00 05 c0 00 	vpshufb 0xc0(%rip),%ymm0,%ymm0        # de1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde1>
     d1f:	00 00 
     d21:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
     d27:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     d2c:	c5 f9 eb c2          	vpor   %xmm2,%xmm0,%xmm0
     d30:	c4 81 7a 7f 04 10    	vmovdqu %xmm0,(%r8,%r10,1)
     d36:	c5 f9 70 c1 e9       	vpshufd $0xe9,%xmm1,%xmm0
     d3b:	c4 81 79 d6 44 10 10 	vmovq  %xmm0,0x10(%r8,%r10,1)
     d42:	48 83 c0 08          	add    $0x8,%rax
     d46:	4c 39 c8             	cmp    %r9,%rax
     d49:	0f 83 8a 07 00 00    	jae    14d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d9>
     d4f:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
     d53:	c4 81 7a 7e 44 10 10 	vmovq  0x10(%r8,%r10,1),%xmm0
     d5a:	c4 81 7a 6f 0c 10    	vmovdqu (%r8,%r10,1),%xmm1
     d60:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
     d66:	c4 e3 75 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
     d6c:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # d75 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd75>
     d73:	00 00 
     d75:	c5 7d db 34 24       	vpand  (%rsp),%ymm0,%ymm14
     d7a:	c4 42 7d 00 fa       	vpshufb %ymm10,%ymm0,%ymm15
     d7f:	49 89 cb             	mov    %rcx,%r11
     d82:	48 89 d6             	mov    %rdx,%rsi
     d85:	e9 b4 01 00 00       	jmp    f3e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf3e>
     d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     d90:	c4 e2 7d 58 3d 60 00 	vpbroadcastd 0x60(%rip),%ymm7        # df9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdf9>
     d97:	00 00 
     d99:	c5 dd db e7          	vpand  %ymm7,%ymm4,%ymm4
     d9d:	c5 f5 db f7          	vpand  %ymm7,%ymm1,%ymm6
     da1:	c5 dd 66 ce          	vpcmpgtd %ymm6,%ymm4,%ymm1
     da5:	c4 e3 7d 4a cb 10    	vblendvps %ymm1,%ymm3,%ymm0,%ymm1
     dab:	c4 62 4d 3f c4       	vpmaxud %ymm4,%ymm6,%ymm8
     db0:	c5 ed db ff          	vpand  %ymm7,%ymm2,%ymm7
     db4:	c4 c1 45 66 d0       	vpcmpgtd %ymm8,%ymm7,%ymm2
     db9:	c4 62 7d 18 0d 64 00 	vbroadcastss 0x64(%rip),%ymm9        # e26 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe26>
     dc0:	00 00 
     dc2:	c4 c3 75 4a c9 20    	vblendvps %ymm2,%ymm9,%ymm1,%ymm1
     dc8:	c5 cd 66 d4          	vpcmpgtd %ymm4,%ymm6,%ymm2
     dcc:	c4 e3 7d 4a d3 20    	vblendvps %ymm2,%ymm3,%ymm0,%ymm2
     dd2:	c5 95 fe c9          	vpaddd %ymm1,%ymm13,%ymm1
     dd6:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     dda:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
     ddf:	c4 62 65 90 1c 8f    	vpgatherdd %ymm3,(%rdi,%ymm1,4),%ymm11
     de5:	c4 62 4d 3b d4       	vpminud %ymm4,%ymm6,%ymm10
     dea:	c5 ad 66 cf          	vpcmpgtd %ymm7,%ymm10,%ymm1
     dee:	c4 c3 6d 4a c9 10    	vblendvps %ymm1,%ymm9,%ymm2,%ymm1
     df4:	c5 d5 fa c9          	vpsubd %ymm1,%ymm5,%ymm1
     df8:	c5 95 fe d1          	vpaddd %ymm1,%ymm13,%ymm2
     dfc:	c5 e5 76 db          	vpcmpeqd %ymm3,%ymm3,%ymm3
     e00:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     e04:	c4 e2 65 90 0c 97    	vpgatherdd %ymm3,(%rdi,%ymm2,4),%ymm1
     e0a:	c4 e2 3d 3f df       	vpmaxud %ymm7,%ymm8,%ymm3
     e0f:	c4 e2 2d 3b d7       	vpminud %ymm7,%ymm10,%ymm2
     e14:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     e18:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     e1c:	c5 e5 fe ea          	vpaddd %ymm2,%ymm3,%ymm5
     e20:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     e24:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     e2b:	00 00 
     e2d:	c5 d5 72 f7 10       	vpslld $0x10,%ymm7,%ymm5
     e32:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
     e37:	c5 a5 db f0          	vpand  %ymm0,%ymm11,%ymm6
     e3b:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     e3f:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
     e44:	c5 c5 fe ed          	vpaddd %ymm5,%ymm7,%ymm5
     e48:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
     e4c:	c5 c5 fa f6          	vpsubd %ymm6,%ymm7,%ymm6
     e50:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
     e57:	00 00 
     e59:	c5 fd fa ff          	vpsubd %ymm7,%ymm0,%ymm7
     e5d:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
     e62:	c4 e2 45 40 fa       	vpmulld %ymm2,%ymm7,%ymm7
     e67:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     e6b:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     e6f:	c5 7e 6f 84 24 00 01 	vmovdqu 0x100(%rsp),%ymm8
     e76:	00 00 
     e78:	c4 c1 4d 72 f0 10    	vpslld $0x10,%ymm8,%ymm6
     e7e:	c5 7d 6f 15 40 00 00 	vmovdqa 0x40(%rip),%ymm10        # ec6 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xec6>
     e85:	00 
     e86:	c4 c2 25 00 fa       	vpshufb %ymm10,%ymm11,%ymm7
     e8b:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     e90:	c4 62 3d 40 c3       	vpmulld %ymm3,%ymm8,%ymm8
     e95:	c5 bd fe f6          	vpaddd %ymm6,%ymm8,%ymm6
     e99:	c4 42 75 00 c2       	vpshufb %ymm10,%ymm1,%ymm8
     e9e:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
     ea2:	c5 7e 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm9
     ea9:	00 00 
     eab:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
     eb0:	c4 e2 45 40 fc       	vpmulld %ymm4,%ymm7,%ymm7
     eb5:	c4 62 3d 40 c2       	vpmulld %ymm2,%ymm8,%ymm8
     eba:	c5 bd fe ff          	vpaddd %ymm7,%ymm8,%ymm7
     ebe:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     ec2:	c5 7e 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm9
     ec9:	00 00 
     ecb:	c5 35 fe ed          	vpaddd %ymm5,%ymm9,%ymm13
     ecf:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
     ed3:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     ed9:	c4 c2 7d 00 fc       	vpshufb %ymm12,%ymm0,%ymm7
     ede:	c5 bd 72 f7 10       	vpslld $0x10,%ymm7,%ymm8
     ee3:	c4 c2 25 00 c4       	vpshufb %ymm12,%ymm11,%ymm0
     ee8:	c5 fd fa ff          	vpsubd %ymm7,%ymm0,%ymm7
     eec:	c4 e2 45 40 db       	vpmulld %ymm3,%ymm7,%ymm3
     ef1:	c4 c2 75 00 cc       	vpshufb %ymm12,%ymm1,%ymm1
     ef6:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
     efa:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     eff:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
     f03:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     f07:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
     f0e:	00 00 
     f10:	c4 c2 65 00 dc       	vpshufb %ymm12,%ymm3,%ymm3
     f15:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
     f19:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     f1e:	c5 b5 fe c9          	vpaddd %ymm1,%ymm9,%ymm1
     f22:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     f26:	c4 c1 0d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm14
     f2c:	c5 85 72 d6 10       	vpsrld $0x10,%ymm6,%ymm15
     f31:	49 83 c3 60          	add    $0x60,%r11
     f35:	48 ff ce             	dec    %rsi
     f38:	0f 84 c2 fd ff ff    	je     d00 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd00>
     f3e:	49 8b 7b a8          	mov    -0x58(%r11),%rdi
     f42:	49 8b 5b b0          	mov    -0x50(%r11),%rbx
     f46:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     f4a:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
     f4e:	c4 a2 6d 90 0c b7    	vpgatherdd %ymm2,(%rdi,%ymm14,4),%ymm1
     f54:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
     f58:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
     f5c:	c4 a2 6d 90 24 bb    	vpgatherdd %ymm2,(%rbx,%ymm15,4),%ymm4
     f62:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     f67:	49 8b 7b b8          	mov    -0x48(%r11),%rdi
     f6b:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     f6f:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
     f73:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
     f79:	c4 e2 7d 90 14 9f    	vpgatherdd %ymm0,(%rdi,%ymm3,4),%ymm2
     f7f:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
     f84:	41 8b 5b f8          	mov    -0x8(%r11),%ebx
     f88:	c5 f9 6e c3          	vmovd  %ebx,%xmm0
     f8c:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     f91:	c4 e2 7d 40 eb       	vpmulld %ymm3,%ymm0,%ymm5
     f96:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
     f9b:	45 8b 73 fc          	mov    -0x4(%r11),%r14d
     f9f:	c4 c1 79 6e de       	vmovd  %r14d,%xmm3
     fa4:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     fa9:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
     fae:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
     fb3:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     fb7:	c5 55 fe ee          	vpaddd %ymm6,%ymm5,%ymm13
     fbb:	49 8b 7b f0          	mov    -0x10(%r11),%rdi
     fbf:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
     fc3:	c4 41 39 ef c0       	vpxor  %xmm8,%xmm8,%xmm8
     fc8:	c4 22 55 90 04 af    	vpgatherdd %ymm5,(%rdi,%ymm13,4),%ymm8
     fce:	42 8d 5c 33 01       	lea    0x1(%rbx,%r14,1),%ebx
     fd3:	c5 f9 6e eb          	vmovd  %ebx,%xmm5
     fd7:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     fdc:	c5 15 fe dd          	vpaddd %ymm5,%ymm13,%ymm11
     fe0:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
     fe5:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
     fe9:	c4 a2 35 90 3c 9f    	vpgatherdd %ymm9,(%rdi,%ymm11,4),%ymm7
     fef:	41 80 3b 00          	cmpb   $0x0,(%r11)
     ff3:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     ff8:	c5 3d db ce          	vpand  %ymm6,%ymm8,%ymm9
     ffc:	c5 7e 7f 8c 24 c0 00 	vmovdqu %ymm9,0xc0(%rsp)
    1003:	00 00 
    1005:	c5 c5 db f6          	vpand  %ymm6,%ymm7,%ymm6
    1009:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1010:	00 00 
    1012:	c5 7e 7f 44 24 60    	vmovdqu %ymm8,0x60(%rsp)
    1018:	c4 c2 3d 00 f2       	vpshufb %ymm10,%ymm8,%ymm6
    101d:	c5 fe 7f b4 24 00 01 	vmovdqu %ymm6,0x100(%rsp)
    1024:	00 00 
    1026:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
    102d:	00 00 
    102f:	c4 c2 45 00 f2       	vpshufb %ymm10,%ymm7,%ymm6
    1034:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
    103b:	00 00 
    103d:	0f 85 4d fd ff ff    	jne    d90 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd90>
    1043:	c4 62 7d 58 25 60 00 	vpbroadcastd 0x60(%rip),%ymm12        # 10ac <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10ac>
    104a:	00 00 
    104c:	c5 9d db e9          	vpand  %ymm1,%ymm12,%ymm5
    1050:	c5 9d db f4          	vpand  %ymm4,%ymm12,%ymm6
    1054:	c5 9d db fa          	vpand  %ymm2,%ymm12,%ymm7
    1058:	c5 cd 66 cd          	vpcmpgtd %ymm5,%ymm6,%ymm1
    105c:	c4 e3 7d 4a d3 10    	vblendvps %ymm1,%ymm3,%ymm0,%ymm2
    1062:	c4 e2 55 3f ce       	vpmaxud %ymm6,%ymm5,%ymm1
    1067:	c5 fe 7f 8c 24 00 02 	vmovdqu %ymm1,0x200(%rsp)
    106e:	00 00 
    1070:	c5 c5 66 e1          	vpcmpgtd %ymm1,%ymm7,%ymm4
    1074:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    107b:	00 00 
    107d:	c4 e2 7d 18 0d 64 00 	vbroadcastss 0x64(%rip),%ymm1        # 10ea <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x10ea>
    1084:	00 00 
    1086:	c4 e3 6d 4a d1 40    	vblendvps %ymm4,%ymm1,%ymm2,%ymm2
    108c:	c5 95 fe d2          	vpaddd %ymm2,%ymm13,%ymm2
    1090:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    1094:	c4 41 39 ef c0       	vpxor  %xmm8,%xmm8,%xmm8
    1099:	c4 62 5d 90 04 97    	vpgatherdd %ymm4,(%rdi,%ymm2,4),%ymm8
    109f:	c5 7e 7f 84 24 e0 01 	vmovdqu %ymm8,0x1e0(%rsp)
    10a6:	00 00 
    10a8:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
    10af:	00 00 
    10b1:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    10b7:	c5 d5 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm2
    10bb:	c4 e3 7d 4a d3 20    	vblendvps %ymm2,%ymm3,%ymm0,%ymm2
    10c1:	c4 e2 55 3b e6       	vpminud %ymm6,%ymm5,%ymm4
    10c6:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
    10cd:	00 00 
    10cf:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
    10d3:	c4 e3 6d 4a d1 40    	vblendvps %ymm4,%ymm1,%ymm2,%ymm2
    10d9:	c5 a5 fa d2          	vpsubd %ymm2,%ymm11,%ymm2
    10dd:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    10e1:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
    10e5:	c4 e2 5d 90 2c 97    	vpgatherdd %ymm4,(%rdi,%ymm2,4),%ymm5
    10eb:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
    10f2:	00 00 
    10f4:	49 8b 5b c0          	mov    -0x40(%r11),%rbx
    10f8:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    10fc:	c5 d9 ef e4          	vpxor  %xmm4,%xmm4,%xmm4
    1100:	c4 a2 6d 90 24 b3    	vpgatherdd %ymm2,(%rbx,%ymm14,4),%ymm4
    1106:	49 8b 5b c8          	mov    -0x38(%r11),%rbx
    110a:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    110e:	c4 41 29 ef d2       	vpxor  %xmm10,%xmm10,%xmm10
    1113:	c4 22 6d 90 14 bb    	vpgatherdd %ymm2,(%rbx,%ymm15,4),%ymm10
    1119:	49 8b 5b d0          	mov    -0x30(%r11),%rbx
    111d:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
    1121:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    1126:	c5 7e 7f 9c 24 20 02 	vmovdqu %ymm11,0x220(%rsp)
    112d:	00 00 
    112f:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
    1134:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
    113a:	c4 22 6d 90 1c 8b    	vpgatherdd %ymm2,(%rbx,%ymm9,4),%ymm11
    1140:	c5 9d db e4          	vpand  %ymm4,%ymm12,%ymm4
    1144:	c4 41 2d db d4       	vpand  %ymm12,%ymm10,%ymm10
    1149:	c4 c1 25 db f4       	vpand  %ymm12,%ymm11,%ymm6
    114e:	c5 ad 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm2
    1152:	c4 e3 7d 4a d3 20    	vblendvps %ymm2,%ymm3,%ymm0,%ymm2
    1158:	c4 c2 5d 3f ea       	vpmaxud %ymm10,%ymm4,%ymm5
    115d:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    1164:	00 00 
    1166:	c5 cd 66 ed          	vpcmpgtd %ymm5,%ymm6,%ymm5
    116a:	c5 fe 7f b4 24 40 02 	vmovdqu %ymm6,0x240(%rsp)
    1171:	00 00 
    1173:	c4 e3 6d 4a d1 50    	vblendvps %ymm5,%ymm1,%ymm2,%ymm2
    1179:	c5 95 fe d2          	vpaddd %ymm2,%ymm13,%ymm2
    117d:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    1181:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
    1185:	c4 e2 55 90 3c 97    	vpgatherdd %ymm5,(%rdi,%ymm2,4),%ymm7
    118b:	c5 fe 7f bc 24 80 02 	vmovdqu %ymm7,0x280(%rsp)
    1192:	00 00 
    1194:	c4 c1 5d 66 d2       	vpcmpgtd %ymm10,%ymm4,%ymm2
    1199:	c4 e3 7d 4a d3 20    	vblendvps %ymm2,%ymm3,%ymm0,%ymm2
    119f:	c4 c2 5d 3b ea       	vpminud %ymm10,%ymm4,%ymm5
    11a4:	c5 fe 7f ac 24 60 02 	vmovdqu %ymm5,0x260(%rsp)
    11ab:	00 00 
    11ad:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    11b1:	c4 e3 6d 4a d1 50    	vblendvps %ymm5,%ymm1,%ymm2,%ymm2
    11b7:	c5 bd fa ea          	vpsubd %ymm2,%ymm8,%ymm5
    11bb:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    11bf:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
    11c3:	c4 e2 45 90 14 af    	vpgatherdd %ymm7,(%rdi,%ymm5,4),%ymm2
    11c9:	49 8b 5b d8          	mov    -0x28(%r11),%rbx
    11cd:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    11d1:	c5 c1 ef ff          	vpxor  %xmm7,%xmm7,%xmm7
    11d5:	c4 a2 55 90 3c b3    	vpgatherdd %ymm5,(%rbx,%ymm14,4),%ymm7
    11db:	49 8b 5b e0          	mov    -0x20(%r11),%rbx
    11df:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    11e3:	c4 41 39 ef c0       	vpxor  %xmm8,%xmm8,%xmm8
    11e8:	c4 22 55 90 04 bb    	vpgatherdd %ymm5,(%rbx,%ymm15,4),%ymm8
    11ee:	49 8b 5b e8          	mov    -0x18(%r11),%rbx
    11f2:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    11f6:	c5 c9 ef f6          	vpxor  %xmm6,%xmm6,%xmm6
    11fa:	c4 a2 55 90 34 8b    	vpgatherdd %ymm5,(%rbx,%ymm9,4),%ymm6
    1200:	c5 1d db f7          	vpand  %ymm7,%ymm12,%ymm14
    1204:	c4 41 3d db fc       	vpand  %ymm12,%ymm8,%ymm15
    1209:	c4 c1 05 66 ee       	vpcmpgtd %ymm14,%ymm15,%ymm5
    120e:	c4 e3 7d 4a eb 50    	vblendvps %ymm5,%ymm3,%ymm0,%ymm5
    1214:	c4 c1 0d 66 ff       	vpcmpgtd %ymm15,%ymm14,%ymm7
    1219:	c4 e3 7d 4a fb 70    	vblendvps %ymm7,%ymm3,%ymm0,%ymm7
    121f:	c5 1d db e6          	vpand  %ymm6,%ymm12,%ymm12
    1223:	c4 c2 0d 3f df       	vpmaxud %ymm15,%ymm14,%ymm3
    1228:	c5 9d 66 c3          	vpcmpgtd %ymm3,%ymm12,%ymm0
    122c:	c4 e3 55 4a c1 00    	vblendvps %ymm0,%ymm1,%ymm5,%ymm0
    1232:	c5 95 fe e8          	vpaddd %ymm0,%ymm13,%ymm5
    1236:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    123a:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
    123f:	c4 62 4d 90 1c af    	vpgatherdd %ymm6,(%rdi,%ymm5,4),%ymm11
    1245:	c4 c2 0d 3b c7       	vpminud %ymm15,%ymm14,%ymm0
    124a:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    1250:	c4 c1 7d 66 ec       	vpcmpgtd %ymm12,%ymm0,%ymm5
    1255:	c4 e3 45 4a c9 50    	vblendvps %ymm5,%ymm1,%ymm7,%ymm1
    125b:	c5 fe 6f 84 24 20 02 	vmovdqu 0x220(%rsp),%ymm0
    1262:	00 00 
    1264:	c5 fd fa e9          	vpsubd %ymm1,%ymm0,%ymm5
    1268:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    126c:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    1270:	c4 e2 4d 90 0c af    	vpgatherdd %ymm6,(%rdi,%ymm5,4),%ymm1
    1276:	c5 fe 6f 84 24 80 01 	vmovdqu 0x180(%rsp),%ymm0
    127d:	00 00 
    127f:	c5 fd fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm0,%ymm5
    1285:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    128c:	00 00 
    128e:	c4 e2 7d 3f b4 24 00 	vpmaxud 0x200(%rsp),%ymm0,%ymm6
    1295:	02 00 00 
    1298:	c4 e2 7d 3b bc 24 a0 	vpminud 0x1a0(%rsp),%ymm0,%ymm7
    129f:	01 00 00 
    12a2:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    12a6:	c5 45 fe c6          	vpaddd %ymm6,%ymm7,%ymm8
    12aa:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    12af:	c5 fe 6f 84 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm0
    12b6:	00 00 
    12b8:	c5 7d db 04 24       	vpand  (%rsp),%ymm0,%ymm8
    12bd:	c5 fe 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm0
    12c4:	00 00 
    12c6:	c5 3d fa c8          	vpsubd %ymm0,%ymm8,%ymm9
    12ca:	c4 e2 35 40 f6       	vpmulld %ymm6,%ymm9,%ymm6
    12cf:	c5 b5 72 f0 10       	vpslld $0x10,%ymm0,%ymm9
    12d4:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
    12d8:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
    12df:	00 00 
    12e1:	c5 7d db 0c 24       	vpand  (%rsp),%ymm0,%ymm9
    12e6:	c4 41 35 fa c0       	vpsubd %ymm8,%ymm9,%ymm8
    12eb:	c4 e2 3d 40 ed       	vpmulld %ymm5,%ymm8,%ymm5
    12f0:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
    12f4:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
    12fb:	00 00 
    12fd:	c4 c1 7d fa f1       	vpsubd %ymm9,%ymm0,%ymm6
    1302:	c4 e2 4d 40 f7       	vpmulld %ymm7,%ymm6,%ymm6
    1307:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
    130e:	00 00 
    1310:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    1314:	c5 55 fe ee          	vpaddd %ymm6,%ymm5,%ymm13
    1318:	c5 ad fe e4          	vpaddd %ymm4,%ymm10,%ymm4
    131c:	c5 fe 6f ac 24 40 02 	vmovdqu 0x240(%rsp),%ymm5
    1323:	00 00 
    1325:	c4 e2 55 3f b4 24 40 	vpmaxud 0x140(%rsp),%ymm5,%ymm6
    132c:	01 00 00 
    132f:	c4 e2 55 3b bc 24 60 	vpminud 0x260(%rsp),%ymm5,%ymm7
    1336:	02 00 00 
    1339:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    133d:	c5 45 fe c6          	vpaddd %ymm6,%ymm7,%ymm8
    1341:	c4 c1 5d fa e0       	vpsubd %ymm8,%ymm4,%ymm4
    1346:	c5 7d 6f 15 40 00 00 	vmovdqa 0x40(%rip),%ymm10        # 138e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138e>
    134d:	00 
    134e:	c5 fe 6f ac 24 80 02 	vmovdqu 0x280(%rsp),%ymm5
    1355:	00 00 
    1357:	c4 42 55 00 c2       	vpshufb %ymm10,%ymm5,%ymm8
    135c:	c5 fe 6f ac 24 00 01 	vmovdqu 0x100(%rsp),%ymm5
    1363:	00 00 
    1365:	c5 3d fa cd          	vpsubd %ymm5,%ymm8,%ymm9
    1369:	c4 e2 35 40 f6       	vpmulld %ymm6,%ymm9,%ymm6
    136e:	c5 b5 72 f5 10       	vpslld $0x10,%ymm5,%ymm9
    1373:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
    1377:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
    137b:	c4 c2 6d 00 d2       	vpshufb %ymm10,%ymm2,%ymm2
    1380:	c4 41 6d fa c0       	vpsubd %ymm8,%ymm2,%ymm8
    1385:	c4 e2 3d 40 e4       	vpmulld %ymm4,%ymm8,%ymm4
    138a:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    138e:	c5 fe 6f 84 24 20 01 	vmovdqu 0x120(%rsp),%ymm0
    1395:	00 00 
    1397:	c5 fd fa d2          	vpsubd %ymm2,%ymm0,%ymm2
    139b:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    13a0:	c5 b5 fe d2          	vpaddd %ymm2,%ymm9,%ymm2
    13a4:	c5 dd fe f2          	vpaddd %ymm2,%ymm4,%ymm6
    13a8:	c4 c1 05 fe e6       	vpaddd %ymm14,%ymm15,%ymm4
    13ad:	c4 c2 65 3f dc       	vpmaxud %ymm12,%ymm3,%ymm3
    13b2:	c4 e2 1d 3b 54 24 40 	vpminud 0x40(%rsp),%ymm12,%ymm2
    13b9:	c5 9d fe e4          	vpaddd %ymm4,%ymm12,%ymm4
    13bd:	c5 7d 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm12        # 1445 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1445>
    13c4:	00 
    13c5:	c5 ed fe fb          	vpaddd %ymm3,%ymm2,%ymm7
    13c9:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    13cd:	e9 01 fb ff ff       	jmp    ed3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xed3>
    13d2:	49 8d 49 ff          	lea    -0x1(%r9),%rcx
    13d6:	49 83 f9 09          	cmp    $0x9,%r9
    13da:	73 07                	jae    13e3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13e3>
    13dc:	31 c0                	xor    %eax,%eax
    13de:	e9 ad 00 00 00       	jmp    1490 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1490>
    13e3:	48 89 ca             	mov    %rcx,%rdx
    13e6:	48 c1 ea 03          	shr    $0x3,%rdx
    13ea:	48 ff c2             	inc    %rdx
    13ed:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    13f1:	31 c0                	xor    %eax,%eax
    13f3:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    13f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    13fe:	00 00 
    1400:	c4 c1 7a 7e 4c 00 10 	vmovq  0x10(%r8,%rax,1),%xmm1
    1407:	c4 c1 7a 6f 14 00    	vmovdqu (%r8,%rax,1),%xmm2
    140d:	c4 c1 7a 6f 5c 00 18 	vmovdqu 0x18(%r8,%rax,1),%xmm3
    1414:	c4 e3 71 0f ca 0c    	vpalignr $0xc,%xmm2,%xmm1,%xmm1
    141a:	c4 e3 6d 38 c9 01    	vinserti128 $0x1,%xmm1,%ymm2,%ymm1
    1420:	c4 e3 75 02 c8 88    	vpblendd $0x88,%ymm0,%ymm1,%ymm1
    1426:	c4 e3 7d 39 ca 01    	vextracti128 $0x1,%ymm1,%xmm2
    142c:	c5 d9 73 fa 0c       	vpslldq $0xc,%xmm2,%xmm4
    1431:	c5 f1 eb cc          	vpor   %xmm4,%xmm1,%xmm1
    1435:	c4 c1 7a 7f 0c 00    	vmovdqu %xmm1,(%r8,%rax,1)
    143b:	c5 f9 70 ca e9       	vpshufd $0xe9,%xmm2,%xmm1
    1440:	c4 c1 79 d6 4c 00 10 	vmovq  %xmm1,0x10(%r8,%rax,1)
    1447:	c4 c1 7a 7e 4c 00 28 	vmovq  0x28(%r8,%rax,1),%xmm1
    144e:	c4 e3 71 0f cb 0c    	vpalignr $0xc,%xmm3,%xmm1,%xmm1
    1454:	c4 e3 65 38 c9 01    	vinserti128 $0x1,%xmm1,%ymm3,%ymm1
    145a:	c4 e3 75 02 c8 88    	vpblendd $0x88,%ymm0,%ymm1,%ymm1
    1460:	c4 e3 7d 39 ca 01    	vextracti128 $0x1,%ymm1,%xmm2
    1466:	c5 e1 73 fa 0c       	vpslldq $0xc,%xmm2,%xmm3
    146b:	c5 f1 eb cb          	vpor   %xmm3,%xmm1,%xmm1
    146f:	c4 c1 7a 7f 4c 00 18 	vmovdqu %xmm1,0x18(%r8,%rax,1)
    1476:	c5 f9 70 ca e9       	vpshufd $0xe9,%xmm2,%xmm1
    147b:	c4 c1 79 d6 4c 00 28 	vmovq  %xmm1,0x28(%r8,%rax,1)
    1482:	48 83 c0 30          	add    $0x30,%rax
    1486:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
    148a:	0f 85 70 ff ff ff    	jne    1400 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1400>
    1490:	f6 c1 08             	test   $0x8,%cl
    1493:	75 44                	jne    14d9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x14d9>
    1495:	c4 c1 7a 7e 44 00 10 	vmovq  0x10(%r8,%rax,1),%xmm0
    149c:	c4 c1 7a 6f 0c 00    	vmovdqu (%r8,%rax,1),%xmm1
    14a2:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
    14a8:	c4 e3 75 38 c0 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
    14ae:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    14b2:	c4 e3 7d 02 c1 88    	vpblendd $0x88,%ymm1,%ymm0,%ymm0
    14b8:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
    14be:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
    14c3:	c5 f9 eb c2          	vpor   %xmm2,%xmm0,%xmm0
    14c7:	c4 c1 7a 7f 04 00    	vmovdqu %xmm0,(%r8,%rax,1)
    14cd:	c5 f9 70 c1 e9       	vpshufd $0xe9,%xmm1,%xmm0
    14d2:	c4 c1 79 d6 44 00 10 	vmovq  %xmm0,0x10(%r8,%rax,1)
    14d9:	c5 f8 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm6
    14e0:	00 00 
    14e2:	c5 f8 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm7
    14e9:	00 00 
    14eb:	c5 78 28 84 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm8
    14f2:	00 00 
    14f4:	c5 78 28 8c 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm9
    14fb:	00 00 
    14fd:	c5 78 28 94 24 e0 02 	vmovaps 0x2e0(%rsp),%xmm10
    1504:	00 00 
    1506:	c5 78 28 9c 24 f0 02 	vmovaps 0x2f0(%rsp),%xmm11
    150d:	00 00 
    150f:	c5 78 28 a4 24 00 03 	vmovaps 0x300(%rsp),%xmm12
    1516:	00 00 
    1518:	c5 78 28 ac 24 10 03 	vmovaps 0x310(%rsp),%xmm13
    151f:	00 00 
    1521:	c5 78 28 b4 24 20 03 	vmovaps 0x320(%rsp),%xmm14
    1528:	00 00 
    152a:	c5 78 28 bc 24 30 03 	vmovaps 0x330(%rsp),%xmm15
    1531:	00 00 
    1533:	48 81 c4 48 03 00 00 	add    $0x348,%rsp
    153a:	5b                   	pop    %rbx
    153b:	5f                   	pop    %rdi
    153c:	5e                   	pop    %rsi
    153d:	41 5e                	pop    %r14
    153f:	c5 f8 77             	vzeroupper
    1542:	c3                   	ret
