# Empty dependencies file for jshc_skylake_prefetchw.
# This may be replaced when dependencies are built.
