# 293/294 V2归档器首执行失败记录

本记录为工具exec回执的文字转录，不是事先重定向保存的本地原始stderr。两份post脚本AST通过，随后唯一执行`python -X utf8 scripts/archive_direct_cache2_perf_v2.py`，退出码1。此记录不代表修复或重跑。

工具回执原文：

```text
AST通过：2份封存/核对脚本
Traceback (most recent call last):
  File "F:\Hackathon\worktrees\p16-tail-20261023\scripts\archive_direct_cache2_perf_v2.py", line 90, in <module>
    if __name__=='__main__':main()
                            ^^^^^^
  File "F:\Hackathon\worktrees\p16-tail-20261023\scripts\archive_direct_cache2_perf_v2.py", line 47, in main
    for relative in MEASURED:assert sha(ROOT/relative)==plan['sources_sha256'][relative],relative
                                                        ~~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^
KeyError: 'experiments/p16-direct-cache2-performance-protocol-v2.md'
```

异常发生在输出目录创建和ZIP步骤之前。已执行归档器、Git核对器、四份测量源及正式计划均保留原字节；未自动修复、重复封存、stage或commit。阶段文档未更新成封存成功。
