
artifacts\skylake-suffix-cache-build-v1\CMakeFiles\jshc_skylake_suffix_cache.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)>:
       0:	56                   	push   %rsi
       1:	53                   	push   %rbx
       2:	48 81 ec 08 03 00 00 	sub    $0x308,%rsp
       9:	c5 f8 29 b4 24 60 02 	vmovaps %xmm6,0x260(%rsp)
      10:	00 00 
      12:	c5 f8 29 bc 24 70 02 	vmovaps %xmm7,0x270(%rsp)
      19:	00 00 
      1b:	c5 78 29 84 24 80 02 	vmovaps %xmm8,0x280(%rsp)
      22:	00 00 
      24:	c5 78 29 8c 24 90 02 	vmovaps %xmm9,0x290(%rsp)
      2b:	00 00 
      2d:	c5 78 29 94 24 a0 02 	vmovaps %xmm10,0x2a0(%rsp)
      34:	00 00 
      36:	c5 78 29 9c 24 b0 02 	vmovaps %xmm11,0x2b0(%rsp)
      3d:	00 00 
      3f:	c5 78 29 a4 24 c0 02 	vmovaps %xmm12,0x2c0(%rsp)
      46:	00 00 
      48:	c5 78 29 ac 24 d0 02 	vmovaps %xmm13,0x2d0(%rsp)
      4f:	00 00 
      51:	c5 78 29 b4 24 e0 02 	vmovaps %xmm14,0x2e0(%rsp)
      58:	00 00 
      5a:	c5 78 29 bc 24 f0 02 	vmovaps %xmm15,0x2f0(%rsp)
      61:	00 00 
      63:	c4 e2 7d 58 7a 08    	vpbroadcastd 0x8(%rdx),%ymm7
      69:	48 89 c8             	mov    %rcx,%rax
      6c:	48 89 d1             	mov    %rdx,%rcx
      6f:	80 b8 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rax)
      76:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
      7c:	c4 e2 7d 58 7a 0c    	vpbroadcastd 0xc(%rdx),%ymm7
      82:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
      88:	c4 e2 7d 58 7a 10    	vpbroadcastd 0x10(%rdx),%ymm7
      8e:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
      95:	00 00 
      97:	c4 e2 7d 58 7a 14    	vpbroadcastd 0x14(%rdx),%ymm7
      9d:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
      a4:	00 00 
      a6:	c4 e2 7d 58 7a 18    	vpbroadcastd 0x18(%rdx),%ymm7
      ac:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
      b3:	00 00 
      b5:	c4 e2 7d 58 7a 1c    	vpbroadcastd 0x1c(%rdx),%ymm7
      bb:	0f b6 50 58          	movzbl 0x58(%rax),%edx
      bf:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
      c6:	00 00 
      c8:	0f 84 c2 0a 00 00    	je     b90 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb90>
      ce:	80 b8 18 01 00 00 00 	cmpb   $0x0,0x118(%rax)
      d5:	0f 84 b5 0a 00 00    	je     b90 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb90>
      db:	44 0f b6 90 78 01 00 	movzbl 0x178(%rax),%r10d
      e2:	00 
      e3:	84 d2                	test   %dl,%dl
      e5:	0f 84 35 20 00 00    	je     2120 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2120>
      eb:	45 84 d2             	test   %r10b,%r10b
      ee:	0f 84 a4 0a 00 00    	je     b98 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb98>
      f4:	4d 85 c9             	test   %r9,%r9
      f7:	0f 84 ab 1a 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
      fd:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 105 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x105>
     104:	00 
     105:	49 ff c9             	dec    %r9
     108:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     10d:	49 c1 e9 03          	shr    $0x3,%r9
     111:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
     117:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     11b:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     122:	00 00 
     124:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 16c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16c>
     12b:	00 
     12c:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
     131:	ba 00 80 00 00       	mov    $0x8000,%edx
     136:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     13d:	00 00 
     13f:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     143:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     148:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     14d:	e9 b1 00 00 00       	jmp    203 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x203>
     152:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     158:	8b 51 24             	mov    0x24(%rcx),%edx
     15b:	44 8b 49 20          	mov    0x20(%rcx),%r9d
     15f:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
     164:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     169:	c4 c1 45 fa fd       	vpsubd %ymm13,%ymm7,%ymm7
     16e:	44 0f af ca          	imul   %edx,%r9d
     172:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     176:	48 8b 11             	mov    (%rcx),%rdx
     179:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     17e:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
     183:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
     188:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     18d:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
     192:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     196:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     19a:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     19e:	c4 e2 45 90 0c 9a    	vpgatherdd %ymm7,(%rdx,%ymm3,4),%ymm1
     1a4:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     1a9:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     1ad:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     1b1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     1b6:	c5 e5 72 f1 10       	vpslld $0x10,%ymm1,%ymm3
     1bb:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
     1c0:	49 83 c0 18          	add    $0x18,%r8
     1c4:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
     1c8:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     1cc:	c4 e2 75 00 8c 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm1
     1d3:	01 00 00 
     1d6:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
     1da:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     1e0:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     1e5:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     1ea:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     1ee:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
     1f4:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     1fa:	4d 39 d8             	cmp    %r11,%r8
     1fd:	0f 84 a5 19 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
     203:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     208:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
     20e:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     212:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     216:	48 8b 10             	mov    (%rax),%rdx
     219:	44 8b 50 54          	mov    0x54(%rax),%r10d
     21d:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
     223:	44 8b 48 50          	mov    0x50(%rax),%r9d
     227:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
     22d:	c4 41 79 6e ea       	vmovd  %r10d,%xmm13
     232:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
     239:	01 00 00 
     23c:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     241:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
     246:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
     24b:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     24f:	c4 e2 45 90 24 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm4
     255:	48 8b 50 08          	mov    0x8(%rax),%rdx
     259:	c5 e5 db c8          	vpand  %ymm0,%ymm3,%ymm1
     25d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     261:	c4 e2 45 90 34 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm6
     267:	48 8b 50 10          	mov    0x10(%rax),%rdx
     26b:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     270:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 2d8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d8>
     277:	00 
     278:	c4 e2 55 90 3c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm7
     27e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     283:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     288:	48 8b 50 48          	mov    0x48(%rax),%rdx
     28c:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     291:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     296:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
     29b:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     2a0:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     2a5:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     2aa:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     2af:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 317 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x317>
     2b6:	00 
     2b7:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 31f <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x31f>
     2be:	00 
     2bf:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     2c4:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     2c9:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     2cd:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     2d1:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     2d5:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     2d9:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     2dd:	c5 2d fe ca          	vpaddd %ymm2,%ymm10,%ymm9
     2e1:	c4 62 75 90 34 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm14
     2e7:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     2eb:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
     2f1:	c4 a2 65 90 0c 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm1
     2f7:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     2fb:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     300:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     305:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     309:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     30e:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     312:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     318:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 341 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x341>
     31f:	00 00 80 
     322:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     327:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     32d:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     332:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     337:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     33d:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 366 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x366>
     344:	00 00 c0 
     347:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     34b:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     350:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     355:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     359:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     35d:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     363:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
     369:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     36d:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
     371:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
     375:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     37a:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     37e:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     382:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     387:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     38c:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     391:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     396:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     39b:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     3a0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     3a5:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     3a9:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     3ad:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     3b1:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     3b5:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     3bb:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     3bf:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     3c4:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     3c8:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
     3cd:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     3d2:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     3d6:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     3da:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     3de:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     3e3:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     3e8:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     3ed:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
     3f1:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     3f6:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     3fb:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     3ff:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     404:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     409:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     40d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     412:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     416:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     41a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     41f:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     424:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     428:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     42d:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     431:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
     437:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     43e:	00 00 
     440:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     444:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     449:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     44e:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
     452:	c5 d5 fa da          	vpsubd %ymm2,%ymm5,%ymm3
     456:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     45b:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     460:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
     467:	00 00 
     469:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     46f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     473:	c5 1d 66 c2          	vpcmpgtd %ymm2,%ymm12,%ymm8
     477:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     47b:	c5 8d 66 f3          	vpcmpgtd %ymm3,%ymm14,%ymm6
     47f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     483:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     488:	c5 f5 fa fa          	vpsubd %ymm2,%ymm1,%ymm7
     48c:	c5 95 66 e7          	vpcmpgtd %ymm7,%ymm13,%ymm4
     490:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
     494:	c5 c5 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm7,%ymm6
     49b:	00 00 
     49d:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
     4a1:	c5 ed 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm6
     4a7:	c5 bd eb f6          	vpor   %ymm6,%ymm8,%ymm6
     4ab:	c5 65 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm8
     4b2:	00 00 
     4b4:	c4 c1 4d eb f0       	vpor   %ymm8,%ymm6,%ymm6
     4b9:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
     4bd:	c5 fd d7 d4          	vpmovmskb %ymm4,%edx
     4c1:	85 d2                	test   %edx,%edx
     4c3:	0f 84 8f fc ff ff    	je     158 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x158>
     4c9:	48 8b 50 60          	mov    0x60(%rax),%rdx
     4cd:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     4d1:	44 8b 90 b4 00 00 00 	mov    0xb4(%rax),%r10d
     4d8:	44 8b 88 b0 00 00 00 	mov    0xb0(%rax),%r9d
     4df:	c4 e2 45 90 24 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm4
     4e5:	48 8b 50 68          	mov    0x68(%rax),%rdx
     4e9:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     4ed:	c4 41 79 6e ea       	vmovd  %r10d,%xmm13
     4f2:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     4f7:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     4fd:	48 8b 50 70          	mov    0x70(%rax),%rdx
     501:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     505:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     50a:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 572 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x572>
     511:	00 
     512:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     518:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     51d:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     522:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     529:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     52e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     533:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
     538:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     53d:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     542:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     547:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     54c:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 5b4 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5b4>
     553:	00 
     554:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 5bc <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5bc>
     55b:	00 
     55c:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     561:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     566:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     56b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     56f:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     573:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     577:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     57b:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
     57f:	c4 62 75 90 34 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm14
     585:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     589:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
     58f:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
     595:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     599:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     59e:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     5a2:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     5a7:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     5ab:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     5af:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     5b5:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 5de <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5de>
     5bc:	00 00 80 
     5bf:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     5c4:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     5ca:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     5cf:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     5d4:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     5da:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 603 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x603>
     5e1:	00 00 c0 
     5e4:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     5e8:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     5ed:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     5f2:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     5f6:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     5fa:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     600:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     606:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     60a:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     60e:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
     615:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     619:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     61e:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     622:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     626:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     62b:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     630:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     635:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     63a:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     63f:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     644:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     649:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     64d:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     651:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     655:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     659:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     65f:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     663:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     668:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     66c:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     671:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     676:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     67a:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     67e:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     682:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     687:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     68c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     691:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     695:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     69a:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     69f:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     6a3:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     6a8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     6ad:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     6b1:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     6b6:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     6ba:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     6be:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     6c3:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     6c8:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     6cc:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     6d1:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     6d5:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     6da:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     6e0:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     6e4:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     6e9:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     6ed:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     6f2:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     6f7:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     6fb:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     6ff:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     703:	c4 e2 4d 90 24 aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm4
     709:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
     710:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     714:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     718:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
     71e:	44 8b 90 14 01 00 00 	mov    0x114(%rax),%r10d
     725:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
     72c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     731:	44 8b 88 10 01 00 00 	mov    0x110(%rax),%r9d
     738:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     73c:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     741:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 7a9 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7a9>
     748:	00 
     749:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     74f:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     754:	c4 41 79 6e ea       	vmovd  %r10d,%xmm13
     759:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
     760:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     765:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     76a:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
     76f:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     774:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     779:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     77e:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     783:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     788:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     78d:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 7f5 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7f5>
     794:	00 
     795:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 7fd <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7fd>
     79c:	00 
     79d:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     7a2:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     7a7:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     7ac:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     7b1:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     7b5:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     7b9:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     7bd:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     7c1:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
     7c5:	c4 62 75 90 34 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm14
     7cb:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     7cf:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     7d5:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
     7db:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     7df:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     7e4:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     7e8:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     7ec:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     7f0:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     7f6:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 81f <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x81f>
     7fd:	00 00 80 
     800:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     805:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     80b:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     810:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     815:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     81b:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 844 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x844>
     822:	00 00 c0 
     825:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     829:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     82e:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     833:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     837:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     83b:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     841:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
     847:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     84b:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
     84f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
     856:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
     85a:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     85f:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     863:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
     867:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     86c:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     871:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     876:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     87b:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     880:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     885:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     88a:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     88e:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     892:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     896:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     89a:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     8a0:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     8a4:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     8a9:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     8ad:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
     8b2:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     8b7:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     8bb:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     8bf:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     8c3:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     8c8:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     8cd:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8d2:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
     8d6:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     8db:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     8e0:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     8e4:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     8e9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     8ee:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     8f2:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     8f7:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     8fb:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
     8ff:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     904:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     909:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
     90d:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     912:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     916:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
     91b:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
     921:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     925:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
     92a:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     92e:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     933:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     938:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     93c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     940:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     944:	c4 e2 4d 90 24 aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm4
     94a:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
     951:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     955:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     959:	c4 e2 55 90 34 ba    	vpgatherdd %ymm5,(%rdx,%ymm7,4),%ymm6
     95f:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
     966:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     96b:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     96f:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     974:	c4 e2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm7
     97a:	44 8b 90 74 01 00 00 	mov    0x174(%rax),%r10d
     981:	44 8b 88 70 01 00 00 	mov    0x170(%rax),%r9d
     988:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     98d:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     992:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
     999:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # a01 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa01>
     9a0:	00 
     9a1:	c4 c1 79 6e e9       	vmovd  %r9d,%xmm5
     9a6:	c4 41 79 6e ea       	vmovd  %r10d,%xmm13
     9ab:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
     9b0:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     9b5:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     9ba:	c4 41 79 6e d1       	vmovd  %r9d,%xmm10
     9bf:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     9c4:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     9c9:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     9ce:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # a36 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa36>
     9d5:	00 
     9d6:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # a3e <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa3e>
     9dd:	00 
     9de:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     9e3:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     9e8:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     9ec:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     9f0:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     9f4:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     9f8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     9fc:	c5 2d fe ca          	vpaddd %ymm2,%ymm10,%ymm9
     a00:	c4 62 75 90 34 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm14
     a06:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     a0a:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
     a10:	c4 a2 65 90 0c 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm1
     a16:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     a1a:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     a1f:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     a24:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     a28:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     a2d:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     a33:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # a5c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa5c>
     a3a:	00 00 80 
     a3d:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     a42:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     a48:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     a4d:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     a52:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     a58:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # a81 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa81>
     a5f:	00 00 c0 
     a62:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     a66:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     a6b:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     a70:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
     a74:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     a78:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     a7c:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     a82:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     a88:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     a8c:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
     a90:	c5 cd db d0          	vpand  %ymm0,%ymm6,%ymm2
     a94:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     a99:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
     a9d:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     aa1:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
     aa6:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     aab:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     ab0:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     ab5:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     aba:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     abf:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     ac4:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     ac8:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     acc:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     ad0:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     ad4:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     ada:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
     ade:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
     ae3:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     ae7:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     aec:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     af1:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     af5:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     af9:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     afd:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     b02:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     b07:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     b0c:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     b10:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     b15:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     b1a:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     b1e:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     b23:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b28:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     b2c:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     b31:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     b35:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
     b39:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     b3e:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     b43:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     b47:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     b4c:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     b50:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
     b56:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     b5a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     b5f:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     b64:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     b68:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     b6d:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     b72:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     b76:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     b7a:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     b7e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     b83:	e9 2e f6 ff ff       	jmp    1b6 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b6>
     b88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     b8f:	00 
     b90:	84 d2                	test   %dl,%dl
     b92:	0f 84 e8 06 00 00    	je     1280 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1280>
     b98:	4d 85 c9             	test   %r9,%r9
     b9b:	0f 84 07 10 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
     ba1:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # ba9 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xba9>
     ba8:	00 
     ba9:	49 ff c9             	dec    %r9
     bac:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     bb1:	48 8d 98 80 01 00 00 	lea    0x180(%rax),%rbx
     bb8:	49 c1 e9 03          	shr    $0x3,%r9
     bbc:	c4 c1 0d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm14
     bc2:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     bc6:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     bcd:	00 00 
     bcf:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # c17 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc17>
     bd6:	00 
     bd7:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
     bdc:	ba 00 80 00 00       	mov    $0x8000,%edx
     be1:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     be8:	00 00 
     bea:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     bee:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     bf3:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
     bfa:	00 00 
     bfc:	e9 b4 00 00 00       	jmp    cb5 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcb5>
     c01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     c08:	8b 51 24             	mov    0x24(%rcx),%edx
     c0b:	44 8b 49 20          	mov    0x20(%rcx),%r9d
     c0f:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
     c14:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
     c19:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
     c1e:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     c22:	44 0f af ca          	imul   %edx,%r9d
     c26:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     c2a:	48 8b 11             	mov    (%rcx),%rdx
     c2d:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     c32:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     c37:	c4 c1 79 6e c1       	vmovd  %r9d,%xmm0
     c3c:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     c41:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
     c46:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     c4a:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     c4e:	c4 e2 45 90 0c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm1
     c54:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
     c59:	c4 c1 75 db d6       	vpand  %ymm14,%ymm1,%ymm2
     c5e:	c4 c1 7d db fe       	vpand  %ymm14,%ymm0,%ymm7
     c63:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     c68:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     c6d:	c5 fd 72 f7 08       	vpslld $0x8,%ymm7,%ymm0
     c72:	49 83 c0 18          	add    $0x18,%r8
     c76:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     c7a:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     c7e:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
     c85:	01 00 00 
     c88:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     c8c:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     c92:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     c97:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     c9c:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     ca0:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     ca6:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     cac:	4d 39 c3             	cmp    %r8,%r11
     caf:	0f 84 f3 0e 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
     cb5:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     cba:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     cc0:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     cc4:	48 8b 10             	mov    (%rax),%rdx
     cc7:	44 8b 50 54          	mov    0x54(%rax),%r10d
     ccb:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     cd1:	44 8b 48 50          	mov    0x50(%rax),%r9d
     cd5:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     cdb:	c4 41 79 6e e2       	vmovd  %r10d,%xmm12
     ce0:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
     ce7:	01 00 00 
     cea:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
     cef:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
     cf4:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     cf9:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     cfe:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
     d03:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
     d09:	48 8b 50 08          	mov    0x8(%rax),%rdx
     d0d:	c4 c1 6d db c6       	vpand  %ymm14,%ymm2,%ymm0
     d12:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d16:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     d1b:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
     d20:	c4 e2 45 90 2c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm5
     d26:	48 8b 50 10          	mov    0x10(%rax),%rdx
     d2a:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d2e:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
     d33:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
     d38:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     d3d:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # da5 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xda5>
     d44:	00 
     d45:	c4 e2 45 90 34 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm6
     d4b:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     d50:	48 8b 50 48          	mov    0x48(%rax),%rdx
     d54:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # dbc <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdbc>
     d5b:	00 
     d5c:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     d61:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     d66:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d6a:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     d6f:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # dd7 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdd7>
     d76:	00 
     d77:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
     d7c:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
     d81:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
     d86:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
     d8a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     d8e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     d92:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
     d96:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
     d9c:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     da0:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
     da5:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
     da9:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
     daf:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
     db3:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     db8:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
     dbc:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     dc1:	c4 c1 15 db ee       	vpand  %ymm14,%ymm13,%ymm5
     dc6:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
     dcc:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # df5 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdf5>
     dd3:	00 00 70 
     dd6:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     ddb:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
     de1:	c5 7e 6f a4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm12
     de8:	00 00 
     dea:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     dee:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     df3:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # e1c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe1c>
     dfa:	00 00 b0 
     dfd:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     e01:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
     e06:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
     e0b:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     e0f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
     e13:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
     e19:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
     e1f:	c4 41 6d db ce       	vpand  %ymm14,%ymm2,%ymm9
     e24:	c4 c1 7d db ce       	vpand  %ymm14,%ymm0,%ymm1
     e29:	c4 c1 65 db e6       	vpand  %ymm14,%ymm3,%ymm4
     e2e:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     e33:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     e37:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     e3b:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
     e40:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     e45:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     e4a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
     e4f:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     e54:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
     e59:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e5e:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     e63:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     e68:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     e6c:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     e70:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
     e76:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     e7a:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
     e7f:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
     e84:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
     e89:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
     e8e:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     e93:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     e98:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
     e9c:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
     ea1:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     ea6:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     eab:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
     eaf:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
     eb4:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     eb9:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     ebe:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
     ec3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ec8:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
     ecd:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     ed2:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     ed6:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     eda:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
     edf:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     ee4:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     ee8:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
     eed:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     ef1:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
     ef7:	c5 7e 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm13
     efe:	00 00 
     f00:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     f05:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     f0a:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     f0f:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
     f13:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
     f17:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     f1c:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     f21:	c5 7e 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm12
     f28:	00 00 
     f2a:	c5 7e 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm11
     f30:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
     f34:	c5 a5 66 f9          	vpcmpgtd %ymm1,%ymm11,%ymm7
     f38:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     f3c:	c5 95 66 ea          	vpcmpgtd %ymm2,%ymm13,%ymm5
     f40:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     f44:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     f49:	c5 fd fa f1          	vpsubd %ymm1,%ymm0,%ymm6
     f4d:	c5 9d 66 de          	vpcmpgtd %ymm6,%ymm12,%ymm3
     f51:	c5 d5 eb db          	vpor   %ymm3,%ymm5,%ymm3
     f55:	c5 cd 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm6,%ymm5
     f5c:	00 00 
     f5e:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
     f62:	c5 f5 66 6c 24 60    	vpcmpgtd 0x60(%rsp),%ymm1,%ymm5
     f68:	c5 c5 eb ed          	vpor   %ymm5,%ymm7,%ymm5
     f6c:	c5 ed 66 bc 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm2,%ymm7
     f73:	00 00 
     f75:	c5 d5 eb ef          	vpor   %ymm7,%ymm5,%ymm5
     f79:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
     f7d:	c5 fd d7 d3          	vpmovmskb %ymm3,%edx
     f81:	85 d2                	test   %edx,%edx
     f83:	0f 84 7f fc ff ff    	je     c08 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc08>
     f89:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
     f90:	00 00 
     f92:	48 8d 50 60          	lea    0x60(%rax),%rdx
     f96:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     f9c:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
     fa1:	4c 8b 4a 08          	mov    0x8(%rdx),%r9
     fa5:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     fab:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     faf:	8b 72 54             	mov    0x54(%rdx),%esi
     fb2:	44 8b 52 50          	mov    0x50(%rdx),%r10d
     fb6:	c4 c2 45 90 24 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm4
     fbc:	4c 8b 0a             	mov    (%rdx),%r9
     fbf:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
     fc6:	00 00 
     fc8:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     fcc:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
     fd1:	c5 79 6e ce          	vmovd  %esi,%xmm9
     fd5:	46 8d 54 16 01       	lea    0x1(%rsi,%r10,1),%r10d
     fda:	c4 c2 45 90 04 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm0
     fe0:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     fe5:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     fea:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
     fee:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
     ff3:	c5 d5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm5
     ff8:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
     ffd:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1001:	c4 e2 55 40 ea       	vpmulld %ymm2,%ymm5,%ymm5
    1006:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    100b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1073 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1073>
    1012:	00 
    1013:	c4 c2 45 90 0c b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm1
    1019:	4c 8b 4a 48          	mov    0x48(%rdx),%r9
    101d:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1021:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1089 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1089>
    1028:	00 
    1029:	c5 cd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm6
    102e:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 1096 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1096>
    1035:	00 
    1036:	c4 62 5d 39 c0       	vpminsd %ymm0,%ymm4,%ymm8
    103b:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    103f:	c5 65 fe ee          	vpaddd %ymm6,%ymm3,%ymm13
    1043:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
    1048:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    104c:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    1051:	c4 02 45 90 1c a9    	vpgatherdd %ymm7,(%r9,%ymm13,4),%ymm11
    1057:	c4 c1 65 fe fd       	vpaddd %ymm13,%ymm3,%ymm7
    105c:	c5 dd 66 d8          	vpcmpgtd %ymm0,%ymm4,%ymm3
    1060:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    1067:	00 00 
    1069:	c4 42 4d 90 14 b9    	vpgatherdd %ymm6,(%r9,%ymm7,4),%ymm10
    106f:	c4 e2 5d 3d f0       	vpmaxsd %ymm0,%ymm4,%ymm6
    1074:	c5 f5 66 ee          	vpcmpgtd %ymm6,%ymm1,%ymm5
    1078:	c4 c3 6d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm2,%ymm3
    107e:	c4 e2 4d 3d f1       	vpmaxsd %ymm1,%ymm6,%ymm6
    1083:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm3,%ymm3        # 10ac <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10ac>
    108a:	00 00 50 
    108d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    1091:	c5 95 fe db          	vpaddd %ymm3,%ymm13,%ymm3
    1095:	c4 42 55 90 24 99    	vpgatherdd %ymm5,(%r9,%ymm3,4),%ymm12
    109b:	c5 fd 66 dc          	vpcmpgtd %ymm4,%ymm0,%ymm3
    109f:	c5 bd 66 e9          	vpcmpgtd %ymm1,%ymm8,%ymm5
    10a3:	c4 62 3d 39 c1       	vpminsd %ymm1,%ymm8,%ymm8
    10a8:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    10ac:	c4 c3 6d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm2,%ymm3
    10b2:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm3,%ymm3        # 10db <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10db>
    10b9:	00 00 50 
    10bc:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
    10c0:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    10c4:	c4 c2 45 90 2c 99    	vpgatherdd %ymm7,(%r9,%ymm3,4),%ymm5
    10ca:	c5 7e 7f a4 24 60 01 	vmovdqu %ymm12,0x160(%rsp)
    10d1:	00 00 
    10d3:	c4 c1 25 db fe       	vpand  %ymm14,%ymm11,%ymm7
    10d8:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
    10df:	00 00 
    10e1:	c5 bd fe ee          	vpaddd %ymm6,%ymm8,%ymm5
    10e5:	c5 dd 72 f7 10       	vpslld $0x10,%ymm7,%ymm4
    10ea:	c5 8d db 9c 24 80 01 	vpand  0x180(%rsp),%ymm14,%ymm3
    10f1:	00 00 
    10f3:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    10f7:	c5 0d db a4 24 60 01 	vpand  0x160(%rsp),%ymm14,%ymm12
    10fe:	00 00 
    1100:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1104:	c4 c1 2d db ce       	vpand  %ymm14,%ymm10,%ymm1
    1109:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    1110:	00 00 
    1112:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    1116:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    111a:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    111e:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    1123:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
    1128:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    112c:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    1131:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    1136:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    113a:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    113e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1142:	c4 c1 65 72 d2 08    	vpsrld $0x8,%ymm10,%ymm3
    1148:	c5 dd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm4
    114d:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    1153:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    1158:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
    115f:	00 00 
    1161:	c4 c1 5d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm4
    1167:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    116d:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    1172:	c4 41 25 db e6       	vpand  %ymm14,%ymm11,%ymm12
    1177:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    117c:	c5 7e 7f 94 24 20 02 	vmovdqu %ymm10,0x220(%rsp)
    1183:	00 00 
    1185:	c4 c1 75 72 f4 10    	vpslld $0x10,%ymm12,%ymm1
    118b:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    1190:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1194:	c5 c5 fe fd          	vpaddd %ymm5,%ymm7,%ymm7
    1198:	c5 fe 7f 8c 24 00 02 	vmovdqu %ymm1,0x200(%rsp)
    119f:	00 00 
    11a1:	0f 84 e9 0c 00 00    	je     1e90 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e90>
    11a7:	c5 7e 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm13
    11ae:	00 00 
    11b0:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
    11b7:	00 00 
    11b9:	48 83 c2 60          	add    $0x60,%rdx
    11bd:	c5 b5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm9
    11c2:	c4 c1 75 72 d5 08    	vpsrld $0x8,%ymm13,%ymm1
    11c8:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    11cd:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    11d2:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    11d7:	c4 c1 65 fa d1       	vpsubd %ymm9,%ymm3,%ymm2
    11dc:	c5 35 fa c9          	vpsubd %ymm1,%ymm9,%ymm9
    11e0:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    11e5:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    11e9:	c4 62 35 40 c8       	vpmulld %ymm0,%ymm9,%ymm9
    11ee:	c5 ad fa dd          	vpsubd %ymm5,%ymm10,%ymm3
    11f2:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    11f7:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    11fc:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    1201:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1205:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    120a:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    120e:	c4 c1 75 72 d5 10    	vpsrld $0x10,%ymm13,%ymm1
    1214:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1219:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    121e:	c5 d5 fa e9          	vpsubd %ymm1,%ymm5,%ymm5
    1222:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    1227:	c5 fd 6f fa          	vmovdqa %ymm2,%ymm7
    122b:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    1230:	c4 e2 55 40 e8       	vpmulld %ymm0,%ymm5,%ymm5
    1235:	c5 f5 fe 8c 24 00 02 	vpaddd 0x200(%rsp),%ymm1,%ymm1
    123c:	00 00 
    123e:	c5 e5 fe c5          	vpaddd %ymm5,%ymm3,%ymm0
    1242:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1246:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    124b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    124f:	48 39 da             	cmp    %rbx,%rdx
    1252:	0f 84 b8 0e 00 00    	je     2110 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2110>
    1258:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    125e:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    1263:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    126a:	00 00 
    126c:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    1273:	00 00 
    1275:	e9 27 fd ff ff       	jmp    fa1 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xfa1>
    127a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1280:	4d 85 c9             	test   %r9,%r9
    1283:	0f 84 1f 09 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
    1289:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 1291 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1291>
    1290:	00 
    1291:	49 ff c9             	dec    %r9
    1294:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
    1299:	48 8d 98 80 01 00 00 	lea    0x180(%rax),%rbx
    12a0:	49 c1 e9 03          	shr    $0x3,%r9
    12a4:	c4 c1 05 72 d1 18    	vpsrld $0x18,%ymm9,%ymm15
    12aa:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    12ae:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    12b5:	00 00 
    12b7:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 12ff <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12ff>
    12be:	00 
    12bf:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
    12c4:	ba 00 80 00 00       	mov    $0x8000,%edx
    12c9:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    12d0:	00 00 
    12d2:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    12d6:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    12db:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    12e1:	e9 b6 00 00 00       	jmp    139c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x139c>
    12e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    12ed:	00 00 00 
    12f0:	8b 51 24             	mov    0x24(%rcx),%edx
    12f3:	44 8b 49 20          	mov    0x20(%rcx),%r9d
    12f7:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    12fb:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    1300:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
    1305:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
    1309:	44 0f af ca          	imul   %edx,%r9d
    130d:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1311:	48 8b 11             	mov    (%rcx),%rdx
    1314:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1319:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    131e:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    1323:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1328:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    132d:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1331:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1335:	c4 e2 45 90 04 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm0
    133b:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1340:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1345:	c4 c1 7d db d7       	vpand  %ymm15,%ymm0,%ymm2
    134a:	c4 c1 65 db f7       	vpand  %ymm15,%ymm3,%ymm6
    134f:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1354:	c5 fd 72 f6 08       	vpslld $0x8,%ymm6,%ymm0
    1359:	49 83 c0 18          	add    $0x18,%r8
    135d:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1361:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1365:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    136c:	01 00 00 
    136f:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1373:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1379:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    137e:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1383:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1387:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    138d:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1393:	4d 39 c3             	cmp    %r8,%r11
    1396:	0f 84 0c 08 00 00    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
    139c:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    13a1:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    13a7:	c5 7d 7f cd          	vmovdqa %ymm9,%ymm5
    13ab:	c4 41 7d 6f d9       	vmovdqa %ymm9,%ymm11
    13b0:	48 8b 10             	mov    (%rax),%rdx
    13b3:	44 8b 50 54          	mov    0x54(%rax),%r10d
    13b7:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    13bd:	44 8b 48 50          	mov    0x50(%rax),%r9d
    13c1:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    13c7:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    13ce:	01 00 00 
    13d1:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    13d6:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    13db:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    13e0:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
    13e7:	00 00 
    13e9:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    13ee:	c5 7d 7f c8          	vmovdqa %ymm9,%ymm0
    13f2:	c4 e2 55 90 14 b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm2
    13f8:	48 8b 50 08          	mov    0x8(%rax),%rdx
    13fc:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    1403:	00 00 
    1405:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    140a:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1472 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1472>
    1411:	00 
    1412:	c4 e2 7d 90 2c 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm5
    1418:	48 8b 50 10          	mov    0x10(%rax),%rdx
    141c:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    1423:	00 00 
    1425:	c5 7d 7f c8          	vmovdqa %ymm9,%ymm0
    1429:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    142e:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
    1433:	c4 e2 7d 90 1c ba    	vpgatherdd %ymm0,(%rdx,%ymm7,4),%ymm3
    1439:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
    143e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1443:	48 8b 50 48          	mov    0x48(%rax),%rdx
    1447:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    144c:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1451:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 14b9 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14b9>
    1458:	00 
    1459:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    145e:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    1463:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    1468:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 14d0 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14d0>
    146f:	00 
    1470:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    1475:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1479:	c5 7d fe ee          	vpaddd %ymm6,%ymm0,%ymm13
    147d:	c5 7d 7f c8          	vmovdqa %ymm9,%ymm0
    1481:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    1486:	c4 22 7d 90 24 aa    	vpgatherdd %ymm0,(%rdx,%ymm13,4),%ymm12
    148c:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    1490:	c4 c1 79 6e c1       	vmovd  %r9d,%xmm0
    1495:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    149a:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    149f:	c4 41 7d fe d5       	vpaddd %ymm13,%ymm0,%ymm10
    14a4:	c5 7e 7f 14 24       	vmovdqu %ymm10,(%rsp)
    14a9:	c4 a2 25 90 04 92    	vpgatherdd %ymm11,(%rdx,%ymm10,4),%ymm0
    14af:	c4 41 7d 6f d1       	vmovdqa %ymm9,%ymm10
    14b4:	c4 62 3d 39 db       	vpminsd %ymm3,%ymm8,%ymm11
    14b9:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
    14bd:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    14c1:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    14c5:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    14cb:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 14f4 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14f4>
    14d2:	00 00 40 
    14d5:	c5 95 fe c0          	vpaddd %ymm0,%ymm13,%ymm0
    14d9:	c4 e2 2d 90 24 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm4
    14df:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    14e3:	c5 7e 6f 14 24       	vmovdqu (%rsp),%ymm10
    14e8:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    14ec:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    14f1:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    14f7:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 1520 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1520>
    14fe:	00 00 80 
    1501:	c5 ad fa c0          	vpsubd %ymm0,%ymm10,%ymm0
    1505:	c4 41 7d 6f d1       	vmovdqa %ymm9,%ymm10
    150a:	c4 62 2d 90 04 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm8
    1510:	c5 7e 7f a4 24 80 01 	vmovdqu %ymm12,0x180(%rsp)
    1517:	00 00 
    1519:	c4 41 4d fe e3       	vpaddd %ymm11,%ymm6,%ymm12
    151e:	4c 8b 48 28          	mov    0x28(%rax),%r9
    1522:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    1527:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    152c:	c5 05 db 94 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm10
    1533:	00 00 
    1535:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    153c:	00 00 
    153e:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    1542:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    1546:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
    154b:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    1550:	c4 c1 05 db d6       	vpand  %ymm14,%ymm15,%ymm2
    1555:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    155a:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    155f:	c4 c1 7d 72 f2 10    	vpslld $0x10,%ymm10,%ymm0
    1565:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    156a:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    156f:	c5 fd fe 44 24 20    	vpaddd 0x20(%rsp),%ymm0,%ymm0
    1575:	c4 41 7d 6f d9       	vmovdqa %ymm9,%ymm11
    157a:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    157e:	c5 7d 7f cb          	vmovdqa %ymm9,%ymm3
    1582:	c4 c2 65 90 34 a9    	vpgatherdd %ymm3,(%r9,%ymm5,4),%ymm6
    1588:	4c 8b 48 20          	mov    0x20(%rax),%r9
    158c:	c5 7d 7f cb          	vmovdqa %ymm9,%ymm3
    1590:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1594:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    159b:	00 00 
    159d:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1605 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1605>
    15a4:	00 
    15a5:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    15a9:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    15b0:	00 00 
    15b2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    15b7:	c4 42 65 90 04 91    	vpgatherdd %ymm3,(%r9,%ymm2,4),%ymm8
    15bd:	4c 8b 48 18          	mov    0x18(%rax),%r9
    15c1:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1629 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1629>
    15c8:	00 
    15c9:	c4 c2 25 90 14 a1    	vpgatherdd %ymm11,(%r9,%ymm4,4),%ymm2
    15cf:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 1637 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1637>
    15d6:	00 
    15d7:	c4 42 6d 3d d8       	vpmaxsd %ymm8,%ymm2,%ymm11
    15dc:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    15e0:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    15e5:	c4 c1 4d 66 db       	vpcmpgtd %ymm11,%ymm6,%ymm3
    15ea:	c4 62 55 39 d6       	vpminsd %ymm6,%ymm5,%ymm10
    15ef:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    15f4:	c5 7e 7f 94 24 e0 01 	vmovdqu %ymm10,0x1e0(%rsp)
    15fb:	00 00 
    15fd:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    1601:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    1607:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 1630 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1630>
    160e:	00 00 30 
    1611:	c5 95 fe e4          	vpaddd %ymm4,%ymm13,%ymm4
    1615:	c4 e2 1d 90 1c a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm3
    161b:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    1620:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
    1625:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    162a:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    162f:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1634:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    163a:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 1663 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1663>
    1641:	00 00 50 
    1644:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
    1649:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    164d:	c4 c1 55 72 d6 08    	vpsrld $0x8,%ymm14,%ymm5
    1653:	c4 62 1d 90 14 a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm10
    1659:	c5 7e 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm12
    1660:	00 00 
    1662:	c5 7e 7f b4 24 c0 01 	vmovdqu %ymm14,0x1c0(%rsp)
    1669:	00 00 
    166b:	c5 25 fe b4 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm11,%ymm14
    1672:	00 00 
    1674:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    167a:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    167f:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    1684:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    168a:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    168f:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    1694:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    1698:	c5 ad fa f3          	vpsubd %ymm3,%ymm10,%ymm6
    169c:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    16a1:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    16a6:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    16ab:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    16b0:	c4 c1 5d 72 f4 10    	vpslld $0x10,%ymm12,%ymm4
    16b6:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    16bd:	01 00 00 
    16c0:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    16c5:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    16cb:	4c 8b 48 40          	mov    0x40(%rax),%r9
    16cf:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    16d6:	00 00 
    16d8:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    16dc:	c5 fe 6f b4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm6
    16e3:	00 00 
    16e5:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    16e9:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    16f0:	00 00 
    16f2:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    16f6:	c4 c2 0d 90 2c b1    	vpgatherdd %ymm14,(%r9,%ymm6,4),%ymm5
    16fc:	4c 8b 48 38          	mov    0x38(%rax),%r9
    1700:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    1705:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 176d <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x176d>
    170c:	00 
    170d:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1712:	c4 c2 0d 90 34 91    	vpgatherdd %ymm14,(%r9,%ymm2,4),%ymm6
    1718:	4c 8b 48 30          	mov    0x30(%rax),%r9
    171c:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    1721:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1789 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1789>
    1728:	00 
    1729:	c4 c2 0d 90 14 99    	vpgatherdd %ymm14,(%r9,%ymm3,4),%ymm2
    172f:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    1734:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 179c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x179c>
    173b:	00 
    173c:	c4 62 6d 3d d6       	vpmaxsd %ymm6,%ymm2,%ymm10
    1741:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    1745:	c4 62 6d 39 de       	vpminsd %ymm6,%ymm2,%ymm11
    174a:	c4 c1 55 66 da       	vpcmpgtd %ymm10,%ymm5,%ymm3
    174f:	c4 62 25 39 e5       	vpminsd %ymm5,%ymm11,%ymm12
    1754:	c4 62 2d 3d d5       	vpmaxsd %ymm5,%ymm10,%ymm10
    1759:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    175d:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    1763:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 178c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x178c>
    176a:	00 00 30 
    176d:	c4 41 15 fe c0       	vpaddd %ymm8,%ymm13,%ymm8
    1772:	c5 7e 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm13
    1779:	00 00 
    177b:	c4 a2 0d 90 1c 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm3
    1781:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    1785:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    178a:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    178f:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    1793:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1798:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    179e:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    17a3:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 17cc <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17cc>
    17aa:	00 00 b0 
    17ad:	c4 c1 25 72 d5 10    	vpsrld $0x10,%ymm13,%ymm11
    17b3:	c4 41 2d fe ec       	vpaddd %ymm12,%ymm10,%ymm13
    17b8:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    17bc:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    17c1:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    17c6:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
    17cc:	c4 e2 0d 90 3c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm7
    17d2:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    17d9:	00 00 
    17db:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    17df:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    17e6:	00 00 
    17e8:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    17ed:	c5 95 66 f0          	vpcmpgtd %ymm0,%ymm13,%ymm6
    17f1:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    17f6:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    17fb:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1800:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    1804:	c5 25 fa df          	vpsubd %ymm7,%ymm11,%ymm11
    1808:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    180f:	00 00 
    1811:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    1816:	c4 42 25 40 dc       	vpmulld %ymm12,%ymm11,%ymm11
    181b:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    181f:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    1824:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    1829:	c5 dd fa c8          	vpsubd %ymm0,%ymm4,%ymm1
    182d:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
    1833:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    1838:	c5 25 fe db          	vpaddd %ymm3,%ymm11,%ymm11
    183c:	c5 c5 66 d9          	vpcmpgtd %ymm1,%ymm7,%ymm3
    1840:	c4 41 3d fe c3       	vpaddd %ymm11,%ymm8,%ymm8
    1845:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    184b:	c5 bd fa e8          	vpsubd %ymm0,%ymm8,%ymm5
    184f:	c5 8d 66 d5          	vpcmpgtd %ymm5,%ymm14,%ymm2
    1853:	c5 e5 eb d2          	vpor   %ymm2,%ymm3,%ymm2
    1857:	c5 d5 66 9c 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm5,%ymm3
    185e:	00 00 
    1860:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    1864:	c5 fd 66 5c 24 60    	vpcmpgtd 0x60(%rsp),%ymm0,%ymm3
    186a:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    186e:	c5 f5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm1,%ymm6
    1875:	00 00 
    1877:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    187b:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    187f:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    1883:	85 d2                	test   %edx,%edx
    1885:	0f 84 65 fa ff ff    	je     12f0 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12f0>
    188b:	c5 fe 7f 84 24 80 01 	vmovdqu %ymm0,0x180(%rsp)
    1892:	00 00 
    1894:	48 8d 50 60          	lea    0x60(%rax),%rdx
    1898:	c5 fe 7f a4 24 60 01 	vmovdqu %ymm4,0x160(%rsp)
    189f:	00 00 
    18a1:	c5 7e 7f 84 24 40 01 	vmovdqu %ymm8,0x140(%rsp)
    18a8:	00 00 
    18aa:	4c 8b 0a             	mov    (%rdx),%r9
    18ad:	c5 fe 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm4
    18b4:	00 00 
    18b6:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
    18ba:	c4 41 7d 6f d9       	vmovdqa %ymm9,%ymm11
    18bf:	8b 72 54             	mov    0x54(%rdx),%esi
    18c2:	44 8b 52 50          	mov    0x50(%rdx),%r10d
    18c6:	c4 c2 45 90 1c a1    	vpgatherdd %ymm7,(%r9,%ymm4,4),%ymm3
    18cc:	4c 8b 4a 08          	mov    0x8(%rdx),%r9
    18d0:	c5 fe 6f a4 24 60 01 	vmovdqu 0x160(%rsp),%ymm4
    18d7:	00 00 
    18d9:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
    18dd:	c5 e5 db 05 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm0        # 1945 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1945>
    18e4:	00 
    18e5:	c5 e5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm3
    18ea:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
    18ef:	c4 c2 45 90 0c a1    	vpgatherdd %ymm7,(%r9,%ymm4,4),%ymm1
    18f5:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    18f9:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    1900:	00 00 
    1902:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
    1906:	c5 75 db 15 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm10        # 196e <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x196e>
    190d:	00 
    190e:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1913:	46 8d 54 16 01       	lea    0x1(%rsi,%r10,1),%r10d
    1918:	c5 f5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm1
    191d:	c4 e2 65 40 da       	vpmulld %ymm2,%ymm3,%ymm3
    1922:	c4 42 45 90 04 a1    	vpgatherdd %ymm7,(%r9,%ymm4,4),%ymm8
    1928:	4c 8b 4a 48          	mov    0x48(%rdx),%r9
    192c:	c5 bd db 25 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm4        # 1994 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1994>
    1933:	00 
    1934:	c4 e2 2d 3d f0       	vpmaxsd %ymm0,%ymm10,%ymm6
    1939:	c4 e2 2d 39 e8       	vpminsd %ymm0,%ymm10,%ymm5
    193e:	c4 c1 3d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm8
    1944:	c4 62 4d 3d f4       	vpmaxsd %ymm4,%ymm6,%ymm14
    1949:	c4 62 55 39 e4       	vpminsd %ymm4,%ymm5,%ymm12
    194e:	c5 dd 66 f6          	vpcmpgtd %ymm6,%ymm4,%ymm6
    1952:	c4 c1 1d fe fe       	vpaddd %ymm14,%ymm12,%ymm7
    1957:	c5 7e 7f 34 24       	vmovdqu %ymm14,(%rsp)
    195c:	c5 d5 66 ec          	vpcmpgtd %ymm4,%ymm5,%ymm5
    1960:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    1965:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    196c:	00 00 
    196e:	c5 f9 6e fe          	vmovd  %esi,%xmm7
    1972:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1977:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    197c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1980:	c5 7d 7f cb          	vmovdqa %ymm9,%ymm3
    1984:	c4 41 75 fe f0       	vpaddd %ymm8,%ymm1,%ymm14
    1989:	c4 82 65 90 0c b1    	vpgatherdd %ymm3,(%r9,%ymm14,4),%ymm1
    198f:	c4 c1 79 6e da       	vmovd  %r10d,%xmm3
    1994:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    1999:	c4 41 65 fe ee       	vpaddd %ymm14,%ymm3,%ymm13
    199e:	c5 7d 7f cb          	vmovdqa %ymm9,%ymm3
    19a2:	c5 7e 7f ac 24 e0 01 	vmovdqu %ymm13,0x1e0(%rsp)
    19a9:	00 00 
    19ab:	c4 02 65 90 04 a9    	vpgatherdd %ymm3,(%r9,%ymm13,4),%ymm8
    19b1:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    19b6:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    19bb:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
    19c2:	00 00 
    19c4:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    19cb:	00 00 
    19cd:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    19d2:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
    19d8:	c5 fe 7f 9c 24 00 02 	vmovdqu %ymm3,0x200(%rsp)
    19df:	00 00 
    19e1:	c5 ad 66 d8          	vpcmpgtd %ymm0,%ymm10,%ymm3
    19e5:	c4 e3 6d 4c df 30    	vpblendvb %ymm3,%ymm7,%ymm2,%ymm3
    19eb:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm3,%ymm3        # 1a14 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a14>
    19f2:	00 00 60 
    19f5:	c5 8d fe db          	vpaddd %ymm3,%ymm14,%ymm3
    19f9:	c4 c2 25 90 34 99    	vpgatherdd %ymm11,(%r9,%ymm3,4),%ymm6
    19ff:	c4 c1 7d 66 da       	vpcmpgtd %ymm10,%ymm0,%ymm3
    1a04:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    1a08:	c4 c1 75 db f7       	vpand  %ymm15,%ymm1,%ymm6
    1a0d:	c5 ad 72 f6 10       	vpslld $0x10,%ymm6,%ymm10
    1a12:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1a17:	c4 e3 6d 4c df 30    	vpblendvb %ymm3,%ymm7,%ymm2,%ymm3
    1a1d:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1a22:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm3,%ymm3        # 1a4b <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a4b>
    1a29:	00 00 50 
    1a2c:	c5 fd fa 84 24 c0 01 	vpsubd 0x1c0(%rsp),%ymm0,%ymm0
    1a33:	00 00 
    1a35:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    1a39:	c5 95 fa db          	vpsubd %ymm3,%ymm13,%ymm3
    1a3d:	c4 41 7d 6f e9       	vmovdqa %ymm9,%ymm13
    1a42:	c4 c2 15 90 2c 99    	vpgatherdd %ymm13,(%r9,%ymm3,4),%ymm5
    1a48:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1a4c:	c4 c1 3d db e7       	vpand  %ymm15,%ymm8,%ymm4
    1a51:	c4 c1 55 db df       	vpand  %ymm15,%ymm5,%ymm3
    1a56:	c4 41 05 db eb       	vpand  %ymm11,%ymm15,%ymm13
    1a5b:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    1a5f:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    1a64:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    1a69:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    1a6e:	c5 95 fa f6          	vpsubd %ymm6,%ymm13,%ymm6
    1a72:	c4 e2 4d 40 34 24    	vpmulld (%rsp),%ymm6,%ymm6
    1a78:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    1a7c:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1a82:	c5 2d fe d6          	vpaddd %ymm6,%ymm10,%ymm10
    1a86:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    1a8b:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    1a8f:	c4 c1 65 72 d0 08    	vpsrld $0x8,%ymm8,%ymm3
    1a95:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1a9a:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    1aa0:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1aa5:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    1aac:	00 00 
    1aae:	c5 dd 72 f1 10       	vpslld $0x10,%ymm1,%ymm4
    1ab3:	c4 41 3d db ef       	vpand  %ymm15,%ymm8,%ymm13
    1ab8:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    1abc:	c5 7e 7f ac 24 40 02 	vmovdqu %ymm13,0x240(%rsp)
    1ac3:	00 00 
    1ac5:	c5 7e 7f 94 24 20 02 	vmovdqu %ymm10,0x220(%rsp)
    1acc:	00 00 
    1ace:	0f 84 3c 01 00 00    	je     1c10 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c10>
    1ad4:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    1ad9:	c4 c1 6d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm2
    1adf:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    1ae4:	48 83 c2 60          	add    $0x60,%rdx
    1ae8:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1aed:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1af2:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1af7:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    1afb:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1aff:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1b04:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
    1b09:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    1b0e:	c5 ed fa 94 24 a0 01 	vpsubd 0x1a0(%rsp),%ymm2,%ymm2
    1b15:	00 00 
    1b17:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1b1c:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    1b20:	c5 95 fa e5          	vpsubd %ymm5,%ymm13,%ymm4
    1b24:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    1b29:	c5 ed fe 94 24 00 02 	vpaddd 0x200(%rsp),%ymm2,%ymm2
    1b30:	00 00 
    1b32:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1b36:	c4 c1 6d 72 d3 10    	vpsrld $0x10,%ymm11,%ymm2
    1b3c:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1b41:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1b46:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1b4a:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    1b4e:	c5 fd 6f f3          	vmovdqa %ymm3,%ymm6
    1b52:	c4 e2 55 40 e8       	vpmulld %ymm0,%ymm5,%ymm5
    1b57:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1b5c:	c5 dd fe c5          	vpaddd %ymm5,%ymm4,%ymm0
    1b60:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    1b65:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1b69:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1b6e:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1b72:	48 39 da             	cmp    %rbx,%rdx
    1b75:	0f 84 fe 02 00 00    	je     1e79 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e79>
    1b7b:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    1b82:	00 00 
    1b84:	c5 fe 7f 9c 24 60 01 	vmovdqu %ymm3,0x160(%rsp)
    1b8b:	00 00 
    1b8d:	c5 fe 7f 84 24 40 01 	vmovdqu %ymm0,0x140(%rsp)
    1b94:	00 00 
    1b96:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    1b9d:	00 00 
    1b9f:	e9 06 fd ff ff       	jmp    18aa <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18aa>
    1ba4:	0f 1f 40 00          	nopl   0x0(%rax)
    1ba8:	c5 f8 77             	vzeroupper
    1bab:	c5 f8 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm6
    1bb2:	00 00 
    1bb4:	c5 f8 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm7
    1bbb:	00 00 
    1bbd:	c5 78 28 84 24 80 02 	vmovaps 0x280(%rsp),%xmm8
    1bc4:	00 00 
    1bc6:	c5 78 28 8c 24 90 02 	vmovaps 0x290(%rsp),%xmm9
    1bcd:	00 00 
    1bcf:	c5 78 28 94 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm10
    1bd6:	00 00 
    1bd8:	c5 78 28 9c 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm11
    1bdf:	00 00 
    1be1:	c5 78 28 a4 24 c0 02 	vmovaps 0x2c0(%rsp),%xmm12
    1be8:	00 00 
    1bea:	c5 78 28 ac 24 d0 02 	vmovaps 0x2d0(%rsp),%xmm13
    1bf1:	00 00 
    1bf3:	c5 78 28 b4 24 e0 02 	vmovaps 0x2e0(%rsp),%xmm14
    1bfa:	00 00 
    1bfc:	c5 78 28 bc 24 f0 02 	vmovaps 0x2f0(%rsp),%xmm15
    1c03:	00 00 
    1c05:	48 81 c4 08 03 00 00 	add    $0x308,%rsp
    1c0c:	5b                   	pop    %rbx
    1c0d:	5e                   	pop    %rsi
    1c0e:	c3                   	ret
    1c0f:	90                   	nop
    1c10:	4c 8b 52 28          	mov    0x28(%rdx),%r10
    1c14:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
    1c1b:	00 00 
    1c1d:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1c21:	c4 41 7d 6f e9       	vmovdqa %ymm9,%ymm13
    1c26:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    1c2d:	00 00 
    1c2f:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    1c36:	00 00 
    1c38:	48 83 c2 60          	add    $0x60,%rdx
    1c3c:	c4 c2 5d 90 2c b2    	vpgatherdd %ymm4,(%r10,%ymm6,4),%ymm5
    1c42:	4c 8b 52 c0          	mov    -0x40(%rdx),%r10
    1c46:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1c4a:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1cb2 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cb2>
    1c51:	00 
    1c52:	c4 c2 5d 90 34 82    	vpgatherdd %ymm4,(%r10,%ymm0,4),%ymm6
    1c58:	4c 8b 52 b8          	mov    -0x48(%rdx),%r10
    1c5c:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1c60:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1cc8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cc8>
    1c67:	00 
    1c68:	c4 82 5d 90 04 9a    	vpgatherdd %ymm4,(%r10,%ymm11,4),%ymm0
    1c6e:	4c 8b 52 e0          	mov    -0x20(%rdx),%r10
    1c72:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1cda <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cda>
    1c79:	00 
    1c7a:	c4 62 7d 3d de       	vpmaxsd %ymm6,%ymm0,%ymm11
    1c7f:	c5 4d 66 c0          	vpcmpgtd %ymm0,%ymm6,%ymm8
    1c83:	c4 62 7d 39 d6       	vpminsd %ymm6,%ymm0,%ymm10
    1c88:	c4 c1 55 66 e3       	vpcmpgtd %ymm11,%ymm5,%ymm4
    1c8d:	c4 62 2d 39 e5       	vpminsd %ymm5,%ymm10,%ymm12
    1c92:	c4 62 25 3d dd       	vpmaxsd %ymm5,%ymm11,%ymm11
    1c97:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    1c9b:	c4 63 6d 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm2,%ymm8
    1ca1:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm8,%ymm8        # 1cca <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cca>
    1ca8:	00 00 40 
    1cab:	c4 41 0d fe c0       	vpaddd %ymm8,%ymm14,%ymm8
    1cb0:	c4 82 15 90 24 81    	vpgatherdd %ymm13,(%r9,%ymm8,4),%ymm4
    1cb6:	c5 7d 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm8
    1cba:	c5 7e 6f ac 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm13
    1cc1:	00 00 
    1cc3:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1cc7:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    1ccc:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1cd1:	c4 63 6d 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm2,%ymm8
    1cd7:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm8,%ymm8        # 1d00 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d00>
    1cde:	00 00 a0 
    1ce1:	c4 41 15 fa c0       	vpsubd %ymm8,%ymm13,%ymm8
    1ce6:	c4 41 7d 6f e9       	vmovdqa %ymm9,%ymm13
    1ceb:	c4 02 15 90 14 81    	vpgatherdd %ymm13,(%r9,%ymm8,4),%ymm10
    1cf1:	c4 41 25 fe c4       	vpaddd %ymm12,%ymm11,%ymm8
    1cf6:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    1cfc:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    1d01:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    1d06:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    1d0a:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    1d0e:	c5 dd fa a4 24 a0 01 	vpsubd 0x1a0(%rsp),%ymm4,%ymm4
    1d15:	00 00 
    1d17:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    1d1c:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    1d21:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    1d28:	00 00 
    1d2a:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    1d2f:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    1d34:	c5 dd fe a4 24 00 02 	vpaddd 0x200(%rsp),%ymm4,%ymm4
    1d3b:	00 00 
    1d3d:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1d41:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1d45:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1d49:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    1d4e:	c4 c2 5d 90 04 aa    	vpgatherdd %ymm4,(%r10,%ymm5,4),%ymm0
    1d54:	4c 8b 52 d8          	mov    -0x28(%rdx),%r10
    1d58:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    1d5f:	00 00 
    1d61:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1d65:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1dcd <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dcd>
    1d6c:	00 
    1d6d:	c5 fd 6f f3          	vmovdqa %ymm3,%ymm6
    1d71:	c4 42 5d 90 04 aa    	vpgatherdd %ymm4,(%r10,%ymm5,4),%ymm8
    1d77:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    1d7e:	00 00 
    1d80:	4c 8b 52 d0          	mov    -0x30(%rdx),%r10
    1d84:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
    1d88:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 1df0 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1df0>
    1d8f:	00 
    1d90:	c4 82 5d 90 2c 9a    	vpgatherdd %ymm4,(%r10,%ymm11,4),%ymm5
    1d96:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1dfe <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dfe>
    1d9d:	00 
    1d9e:	c4 42 55 3d d8       	vpmaxsd %ymm8,%ymm5,%ymm11
    1da3:	c5 3d 66 d5          	vpcmpgtd %ymm5,%ymm8,%ymm10
    1da7:	c4 42 55 39 e0       	vpminsd %ymm8,%ymm5,%ymm12
    1dac:	c4 c1 7d 66 e3       	vpcmpgtd %ymm11,%ymm0,%ymm4
    1db1:	c4 62 1d 39 e8       	vpminsd %ymm0,%ymm12,%ymm13
    1db6:	c4 62 25 3d d8       	vpmaxsd %ymm0,%ymm11,%ymm11
    1dbb:	c5 1d 66 e0          	vpcmpgtd %ymm0,%ymm12,%ymm12
    1dbf:	c4 63 6d 4c d7 a0    	vpblendvb %ymm10,%ymm7,%ymm2,%ymm10
    1dc5:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm10,%ymm10        # 1dee <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dee>
    1dcc:	00 00 40 
    1dcf:	c4 41 0d fe d2       	vpaddd %ymm10,%ymm14,%ymm10
    1dd4:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    1dd9:	c4 82 0d 90 24 91    	vpgatherdd %ymm14,(%r9,%ymm10,4),%ymm4
    1ddf:	c4 41 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm10
    1de4:	c4 41 7d 6f f1       	vmovdqa %ymm9,%ymm14
    1de9:	c4 c1 55 fe e8       	vpaddd %ymm8,%ymm5,%ymm5
    1dee:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1df3:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1df8:	c4 e3 6d 4c d7 a0    	vpblendvb %ymm10,%ymm7,%ymm2,%ymm2
    1dfe:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    1e05:	00 00 
    1e07:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1e30 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e30>
    1e0e:	00 00 c0 
    1e11:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    1e15:	c4 c2 0d 90 3c 91    	vpgatherdd %ymm14,(%r9,%ymm2,4),%ymm7
    1e1b:	c4 c1 25 fe d5       	vpaddd %ymm13,%ymm11,%ymm2
    1e20:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    1e24:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    1e29:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1e2e:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1e32:	c5 fe 6f ac 24 40 02 	vmovdqu 0x240(%rsp),%ymm5
    1e39:	00 00 
    1e3b:	c5 c5 fa d4          	vpsubd %ymm4,%ymm7,%ymm2
    1e3f:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    1e43:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1e48:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    1e4d:	c5 d5 fa d7          	vpsubd %ymm7,%ymm5,%ymm2
    1e51:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1e56:	c5 dd fe a4 24 20 02 	vpaddd 0x220(%rsp),%ymm4,%ymm4
    1e5d:	00 00 
    1e5f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1e63:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1e67:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1e6c:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1e70:	48 39 d3             	cmp    %rdx,%rbx
    1e73:	0f 85 02 fd ff ff    	jne    1b7b <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b7b>
    1e79:	c5 fe 6f 94 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm2
    1e80:	00 00 
    1e82:	e9 c8 f4 ff ff       	jmp    134f <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x134f>
    1e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e8e:	00 00 
    1e90:	4c 8b 52 28          	mov    0x28(%rdx),%r10
    1e94:	c5 fe 6f 04 24       	vmovdqu (%rsp),%ymm0
    1e99:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    1e9d:	48 83 c2 60          	add    $0x60,%rdx
    1ea1:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    1ea7:	c5 7e 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm11
    1eae:	00 00 
    1eb0:	c4 c2 4d 90 2c 82    	vpgatherdd %ymm6,(%r10,%ymm0,4),%ymm5
    1eb6:	4c 8b 52 c0          	mov    -0x40(%rdx),%r10
    1eba:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    1ebe:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1f26 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f26>
    1ec5:	00 
    1ec6:	c4 c2 7d 90 34 8a    	vpgatherdd %ymm0,(%r10,%ymm1,4),%ymm6
    1ecc:	4c 8b 52 b8          	mov    -0x48(%rdx),%r10
    1ed0:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
    1ed4:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1f3c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f3c>
    1edb:	00 
    1edc:	c4 82 75 90 04 9a    	vpgatherdd %ymm1,(%r10,%ymm11,4),%ymm0
    1ee2:	4c 8b 52 e0          	mov    -0x20(%rdx),%r10
    1ee6:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 1f4e <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f4e>
    1eed:	00 
    1eee:	c4 62 7d 3d de       	vpmaxsd %ymm6,%ymm0,%ymm11
    1ef3:	c5 4d 66 c0          	vpcmpgtd %ymm0,%ymm6,%ymm8
    1ef7:	c4 62 7d 39 d6       	vpminsd %ymm6,%ymm0,%ymm10
    1efc:	c4 c1 55 66 cb       	vpcmpgtd %ymm11,%ymm5,%ymm1
    1f01:	c4 43 6d 4c c1 80    	vpblendvb %ymm8,%ymm9,%ymm2,%ymm8
    1f07:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # 1f30 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f30>
    1f0e:	00 00 10 
    1f11:	c4 e2 25 3d cd       	vpmaxsd %ymm5,%ymm11,%ymm1
    1f16:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    1f1b:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    1f22:	00 00 
    1f24:	c4 e2 2d 39 cd       	vpminsd %ymm5,%ymm10,%ymm1
    1f29:	c4 41 15 fe c0       	vpaddd %ymm8,%ymm13,%ymm8
    1f2e:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    1f32:	c5 fe 7f 8c 24 80 01 	vmovdqu %ymm1,0x180(%rsp)
    1f39:	00 00 
    1f3b:	c4 82 25 90 0c 81    	vpgatherdd %ymm11,(%r9,%ymm8,4),%ymm1
    1f41:	c5 7d 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm8
    1f45:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    1f4a:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
    1f4f:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1f53:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    1f58:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1f5d:	c4 43 6d 4c c1 80    	vpblendvb %ymm8,%ymm9,%ymm2,%ymm8
    1f63:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm8,%ymm8        # 1f8c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f8c>
    1f6a:	00 00 a0 
    1f6d:	c5 7e 6f 94 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm10
    1f74:	00 00 
    1f76:	c4 41 2d fa c0       	vpsubd %ymm8,%ymm10,%ymm8
    1f7b:	c4 02 25 90 14 81    	vpgatherdd %ymm11,(%r9,%ymm8,4),%ymm10
    1f81:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    1f88:	00 00 
    1f8a:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    1f90:	c5 25 fe 84 24 60 01 	vpaddd 0x160(%rsp),%ymm11,%ymm8
    1f97:	00 00 
    1f99:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    1f9e:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    1fa3:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    1fa8:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    1fad:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    1fb1:	c5 ad fa e9          	vpsubd %ymm1,%ymm10,%ymm5
    1fb5:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    1fba:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    1fbe:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    1fc2:	c4 e2 75 40 8c 24 60 	vpmulld 0x160(%rsp),%ymm1,%ymm1
    1fc9:	01 00 00 
    1fcc:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    1fd0:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1fd4:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1fd8:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    1fdd:	c4 c2 5d 90 04 b2    	vpgatherdd %ymm4,(%r10,%ymm6,4),%ymm0
    1fe3:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    1fe7:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 204f <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x204f>
    1fee:	00 
    1fef:	4c 8b 52 d8          	mov    -0x28(%rdx),%r10
    1ff3:	c5 fd 6f fb          	vmovdqa %ymm3,%ymm7
    1ff7:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1ffd:	c5 fe 6f 8c 24 40 01 	vmovdqu 0x140(%rsp),%ymm1
    2004:	00 00 
    2006:	c4 c2 5d 90 2c b2    	vpgatherdd %ymm4,(%r10,%ymm6,4),%ymm5
    200c:	4c 8b 52 d0          	mov    -0x30(%rdx),%r10
    2010:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    2014:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 207c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x207c>
    201b:	00 
    201c:	c4 c2 4d 90 24 8a    	vpgatherdd %ymm6,(%r10,%ymm1,4),%ymm4
    2022:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 208a <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x208a>
    2029:	00 
    202a:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    202f:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    2033:	c4 62 5d 39 d5       	vpminsd %ymm5,%ymm4,%ymm10
    2038:	c4 c1 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm1
    203d:	c4 62 2d 39 d8       	vpminsd %ymm0,%ymm10,%ymm11
    2042:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    2047:	c5 2d 66 d0          	vpcmpgtd %ymm0,%ymm10,%ymm10
    204b:	c4 c3 6d 4c f1 60    	vpblendvb %ymm6,%ymm9,%ymm2,%ymm6
    2051:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm6,%ymm6        # 207a <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x207a>
    2058:	00 00 10 
    205b:	c5 95 fe f6          	vpaddd %ymm6,%ymm13,%ymm6
    205f:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    2064:	c4 c2 15 90 0c b1    	vpgatherdd %ymm13,(%r9,%ymm6,4),%ymm1
    206a:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    206e:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    2073:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2077:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    207c:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    2081:	c4 c3 6d 4c d1 60    	vpblendvb %ymm6,%ymm9,%ymm2,%ymm2
    2087:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm2,%ymm2        # 20b0 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20b0>
    208e:	00 00 a0 
    2091:	c5 7e 6f 94 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm10
    2098:	00 00 
    209a:	c5 ad fa d2          	vpsubd %ymm2,%ymm10,%ymm2
    209e:	c4 c2 15 90 34 91    	vpgatherdd %ymm13,(%r9,%ymm2,4),%ymm6
    20a4:	c4 c1 3d fe d3       	vpaddd %ymm11,%ymm8,%ymm2
    20a9:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    20ad:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    20b2:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    20b7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    20bb:	c5 fe 6f a4 24 20 02 	vmovdqu 0x220(%rsp),%ymm4
    20c2:	00 00 
    20c4:	c5 cd fa d1          	vpsubd %ymm1,%ymm6,%ymm2
    20c8:	c4 c1 75 fa cc       	vpsubd %ymm12,%ymm1,%ymm1
    20cd:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    20d2:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    20d7:	c5 dd fa d6          	vpsubd %ymm6,%ymm4,%ymm2
    20db:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    20e0:	c5 f5 fe 8c 24 00 02 	vpaddd 0x200(%rsp),%ymm1,%ymm1
    20e7:	00 00 
    20e9:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    20ed:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    20f1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    20f6:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    20fa:	48 39 d3             	cmp    %rdx,%rbx
    20fd:	74 11                	je     2110 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2110>
    20ff:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    2105:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    210a:	e9 54 f1 ff ff       	jmp    1263 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1263>
    210f:	90                   	nop
    2110:	c5 fe 6f 94 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm2
    2117:	00 00 
    2119:	e9 4a eb ff ff       	jmp    c68 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc68>
    211e:	66 90                	xchg   %ax,%ax
    2120:	45 84 d2             	test   %r10b,%r10b
    2123:	0f 84 57 f1 ff ff    	je     1280 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1280>
    2129:	4d 85 c9             	test   %r9,%r9
    212c:	0f 84 76 fa ff ff    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
    2132:	c5 fd 6f 3d 00 00 00 	vmovdqa 0x0(%rip),%ymm7        # 213a <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x213a>
    2139:	00 
    213a:	49 ff c9             	dec    %r9
    213d:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    2142:	49 c1 e9 03          	shr    $0x3,%r9
    2146:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    214c:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    2150:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    2157:	00 00 
    2159:	c5 fd 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm7        # 21a1 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21a1>
    2160:	00 
    2161:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
    2166:	ba 00 80 00 00       	mov    $0x8000,%edx
    216b:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    2172:	00 00 
    2174:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    2178:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    217d:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    2182:	e9 b5 00 00 00       	jmp    223c <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x223c>
    2187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    218e:	00 00 
    2190:	8b 51 24             	mov    0x24(%rcx),%edx
    2193:	44 8b 49 20          	mov    0x20(%rcx),%r9d
    2197:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    219b:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    21a0:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    21a5:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    21a9:	44 0f af ca          	imul   %edx,%r9d
    21ad:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    21b1:	48 8b 11             	mov    (%rcx),%rdx
    21b4:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    21b9:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    21be:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    21c3:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    21c8:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    21cd:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    21d1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    21d5:	c4 e2 45 90 04 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm0
    21db:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    21e0:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    21e5:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    21ea:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    21ef:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    21f4:	c5 ed 72 f1 08       	vpslld $0x8,%ymm1,%ymm2
    21f9:	49 83 c0 18          	add    $0x18,%r8
    21fd:	c5 ed eb d0          	vpor   %ymm0,%ymm2,%ymm2
    2201:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    2205:	c4 e2 6d 00 94 24 20 	vpshufb 0x120(%rsp),%ymm2,%ymm2
    220c:	01 00 00 
    220f:	c5 f9 6f ca          	vmovdqa %xmm2,%xmm1
    2213:	c4 e3 7d 39 d2 01    	vextracti128 $0x1,%ymm2,%xmm2
    2219:	c5 f9 73 fa 0c       	vpslldq $0xc,%xmm2,%xmm0
    221e:	c5 e9 73 da 04       	vpsrldq $0x4,%xmm2,%xmm2
    2223:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
    2227:	c4 c1 79 d6 50 f8    	vmovq  %xmm2,-0x8(%r8)
    222d:	c4 c1 7a 7f 40 e8    	vmovdqu %xmm0,-0x18(%r8)
    2233:	4d 39 c3             	cmp    %r8,%r11
    2236:	0f 84 6c f9 ff ff    	je     1ba8 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba8>
    223c:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    2241:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    2247:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    224b:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    2250:	48 8b 10             	mov    (%rax),%rdx
    2253:	44 8b 50 54          	mov    0x54(%rax),%r10d
    2257:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    225c:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2262:	44 8b 48 50          	mov    0x50(%rax),%r9d
    2266:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    226c:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    2273:	01 00 00 
    2276:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    227b:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    2280:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    2285:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
    228c:	00 00 
    228e:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
    2293:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    2297:	c4 e2 55 90 14 b2    	vpgatherdd %ymm5,(%rdx,%ymm6,4),%ymm2
    229d:	48 8b 50 08          	mov    0x8(%rax),%rdx
    22a1:	c5 fe 7f 84 24 60 01 	vmovdqu %ymm0,0x160(%rsp)
    22a8:	00 00 
    22aa:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    22af:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2317 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2317>
    22b6:	00 
    22b7:	c4 e2 75 90 2c 82    	vpgatherdd %ymm1,(%rdx,%ymm0,4),%ymm5
    22bd:	48 8b 50 10          	mov    0x10(%rax),%rdx
    22c1:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    22c8:	00 00 
    22ca:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    22ce:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    22d3:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 233b <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x233b>
    22da:	00 
    22db:	c4 e2 75 90 1c ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm3
    22e1:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    22e6:	c4 c1 79 6e fa       	vmovd  %r10d,%xmm7
    22eb:	48 8b 50 48          	mov    0x48(%rax),%rdx
    22ef:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    22f4:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    22f9:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
    22fe:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    2303:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    2308:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    230d:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    2312:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 237a <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x237a>
    2319:	00 
    231a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    231e:	c5 fd fe f6          	vpaddd %ymm6,%ymm0,%ymm6
    2322:	c4 c1 79 6e c1       	vmovd  %r9d,%xmm0
    2327:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    232c:	c4 62 15 90 1c b2    	vpgatherdd %ymm13,(%rdx,%ymm6,4),%ymm11
    2332:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    2338:	c5 7d fe ee          	vpaddd %ymm6,%ymm0,%ymm13
    233c:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    2341:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    2345:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    2349:	c4 22 2d 90 0c aa    	vpgatherdd %ymm10,(%rdx,%ymm13,4),%ymm9
    234f:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    2354:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
    2359:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    235e:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    2363:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    2369:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    236d:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 2396 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2396>
    2374:	00 00 40 
    2377:	c5 fd fe 44 24 20    	vpaddd 0x20(%rsp),%ymm0,%ymm0
    237d:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    2383:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    2387:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    238c:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2391:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2395:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    239b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 23c4 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23c4>
    23a2:	00 00 80 
    23a5:	c5 95 fa c0          	vpsubd %ymm0,%ymm13,%ymm0
    23a9:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    23af:	c5 7e 7f 9c 24 80 01 	vmovdqu %ymm11,0x180(%rsp)
    23b6:	00 00 
    23b8:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    23bd:	4c 8b 48 28          	mov    0x28(%rax),%r9
    23c1:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    23c6:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    23cb:	c5 05 db 8c 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm9
    23d2:	00 00 
    23d4:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    23db:	00 00 
    23dd:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    23e1:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    23e5:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    23ea:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    23ef:	c4 c1 05 db d4       	vpand  %ymm12,%ymm15,%ymm2
    23f4:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    23f9:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    23fe:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    2404:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    2409:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    240e:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    2413:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    2418:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    241c:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    2420:	c4 c2 65 90 34 a9    	vpgatherdd %ymm3,(%r9,%ymm5,4),%ymm6
    2426:	4c 8b 48 20          	mov    0x20(%rax),%r9
    242a:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    242e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2432:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    2439:	00 00 
    243b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 24a3 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24a3>
    2442:	00 
    2443:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2447:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    244e:	00 00 
    2450:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2455:	c4 42 65 90 04 91    	vpgatherdd %ymm3,(%r9,%ymm2,4),%ymm8
    245b:	4c 8b 48 18          	mov    0x18(%rax),%r9
    245f:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 24c7 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24c7>
    2466:	00 
    2467:	c4 c2 2d 90 14 a1    	vpgatherdd %ymm10,(%r9,%ymm4,4),%ymm2
    246d:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 24d5 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24d5>
    2474:	00 
    2475:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    247a:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    247e:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    2483:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    2488:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    248d:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    2492:	c5 7e 7f 8c 24 e0 01 	vmovdqu %ymm9,0x1e0(%rsp)
    2499:	00 00 
    249b:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    249f:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    24a5:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 24ce <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24ce>
    24ac:	00 00 30 
    24af:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    24b5:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    24bb:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    24c0:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    24c5:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    24ca:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    24cf:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    24d4:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    24da:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 2503 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2503>
    24e1:	00 00 50 
    24e4:	c4 c1 55 72 d4 08    	vpsrld $0x8,%ymm12,%ymm5
    24ea:	c5 95 fa e4          	vpsubd %ymm4,%ymm13,%ymm4
    24ee:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    24f3:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    24f9:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    2500:	00 00 
    2502:	c5 7e 7f a4 24 c0 01 	vmovdqu %ymm12,0x1c0(%rsp)
    2509:	00 00 
    250b:	c5 2d fe a4 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm10,%ymm12
    2512:	00 00 
    2514:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    251a:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    251f:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    2525:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    252a:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    252f:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    2533:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2537:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    253c:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    2541:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2546:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    254b:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    2551:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    2558:	01 00 00 
    255b:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2560:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    2565:	4c 8b 48 40          	mov    0x40(%rax),%r9
    2569:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    2570:	00 00 
    2572:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    2576:	c5 fe 6f b4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm6
    257d:	00 00 
    257f:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    2583:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    258a:	00 00 
    258c:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2590:	c4 c2 1d 90 2c b1    	vpgatherdd %ymm12,(%r9,%ymm6,4),%ymm5
    2596:	4c 8b 48 38          	mov    0x38(%rax),%r9
    259a:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    259f:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2607 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2607>
    25a6:	00 
    25a7:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    25ac:	c4 c2 1d 90 34 91    	vpgatherdd %ymm12,(%r9,%ymm2,4),%ymm6
    25b2:	4c 8b 48 30          	mov    0x30(%rax),%r9
    25b6:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    25bb:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2623 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2623>
    25c2:	00 
    25c3:	c4 c2 1d 90 14 99    	vpgatherdd %ymm12,(%r9,%ymm3,4),%ymm2
    25c9:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    25ce:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 2636 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2636>
    25d5:	00 
    25d6:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    25db:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    25df:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    25e4:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    25e9:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    25ee:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    25f3:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    25f7:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    25fd:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 2626 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2626>
    2604:	00 00 30 
    2607:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
    260d:	c4 a2 1d 90 1c 82    	vpgatherdd %ymm12,(%rdx,%ymm8,4),%ymm3
    2613:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    2617:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    261c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2621:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    2625:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    262a:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    2630:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 2659 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2659>
    2637:	00 00 a0 
    263a:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    263e:	c5 7e 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm13
    2645:	00 00 
    2647:	c4 e2 1d 90 3c 8a    	vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm7
    264d:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    2654:	00 00 
    2656:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    265b:	c4 c1 2d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm10
    2661:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2666:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    266b:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    2672:	00 00 
    2674:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2679:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    267e:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    2683:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2688:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    268c:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    2690:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    2695:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    269a:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    269e:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    26a5:	00 00 
    26a7:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    26ab:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    26b0:	c5 3d fe 04 24       	vpaddd (%rsp),%ymm8,%ymm8
    26b5:	c5 7e 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm11
    26bb:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    26c0:	c5 dd fa c8          	vpsubd %ymm0,%ymm4,%ymm1
    26c4:	c5 a5 66 f0          	vpcmpgtd %ymm0,%ymm11,%ymm6
    26c8:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    26cd:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    26d1:	c5 c5 66 d9          	vpcmpgtd %ymm1,%ymm7,%ymm3
    26d5:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    26da:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    26e0:	c5 bd fa e8          	vpsubd %ymm0,%ymm8,%ymm5
    26e4:	c5 95 66 d5          	vpcmpgtd %ymm5,%ymm13,%ymm2
    26e8:	c5 e5 eb d2          	vpor   %ymm2,%ymm3,%ymm2
    26ec:	c5 d5 66 9c 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm5,%ymm3
    26f3:	00 00 
    26f5:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    26f9:	c5 fd 66 5c 24 60    	vpcmpgtd 0x60(%rsp),%ymm0,%ymm3
    26ff:	c5 cd eb db          	vpor   %ymm3,%ymm6,%ymm3
    2703:	c5 f5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm1,%ymm6
    270a:	00 00 
    270c:	c5 e5 eb de          	vpor   %ymm6,%ymm3,%ymm3
    2710:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    2714:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    2718:	85 d2                	test   %edx,%edx
    271a:	0f 84 70 fa ff ff    	je     2190 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2190>
    2720:	48 8b 50 60          	mov    0x60(%rax),%rdx
    2724:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2728:	44 8b 90 b4 00 00 00 	mov    0xb4(%rax),%r10d
    272f:	44 8b 88 b0 00 00 00 	mov    0xb0(%rax),%r9d
    2736:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
    273c:	48 8b 50 68          	mov    0x68(%rax),%rdx
    2740:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2744:	c4 41 79 6e e2       	vmovd  %r10d,%xmm12
    2749:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    274e:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2753:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 27bb <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x27bb>
    275a:	00 
    275b:	c4 e2 45 90 2c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm5
    2761:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    2766:	48 8b 50 70          	mov    0x70(%rax),%rdx
    276a:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    276e:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2773:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2778:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
    277d:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2782:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2787:	c4 a2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm8,4),%ymm6
    278d:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    2794:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    2799:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    279e:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2806 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2806>
    27a5:	00 
    27a6:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    27ab:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    27af:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2817 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2817>
    27b6:	00 
    27b7:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    27bc:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    27c1:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    27c6:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    27ca:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    27ce:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    27d2:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    27d6:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    27dc:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    27e0:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    27e6:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    27ea:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    27f0:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    27f4:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    27f9:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    27fd:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2802:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2808:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    280e:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2837 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2837>
    2815:	00 00 70 
    2818:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    281e:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2823:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2828:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2851 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2851>
    282f:	00 00 b0 
    2832:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2836:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    283a:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    283f:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2843:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2848:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    284c:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2852:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    2857:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    285d:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2862:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2867:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    286e:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    2873:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2878:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    287c:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    2880:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2885:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    288a:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    288f:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2894:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2899:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    289e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    28a3:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    28a8:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    28ad:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    28b1:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    28b5:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    28bb:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    28bf:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    28c4:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    28c9:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    28ce:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    28d3:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    28d8:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    28dd:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    28e1:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    28e6:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    28eb:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    28f0:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    28f4:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    28f9:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    28fe:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2903:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2908:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    290d:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2912:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2917:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    291b:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    291f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2924:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2929:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    292d:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2931:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2936:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    293a:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    293f:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    2945:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    294a:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    294f:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    2953:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2958:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    295d:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2961:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2965:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    296b:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    2972:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2976:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    297a:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2980:	44 8b 90 14 01 00 00 	mov    0x114(%rax),%r10d
    2987:	44 8b 88 10 01 00 00 	mov    0x110(%rax),%r9d
    298e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2993:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    299a:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    299e:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    29a3:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2a0b <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a0b>
    29aa:	00 
    29ab:	c4 41 79 6e e2       	vmovd  %r10d,%xmm12
    29b0:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    29b5:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
    29ba:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    29c0:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    29c5:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    29ca:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    29d1:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    29d6:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    29db:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    29e0:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    29e5:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    29ea:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    29ef:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2a57 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a57>
    29f6:	00 
    29f7:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    29fb:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2a63 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a63>
    2a02:	00 
    2a03:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2a08:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2a0d:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    2a12:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2a16:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2a1a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2a1e:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2a22:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2a28:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2a2c:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2a32:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2a36:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2a3c:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2a40:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2a45:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2a49:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2a4e:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2a54:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2a5a:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2a83 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a83>
    2a61:	00 00 70 
    2a64:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2a6a:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2a6f:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2a74:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2a9d <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2a9d>
    2a7b:	00 00 b0 
    2a7e:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2a82:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2a86:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2a8b:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2a8f:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2a94:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2a98:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2a9e:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    2aa3:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    2aa9:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2aae:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2ab3:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    2aba:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    2abf:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2ac4:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2ac8:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    2acc:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2ad1:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2ad6:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2adb:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2ae0:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2ae5:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2aea:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2aef:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2af4:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2af9:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2afd:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2b01:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2b07:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    2b0b:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    2b10:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2b15:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    2b1a:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2b1f:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2b24:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2b29:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2b2d:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2b32:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2b37:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b3c:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    2b40:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2b45:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2b4a:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2b4f:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2b54:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2b59:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2b5e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2b63:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2b67:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2b6b:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2b70:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2b75:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2b79:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2b7d:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2b82:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2b86:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    2b8b:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    2b91:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2b96:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    2b9b:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    2b9f:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2ba4:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    2ba9:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2bad:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2bb1:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    2bb7:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2bbe:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2bc2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2bc6:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2bcc:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    2bd3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2bd8:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2bdc:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2be1:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2be7:	44 8b 90 74 01 00 00 	mov    0x174(%rax),%r10d
    2bee:	44 8b 88 70 01 00 00 	mov    0x170(%rax),%r9d
    2bf5:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    2bfa:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    2bff:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    2c06:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 2c6e <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2c6e>
    2c0d:	00 
    2c0e:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c12:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
    2c17:	c4 41 79 6e e2       	vmovd  %r10d,%xmm12
    2c1c:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
    2c21:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2c26:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2c2b:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
    2c30:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2c35:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2c3a:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2c3f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2ca7 <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ca7>
    2c46:	00 
    2c47:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 2caf <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2caf>
    2c4e:	00 
    2c4f:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2c54:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2c59:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    2c5e:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2c62:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2c66:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2c6a:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2c6e:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2c74:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c78:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2c7e:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2c82:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2c88:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2c8c:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2c91:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2c95:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2c9a:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2ca0:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2ca6:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2ccf <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ccf>
    2cad:	00 00 70 
    2cb0:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2cb6:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2cbb:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2cc0:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2cc4:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2ced <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ced>
    2ccb:	00 00 b0 
    2cce:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2cd2:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2cd7:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    2cdb:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2ce0:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2ce4:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2cea:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    2cef:	c4 e2 4d 90 2c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm5
    2cf5:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2cfa:	c4 c1 15 db e7       	vpand  %ymm15,%ymm13,%ymm4
    2cff:	c4 c1 55 db cf       	vpand  %ymm15,%ymm5,%ymm1
    2d04:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    2d09:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
    2d0d:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2d11:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    2d16:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2d1b:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2d20:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2d25:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2d2a:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2d2f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2d34:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2d39:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2d3e:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2d42:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    2d46:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2d4c:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    2d50:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    2d55:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2d5a:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2d5f:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2d64:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2d69:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2d6e:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2d72:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2d77:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2d7c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    2d81:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    2d85:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    2d8a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    2d8f:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2d94:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2d99:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2d9e:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2da3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2da8:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    2dac:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    2db0:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2db5:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2dba:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2dbe:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    2dc3:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2dc7:	c4 c1 5d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm4
    2dcd:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2dd2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2dd7:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    2ddc:	c5 ed fa e4          	vpsubd %ymm4,%ymm2,%ymm4
    2de0:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2de5:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2dea:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    2dee:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2df2:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2df6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2dfb:	e9 ef f3 ff ff       	jmp    21ef <jshc_channel::avx2_chain_cached(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21ef>

0000000000002e00 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    2e00:	57                   	push   %rdi
    2e01:	56                   	push   %rsi
    2e02:	53                   	push   %rbx
    2e03:	48 81 ec 80 02 00 00 	sub    $0x280,%rsp
    2e0a:	c5 f8 29 b4 24 e0 01 	vmovaps %xmm6,0x1e0(%rsp)
    2e11:	00 00 
    2e13:	c5 f8 29 bc 24 f0 01 	vmovaps %xmm7,0x1f0(%rsp)
    2e1a:	00 00 
    2e1c:	c5 78 29 84 24 00 02 	vmovaps %xmm8,0x200(%rsp)
    2e23:	00 00 
    2e25:	c5 78 29 8c 24 10 02 	vmovaps %xmm9,0x210(%rsp)
    2e2c:	00 00 
    2e2e:	c5 78 29 94 24 20 02 	vmovaps %xmm10,0x220(%rsp)
    2e35:	00 00 
    2e37:	c5 78 29 9c 24 30 02 	vmovaps %xmm11,0x230(%rsp)
    2e3e:	00 00 
    2e40:	c5 78 29 a4 24 40 02 	vmovaps %xmm12,0x240(%rsp)
    2e47:	00 00 
    2e49:	c5 78 29 ac 24 50 02 	vmovaps %xmm13,0x250(%rsp)
    2e50:	00 00 
    2e52:	c5 78 29 b4 24 60 02 	vmovaps %xmm14,0x260(%rsp)
    2e59:	00 00 
    2e5b:	c5 78 29 bc 24 70 02 	vmovaps %xmm15,0x270(%rsp)
    2e62:	00 00 
    2e64:	49 89 d3             	mov    %rdx,%r11
    2e67:	48 83 fa 04          	cmp    $0x4,%rdx
    2e6b:	0f 84 0a 07 00 00    	je     357b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x77b>
    2e71:	4d 85 c9             	test   %r9,%r9
    2e74:	0f 84 8c 06 00 00    	je     3506 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
    2e7a:	c5 fd 6f 1d 00 00 00 	vmovdqa 0x0(%rip),%ymm3        # 2e82 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x82>
    2e81:	00 
    2e82:	49 ff c9             	dec    %r9
    2e85:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
    2e89:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    2e8e:	49 c1 e9 03          	shr    $0x3,%r9
    2e92:	49 c1 e2 05          	shl    $0x5,%r10
    2e96:	c4 c1 35 72 d2 18    	vpsrld $0x18,%ymm10,%ymm9
    2e9c:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    2ea0:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
    2ea7:	00 00 
    2ea9:	c5 fd 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm3        # 2ef1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf1>
    2eb0:	00 
    2eb1:	49 01 ca             	add    %rcx,%r10
    2eb4:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    2eb9:	b8 00 80 00 00       	mov    $0x8000,%eax
    2ebe:	c5 fe 7f 9c 24 c0 01 	vmovdqu %ymm3,0x1c0(%rsp)
    2ec5:	00 00 
    2ec7:	c5 f9 6e d8          	vmovd  %eax,%xmm3
    2ecb:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2ed0:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
    2ed5:	0f 1f 00             	nopl   (%rax)
    2ed8:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    2edd:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    2ee3:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2ee9:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2eef:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
    2ef6:	01 00 00 
    2ef9:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    2efe:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
    2f03:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    2f08:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2f0d:	4d 85 db             	test   %r11,%r11
    2f10:	0f 84 5a 06 00 00    	je     3570 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x770>
    2f16:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
    2f1d:	00 00 
    2f1f:	48 89 c8             	mov    %rcx,%rax
    2f22:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    2f29:	00 00 
    2f2b:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    2f32:	00 00 
    2f34:	e9 d6 00 00 00       	jmp    300f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20f>
    2f39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2f40:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    2f47:	00 00 
    2f49:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
    2f4e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2f53:	48 83 c0 60          	add    $0x60,%rax
    2f57:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    2f5c:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    2f61:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    2f66:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    2f6b:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    2f6f:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    2f73:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    2f78:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    2f7d:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
    2f83:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    2f88:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2f8c:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    2f93:	00 00 
    2f95:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2f99:	c5 ed 72 d7 10       	vpsrld $0x10,%ymm7,%ymm2
    2f9e:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    2fa3:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2fa8:	c5 9d fa da          	vpsubd %ymm2,%ymm12,%ymm3
    2fac:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    2fb0:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
    2fb6:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    2fbb:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    2fc0:	c5 dd fa 64 24 60    	vpsubd 0x60(%rsp),%ymm4,%ymm4
    2fc6:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2fcb:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    2fcf:	c5 dd fe a4 24 40 01 	vpaddd 0x140(%rsp),%ymm4,%ymm4
    2fd6:	00 00 
    2fd8:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2fdc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2fe1:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
    2fe5:	4c 39 d0             	cmp    %r10,%rax
    2fe8:	0f 84 bc 04 00 00    	je     34aa <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6aa>
    2fee:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2ff4:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    2ffb:	00 00 
    2ffd:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
    3004:	00 00 
    3006:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    300d:	00 00 
    300f:	48 8b 70 08          	mov    0x8(%rax),%rsi
    3013:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
    301a:	00 00 
    301c:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3020:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    3025:	8b 58 54             	mov    0x54(%rax),%ebx
    3028:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    302f:	00 00 
    3031:	c4 e2 5d 90 1c be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm3
    3037:	48 8b 30             	mov    (%rax),%rsi
    303a:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    3041:	00 00 
    3043:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3047:	c5 79 6e eb          	vmovd  %ebx,%xmm13
    304b:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    3050:	48 8b 78 10          	mov    0x10(%rax),%rdi
    3054:	48 8b 50 48          	mov    0x48(%rax),%rdx
    3058:	c4 e2 5d 90 04 be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm0
    305e:	8b 70 50             	mov    0x50(%rax),%esi
    3061:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3066:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    306a:	c5 d5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm5
    306f:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    3074:	c4 e2 5d 90 14 b7    	vpgatherdd %ymm4,(%rdi,%ymm6,4),%ymm2
    307a:	c5 79 6e f6          	vmovd  %esi,%xmm14
    307e:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    3083:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    3087:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    308c:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 30f4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f4>
    3093:	00 
    3094:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 30fc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2fc>
    309b:	00 
    309c:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
    30a1:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 3109 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x309>
    30a8:	00 
    30a9:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    30ad:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    30b1:	c4 e2 65 39 e8       	vpminsd %ymm0,%ymm3,%ymm5
    30b6:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
    30ba:	c4 62 55 39 da       	vpminsd %ymm2,%ymm5,%ymm11
    30bf:	c5 d5 66 ea          	vpcmpgtd %ymm2,%ymm5,%ymm5
    30c3:	c4 a2 45 90 0c ba    	vpgatherdd %ymm7,(%rdx,%ymm15,4),%ymm1
    30c9:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    30ce:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    30d4:	c4 e2 65 3d e0       	vpmaxsd %ymm0,%ymm3,%ymm4
    30d9:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    30df:	c4 62 5d 3d c2       	vpmaxsd %ymm2,%ymm4,%ymm8
    30e4:	c5 ed 66 e4          	vpcmpgtd %ymm4,%ymm2,%ymm4
    30e8:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    30ed:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
    30f2:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    30f9:	00 00 
    30fb:	c5 fe 7f b4 24 60 01 	vmovdqu %ymm6,0x160(%rsp)
    3102:	00 00 
    3104:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    3109:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    310e:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
    3113:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
    3119:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    311f:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
    3124:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    3129:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    312d:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
    3134:	00 00 
    3136:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    313b:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
    3141:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
    3147:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    314c:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    3150:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    3157:	00 00 
    3159:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    315d:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    3162:	c4 c1 75 fe ff       	vpaddd %ymm15,%ymm1,%ymm7
    3167:	c5 fd 66 cb          	vpcmpgtd %ymm3,%ymm0,%ymm1
    316b:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    3172:	00 00 
    3174:	c4 e2 1d 90 34 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm6
    317a:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    317f:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
    3186:	00 00 
    3188:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    318c:	c4 c3 0d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm14,%ymm1
    3192:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm1,%ymm1        # 31bb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3bb>
    3199:	00 00 50 
    319c:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    31a0:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
    31a5:	c4 e2 1d 90 2c 8a    	vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm5
    31ab:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    31b0:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
    31b7:	00 00 
    31b9:	c5 e5 66 e8          	vpcmpgtd %ymm0,%ymm3,%ymm5
    31bd:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    31c1:	c5 b5 db 8c 24 e0 00 	vpand  0xe0(%rsp),%ymm9,%ymm1
    31c8:	00 00 
    31ca:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    31ce:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    31d5:	00 00 
    31d7:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    31dd:	c5 c5 fa f9          	vpsubd %ymm1,%ymm7,%ymm7
    31e1:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 320a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x40a>
    31e8:	00 00 40 
    31eb:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    31f0:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    31f4:	c4 e2 1d 90 24 aa    	vpgatherdd %ymm12,(%rdx,%ymm5,4),%ymm4
    31fa:	c5 6d fe 24 24       	vpaddd (%rsp),%ymm2,%ymm12
    31ff:	c4 c1 5d db e9       	vpand  %ymm9,%ymm4,%ymm5
    3204:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    3208:	c5 d5 fa 6c 24 20    	vpsubd 0x20(%rsp),%ymm5,%ymm5
    320e:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
    3213:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3218:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    321d:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    3221:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3225:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    322a:	c5 f5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm1
    322f:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3234:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    323a:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    323f:	c4 41 4d db e1       	vpand  %ymm9,%ymm6,%ymm12
    3244:	0f 85 f6 fc ff ff    	jne    2f40 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
    324a:	48 8b 58 28          	mov    0x28(%rax),%rbx
    324e:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    3255:	00 00 
    3257:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    325b:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    325f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    3266:	00 00 
    3268:	c4 41 7d 6f da       	vmovdqa %ymm10,%ymm11
    326d:	48 83 c0 60          	add    $0x60,%rax
    3271:	c4 e2 5d 90 1c 83    	vpgatherdd %ymm4,(%rbx,%ymm0,4),%ymm3
    3277:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
    327b:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
    3282:	00 00 
    3284:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 32ec <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ec>
    328b:	00 
    328c:	c4 e2 4d 90 24 83    	vpgatherdd %ymm6,(%rbx,%ymm0,4),%ymm4
    3292:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
    3296:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    329a:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3302 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x502>
    32a1:	00 
    32a2:	c4 e2 4d 90 04 bb    	vpgatherdd %ymm6,(%rbx,%ymm7,4),%ymm0
    32a8:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
    32ac:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3314 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
    32b3:	00 
    32b4:	c4 e2 7d 3d fc       	vpmaxsd %ymm4,%ymm0,%ymm7
    32b9:	c5 dd 66 e8          	vpcmpgtd %ymm0,%ymm4,%ymm5
    32bd:	c4 e2 7d 39 f4       	vpminsd %ymm4,%ymm0,%ymm6
    32c2:	c5 e5 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm2
    32c6:	c4 62 4d 39 c3       	vpminsd %ymm3,%ymm6,%ymm8
    32cb:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    32d0:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
    32d4:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    32da:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 3303 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x503>
    32e1:	00 00 20 
    32e4:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    32e8:	c4 e2 25 90 14 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm2
    32ee:	c5 fd 66 ec          	vpcmpgtd %ymm4,%ymm0,%ymm5
    32f2:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    32f9:	00 00 
    32fb:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    32ff:	c5 fe 7f 94 24 e0 00 	vmovdqu %ymm2,0xe0(%rsp)
    3306:	00 00 
    3308:	c5 7d 7f d2          	vmovdqa %ymm10,%ymm2
    330c:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
    3313:	00 00 
    3315:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    331b:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 3344 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x544>
    3322:	00 00 60 
    3325:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    3329:	c4 e2 6d 90 34 aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm6
    332f:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
    3336:	00 00 
    3338:	c4 c1 45 fe e8       	vpaddd %ymm8,%ymm7,%ymm5
    333d:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    3342:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    3346:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    334b:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    3350:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    3354:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    3359:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    335d:	c5 cd fa da          	vpsubd %ymm2,%ymm6,%ymm3
    3361:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
    3367:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    336c:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    3371:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    3375:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    337a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    337e:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    3385:	00 00 
    3387:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    338b:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    3390:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
    3396:	c4 e2 65 90 04 a3    	vpgatherdd %ymm3,(%rbx,%ymm4,4),%ymm0
    339c:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    33a0:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3408 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x608>
    33a7:	00 
    33a8:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
    33ac:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    33b3:	00 00 
    33b5:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    33bc:	00 00 
    33be:	48 8b 78 d0          	mov    -0x30(%rax),%rdi
    33c2:	c4 e2 65 90 24 b3    	vpgatherdd %ymm3,(%rbx,%ymm6,4),%ymm4
    33c8:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    33cc:	c4 e2 4d 90 1c bf    	vpgatherdd %ymm6,(%rdi,%ymm7,4),%ymm3
    33d2:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 343a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
    33d9:	00 
    33da:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3442 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x642>
    33e1:	00 
    33e2:	c4 e2 65 3d f4       	vpmaxsd %ymm4,%ymm3,%ymm6
    33e7:	c5 dd 66 eb          	vpcmpgtd %ymm3,%ymm4,%ymm5
    33eb:	c4 e2 65 39 fc       	vpminsd %ymm4,%ymm3,%ymm7
    33f0:	c5 fd 66 d6          	vpcmpgtd %ymm6,%ymm0,%ymm2
    33f4:	c4 62 45 39 c0       	vpminsd %ymm0,%ymm7,%ymm8
    33f9:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
    33fe:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
    3402:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    3408:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 3431 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x631>
    340f:	00 00 20 
    3412:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
    3416:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    341b:	c4 e2 05 90 14 aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm2
    3421:	c5 e5 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm5
    3425:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    342a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    342f:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3433:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    3438:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
    343e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 3467 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x667>
    3445:	00 00 70 
    3448:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    344c:	c4 e2 05 90 3c aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm7
    3452:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
    3457:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    345c:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    3460:	c4 c1 45 db f9       	vpand  %ymm9,%ymm7,%ymm7
    3465:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3469:	c5 c5 fa da          	vpsubd %ymm2,%ymm7,%ymm3
    346d:	c5 ed fa 54 24 60    	vpsubd 0x60(%rsp),%ymm2,%ymm2
    3473:	c5 1d fa e7          	vpsubd %ymm7,%ymm12,%ymm12
    3477:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    347c:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    3481:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    3486:	c5 ed fe 94 24 40 01 	vpaddd 0x140(%rsp),%ymm2,%ymm2
    348d:	00 00 
    348f:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
    3494:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    3498:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    349d:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
    34a1:	49 39 c2             	cmp    %rax,%r10
    34a4:	0f 85 44 fb ff ff    	jne    2fee <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ee>
    34aa:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    34b0:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    34b6:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    34bb:	49 83 c0 18          	add    $0x18,%r8
    34bf:	c5 ed 72 f3 08       	vpslld $0x8,%ymm3,%ymm2
    34c4:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    34c8:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    34cc:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    34d3:	01 00 00 
    34d6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    34da:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    34e0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    34e5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    34ea:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    34ee:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    34f4:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    34fa:	4d 39 c1             	cmp    %r8,%r9
    34fd:	0f 85 d5 f9 ff ff    	jne    2ed8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
    3503:	c5 f8 77             	vzeroupper
    3506:	c5 f8 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm6
    350d:	00 00 
    350f:	c5 f8 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm7
    3516:	00 00 
    3518:	c5 78 28 84 24 00 02 	vmovaps 0x200(%rsp),%xmm8
    351f:	00 00 
    3521:	c5 78 28 8c 24 10 02 	vmovaps 0x210(%rsp),%xmm9
    3528:	00 00 
    352a:	c5 78 28 94 24 20 02 	vmovaps 0x220(%rsp),%xmm10
    3531:	00 00 
    3533:	c5 78 28 9c 24 30 02 	vmovaps 0x230(%rsp),%xmm11
    353a:	00 00 
    353c:	c5 78 28 a4 24 40 02 	vmovaps 0x240(%rsp),%xmm12
    3543:	00 00 
    3545:	c5 78 28 ac 24 50 02 	vmovaps 0x250(%rsp),%xmm13
    354c:	00 00 
    354e:	c5 78 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm14
    3555:	00 00 
    3557:	c5 78 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm15
    355e:	00 00 
    3560:	48 81 c4 80 02 00 00 	add    $0x280,%rsp
    3567:	5b                   	pop    %rbx
    3568:	5e                   	pop    %rsi
    3569:	5f                   	pop    %rdi
    356a:	c3                   	ret
    356b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3570:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    3576:	e9 35 ff ff ff       	jmp    34b0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6b0>
    357b:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    357f:	0f 85 ec f8 ff ff    	jne    2e71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    3585:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    358c:	0f 84 df f8 ff ff    	je     2e71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    3592:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    3599:	0f 84 d2 f8 ff ff    	je     2e71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    359f:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    35a6:	0f 84 c5 f8 ff ff    	je     2e71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    35ac:	4d 85 c9             	test   %r9,%r9
    35af:	0f 84 51 ff ff ff    	je     3506 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
    35b5:	c5 fd 6f 25 00 00 00 	vmovdqa 0x0(%rip),%ymm4        # 35bd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7bd>
    35bc:	00 
    35bd:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    35c1:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    35c6:	48 c1 e8 03          	shr    $0x3,%rax
    35ca:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
    35d0:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    35d4:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
    35db:	00 00 
    35dd:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # 3625 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x825>
    35e4:	00 
    35e5:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    35ea:	b8 00 80 00 00       	mov    $0x8000,%eax
    35ef:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    35f6:	00 00 
    35f8:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    35fc:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3601:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
    3606:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    360b:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    3611:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3615:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    361a:	48 8b 01             	mov    (%rcx),%rax
    361d:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    3621:	49 83 c0 18          	add    $0x18,%r8
    3625:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    362b:	8b 51 50             	mov    0x50(%rcx),%edx
    362e:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    3634:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    3639:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
    3640:	01 00 00 
    3643:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    3647:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    364c:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
    3651:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    3656:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    365b:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    3661:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    3666:	c4 c1 35 db f6       	vpand  %ymm14,%ymm9,%ymm6
    366b:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3670:	c4 e2 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm0
    3676:	48 8b 41 08          	mov    0x8(%rcx),%rax
    367a:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    3680:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3684:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    3688:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
    368e:	48 8b 41 10          	mov    0x10(%rcx),%rax
    3692:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3696:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    369b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3703 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x903>
    36a2:	00 
    36a3:	c4 a2 65 90 24 a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm4
    36a9:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    36ae:	48 8b 41 48          	mov    0x48(%rcx),%rax
    36b2:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 371a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x91a>
    36b9:	00 
    36ba:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    36bf:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    36c4:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    36c9:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3731 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x931>
    36d0:	00 
    36d1:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    36d6:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    36db:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    36df:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    36e3:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    36e7:	c4 62 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm13
    36ed:	c5 f9 6e da          	vmovd  %edx,%xmm3
    36f1:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    36f6:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    36fa:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
    3700:	c4 62 3d 3d fc       	vpmaxsd %ymm4,%ymm8,%ymm15
    3705:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    370a:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    3711:	00 00 
    3713:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    3717:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    371c:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    3723:	00 00 
    3725:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    3729:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    372f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # 3758 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x958>
    3736:	00 00 a0 
    3739:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    373e:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    3742:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
    3748:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    374c:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    3750:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    3756:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # 377f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x97f>
    375d:	00 00 80 
    3760:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    3765:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    3769:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    376f:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
    3775:	c4 c1 05 db ee       	vpand  %ymm14,%ymm15,%ymm5
    377a:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
    3781:	00 00 
    3783:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    3788:	c5 0d db 6c 24 60    	vpand  0x60(%rsp),%ymm14,%ymm13
    378e:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3792:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    3797:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    379d:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    37a1:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    37a5:	c4 c1 3d 72 f5 10    	vpslld $0x10,%ymm13,%ymm8
    37ab:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    37b0:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    37b5:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    37ba:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    37c1:	00 00 00 
    37c4:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    37c9:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    37cd:	c5 8d db a4 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm4
    37d4:	00 00 
    37d6:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    37db:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    37e0:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    37e5:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    37e9:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    37ed:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    37f3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    37f8:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    37ff:	00 00 
    3801:	c4 a2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm5
    3807:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    380b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3873 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa73>
    3812:	00 
    3813:	c4 62 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm8
    3819:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    381d:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    3822:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 388a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa8a>
    3829:	00 
    382a:	c4 e2 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm0
    3830:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3898 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa98>
    3837:	00 
    3838:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    383d:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    3841:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    3845:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    384a:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    384f:	c4 62 4d 39 ed       	vpminsd %ymm5,%ymm6,%ymm13
    3854:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    3858:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    385e:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    3865:	00 00 
    3867:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # 3890 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa90>
    386e:	00 00 a0 
    3871:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    3876:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    387a:	c4 62 2d 90 2c a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm13
    3880:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    3885:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    388a:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    388f:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    3894:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    389a:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 38c3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xac3>
    38a1:	00 00 60 
    38a4:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    38a8:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    38ae:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
    38b4:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    38b9:	c4 c1 5d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm4
    38bf:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    38c6:	00 00 
    38c8:	c4 41 5d db fe       	vpand  %ymm14,%ymm4,%ymm15
    38cd:	c4 c1 5d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm4
    38d3:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    38da:	00 00 
    38dc:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    38e2:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    38e7:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
    38ec:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    38f3:	00 00 
    38f5:	c4 41 4d db d6       	vpand  %ymm14,%ymm6,%ymm10
    38fa:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    38ff:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
    3905:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    3909:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    390d:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    3912:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    3917:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    391c:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3921:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    3925:	c5 8d db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm14,%ymm0
    392c:	00 00 
    392e:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3932:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    3938:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    393d:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    3944:	00 00 00 
    3947:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    394b:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    394f:	c4 a2 3d 90 04 a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm0
    3955:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    3959:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    395e:	c5 95 72 d5 10       	vpsrld $0x10,%ymm5,%ymm13
    3963:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 39cb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbcb>
    396a:	00 
    396b:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    3970:	c4 e2 3d 90 2c b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm5
    3976:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    397a:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    3980:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    3985:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 39ed <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbed>
    398c:	00 
    398d:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    3993:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 39fb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbfb>
    399a:	00 
    399b:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    39a0:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    39a4:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    39a9:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    39ae:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    39b4:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 39dd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbdd>
    39bb:	00 00 90 
    39be:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    39c3:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    39c7:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    39cc:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    39d0:	c4 e2 1d 90 14 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm2
    39d6:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    39da:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    39de:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    39e4:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    39e8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # 3a11 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc11>
    39ef:	00 00 90 
    39f2:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    39f7:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    39fb:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    3a00:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    3a05:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    3a0b:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3a10:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    3a16:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3a1a:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    3a1f:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    3a26:	00 00 
    3a28:	48 8b 41 60          	mov    0x60(%rcx),%rax
    3a2c:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
    3a31:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3a36:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    3a3a:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3a3f:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    3a44:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    3a49:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    3a4e:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    3a52:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    3a59:	00 00 
    3a5b:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    3a60:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    3a65:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    3a69:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3a6e:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    3a72:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    3a76:	c4 e2 4d 90 24 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm4
    3a7c:	48 8b 41 68          	mov    0x68(%rcx),%rax
    3a80:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3a84:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3a89:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3a8d:	c4 a2 65 90 2c a8    	vpgatherdd %ymm3,(%rax,%ymm13,4),%ymm5
    3a93:	48 8b 41 70          	mov    0x70(%rcx),%rax
    3a97:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    3a9e:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3aa2:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    3aa8:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3aad:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3ab1:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3ab6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3abb:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    3ac2:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    3ac6:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3acb:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3ad0:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3ad4:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3ad9:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3b41 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd41>
    3ae0:	00 
    3ae1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3ae6:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3aec:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3af1:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    3af8:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3afc:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3b01:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3b06:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3b6e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd6e>
    3b0d:	00 
    3b0e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3b76 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd76>
    3b15:	00 
    3b16:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3b1b:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    3b20:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    3b25:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    3b29:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    3b2d:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    3b31:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3b35:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3b39:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3b3e:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    3b44:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    3b48:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    3b4e:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    3b54:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    3b58:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    3b5d:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    3b61:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    3b66:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    3b6b:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    3b71:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 3b9a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd9a>
    3b78:	00 00 70 
    3b7b:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    3b80:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    3b84:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3b88:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    3b8d:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    3b92:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    3b98:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    3b9e:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3ba4:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    3ba9:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 3bd2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdd2>
    3bb0:	00 00 c0 
    3bb3:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    3bb8:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    3bbd:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    3bc1:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    3bc5:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    3bca:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    3bd0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3bd5:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3bda:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    3be1:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3be6:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    3beb:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    3bef:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    3bf3:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3bf8:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3bfd:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    3c02:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3c07:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    3c0c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3c11:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3c15:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    3c1a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3c1e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    3c23:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    3c28:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3c2d:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    3c33:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    3c38:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    3c3d:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    3c42:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    3c47:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    3c4c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3c51:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    3c55:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3c5a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3c5f:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    3c64:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    3c69:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    3c6e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3c73:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3c78:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3c7d:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3c82:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    3c87:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3c8b:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3c90:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    3c95:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3c9a:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    3c9f:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3ca4:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    3ca9:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    3cad:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    3cb1:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    3cb5:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3cba:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    3cbf:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3cc4:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    3cc9:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3ccd:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    3cd1:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3cd5:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3cd9:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3cdf:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    3ce6:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3cea:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3cee:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3cf3:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    3cf9:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    3d00:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d04:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3d09:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3d0f:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    3d15:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3d1a:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    3d21:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3d26:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3d2b:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3d2f:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3d33:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3d38:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3da0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfa0>
    3d3f:	00 
    3d40:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    3d47:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3d4c:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3db4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb4>
    3d53:	00 
    3d54:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3dbc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfbc>
    3d5b:	00 
    3d5c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3d61:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3d66:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    3d6b:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    3d70:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    3d74:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    3d78:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    3d7c:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3d80:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    3d86:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3d8a:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3d8f:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    3d95:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    3d99:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    3d9f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    3da5:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    3da9:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    3dae:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    3db2:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    3db7:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    3dbc:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    3dc2:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 3deb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfeb>
    3dc9:	00 00 70 
    3dcc:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    3dd1:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    3dd5:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3dd9:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    3dde:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    3de3:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    3de9:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    3def:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3df5:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    3dfa:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 3e23 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1023>
    3e01:	00 00 c0 
    3e04:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    3e09:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    3e0e:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    3e12:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    3e16:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    3e1b:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    3e21:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3e26:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3e2b:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    3e32:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    3e37:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    3e3c:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    3e40:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    3e44:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3e49:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3e4e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    3e53:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    3e58:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    3e5d:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3e62:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3e66:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    3e6b:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3e6f:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    3e74:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    3e79:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    3e7e:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    3e84:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    3e89:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    3e8e:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    3e93:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    3e98:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    3e9d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3ea2:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    3ea6:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    3eab:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3eb0:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    3eb5:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    3eba:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    3ebf:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    3ec4:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3ec9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3ece:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3ed3:	c5 79 6e ca          	vmovd  %edx,%xmm9
    3ed7:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    3edc:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    3ee1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    3ee6:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3eea:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    3eef:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    3ef4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3ef9:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    3efe:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    3f03:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    3f08:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    3f0c:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    3f10:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    3f14:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3f19:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    3f1e:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3f23:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    3f28:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    3f2c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    3f30:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3f34:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3f38:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3f3e:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    3f45:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3f49:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3f4d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3f52:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    3f58:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    3f5f:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3f63:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3f68:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3fd0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d0>
    3f6f:	00 
    3f70:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    3f76:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    3f7b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3fe3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11e3>
    3f82:	00 
    3f83:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3f88:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3f8d:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    3f91:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    3f96:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3ffe <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11fe>
    3f9d:	00 
    3f9e:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    3fa5:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    3faa:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    3faf:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    3fb3:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    3fb8:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    3fbc:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    3fc0:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3fc4:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3fc8:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3fcd:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    3fd3:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    3fd7:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    3fdd:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    3fe3:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    3fe7:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    3fec:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    3ff0:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    3ff5:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    3ffb:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 4024 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1224>
    4002:	00 00 70 
    4005:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    400a:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    400e:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4012:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    4017:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    401c:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    4021:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    4027:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    402d:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    4033:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    4038:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 4061 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1261>
    403f:	00 00 c0 
    4042:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    4047:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    404c:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    4050:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    4054:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
    4059:	c4 e2 5d 90 2c 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm5
    405f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4064:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    4069:	c4 c1 55 db d6       	vpand  %ymm14,%ymm5,%ymm2
    406e:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    4073:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    4077:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    407b:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    4080:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    4085:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    408a:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    408f:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    4094:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    4099:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    409d:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    40a2:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    40a6:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    40ab:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    40b0:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    40b5:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    40bb:	c5 8d db f6          	vpand  %ymm6,%ymm14,%ymm6
    40bf:	c5 8d db d2          	vpand  %ymm2,%ymm14,%ymm2
    40c3:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    40c8:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    40cd:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    40d2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    40d7:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    40db:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    40e0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    40e5:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    40ea:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    40ef:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    40f4:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    40f9:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    40fe:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    4103:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    4107:	c4 c1 75 db f6       	vpand  %ymm14,%ymm1,%ymm6
    410c:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4111:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4116:	c4 c1 65 db ee       	vpand  %ymm14,%ymm3,%ymm5
    411b:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    4120:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    4125:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    4129:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    412d:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    4131:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    4136:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    413b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4140:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    4145:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    414a:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    414e:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    4152:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4156:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    415b:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    4160:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    4164:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    4168:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    416f:	01 00 00 
    4172:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    4176:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    417c:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    4181:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    4186:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    418a:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    4190:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    4196:	4d 39 c2             	cmp    %r8,%r10
    4199:	0f 85 67 f4 ff ff    	jne    3606 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x806>
    419f:	e9 5f f3 ff ff       	jmp    3503 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x703>
    41a4:	90                   	nop
    41a5:	90                   	nop
    41a6:	90                   	nop
    41a7:	90                   	nop
    41a8:	90                   	nop
    41a9:	90                   	nop
    41aa:	90                   	nop
    41ab:	90                   	nop
    41ac:	90                   	nop
    41ad:	90                   	nop
    41ae:	90                   	nop
    41af:	90                   	nop
