
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/p16-direct-compile/compile_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/p16-direct-compile/compile_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/p16-direct-compile/compile_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/andn_outplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/normal_inplace/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-andn-normal-runtime/outplace_bench.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-exception-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/F_/Hackathon/worktrees/p16-speed-20261023/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.obj.d"
  "F:/Hackathon/worktrees/p16-speed-20261023/experiments/p16-shared-domain-runtime/channel_runtime.cpp" "CMakeFiles/jshc_shared_domain.dir/channel_runtime.cpp.obj" "gcc" "CMakeFiles/jshc_shared_domain.dir/channel_runtime.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
