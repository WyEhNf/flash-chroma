# Empty dependencies file for jshc_shared_domain.
# This may be replaced when dependencies are built.
