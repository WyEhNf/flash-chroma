# 四后端固定比较入口

本包只包含已验的原实现、无损坐标差、精确缓存及其组合，修订2/5/4/6；静态停止原型不参与。复用既有a399模型、100图字节及完整整数预期，不重新拟合或变更质量。原照片用途限制保存在assets/photos/manifest.json，不声明新许可，原始大流只在本地传输包。

Linux x86_64需要Python 3.11及以上标准库、CMake 3.24及以上、GNU C/C++和OpenMP，无需NumPy/Pillow。解包进入目录后：

```sh
python3 scripts/run_skylake_matrix.py --bundle bundle-manifest.json --output artifacts/server-matrix-v1 --compiler /usr/bin/g++ --c-compiler /usr/bin/gcc --measure
```

省略--measure只完成集中正确性。--cpus可指定同L3/NUMA的4个不同物理核，默认从实际允许集合选择；--expected-cpu须匹配所选各CPU的完整型号原文，只作SKU核对，不自动判定微架构。

入口逐字节检查包，在该机器独立构建两组共4库和原生计时器。先验有限边界、24组完整256³、缓存全表与100图，再冻结本次库/正确性身份，显式执行唯一四进程同场比较。每角色在每个序位出现一次，1/4线程和整批/逐图模式平衡，每配置5轮，共320轮100图组。准备、apply、copy+apply、外层墙钟和逐图描述性尾部分列，排除IO/解码/拟合。真实C ABI成本与旧内部bench不同，不混用绝对时间。

输出必须新目录；失败保留日志，不自动重跑或调参。实际CPU/微码/GDS、NUMA/缓存、线程落点、编译器及所有已加载库SHA记录；不改安全设置或频率。AMD/WSL的协议验证和计时不能替代Skylake；官方数据/Threshold、侧表/派生缓存许可仍待确认。
