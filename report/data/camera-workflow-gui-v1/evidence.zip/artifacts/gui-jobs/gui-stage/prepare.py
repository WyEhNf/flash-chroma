"""汇总已执行的GUI证据与静态检查，不再次执行RAW。"""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
BASE = ROOT / "artifacts/gui-jobs"
STAGE = BASE / "gui-stage"
files = [p for p in (ROOT / "gui").rglob("*") if p.is_file() and "__pycache__" not in p.parts] + [ROOT / "start-gui.ps1"]
python = [p for p in files if p.suffix == ".py"]
for path in python:
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
subprocess.run(["node", "--check", "gui/static/app.js"], check=True)
html = (ROOT / "gui/static/index.html").read_text(encoding="utf-8")
ids = re.findall(r'id="([^"]+)"', html)
assert len(ids) == len(set(ids))
refs = re.findall(r'\$\("([^"]+)"\)', (ROOT / "gui/static/app.js").read_text(encoding="utf-8"))
assert set(refs) <= set(ids)
old = json.loads((ROOT / "artifacts/camera-raw-workflow-v1/remote-final.json").read_text(encoding="utf-8"))
new = json.loads((STAGE / "remote-preflight.json").read_text(encoding="utf-8"))
prior = {r["issue_number"]: r["body"] for r in old["all_prs"]["issues"]}
latest = {r["issue_number"]: r["body"] for r in new["all_prs"]["issues"]}
assert [n for n in latest if n not in prior] == [83]
assert all(latest[n] == body for n, body in prior.items())
inventory = [{"path": p.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size} for p in files]
(STAGE / "source-inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
result = {
    "purpose": "GUI交付验证汇总，未将受阻的RED/BRAW新GUI运行算作通过",
    "view_checks": json.loads((BASE / "view-verification.json").read_text(encoding="utf-8")),
    "arri_gui": json.loads((BASE / "arri-verification.json").read_text(encoding="utf-8")),
    "static": {"python_ast": len(python), "javascript_syntax": True, "html_unique_ids": len(ids), "literal_js_dom_references": len(set(refs))},
    "remote": {"prior_full_pr_bodies": len(prior), "current_full_pr_bodies": len(latest), "added": [83], "prior_bodies_unchanged": True},
    "gui_ui_observed": ["三家真实缩略图", "ARRI处理首帧及导出按钮实际完成", "BRAW时间轴52/52与1/52", "分割线52%", "HDR及误差模式", "工程内ARRI素材浏览"],
    "blocked": ["WSL启动E_UNEXPECTED/退出1，管理员服务恢复受限", "RED/BRAW新GUI解码", "新导入素材实际处理", "运行中Linux进程组取消", "GUI完整52帧重跑"],
    "native_or_models_changed": False,
}
(STAGE / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"python_ast": len(python), "dom_ids": len(ids), "view_checks": 23, "arri_outputs": 4, "blocked_dynamic_cases": len(result["blocked"])}))
