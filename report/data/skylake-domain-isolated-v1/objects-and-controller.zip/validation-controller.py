"""单次顺序验收：基础、缓存、域证明、完整实际输出，然后唯一逐轮核对性能；失败不重试。"""
import hashlib,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
import psutil
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent
PLAN='experiments/skylake-domain-isolated-v1.json';BUILD='artifacts/skylake-domain-isolated-build-v1'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def spec(p):return {'path':p,'sha256':sha(ROOT/p)}
def save(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def now():return datetime.now(timezone.utc).isoformat()
record=HERE/'validation-commands.json'
if record.exists():raise ValueError('不重跑已开始的阶段')
static=read(ROOT/'artifacts/skylake-domain-isolated-static-v1/results.json')
assert static['static_cost_gate_pass'] and static['plan_sha256']==sha(ROOT/PLAN) and static['build_sha256']==sha(ROOT/BUILD/'build.json')
plan=read(ROOT/PLAN);commands=[]
def run(label,script,args):
 cmd=[sys.executable,'-X','utf8',str(ROOT/script),*args];entry={'label':label,'command':cmd,'started_at_utc':now()};commands.append(entry);save(record,commands)
 with (HERE/(label+'.stdout.log')).open('wb') as out,(HERE/(label+'.stderr.log')).open('wb') as err:
  result=subprocess.run(cmd,cwd=ROOT,stdout=out,stderr=err)
 entry.update(returncode=result.returncode,finished_at_utc=now());save(record,commands)
 if result.returncode:raise RuntimeError(label+'失败，不继续或重试')
 print('完成：'+label,flush=True)
base='artifacts/skylake-domain-isolated-base-contract-v1'
cache='artifacts/skylake-domain-isolated-cache-contract-v1'
domain='artifacts/skylake-domain-isolated-domain-contract-v1'
full='artifacts/skylake-domain-isolated-full-v1'
common=['--plan',PLAN,'--build',BUILD]
run('base-contract','scripts/verify_skylake_packed.py',common+['--output',base])
run('cache-contract','scripts/verify_skylake_suffix_cache.py',common+['--contract',base+'/results.json','--output',cache])
run('domain-contract','scripts/verify_skylake_domain_cache.py',common+['--contract',base+'/results.json','--cache-contract',cache+'/results.json','--output',domain])
run('full','scripts/accept_skylake_runtime.py',common+['--contract',base+'/results.json','--cache-contract',cache+'/results.json','--domain-contract',domain+'/results.json','--output',full])
policy=read(ROOT/'experiments/skylake-r-contiguous-perf-v1.json')
for name in ('extra_validation','storage_contract'):policy.pop(name,None)
policy.update(purpose='缓存修订4与隔离域证明修订16的唯一四进程平衡比较；所有80测量轮均核对完整100图SHA',
 plan=spec(PLAN),build_path=BUILD,build=spec(BUILD+'/build.json'),full_acceptance=spec(full+'/results.json'),
 domain_contract=spec(domain+'/results.json'),verify_each_measured_round=True)
assert policy['adoption_gate']==plan['performance']['adoption_gate']
target=ROOT/'experiments/skylake-domain-isolated-perf-v1.json'
if target.exists():raise ValueError('不覆盖性能冻结')
save(target,policy)
live=[]
for p in psutil.process_iter(['pid','name']):
 if (p.info['name'] or '').lower() in ('g++.exe','gcc.exe','cc1plus.exe','llvm-mca.exe'):
  live.append(p.info)
save(HERE/'performance-preflight.json',{'checked_at_utc':now(),'known_compiler_or_mca_processes':live,
 'scope':'仅已知编译进程检查，不宣称独占整机；完整验收已顺序退出，无修改频率/温度或安全状态',
 'full_result_sha256':sha(ROOT/full/'results.json'),'policy_sha256':sha(target)})
if live:raise ValueError('性能前仍有编译/分析进程，不启动或自动重试')
run('performance','scripts/bench_skylake_runtime.py',['--policy','experiments/skylake-domain-isolated-perf-v1.json','--output','artifacts/skylake-domain-isolated-perf-v1'])
