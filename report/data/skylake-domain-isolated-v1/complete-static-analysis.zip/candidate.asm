
artifacts\skylake-domain-isolated-build-v1\CMakeFiles\jshc_skylake_domain_isolated.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)>:
   0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
   7:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
   e:	00 00 
  10:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
  17:	00 00 
  19:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
  20:	00 00 
  22:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
  29:	00 00 
  2b:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
  32:	00 00 
  34:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
  3b:	00 00 
  3d:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
  44:	00 00 
  46:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
  4d:	00 00 
  4f:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
  56:	00 00 
  58:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
  5f:	00 00 
  61:	48 89 c8             	mov    %rcx,%rax
  64:	48 89 d1             	mov    %rdx,%rcx
  67:	4d 85 c9             	test   %r9,%r9
  6a:	0f 84 63 05 00 00    	je     5d3 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5d3>
  70:	49 ff c9             	dec    %r9
  73:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
  78:	49 c1 e9 03          	shr    $0x3,%r9
  7c:	c4 c1 4d 72 d6 18    	vpsrld $0x18,%ymm14,%ymm6
  82:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
  86:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
  8b:	ba 00 80 00 00       	mov    $0x8000,%edx
  90:	c5 f9 6e d2          	vmovd  %edx,%xmm2
  94:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
  99:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
  a0:	00 00 
  a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  a8:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
  ad:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
  b3:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
  b7:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
  bb:	48 8b 10             	mov    (%rax),%rdx
  be:	44 8b 50 54          	mov    0x54(%rax),%r10d
  c2:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
  c7:	49 83 c0 18          	add    $0x18,%r8
  cb:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
  d1:	44 8b 48 50          	mov    0x50(%rax),%r9d
  d5:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
  db:	c4 41 79 6e c2       	vmovd  %r10d,%xmm8
  e0:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # e9 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe9>
  e7:	00 00 
  e9:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
  ee:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
  f3:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
  f8:	c5 fd db ee          	vpand  %ymm6,%ymm0,%ymm5
  fc:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
 102:	c4 e2 65 90 04 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm0
 108:	c5 f5 db de          	vpand  %ymm6,%ymm1,%ymm3
 10c:	48 8b 50 08          	mov    0x8(%rax),%rdx
 110:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
 114:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
 11a:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
 11f:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 187 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x187>
 126:	00 
 127:	c4 e2 75 90 2c 9a    	vpgatherdd %ymm1,(%rdx,%ymm3,4),%ymm5
 12d:	48 8b 50 10          	mov    0x10(%rax),%rdx
 131:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
 138:	00 00 
 13a:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
 13f:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
 144:	47 8d 4c 0a 01       	lea    0x1(%r10,%r9,1),%r9d
 149:	c4 e2 45 90 1c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm3
 14f:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
 154:	48 8b 50 48          	mov    0x48(%rax),%rdx
 158:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 1c0 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c0>
 15f:	00 
 160:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
 165:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
 16a:	c5 c5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm7
 16f:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 1d7 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d7>
 176:	00 
 177:	c4 62 7d 3d cd       	vpmaxsd %ymm5,%ymm0,%ymm9
 17c:	c4 62 7d 39 d5       	vpminsd %ymm5,%ymm0,%ymm10
 181:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
 185:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
 18a:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
 18e:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
 193:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
 197:	c5 5d fe ea          	vpaddd %ymm2,%ymm4,%ymm13
 19b:	c4 c1 65 66 e1       	vpcmpgtd %ymm9,%ymm3,%ymm4
 1a0:	c4 62 45 90 1c 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm11
 1a6:	c5 7e 7f 2c 24       	vmovdqu %ymm13,(%rsp)
 1ab:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
 1b0:	c4 a2 1d 90 3c aa    	vpgatherdd %ymm12,(%rdx,%ymm13,4),%ymm7
 1b6:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
 1bb:	c4 62 2d 39 e3       	vpminsd %ymm3,%ymm10,%ymm12
 1c0:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
 1c4:	c5 d5 66 f8          	vpcmpgtd %ymm0,%ymm5,%ymm7
 1c8:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
 1cc:	c4 c3 75 4c f8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm7
 1d2:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm7,%ymm7        # 1fb <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1fb>
 1d9:	00 00 40 
 1dc:	c5 ed fe ff          	vpaddd %ymm7,%ymm2,%ymm7
 1e0:	c4 e2 15 90 24 ba    	vpgatherdd %ymm13,(%rdx,%ymm7,4),%ymm4
 1e6:	c5 fd 66 fd          	vpcmpgtd %ymm5,%ymm0,%ymm7
 1ea:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
 1ef:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
 1f3:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
 1f7:	c4 c3 75 4c f8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm7
 1fd:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm7,%ymm7        # 226 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x226>
 204:	00 00 a0 
 207:	c5 95 fa ff          	vpsubd %ymm7,%ymm13,%ymm7
 20b:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
 210:	c4 62 15 90 14 ba    	vpgatherdd %ymm13,(%rdx,%ymm7,4),%ymm10
 216:	c4 41 35 fe ec       	vpaddd %ymm12,%ymm9,%ymm13
 21b:	c5 7e 7f 5c 24 60    	vmovdqu %ymm11,0x60(%rsp)
 221:	4c 8b 48 28          	mov    0x28(%rax),%r9
 225:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
 229:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
 22e:	c5 4d db 5c 24 60    	vpand  0x60(%rsp),%ymm6,%ymm11
 234:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
 23b:	00 00 
 23d:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
 241:	c5 ad fa dc          	vpsubd %ymm4,%ymm10,%ymm3
 245:	c4 e2 7d 40 db       	vpmulld %ymm3,%ymm0,%ymm3
 24a:	c4 c1 4d db c7       	vpand  %ymm15,%ymm6,%ymm0
 24f:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
 254:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
 259:	c4 c1 45 72 f3 10    	vpslld $0x10,%ymm11,%ymm7
 25f:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
 264:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
 269:	c5 c5 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm7,%ymm7
 270:	00 00 
 272:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
 277:	c5 e5 fe ff          	vpaddd %ymm7,%ymm3,%ymm7
 27b:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
 281:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
 285:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
 28b:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
 28f:	c5 9d 72 d7 10       	vpsrld $0x10,%ymm7,%ymm12
 294:	c5 7e 7f a4 24 e0 00 	vmovdqu %ymm12,0xe0(%rsp)
 29b:	00 00 
 29d:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
 2a2:	c4 c2 2d 90 3c a9    	vpgatherdd %ymm10,(%r9,%ymm5,4),%ymm7
 2a8:	4c 8b 48 20          	mov    0x20(%rax),%r9
 2ac:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
 2b1:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # 319 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x319>
 2b8:	00 
 2b9:	c4 42 2d 90 0c 99    	vpgatherdd %ymm10,(%r9,%ymm3,4),%ymm9
 2bf:	4c 8b 48 18          	mov    0x18(%rax),%r9
 2c3:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
 2c8:	c5 35 db 0d 60 00 00 	vpand  0x60(%rip),%ymm9,%ymm9        # 330 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x330>
 2cf:	00 
 2d0:	c4 c2 2d 90 1c a1    	vpgatherdd %ymm10,(%r9,%ymm4,4),%ymm3
 2d6:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
 2db:	4c 8b 48 40          	mov    0x40(%rax),%r9
 2df:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 347 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x347>
 2e6:	00 
 2e7:	c4 42 65 3d d9       	vpmaxsd %ymm9,%ymm3,%ymm11
 2ec:	c5 b5 66 c3          	vpcmpgtd %ymm3,%ymm9,%ymm0
 2f0:	c4 c2 65 39 e9       	vpminsd %ymm9,%ymm3,%ymm5
 2f5:	c4 c1 45 66 e3       	vpcmpgtd %ymm11,%ymm7,%ymm4
 2fa:	c4 62 55 39 ef       	vpminsd %ymm7,%ymm5,%ymm13
 2ff:	c4 62 25 3d df       	vpmaxsd %ymm7,%ymm11,%ymm11
 304:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
 308:	c4 c3 75 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm1,%ymm0
 30e:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 337 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x337>
 315:	00 00 40 
 318:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
 31c:	c4 e2 2d 90 24 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm4
 322:	c4 c1 65 66 c1       	vpcmpgtd %ymm9,%ymm3,%ymm0
 327:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
 32c:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
 331:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
 335:	c4 c3 75 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm1,%ymm0
 33b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm0,%ymm0        # 364 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x364>
 342:	00 00 50 
 345:	c5 fe 6f 2c 24       	vmovdqu (%rsp),%ymm5
 34a:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
 34e:	c4 c1 55 72 d7 08    	vpsrld $0x8,%ymm15,%ymm5
 354:	c4 62 1d 90 14 82    	vpgatherdd %ymm12,(%rdx,%ymm0,4),%ymm10
 35a:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
 360:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
 367:	00 00 
 369:	c4 41 25 fe fd       	vpaddd %ymm13,%ymm11,%ymm15
 36e:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
 374:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
 379:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
 37d:	c5 9d 72 d0 08       	vpsrld $0x8,%ymm0,%ymm12
 382:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
 386:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
 38a:	c5 1d db e6          	vpand  %ymm6,%ymm12,%ymm12
 38e:	c5 ad fa fc          	vpsubd %ymm4,%ymm10,%ymm7
 392:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
 397:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
 39c:	c4 e2 65 40 ff       	vpmulld %ymm7,%ymm3,%ymm7
 3a1:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
 3a6:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
 3ab:	c4 c2 55 40 ed       	vpmulld %ymm13,%ymm5,%ymm5
 3b0:	c4 c1 7d 72 f4 10    	vpslld $0x10,%ymm12,%ymm0
 3b6:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
 3bd:	00 00 
 3bf:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
 3c3:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
 3c7:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
 3cb:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
 3d2:	00 00 
 3d4:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
 3d9:	c4 c2 05 90 1c a9    	vpgatherdd %ymm15,(%r9,%ymm5,4),%ymm3
 3df:	4c 8b 48 38          	mov    0x38(%rax),%r9
 3e3:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
 3e9:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
 3ee:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
 3f4:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 45c <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x45c>
 3fb:	00 
 3fc:	c4 82 05 90 2c a9    	vpgatherdd %ymm15,(%r9,%ymm13,4),%ymm5
 402:	4c 8b 48 30          	mov    0x30(%rax),%r9
 406:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
 40b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 473 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x473>
 412:	00 
 413:	c4 c2 05 90 24 b9    	vpgatherdd %ymm15,(%r9,%ymm7,4),%ymm4
 419:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
 41e:	44 8b 49 20          	mov    0x20(%rcx),%r9d
 422:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 48a <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x48a>
 429:	00 
 42a:	c4 62 5d 3d cd       	vpmaxsd %ymm5,%ymm4,%ymm9
 42f:	c5 d5 66 fc          	vpcmpgtd %ymm4,%ymm5,%ymm7
 433:	c4 41 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm10
 438:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
 43d:	c4 c3 75 4c f8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm7
 443:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm7,%ymm7        # 46c <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x46c>
 44a:	00 00 a0 
 44d:	c4 62 5d 39 d5       	vpminsd %ymm5,%ymm4,%ymm10
 452:	c5 ed fe ff          	vpaddd %ymm7,%ymm2,%ymm7
 456:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
 45b:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
 45f:	c4 e2 05 90 14 ba    	vpgatherdd %ymm15,(%rdx,%ymm7,4),%ymm2
 465:	c5 dd 66 fd          	vpcmpgtd %ymm5,%ymm4,%ymm7
 469:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
 46e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
 473:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
 477:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
 47c:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
 483:	00 00 
 485:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
 489:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
 48d:	c4 c3 75 4c c8 70    	vpblendvb %ymm7,%ymm8,%ymm1,%ymm1
 493:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
 498:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 4c1 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4c1>
 49f:	00 00 a0 
 4a2:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
 4a6:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
 4aa:	c4 62 45 90 04 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm8
 4b0:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
 4b6:	8b 51 24             	mov    0x24(%rcx),%edx
 4b9:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
 4bf:	c5 c5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm7
 4c4:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
 4cb:	00 00 
 4cd:	44 0f af ca          	imul   %edx,%r9d
 4d1:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
 4d5:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
 4d9:	c5 bd fa e2          	vpsubd %ymm2,%ymm8,%ymm4
 4dd:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
 4e2:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
 4e7:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
 4eb:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
 4f0:	c5 ad 72 f7 10       	vpslld $0x10,%ymm7,%ymm10
 4f5:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
 4f9:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
 4fe:	c5 2d fe 94 24 a0 00 	vpaddd 0xa0(%rsp),%ymm10,%ymm10
 505:	00 00 
 507:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
 50c:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
 511:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
 515:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
 51a:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
 51e:	c4 e2 7d 58 49 10    	vpbroadcastd 0x10(%rcx),%ymm1
 524:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
 529:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
 52e:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
 532:	c5 f9 6e ca          	vmovd  %edx,%xmm1
 536:	48 8b 11             	mov    (%rcx),%rdx
 539:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
 53e:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
 542:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
 547:	c4 e2 7d 58 49 18    	vpbroadcastd 0x18(%rcx),%ymm1
 54d:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
 551:	c4 e2 7d 58 49 08    	vpbroadcastd 0x8(%rcx),%ymm1
 557:	c5 d5 fa c9          	vpsubd %ymm1,%ymm5,%ymm1
 55b:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
 560:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
 564:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
 568:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
 56c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
 570:	c4 e2 6d 90 0c 82    	vpgatherdd %ymm2,(%rdx,%ymm0,4),%ymm1
 576:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
 57b:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
 580:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
 584:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
 588:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
 58d:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
 592:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
 596:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
 59a:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 5e3 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5e3>
 5a1:	00 00 
 5a3:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
 5a7:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
 5ad:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
 5b2:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
 5b7:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
 5bb:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
 5c1:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
 5c7:	4d 39 c3             	cmp    %r8,%r11
 5ca:	0f 85 d8 fa ff ff    	jne    a8 <jshc_channel::avx2_chain_domain(jshc_channel::View const*, jshc_channel::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa8>
 5d0:	c5 f8 77             	vzeroupper
 5d3:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
 5da:	00 00 
 5dc:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
 5e3:	00 00 
 5e5:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
 5ec:	00 00 
 5ee:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
 5f5:	00 00 
 5f7:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
 5fe:	00 00 
 600:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
 607:	00 00 
 609:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
 610:	00 00 
 612:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
 619:	00 00 
 61b:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
 622:	00 00 
 624:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
 62b:	00 00 
 62d:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
 634:	c3                   	ret
 635:	90                   	nop
 636:	90                   	nop
 637:	90                   	nop
 638:	90                   	nop
 639:	90                   	nop
 63a:	90                   	nop
 63b:	90                   	nop
 63c:	90                   	nop
 63d:	90                   	nop
 63e:	90                   	nop
 63f:	90                   	nop
