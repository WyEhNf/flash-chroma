"""冻结53：4×2×2颜色分块的RGB32直接表；首次像素前固定源码、边界与筛查。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
old=ROOT/'experiments/skylake-raw32-runtime';out=ROOT/'experiments/skylake-directtile-runtime';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_raw32','skylake_directtile').replace('avx2_chain_raw32','avx2_chain_directtile')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 44;','jshc_cc_revision(void) {return 53;').replace('uint32_t(!h.direct_index.empty()),12,0,','uint32_t(!h.direct_index.empty()),16,0,')
        s=s.replace('// 物理次序R低/G中/B高；每个输入直接保存精确RGB32，不经ID查palette。','// 一条64字节行保存4×2×2种输入颜色；RGB32直接输出，不经ID查palette。')
        old_index='const size_t i=((size_t(address)&255u)<<16)|(size_t(address)&0xff00u)|(size_t(address)>>16);'
        new_index='''const size_t a=size_t(address);
        const size_t r=((a>>4)&63u)*4+(a&3u);
        const size_t g=((a>>10)&127u)*2+((a>>2)&1u);
        const size_t b=((a>>17)&127u)*2+((a>>3)&1u);
        const size_t i=(r<<16)|(g<<8)|b;'''
        assert old_index in s;s=s.replace(old_index,new_index)
    if p.name=='channel_avx2.cpp':
        vector=(ROOT/'experiments/skylake-tilemadd-runtime/channel_tilemadd.cpp').read_text(encoding='utf-8')
        a=vector.index('inline __attribute__((always_inline)) uint32_t index(');b=vector.index('inline __attribute__((always_inline)) void output(',a)
        part=vector[a:b]
        part=part.replace('((c&0xfcu)<<4)|((c&0xfc00u)<<2)|(c&0xfc0000u)|(c&3u)|((c>>6)&12u)|((c>>12)&48u)','((c&0xfcu)<<2)|((c&0xfe00u)<<1)|(c&0xfe0000u)|(c&3u)|((c>>6)&4u)|((c>>13)&8u)')
        part=part.replace('// R/G展开为无符号16位，再以64/4096系数组成索引高位；值均≤63。','// R/G展开为16位，清除各自低2/1位，再乘4/512，组合互不重叠的高位。')
        part=part.replace('_mm256_srli_epi16(rg,2),_mm256_set1_epi32(0x10000040)','_mm256_and_si256(rg,_mm256_set1_epi32(0x00fe00fc)),_mm256_set1_epi32(0x02000004)')
        part=part.replace('// 低2位的加权和最大63，PMADDUBSW的两个16位部分和分别≤15及≤48，不饱和。','// 低位加权和最大15，PMADDUBSW两个部分和分别≤7及≤8，不饱和。')
        part=part.replace('0x030303','0x010103').replace('0x00100401','0x00080401').replace('0xfc0000','0xfe0000')
        part=part.replace('// 先以AVX2计算8个地址，再用普通GPR字节加载，避免硬件gather及逐像素PEXT。','// AVX2计算8个字地址，普通GPR直接读取RGB32，避免二级palette依赖。')
        part=part.replace('[table,palette](uint32_t i) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[i]]);}','[table](uint32_t i) {return int32_t(table[i]);}')
        a=s.index('inline __attribute__((always_inline)) __m256i read(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+part+s[b:]
        s=s.replace('// 表按R低/G中/B高的输入字节序排列，输出RGB32的字节序保持原样。','// 表按4×2×2输入颜色分块，输出RGB32的字节序保持原样。').replace('const uint32_t value=table[code];','const uint32_t value=table[index(code)];')
    write(out/p.name,s)
plan=json.loads((ROOT/'experiments/skylake-raw32-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='53研究RGB32直接表与缓存行颜色分块，精度保持原固定四模型逐级RGB8输出',candidate='从44的直接RGB32表改为4×2×2颜色tile；通用AVX2整数MADD构建地址，GPR直接查表，保留40的NT64/NTA/65536块',base_commit='7f3a4790907ee64c25155c1683c24e743762c296',revisions={'reference':23,'candidate':53},cmake_project='experiments/skylake-directtile-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_directtile'])
plan.pop('raw32_policy')
plan['directtile_policy']={'format':16,'entries':2**24,'table_bytes':2**26,'tile_rgb':[4,2,2],'colors_per_cacheline':16,'output_word':'R低/G中/B高/最高字节0','address_bits_low_to_high':'R低2,G低1,B低1,R高6,G高7,B高7','model_accounting_delta_vs23':2**26+24,'input_span_bytes':24,'choice':'一次固定4×2×2，不扫描轴/尺寸；44直接RGB32消除依赖但miss较高，49分块降低miss却增加索引成本，组合需实测','arithmetic_proof':'R/G高部输入≤252/254，乘4/512，和≤131056；低部部分和≤7/8，总≤15；B高部与其他位段不交叉，无饱和或溢出','hypothesis':'直接表少一次依赖读取，4×2×2改善邻色行共享；64MiB容量及向量到GPR提取仍可能抵消收益','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
for field in ('pageindex_policy','nt64_policy','batchspan_policy'):
    if field in plan:plan[field]['scope_note']='该字段保留40历史来源；53物理布局/容量以directtile_policy为准，其余循环和提示保留'
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-raw32-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-directtile-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
verifier=(ROOT/'scripts/verify_skylake_raw32_linux.py').read_text(encoding='utf-8').replace('精确直接RGB32加载44','4×2×2分块RGB32直接加载53').replace("direct_state['format']!=12","direct_state['format']!=16")
verifier=verifier.replace('words[r+256*g+65536*b]','words[(r%4)+4*(g%2)+8*(b%2)+16*(r//4)+1024*(g//2)+131072*(b//2)]')
verify_path=ROOT/'scripts/verify_skylake_directtile_linux.py';write(verify_path,verifier)
static=(ROOT/'scripts/inspect_skylake_vectorinput.py').read_text(encoding='utf-8').replace('50输入向量化','53直接RGB32分块').replace('skylake_vectorinput','skylake_directtile')
static=static.replace("assert any(i.startswith('vpextr') for i in mn)","assert any(i.startswith('vpextr') for i in mn)\n    assert 'vpmaddwd' in mn and 'vpmaddubsw' in mn")
write(ROOT/'scripts/inspect_skylake_directtile.py',static)
pmu=(ROOT/'scripts/profile_skylake_palettegather_pmu.py').read_text(encoding='utf-8').replace('40/52','40/53').replace('palettegather52','directtile53').replace("ds['format']==9","ds['format']==16").replace("pages['bytes']==2**24","pages['bytes']==(2**26 if label=='directtile53' else 2**24)")
write(ROOT/'scripts/profile_skylake_directtile_pmu.py',pmu)
validation={'purpose':'53独立RGB坐标解码16M、24组完整域、尾部/别名/保护页/全对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [verify_path,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-directtile-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
def index(c):return ((c&0xfc)<<2)|((c&0xfe00)<<1)|(c&0xfe0000)|(c&3)|((c>>6)&4)|((c>>13)&8)
bits=[index(1<<i) for i in range(24)]
assert len(set(bits))==24 and all(x>0 and x&(x-1)==0 for x in bits) and sum(bits)==2**24-1
for c in [0,2**24-1,*[1<<i for i in range(24)]]:
    a=index(c);r=((a>>4)&63)*4+(a&3);g=((a>>10)&127)*2+((a>>2)&1);b=((a>>17)&127)*2+((a>>3)&1)
    assert c==r+256*g+65536*b
for p in [verify_path,ROOT/'scripts/inspect_skylake_directtile.py',ROOT/'scripts/profile_skylake_directtile_pmu.py']:compile(p.read_text(encoding='utf-8'),str(p),'exec')
print('53源码、独立验证与5%单次筛查已冻结；24个输入位一一映射，尚未构建/执行像素')
