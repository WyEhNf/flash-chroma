"""53完整域通过后绑定实际二进制，只执行事前约定的一次40/53计数。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def spec(p):return {'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()}
full=read('artifacts/skylake-directtile-linux-full-v1/results.json');assert full['pass']
assert full['direct_info']['format']==16 and full['independent_table_colors']==2**24
p=read('experiments/skylake-sourcehint-pmu-v1.json');p['cases']={}
for label,name,revision in [('reference40','batchspan',40),('directtile53','directtile',53)]:
    build=f'artifacts/skylake-{name}-linux-build-v1/build.json';full=f'artifacts/skylake-{name}-linux-full-v1/results.json'
    p['cases'][label]={'revision':revision,'plan':spec(f'experiments/skylake-{name}-v1.json'),'build':spec(build),'full':spec(full),'build_role':'candidate','library':read(build)['libraries']['candidate']}
p['models_plan']=spec('experiments/skylake-directtile-v1.json');new='scripts/profile_skylake_directtile_pmu.py';p['script']=spec(new)
p['python_sources']=[new if x=='scripts/profile_skylake_sourcehint_pmu.py' else x for x in p['python_sources']]
p['orders']=[{'threads':1,'variants':['reference40','directtile53']},{'threads':4,'variants':['directtile53','reference40']}]
p['purpose']='40对53直接RGB32颜色分块的单次用户态计数；增量筛查1线程≤0.95、4线程≤1.05，整体墙钟3倍门槛不变'
p['screen']=read('experiments/skylake-directtile-v1.json')['directtile_policy']['pmu_screen']
dest=ROOT/'experiments/skylake-directtile-pmu-v1.json';assert not dest.exists();dest.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('53全域已核验，单次计数绑定冻结，尚未计数')
