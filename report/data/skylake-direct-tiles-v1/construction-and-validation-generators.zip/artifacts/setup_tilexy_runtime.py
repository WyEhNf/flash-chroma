"""冻结54：16MiB表中交换R/G各3位，用六个向量操作实现8×8×1行布局。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-tilexy-runtime';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_tilexy').replace('avx2_chain_batchspan','avx2_chain_tilexy')
    if p.name=='channel_runtime.cpp':
        s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 54;').replace('uint32_t(!h.direct_index.empty()),9,0,','uint32_t(!h.direct_index.empty()),17,0,')
        old_index='const size_t i=((address&255u)<<16)|(address&0xff00u)|(address>>16);'
        new_index='''// 交换R中3位与G低3位的置换自逆；仍仅从原模型生成的RGB构造。
          const uint32_t swap=((address>>5)^address)&0x38u;
          const uint32_t code=address^swap^(swap<<5);
          const size_t i=((code&255u)<<16)|(code&0xff00u)|(code>>16);'''
        assert old_index in s;s=s.replace(old_index,new_index)
        s=s.replace('// 四个输入ID按小端打包；对齐词gather加移位，不再需要末端额外词。','// 每条64字节行保存8×8×1颜色ID；四个字节按小端打包，供GPR读取。')
    if p.name=='channel_avx2.cpp':
        vector=(ROOT/'experiments/skylake-tilemadd-runtime/channel_tilemadd.cpp').read_text(encoding='utf-8')
        a=vector.index('inline __attribute__((always_inline)) uint32_t index(');b=vector.index('inline __attribute__((always_inline)) void output(',a);part=vector[a:b]
        c=part.index('  return ((c&0xfcu)');d=part.index('\n}',c)
        part=part[:c]+'''  const uint32_t swap=((c>>5)^c)&0x38u;
  return c^swap^(swap<<5);'''+part[d:]
        c=part.index('inline __attribute__((always_inline)) __m256i indices(');d=part.index('// 先以AVX2计算8个地址',c)
        part=part[:c]+'''inline __attribute__((always_inline)) __m256i indices(__m256i c) {
  // 两组互不重叠位交换；六个向量逻辑/移位操作，2MiB页编号不变。
  const __m256i swap=_mm256_and_si256(_mm256_xor_si256(_mm256_srli_epi32(c,5),c),_mm256_set1_epi32(0x38));
  return _mm256_xor_si256(_mm256_xor_si256(c,swap),_mm256_slli_epi32(swap,5));
}
'''+part[d:]
        a=s.index('inline __attribute__((always_inline)) __m256i read(');b=s.index('inline __attribute__((always_inline)) void output(',a);s=s[:a]+part+s[b:]
        s=s.replace('// 表按R低/G中/B高的输入字节序排列，输出RGB32的字节序保持原样。','// 表按R/G交换位排列，行内8×8×1颜色；输出RGB32字节序不变。')
        s=s.replace('const uint32_t value=palette[reinterpret_cast<const uint8_t*>(table)[code]];','const uint32_t value=palette[reinterpret_cast<const uint8_t*>(table)[index(code)]];')
    write(out/p.name,s)
plan=json.loads((ROOT/'experiments/skylake-vectorinput-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='54研究16MiB ID表的低成本二维颜色分块；精度不变',candidate='从40更换物理排列与地址计算：R位3..5与G位8..10互换，8×8×1颜色共享缓存行，6个向量索引操作，原两级GPR读取/NT64/NTA/块长',base_commit='7f3a4790907ee64c25155c1683c24e743762c296',revisions={'reference':23,'candidate':54},cmake_project='experiments/skylake-tilexy-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_tilexy'])
plan.pop('vectorinput_policy')
plan['tilexy_policy']={'format':17,'table_bytes':2**24,'tile_rgb':[8,8,1],'colors_per_cacheline':64,'swap_input_bits':[[3,8],[4,9],[5,10]],'involution':True,'huge_page_number_unchanged':True,'input_span_bytes':24,'choice':'53扩大表后显著退化，回到16MiB；49九操作三维索引成本未过筛查，本版固定六操作自逆位交换，不扫描尺寸/轴','hypothesis':'牺牲B行内局部性，降低索引操作数并保留16MiB容量；需要一次实测，不推定缓存收益','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
plan['pageindex_policy']['scope_note']='该字段保留40来源；54物理布局以tilexy_policy为准'
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-vectorinput-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-tilexy-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
verifier=(ROOT/'scripts/verify_skylake_vectorinput_linux.py').read_text(encoding='utf-8').replace('50','54').replace("direct_state['format']!=9","direct_state['format']!=17")
start=verifier.index('                    for red in range(256):');end=verifier.index('                    del old_words,raw_table',start)
verifier=verifier[:start]+'''                    for r in range(256):
                        # 独立分通道权重公式，不调用生产代码的XOR交换。
                        ids=bytes(raw_table[(r&7)+8*(g&7)+(r&0xc0)+32*(r&0x38)+256*(g&0xf8)+65536*b] for g in range(256) for b in range(256))
                        if max(ids)>=compiled_states['chain']['palette_size']:raise AssertionError('索引越过调色板')
                        if b''.join(palette_rgb[i] for i in ids)!=cube[r*65536*3:(r+1)*65536*3]:raise AssertionError('独立8×8×1全域解码不符')
'''+verifier[end:]
verifier=verifier.replace('新RGB32直表没有实际启用','新8×8×1字节表没有实际启用')
verify_path=ROOT/'scripts/verify_skylake_tilexy_linux.py';write(verify_path,verifier)
static=(ROOT/'scripts/inspect_skylake_vectorinput.py').read_text(encoding='utf-8').replace('50输入向量化','54二维颜色分块').replace('skylake_vectorinput','skylake_tilexy')
write(ROOT/'scripts/inspect_skylake_tilexy.py',static)
pmu=(ROOT/'scripts/profile_skylake_palettegather_pmu.py').read_text(encoding='utf-8').replace('40/52','40/54').replace('palettegather52','tilexy54').replace("ds['format']==9","ds['format']==17")
write(ROOT/'scripts/profile_skylake_tilexy_pmu.py',pmu)
validation={'purpose':'54独立16M解码、24组完整域、尾部/别名/保护页/全对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [verify_path,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-tilexy-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
def index(c):t=((c>>5)^c)&0x38;return c^t^(t<<5)
bits=[index(1<<i) for i in range(24)];assert len(set(bits))==24 and sum(bits)==2**24-1
for c in [0,2**24-1,*[1<<i for i in range(24)]]:assert index(index(c))==c and index(c)>>21==c>>21
for axis in range(3):
 for v in range(256):
  rgb=[0,0,0];rgb[axis]=v;r,g,b=rgb
  assert index(r+256*g+65536*b)==(r&7)+8*(g&7)+(r&0xc0)+32*(r&0x38)+256*(g&0xf8)+65536*b
for p in [verify_path,ROOT/'scripts/inspect_skylake_tilexy.py',ROOT/'scripts/profile_skylake_tilexy_pmu.py']:compile(p.read_text(encoding='utf-8'),str(p),'exec')
print('54位交换、独立解码和单次5%筛查冻结，尚未构建或执行像素')
