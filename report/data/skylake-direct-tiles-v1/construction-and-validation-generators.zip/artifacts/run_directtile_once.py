"""53单次顺序执行：构建、静态、完整精度通过后才做一次PMU；失败立即停止。"""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
commands=[
 ['scripts/build_skylake_runtime.py','--plan','experiments/skylake-directtile-v1.json','--output','artifacts/skylake-directtile-linux-build-v1'],
 ['scripts/inspect_skylake_directtile.py','--plan','experiments/skylake-directtile-v1.json','--build','artifacts/skylake-directtile-linux-build-v1','--output','artifacts/skylake-directtile-linux-static-v1'],
 ['scripts/verify_skylake_directtile_linux.py','--plan','experiments/skylake-directtile-v1.json','--build','artifacts/skylake-directtile-linux-build-v1','--single-oracle-stream','artifacts/skylake-domain-isolated-full-v1/first-stage.rgb','--output','artifacts/skylake-directtile-linux-full-v1','--affinity-cpus','0,2,4,6'],
 ['artifacts/prepare_directtile_pmu.py'],
 ['scripts/profile_skylake_directtile_pmu.py','--policy','experiments/skylake-directtile-pmu-v1.json','--output','artifacts/skylake-directtile-pmu-v1']]
for command in commands:
    print('开始',command[0],flush=True)
    subprocess.run([sys.executable,*command],cwd=ROOT,check=True)
