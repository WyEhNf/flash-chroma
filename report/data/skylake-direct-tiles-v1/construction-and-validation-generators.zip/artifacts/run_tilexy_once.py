"""54单次顺序执行：构建、静态、完整精度通过后才做一次PMU；失败立即停止。"""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
commands=[
 ['scripts/build_skylake_runtime.py','--plan','experiments/skylake-tilexy-v1.json','--output','artifacts/skylake-tilexy-linux-build-v1'],
 ['scripts/inspect_skylake_tilexy.py','--plan','experiments/skylake-tilexy-v1.json','--build','artifacts/skylake-tilexy-linux-build-v1','--output','artifacts/skylake-tilexy-linux-static-v1'],
 ['scripts/verify_skylake_tilexy_linux.py','--plan','experiments/skylake-tilexy-v1.json','--build','artifacts/skylake-tilexy-linux-build-v1','--single-oracle-stream','artifacts/skylake-domain-isolated-full-v1/first-stage.rgb','--output','artifacts/skylake-tilexy-linux-full-v1','--affinity-cpus','0,2,4,6'],
 ['artifacts/prepare_tilexy_pmu.py'],
 ['scripts/profile_skylake_tilexy_pmu.py','--policy','experiments/skylake-tilexy-pmu-v1.json','--output','artifacts/skylake-tilexy-pmu-v1']]
for command in commands:
    print('开始',command[0],flush=True)
    subprocess.run([sys.executable,*command],cwd=ROOT,check=True)
