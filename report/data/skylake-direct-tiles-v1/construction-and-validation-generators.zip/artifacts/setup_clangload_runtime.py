"""冻结55：只用Clang22编译原40像素TU，GCC参考、调度与OpenMP保持同场字节。"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-clangload-runtime';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_bytes(s.encode('utf-8'))
for p in old.iterdir():
    s=p.read_text(encoding='utf-8')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 55;')
    if p.name=='CMakeLists.txt':
        s=s.replace('skylake_batchspan','skylake_clangload')
        marker='add_library(${SKYLAKE_CANDIDATE_TARGET} SHARED'
        addition='''# 仅像素TU使用Clang；原参考/回退、dispatcher和OpenMP仍由GCC编译。
set(CLANG_PIXEL_OBJECT "${CMAKE_BINARY_DIR}/CMakeFiles/${SKYLAKE_CANDIDATE_TARGET}.dir/channel_avx2.cpp.o")
add_custom_command(OUTPUT "${CLANG_PIXEL_OBJECT}"
  COMMAND "${CMAKE_COMMAND}" -E make_directory "${CMAKE_BINARY_DIR}/CMakeFiles/${SKYLAKE_CANDIDATE_TARGET}.dir"
  COMMAND /usr/bin/clang++-22 --gcc-install-dir=/usr/lib/gcc/x86_64-linux-gnu/15
    -std=c++17 -O3 -DNDEBUG -fPIC -fvisibility=hidden -Wall -Wextra
    -mavx2 -mtune=skylake -ffp-contract=off -DJSHC_CC_HAVE_AVX2=1
    "-I${JSHC_ROOT}/experiments/channel-runtime"
    -c "${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp" -o "${CLANG_PIXEL_OBJECT}"
  DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp" "${CMAKE_CURRENT_SOURCE_DIR}/suffix_cache.hpp"
    "${CMAKE_CURRENT_SOURCE_DIR}/channel_views.hpp"
  VERBATIM)
set_source_files_properties("${CLANG_PIXEL_OBJECT}" PROPERTIES GENERATED TRUE EXTERNAL_OBJECT TRUE)
'''
        assert s.count(marker)==1;s=s.replace(marker,addition+marker)
        a=s.index(marker);b=s.index('foreach(target',a);part=s[a:b];assert part.count('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"')==1
        s=s[:a]+part.replace('"${CMAKE_CURRENT_SOURCE_DIR}/channel_avx2.cpp"','"${CLANG_PIXEL_OBJECT}"')+s[b:]
    write(out/p.name,s)
assert (out/'channel_avx2.cpp').read_bytes()==(old/'channel_avx2.cpp').read_bytes()
builder=(ROOT/'scripts/build_skylake_runtime.py').read_text(encoding='utf-8')
needle="    out.mkdir(parents=True)"
extra='''    if platform.system()!='Linux':raise ValueError('55只验证Linux混合对象构建')
    cp=plan['clangload_policy']['compiler'];assert digest(cp['path'])==cp['sha256']
    clang_version=subprocess.check_output([cp['path'],'--version'],text=True,encoding='utf-8',stderr=subprocess.STDOUT)
    assert 'clang version 22.1.2' in clang_version
'''
assert builder.count(needle)==1;builder=builder.replace(needle,extra+needle)
needle="    (out/'build.json').write_text"
builder=builder.replace(needle,"    record['kernel_compiler']={**cp,'version':clang_version,'scope':'仅当前channel_avx2.cpp；其余仍为GCC'}\n"+needle)
build_path=ROOT/'scripts/build_skylake_clangload.py';write(build_path,builder)
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='55研究编译器对原40载荷/打包内核的指令调度，像素TU源码不变',candidate='仅当前AVX2 TU使用Clang22.1.2，其余GCC15.2；同场原23、回退与OpenMP不变，保留通用AVX2和Skylake调度',base_commit='7f3a4790907ee64c25155c1683c24e743762c296',revisions={'reference':23,'candidate':55},cmake_project='experiments/skylake-clangload-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_clangload'])
plan['clangload_policy']={'compiler':{'path':'/usr/bin/clang++-22','sha256':'97b50a720cf5b662ebd3f5e7f64f995dc5f13999132124faaef37d7ddd6afbba'},'gcc_headers':'/usr/lib/gcc/x86_64-linux-gnu/15','pixel_source_equals':'experiments/skylake-batchspan-runtime/channel_avx2.cpp','source_sha256':sha(old/'channel_avx2.cpp'),'choice':'先前Clang21研究对象是旧插值核心，本版首次研究40直接字节表/NT打包内核，不扫描编译旗标','hypothesis':'不同寄存器分配和指令选择可减少GPR/向量装配成本；静态数量不作为性能通过','source':'https://clang.llvm.org/docs/Toolchain.html','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in [*out.iterdir(),build_path]:plan['source_sha256'][p.relative_to(ROOT).as_posix()]=sha(p)
dest=ROOT/'experiments/skylake-clangload-v1.json';write(dest,json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
verify=(ROOT/'scripts/verify_skylake_vectorinput_linux.py').read_text(encoding='utf-8').replace('线性布局向量输入50','Clang像素TU修订55')
verify_path=ROOT/'scripts/verify_skylake_clangload_linux.py';write(verify_path,verify)
static=(ROOT/'scripts/inspect_skylake_vectorinput.py').read_text(encoding='utf-8').replace('50输入向量化','55同源Clang像素TU').replace('skylake_vectorinput','skylake_clangload')
static=static.replace("    assert any(i.startswith('vpextr') for i in mn)\n",'')
write(ROOT/'scripts/inspect_skylake_clangload.py',static)
pmu=(ROOT/'scripts/profile_skylake_palettegather_pmu.py').read_text(encoding='utf-8').replace('40/52','40/55').replace('palettegather52','clangload55')
write(ROOT/'scripts/profile_skylake_clangload_pmu.py',pmu)
validation={'purpose':'55同源混合编译的24组全域、独立表、有限/别名/边界及对齐；不计时','plan_sha256':sha(dest),'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [verify_path,ROOT/'scripts/paged_table_support.py',ROOT/'scripts/outplace_support.py',ROOT/'scripts/guarded_buffer_support.py']}}
write(ROOT/'experiments/skylake-clangload-validation-v1.json',json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
prepare=(ROOT/'artifacts/prepare_palettegather_pmu.py').read_text(encoding='utf-8').replace('52','55').replace('palettegather','clangload').replace('仅改变输入加载','仅改变像素TU编译器')
write(ROOT/'artifacts/prepare_clangload_pmu.py',prepare)
runner=(ROOT/'artifacts/run_directtile_once.py').read_text(encoding='utf-8').replace('53','55').replace('directtile','clangload').replace('build_skylake_runtime.py','build_skylake_clangload.py')
write(ROOT/'artifacts/run_clangload_once.py',runner)
for p in [build_path,verify_path,ROOT/'scripts/inspect_skylake_clangload.py',ROOT/'scripts/profile_skylake_clangload_pmu.py',ROOT/'artifacts/prepare_clangload_pmu.py',ROOT/'artifacts/run_clangload_once.py']:compile(p.read_text(encoding='utf-8'),str(p),'exec')
print('55单TU编译器与固定选项已冻结，像素源与40逐字节相同；尚未构建或执行像素')
