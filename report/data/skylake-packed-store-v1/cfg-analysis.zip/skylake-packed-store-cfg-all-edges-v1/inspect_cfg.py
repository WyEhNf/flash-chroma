import sys,re,json,collections
from pathlib import Path
sys.path.insert(0,'scripts')
from inspect_skylake_avx2 import functions,loops
sys.setrecursionlimit(10000)
root=Path.cwd();out=Path(__file__).resolve().parent;source=root/'artifacts/skylake-packed-store-static-v1';records={}
for role in ('reference','candidate'):
 fs=functions((source/(role+'.asm')).read_text());found={};attempts=0
 for f in fs:
  if '::avx2_chain_cached(' not in f['function']:continue
  ins=f['instructions'];by={x[0]:x for x in ins};callees={g['instructions'][0][0]:g for g in fs if g['instructions']};nexts={a[0]:b[0] for a,b in zip(ins,ins[1:])}
  starts={int(m[1],16) for address,op,operands in ins if op.startswith('j') for m in [re.match(r'([0-9a-f]+)\s+<',operands)] if m and int(m[1],16)<address}
  def walk(start,at,path,seen,gathers):
   global attempts
   attempts+=1
   if attempts>2000000:raise ValueError('静态路径枚举预算超限，不自动扩大')
   if at==start and path:
    if gathers==15:
     key=tuple(sorted(seen));found.setdefault(key,path)
    return
   if at not in by or at in seen or len(path)>700 or gathers>15:return
   address,op,operands=by[at]
   if op.startswith('ret'):return
   extra=0
   if op.startswith('call'):
    cm=re.match(r'([0-9a-f]+)',operands);cf=callees.get(int(cm[1],16)) if cm else None
    if not cf or any(q.startswith(('j','call')) for _,q,_ in cf['instructions']):return
    extra=sum(q.startswith('vpgather') for _,q,_ in cf['instructions'])
   ng=gathers+op.startswith('vpgather')+extra;branches=[]
   if op.startswith('j'):
    m=re.match(r'([0-9a-f]+)\s+<',operands)
    if m:branches.append(int(m[1],16))
    if op!='jmp' and at in nexts:branches.append(nexts[at])
   elif at in nexts:branches=[nexts[at]]
   for target in branches:walk(start,target,path+[by[at]],seen|{at},ng)
  for start in sorted(starts):walk(start,start,[],set(),0)
 cases=[]
 for i,seq in enumerate(found.values()):
  ops=collections.Counter(x[1] for x in seq);body=['.text','.Lloop:'];expanded=[]
  for _,op,operands in seq:
   if op.startswith('call'):
    cf=callees[int(re.match(r'([0-9a-f]+)',operands)[1],16)];expanded.append({'function':cf['function'],'instructions':len(cf['instructions']),'gathers':sum(q.startswith('vpgather') for _,q,_ in cf['instructions'])})
  for address,op,operands in seq:
   # 轨迹已明确控制流，省略转移但保留等量无条件跳转仅作分离成本说明；不喂给MCA。
   body.append(hex(address)+': '+op+' '+operands)
  (out/(role+'-'+str(i)+'-path.txt')).write_text('\n'.join(body)+'\n',encoding='utf-8')
  cases.append({'first_address':hex(seq[0][0]),'last_address':hex(seq[-1][0]),'instructions':len(seq),'expanded_calls':expanded,'instruction_budget_with_calls':len(seq)+sum(c['instructions'] for c in expanded),'gathers':sum(v for k,v in ops.items() if k.startswith('vpgather')),'rsp_operands':sum('%rsp' in x[2] for x in seq),'branches':sum(x[1].startswith('j') for x in seq),'unconditional_jumps':ops['jmp'],'address_set':[hex(x) for x in sorted(a[0] for a in seq)]})
 records[role]={'unique_simple_cycles_with_15_effective_gathers':cases,'enumeration_steps':attempts}
 print(role,[(x['instructions'],x['gathers'],x['rsp_operands'],x['branches'],x['unconditional_jumps'],x['expanded_calls'],x['instruction_budget_with_calls']) for x in cases], 'steps',attempts)
(out/'results.json').write_text(json.dumps({'purpose':'通用检查拒绝后，枚举CFG的15有效gather简单环；只展开无分支无嵌套调用的内部transform；无源码重编译、无像素或性能调用','variants':records,'limits':{'max_steps':2000000,'max_path_instructions':700},'scope':'只按控制流图枚举，不证明数据谓词可达或动态耗时；路径不连续不能直接使用旧线性区间MCA','native_calls':0,'performance_calls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
