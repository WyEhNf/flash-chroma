import hashlib,json,os,subprocess,sys,time
from pathlib import Path
import psutil
ROOT=Path.cwd();here=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
known=('python','jshc','cmake','g++','gcc','cc1','ld.exe','as.exe','make')
def active():
 rows={}
 for p in psutil.process_iter(['pid','name','cpu_times']):
  try:
   v=p.info
   if v['pid']==os.getpid() or not any(t in (v['name'] or '').lower() for t in known):continue
   rows[v['pid']]={'name':v['name'],'cpu':v['cpu_times'].user+v['cpu_times'].system}
  except (psutil.NoSuchProcess,psutil.AccessDenied):pass
 return rows
a=active();start=time.perf_counter();time.sleep(1);b=active();elapsed=time.perf_counter()-start
observed=[{'pid':pid,'name':v['name'],'cpu_seconds_delta':max(0,v['cpu']-a[pid]['cpu'])} for pid,v in b.items() if pid in a]
save(here/'performance-preflight.json',{'purpose':'计时前已知数值/编译进程的短时CPU活动记录，不读取命令行或修改系统设置',
 'observed_seconds':elapsed,'known_processes':observed,'numeric_or_compile_cpu_active':any(x['cpu_seconds_delta']>.1 for x in observed),
 'scope':'只核对已知进程名，不保证整机专用或无系统噪声；本轮构建与集中验证及此前WSL矩阵句柄均已确认完成；不保证宿主专用'})
if any(x['cpu_seconds_delta']>.1 for x in observed):raise RuntimeError('存在已知数值/编译活动，尚未开始正式计时')
plan='experiments/skylake-packed-store-v1.json';build='artifacts/skylake-packed-store-build-v1';full='artifacts/skylake-packed-store-full-v1/results.json'
previous=json.loads(Path('experiments/skylake-delta-cache-perf-v1.json').read_text(encoding='utf-8'))
policy={**previous,'purpose':'同一坐标差与缓存基线对直接packed写回的唯一平衡比较；模型及容量不变',
 'plan':{'path':plan,'sha256':sha(plan)},'build_path':build,'build':{'path':build+'/build.json','sha256':sha(build+'/build.json')},
 'full_acceptance':{'path':full,'sha256':sha(full)},
 'adoption_gate':{'median_apply_ratio_max':.97,'any_process_apply_ratio_max':1.02,'median_copy_apply_ratio_max':1.0,'median_prepare_plus_100_ratio_max':1.0}}
policy_path=Path('experiments/skylake-packed-store-perf-v1.json')
if policy_path.exists():raise ValueError('不覆盖已冻结性能策略')
save(policy_path,policy)
command=[sys.executable,'-X','utf8','scripts/bench_skylake_runtime.py','--policy',str(policy_path),'--output','artifacts/skylake-packed-store-perf-v1']
r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
(here/'performance.stdout.log').write_text(r.stdout,encoding='utf-8');(here/'performance.stderr.log').write_text(r.stderr,encoding='utf-8')
save(here/'performance-command.json',{'command':command,'returncode':r.returncode})
print(r.stdout[-5000:],flush=True)
if r.returncode:raise RuntimeError(r.stderr)
