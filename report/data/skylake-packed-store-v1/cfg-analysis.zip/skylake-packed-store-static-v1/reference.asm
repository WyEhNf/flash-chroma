
artifacts\skylake-packed-store-build-v1\CMakeFiles\jshc_skylake_reference.dir\F_\Hackathon\projects\16-lut-color\experiments\skylake-delta-cache-runtime\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
       7:	c5 f8 29 34 24       	vmovaps %xmm6,(%rsp)
       c:	c5 f8 29 7c 24 10    	vmovaps %xmm7,0x10(%rsp)
      12:	c5 78 29 44 24 20    	vmovaps %xmm8,0x20(%rsp)
      18:	c5 78 29 4c 24 30    	vmovaps %xmm9,0x30(%rsp)
      1e:	c5 78 29 54 24 40    	vmovaps %xmm10,0x40(%rsp)
      24:	c5 78 29 5c 24 50    	vmovaps %xmm11,0x50(%rsp)
      2a:	c5 78 29 64 24 60    	vmovaps %xmm12,0x60(%rsp)
      30:	c5 78 29 6c 24 70    	vmovaps %xmm13,0x70(%rsp)
      36:	c5 78 29 b4 24 80 00 	vmovaps %xmm14,0x80(%rsp)
      3d:	00 00 
      3f:	c5 78 29 bc 24 90 00 	vmovaps %xmm15,0x90(%rsp)
      46:	00 00 
      48:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      4c:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
      50:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
      54:	48 8b 01             	mov    (%rcx),%rax
      57:	c5 fd 6f 2a          	vmovdqa (%rdx),%ymm5
      5b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      5f:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      63:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
      69:	48 8b 41 08          	mov    0x8(%rcx),%rax
      6d:	c5 fd 6f 52 20       	vmovdqa 0x20(%rdx),%ymm2
      72:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      76:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
      7b:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
      80:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
      85:	c4 e2 75 90 3c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm7
      8b:	48 8b 41 10          	mov    0x10(%rcx),%rax
      8f:	c5 fd 6f 4a 40       	vmovdqa 0x40(%rdx),%ymm1
      94:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
      99:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
      9e:	c4 62 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm8
      a4:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
      a9:	48 8b 41 48          	mov    0x48(%rcx),%rax
      ad:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
      b2:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
      b7:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
      bc:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
      c0:	c4 c1 6d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm2
      c6:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      ca:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      cf:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
      d3:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
      d8:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
      dc:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
      e0:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
      e4:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
      ea:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
      ee:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      f2:	c5 3d db c1          	vpand  %ymm1,%ymm8,%ymm8
      f6:	c4 62 5d 3d d7       	vpmaxsd %ymm7,%ymm4,%ymm10
      fb:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
     101:	c5 c5 66 ec          	vpcmpgtd %ymm4,%ymm7,%ymm5
     105:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
     10a:	c4 62 5d 39 ef       	vpminsd %ymm7,%ymm4,%ymm13
     10f:	c5 5d fe ff          	vpaddd %ymm7,%ymm4,%ymm15
     113:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     117:	c4 42 15 39 e0       	vpminsd %ymm8,%ymm13,%ymm12
     11c:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
     121:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
     126:	c4 c3 25 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm11,%ymm5
     12c:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm5,%ymm5        # 135 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x135>
     133:	ff ff 90 
     136:	c4 43 25 4c de 40    	vpblendvb %ymm4,%ymm14,%ymm11,%ymm11
     13c:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
     141:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm11,%ymm11        # 14a <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x14a>
     148:	ff ff d0 
     14b:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     150:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
     154:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     159:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
     15e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     162:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     166:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
     16c:	c4 e2 5d 90 1c b0    	vpgatherdd %ymm4,(%rax,%ymm6,4),%ymm3
     172:	b8 00 80 00 00       	mov    $0x8000,%eax
     177:	c5 cd 72 d0 18       	vpsrld $0x18,%ymm0,%ymm6
     17c:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     181:	c5 55 db de          	vpand  %ymm6,%ymm5,%ymm11
     185:	c5 ed db e6          	vpand  %ymm6,%ymm2,%ymm4
     189:	c5 e5 db c6          	vpand  %ymm6,%ymm3,%ymm0
     18d:	c5 f5 db fe          	vpand  %ymm6,%ymm1,%ymm7
     191:	c5 bd 72 f4 10       	vpslld $0x10,%ymm4,%ymm8
     196:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
     19a:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     19e:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     1a3:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     1a8:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     1ad:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     1b2:	c5 15 db ee          	vpand  %ymm6,%ymm13,%ymm13
     1b6:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     1bb:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     1c0:	c5 25 db de          	vpand  %ymm6,%ymm11,%ymm11
     1c4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     1c9:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
     1cd:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
     1d1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     1d5:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     1d9:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     1de:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1e2:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     1e7:	c4 c1 3d 72 f3 10    	vpslld $0x10,%ymm11,%ymm8
     1ed:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     1f2:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     1f6:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     1fb:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     204:	c4 42 25 40 da       	vpmulld %ymm10,%ymm11,%ymm11
     209:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     20d:	c5 fd 7f 02          	vmovdqa %ymm0,(%rdx)
     211:	c5 fd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm0
     216:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     21b:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     21f:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     223:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     227:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
     22c:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     231:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     236:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     23b:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     240:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
     244:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     249:	c5 f5 72 f2 10       	vpslld $0x10,%ymm2,%ymm1
     24e:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     252:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     256:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     25a:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     25e:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     263:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     268:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
     26d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     271:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     276:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     27b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     27f:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     283:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     287:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     28c:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     291:	c5 f8 77             	vzeroupper
     294:	c5 f8 28 34 24       	vmovaps (%rsp),%xmm6
     299:	c5 f8 28 7c 24 10    	vmovaps 0x10(%rsp),%xmm7
     29f:	c5 78 28 44 24 20    	vmovaps 0x20(%rsp),%xmm8
     2a5:	c5 78 28 4c 24 30    	vmovaps 0x30(%rsp),%xmm9
     2ab:	c5 78 28 54 24 40    	vmovaps 0x40(%rsp),%xmm10
     2b1:	c5 78 28 5c 24 50    	vmovaps 0x50(%rsp),%xmm11
     2b7:	c5 78 28 64 24 60    	vmovaps 0x60(%rsp),%xmm12
     2bd:	c5 78 28 6c 24 70    	vmovaps 0x70(%rsp),%xmm13
     2c3:	c5 78 28 b4 24 80 00 	vmovaps 0x80(%rsp),%xmm14
     2ca:	00 00 
     2cc:	c5 78 28 bc 24 90 00 	vmovaps 0x90(%rsp),%xmm15
     2d3:	00 00 
     2d5:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
     2dc:	c3                   	ret
     2dd:	0f 1f 00             	nopl   (%rax)

00000000000002e0 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>:
     2e0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
     2e7:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
     2ee:	00 00 
     2f0:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
     2f7:	00 00 
     2f9:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
     300:	00 00 
     302:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
     309:	00 00 
     30b:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
     312:	00 00 
     314:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
     31b:	00 00 
     31d:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
     324:	00 00 
     326:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
     32d:	00 00 
     32f:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
     336:	00 00 
     338:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
     33f:	00 00 
     341:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     345:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     349:	48 8b 01             	mov    (%rcx),%rax
     34c:	c5 fd 6f 3a          	vmovdqa (%rdx),%ymm7
     350:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     354:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     358:	c4 e2 65 90 24 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm4
     35e:	48 8b 41 08          	mov    0x8(%rcx),%rax
     362:	c5 fd 6f 7a 20       	vmovdqa 0x20(%rdx),%ymm7
     367:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     36b:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
     370:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     375:	c5 7d 6f 32          	vmovdqa (%rdx),%ymm14
     379:	c5 7d 6f 52 20       	vmovdqa 0x20(%rdx),%ymm10
     37e:	c4 e2 65 90 2c b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm5
     384:	c5 fd 6f 7a 40       	vmovdqa 0x40(%rdx),%ymm7
     389:	48 8b 41 10          	mov    0x10(%rcx),%rax
     38d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     391:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     396:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     39b:	c4 e2 65 90 34 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm6
     3a1:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     3a6:	c4 c1 79 6e d8       	vmovd  %r8d,%xmm3
     3ab:	48 8b 41 48          	mov    0x48(%rcx),%rax
     3af:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     3b4:	c5 b5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm9
     3b9:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     3be:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     3c3:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     3c7:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     3cb:	c4 41 75 fe d9       	vpaddd %ymm9,%ymm1,%ymm11
     3d0:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
     3d5:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     3d9:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     3dd:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     3e1:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     3e6:	c4 22 6d 90 24 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm12
     3ec:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     3f0:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     3f5:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     3fa:	c4 41 75 fe eb       	vpaddd %ymm11,%ymm1,%ymm13
     3ff:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     403:	c4 a2 75 90 14 a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm2
     409:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     40d:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
     413:	c4 02 75 90 3c b0    	vpgatherdd %ymm1,(%r8,%ymm14,4),%ymm15
     419:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     41d:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     421:	48 8b 49 28          	mov    0x28(%rcx),%rcx
     425:	c4 02 75 90 34 90    	vpgatherdd %ymm1,(%r8,%ymm10,4),%ymm14
     42b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     42f:	c4 62 5d 3d d5       	vpmaxsd %ymm5,%ymm4,%ymm10
     434:	c4 e2 75 90 14 b9    	vpgatherdd %ymm1,(%rcx,%ymm7,4),%ymm2
     43a:	c5 d5 66 cc          	vpcmpgtd %ymm4,%ymm5,%ymm1
     43e:	b9 00 80 00 00       	mov    $0x8000,%ecx
     443:	c4 c1 4d 66 fa       	vpcmpgtd %ymm10,%ymm6,%ymm7
     448:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     44e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm1,%ymm1        # 457 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x177>
     455:	ff ff 70 
     458:	c4 e2 2d 3d fe       	vpmaxsd %ymm6,%ymm10,%ymm7
     45d:	c4 62 35 39 d6       	vpminsd %ymm6,%ymm9,%ymm10
     462:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     469:	00 00 
     46b:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     470:	c5 35 66 ce          	vpcmpgtd %ymm6,%ymm9,%ymm9
     474:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
     47b:	00 00 
     47d:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     481:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     487:	c4 e2 2d 90 3c 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm7
     48d:	c5 dd 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm1
     491:	c5 7e 7f 2c 24       	vmovdqu %ymm13,(%rsp)
     496:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     49c:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 4a5 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x1c5>
     4a3:	ff ff 90 
     4a6:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
     4aa:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
     4ae:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
     4b5:	00 00 
     4b7:	c4 62 35 90 1c 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm11
     4bd:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     4c3:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     4c8:	c5 15 fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm13,%ymm12
     4cf:	00 00 
     4d1:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     4d5:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     4d9:	c5 5d fe ed          	vpaddd %ymm5,%ymm4,%ymm13
     4dd:	c5 75 db 54 24 40    	vpand  0x40(%rsp),%ymm1,%ymm10
     4e3:	c4 41 4d fa e4       	vpsubd %ymm12,%ymm6,%ymm12
     4e8:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
     4ed:	c5 25 fa e7          	vpsubd %ymm7,%ymm11,%ymm12
     4f1:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
     4f7:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
     4fc:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     500:	c4 c1 45 fa fa       	vpsubd %ymm10,%ymm7,%ymm7
     505:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     50a:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     511:	00 00 00 
     514:	c4 c1 2d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm10
     51a:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
     51f:	c5 2d fe d5          	vpaddd %ymm5,%ymm10,%ymm10
     523:	c5 7e 7f ac 24 80 00 	vmovdqu %ymm13,0x80(%rsp)
     52a:	00 00 
     52c:	c4 41 1d fe c9       	vpaddd %ymm9,%ymm12,%ymm9
     531:	c5 75 db 64 24 60    	vpand  0x60(%rsp),%ymm1,%ymm12
     537:	c4 41 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm12
     53c:	c4 62 1d 40 a4 24 c0 	vpmulld 0xc0(%rsp),%ymm12,%ymm12
     543:	00 00 00 
     546:	c5 1d fe e7          	vpaddd %ymm7,%ymm12,%ymm12
     54a:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     54f:	c4 c1 45 72 d1 10    	vpsrld $0x10,%ymm9,%ymm7
     555:	c4 c1 35 72 e7 10    	vpsrad $0x10,%ymm15,%ymm9
     55b:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     562:	00 00 
     564:	c5 c5 72 e2 10       	vpsrad $0x10,%ymm2,%ymm7
     569:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     56e:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
     572:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     577:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
     57b:	c4 41 2d fe e1       	vpaddd %ymm9,%ymm10,%ymm12
     580:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     584:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
     58a:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
     591:	00 00 
     593:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     598:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
     59c:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
     5a2:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     5a6:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     5ab:	c5 6d fe f5          	vpaddd %ymm5,%ymm2,%ymm14
     5af:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
     5b3:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
     5ba:	00 00 
     5bc:	c4 62 5d 3d dd       	vpmaxsd %ymm5,%ymm4,%ymm11
     5c1:	c5 55 66 ec          	vpcmpgtd %ymm4,%ymm5,%ymm13
     5c5:	c4 62 5d 39 f5       	vpminsd %ymm5,%ymm4,%ymm14
     5ca:	c4 c1 6d 66 f3       	vpcmpgtd %ymm11,%ymm2,%ymm6
     5cf:	c5 dd 66 ed          	vpcmpgtd %ymm5,%ymm4,%ymm5
     5d3:	c4 62 0d 39 e2       	vpminsd %ymm2,%ymm14,%ymm12
     5d8:	c5 0d 66 f2          	vpcmpgtd %ymm2,%ymm14,%ymm14
     5dc:	c4 62 25 3d da       	vpmaxsd %ymm2,%ymm11,%ymm11
     5e1:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     5e5:	c4 43 65 4c e8 d0    	vpblendvb %ymm13,%ymm8,%ymm3,%ymm13
     5eb:	c4 63 15 4c 2d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm13,%ymm13        # 5f4 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x314>
     5f2:	ff ff 60 
     5f5:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     5fb:	c5 15 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm13,%ymm13
     601:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm5,%ymm5        # 60a <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x32a>
     608:	ff ff e0 
     60b:	c4 a2 05 90 34 a8    	vpgatherdd %ymm15,(%rax,%ymm13,4),%ymm6
     611:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     616:	c4 41 25 fe fc       	vpaddd %ymm12,%ymm11,%ymm15
     61b:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     620:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     625:	c5 95 fa ed          	vpsubd %ymm5,%ymm13,%ymm5
     629:	c5 dd fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm4,%ymm4
     630:	00 00 
     632:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     636:	c4 62 6d 90 2c a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm13
     63c:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     642:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     648:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
     64e:	c5 8d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm14
     653:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
     658:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     65c:	c5 0d db f1          	vpand  %ymm1,%ymm14,%ymm14
     660:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     664:	c5 15 fa fe          	vpsubd %ymm6,%ymm13,%ymm15
     668:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     66d:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     672:	c4 42 5d 40 ff       	vpmulld %ymm15,%ymm4,%ymm15
     677:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
     67c:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
     681:	c4 42 35 39 da       	vpminsd %ymm10,%ymm9,%ymm11
     686:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
     68c:	c4 62 25 39 e7       	vpminsd %ymm7,%ymm11,%ymm12
     691:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     695:	c5 ed fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm2,%ymm2
     69c:	00 00 
     69e:	c5 25 66 df          	vpcmpgtd %ymm7,%ymm11,%ymm11
     6a2:	c5 85 fe d2          	vpaddd %ymm2,%ymm15,%ymm2
     6a6:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     6aa:	c4 c2 35 3d f2       	vpmaxsd %ymm10,%ymm9,%ymm6
     6af:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     6b3:	c4 c1 2d 66 e9       	vpcmpgtd %ymm9,%ymm10,%ymm5
     6b8:	c5 c5 66 e6          	vpcmpgtd %ymm6,%ymm7,%ymm4
     6bc:	c4 41 35 66 ca       	vpcmpgtd %ymm10,%ymm9,%ymm9
     6c1:	c4 e2 4d 3d f7       	vpmaxsd %ymm7,%ymm6,%ymm6
     6c6:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6cb:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     6d1:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm5,%ymm5        # 6da <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x3fa>
     6d8:	ff ff 40 
     6db:	c4 c3 65 4c d8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm3
     6e1:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     6e7:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     6ec:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm3,%ymm3        # 6f5 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)+0x415>
     6f3:	ff ff b0 
     6f6:	c5 95 fa db          	vpsubd %ymm3,%ymm13,%ymm3
     6fa:	c4 e2 0d 90 24 a8    	vpgatherdd %ymm14,(%rax,%ymm5,4),%ymm4
     700:	c4 e2 7d 90 2c 98    	vpgatherdd %ymm0,(%rax,%ymm3,4),%ymm5
     706:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     70c:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     712:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     717:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     71c:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     720:	c5 fd 7f 52 20       	vmovdqa %ymm2,0x20(%rdx)
     725:	c5 bd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm8
     72a:	c4 c1 4d fe c4       	vpaddd %ymm12,%ymm6,%ymm0
     72f:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     733:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
     737:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     73c:	c5 d5 fa fc          	vpsubd %ymm4,%ymm5,%ymm7
     740:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
     744:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
     74b:	00 00 
     74d:	c5 bd db c9          	vpand  %ymm1,%ymm8,%ymm1
     751:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     755:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     759:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
     75e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     763:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
     768:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
     76d:	c5 b5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm9,%ymm7
     774:	00 00 
     776:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
     77a:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     77e:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     785:	00 00 
     787:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     78b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     790:	c5 fd 7f 3a          	vmovdqa %ymm7,(%rdx)
     794:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     799:	c5 f8 77             	vzeroupper
     79c:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
     7a3:	00 00 
     7a5:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
     7ac:	00 00 
     7ae:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
     7b5:	00 00 
     7b7:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
     7be:	00 00 
     7c0:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
     7c7:	00 00 
     7c9:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
     7d0:	00 00 
     7d2:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
     7d9:	00 00 
     7db:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
     7e2:	00 00 
     7e4:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
     7eb:	00 00 
     7ed:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
     7f4:	00 00 
     7f6:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
     7fd:	c3                   	ret
     7fe:	66 90                	xchg   %ax,%ax

0000000000000800 <void jshc_delta16_cache::(anonymous namespace)::transform<false, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>:
     800:	48 81 ec 88 01 00 00 	sub    $0x188,%rsp
     807:	c5 f8 29 b4 24 e0 00 	vmovaps %xmm6,0xe0(%rsp)
     80e:	00 00 
     810:	c5 f8 29 bc 24 f0 00 	vmovaps %xmm7,0xf0(%rsp)
     817:	00 00 
     819:	c5 78 29 84 24 00 01 	vmovaps %xmm8,0x100(%rsp)
     820:	00 00 
     822:	c5 78 29 8c 24 10 01 	vmovaps %xmm9,0x110(%rsp)
     829:	00 00 
     82b:	c5 78 29 94 24 20 01 	vmovaps %xmm10,0x120(%rsp)
     832:	00 00 
     834:	c5 78 29 9c 24 30 01 	vmovaps %xmm11,0x130(%rsp)
     83b:	00 00 
     83d:	c5 78 29 a4 24 40 01 	vmovaps %xmm12,0x140(%rsp)
     844:	00 00 
     846:	c5 78 29 ac 24 50 01 	vmovaps %xmm13,0x150(%rsp)
     84d:	00 00 
     84f:	c5 78 29 b4 24 60 01 	vmovaps %xmm14,0x160(%rsp)
     856:	00 00 
     858:	c5 78 29 bc 24 70 01 	vmovaps %xmm15,0x170(%rsp)
     85f:	00 00 
     861:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     865:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     869:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     86d:	48 89 d0             	mov    %rdx,%rax
     870:	48 8b 11             	mov    (%rcx),%rdx
     873:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     877:	c5 fd 6f 10          	vmovdqa (%rax),%ymm2
     87b:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     87f:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
     884:	c4 e2 4d 90 1c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm3
     88a:	48 8b 51 08          	mov    0x8(%rcx),%rdx
     88e:	c5 fd 6f 50 20       	vmovdqa 0x20(%rax),%ymm2
     893:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     897:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     89c:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     8a1:	c4 e2 4d 90 3c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm7
     8a7:	48 8b 51 10          	mov    0x10(%rcx),%rdx
     8ab:	c5 fd 6f 50 40       	vmovdqa 0x40(%rax),%ymm2
     8b0:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     8b4:	c5 d5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm5
     8b9:	c4 e2 4d 90 24 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm4
     8bf:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     8c4:	c4 c1 79 6e d0       	vmovd  %r8d,%xmm2
     8c9:	48 8b 51 48          	mov    0x48(%rcx),%rdx
     8cd:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     8d2:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
     8d7:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     8dc:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     8e1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     8e5:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     8e9:	c5 75 fe de          	vpaddd %ymm6,%ymm1,%ymm11
     8ed:	c5 cd 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm6
     8f2:	c4 a2 55 90 0c 9a    	vpgatherdd %ymm5,(%rdx,%ymm11,4),%ymm1
     8f8:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     8fc:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     900:	c5 7d 6f f9          	vmovdqa %ymm1,%ymm15
     904:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     909:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     90d:	41 b8 00 80 00 00    	mov    $0x8000,%r8d
     913:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     918:	c4 62 65 3d d7       	vpmaxsd %ymm7,%ymm3,%ymm10
     91d:	c4 62 65 39 c7       	vpminsd %ymm7,%ymm3,%ymm8
     922:	c4 41 75 fe e3       	vpaddd %ymm11,%ymm1,%ymm12
     927:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
     92b:	c4 c1 5d 66 ea       	vpcmpgtd %ymm10,%ymm4,%ymm5
     930:	c4 22 15 90 34 a2    	vpgatherdd %ymm13,(%rdx,%ymm12,4),%ymm14
     936:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     93c:	c4 62 3d 39 ec       	vpminsd %ymm4,%ymm8,%ymm13
     941:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     947:	c5 8d 72 d0 1f       	vpsrld $0x1f,%ymm0,%ymm14
     94c:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
     950:	c4 62 2d 3d d4       	vpmaxsd %ymm4,%ymm10,%ymm10
     955:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     95b:	c4 c3 75 4c ce 50    	vpblendvb %ymm5,%ymm14,%ymm1,%ymm1
     961:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     966:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     96a:	c4 e2 25 90 2c 8a    	vpgatherdd %ymm11,(%rdx,%ymm1,4),%ymm5
     970:	c5 e5 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm1
     974:	c5 7e 7f 24 24       	vmovdqu %ymm12,(%rsp)
     979:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     97d:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     983:	c4 c3 75 4c ce 80    	vpblendvb %ymm8,%ymm14,%ymm1,%ymm1
     989:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     98d:	c5 9d fa c9          	vpsubd %ymm1,%ymm12,%ymm1
     991:	c4 62 3d 90 1c 8a    	vpgatherdd %ymm8,(%rdx,%ymm1,4),%ymm11
     997:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     99c:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
     9a2:	c4 41 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm15
     9a7:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     9ab:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     9af:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     9b4:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     9b8:	c5 a5 fa e5          	vpsubd %ymm5,%ymm11,%ymm4
     9bc:	c5 75 db 64 24 40    	vpand  0x40(%rsp),%ymm1,%ymm12
     9c2:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
     9c7:	c4 c1 79 6e e0       	vmovd  %r8d,%xmm4
     9cc:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     9d0:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9d5:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
     9db:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     9e0:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     9e4:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     9e9:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     9f0:	00 00 
     9f2:	c4 41 65 fe c0       	vpaddd %ymm8,%ymm3,%ymm8
     9f7:	c5 f5 db 5c 24 60    	vpand  0x60(%rsp),%ymm1,%ymm3
     9fd:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     a02:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
     a07:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a0b:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     a0f:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     a13:	c4 c1 05 72 d0 10    	vpsrld $0x10,%ymm8,%ymm15
     a19:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
     a20:	00 00 
     a22:	c5 7d 6f 50 40       	vmovdqa 0x40(%rax),%ymm10
     a27:	c5 7d 6f 58 20       	vmovdqa 0x20(%rax),%ymm11
     a2c:	c4 02 15 90 04 90    	vpgatherdd %ymm13,(%r8,%ymm10,4),%ymm8
     a32:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     a36:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a3a:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     a3e:	c4 02 15 90 14 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm10
     a44:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     a48:	c5 7d 6f 18          	vmovdqa (%rax),%ymm11
     a4c:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a50:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     a54:	c4 82 15 90 1c 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm3
     a5a:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     a5e:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a62:	4c 8b 41 40          	mov    0x40(%rcx),%r8
     a66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     a6a:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
     a6f:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
     a73:	c4 c2 65 39 fa       	vpminsd %ymm10,%ymm3,%ymm7
     a78:	c4 c1 3d 66 e4       	vpcmpgtd %ymm12,%ymm8,%ymm4
     a7d:	c4 42 45 39 f8       	vpminsd %ymm8,%ymm7,%ymm15
     a82:	c4 42 1d 3d e0       	vpmaxsd %ymm8,%ymm12,%ymm12
     a87:	c4 c1 45 66 f8       	vpcmpgtd %ymm8,%ymm7,%ymm7
     a8c:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     a92:	c4 c3 55 4c ee 40    	vpblendvb %ymm4,%ymm14,%ymm5,%ymm5
     a98:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     a9e:	c4 e2 25 90 24 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm4
     aa4:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
     aa9:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
     aae:	c5 7d 6f 10          	vmovdqa (%rax),%ymm10
     ab2:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     ab7:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     abb:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     ac1:	c4 c3 55 4c ee 70    	vpblendvb %ymm7,%ymm14,%ymm5,%ymm5
     ac7:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     acc:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     ad0:	c4 62 15 90 1c aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm11
     ad6:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
     adc:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
     ae3:	00 00 
     ae5:	c4 41 1d fe ff       	vpaddd %ymm15,%ymm12,%ymm15
     aea:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
     af0:	c4 41 3d fa c7       	vpsubd %ymm15,%ymm8,%ymm8
     af5:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     af9:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     afd:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     b02:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
     b06:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     b0c:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     b10:	c5 25 fa c4          	vpsubd %ymm4,%ymm11,%ymm8
     b14:	c4 42 65 40 c0       	vpmulld %ymm8,%ymm3,%ymm8
     b19:	c5 c5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm7
     b1e:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
     b23:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     b28:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
     b2e:	c5 7d 6f 68 40       	vmovdqa 0x40(%rax),%ymm13
     b33:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     b37:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
     b3e:	00 00 
     b40:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     b45:	c4 82 05 90 1c a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm3
     b4b:	c5 7d 6f 68 20       	vmovdqa 0x20(%rax),%ymm13
     b50:	4c 8b 41 38          	mov    0x38(%rcx),%r8
     b54:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b58:	48 8b 49 30          	mov    0x30(%rcx),%rcx
     b5c:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     b63:	00 00 00 
     b66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     b6a:	c5 bd fe ed          	vpaddd %ymm5,%ymm8,%ymm5
     b6e:	c4 02 05 90 04 a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm8
     b74:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b78:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     b7c:	c4 a2 05 90 24 91    	vpgatherdd %ymm15,(%rcx,%ymm10,4),%ymm4
     b82:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     b86:	c5 dd db f6          	vpand  %ymm6,%ymm4,%ymm6
     b8a:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     b8e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b92:	c4 42 4d 3d d0       	vpmaxsd %ymm8,%ymm6,%ymm10
     b97:	c5 bd 66 fe          	vpcmpgtd %ymm6,%ymm8,%ymm7
     b9b:	c4 42 4d 39 d8       	vpminsd %ymm8,%ymm6,%ymm11
     ba0:	c4 c1 65 66 e2       	vpcmpgtd %ymm10,%ymm3,%ymm4
     ba5:	c4 62 25 39 e3       	vpminsd %ymm3,%ymm11,%ymm12
     baa:	c4 62 2d 3d d3       	vpmaxsd %ymm3,%ymm10,%ymm10
     baf:	c5 25 66 db          	vpcmpgtd %ymm3,%ymm11,%ymm11
     bb3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     bb8:	c4 c3 6d 4c f9 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm7
     bbe:	c4 c3 45 4c fe 40    	vpblendvb %ymm4,%ymm14,%ymm7,%ymm7
     bc4:	c5 c5 fe 7c 24 20    	vpaddd 0x20(%rsp),%ymm7,%ymm7
     bca:	c4 e2 05 90 24 ba    	vpgatherdd %ymm15,(%rdx,%ymm7,4),%ymm4
     bd0:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     bd5:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
     bda:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
     be1:	00 00 
     be3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     be8:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     bec:	c4 c3 6d 4c d1 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm2
     bf2:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     bf7:	c4 c3 6d 4c d6 b0    	vpblendvb %ymm11,%ymm14,%ymm2,%ymm2
     bfd:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     c03:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
     c07:	c4 62 7d 90 0c 92    	vpgatherdd %ymm0,(%rdx,%ymm2,4),%ymm9
     c0d:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     c13:	c4 c1 2d fe c4       	vpaddd %ymm12,%ymm10,%ymm0
     c18:	c5 7d 7f 38          	vmovdqa %ymm15,(%rax)
     c1c:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
     c22:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     c28:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
     c2c:	c5 fd 7f 68 20       	vmovdqa %ymm5,0x20(%rax)
     c31:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     c36:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
     c3a:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     c3e:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     c42:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
     c46:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     c4a:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     c4f:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     c53:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     c58:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     c5d:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     c62:	c5 a5 72 f2 10       	vpslld $0x10,%ymm2,%ymm11
     c67:	c5 25 fe 9c 24 80 00 	vpaddd 0x80(%rsp),%ymm11,%ymm11
     c6e:	00 00 
     c70:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     c75:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     c79:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     c7d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     c82:	c5 fd 7f 40 40       	vmovdqa %ymm0,0x40(%rax)
     c87:	c5 f8 77             	vzeroupper
     c8a:	c5 f8 28 b4 24 e0 00 	vmovaps 0xe0(%rsp),%xmm6
     c91:	00 00 
     c93:	c5 f8 28 bc 24 f0 00 	vmovaps 0xf0(%rsp),%xmm7
     c9a:	00 00 
     c9c:	c5 78 28 84 24 00 01 	vmovaps 0x100(%rsp),%xmm8
     ca3:	00 00 
     ca5:	c5 78 28 8c 24 10 01 	vmovaps 0x110(%rsp),%xmm9
     cac:	00 00 
     cae:	c5 78 28 94 24 20 01 	vmovaps 0x120(%rsp),%xmm10
     cb5:	00 00 
     cb7:	c5 78 28 9c 24 30 01 	vmovaps 0x130(%rsp),%xmm11
     cbe:	00 00 
     cc0:	c5 78 28 a4 24 40 01 	vmovaps 0x140(%rsp),%xmm12
     cc7:	00 00 
     cc9:	c5 78 28 ac 24 50 01 	vmovaps 0x150(%rsp),%xmm13
     cd0:	00 00 
     cd2:	c5 78 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm14
     cd9:	00 00 
     cdb:	c5 78 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm15
     ce2:	00 00 
     ce4:	48 81 c4 88 01 00 00 	add    $0x188,%rsp
     ceb:	c3                   	ret
     cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000cf0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     cf0:	41 55                	push   %r13
     cf2:	41 54                	push   %r12
     cf4:	55                   	push   %rbp
     cf5:	57                   	push   %rdi
     cf6:	56                   	push   %rsi
     cf7:	53                   	push   %rbx
     cf8:	48 81 ec d8 04 00 00 	sub    $0x4d8,%rsp
     cff:	c5 f8 29 b4 24 30 04 	vmovaps %xmm6,0x430(%rsp)
     d06:	00 00 
     d08:	c5 f8 29 bc 24 40 04 	vmovaps %xmm7,0x440(%rsp)
     d0f:	00 00 
     d11:	c5 78 29 84 24 50 04 	vmovaps %xmm8,0x450(%rsp)
     d18:	00 00 
     d1a:	c5 78 29 8c 24 60 04 	vmovaps %xmm9,0x460(%rsp)
     d21:	00 00 
     d23:	c5 78 29 94 24 70 04 	vmovaps %xmm10,0x470(%rsp)
     d2a:	00 00 
     d2c:	c5 78 29 9c 24 80 04 	vmovaps %xmm11,0x480(%rsp)
     d33:	00 00 
     d35:	c5 78 29 a4 24 90 04 	vmovaps %xmm12,0x490(%rsp)
     d3c:	00 00 
     d3e:	c5 78 29 ac 24 a0 04 	vmovaps %xmm13,0x4a0(%rsp)
     d45:	00 00 
     d47:	c5 78 29 b4 24 b0 04 	vmovaps %xmm14,0x4b0(%rsp)
     d4e:	00 00 
     d50:	c5 78 29 bc 24 c0 04 	vmovaps %xmm15,0x4c0(%rsp)
     d57:	00 00 
     d59:	c4 e2 7d 58 7a 08    	vpbroadcastd 0x8(%rdx),%ymm7
     d5f:	c4 e2 7d 58 6a 14    	vpbroadcastd 0x14(%rdx),%ymm5
     d65:	48 8d b4 24 5f 02 00 	lea    0x25f(%rsp),%rsi
     d6c:	00 
     d6d:	49 89 ca             	mov    %rcx,%r10
     d70:	48 83 e6 e0          	and    $0xffffffffffffffe0,%rsi
     d74:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     d7b:	0f b6 41 58          	movzbl 0x58(%rcx),%eax
     d7f:	48 89 d3             	mov    %rdx,%rbx
     d82:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
     d88:	c4 e2 7d 58 7a 0c    	vpbroadcastd 0xc(%rdx),%ymm7
     d8e:	4d 89 c3             	mov    %r8,%r11
     d91:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     d98:	00 00 
     d9a:	c4 e2 7d 58 6a 1c    	vpbroadcastd 0x1c(%rdx),%ymm5
     da0:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     da6:	c4 e2 7d 58 7a 10    	vpbroadcastd 0x10(%rdx),%ymm7
     dac:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
     db3:	00 00 
     db5:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
     dbb:	c4 e2 7d 58 7a 18    	vpbroadcastd 0x18(%rdx),%ymm7
     dc1:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     dc8:	00 00 
     dca:	0f 84 20 0b 00 00    	je     18f0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc00>
     dd0:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     dd7:	0f 84 13 0b 00 00    	je     18f0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc00>
     ddd:	0f b6 91 78 01 00 00 	movzbl 0x178(%rcx),%edx
     de4:	84 c0                	test   %al,%al
     de6:	0f 85 f4 23 00 00    	jne    31e0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24f0>
     dec:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     df0:	0f 84 3a 2f 00 00    	je     3d30 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3040>
     df6:	84 d2                	test   %dl,%dl
     df8:	0f 84 75 0f 00 00    	je     1d73 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1083>
     dfe:	4d 85 c9             	test   %r9,%r9
     e01:	0f 84 29 16 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
     e07:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # e6f <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17f>
     e0e:	00 
     e0f:	b8 00 80 00 00       	mov    $0x8000,%eax
     e14:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
     e18:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
     e1d:	c5 f9 6e e8          	vmovd  %eax,%xmm5
     e21:	48 c1 ef 03          	shr    $0x3,%rdi
     e25:	c4 c1 05 72 d4 18    	vpsrld $0x18,%ymm12,%ymm15
     e2b:	31 ed                	xor    %ebp,%ebp
     e2d:	c5 fe 7f a4 24 e0 00 	vmovdqu %ymm4,0xe0(%rsp)
     e34:	00 00 
     e36:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # ebe <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ce>
     e3d:	00 
     e3e:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     e43:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
     e4a:	00 00 
     e4c:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
     e53:	00 00 
     e55:	e9 b3 00 00 00       	jmp    f0d <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21d>
     e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     e60:	8b 43 24             	mov    0x24(%rbx),%eax
     e63:	8b 53 20             	mov    0x20(%rbx),%edx
     e66:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     e6b:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
     e70:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     e74:	0f af d0             	imul   %eax,%edx
     e77:	c5 f9 6e c0          	vmovd  %eax,%xmm0
     e7b:	48 8b 03             	mov    (%rbx),%rax
     e7e:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     e83:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
     e88:	c4 c1 45 fa c5       	vpsubd %ymm13,%ymm7,%ymm0
     e8d:	c5 f9 6e d2          	vmovd  %edx,%xmm2
     e91:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     e96:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
     e9b:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     e9f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     ea3:	c4 e2 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm0
     ea9:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     eae:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
     eb3:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     eb8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ebd:	c5 ed 72 f0 10       	vpslld $0x10,%ymm0,%ymm2
     ec2:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
     ec7:	49 83 c3 18          	add    $0x18,%r11
     ecb:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     ecf:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
     ed3:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
     eda:	01 00 00 
     edd:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     ee1:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     ee7:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     eec:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     ef1:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     ef5:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
     efb:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
     f01:	48 39 ef             	cmp    %rbp,%rdi
     f04:	0f 84 26 15 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
     f0a:	48 ff c5             	inc    %rbp
     f0d:	c4 c1 7a 6f 1b       	vmovdqu (%r11),%xmm3
     f12:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
     f18:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f1c:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
     f21:	49 8b 02             	mov    (%r10),%rax
     f24:	41 8b 4a 54          	mov    0x54(%r10),%ecx
     f28:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
     f2d:	c4 e3 79 0f c3 0c    	vpalignr $0xc,%xmm3,%xmm0,%xmm0
     f33:	41 8b 52 50          	mov    0x50(%r10),%edx
     f37:	c4 e3 65 38 d8 01    	vinserti128 $0x1,%xmm0,%ymm3,%ymm3
     f3d:	c5 79 6e f1          	vmovd  %ecx,%xmm14
     f41:	c4 e2 65 00 9c 24 e0 	vpshufb 0xe0(%rsp),%ymm3,%ymm3
     f48:	00 00 00 
     f4b:	c5 f9 6e d2          	vmovd  %edx,%xmm2
     f4f:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     f54:	c5 dd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm4
     f59:	c5 cd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm6
     f5e:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
     f63:	c4 e2 45 90 2c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm5
     f69:	49 8b 42 08          	mov    0x8(%r10),%rax
     f6d:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     f72:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f76:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     f7b:	c5 bd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm8
     f80:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     f84:	c4 e2 45 90 0c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm1
     f8a:	49 8b 42 10          	mov    0x10(%r10),%rax
     f8e:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     f92:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # fba <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ca>
     f99:	00 
     f9a:	c4 62 3d 40 c2       	vpmulld %ymm2,%ymm8,%ymm8
     f9f:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
     fa5:	c5 c5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm7
     faa:	49 8b 42 48          	mov    0x48(%r10),%rax
     fae:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # fd6 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e6>
     fb5:	00 
     fb6:	c4 c2 45 40 fe       	vpmulld %ymm14,%ymm7,%ymm7
     fbb:	c5 b5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm9
     fc0:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # fe8 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f8>
     fc7:	00 
     fc8:	c4 c1 45 fe f8       	vpaddd %ymm8,%ymm7,%ymm7
     fcd:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
     fd2:	c4 41 45 fe d1       	vpaddd %ymm9,%ymm7,%ymm10
     fd7:	c4 a2 25 90 3c 90    	vpgatherdd %ymm11,(%rax,%ymm10,4),%ymm7
     fdd:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
     fe4:	00 00 
     fe6:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     fea:	49 8b 52 18          	mov    0x18(%r10),%rdx
     fee:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     ff3:	c4 41 45 fe ca       	vpaddd %ymm10,%ymm7,%ymm9
     ff8:	c4 e2 55 3d f9       	vpmaxsd %ymm1,%ymm5,%ymm7
     ffd:	c4 22 15 90 1c 88    	vpgatherdd %ymm13,(%rax,%ymm9,4),%ymm11
    1003:	c5 7e 7f 9c 24 a0 01 	vmovdqu %ymm11,0x1a0(%rsp)
    100a:	00 00 
    100c:	c4 62 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm3,4),%ymm13
    1012:	49 8b 52 20          	mov    0x20(%r10),%rdx
    1016:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    101a:	c4 62 55 39 c1       	vpminsd %ymm1,%ymm5,%ymm8
    101f:	c4 62 65 90 1c b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm11
    1025:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1029:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    102d:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
    1033:	c5 f5 66 f5          	vpcmpgtd %ymm5,%ymm1,%ymm6
    1037:	c5 7e 7f 94 24 40 01 	vmovdqu %ymm10,0x140(%rsp)
    103e:	00 00 
    1040:	c5 fd 66 e7          	vpcmpgtd %ymm7,%ymm0,%ymm4
    1044:	c4 c3 6d 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
    104a:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm6,%ymm6        # 1053 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x363>
    1051:	ff ff 40 
    1054:	c4 e2 45 3d e0       	vpmaxsd %ymm0,%ymm7,%ymm4
    1059:	c4 e2 3d 39 f8       	vpminsd %ymm0,%ymm8,%ymm7
    105e:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    1065:	00 00 
    1067:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    106c:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
    1070:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    1077:	00 00 
    1079:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    107d:	c4 e2 45 90 24 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm4
    1083:	c5 d5 66 f1          	vpcmpgtd %ymm1,%ymm5,%ymm6
    1087:	c5 7e 6f 94 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm10
    108e:	00 00 
    1090:	c5 7e 7f 8c 24 80 01 	vmovdqu %ymm9,0x180(%rsp)
    1097:	00 00 
    1099:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    109d:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    10a2:	c4 c3 6d 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
    10a8:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm6,%ymm6        # 10b1 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3c1>
    10af:	ff ff 80 
    10b2:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    10b6:	c5 2d fe 8c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm10,%ymm9
    10bd:	00 00 
    10bf:	c4 62 45 90 04 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm8
    10c5:	c5 55 fe d1          	vpaddd %ymm1,%ymm5,%ymm10
    10c9:	c5 85 db bc 24 60 01 	vpand  0x160(%rsp),%ymm15,%ymm7
    10d0:	00 00 
    10d2:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    10d7:	c4 41 7d fa c9       	vpsubd %ymm9,%ymm0,%ymm9
    10dc:	c4 41 35 fe d2       	vpaddd %ymm10,%ymm9,%ymm10
    10e1:	c5 3d fa cc          	vpsubd %ymm4,%ymm8,%ymm9
    10e5:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
    10ea:	c4 42 2d 40 c9       	vpmulld %ymm9,%ymm10,%ymm9
    10ef:	c5 cd fe b4 24 20 01 	vpaddd 0x120(%rsp),%ymm6,%ymm6
    10f6:	00 00 
    10f8:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    10fc:	c4 e2 5d 40 a4 24 c0 	vpmulld 0x1c0(%rsp),%ymm4,%ymm4
    1103:	01 00 00 
    1106:	c5 b5 fe f6          	vpaddd %ymm6,%ymm9,%ymm6
    110a:	c5 05 db 8c 24 a0 01 	vpand  0x1a0(%rsp),%ymm15,%ymm9
    1111:	00 00 
    1113:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
    1118:	c4 62 35 40 8c 24 e0 	vpmulld 0x1e0(%rsp),%ymm9,%ymm9
    111f:	01 00 00 
    1122:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
    1126:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    112b:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    1130:	c4 c1 4d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm6
    1136:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    113d:	00 00 
    113f:	c4 c1 45 72 e3 10    	vpsrad $0x10,%ymm11,%ymm7
    1145:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    1149:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    114d:	c5 cd fe e7          	vpaddd %ymm7,%ymm6,%ymm4
    1151:	c5 fe 7f a4 24 00 02 	vmovdqu %ymm4,0x200(%rsp)
    1158:	00 00 
    115a:	c5 dd 72 e3 10       	vpsrad $0x10,%ymm3,%ymm4
    115f:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    1164:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1169:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    116d:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    1171:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    1177:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    117c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1180:	c4 c1 75 72 f5 10    	vpslld $0x10,%ymm13,%ymm1
    1186:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    118b:	c5 65 fe d0          	vpaddd %ymm0,%ymm3,%ymm10
    118f:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1193:	c4 62 75 3d c0       	vpmaxsd %ymm0,%ymm1,%ymm8
    1198:	c5 7d 66 d9          	vpcmpgtd %ymm1,%ymm0,%ymm11
    119c:	c4 62 3d 3d eb       	vpmaxsd %ymm3,%ymm8,%ymm13
    11a1:	c4 c1 65 66 e8       	vpcmpgtd %ymm8,%ymm3,%ymm5
    11a6:	c4 41 7d 6f c4       	vmovdqa %ymm12,%ymm8
    11ab:	c5 7e 7f ac 24 c0 01 	vmovdqu %ymm13,0x1c0(%rsp)
    11b2:	00 00 
    11b4:	c4 62 75 39 e8       	vpminsd %ymm0,%ymm1,%ymm13
    11b9:	c5 f5 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm0
    11bd:	c4 62 15 39 cb       	vpminsd %ymm3,%ymm13,%ymm9
    11c2:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    11c6:	c4 43 6d 4c de b0    	vpblendvb %ymm11,%ymm14,%ymm2,%ymm11
    11cc:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    11d3:	00 00 
    11d5:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm11,%ymm11        # 11de <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4ee>
    11dc:	ff ff 50 
    11df:	c4 c3 6d 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm2,%ymm0
    11e5:	c5 25 fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm11,%ymm11
    11ec:	00 00 
    11ee:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 11f7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x507>
    11f5:	ff ff d0 
    11f8:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    11fd:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1201:	c4 a2 3d 90 2c 98    	vpgatherdd %ymm8,(%rax,%ymm11,4),%ymm5
    1207:	c5 35 fe 84 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm9,%ymm8
    120e:	00 00 
    1210:	c4 62 15 90 1c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm11
    1216:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    121d:	00 00 
    121f:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    1224:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    122a:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    122f:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    1234:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    1239:	c5 fe 6f 84 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm0
    1240:	00 00 
    1242:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1247:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    124c:	c5 25 fa d5          	vpsubd %ymm5,%ymm11,%ymm10
    1250:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    1255:	c4 62 4d 39 c7       	vpminsd %ymm7,%ymm6,%ymm8
    125a:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    125f:	c4 42 75 40 d2       	vpmulld %ymm10,%ymm1,%ymm10
    1264:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    1269:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    126e:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    1274:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1279:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    127e:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
    1285:	00 00 
    1287:	c4 e2 55 40 ac 24 c0 	vpmulld 0x1c0(%rsp),%ymm5,%ymm5
    128e:	01 00 00 
    1291:	c5 7e 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm11
    1298:	00 00 
    129a:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    129f:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    12a4:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    12a8:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    12ac:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    12b0:	c4 e2 4d 3d ef       	vpmaxsd %ymm7,%ymm6,%ymm5
    12b5:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    12b9:	c5 c5 66 de          	vpcmpgtd %ymm6,%ymm7,%ymm3
    12bd:	c5 dd 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm1
    12c1:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    12c5:	c4 e2 55 3d ec       	vpmaxsd %ymm4,%ymm5,%ymm5
    12ca:	c4 c1 45 72 d3 10    	vpsrld $0x10,%ymm11,%ymm7
    12d0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12d5:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    12dc:	00 00 
    12de:	c4 c3 6d 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm2,%ymm3
    12e4:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    12e9:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm3,%ymm3        # 12f2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x602>
    12f0:	ff ff 10 
    12f3:	c4 c3 6d 4c d6 60    	vpblendvb %ymm6,%ymm14,%ymm2,%ymm2
    12f9:	c5 fe 6f b4 24 60 01 	vmovdqu 0x160(%rsp),%ymm6
    1300:	00 00 
    1302:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
    1308:	c5 e5 fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm3,%ymm3
    130f:	00 00 
    1311:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm2,%ymm2        # 131a <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x62a>
    1318:	ff ff 80 
    131b:	c4 41 55 fe c1       	vpaddd %ymm9,%ymm5,%ymm8
    1320:	c4 c1 5d fa e0       	vpsubd %ymm8,%ymm4,%ymm4
    1325:	c4 e2 15 90 0c 98    	vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm1
    132b:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    1332:	00 00 
    1334:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1339:	c5 dd fe a4 24 00 02 	vpaddd 0x200(%rsp),%ymm4,%ymm4
    1340:	00 00 
    1342:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1347:	c5 e5 fa d2          	vpsubd %ymm2,%ymm3,%ymm2
    134b:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1350:	c4 e2 15 90 1c 90    	vpgatherdd %ymm13,(%rax,%ymm2,4),%ymm3
    1356:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
    135b:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    1361:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1366:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    136b:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1370:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    1375:	c5 65 fa c1          	vpsubd %ymm1,%ymm3,%ymm8
    1379:	c5 c5 fa fb          	vpsubd %ymm3,%ymm7,%ymm7
    137d:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1381:	c4 42 5d 40 c0       	vpmulld %ymm8,%ymm4,%ymm8
    1386:	c5 cd fe b4 24 20 01 	vpaddd 0x120(%rsp),%ymm6,%ymm6
    138d:	00 00 
    138f:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    1394:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1399:	c5 bd fe f6          	vpaddd %ymm6,%ymm8,%ymm6
    139d:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    13a1:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    13a5:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    13ac:	00 00 
    13ae:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    13b3:	c5 fd fa cf          	vpsubd %ymm7,%ymm0,%ymm1
    13b7:	c5 cd fa e7          	vpsubd %ymm7,%ymm6,%ymm4
    13bb:	c5 95 66 ef          	vpcmpgtd %ymm7,%ymm13,%ymm5
    13bf:	c5 8d 66 d9          	vpcmpgtd %ymm1,%ymm14,%ymm3
    13c3:	c5 a5 66 d4          	vpcmpgtd %ymm4,%ymm11,%ymm2
    13c7:	c5 e5 eb d2          	vpor   %ymm2,%ymm3,%ymm2
    13cb:	c5 dd 66 9c 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm4,%ymm3
    13d2:	00 00 
    13d4:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    13d8:	c5 c5 66 5c 24 40    	vpcmpgtd 0x40(%rsp),%ymm7,%ymm3
    13de:	c5 d5 eb db          	vpor   %ymm3,%ymm5,%ymm3
    13e2:	c5 f5 66 ac 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm1,%ymm5
    13e9:	00 00 
    13eb:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    13ef:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    13f3:	c5 fd d7 c2          	vpmovmskb %ymm2,%eax
    13f7:	85 c0                	test   %eax,%eax
    13f9:	0f 84 61 fa ff ff    	je     e60 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x170>
    13ff:	c5 fd 7f be 20 01 00 	vmovdqa %ymm7,0x120(%rsi)
    1406:	00 
    1407:	48 8d 96 20 01 00 00 	lea    0x120(%rsi),%rdx
    140e:	49 8d 4a 60          	lea    0x60(%r10),%rcx
    1412:	c5 fd 7f 86 40 01 00 	vmovdqa %ymm0,0x140(%rsi)
    1419:	00 
    141a:	c5 fd 7f b6 60 01 00 	vmovdqa %ymm6,0x160(%rsi)
    1421:	00 
    1422:	c5 f8 77             	vzeroupper
    1425:	e8 d6 eb ff ff       	call   0 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    142a:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    142f:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    1436:	c5 fd 6f 86 20 01 00 	vmovdqa 0x120(%rsi),%ymm0
    143d:	00 
    143e:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    1442:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    1449:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    144d:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    1454:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1458:	c4 e2 5d 90 14 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm2
    145e:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    1465:	c5 fd 6f 86 40 01 00 	vmovdqa 0x140(%rsi),%ymm0
    146c:	00 
    146d:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    1471:	c5 f9 6e da          	vmovd  %edx,%xmm3
    1475:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    147a:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    147e:	c4 e2 55 90 24 80    	vpgatherdd %ymm5,(%rax,%ymm0,4),%ymm4
    1484:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    148b:	c5 fd 6f 86 60 01 00 	vmovdqa 0x160(%rsi),%ymm0
    1492:	00 
    1493:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    1498:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    149d:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 14c5 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7d5>
    14a4:	00 
    14a5:	c4 e2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm5
    14ab:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    14b0:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    14b7:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 14df <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ef>
    14be:	00 
    14bf:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    14c4:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    14c9:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    14cd:	c5 cd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm6
    14d2:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 14fa <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x80a>
    14d9:	00 
    14da:	c4 62 6d 39 cc       	vpminsd %ymm4,%ymm2,%ymm9
    14df:	c5 6d fe dc          	vpaddd %ymm4,%ymm2,%ymm11
    14e3:	c4 62 35 39 c5       	vpminsd %ymm5,%ymm9,%ymm8
    14e8:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    14ec:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    14f0:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    14f4:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    14f8:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    14fd:	c4 62 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm13
    1503:	c5 75 fe f8          	vpaddd %ymm0,%ymm1,%ymm15
    1507:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    150b:	c4 22 45 90 34 b8    	vpgatherdd %ymm7,(%rax,%ymm15,4),%ymm14
    1511:	c5 dd 66 ca          	vpcmpgtd %ymm2,%ymm4,%ymm1
    1515:	c4 e2 6d 3d fc       	vpmaxsd %ymm4,%ymm2,%ymm7
    151a:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    151e:	c5 ed 66 d4          	vpcmpgtd %ymm4,%ymm2,%ymm2
    1522:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    1527:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    152b:	c4 c3 65 4c ca 10    	vpblendvb %ymm1,%ymm10,%ymm3,%ymm1
    1531:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 153a <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x84a>
    1538:	ff ff 60 
    153b:	c4 c3 65 4c da 20    	vpblendvb %ymm2,%ymm10,%ymm3,%ymm3
    1541:	c4 c1 45 fe f0       	vpaddd %ymm8,%ymm7,%ymm6
    1546:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm3,%ymm3        # 154f <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x85f>
    154d:	ff ff 90 
    1550:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    1554:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1558:	c4 c1 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm6
    155d:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
    1561:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1566:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 15ae <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8be>
    156d:	00 
    156e:	c4 e2 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm1
    1574:	c4 e2 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm0
    157a:	c5 7e 6f 9c 24 20 01 	vmovdqu 0x120(%rsp),%ymm11
    1581:	00 00 
    1583:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    158a:	c4 41 75 db cf       	vpand  %ymm15,%ymm1,%ymm9
    158f:	c4 c1 15 db df       	vpand  %ymm15,%ymm13,%ymm3
    1594:	c4 c1 7d db d7       	vpand  %ymm15,%ymm0,%ymm2
    1599:	c4 c1 0d db e7       	vpand  %ymm15,%ymm14,%ymm4
    159e:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    15a3:	c5 b5 fa db          	vpsubd %ymm3,%ymm9,%ymm3
    15a7:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    15ab:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    15b0:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    15b5:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    15ba:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    15bf:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    15c4:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    15c9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    15ce:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    15d3:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    15d8:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    15dc:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    15e0:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    15e6:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    15ea:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    15ef:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    15f4:	c4 c1 6d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm2
    15fa:	c5 ad 72 f5 10       	vpslld $0x10,%ymm5,%ymm10
    15ff:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1604:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1609:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    160d:	c4 41 2d fe d3       	vpaddd %ymm11,%ymm10,%ymm10
    1612:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    1617:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    161c:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    1620:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    1625:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    162a:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    162f:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    1634:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1639:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    163d:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
    1643:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    1648:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    164d:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1651:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    1657:	c5 d5 fa e8          	vpsubd %ymm0,%ymm5,%ymm5
    165b:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1660:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1665:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1669:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
    166e:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    1673:	c5 f5 fa db          	vpsubd %ymm3,%ymm1,%ymm3
    1677:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    167c:	c4 41 35 fe cb       	vpaddd %ymm11,%ymm9,%ymm9
    1681:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1685:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    168a:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    168f:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    1693:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    1697:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    169c:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    16a0:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    16a6:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    16ad:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    16b1:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    16b8:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    16bf:	c4 e2 5d 90 2c 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm5
    16c5:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    16cc:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    16d0:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    16d4:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    16d9:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    16de:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 1706 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa16>
    16e5:	00 
    16e6:	c4 e2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm6
    16ec:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    16f1:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    16f5:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    16fc:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1701:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1706:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    170a:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    170f:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1714:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 173c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa4c>
    171b:	00 
    171c:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 1744 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa54>
    1723:	00 
    1724:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    1729:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    172e:	c5 65 fe ed          	vpaddd %ymm5,%ymm3,%ymm13
    1732:	c4 62 25 39 ce       	vpminsd %ymm6,%ymm11,%ymm9
    1737:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    173b:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    173f:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1743:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1747:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    174c:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    1750:	c4 62 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm14
    1756:	c5 fd fe f9          	vpaddd %ymm1,%ymm0,%ymm7
    175a:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    1761:	00 00 
    1763:	c4 e2 6d 90 04 b8    	vpgatherdd %ymm2,(%rax,%ymm7,4),%ymm0
    1769:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    176d:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    1772:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    1776:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    177b:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    1782:	00 00 
    1784:	c4 c3 5d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm4,%ymm2
    178a:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 1793 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaa3>
    1791:	ff ff 70 
    1794:	c4 c1 3d fe f9       	vpaddd %ymm9,%ymm8,%ymm7
    1799:	c4 c3 5d 4c e2 30    	vpblendvb %ymm3,%ymm10,%ymm4,%ymm4
    179f:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    17a3:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    17a7:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm4,%ymm4        # 17b0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xac0>
    17ae:	ff ff b0 
    17b1:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    17b6:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    17bb:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    17bf:	c4 e2 15 90 14 88    	vpgatherdd %ymm13,(%rax,%ymm1,4),%ymm2
    17c5:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    17c9:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    17ce:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    17d5:	00 00 
    17d7:	c4 e2 75 90 2c a0    	vpgatherdd %ymm1,(%rax,%ymm4,4),%ymm5
    17dd:	c4 41 6d db d7       	vpand  %ymm15,%ymm2,%ymm10
    17e2:	c4 c1 0d db e7       	vpand  %ymm15,%ymm14,%ymm4
    17e7:	c4 c1 55 db cf       	vpand  %ymm15,%ymm5,%ymm1
    17ec:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    17f1:	c5 ad fa e4          	vpsubd %ymm4,%ymm10,%ymm4
    17f5:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    17f9:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    17fe:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1803:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1808:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    180d:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    1812:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
    1817:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    181c:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    1821:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1826:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    182a:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    182e:	c4 c1 4d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm6
    1834:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    1838:	c5 dd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm4
    183d:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1842:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1847:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    184c:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1851:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    1856:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    185a:	c4 41 25 fe dd       	vpaddd %ymm13,%ymm11,%ymm11
    185f:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1864:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    186a:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    186e:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1873:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    1878:	c4 41 0d db f7       	vpand  %ymm15,%ymm14,%ymm14
    187d:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    1882:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1887:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    188c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1891:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1896:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    189b:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    189f:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    18a3:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    18a8:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    18ad:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    18b1:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    18b6:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    18ba:	c4 c1 5d 72 f6 10    	vpslld $0x10,%ymm14,%ymm4
    18c0:	c4 41 6d fa f6       	vpsubd %ymm14,%ymm2,%ymm14
    18c5:	c4 42 0d 40 f0       	vpmulld %ymm8,%ymm14,%ymm14
    18ca:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    18cf:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
    18d4:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    18d8:	c4 c1 7d fe c6       	vpaddd %ymm14,%ymm0,%ymm0
    18dd:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    18e1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    18e6:	e9 d2 f5 ff ff       	jmp    ebd <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cd>
    18eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    18f0:	84 c0                	test   %al,%al
    18f2:	0f 84 70 04 00 00    	je     1d68 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1078>
    18f8:	4d 85 c9             	test   %r9,%r9
    18fb:	0f 84 2f 0b 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    1901:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 1969 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc79>
    1908:	00 
    1909:	c5 fd 6f 2d 80 00 00 	vmovdqa 0x80(%rip),%ymm5        # 1991 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xca1>
    1910:	00 
    1911:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    1915:	45 31 e4             	xor    %r12d,%r12d
    1918:	48 c1 ed 03          	shr    $0x3,%rbp
    191c:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    1921:	c5 fe 7f a4 24 e0 00 	vmovdqu %ymm4,0xe0(%rsp)
    1928:	00 00 
    192a:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
    1931:	00 00 
    1933:	e9 b4 00 00 00       	jmp    19ec <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcfc>
    1938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    193f:	00 
    1940:	8b 43 24             	mov    0x24(%rbx),%eax
    1943:	8b 53 20             	mov    0x20(%rbx),%edx
    1946:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    194b:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    1950:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
    1955:	0f af d0             	imul   %eax,%edx
    1958:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    195c:	48 8b 03             	mov    (%rbx),%rax
    195f:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1964:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
    1969:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    196d:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1972:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    1977:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    197b:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    197f:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1983:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    1989:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    198e:	c5 fd db d1          	vpand  %ymm1,%ymm0,%ymm2
    1992:	c5 65 db f1          	vpand  %ymm1,%ymm3,%ymm14
    1996:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    199b:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    19a0:	c4 c1 7d 72 f6 08    	vpslld $0x8,%ymm14,%ymm0
    19a6:	49 83 c3 18          	add    $0x18,%r11
    19aa:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    19ae:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    19b2:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    19b9:	01 00 00 
    19bc:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    19c0:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    19c6:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    19cb:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    19d0:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    19d4:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    19da:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    19e0:	4c 39 e5             	cmp    %r12,%rbp
    19e3:	0f 84 47 0a 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    19e9:	49 ff c4             	inc    %r12
    19ec:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    19f1:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    19f7:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    19fb:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
    19ff:	49 8b 02             	mov    (%r10),%rax
    1a02:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    1a06:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1a0c:	41 8b 52 50          	mov    0x50(%r10),%edx
    1a10:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1a16:	c4 c1 75 72 d5 18    	vpsrld $0x18,%ymm13,%ymm1
    1a1c:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    1a20:	c4 e2 7d 00 84 24 e0 	vpshufb 0xe0(%rsp),%ymm0,%ymm0
    1a27:	00 00 00 
    1a2a:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1a2f:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1a34:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    1a39:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1a3d:	c4 e2 45 90 24 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
    1a43:	49 8b 42 08          	mov    0x8(%r10),%rax
    1a47:	c5 e5 db c1          	vpand  %ymm1,%ymm3,%ymm0
    1a4b:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1a4f:	c4 e2 45 90 34 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm6
    1a55:	49 8b 42 10          	mov    0x10(%r10),%rax
    1a59:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    1a5e:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 1a86 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd96>
    1a65:	00 
    1a66:	c4 e2 55 90 3c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm7
    1a6c:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1a71:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    1a75:	49 8b 42 48          	mov    0x48(%r10),%rax
    1a79:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    1a7e:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1a83:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1a87:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    1a8c:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    1a91:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1a95:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1a9a:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 1ac2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdd2>
    1aa1:	00 
    1aa2:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 1aca <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xdda>
    1aa9:	00 
    1aaa:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    1aaf:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    1ab4:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    1ab9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1abd:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1ac1:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    1ac5:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
    1ac9:	c4 62 65 90 3c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm15
    1acf:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
    1ad3:	c5 7e 7f a4 24 20 01 	vmovdqu %ymm12,0x120(%rsp)
    1ada:	00 00 
    1adc:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    1ae0:	c4 a2 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm0
    1ae6:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    1aea:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    1aef:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    1af3:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    1af8:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    1afc:	c4 c3 55 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm5,%ymm3
    1b02:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 1b0b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe1b>
    1b09:	ff ff 80 
    1b0c:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1b11:	c4 c3 55 4c ee 40    	vpblendvb %ymm4,%ymm14,%ymm5,%ymm5
    1b17:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1b1c:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
    1b23:	00 00 
    1b25:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 1b2e <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xe3e>
    1b2c:	ff ff c0 
    1b2f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1b33:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    1b38:	c4 41 7d 6f d5       	vmovdqa %ymm13,%ymm10
    1b3d:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    1b41:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    1b45:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    1b4b:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    1b51:	c5 85 db d1          	vpand  %ymm1,%ymm15,%ymm2
    1b55:	c5 e5 db f9          	vpand  %ymm1,%ymm3,%ymm7
    1b59:	b8 00 80 00 00       	mov    $0x8000,%eax
    1b5e:	c5 dd db e9          	vpand  %ymm1,%ymm4,%ymm5
    1b62:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    1b67:	c5 7d db d1          	vpand  %ymm1,%ymm0,%ymm10
    1b6b:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
    1b6f:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    1b73:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    1b78:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    1b7d:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1b82:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
    1b86:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1b8b:	c4 c1 45 72 d7 08    	vpsrld $0x8,%ymm15,%ymm7
    1b91:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
    1b95:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
    1b99:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1b9e:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1ba3:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    1ba7:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    1bab:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1bb0:	c5 ad fe d2          	vpaddd %ymm2,%ymm10,%ymm2
    1bb4:	c5 79 6e d0          	vmovd  %eax,%xmm10
    1bb8:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1bbd:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    1bc2:	c4 41 0d fe f2       	vpaddd %ymm10,%ymm14,%ymm14
    1bc7:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1bcb:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    1bd0:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1bd4:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    1bd9:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    1bdd:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1be2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1be7:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    1beb:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    1bef:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    1bf4:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    1bf8:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1bfd:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1c02:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
    1c06:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    1c0a:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    1c0e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1c13:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    1c18:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1c1d:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1c22:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1c26:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
    1c2c:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1c30:	c4 c1 4d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm6
    1c36:	c5 7e 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm15
    1c3d:	00 00 
    1c3f:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    1c43:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1c48:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    1c4d:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    1c51:	c5 d5 fa da          	vpsubd %ymm2,%ymm5,%ymm3
    1c55:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1c5a:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
    1c5f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1c63:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1c67:	c5 8d 66 f3          	vpcmpgtd %ymm3,%ymm14,%ymm6
    1c6b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1c6f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1c74:	c5 fd fa fa          	vpsubd %ymm2,%ymm0,%ymm7
    1c78:	c5 85 66 e7          	vpcmpgtd %ymm7,%ymm15,%ymm4
    1c7c:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    1c80:	c5 c5 66 b4 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm7,%ymm6
    1c87:	00 00 
    1c89:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
    1c8f:	c5 25 66 c2          	vpcmpgtd %ymm2,%ymm11,%ymm8
    1c93:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    1c97:	c5 ed 66 74 24 40    	vpcmpgtd 0x40(%rsp),%ymm2,%ymm6
    1c9d:	c5 bd eb f6          	vpor   %ymm6,%ymm8,%ymm6
    1ca1:	c5 65 66 84 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm3,%ymm8
    1ca8:	00 00 
    1caa:	c4 c1 4d eb f0       	vpor   %ymm8,%ymm6,%ymm6
    1caf:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    1cb3:	c5 fd d7 c4          	vpmovmskb %ymm4,%eax
    1cb7:	85 c0                	test   %eax,%eax
    1cb9:	0f 84 81 fc ff ff    	je     1940 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc50>
    1cbf:	c5 fe 7f 94 24 20 01 	vmovdqu %ymm2,0x120(%rsp)
    1cc6:	00 00 
    1cc8:	c5 7d 6f f5          	vmovdqa %ymm5,%ymm14
    1ccc:	c5 7d 6f e0          	vmovdqa %ymm0,%ymm12
    1cd0:	49 8d 7a 60          	lea    0x60(%r10),%rdi
    1cd4:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    1cdb:	80 7f 58 00          	cmpb   $0x0,0x58(%rdi)
    1cdf:	0f 85 2b 0c 00 00    	jne    2910 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c20>
    1ce5:	80 7f 59 00          	cmpb   $0x0,0x59(%rdi)
    1ce9:	0f 84 b1 07 00 00    	je     24a0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17b0>
    1cef:	c5 fe 6f a4 24 20 01 	vmovdqu 0x120(%rsp),%ymm4
    1cf6:	00 00 
    1cf8:	c5 7d 7f b6 a0 01 00 	vmovdqa %ymm14,0x1a0(%rsi)
    1cff:	00 
    1d00:	48 8d 96 80 01 00 00 	lea    0x180(%rsi),%rdx
    1d07:	48 89 f9             	mov    %rdi,%rcx
    1d0a:	c5 7d 7f a6 c0 01 00 	vmovdqa %ymm12,0x1c0(%rsi)
    1d11:	00 
    1d12:	c5 fd 7f a6 80 01 00 	vmovdqa %ymm4,0x180(%rsi)
    1d19:	00 
    1d1a:	c5 f8 77             	vzeroupper
    1d1d:	e8 be e5 ff ff       	call   2e0 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    1d22:	c5 fd 6f a6 80 01 00 	vmovdqa 0x180(%rsi),%ymm4
    1d29:	00 
    1d2a:	c5 7d 6f b6 a0 01 00 	vmovdqa 0x1a0(%rsi),%ymm14
    1d31:	00 
    1d32:	c5 7d 6f a6 c0 01 00 	vmovdqa 0x1c0(%rsi),%ymm12
    1d39:	00 
    1d3a:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    1d3f:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
    1d46:	00 00 
    1d48:	48 83 c7 60          	add    $0x60,%rdi
    1d4c:	49 39 fd             	cmp    %rdi,%r13
    1d4f:	75 8a                	jne    1cdb <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xfeb>
    1d51:	c5 fe 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm2
    1d58:	00 00 
    1d5a:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    1d5e:	e9 38 fc ff ff       	jmp    199b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xcab>
    1d63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1d68:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
    1d6d:	0f 84 ed 0d 00 00    	je     2b60 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e70>
    1d73:	4d 85 c9             	test   %r9,%r9
    1d76:	0f 84 b4 06 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    1d7c:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 1de4 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10f4>
    1d83:	00 
    1d84:	b8 00 80 00 00       	mov    $0x8000,%eax
    1d89:	c5 fd 6f 2d 80 00 00 	vmovdqa 0x80(%rip),%ymm5        # 1e11 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1121>
    1d90:	00 
    1d91:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    1d95:	48 c1 ef 03          	shr    $0x3,%rdi
    1d99:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    1d9e:	45 31 e4             	xor    %r12d,%r12d
    1da1:	c5 fe 7f a4 24 e0 00 	vmovdqu %ymm4,0xe0(%rsp)
    1da8:	00 00 
    1daa:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    1dae:	c4 c1 05 72 d4 18    	vpsrld $0x18,%ymm12,%ymm15
    1db4:	49 89 f8             	mov    %rdi,%r8
    1db7:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1dbc:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
    1dc3:	00 00 
    1dc5:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    1dcc:	00 00 
    1dce:	e9 b2 00 00 00       	jmp    1e85 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1195>
    1dd3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1dd8:	8b 43 24             	mov    0x24(%rbx),%eax
    1ddb:	8b 53 20             	mov    0x20(%rbx),%edx
    1dde:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    1de3:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    1de8:	0f af d0             	imul   %eax,%edx
    1deb:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    1def:	48 8b 03             	mov    (%rbx),%rax
    1df2:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1df7:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
    1dfc:	c4 c1 45 fa c5       	vpsubd %ymm13,%ymm7,%ymm0
    1e01:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1e05:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1e09:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1e0e:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1e13:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1e17:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1e1b:	c4 e2 45 90 14 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm2
    1e21:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
    1e26:	c4 c1 6d db cf       	vpand  %ymm15,%ymm2,%ymm1
    1e2b:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1e30:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1e35:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    1e3a:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    1e3f:	49 83 c3 18          	add    $0x18,%r11
    1e43:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1e47:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    1e4b:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    1e52:	01 00 00 
    1e55:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1e59:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1e5f:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1e64:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1e69:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1e6d:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    1e73:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    1e79:	4d 39 e0             	cmp    %r12,%r8
    1e7c:	0f 84 ae 05 00 00    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    1e82:	49 ff c4             	inc    %r12
    1e85:	c4 c1 7a 6f 13       	vmovdqu (%r11),%xmm2
    1e8a:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
    1e90:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1e94:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1e99:	49 8b 02             	mov    (%r10),%rax
    1e9c:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    1ea0:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    1ea5:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1eaa:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
    1eb0:	41 8b 52 50          	mov    0x50(%r10),%edx
    1eb4:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
    1eba:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    1ebe:	c4 e2 6d 00 94 24 e0 	vpshufb 0xe0(%rsp),%ymm2,%ymm2
    1ec5:	00 00 00 
    1ec8:	c5 79 6e f2          	vmovd  %edx,%xmm14
    1ecc:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1ed1:	c5 e5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm3
    1ed6:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    1edb:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1ee0:	c4 e2 45 90 24 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm4
    1ee6:	49 8b 42 08          	mov    0x8(%r10),%rax
    1eea:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1eef:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1ef3:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1ef8:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1efc:	c4 e2 45 90 0c a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm1
    1f02:	49 8b 42 10          	mov    0x10(%r10),%rax
    1f06:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1f0a:	c5 cd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm6
    1f0f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    1f15:	c5 c5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm7
    1f1a:	49 8b 42 48          	mov    0x48(%r10),%rax
    1f1e:	c4 c2 45 40 fe       	vpmulld %ymm14,%ymm7,%ymm7
    1f23:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1f28:	c5 bd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm8
    1f2d:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    1f31:	c4 41 4d fe c0       	vpaddd %ymm8,%ymm6,%ymm8
    1f36:	c4 c1 4d 72 d4 0f    	vpsrld $0xf,%ymm12,%ymm6
    1f3c:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
    1f40:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
    1f44:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
    1f48:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    1f4c:	c4 a2 4d 90 3c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
    1f52:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    1f56:	49 8b 52 18          	mov    0x18(%r10),%rdx
    1f5a:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1f5f:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    1f66:	00 00 
    1f68:	c4 c1 4d fe f8       	vpaddd %ymm8,%ymm6,%ymm7
    1f6d:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    1f74:	00 00 
    1f76:	c4 e2 25 90 34 b8    	vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm6
    1f7c:	c4 c1 45 72 d4 1f    	vpsrld $0x1f,%ymm12,%ymm7
    1f82:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    1f89:	00 00 
    1f8b:	c4 e2 5d 39 f1       	vpminsd %ymm1,%ymm4,%ymm6
    1f90:	c4 62 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm11
    1f96:	49 8b 52 20          	mov    0x20(%r10),%rdx
    1f9a:	c4 62 15 90 14 aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm10
    1fa0:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1fa4:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1fa8:	c4 62 55 90 2c 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm13
    1fae:	c5 f5 66 dc          	vpcmpgtd %ymm4,%ymm1,%ymm3
    1fb2:	c4 e2 5d 3d e9       	vpmaxsd %ymm1,%ymm4,%ymm5
    1fb7:	c5 fd 66 d5          	vpcmpgtd %ymm5,%ymm0,%ymm2
    1fbb:	c4 e2 55 3d e8       	vpmaxsd %ymm0,%ymm5,%ymm5
    1fc0:	c5 fe 7f ac 24 e0 01 	vmovdqu %ymm5,0x1e0(%rsp)
    1fc7:	00 00 
    1fc9:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1fcd:	c4 c3 0d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm14,%ymm3
    1fd3:	c4 e3 65 4c df 20    	vpblendvb %ymm2,%ymm7,%ymm3,%ymm3
    1fd9:	c4 e2 4d 39 d0       	vpminsd %ymm0,%ymm6,%ymm2
    1fde:	c5 fe 7f 94 24 00 02 	vmovdqu %ymm2,0x200(%rsp)
    1fe5:	00 00 
    1fe7:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1fec:	c5 cd 66 f0          	vpcmpgtd %ymm0,%ymm6,%ymm6
    1ff0:	c5 7e 7f 84 24 60 01 	vmovdqu %ymm8,0x160(%rsp)
    1ff7:	00 00 
    1ff9:	c5 7e 6f 84 24 00 02 	vmovdqu 0x200(%rsp),%ymm8
    2000:	00 00 
    2002:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
    2008:	c5 dd 66 d9          	vpcmpgtd %ymm1,%ymm4,%ymm3
    200c:	c5 7e 7f 8c 24 40 01 	vmovdqu %ymm9,0x140(%rsp)
    2013:	00 00 
    2015:	c5 fe 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm5
    201c:	00 00 
    201e:	c5 3d fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm8,%ymm8
    2025:	00 00 
    2027:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    202c:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2031:	c4 e3 0d 4c 9c 24 40 	vpblendvb %ymm3,0x140(%rsp),%ymm14,%ymm3
    2038:	01 00 00 30 
    203c:	c4 41 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm8
    2041:	c4 e3 65 4c df 60    	vpblendvb %ymm6,%ymm7,%ymm3,%ymm3
    2047:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    204b:	c5 85 db ac 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm5
    2052:	00 00 
    2054:	c4 e2 35 90 34 98    	vpgatherdd %ymm9,(%rax,%ymm3,4),%ymm6
    205a:	c5 5d fe c9          	vpaddd %ymm1,%ymm4,%ymm9
    205e:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2063:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    2068:	c4 41 3d fe c9       	vpaddd %ymm9,%ymm8,%ymm9
    206d:	c5 4d fa c2          	vpsubd %ymm2,%ymm6,%ymm8
    2071:	c5 e5 fe 9c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm3,%ymm3
    2078:	00 00 
    207a:	c4 42 35 40 c0       	vpmulld %ymm8,%ymm9,%ymm8
    207f:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    2083:	c4 e2 6d 40 94 24 e0 	vpmulld 0x1e0(%rsp),%ymm2,%ymm2
    208a:	01 00 00 
    208d:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    2091:	c5 05 db 84 24 a0 01 	vpand  0x1a0(%rsp),%ymm15,%ymm8
    2098:	00 00 
    209a:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
    209e:	c4 c1 4d 72 e2 10    	vpsrad $0x10,%ymm10,%ymm6
    20a4:	c4 62 3d 40 84 24 00 	vpmulld 0x200(%rsp),%ymm8,%ymm8
    20ab:	02 00 00 
    20ae:	c5 3d fe c2          	vpaddd %ymm2,%ymm8,%ymm8
    20b2:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
    20b6:	c4 c1 6d 72 f5 10    	vpslld $0x10,%ymm13,%ymm2
    20bc:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    20c1:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    20c6:	c5 d5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm5
    20cb:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    20cf:	c5 fe 7f ac 24 e0 01 	vmovdqu %ymm5,0x1e0(%rsp)
    20d6:	00 00 
    20d8:	c4 c1 55 72 e3 10    	vpsrad $0x10,%ymm11,%ymm5
    20de:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    20e2:	c5 d5 fe de          	vpaddd %ymm6,%ymm5,%ymm3
    20e6:	c5 fe 7f 9c 24 20 02 	vmovdqu %ymm3,0x220(%rsp)
    20ed:	00 00 
    20ef:	c4 c1 65 72 e5 10    	vpsrad $0x10,%ymm13,%ymm3
    20f5:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    20f9:	c4 c1 7d 72 f2 10    	vpslld $0x10,%ymm10,%ymm0
    20ff:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    2104:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    2109:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    210d:	c5 ed fe c8          	vpaddd %ymm0,%ymm2,%ymm1
    2111:	c5 fe 7f 8c 24 00 02 	vmovdqu %ymm1,0x200(%rsp)
    2118:	00 00 
    211a:	c4 c1 75 72 f3 10    	vpslld $0x10,%ymm11,%ymm1
    2120:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    2125:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2129:	c4 62 75 3d c0       	vpmaxsd %ymm0,%ymm1,%ymm8
    212e:	c5 7d 66 d9          	vpcmpgtd %ymm1,%ymm0,%ymm11
    2132:	c4 62 75 39 e8       	vpminsd %ymm0,%ymm1,%ymm13
    2137:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    213c:	c5 f5 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm0
    2140:	c4 62 15 39 ca       	vpminsd %ymm2,%ymm13,%ymm9
    2145:	c5 15 66 ea          	vpcmpgtd %ymm2,%ymm13,%ymm13
    2149:	c4 62 3d 3d c2       	vpmaxsd %ymm2,%ymm8,%ymm8
    214e:	c5 fe 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm2
    2155:	00 00 
    2157:	c4 63 0d 4c 9c 24 40 	vpblendvb %ymm11,0x140(%rsp),%ymm14,%ymm11
    215e:	01 00 00 b0 
    2162:	c4 63 25 4c df 40    	vpblendvb %ymm4,%ymm7,%ymm11,%ymm11
    2168:	c4 e3 0d 4c 84 24 40 	vpblendvb %ymm0,0x140(%rsp),%ymm14,%ymm0
    216f:	01 00 00 00 
    2173:	c5 25 fe 9c 24 60 01 	vpaddd 0x160(%rsp),%ymm11,%ymm11
    217a:	00 00 
    217c:	c4 e3 7d 4c c7 d0    	vpblendvb %ymm13,%ymm7,%ymm0,%ymm0
    2182:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    2186:	c5 fe 6f 94 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm2
    218d:	00 00 
    218f:	c4 a2 2d 90 24 98    	vpgatherdd %ymm10,(%rax,%ymm11,4),%ymm4
    2195:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    219a:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    219f:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    21a4:	c4 62 2d 90 1c 80    	vpgatherdd %ymm10,(%rax,%ymm0,4),%ymm11
    21aa:	c5 fe 6f 84 24 80 01 	vmovdqu 0x180(%rsp),%ymm0
    21b1:	00 00 
    21b3:	c4 41 3d fe d1       	vpaddd %ymm9,%ymm8,%ymm10
    21b8:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    21be:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    21c3:	c5 95 72 d0 08       	vpsrld $0x8,%ymm0,%ymm13
    21c8:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    21cd:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    21d2:	c5 f5 fe 8c 24 00 02 	vpaddd 0x200(%rsp),%ymm1,%ymm1
    21d9:	00 00 
    21db:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    21e0:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    21e5:	c5 25 fa d4          	vpsubd %ymm4,%ymm11,%ymm10
    21e9:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    21ee:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    21f4:	c5 7e 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm11
    21fb:	00 00 
    21fd:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    2202:	c4 42 75 40 d2       	vpmulld %ymm10,%ymm1,%ymm10
    2207:	c5 fd fe 84 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm0,%ymm0
    220e:	00 00 
    2210:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2215:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    221a:	c4 62 55 39 c6       	vpminsd %ymm6,%ymm5,%ymm8
    221f:	c4 62 3d 39 cb       	vpminsd %ymm3,%ymm8,%ymm9
    2224:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    2228:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    222d:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    2231:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2235:	c4 e2 55 3d e6       	vpmaxsd %ymm6,%ymm5,%ymm4
    223a:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    223e:	c5 cd 66 d5          	vpcmpgtd %ymm5,%ymm6,%ymm2
    2242:	c5 e5 66 cc          	vpcmpgtd %ymm4,%ymm3,%ymm1
    2246:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    224a:	c4 e2 5d 3d e3       	vpmaxsd %ymm3,%ymm4,%ymm4
    224f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2254:	c4 c3 0d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm14,%ymm2
    225a:	c4 e3 6d 4c d7 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm2
    2260:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
    2267:	00 00 
    2269:	c4 e2 15 90 0c 90    	vpgatherdd %ymm13,(%rax,%ymm2,4),%ymm1
    226f:	c4 c3 0d 4c d3 50    	vpblendvb %ymm5,%ymm11,%ymm14,%ymm2
    2275:	c5 fe 6f b4 24 20 01 	vmovdqu 0x120(%rsp),%ymm6
    227c:	00 00 
    227e:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    2283:	c4 e3 6d 4c d7 80    	vpblendvb %ymm8,%ymm7,%ymm2,%ymm2
    2289:	c4 41 5d fe c1       	vpaddd %ymm9,%ymm4,%ymm8
    228e:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
    2294:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    229a:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    229e:	c5 fe 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm6
    22a5:	00 00 
    22a7:	c4 c1 65 fa d8       	vpsubd %ymm8,%ymm3,%ymm3
    22ac:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    22b1:	c4 e2 25 90 3c 90    	vpgatherdd %ymm11,(%rax,%ymm2,4),%ymm7
    22b7:	c5 fe 6f 94 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm2
    22be:	00 00 
    22c0:	c5 e5 fe 9c 24 20 02 	vpaddd 0x220(%rsp),%ymm3,%ymm3
    22c7:	00 00 
    22c9:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    22ce:	c5 d5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm5
    22d3:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    22d8:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    22df:	00 00 
    22e1:	c5 cd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm6
    22e6:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    22eb:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    22f0:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    22f5:	c5 ed 72 f5 10       	vpslld $0x10,%ymm5,%ymm2
    22fa:	c5 45 fa c1          	vpsubd %ymm1,%ymm7,%ymm8
    22fe:	c5 cd fa f7          	vpsubd %ymm7,%ymm6,%ymm6
    2302:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    2306:	c4 42 65 40 c0       	vpmulld %ymm8,%ymm3,%ymm8
    230b:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    2312:	00 00 
    2314:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    2319:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    231e:	c5 ed fe 94 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm2,%ymm2
    2325:	00 00 
    2327:	c5 bd fe d2          	vpaddd %ymm2,%ymm8,%ymm2
    232b:	c5 cd fe f1          	vpaddd %ymm1,%ymm6,%ymm6
    232f:	c5 fd fa cf          	vpsubd %ymm7,%ymm0,%ymm1
    2333:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    2337:	c5 8d 66 e1          	vpcmpgtd %ymm1,%ymm14,%ymm4
    233b:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2340:	c5 95 66 f7          	vpcmpgtd %ymm7,%ymm13,%ymm6
    2344:	c5 ed fa ef          	vpsubd %ymm7,%ymm2,%ymm5
    2348:	c5 a5 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm3
    234c:	c5 dd eb db          	vpor   %ymm3,%ymm4,%ymm3
    2350:	c5 d5 66 a4 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm5,%ymm4
    2357:	00 00 
    2359:	c5 e5 eb dc          	vpor   %ymm4,%ymm3,%ymm3
    235d:	c5 c5 66 64 24 40    	vpcmpgtd 0x40(%rsp),%ymm7,%ymm4
    2363:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    2367:	c5 f5 66 b4 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm1,%ymm6
    236e:	00 00 
    2370:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    2374:	c5 e5 eb dc          	vpor   %ymm4,%ymm3,%ymm3
    2378:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    237c:	85 c0                	test   %eax,%eax
    237e:	0f 84 54 fa ff ff    	je     1dd8 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10e8>
    2384:	c5 fe 6f 8c 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm1
    238b:	00 00 
    238d:	48 89 9c 24 18 05 00 	mov    %rbx,0x518(%rsp)
    2394:	00 
    2395:	49 8d 6a 60          	lea    0x60(%r10),%rbp
    2399:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    23a0:	4c 89 d3             	mov    %r10,%rbx
    23a3:	48 8d be c0 00 00 00 	lea    0xc0(%rsi),%rdi
    23aa:	4d 89 c2             	mov    %r8,%r10
    23ad:	80 7d 58 00          	cmpb   $0x0,0x58(%rbp)
    23b1:	0f 85 49 19 00 00    	jne    3d00 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3010>
    23b7:	80 7d 59 00          	cmpb   $0x0,0x59(%rbp)
    23bb:	c5 fd 7f 8e c0 00 00 	vmovdqa %ymm1,0xc0(%rsi)
    23c2:	00 
    23c3:	48 89 fa             	mov    %rdi,%rdx
    23c6:	48 89 e9             	mov    %rbp,%rcx
    23c9:	c5 fd 7f 86 e0 00 00 	vmovdqa %ymm0,0xe0(%rsi)
    23d0:	00 
    23d1:	c5 fd 7f 96 00 01 00 	vmovdqa %ymm2,0x100(%rsi)
    23d8:	00 
    23d9:	0f 84 b9 18 00 00    	je     3c98 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fa8>
    23df:	c5 f8 77             	vzeroupper
    23e2:	e8 f9 de ff ff       	call   2e0 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    23e7:	c5 fd 6f 8e c0 00 00 	vmovdqa 0xc0(%rsi),%ymm1
    23ee:	00 
    23ef:	c5 fd 6f 86 e0 00 00 	vmovdqa 0xe0(%rsi),%ymm0
    23f6:	00 
    23f7:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    23fc:	c5 fd 6f 96 00 01 00 	vmovdqa 0x100(%rsi),%ymm2
    2403:	00 
    2404:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 244c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x175c>
    240b:	00 
    240c:	48 83 c5 60          	add    $0x60,%rbp
    2410:	49 39 ed             	cmp    %rbp,%r13
    2413:	75 98                	jne    23ad <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16bd>
    2415:	4d 89 d0             	mov    %r10,%r8
    2418:	49 89 da             	mov    %rbx,%r10
    241b:	48 8b 9c 24 18 05 00 	mov    0x518(%rsp),%rbx
    2422:	00 
    2423:	e9 0d fa ff ff       	jmp    1e35 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1145>
    2428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    242f:	00 
    2430:	c5 f8 77             	vzeroupper
    2433:	c5 f8 28 b4 24 30 04 	vmovaps 0x430(%rsp),%xmm6
    243a:	00 00 
    243c:	c5 f8 28 bc 24 40 04 	vmovaps 0x440(%rsp),%xmm7
    2443:	00 00 
    2445:	c5 78 28 84 24 50 04 	vmovaps 0x450(%rsp),%xmm8
    244c:	00 00 
    244e:	c5 78 28 8c 24 60 04 	vmovaps 0x460(%rsp),%xmm9
    2455:	00 00 
    2457:	c5 78 28 94 24 70 04 	vmovaps 0x470(%rsp),%xmm10
    245e:	00 00 
    2460:	c5 78 28 9c 24 80 04 	vmovaps 0x480(%rsp),%xmm11
    2467:	00 00 
    2469:	c5 78 28 a4 24 90 04 	vmovaps 0x490(%rsp),%xmm12
    2470:	00 00 
    2472:	c5 78 28 ac 24 a0 04 	vmovaps 0x4a0(%rsp),%xmm13
    2479:	00 00 
    247b:	c5 78 28 b4 24 b0 04 	vmovaps 0x4b0(%rsp),%xmm14
    2482:	00 00 
    2484:	c5 78 28 bc 24 c0 04 	vmovaps 0x4c0(%rsp),%xmm15
    248b:	00 00 
    248d:	48 81 c4 d8 04 00 00 	add    $0x4d8,%rsp
    2494:	5b                   	pop    %rbx
    2495:	5e                   	pop    %rsi
    2496:	5f                   	pop    %rdi
    2497:	5d                   	pop    %rbp
    2498:	41 5c                	pop    %r12
    249a:	41 5d                	pop    %r13
    249c:	c3                   	ret
    249d:	0f 1f 00             	nopl   (%rax)
    24a0:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
    24a7:	00 00 
    24a9:	48 8b 07             	mov    (%rdi),%rax
    24ac:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
    24b0:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    24b4:	8b 4f 54             	mov    0x54(%rdi),%ecx
    24b7:	8b 57 50             	mov    0x50(%rdi),%edx
    24ba:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    24bf:	c4 41 7d 6f cd       	vmovdqa %ymm13,%ymm9
    24c4:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    24cb:	00 00 
    24cd:	c4 e2 55 90 04 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm0
    24d3:	48 8b 47 08          	mov    0x8(%rdi),%rax
    24d7:	c5 7e 7f b4 24 60 01 	vmovdqu %ymm14,0x160(%rsp)
    24de:	00 00 
    24e0:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    24e4:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    24e8:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    24ed:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    24f1:	c4 a2 75 90 2c b0    	vpgatherdd %ymm1,(%rax,%ymm14,4),%ymm5
    24f7:	48 8b 47 10          	mov    0x10(%rdi),%rax
    24fb:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    24ff:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2504:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    2509:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2531 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1841>
    2510:	00 
    2511:	c4 a2 75 90 1c a0    	vpgatherdd %ymm1,(%rax,%ymm12,4),%ymm3
    2517:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    251c:	48 8b 47 48          	mov    0x48(%rdi),%rax
    2520:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 2548 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1858>
    2527:	00 
    2528:	c4 e2 5d 40 e2       	vpmulld %ymm2,%ymm4,%ymm4
    252d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2532:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    2537:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 255f <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x186f>
    253e:	00 
    253f:	c4 62 7d 3d c5       	vpmaxsd %ymm5,%ymm0,%ymm8
    2544:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    2548:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
    254d:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    2552:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    2556:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
    255a:	c4 e2 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm6
    255f:	c4 22 75 90 14 b8    	vpgatherdd %ymm1,(%rax,%ymm15,4),%ymm10
    2565:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2569:	ba 00 80 00 00       	mov    $0x8000,%edx
    256e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2573:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    2578:	c4 a2 25 90 0c b0    	vpgatherdd %ymm11,(%rax,%ymm14,4),%ymm1
    257e:	c4 62 4d 39 db       	vpminsd %ymm3,%ymm6,%ymm11
    2583:	c5 fe 7f 8c 24 c0 01 	vmovdqu %ymm1,0x1c0(%rsp)
    258a:	00 00 
    258c:	c5 d5 66 c8          	vpcmpgtd %ymm0,%ymm5,%ymm1
    2590:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
    2594:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    259a:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 25a3 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18b3>
    25a1:	ff ff 40 
    25a4:	c5 85 fe c9          	vpaddd %ymm1,%ymm15,%ymm1
    25a8:	c4 e2 35 90 24 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm4
    25ae:	c5 fd 66 cd          	vpcmpgtd %ymm5,%ymm0,%ymm1
    25b2:	c5 7e 7f b4 24 a0 01 	vmovdqu %ymm14,0x1a0(%rsp)
    25b9:	00 00 
    25bb:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    25bf:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    25c3:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    25c8:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    25ce:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 25d7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18e7>
    25d5:	ff ff 60 
    25d8:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    25dc:	c5 8d fa c9          	vpsubd %ymm1,%ymm14,%ymm1
    25e0:	c4 41 3d fe f3       	vpaddd %ymm11,%ymm8,%ymm14
    25e5:	c4 62 4d 90 0c 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm9
    25eb:	c4 c1 75 72 d5 18    	vpsrld $0x18,%ymm13,%ymm1
    25f1:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    25f6:	c5 7e 7f 94 24 80 01 	vmovdqu %ymm10,0x180(%rsp)
    25fd:	00 00 
    25ff:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    2603:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    2607:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    260b:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
    260f:	c5 75 db 94 24 80 01 	vpand  0x180(%rsp),%ymm1,%ymm10
    2616:	00 00 
    2618:	c5 fe 7f ac 24 e0 01 	vmovdqu %ymm5,0x1e0(%rsp)
    261f:	00 00 
    2621:	48 8b 57 28          	mov    0x28(%rdi),%rdx
    2625:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    262a:	c5 fe 6f 9c 24 60 01 	vmovdqu 0x160(%rsp),%ymm3
    2631:	00 00 
    2633:	c4 c1 4d 72 f2 10    	vpslld $0x10,%ymm10,%ymm6
    2639:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    263e:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    2642:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    2647:	c5 fd fe f6          	vpaddd %ymm6,%ymm0,%ymm6
    264b:	c5 f5 db 84 24 c0 01 	vpand  0x1c0(%rsp),%ymm1,%ymm0
    2652:	00 00 
    2654:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    2659:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    265e:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2662:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    2669:	00 00 
    266b:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    266f:	c5 a5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm11
    2674:	c5 7e 7f 9c 24 20 01 	vmovdqu %ymm11,0x120(%rsp)
    267b:	00 00 
    267d:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    2682:	c4 a2 25 90 34 a2    	vpgatherdd %ymm11,(%rdx,%ymm12,4),%ymm6
    2688:	48 8b 57 20          	mov    0x20(%rdi),%rdx
    268c:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    2691:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 26b9 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x19c9>
    2698:	00 
    2699:	c4 62 25 90 04 9a    	vpgatherdd %ymm11,(%rdx,%ymm3,4),%ymm8
    269f:	48 8b 57 18          	mov    0x18(%rdi),%rdx
    26a3:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    26a8:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 26d0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x19e0>
    26af:	00 
    26b0:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    26b6:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    26bb:	48 8b 57 40          	mov    0x40(%rdi),%rdx
    26bf:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 26e7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x19f7>
    26c6:	00 
    26c7:	c4 42 65 3d d0       	vpmaxsd %ymm8,%ymm3,%ymm10
    26cc:	c5 bd 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm0
    26d0:	c4 c2 65 39 e8       	vpminsd %ymm8,%ymm3,%ymm5
    26d5:	c4 c1 4d 66 e2       	vpcmpgtd %ymm10,%ymm6,%ymm4
    26da:	c4 62 55 39 f6       	vpminsd %ymm6,%ymm5,%ymm14
    26df:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    26e4:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    26e8:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    26ee:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm0,%ymm0        # 26f7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a07>
    26f5:	ff ff 40 
    26f8:	c5 85 fe c0          	vpaddd %ymm0,%ymm15,%ymm0
    26fc:	c4 e2 25 90 24 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm4
    2702:	c4 c1 65 66 c0       	vpcmpgtd %ymm8,%ymm3,%ymm0
    2707:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    270c:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    2711:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    2716:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    271a:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    2720:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 2729 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a39>
    2727:	ff ff 50 
    272a:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    2731:	00 00 
    2733:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2737:	c5 fe 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm5
    273e:	00 00 
    2740:	c4 62 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm9
    2746:	c5 fe 6f 84 24 80 01 	vmovdqu 0x180(%rsp),%ymm0
    274d:	00 00 
    274f:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    2755:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    275a:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    275e:	c5 a5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm11
    2763:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    2767:	c5 7e 7f 8c 24 00 02 	vmovdqu %ymm9,0x200(%rsp)
    276e:	00 00 
    2770:	c4 41 2d fe ce       	vpaddd %ymm14,%ymm10,%ymm9
    2775:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
    2779:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    277e:	c5 7e 6f 8c 24 00 02 	vmovdqu 0x200(%rsp),%ymm9
    2785:	00 00 
    2787:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    278d:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    2791:	c5 fd fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm0
    2798:	00 00 
    279a:	c5 b5 fa f4          	vpsubd %ymm4,%ymm9,%ymm6
    279e:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    27a3:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    27a8:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
    27ad:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    27b2:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    27b7:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
    27bc:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    27c0:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    27c4:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    27c8:	c5 8d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm14
    27cd:	c4 a2 25 90 04 a2    	vpgatherdd %ymm11,(%rdx,%ymm12,4),%ymm0
    27d3:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
    27d8:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2800 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b10>
    27df:	00 
    27e0:	48 8b 57 38          	mov    0x38(%rdi),%rdx
    27e4:	c5 fe 6f b4 24 60 01 	vmovdqu 0x160(%rsp),%ymm6
    27eb:	00 00 
    27ed:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    27f4:	00 00 
    27f6:	c4 e2 1d 90 2c b2    	vpgatherdd %ymm12,(%rdx,%ymm6,4),%ymm5
    27fc:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    2800:	c4 41 7d 6f e5       	vmovdqa %ymm13,%ymm12
    2805:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 282d <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b3d>
    280c:	00 
    280d:	c4 e2 1d 90 24 9a    	vpgatherdd %ymm12,(%rdx,%ymm3,4),%ymm4
    2813:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 283b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b4b>
    281a:	00 
    281b:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    2820:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    2824:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    2829:	c4 c1 7d 66 d8       	vpcmpgtd %ymm8,%ymm0,%ymm3
    282e:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    2833:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    2838:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    283c:	c4 41 3d fe da       	vpaddd %ymm10,%ymm8,%ymm11
    2841:	c4 e3 6d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm6
    2847:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    284c:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 2855 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b65>
    2853:	ff ff 30 
    2856:	c5 85 fe f6          	vpaddd %ymm6,%ymm15,%ymm6
    285a:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    285f:	c4 e2 05 90 1c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm3
    2865:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    2869:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    286e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2873:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2877:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    287b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    287f:	c4 e3 6d 4c d7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm2
    2885:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    288c:	00 00 
    288e:	c5 fe 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm6
    2895:	00 00 
    2897:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm2,%ymm2        # 28a0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bb0>
    289e:	ff ff 90 
    28a1:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    28a5:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    28aa:	c4 e2 05 90 3c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm7
    28b0:	c5 fe 6f 94 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm2
    28b7:	00 00 
    28b9:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    28bd:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    28c2:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    28c7:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    28cc:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
    28d0:	c5 35 fe 8c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm9,%ymm9
    28d7:	00 00 
    28d9:	c5 ed db c9          	vpand  %ymm1,%ymm2,%ymm1
    28dd:	c5 c5 fa e3          	vpsubd %ymm3,%ymm7,%ymm4
    28e1:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    28e5:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    28ea:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    28ef:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    28f3:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    28f8:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    28fd:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2901:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2905:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    290a:	e9 39 f4 ff ff       	jmp    1d48 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1058>
    290f:	90                   	nop
    2910:	c5 fe 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm5
    2917:	00 00 
    2919:	48 8b 07             	mov    (%rdi),%rax
    291c:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    2920:	8b 4f 54             	mov    0x54(%rdi),%ecx
    2923:	8b 57 50             	mov    0x50(%rdi),%edx
    2926:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    292c:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2930:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    2934:	c5 79 6e ca          	vmovd  %edx,%xmm9
    2938:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    293d:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2941:	c4 a2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm14,4),%ymm5
    2947:	48 8b 47 10          	mov    0x10(%rdi),%rax
    294b:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    294f:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2954:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    2959:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    295e:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 2986 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c96>
    2965:	00 
    2966:	c4 a2 45 90 34 a0    	vpgatherdd %ymm7,(%rax,%ymm12,4),%ymm6
    296c:	c5 79 6e e1          	vmovd  %ecx,%xmm12
    2970:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 2998 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ca8>
    2977:	00 
    2978:	48 8b 47 48          	mov    0x48(%rdi),%rax
    297c:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2981:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    2986:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    298a:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    298f:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 29b7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cc7>
    2996:	00 
    2997:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    299c:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    29a0:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    29a5:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    29a9:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    29ad:	c4 c1 55 72 d5 18    	vpsrld $0x18,%ymm13,%ymm5
    29b3:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    29b8:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    29bc:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    29c2:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    29c6:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    29ca:	c4 43 35 4c cc 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm9
    29d0:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    29d4:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    29d9:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm9,%ymm9        # 29e2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cf2>
    29e0:	ff ff b0 
    29e3:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    29e9:	c5 7d fe f2          	vpaddd %ymm2,%ymm0,%ymm14
    29ed:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
    29f1:	c4 a2 45 90 04 b0    	vpgatherdd %ymm7,(%rax,%ymm14,4),%ymm0
    29f7:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    29fc:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2a01:	c5 7d 7f ec          	vmovdqa %ymm13,%ymm4
    2a05:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 2a0e <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d1e>
    2a0c:	ff ff 70 
    2a0f:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2a14:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2a18:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    2a1c:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    2a21:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    2a26:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    2a2c:	c4 c1 0d fa d1       	vpsubd %ymm9,%ymm14,%ymm2
    2a31:	c5 75 db cd          	vpand  %ymm5,%ymm1,%ymm9
    2a35:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    2a3b:	c5 65 db e5          	vpand  %ymm5,%ymm3,%ymm12
    2a3f:	c5 fd db e5          	vpand  %ymm5,%ymm0,%ymm4
    2a43:	b8 00 80 00 00       	mov    $0x8000,%eax
    2a48:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    2a4e:	c5 cd db d5          	vpand  %ymm5,%ymm6,%ymm2
    2a52:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    2a57:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    2a5c:	c5 8d 72 d0 08       	vpsrld $0x8,%ymm0,%ymm14
    2a61:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    2a65:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2a6a:	c5 0d db f5          	vpand  %ymm5,%ymm14,%ymm14
    2a6e:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2a73:	c4 41 6d fa cc       	vpsubd %ymm12,%ymm2,%ymm9
    2a78:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    2a7c:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
    2a81:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    2a86:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2a8b:	c5 25 fe da          	vpaddd %ymm2,%ymm11,%ymm11
    2a8f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2a94:	c5 1d db e5          	vpand  %ymm5,%ymm12,%ymm12
    2a98:	c5 e5 db dd          	vpand  %ymm5,%ymm3,%ymm3
    2a9c:	c4 41 35 fe cb       	vpaddd %ymm11,%ymm9,%ymm9
    2aa1:	c5 a5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm11
    2aa6:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2aab:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2ab0:	c5 25 db dd          	vpand  %ymm5,%ymm11,%ymm11
    2ab4:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2ab9:	c4 c1 35 72 f3 10    	vpslld $0x10,%ymm11,%ymm9
    2abf:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    2ac4:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
    2acb:	00 00 
    2acd:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    2ad2:	c4 42 25 40 d8       	vpmulld %ymm8,%ymm11,%ymm11
    2ad7:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
    2adb:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
    2adf:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    2ae4:	c5 f5 db cd          	vpand  %ymm5,%ymm1,%ymm1
    2ae8:	c5 0d fa f4          	vpsubd %ymm4,%ymm14,%ymm14
    2aec:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    2af1:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    2af6:	c4 42 0d 40 f2       	vpmulld %ymm10,%ymm14,%ymm14
    2afb:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2b00:	c5 cd db c5          	vpand  %ymm5,%ymm6,%ymm0
    2b04:	c5 1d db e5          	vpand  %ymm5,%ymm12,%ymm12
    2b08:	c5 1d fa e0          	vpsubd %ymm0,%ymm12,%ymm12
    2b0c:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    2b10:	c4 42 1d 40 e2       	vpmulld %ymm10,%ymm12,%ymm12
    2b15:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    2b1a:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2b1f:	c4 41 0d fe f3       	vpaddd %ymm11,%ymm14,%ymm14
    2b24:	c5 0d fe f4          	vpaddd %ymm4,%ymm14,%ymm14
    2b28:	c5 dd 72 f1 10       	vpslld $0x10,%ymm1,%ymm4
    2b2d:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    2b31:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    2b36:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    2b3c:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    2b40:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2b44:	c5 1d fe e1          	vpaddd %ymm1,%ymm12,%ymm12
    2b48:	c5 1d fe e0          	vpaddd %ymm0,%ymm12,%ymm12
    2b4c:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    2b52:	e9 f1 f1 ff ff       	jmp    1d48 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1058>
    2b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2b5e:	00 00 
    2b60:	4d 85 c9             	test   %r9,%r9
    2b63:	0f 84 c7 f8 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    2b69:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 2bd1 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ee1>
    2b70:	00 
    2b71:	b8 00 80 00 00       	mov    $0x8000,%eax
    2b76:	c5 fd 6f 2d 80 00 00 	vmovdqa 0x80(%rip),%ymm5        # 2bfe <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f0e>
    2b7d:	00 
    2b7e:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    2b82:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    2b87:	48 c1 ef 03          	shr    $0x3,%rdi
    2b8b:	45 31 e4             	xor    %r12d,%r12d
    2b8e:	c5 fe 7f a4 24 e0 00 	vmovdqu %ymm4,0xe0(%rsp)
    2b95:	00 00 
    2b97:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    2b9b:	c4 c1 25 72 d2 18    	vpsrld $0x18,%ymm10,%ymm11
    2ba1:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2ba6:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
    2bad:	00 00 
    2baf:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
    2bb6:	00 00 
    2bb8:	e9 af 00 00 00       	jmp    2c6c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f7c>
    2bbd:	0f 1f 00             	nopl   (%rax)
    2bc0:	8b 43 24             	mov    0x24(%rbx),%eax
    2bc3:	8b 53 20             	mov    0x20(%rbx),%edx
    2bc6:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    2bca:	c4 c1 55 fa ee       	vpsubd %ymm14,%ymm5,%ymm5
    2bcf:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    2bd3:	0f af d0             	imul   %eax,%edx
    2bd6:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    2bda:	48 8b 03             	mov    (%rbx),%rax
    2bdd:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    2be2:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    2be7:	c4 c1 05 fa c4       	vpsubd %ymm12,%ymm15,%ymm0
    2bec:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2bf0:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2bf5:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    2bfa:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    2bfe:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2c02:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    2c08:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    2c0d:	c4 c1 75 db d3       	vpand  %ymm11,%ymm1,%ymm2
    2c12:	c4 c1 7d db c3       	vpand  %ymm11,%ymm0,%ymm0
    2c17:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2c1c:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    2c21:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    2c26:	49 83 c3 18          	add    $0x18,%r11
    2c2a:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2c2e:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2c32:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    2c39:	01 00 00 
    2c3c:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2c40:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2c46:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2c4b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2c50:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2c54:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    2c5a:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    2c60:	4c 39 e7             	cmp    %r12,%rdi
    2c63:	0f 84 c7 f7 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    2c69:	49 ff c4             	inc    %r12
    2c6c:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    2c71:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    2c77:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    2c7b:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    2c7f:	49 8b 02             	mov    (%r10),%rax
    2c82:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    2c86:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2c8b:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2c91:	41 8b 52 50          	mov    0x50(%r10),%edx
    2c95:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2c9b:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    2c9f:	c4 e2 7d 00 84 24 e0 	vpshufb 0xe0(%rsp),%ymm0,%ymm0
    2ca6:	00 00 00 
    2ca9:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    2cae:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2cb3:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    2cb8:	c4 c1 7d db eb       	vpand  %ymm11,%ymm0,%ymm5
    2cbd:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
    2cc4:	00 00 
    2cc6:	c4 e2 5d 90 04 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm0
    2ccc:	c4 c1 75 db e3       	vpand  %ymm11,%ymm1,%ymm4
    2cd1:	49 8b 42 08          	mov    0x8(%r10),%rax
    2cd5:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2cd9:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    2ce0:	00 00 
    2ce2:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2ce7:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2ceb:	c4 e2 65 90 2c a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm5
    2cf1:	49 8b 42 10          	mov    0x10(%r10),%rax
    2cf5:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    2cfc:	00 00 
    2cfe:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    2d02:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    2d07:	c4 e2 65 90 14 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm2
    2d0d:	c5 e5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm3
    2d12:	49 8b 42 48          	mov    0x48(%r10),%rax
    2d16:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    2d1b:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    2d20:	c5 cd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm6
    2d25:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    2d29:	c4 c1 5d 72 d2 0f    	vpsrld $0xf,%ymm10,%ymm4
    2d2f:	c5 65 fe fe          	vpaddd %ymm6,%ymm3,%ymm15
    2d33:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2d37:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    2d3b:	c4 a2 4d 90 1c b8    	vpgatherdd %ymm6,(%rax,%ymm15,4),%ymm3
    2d41:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
    2d45:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2d49:	c5 fe 7f 9c 24 80 01 	vmovdqu %ymm3,0x180(%rsp)
    2d50:	00 00 
    2d52:	c5 f9 6e da          	vmovd  %edx,%xmm3
    2d56:	c4 e2 7d 3d fd       	vpmaxsd %ymm5,%ymm0,%ymm7
    2d5b:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2d60:	c4 41 65 fe e7       	vpaddd %ymm15,%ymm3,%ymm12
    2d65:	c5 ed 66 df          	vpcmpgtd %ymm7,%ymm2,%ymm3
    2d69:	c4 e2 45 3d fa       	vpmaxsd %ymm2,%ymm7,%ymm7
    2d6e:	c4 a2 35 90 34 a0    	vpgatherdd %ymm9,(%rax,%ymm12,4),%ymm6
    2d74:	c5 7e 7f bc 24 60 01 	vmovdqu %ymm15,0x160(%rsp)
    2d7b:	00 00 
    2d7d:	c4 62 7d 39 cd       	vpminsd %ymm5,%ymm0,%ymm9
    2d82:	c5 7d 6f c6          	vmovdqa %ymm6,%ymm8
    2d86:	c5 d5 66 f0          	vpcmpgtd %ymm0,%ymm5,%ymm6
    2d8a:	c4 62 35 39 ea       	vpminsd %ymm2,%ymm9,%ymm13
    2d8f:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
    2d93:	c4 c3 75 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm6
    2d99:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 2da2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20b2>
    2da0:	ff ff 30 
    2da3:	c4 c1 4d fe f7       	vpaddd %ymm15,%ymm6,%ymm6
    2da8:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    2dad:	c4 e2 05 90 1c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm3
    2db3:	c5 fd 66 f5          	vpcmpgtd %ymm5,%ymm0,%ymm6
    2db7:	c5 7e 7f a4 24 a0 01 	vmovdqu %ymm12,0x1a0(%rsp)
    2dbe:	00 00 
    2dc0:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    2dc5:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2dca:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2dce:	c4 c3 75 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm6
    2dd4:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 2ddd <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20ed>
    2ddb:	ff ff 90 
    2dde:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    2de2:	c5 25 db a4 24 80 01 	vpand  0x180(%rsp),%ymm11,%ymm12
    2de9:	00 00 
    2deb:	c4 62 05 90 0c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm9
    2df1:	c4 41 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm15
    2df6:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2dfb:	c4 c1 4d 72 f4 10    	vpslld $0x10,%ymm12,%ymm6
    2e01:	c4 c1 6d fa d7       	vpsubd %ymm15,%ymm2,%ymm2
    2e06:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    2e0a:	c5 b5 fa d3          	vpsubd %ymm3,%ymm9,%ymm2
    2e0e:	c4 e2 7d 40 d2       	vpmulld %ymm2,%ymm0,%ymm2
    2e13:	c4 c1 25 db c0       	vpand  %ymm8,%ymm11,%ymm0
    2e18:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    2e1d:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    2e22:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2e27:	c5 cd fe b4 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm6,%ymm6
    2e2e:	00 00 
    2e30:	49 8b 52 28          	mov    0x28(%r10),%rdx
    2e34:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    2e39:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    2e40:	00 00 
    2e42:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2e47:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    2e4c:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    2e50:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
    2e57:	00 00 
    2e59:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2e5d:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    2e61:	c5 fe 6f 84 24 20 01 	vmovdqu 0x120(%rsp),%ymm0
    2e68:	00 00 
    2e6a:	c5 85 72 d6 10       	vpsrld $0x10,%ymm6,%ymm15
    2e6f:	c4 e2 35 90 34 ba    	vpgatherdd %ymm9,(%rdx,%ymm7,4),%ymm6
    2e75:	49 8b 52 20          	mov    0x20(%r10),%rdx
    2e79:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2e7e:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
    2e82:	c4 e2 35 90 3c 92    	vpgatherdd %ymm9,(%rdx,%ymm2,4),%ymm7
    2e88:	49 8b 52 18          	mov    0x18(%r10),%rdx
    2e8c:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2e91:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
    2e95:	c4 e2 35 90 14 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm2
    2e9b:	49 8b 52 40          	mov    0x40(%r10),%rdx
    2e9f:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2ea3:	c4 62 6d 3d e7       	vpmaxsd %ymm7,%ymm2,%ymm12
    2ea8:	c5 c5 66 c2          	vpcmpgtd %ymm2,%ymm7,%ymm0
    2eac:	c4 e2 6d 39 ef       	vpminsd %ymm7,%ymm2,%ymm5
    2eb1:	c4 c1 4d 66 dc       	vpcmpgtd %ymm12,%ymm6,%ymm3
    2eb6:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    2ebb:	c4 62 1d 3d e6       	vpmaxsd %ymm6,%ymm12,%ymm12
    2ec0:	c5 7e 7f 8c 24 20 02 	vmovdqu %ymm9,0x220(%rsp)
    2ec7:	00 00 
    2ec9:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    2ecd:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2ed3:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm0,%ymm0        # 2edc <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21ec>
    2eda:	ff ff 30 
    2edd:	c5 fd fe 84 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm0
    2ee4:	00 00 
    2ee6:	c4 e2 15 90 1c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm3
    2eec:	c5 ed 66 c7          	vpcmpgtd %ymm7,%ymm2,%ymm0
    2ef0:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    2ef5:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    2efa:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    2efe:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    2f05:	00 00 
    2f07:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2f0c:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2f12:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 2f1b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x222b>
    2f19:	ff ff 50 
    2f1c:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    2f23:	00 00 
    2f25:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2f29:	c4 c1 55 72 d0 08    	vpsrld $0x8,%ymm8,%ymm5
    2f2f:	c4 62 15 90 0c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm9
    2f35:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    2f3c:	00 00 
    2f3e:	c5 7e 7f 84 24 00 02 	vmovdqu %ymm8,0x200(%rsp)
    2f45:	00 00 
    2f47:	c5 1d fe 84 24 20 02 	vpaddd 0x220(%rsp),%ymm12,%ymm8
    2f4e:	00 00 
    2f50:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    2f56:	c4 c1 55 db eb       	vpand  %ymm11,%ymm5,%ymm5
    2f5b:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
    2f61:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2f66:	c4 c1 4d fa f0       	vpsubd %ymm8,%ymm6,%ymm6
    2f6b:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    2f70:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    2f74:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2f78:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    2f7d:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    2f82:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2f87:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    2f8c:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    2f92:	c4 e2 55 40 ac 24 20 	vpmulld 0x220(%rsp),%ymm5,%ymm5
    2f99:	02 00 00 
    2f9c:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    2fa1:	c5 fd fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm0
    2fa8:	00 00 
    2faa:	c4 41 7d 6f c2       	vmovdqa %ymm10,%ymm8
    2faf:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    2fb3:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    2fb7:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    2fbb:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2fbf:	c4 e2 4d 90 2c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm5
    2fc5:	49 8b 52 38          	mov    0x38(%r10),%rdx
    2fc9:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
    2fd0:	00 00 
    2fd2:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
    2fd9:	00 00 
    2fdb:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    2fdf:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    2fe6:	00 00 
    2fe8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2fed:	c4 e2 1d 90 34 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm6
    2ff3:	49 8b 52 30          	mov    0x30(%r10),%rdx
    2ff7:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    2ffc:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
    3000:	c4 e2 1d 90 14 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm2
    3006:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    300a:	c4 e2 6d 3d fe       	vpmaxsd %ymm6,%ymm2,%ymm7
    300f:	c5 cd 66 e2          	vpcmpgtd %ymm2,%ymm6,%ymm4
    3013:	c4 62 6d 39 ce       	vpminsd %ymm6,%ymm2,%ymm9
    3018:	c5 d5 66 df          	vpcmpgtd %ymm7,%ymm5,%ymm3
    301c:	c4 62 35 39 e5       	vpminsd %ymm5,%ymm9,%ymm12
    3021:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    3026:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    302a:	c4 c3 75 4c e6 40    	vpblendvb %ymm4,%ymm14,%ymm1,%ymm4
    3030:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm4,%ymm4        # 3039 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2349>
    3037:	ff ff 30 
    303a:	c5 dd fe a4 24 60 01 	vpaddd 0x160(%rsp),%ymm4,%ymm4
    3041:	00 00 
    3043:	c4 e2 3d 90 1c a0    	vpgatherdd %ymm8,(%rax,%ymm4,4),%ymm3
    3049:	c5 ed 66 e6          	vpcmpgtd %ymm6,%ymm2,%ymm4
    304d:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3051:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3056:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    305b:	c4 c3 75 4c ce 40    	vpblendvb %ymm4,%ymm14,%ymm1,%ymm1
    3061:	c5 fe 6f a4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm4
    3068:	00 00 
    306a:	c5 7e 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm14
    3071:	00 00 
    3073:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 307c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x238c>
    307a:	ff ff 90 
    307d:	c5 dd fa c9          	vpsubd %ymm1,%ymm4,%ymm1
    3081:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3085:	c4 62 5d 90 0c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm9
    308b:	c5 fe 6f 8c 24 00 02 	vmovdqu 0x200(%rsp),%ymm1
    3092:	00 00 
    3094:	c4 c1 5d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm4
    309a:	c4 41 45 fe ec       	vpaddd %ymm12,%ymm7,%ymm13
    309f:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    30a5:	c4 c1 5d db e3       	vpand  %ymm11,%ymm4,%ymm4
    30aa:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    30af:	c5 bd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm8
    30b4:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    30b9:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    30bd:	c4 41 3d db c3       	vpand  %ymm11,%ymm8,%ymm8
    30c2:	c5 f5 72 f4 10       	vpslld $0x10,%ymm4,%ymm1
    30c7:	c5 b5 fa eb          	vpsubd %ymm3,%ymm9,%ymm5
    30cb:	c4 41 3d fa c1       	vpsubd %ymm9,%ymm8,%ymm8
    30d0:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    30d4:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    30d9:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    30de:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
    30e3:	c5 f5 fe 8c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm1,%ymm1
    30ea:	00 00 
    30ec:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    30f2:	c4 c1 7d fa d7       	vpsubd %ymm15,%ymm0,%ymm2
    30f7:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
    30fd:	c5 c5 66 e2          	vpcmpgtd %ymm2,%ymm7,%ymm4
    3101:	c4 c1 1d 66 f7       	vpcmpgtd %ymm15,%ymm12,%ymm6
    3106:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    310a:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    310e:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    3113:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3118:	c4 c1 75 fa ef       	vpsubd %ymm15,%ymm1,%ymm5
    311d:	c5 8d 66 dd          	vpcmpgtd %ymm5,%ymm14,%ymm3
    3121:	c5 dd eb db          	vpor   %ymm3,%ymm4,%ymm3
    3125:	c5 d5 66 a4 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm5,%ymm4
    312c:	00 00 
    312e:	c5 e5 eb dc          	vpor   %ymm4,%ymm3,%ymm3
    3132:	c5 85 66 64 24 40    	vpcmpgtd 0x40(%rsp),%ymm15,%ymm4
    3138:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    313c:	c5 ed 66 b4 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm2,%ymm6
    3143:	00 00 
    3145:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    3149:	c5 e5 eb dc          	vpor   %ymm4,%ymm3,%ymm3
    314d:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    3151:	85 c0                	test   %eax,%eax
    3153:	0f 84 67 fa ff ff    	je     2bc0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ed0>
    3159:	49 8d 6a 60          	lea    0x60(%r10),%rbp
    315d:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    3161:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    3168:	80 7d 58 00          	cmpb   $0x0,0x58(%rbp)
    316c:	75 54                	jne    31c2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24d2>
    316e:	80 7d 59 00          	cmpb   $0x0,0x59(%rbp)
    3172:	c5 fd 7f 16          	vmovdqa %ymm2,(%rsi)
    3176:	48 89 f2             	mov    %rsi,%rdx
    3179:	48 89 e9             	mov    %rbp,%rcx
    317c:	c5 fd 7f 46 20       	vmovdqa %ymm0,0x20(%rsi)
    3181:	c5 fd 7f 4e 40       	vmovdqa %ymm1,0x40(%rsi)
    3186:	0f 84 44 0b 00 00    	je     3cd0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fe0>
    318c:	c5 f8 77             	vzeroupper
    318f:	e8 4c d1 ff ff       	call   2e0 <void jshc_delta16_cache::(anonymous namespace)::transform<false, true>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    3194:	c5 fd 6f 16          	vmovdqa (%rsi),%ymm2
    3198:	c5 fd 6f 46 20       	vmovdqa 0x20(%rsi),%ymm0
    319d:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    31a2:	c5 fd 6f 4e 40       	vmovdqa 0x40(%rsi),%ymm1
    31a7:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 31ef <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24ff>
    31ae:	00 
    31af:	48 83 c5 60          	add    $0x60,%rbp
    31b3:	49 39 ed             	cmp    %rbp,%r13
    31b6:	0f 84 60 fa ff ff    	je     2c1c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f2c>
    31bc:	80 7d 58 00          	cmpb   $0x0,0x58(%rbp)
    31c0:	74 ac                	je     316e <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x247e>
    31c2:	c5 fd 7f 16          	vmovdqa %ymm2,(%rsi)
    31c6:	48 89 f2             	mov    %rsi,%rdx
    31c9:	48 89 e9             	mov    %rbp,%rcx
    31cc:	c5 fd 7f 46 20       	vmovdqa %ymm0,0x20(%rsi)
    31d1:	c5 fd 7f 4e 40       	vmovdqa %ymm1,0x40(%rsi)
    31d6:	c5 f8 77             	vzeroupper
    31d9:	e8 22 ce ff ff       	call   0 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    31de:	eb b4                	jmp    3194 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24a4>
    31e0:	84 d2                	test   %dl,%dl
    31e2:	0f 84 10 e7 ff ff    	je     18f8 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc08>
    31e8:	4d 85 c9             	test   %r9,%r9
    31eb:	0f 84 3f f2 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    31f1:	c5 fd 6f 2d 60 00 00 	vmovdqa 0x60(%rip),%ymm5        # 3259 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2569>
    31f8:	00 
    31f9:	49 ff c9             	dec    %r9
    31fc:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3201:	49 c1 e9 03          	shr    $0x3,%r9
    3205:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
    320b:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    320f:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
    3216:	00 00 
    3218:	c5 fd 6f 2d 80 00 00 	vmovdqa 0x80(%rip),%ymm5        # 32a0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25b0>
    321f:	00 
    3220:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    3225:	b8 00 80 00 00       	mov    $0x8000,%eax
    322a:	c5 fe 7f ac 24 00 01 	vmovdqu %ymm5,0x100(%rsp)
    3231:	00 00 
    3233:	c5 f9 6e e8          	vmovd  %eax,%xmm5
    3237:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    323c:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
    3243:	00 00 
    3245:	e9 ae 00 00 00       	jmp    32f8 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2608>
    324a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3250:	8b 43 24             	mov    0x24(%rbx),%eax
    3253:	8b 53 20             	mov    0x20(%rbx),%edx
    3256:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    325b:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3260:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
    3265:	0f af d0             	imul   %eax,%edx
    3268:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    326c:	48 8b 03             	mov    (%rbx),%rax
    326f:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    3274:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    3279:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    327d:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    3282:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
    3287:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    328b:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    328f:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3293:	c4 e2 45 90 0c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm1
    3299:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    329e:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
    32a2:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    32a6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    32ab:	c5 e5 72 f1 10       	vpslld $0x10,%ymm1,%ymm3
    32b0:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
    32b5:	49 83 c0 18          	add    $0x18,%r8
    32b9:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
    32bd:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
    32c1:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
    32c8:	01 00 00 
    32cb:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
    32cf:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    32d5:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
    32da:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    32df:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    32e3:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
    32e9:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    32ef:	4d 39 c8             	cmp    %r9,%r8
    32f2:	0f 84 38 f1 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    32f8:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    32fd:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
    3303:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3307:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    330b:	49 8b 02             	mov    (%r10),%rax
    330e:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    3312:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
    3318:	41 8b 52 50          	mov    0x50(%r10),%edx
    331c:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
    3322:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3326:	c4 e2 75 00 8c 24 e0 	vpshufb 0xe0(%rsp),%ymm1,%ymm1
    332d:	00 00 00 
    3330:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3335:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    333a:	c5 ed 72 d1 10       	vpsrld $0x10,%ymm1,%ymm2
    333f:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3343:	c4 e2 45 90 24 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm4
    3349:	49 8b 42 08          	mov    0x8(%r10),%rax
    334d:	c5 e5 db c8          	vpand  %ymm0,%ymm3,%ymm1
    3351:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3355:	c4 e2 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm6
    335b:	49 8b 42 10          	mov    0x10(%r10),%rax
    335f:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3364:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 338c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x269c>
    336b:	00 
    336c:	c4 e2 55 90 3c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm7
    3372:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3377:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    337b:	49 8b 42 48          	mov    0x48(%r10),%rax
    337f:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3384:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3389:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    338d:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3392:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3397:	c5 79 6e d2          	vmovd  %edx,%xmm10
    339b:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    33a0:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 33c8 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26d8>
    33a7:	00 
    33a8:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 33d0 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26e0>
    33af:	00 
    33b0:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    33b5:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    33ba:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    33bf:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    33c4:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    33c8:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    33cc:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    33d0:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    33d4:	c4 62 65 90 34 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm14
    33da:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    33de:	c5 7e 7f 9c 24 40 01 	vmovdqu %ymm11,0x140(%rsp)
    33e5:	00 00 
    33e7:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    33eb:	c4 a2 65 90 0c 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm1
    33f1:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    33f5:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    33fa:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    33fe:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3402:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    3406:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    340c:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 3415 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2725>
    3413:	ff ff 80 
    3416:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    341b:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    3421:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    3428:	00 00 
    342a:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    342f:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    3436:	00 00 
    3438:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 3441 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2751>
    343f:	ff ff c0 
    3442:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3446:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    344b:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    3450:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    3454:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3458:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    345e:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    3464:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3468:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
    346c:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
    3470:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3475:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    3479:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    347d:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    3482:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3487:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    348c:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3491:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3496:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    349b:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    34a0:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    34a4:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    34a8:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    34ac:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    34b0:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    34b6:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    34ba:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    34bf:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    34c3:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    34c8:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    34cd:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    34d1:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    34d5:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    34d9:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    34de:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    34e3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    34e8:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    34ec:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    34f1:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    34f6:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    34fa:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    34ff:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3504:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3508:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    350d:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    3511:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    3515:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    351a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    351f:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    3523:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3528:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    352c:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    3532:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
    3538:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    353f:	00 00 
    3541:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3545:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    354a:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
    3550:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3555:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    3559:	c5 d5 fa da          	vpsubd %ymm2,%ymm5,%ymm3
    355d:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3562:	c5 1d 66 c2          	vpcmpgtd %ymm2,%ymm12,%ymm8
    3566:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    356b:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    356f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3573:	c5 8d 66 f3          	vpcmpgtd %ymm3,%ymm14,%ymm6
    3577:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    357b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3580:	c5 f5 fa fa          	vpsubd %ymm2,%ymm1,%ymm7
    3584:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
    3588:	c5 cd eb e4          	vpor   %ymm4,%ymm6,%ymm4
    358c:	c5 c5 66 b4 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm7,%ymm6
    3593:	00 00 
    3595:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    3599:	c5 ed 66 74 24 40    	vpcmpgtd 0x40(%rsp),%ymm2,%ymm6
    359f:	c5 bd eb f6          	vpor   %ymm6,%ymm8,%ymm6
    35a3:	c5 65 66 84 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm3,%ymm8
    35aa:	00 00 
    35ac:	c4 c1 4d eb f0       	vpor   %ymm8,%ymm6,%ymm6
    35b1:	c5 dd eb e6          	vpor   %ymm6,%ymm4,%ymm4
    35b5:	c5 fd d7 c4          	vpmovmskb %ymm4,%eax
    35b9:	85 c0                	test   %eax,%eax
    35bb:	0f 84 8f fc ff ff    	je     3250 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2560>
    35c1:	49 8b 42 60          	mov    0x60(%r10),%rax
    35c5:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    35c9:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    35d0:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    35d7:	c4 e2 45 90 24 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm4
    35dd:	49 8b 42 68          	mov    0x68(%r10),%rax
    35e1:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    35e5:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    35e9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    35ee:	c4 e2 45 90 34 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm6
    35f4:	49 8b 42 70          	mov    0x70(%r10),%rax
    35f8:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    35fc:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3601:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3629 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2939>
    3608:	00 
    3609:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    360f:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3614:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    3618:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    361f:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3624:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3629:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    362d:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3632:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3637:	c5 79 6e d2          	vmovd  %edx,%xmm10
    363b:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3640:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 3668 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2978>
    3647:	00 
    3648:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 3670 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2980>
    364f:	00 
    3650:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3655:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    365a:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    365f:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3664:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3668:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    366c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3670:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    3674:	c4 62 65 90 34 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm14
    367a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    367e:	c5 7e 7f 9c 24 40 01 	vmovdqu %ymm11,0x140(%rsp)
    3685:	00 00 
    3687:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    368b:	c4 a2 65 90 0c 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm1
    3691:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3695:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    369a:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    369e:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    36a2:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    36a6:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    36ac:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 36b5 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x29c5>
    36b3:	ff ff 80 
    36b6:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    36bb:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    36c1:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    36c8:	00 00 
    36ca:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    36cf:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    36d6:	00 00 
    36d8:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 36e1 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x29f1>
    36df:	ff ff c0 
    36e2:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    36e6:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    36eb:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    36f0:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    36f4:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    36f8:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    36fe:	c4 e2 45 90 14 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm2
    3704:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3708:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    370c:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    3713:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    3717:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    371c:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    3720:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    3724:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    3729:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    372e:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    3733:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3738:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    373d:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3742:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3747:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    374b:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    374f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3753:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3757:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    375d:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    3761:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    3766:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    376a:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    376f:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3774:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3778:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    377c:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3780:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3785:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    378a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    378f:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    3793:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    3798:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    379d:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    37a1:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    37a6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    37ab:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    37af:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    37b4:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    37b8:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    37bc:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    37c1:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    37c6:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    37ca:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    37cf:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    37d3:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    37d8:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    37de:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    37e2:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    37e7:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    37eb:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    37ef:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    37f4:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    37f9:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    37fd:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3801:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3807:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    380e:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3812:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3816:	c4 e2 55 90 34 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm6
    381c:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    3823:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    382a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    382f:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    3836:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    383a:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    383f:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3867 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2b77>
    3846:	00 
    3847:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    384d:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3852:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3856:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    385d:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    3861:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3866:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    386a:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    386f:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3874:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3878:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    387d:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3882:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3887:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 38af <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2bbf>
    388e:	00 
    388f:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 38b7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2bc7>
    3896:	00 
    3897:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    389c:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    38a1:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    38a6:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    38aa:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
    38ae:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    38b2:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    38b6:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
    38ba:	c4 62 75 90 34 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm14
    38c0:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    38c4:	c5 7e 7f a4 24 40 01 	vmovdqu %ymm12,0x140(%rsp)
    38cb:	00 00 
    38cd:	c4 a2 65 90 0c a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm1
    38d3:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    38d7:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    38dc:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    38e0:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    38e5:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    38e9:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    38ed:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    38f3:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 38fc <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2c0c>
    38fa:	ff ff 80 
    38fd:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    3903:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3908:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    390f:	00 00 
    3911:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 391a <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2c2a>
    3918:	ff ff c0 
    391b:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3920:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3924:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    392b:	00 00 
    392d:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    3932:	c5 dd fa ed          	vpsubd %ymm5,%ymm4,%ymm5
    3936:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    393b:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    393f:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3944:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    394a:	c4 e2 5d 90 14 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm2
    3950:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3954:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    3958:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    395f:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    3963:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    3967:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    396c:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    3970:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    3975:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    397a:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    397f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3984:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3989:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    398e:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3992:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3996:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    399a:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    399e:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    39a4:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    39a8:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    39ad:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    39b1:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    39b6:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    39bb:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    39bf:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    39c3:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    39c7:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    39cc:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    39d1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    39d6:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    39da:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    39df:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    39e4:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    39e8:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    39ed:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    39f2:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    39f6:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    39fb:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    39ff:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    3a03:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3a08:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3a0d:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3a11:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3a16:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    3a1a:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    3a1f:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    3a25:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3a29:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    3a2e:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    3a32:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3a36:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3a3b:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    3a40:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3a44:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3a48:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    3a4e:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    3a55:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3a59:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3a5d:	c4 e2 55 90 34 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm6
    3a63:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    3a6a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3a6f:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3a73:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3a78:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    3a7e:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    3a85:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    3a8c:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3a91:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3a96:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    3a9d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3ac5 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2dd5>
    3aa4:	00 
    3aa5:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    3aa9:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3aad:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3ab1:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3ab6:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3abb:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3abf:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3ac4:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3ac9:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3ace:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 3af6 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e06>
    3ad5:	00 
    3ad6:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 3afe <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e0e>
    3add:	00 
    3ade:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3ae3:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    3ae8:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3aed:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3af1:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
    3af5:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3af9:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3afd:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
    3b01:	c4 62 75 90 34 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm14
    3b07:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    3b0b:	c5 7e 7f a4 24 40 01 	vmovdqu %ymm12,0x140(%rsp)
    3b12:	00 00 
    3b14:	c4 a2 65 90 0c a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm1
    3b1a:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3b1e:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3b23:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    3b27:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    3b2c:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3b30:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    3b36:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 3b3f <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e4f>
    3b3d:	ff ff 80 
    3b40:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3b45:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    3b4b:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    3b52:	00 00 
    3b54:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3b59:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    3b60:	00 00 
    3b62:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm5,%ymm5        # 3b6b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e7b>
    3b69:	ff ff c0 
    3b6c:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3b70:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    3b75:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    3b7a:	c5 f5 db e0          	vpand  %ymm0,%ymm1,%ymm4
    3b7e:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    3b82:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3b86:	c4 e2 2d 90 1c 90    	vpgatherdd %ymm10,(%rax,%ymm2,4),%ymm3
    3b8c:	c4 e2 45 90 34 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm6
    3b92:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3b96:	c5 8d db e8          	vpand  %ymm0,%ymm14,%ymm5
    3b9a:	c5 cd db d0          	vpand  %ymm0,%ymm6,%ymm2
    3b9e:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    3ba3:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
    3ba7:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    3bab:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
    3bb0:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    3bb5:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    3bba:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3bbf:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3bc4:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3bc9:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3bce:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3bd2:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3bd6:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3bda:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    3bde:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    3be4:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    3be8:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
    3bed:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3bf1:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    3bf6:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3bfb:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    3bff:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3c03:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3c07:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3c0c:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3c11:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    3c16:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    3c1a:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    3c1f:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3c24:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3c28:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3c2d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3c32:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3c36:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3c3b:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    3c3f:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
    3c43:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3c48:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3c4d:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3c51:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    3c56:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3c5a:	c4 c1 55 72 d6 10    	vpsrld $0x10,%ymm14,%ymm5
    3c60:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    3c64:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3c69:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    3c6e:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    3c72:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    3c77:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3c7c:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    3c80:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3c84:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3c88:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3c8d:	e9 19 f6 ff ff       	jmp    32ab <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25bb>
    3c92:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3c98:	c5 f8 77             	vzeroupper
    3c9b:	e8 60 cb ff ff       	call   800 <void jshc_delta16_cache::(anonymous namespace)::transform<false, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    3ca0:	c5 fd 6f 8e c0 00 00 	vmovdqa 0xc0(%rsi),%ymm1
    3ca7:	00 
    3ca8:	c5 fd 6f 86 e0 00 00 	vmovdqa 0xe0(%rsi),%ymm0
    3caf:	00 
    3cb0:	c5 fd 6f 96 00 01 00 	vmovdqa 0x100(%rsi),%ymm2
    3cb7:	00 
    3cb8:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 3d00 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3010>
    3cbf:	00 
    3cc0:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3cc5:	e9 42 e7 ff ff       	jmp    240c <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x171c>
    3cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3cd0:	c5 f8 77             	vzeroupper
    3cd3:	e8 28 cb ff ff       	call   800 <void jshc_delta16_cache::(anonymous namespace)::transform<false, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    3cd8:	c5 fd 6f 16          	vmovdqa (%rsi),%ymm2
    3cdc:	c5 fd 6f 46 20       	vmovdqa 0x20(%rsi),%ymm0
    3ce1:	c5 fd 6f 4e 40       	vmovdqa 0x40(%rsi),%ymm1
    3ce6:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 3d2e <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x303e>
    3ced:	00 
    3cee:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    3cf3:	e9 b7 f4 ff ff       	jmp    31af <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24bf>
    3cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cff:	00 
    3d00:	c5 fd 7f 8e c0 00 00 	vmovdqa %ymm1,0xc0(%rsi)
    3d07:	00 
    3d08:	48 89 fa             	mov    %rdi,%rdx
    3d0b:	48 89 e9             	mov    %rbp,%rcx
    3d0e:	c5 fd 7f 86 e0 00 00 	vmovdqa %ymm0,0xe0(%rsi)
    3d15:	00 
    3d16:	c5 fd 7f 96 00 01 00 	vmovdqa %ymm2,0x100(%rsi)
    3d1d:	00 
    3d1e:	c5 f8 77             	vzeroupper
    3d21:	e8 da c2 ff ff       	call   0 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    3d26:	e9 bc e6 ff ff       	jmp    23e7 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16f7>
    3d2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3d30:	84 d2                	test   %dl,%dl
    3d32:	0f 84 28 ee ff ff    	je     2b60 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e70>
    3d38:	4d 85 c9             	test   %r9,%r9
    3d3b:	0f 84 ef e6 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    3d41:	c5 fd 6f 2d 60 00 00 	vmovdqa 0x60(%rip),%ymm5        # 3da9 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x30b9>
    3d48:	00 
    3d49:	b8 00 80 00 00       	mov    $0x8000,%eax
    3d4e:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 3dd6 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x30e6>
    3d55:	00 
    3d56:	49 8d 79 ff          	lea    -0x1(%r9),%rdi
    3d5a:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3d5f:	48 c1 ef 03          	shr    $0x3,%rdi
    3d63:	31 ed                	xor    %ebp,%ebp
    3d65:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
    3d6c:	00 00 
    3d6e:	c5 f9 6e e8          	vmovd  %eax,%xmm5
    3d72:	c4 c1 2d 72 d4 18    	vpsrld $0x18,%ymm12,%ymm10
    3d78:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3d7d:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    3d84:	00 00 
    3d86:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
    3d8d:	00 00 
    3d8f:	e9 b1 00 00 00       	jmp    3e45 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3155>
    3d94:	0f 1f 40 00          	nopl   0x0(%rax)
    3d98:	8b 43 24             	mov    0x24(%rbx),%eax
    3d9b:	8b 53 20             	mov    0x20(%rbx),%edx
    3d9e:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    3da3:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    3da8:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
    3dad:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    3db1:	0f af d0             	imul   %eax,%edx
    3db4:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    3db8:	48 8b 03             	mov    (%rbx),%rax
    3dbb:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3dc0:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    3dc5:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    3dc9:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3dce:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    3dd3:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    3dd7:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3ddb:	c4 e2 45 90 14 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm2
    3de1:	c5 fd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm0
    3de6:	c4 c1 6d db ca       	vpand  %ymm10,%ymm2,%ymm1
    3deb:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    3df0:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3df5:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    3dfa:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    3dff:	49 83 c3 18          	add    $0x18,%r11
    3e03:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    3e07:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    3e0b:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    3e12:	01 00 00 
    3e15:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    3e19:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    3e1f:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    3e24:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    3e29:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    3e2d:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    3e33:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    3e39:	48 39 ef             	cmp    %rbp,%rdi
    3e3c:	0f 84 ee e5 ff ff    	je     2430 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1740>
    3e42:	48 ff c5             	inc    %rbp
    3e45:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    3e4a:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    3e50:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
    3e54:	c4 c1 0d 72 d4 0f    	vpsrld $0xf,%ymm12,%ymm14
    3e5a:	49 8b 02             	mov    (%r10),%rax
    3e5d:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    3e61:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    3e66:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    3e6c:	41 8b 52 50          	mov    0x50(%r10),%edx
    3e70:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    3e76:	c4 e2 7d 00 84 24 e0 	vpshufb 0xe0(%rsp),%ymm0,%ymm0
    3e7d:	00 00 00 
    3e80:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    3e85:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    3e8a:	c4 c1 7d db ea       	vpand  %ymm10,%ymm0,%ymm5
    3e8f:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    3e96:	00 00 
    3e98:	c4 e2 65 90 14 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm2
    3e9e:	c4 c1 75 db da       	vpand  %ymm10,%ymm1,%ymm3
    3ea3:	49 8b 42 08          	mov    0x8(%r10),%rax
    3ea7:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    3eab:	c5 fe 7f 9c 24 60 01 	vmovdqu %ymm3,0x160(%rsp)
    3eb2:	00 00 
    3eb4:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    3eb9:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    3ebe:	c4 e2 75 90 2c 98    	vpgatherdd %ymm1,(%rax,%ymm3,4),%ymm5
    3ec4:	49 8b 42 10          	mov    0x10(%r10),%rax
    3ec8:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
    3ecf:	00 00 
    3ed1:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    3ed5:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    3eda:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    3edf:	c4 e2 75 90 1c b8    	vpgatherdd %ymm1,(%rax,%ymm7,4),%ymm3
    3ee5:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    3ee9:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    3eed:	49 8b 42 48          	mov    0x48(%r10),%rax
    3ef1:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    3ef6:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    3efb:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3eff:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    3f04:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    3f09:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    3f0e:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    3f13:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    3f18:	c4 62 3d 39 db       	vpminsd %ymm3,%ymm8,%ymm11
    3f1d:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    3f21:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3f25:	c5 7d fe ee          	vpaddd %ymm6,%ymm0,%ymm13
    3f29:	c5 7d 7f e0          	vmovdqa %ymm12,%ymm0
    3f2d:	c4 a2 7d 90 34 a8    	vpgatherdd %ymm0,(%rax,%ymm13,4),%ymm6
    3f33:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3f37:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3f3c:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    3f43:	00 00 
    3f45:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    3f4a:	c4 41 7d fe cd       	vpaddd %ymm13,%ymm0,%ymm9
    3f4f:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    3f53:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    3f58:	c4 a2 05 90 04 88    	vpgatherdd %ymm15,(%rax,%ymm9,4),%ymm0
    3f5e:	c5 7e 7f ac 24 80 01 	vmovdqu %ymm13,0x180(%rsp)
    3f65:	00 00 
    3f67:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
    3f6b:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    3f6f:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    3f75:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm0,%ymm0        # 3f7e <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x328e>
    3f7c:	ff ff 40 
    3f7f:	c4 c1 7d fe c5       	vpaddd %ymm13,%ymm0,%ymm0
    3f84:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    3f89:	c4 e2 15 90 24 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm4
    3f8f:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    3f93:	c5 7e 7f 8c 24 c0 01 	vmovdqu %ymm9,0x1c0(%rsp)
    3f9a:	00 00 
    3f9c:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    3fa1:	c4 c1 5d db e2       	vpand  %ymm10,%ymm4,%ymm4
    3fa6:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    3faa:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    3fb0:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm0,%ymm0        # 3fb9 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32c9>
    3fb7:	ff ff 80 
    3fba:	c5 b5 fa c0          	vpsubd %ymm0,%ymm9,%ymm0
    3fbe:	c5 2d db 8c 24 a0 01 	vpand  0x1a0(%rsp),%ymm10,%ymm9
    3fc5:	00 00 
    3fc7:	c4 62 15 90 04 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm8
    3fcd:	c4 41 4d fe eb       	vpaddd %ymm11,%ymm6,%ymm13
    3fd2:	c4 41 3d db c2       	vpand  %ymm10,%ymm8,%ymm8
    3fd7:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    3fdd:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    3fe2:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    3fe6:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    3fea:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    3fef:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    3ff4:	c4 c1 2d db d7       	vpand  %ymm15,%ymm10,%ymm2
    3ff9:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    3ffe:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    4003:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    4008:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
    400f:	00 00 
    4011:	49 8b 52 28          	mov    0x28(%r10),%rdx
    4015:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    401a:	c5 fe 6f ac 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm5
    4021:	00 00 
    4023:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    4028:	c5 7e 6f 8c 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm9
    402f:	00 00 
    4031:	c4 e2 25 90 34 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm6
    4037:	49 8b 52 20          	mov    0x20(%r10),%rdx
    403b:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    4040:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    4044:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    4049:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    404d:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    4054:	00 00 
    4056:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    405a:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    4061:	00 00 
    4063:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4068:	c4 62 25 90 04 92    	vpgatherdd %ymm11,(%rdx,%ymm2,4),%ymm8
    406e:	49 8b 52 18          	mov    0x18(%r10),%rdx
    4072:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    4077:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
    407c:	c4 e2 25 90 14 a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm2
    4082:	49 8b 52 40          	mov    0x40(%r10),%rdx
    4086:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    408b:	c4 42 6d 3d d8       	vpmaxsd %ymm8,%ymm2,%ymm11
    4090:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    4094:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    4099:	c4 c1 4d 66 db       	vpcmpgtd %ymm11,%ymm6,%ymm3
    409e:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    40a3:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    40a9:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm4,%ymm4        # 40b2 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33c2>
    40b0:	ff ff 30 
    40b3:	c4 e2 55 39 de       	vpminsd %ymm6,%ymm5,%ymm3
    40b8:	c5 dd fe a4 24 80 01 	vpaddd 0x180(%rsp),%ymm4,%ymm4
    40bf:	00 00 
    40c1:	c5 fe 7f 9c 24 20 02 	vmovdqu %ymm3,0x220(%rsp)
    40c8:	00 00 
    40ca:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    40ce:	c4 e2 15 90 1c a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm3
    40d4:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    40d9:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    40de:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    40e3:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    40e8:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    40ed:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    40f3:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm4,%ymm4        # 40fc <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x340c>
    40fa:	ff ff 50 
    40fd:	c4 c1 55 72 d7 08    	vpsrld $0x8,%ymm15,%ymm5
    4103:	c5 b5 fa e4          	vpsubd %ymm4,%ymm9,%ymm4
    4107:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    410c:	c4 62 15 90 0c a0    	vpgatherdd %ymm13,(%rax,%ymm4,4),%ymm9
    4112:	c5 fe 6f a4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm4
    4119:	00 00 
    411b:	c5 7e 7f bc 24 00 02 	vmovdqu %ymm15,0x200(%rsp)
    4122:	00 00 
    4124:	c5 25 fe bc 24 20 02 	vpaddd 0x220(%rsp),%ymm11,%ymm15
    412b:	00 00 
    412d:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    4133:	c5 95 72 d4 08       	vpsrld $0x8,%ymm4,%ymm13
    4138:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
    413d:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    4142:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
    4147:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    414b:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    414f:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    4154:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    4159:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    415e:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4163:	c4 c1 5d 72 f5 10    	vpslld $0x10,%ymm13,%ymm4
    4169:	c4 e2 55 40 ac 24 20 	vpmulld 0x220(%rsp),%ymm5,%ymm5
    4170:	02 00 00 
    4173:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    4178:	c5 dd fe a4 24 20 01 	vpaddd 0x120(%rsp),%ymm4,%ymm4
    417f:	00 00 
    4181:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    4185:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    4189:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    418d:	c5 fe 6f ac 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm5
    4194:	00 00 
    4196:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    419b:	c4 e2 05 90 34 aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm6
    41a1:	49 8b 52 38          	mov    0x38(%r10),%rdx
    41a5:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    41ac:	00 00 
    41ae:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    41b3:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    41ba:	00 00 
    41bc:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    41c1:	c4 62 05 90 04 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm8
    41c7:	49 8b 52 30          	mov    0x30(%r10),%rdx
    41cb:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    41d0:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
    41d5:	c4 e2 05 90 14 aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm2
    41db:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    41e0:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    41e5:	c4 42 6d 3d c8       	vpmaxsd %ymm8,%ymm2,%ymm9
    41ea:	c5 bd 66 ea          	vpcmpgtd %ymm2,%ymm8,%ymm5
    41ee:	c4 42 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm13
    41f3:	c4 c1 4d 66 d9       	vpcmpgtd %ymm9,%ymm6,%ymm3
    41f8:	c4 62 15 39 de       	vpminsd %ymm6,%ymm13,%ymm11
    41fd:	c4 62 35 3d ce       	vpmaxsd %ymm6,%ymm9,%ymm9
    4202:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
    4206:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    420c:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm5,%ymm5        # 4215 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3525>
    4213:	ff ff 30 
    4216:	c5 d5 fe ac 24 80 01 	vpaddd 0x180(%rsp),%ymm5,%ymm5
    421d:	00 00 
    421f:	c4 e2 05 90 1c a8    	vpgatherdd %ymm15,(%rax,%ymm5,4),%ymm3
    4225:	c4 c1 6d 66 e8       	vpcmpgtd %ymm8,%ymm2,%ymm5
    422a:	c4 41 7d 6f fc       	vmovdqa %ymm12,%ymm15
    422f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4234:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    4239:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    423e:	c4 e3 75 4c cf 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm1
    4244:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    424b:	00 00 
    424d:	c5 fe 6f ac 24 00 02 	vmovdqu 0x200(%rsp),%ymm5
    4254:	00 00 
    4256:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm1,%ymm1        # 425f <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x356f>
    425d:	ff ff d0 
    4260:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
    4264:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    426b:	00 00 
    426d:	c4 62 05 90 2c 88    	vpgatherdd %ymm15,(%rax,%ymm1,4),%ymm13
    4273:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4278:	c4 41 35 fe fb       	vpaddd %ymm11,%ymm9,%ymm15
    427d:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    4282:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    4288:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
    428d:	c4 c1 45 db fa       	vpand  %ymm10,%ymm7,%ymm7
    4292:	c4 41 15 db ea       	vpand  %ymm10,%ymm13,%ymm13
    4297:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    429c:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    42a0:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    42a5:	c5 d5 72 f7 10       	vpslld $0x10,%ymm7,%ymm5
    42aa:	c5 95 fa f3          	vpsubd %ymm3,%ymm13,%ymm6
    42ae:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    42b2:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    42b7:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    42be:	00 00 
    42c0:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    42c5:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    42ca:	c5 d5 fe ac 24 20 01 	vpaddd 0x120(%rsp),%ymm5,%ymm5
    42d1:	00 00 
    42d3:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
    42d9:	c5 7e 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm9
    42df:	c5 b5 66 f8          	vpcmpgtd %ymm0,%ymm9,%ymm7
    42e3:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    42e7:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
    42eb:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    42ef:	c5 dd fa c8          	vpsubd %ymm0,%ymm4,%ymm1
    42f3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    42f8:	c5 a5 66 d9          	vpcmpgtd %ymm1,%ymm11,%ymm3
    42fc:	c5 d5 fa f0          	vpsubd %ymm0,%ymm5,%ymm6
    4300:	c5 95 66 d6          	vpcmpgtd %ymm6,%ymm13,%ymm2
    4304:	c5 e5 eb d2          	vpor   %ymm2,%ymm3,%ymm2
    4308:	c5 cd 66 9c 24 c0 00 	vpcmpgtd 0xc0(%rsp),%ymm6,%ymm3
    430f:	00 00 
    4311:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    4315:	c5 fd 66 5c 24 40    	vpcmpgtd 0x40(%rsp),%ymm0,%ymm3
    431b:	c5 c5 eb db          	vpor   %ymm3,%ymm7,%ymm3
    431f:	c5 f5 66 bc 24 80 00 	vpcmpgtd 0x80(%rsp),%ymm1,%ymm7
    4326:	00 00 
    4328:	c5 e5 eb df          	vpor   %ymm7,%ymm3,%ymm3
    432c:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
    4330:	c5 fd d7 c2          	vpmovmskb %ymm2,%eax
    4334:	85 c0                	test   %eax,%eax
    4336:	0f 84 5c fa ff ff    	je     3d98 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x30a8>
    433c:	49 8b 42 60          	mov    0x60(%r10),%rax
    4340:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    4344:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    434b:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    4352:	c4 e2 45 90 14 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm2
    4358:	49 8b 42 68          	mov    0x68(%r10),%rax
    435c:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    4360:	c5 79 6e d9          	vmovd  %ecx,%xmm11
    4364:	c5 f9 6e da          	vmovd  %edx,%xmm3
    4368:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    436d:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4371:	c4 e2 45 90 34 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm6
    4377:	49 8b 42 70          	mov    0x70(%r10),%rax
    437b:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    437f:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    4384:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    4389:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    438d:	c4 e2 5d 90 0c a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm1
    4393:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    4398:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    439f:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    43a4:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
    43a9:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    43ae:	c5 d5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm5
    43b3:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    43b7:	c4 c1 4d db e6       	vpand  %ymm14,%ymm6,%ymm4
    43bc:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    43c0:	c4 c1 75 db ee       	vpand  %ymm14,%ymm1,%ymm5
    43c5:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    43c9:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    43ce:	c4 62 45 90 3c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm15
    43d4:	c4 62 6d 39 cc       	vpminsd %ymm4,%ymm2,%ymm9
    43d9:	c5 f5 fe f8          	vpaddd %ymm0,%ymm1,%ymm7
    43dd:	c5 7d 7f e1          	vmovdqa %ymm12,%ymm1
    43e1:	c5 6d fe ec          	vpaddd %ymm4,%ymm2,%ymm13
    43e5:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    43ec:	00 00 
    43ee:	c4 62 35 39 c5       	vpminsd %ymm5,%ymm9,%ymm8
    43f3:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    43f7:	c4 e2 75 90 34 b8    	vpgatherdd %ymm1,(%rax,%ymm7,4),%ymm6
    43fd:	c5 dd 66 ca          	vpcmpgtd %ymm2,%ymm4,%ymm1
    4401:	c4 e2 6d 3d fc       	vpmaxsd %ymm4,%ymm2,%ymm7
    4406:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
    440d:	00 00 
    440f:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    4413:	c5 ed 66 d4          	vpcmpgtd %ymm4,%ymm2,%ymm2
    4417:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    441c:	c4 c3 65 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm3,%ymm1
    4422:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 442b <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x373b>
    4429:	ff ff 60 
    442c:	c4 c1 45 fe f0       	vpaddd %ymm8,%ymm7,%ymm6
    4431:	c4 c3 65 4c db 20    	vpblendvb %ymm2,%ymm11,%ymm3,%ymm3
    4437:	c5 7e 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm11
    443e:	00 00 
    4440:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    4444:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    444b:	00 00 
    444d:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm3,%ymm3        # 4456 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3766>
    4454:	ff ff 90 
    4457:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    445b:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    4460:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    4465:	c4 c1 2d db e3       	vpand  %ymm11,%ymm10,%ymm4
    446a:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    446e:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    4472:	c4 e2 15 90 0c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm1
    4478:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    447f:	00 00 
    4481:	c4 e2 55 90 04 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm0
    4487:	c4 41 75 db ca       	vpand  %ymm10,%ymm1,%ymm9
    448c:	c4 c1 2d db df       	vpand  %ymm15,%ymm10,%ymm3
    4491:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    4498:	c4 c1 7d db d2       	vpand  %ymm10,%ymm0,%ymm2
    449d:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    44a2:	c5 b5 fa db          	vpsubd %ymm3,%ymm9,%ymm3
    44a6:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    44aa:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
    44af:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    44b4:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    44b9:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
    44be:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    44c3:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    44c8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    44cd:	c4 41 35 db ca       	vpand  %ymm10,%ymm9,%ymm9
    44d2:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    44d7:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    44db:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    44df:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    44e4:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    44e8:	c4 c1 6d 72 d3 08    	vpsrld $0x8,%ymm11,%ymm2
    44ee:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    44f3:	c4 c1 55 72 d7 08    	vpsrld $0x8,%ymm15,%ymm5
    44f9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    44fe:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
    4503:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    4508:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    450c:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    4511:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    4516:	c5 a5 72 f5 10       	vpslld $0x10,%ymm5,%ymm11
    451b:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    451f:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    4524:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    4529:	c4 41 25 fe dd       	vpaddd %ymm13,%ymm11,%ymm11
    452e:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    4533:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    4538:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
    453d:	c5 7e 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm11
    4544:	00 00 
    4546:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    454a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    454e:	c4 c1 55 72 d3 10    	vpsrld $0x10,%ymm11,%ymm5
    4554:	c4 c1 65 72 d7 10    	vpsrld $0x10,%ymm15,%ymm3
    455a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    455f:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    4564:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    4569:	c5 d5 fa e8          	vpsubd %ymm0,%ymm5,%ymm5
    456d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    4571:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
    4576:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    457b:	c5 f5 fa db          	vpsubd %ymm3,%ymm1,%ymm3
    457f:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    4584:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
    4589:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
    458e:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    4593:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    4597:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    459b:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    45a0:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    45a4:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    45aa:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    45b1:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    45b5:	c4 e2 5d 90 2c 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm5
    45bb:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    45c2:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    45c9:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    45cd:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    45d4:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    45d9:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
    45de:	c4 e2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm6
    45e4:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    45e9:	c5 79 6e d9          	vmovd  %ecx,%xmm11
    45ed:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    45f4:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    45f8:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    45fd:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4601:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    4606:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    460b:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    4610:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    4615:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    461a:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    461f:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
    4624:	c4 62 65 39 ed       	vpminsd %ymm5,%ymm3,%ymm13
    4629:	c5 65 fe f5          	vpaddd %ymm5,%ymm3,%ymm14
    462d:	c4 62 15 39 ce       	vpminsd %ymm6,%ymm13,%ymm9
    4632:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
    4636:	49 8d 8a 20 01 00 00 	lea    0x120(%r10),%rcx
    463d:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4641:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4645:	48 8d 56 60          	lea    0x60(%rsi),%rdx
    4649:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    464d:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    4651:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4656:	c4 e2 6d 90 3c 88    	vpgatherdd %ymm2,(%rax,%ymm1,4),%ymm7
    465c:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
    4660:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
    4664:	c5 fd fe f9          	vpaddd %ymm1,%ymm0,%ymm7
    4668:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    466f:	00 00 
    4671:	c4 e2 6d 90 04 b8    	vpgatherdd %ymm2,(%rax,%ymm7,4),%ymm0
    4677:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    467b:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4680:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    4684:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4689:	c5 fe 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm5
    4690:	00 00 
    4692:	c4 c3 5d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm4,%ymm2
    4698:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 46a1 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x39b1>
    469f:	ff ff 70 
    46a2:	c4 c3 5d 4c e3 30    	vpblendvb %ymm3,%ymm11,%ymm4,%ymm4
    46a8:	c4 c1 3d fe f9       	vpaddd %ymm9,%ymm8,%ymm7
    46ad:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm4,%ymm4        # 46b6 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x39c6>
    46b4:	ff ff d0 
    46b7:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    46bb:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    46bf:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    46c4:	c5 d5 fa e4          	vpsubd %ymm4,%ymm5,%ymm4
    46c8:	c4 41 7d 6f f4       	vmovdqa %ymm12,%ymm14
    46cd:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    46d1:	c4 e2 0d 90 14 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm2
    46d7:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    46dc:	c4 e2 55 90 0c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm1
    46e2:	c4 41 6d db da       	vpand  %ymm10,%ymm2,%ymm11
    46e7:	c4 c1 2d db ef       	vpand  %ymm15,%ymm10,%ymm5
    46ec:	c5 7e 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm15
    46f3:	00 00 
    46f5:	c4 c1 75 db da       	vpand  %ymm10,%ymm1,%ymm3
    46fa:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    46ff:	c4 c1 7d db e2       	vpand  %ymm10,%ymm0,%ymm4
    4704:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    4708:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    470c:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    4711:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    4716:	c4 c1 4d fe f7       	vpaddd %ymm15,%ymm6,%ymm6
    471b:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    4720:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    4725:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
    472a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    472f:	c4 41 25 db da       	vpand  %ymm10,%ymm11,%ymm11
    4734:	c4 c1 6d db d2       	vpand  %ymm10,%ymm2,%ymm2
    4739:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    473d:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    4741:	c4 c1 4d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm6
    4747:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    474b:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    4750:	c4 c1 4d db f2       	vpand  %ymm10,%ymm6,%ymm6
    4755:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    475a:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    475f:	c4 c1 55 db ea       	vpand  %ymm10,%ymm5,%ymm5
    4764:	c4 c1 65 db da       	vpand  %ymm10,%ymm3,%ymm3
    4769:	c5 a5 fa f6          	vpsubd %ymm6,%ymm11,%ymm6
    476d:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    4772:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    4777:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    477c:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    4780:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    4785:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    478a:	c4 c1 75 db ca       	vpand  %ymm10,%ymm1,%ymm1
    478f:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    4794:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4799:	c4 c1 7d db c2       	vpand  %ymm10,%ymm0,%ymm0
    479e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    47a3:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    47a7:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    47ab:	c5 fd 7f 66 60       	vmovdqa %ymm4,0x60(%rsi)
    47b0:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    47b5:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    47ba:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    47be:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    47c2:	c4 c1 05 72 d6 10    	vpsrld $0x10,%ymm14,%ymm15
    47c8:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    47cd:	c4 41 05 db fa       	vpand  %ymm10,%ymm15,%ymm15
    47d2:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    47d6:	c4 c1 55 72 f7 10    	vpslld $0x10,%ymm15,%ymm5
    47dc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    47e1:	c4 41 6d fa ff       	vpsubd %ymm15,%ymm2,%ymm15
    47e6:	c4 42 05 40 f8       	vpmulld %ymm8,%ymm15,%ymm15
    47eb:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    47ef:	c5 fd 7f 9e 80 00 00 	vmovdqa %ymm3,0x80(%rsi)
    47f6:	00 
    47f7:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    47fb:	c4 c1 7d fe c7       	vpaddd %ymm15,%ymm0,%ymm0
    4800:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4804:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4809:	c5 fd 7f 86 a0 00 00 	vmovdqa %ymm0,0xa0(%rsi)
    4810:	00 
    4811:	c5 f8 77             	vzeroupper
    4814:	e8 e7 b7 ff ff       	call   0 <void jshc_delta16_cache::(anonymous namespace)::transform<true, false>(jshc_delta16_cache::View const&, jshc_delta16_cache::(anonymous namespace)::Rgb&)>
    4819:	c5 fd 6f 86 80 00 00 	vmovdqa 0x80(%rsi),%ymm0
    4820:	00 
    4821:	c5 fd 6f 96 a0 00 00 	vmovdqa 0xa0(%rsi),%ymm2
    4828:	00 
    4829:	c5 fd 6f 4e 60       	vmovdqa 0x60(%rsi),%ymm1
    482e:	c5 7d 6f 15 40 00 00 	vmovdqa 0x40(%rip),%ymm10        # 4876 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x36>
    4835:	00 
    4836:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    483b:	e9 b5 f5 ff ff       	jmp    3df5 <jshc_delta16_cache::avx2_chain_cached(jshc_delta16_cache::View const*, jshc_delta16_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3105>

0000000000004840 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    4840:	57                   	push   %rdi
    4841:	56                   	push   %rsi
    4842:	53                   	push   %rbx
    4843:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
    484a:	c5 f8 29 b4 24 20 02 	vmovaps %xmm6,0x220(%rsp)
    4851:	00 00 
    4853:	c5 f8 29 bc 24 30 02 	vmovaps %xmm7,0x230(%rsp)
    485a:	00 00 
    485c:	c5 78 29 84 24 40 02 	vmovaps %xmm8,0x240(%rsp)
    4863:	00 00 
    4865:	c5 78 29 8c 24 50 02 	vmovaps %xmm9,0x250(%rsp)
    486c:	00 00 
    486e:	c5 78 29 94 24 60 02 	vmovaps %xmm10,0x260(%rsp)
    4875:	00 00 
    4877:	c5 78 29 9c 24 70 02 	vmovaps %xmm11,0x270(%rsp)
    487e:	00 00 
    4880:	c5 78 29 a4 24 80 02 	vmovaps %xmm12,0x280(%rsp)
    4887:	00 00 
    4889:	c5 78 29 ac 24 90 02 	vmovaps %xmm13,0x290(%rsp)
    4890:	00 00 
    4892:	c5 78 29 b4 24 a0 02 	vmovaps %xmm14,0x2a0(%rsp)
    4899:	00 00 
    489b:	c5 78 29 bc 24 b0 02 	vmovaps %xmm15,0x2b0(%rsp)
    48a2:	00 00 
    48a4:	49 89 d3             	mov    %rdx,%r11
    48a7:	48 83 fa 04          	cmp    $0x4,%rdx
    48ab:	0f 84 f8 08 00 00    	je     51a9 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x969>
    48b1:	4d 85 c9             	test   %r9,%r9
    48b4:	0f 84 7a 08 00 00    	je     5134 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    48ba:	49 ff c9             	dec    %r9
    48bd:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 4925 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe5>
    48c4:	00 
    48c5:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
    48c9:	49 c1 e9 03          	shr    $0x3,%r9
    48cd:	49 c1 e2 05          	shl    $0x5,%r10
    48d1:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    48d5:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    48dc:	00 00 
    48de:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 4966 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x126>
    48e5:	00 
    48e6:	49 01 ca             	add    %rcx,%r10
    48e9:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    48ee:	b8 00 80 00 00       	mov    $0x8000,%eax
    48f3:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    48f7:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    48fe:	00 00 
    4900:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    4904:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4909:	c5 95 72 d6 18       	vpsrld $0x18,%ymm6,%ymm13
    490e:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    4913:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4918:	c4 c1 7a 6f 10       	vmovdqu (%r8),%xmm2
    491d:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    4923:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
    4929:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
    492f:	c4 e2 6d 00 94 24 e0 	vpshufb 0x1e0(%rsp),%ymm2,%ymm2
    4936:	01 00 00 
    4939:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
    493e:	c4 c1 6d db c5       	vpand  %ymm13,%ymm2,%ymm0
    4943:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    4948:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    494d:	4d 85 db             	test   %r11,%r11
    4950:	0f 84 4a 08 00 00    	je     51a0 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x960>
    4956:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    495d:	00 00 
    495f:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4963:	48 89 c8             	mov    %rcx,%rax
    4966:	c5 fd 6f cc          	vmovdqa %ymm4,%ymm1
    496a:	e9 22 02 00 00       	jmp    4b91 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    496f:	90                   	nop
    4970:	c4 c1 5d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm4
    4976:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
    497b:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    497f:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
    4983:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    4987:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    498c:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
    4992:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    4997:	c5 dd fe ef          	vpaddd %ymm7,%ymm4,%ymm5
    499b:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    49a2:	00 00 
    49a4:	c4 c1 55 72 e1 10    	vpsrad $0x10,%ymm9,%ymm5
    49aa:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    49b0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    49b4:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
    49ba:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
    49c0:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    49c4:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
    49c8:	c5 b5 fe db          	vpaddd %ymm3,%ymm9,%ymm3
    49cc:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    49d0:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
    49d5:	c5 75 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm8
    49d9:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    49e0:	00 00 
    49e2:	c4 c1 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm2
    49e7:	c4 62 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm10
    49ec:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
    49f1:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
    49f5:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
    49fa:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    49ff:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
    4a03:	c4 63 1d 4c 44 24 60 	vpblendvb %ymm8,0x60(%rsp),%ymm12,%ymm8
    4a0a:	80 
    4a0b:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    4a11:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm8,%ymm8        # 4a1a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1da>
    4a18:	ff ff 20 
    4a1b:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
    4a21:	c4 e3 1d 4c 4c 24 60 	vpblendvb %ymm1,0x60(%rsp),%ymm12,%ymm1
    4a28:	10 
    4a29:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm1,%ymm1        # 4a32 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f2>
    4a30:	ff ff a0 
    4a33:	c4 a2 0d 90 14 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm2
    4a39:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    4a3d:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4a41:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
    4a47:	c5 fe 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm1
    4a4e:	00 00 
    4a50:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    4a55:	c4 62 5d 3d c7       	vpmaxsd %ymm7,%ymm4,%ymm8
    4a5a:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    4a5f:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4a64:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4a68:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    4a6d:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    4a72:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    4a76:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
    4a7a:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
    4a81:	00 00 
    4a83:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
    4a87:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    4a8c:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
    4a92:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4a97:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    4a9c:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
    4aa1:	c4 62 35 39 d5       	vpminsd %ymm5,%ymm9,%ymm10
    4aa6:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    4aaa:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    4aae:	c5 c5 66 dc          	vpcmpgtd %ymm4,%ymm7,%ymm3
    4ab2:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    4ab9:	00 00 
    4abb:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
    4abf:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    4ac6:	00 00 
    4ac8:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4acc:	c4 c1 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm2
    4ad1:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
    4ad7:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    4add:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4ae1:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
    4ae6:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 4aef <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2af>
    4aed:	ff ff 90 
    4af0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4af5:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    4afa:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm3        # 4b03 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2c3>
    4b01:	ff ff 20 
    4b04:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4b08:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
    4b0e:	c4 e2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm2
    4b14:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    4b1a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4b1f:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    4b23:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4b28:	c4 e2 1d 90 1c a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm3
    4b2e:	c4 c1 45 fa e2       	vpsubd %ymm10,%ymm7,%ymm4
    4b33:	c5 fe 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm7
    4b3a:	00 00 
    4b3c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4b41:	c5 dd fe ed          	vpaddd %ymm5,%ymm4,%ymm5
    4b45:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    4b4a:	c5 e5 fa e2          	vpsubd %ymm2,%ymm3,%ymm4
    4b4e:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
    4b52:	c4 e2 55 40 e4       	vpmulld %ymm4,%ymm5,%ymm4
    4b57:	c5 ed fa 94 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm2
    4b5e:	00 00 
    4b60:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    4b65:	48 83 c0 60          	add    $0x60,%rax
    4b69:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    4b6e:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    4b72:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
    4b79:	00 00 
    4b7b:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    4b7f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4b84:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4b88:	49 39 c2             	cmp    %rax,%r10
    4b8b:	0f 84 46 05 00 00    	je     50d7 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x897>
    4b91:	8b 58 54             	mov    0x54(%rax),%ebx
    4b94:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4b98:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    4b9f:	00 00 
    4ba1:	c5 fd 6f c6          	vmovdqa %ymm6,%ymm0
    4ba5:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
    4bac:	00 00 
    4bae:	8b 70 50             	mov    0x50(%rax),%esi
    4bb1:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4bb5:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    4bb9:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
    4bbd:	c4 e2 7d 90 14 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm2
    4bc3:	48 8b 10             	mov    (%rax),%rdx
    4bc6:	48 8b 78 10          	mov    0x10(%rax),%rdi
    4bca:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    4bcf:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4bd6:	00 00 
    4bd8:	c5 79 6e e6          	vmovd  %esi,%xmm12
    4bdc:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    4be1:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    4be7:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    4bec:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    4bf1:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    4bf5:	c4 e2 65 90 04 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm0
    4bfb:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4c00:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
    4c07:	00 00 
    4c09:	48 8b 50 48          	mov    0x48(%rax),%rdx
    4c0d:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    4c12:	c4 a2 2d 90 1c 9f    	vpgatherdd %ymm10,(%rdi,%ymm11,4),%ymm3
    4c18:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 4c40 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x400>
    4c1f:	00 
    4c20:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    4c25:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
    4c2a:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 4c52 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x412>
    4c31:	00 
    4c32:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4c5a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x41a>
    4c39:	00 
    4c3a:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
    4c3e:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
    4c42:	c4 62 6d 39 c0       	vpminsd %ymm0,%ymm2,%ymm8
    4c47:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4c4b:	c5 f5 fe e5          	vpaddd %ymm5,%ymm1,%ymm4
    4c4f:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4c53:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    4c59:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    4c5f:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
    4c64:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4c69:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    4c70:	00 00 
    4c72:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4c77:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4c7c:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
    4c83:	00 00 
    4c85:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4c8a:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    4c8f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4c94:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    4c9b:	00 00 
    4c9d:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4ca2:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4ca7:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
    4cac:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    4cb3:	00 00 
    4cb5:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    4cb9:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4cbe:	c5 75 fe dc          	vpaddd %ymm4,%ymm1,%ymm11
    4cc2:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
    4cc6:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4cca:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
    4cd0:	c4 62 3d 39 c3       	vpminsd %ymm3,%ymm8,%ymm8
    4cd5:	c4 22 75 90 14 9a    	vpgatherdd %ymm1,(%rdx,%ymm11,4),%ymm10
    4cdb:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
    4cdf:	c4 e3 1d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm12,%ymm1
    4ce5:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 4cee <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ae>
    4cec:	ff ff 40 
    4cef:	c5 ed 66 e0          	vpcmpgtd %ymm0,%ymm2,%ymm4
    4cf3:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    4cf7:	c4 41 2d db dd       	vpand  %ymm13,%ymm10,%ymm11
    4cfc:	c4 e2 35 90 3c 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm7
    4d02:	c5 0d fe 34 24       	vpaddd (%rsp),%ymm14,%ymm14
    4d07:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    4d0b:	c5 95 db cf          	vpand  %ymm7,%ymm13,%ymm1
    4d0f:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    4d16:	00 00 
    4d18:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    4d1e:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    4d22:	c4 c2 25 40 f8       	vpmulld %ymm8,%ymm11,%ymm7
    4d27:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    4d2b:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
    4d32:	00 00 
    4d34:	c4 e2 6d 3d f8       	vpmaxsd %ymm0,%ymm2,%ymm7
    4d39:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
    4d3d:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    4d42:	c5 3d fe ff          	vpaddd %ymm7,%ymm8,%ymm15
    4d46:	c4 41 65 fa ff       	vpsubd %ymm15,%ymm3,%ymm15
    4d4b:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 4d54 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
    4d52:	ff ff 90 
    4d55:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    4d5b:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    4d61:	c5 6d fe d8          	vpaddd %ymm0,%ymm2,%ymm11
    4d65:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    4d6a:	c4 41 05 fe db       	vpaddd %ymm11,%ymm15,%ymm11
    4d6f:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    4d73:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    4d77:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4d7c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    4d81:	c5 dd fe a4 24 80 00 	vpaddd 0x80(%rsp),%ymm4,%ymm4
    4d88:	00 00 
    4d8a:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4d8f:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4d93:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
    4d98:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
    4d9e:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    4da4:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
    4dab:	00 00 
    4dad:	c4 41 75 db fd       	vpand  %ymm13,%ymm1,%ymm15
    4db2:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    4db9:	00 00 
    4dbb:	c4 c1 2d db ed       	vpand  %ymm13,%ymm10,%ymm5
    4dc0:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
    4dc7:	00 00 
    4dc9:	0f 85 49 02 00 00    	jne    5018 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d8>
    4dcf:	48 8b 58 28          	mov    0x28(%rax),%rbx
    4dd3:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
    4dda:	00 00 
    4ddc:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4de0:	48 8b 78 18          	mov    0x18(%rax),%rdi
    4de4:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
    4de8:	c4 62 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm9
    4dee:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    4df5:	00 00 
    4df7:	48 8b 58 20          	mov    0x20(%rax),%rbx
    4dfb:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4dff:	c4 e2 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm1
    4e05:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
    4e0c:	00 00 
    4e0e:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4e12:	c4 62 45 90 04 af    	vpgatherdd %ymm7,(%rdi,%ymm5,4),%ymm8
    4e18:	0f 85 52 fb ff ff    	jne    4970 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
    4e1e:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # 4e46 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x606>
    4e25:	00 
    4e26:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 4e4e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x60e>
    4e2d:	00 
    4e2e:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4e32:	c5 b5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm9,%ymm3        # 4e5a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x61a>
    4e39:	00 
    4e3a:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
    4e40:	c4 e2 3d 3d e9       	vpmaxsd %ymm1,%ymm8,%ymm5
    4e45:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
    4e4a:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
    4e50:	c4 e2 3d 39 e1       	vpminsd %ymm1,%ymm8,%ymm4
    4e55:	c5 e5 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm0
    4e59:	c4 e2 5d 39 fb       	vpminsd %ymm3,%ymm4,%ymm7
    4e5e:	c4 e2 55 3d eb       	vpmaxsd %ymm3,%ymm5,%ymm5
    4e63:	48 8b 58 40          	mov    0x40(%rax),%rbx
    4e67:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
    4e6b:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4e71:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 4e7a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
    4e78:	ff ff 00 
    4e7b:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    4e80:	c4 e2 0d 90 04 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm0
    4e86:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
    4e8a:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4e8e:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    4e92:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    4e97:	c5 d5 fe cf          	vpaddd %ymm7,%ymm5,%ymm1
    4e9b:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    4e9f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    4ea4:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4ea8:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4eae:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    4eb2:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm2,%ymm2        # 4ebb <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x67b>
    4eb9:	ff ff 40 
    4ebc:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    4ec2:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    4ec6:	c4 e2 0d 90 24 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm4
    4ecc:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4ed0:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    4ed5:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    4eda:	c5 05 fa fc          	vpsubd %ymm4,%ymm15,%ymm15
    4ede:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
    4ee2:	c4 62 05 40 ff       	vpmulld %ymm7,%ymm15,%ymm15
    4ee7:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    4eee:	00 00 
    4ef0:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    4ef5:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
    4efc:	00 00 
    4efe:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    4f05:	00 00 
    4f07:	c4 e2 65 90 24 bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm4
    4f0d:	48 8b 58 38          	mov    0x38(%rax),%rbx
    4f11:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
    4f18:	00 00 
    4f1a:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4f1e:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    4f23:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 4f4b <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70b>
    4f2a:	00 
    4f2b:	c4 e2 65 90 2c bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm5
    4f31:	48 8b 58 30          	mov    0x30(%rax),%rbx
    4f35:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4f39:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 4f61 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x721>
    4f40:	00 
    4f41:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    4f46:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    4f4b:	c4 e2 45 90 1c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm3
    4f51:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4f79 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x739>
    4f58:	00 
    4f59:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
    4f60:	00 00 
    4f62:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    4f67:	c5 d5 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm7
    4f6b:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
    4f70:	c4 c1 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm2
    4f75:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
    4f7a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4f7e:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
    4f83:	c4 c3 1d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm12,%ymm7
    4f89:	c4 62 35 39 d4       	vpminsd %ymm4,%ymm9,%ymm10
    4f8e:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4f92:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm7,%ymm7        # 4f9b <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x75b>
    4f99:	ff ff 20 
    4f9c:	c5 35 66 cc          	vpcmpgtd %ymm4,%ymm9,%ymm9
    4fa0:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
    4fa5:	c4 e2 0d 90 14 ba    	vpgatherdd %ymm14,(%rdx,%ymm7,4),%ymm2
    4fab:	c5 e5 66 fd          	vpcmpgtd %ymm5,%ymm3,%ymm7
    4faf:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4fb3:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4fb8:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4fbd:	c4 c3 1d 4c ff 70    	vpblendvb %ymm7,%ymm15,%ymm12,%ymm7
    4fc3:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # 4fcc <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x78c>
    4fca:	ff ff 90 
    4fcd:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    4fd3:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    4fd7:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4fdb:	c4 62 1d 90 0c ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm9
    4fe1:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4fe6:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    4fec:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    4ff0:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    4ff5:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    4ff9:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
    4ffd:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    5002:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    5009:	00 00 
    500b:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    5010:	e9 42 fb ff ff       	jmp    4b57 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x317>
    5015:	0f 1f 00             	nopl   (%rax)
    5018:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    501f:	00 00 
    5021:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
    5027:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    502d:	48 83 c0 60          	add    $0x60,%rax
    5031:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5036:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    503b:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
    5040:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5045:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    504a:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    504f:	c5 85 fa c2          	vpsubd %ymm2,%ymm15,%ymm0
    5053:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    5057:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    505c:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    5061:	c5 f5 fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm1,%ymm1
    5068:	00 00 
    506a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    506f:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5073:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    507a:	00 00 
    507c:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    5080:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    5085:	c5 35 fa 8c 24 40 01 	vpsubd 0x140(%rsp),%ymm9,%ymm9
    508c:	00 00 
    508e:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    5093:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
    509a:	00 00 
    509c:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    50a1:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
    50a6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    50aa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    50af:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    50b3:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    50b7:	c5 35 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm9,%ymm9
    50be:	00 00 
    50c0:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    50c5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    50ca:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    50ce:	49 39 c2             	cmp    %rax,%r10
    50d1:	0f 85 ba fa ff ff    	jne    4b91 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    50d7:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
    50db:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
    50e2:	00 00 
    50e4:	c5 dd 72 f7 08       	vpslld $0x8,%ymm7,%ymm4
    50e9:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    50ee:	49 83 c0 18          	add    $0x18,%r8
    50f2:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
    50f6:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    50fa:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    5101:	02 00 00 
    5104:	c5 f9 6f e0          	vmovdqa %xmm0,%xmm4
    5108:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    510e:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
    5113:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    5118:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
    511c:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    5122:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    5128:	4d 39 c1             	cmp    %r8,%r9
    512b:	0f 85 e7 f7 ff ff    	jne    4918 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
    5131:	c5 f8 77             	vzeroupper
    5134:	c5 f8 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm6
    513b:	00 00 
    513d:	c5 f8 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm7
    5144:	00 00 
    5146:	c5 78 28 84 24 40 02 	vmovaps 0x240(%rsp),%xmm8
    514d:	00 00 
    514f:	c5 78 28 8c 24 50 02 	vmovaps 0x250(%rsp),%xmm9
    5156:	00 00 
    5158:	c5 78 28 94 24 60 02 	vmovaps 0x260(%rsp),%xmm10
    515f:	00 00 
    5161:	c5 78 28 9c 24 70 02 	vmovaps 0x270(%rsp),%xmm11
    5168:	00 00 
    516a:	c5 78 28 a4 24 80 02 	vmovaps 0x280(%rsp),%xmm12
    5171:	00 00 
    5173:	c5 78 28 ac 24 90 02 	vmovaps 0x290(%rsp),%xmm13
    517a:	00 00 
    517c:	c5 78 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm14
    5183:	00 00 
    5185:	c5 78 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm15
    518c:	00 00 
    518e:	48 81 c4 c0 02 00 00 	add    $0x2c0,%rsp
    5195:	5b                   	pop    %rbx
    5196:	5e                   	pop    %rsi
    5197:	5f                   	pop    %rdi
    5198:	c3                   	ret
    5199:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51a0:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
    51a4:	e9 3b ff ff ff       	jmp    50e4 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8a4>
    51a9:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    51ad:	0f 85 fe f6 ff ff    	jne    48b1 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    51b3:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    51ba:	0f 84 f1 f6 ff ff    	je     48b1 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    51c0:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    51c7:	0f 84 e4 f6 ff ff    	je     48b1 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    51cd:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    51d4:	0f 84 d7 f6 ff ff    	je     48b1 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    51da:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    51de:	0f 85 ff 0b 00 00    	jne    5de3 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15a3>
    51e4:	4d 85 c9             	test   %r9,%r9
    51e7:	0f 84 47 ff ff ff    	je     5134 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    51ed:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 5255 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa15>
    51f4:	00 
    51f5:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    51f9:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    51fe:	48 c1 e8 03          	shr    $0x3,%rax
    5202:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
    5208:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    520c:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    5213:	00 00 
    5215:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 529d <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa5d>
    521c:	00 
    521d:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    5222:	b8 00 80 00 00       	mov    $0x8000,%eax
    5227:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    522e:	00 00 
    5230:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    5234:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5239:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    523e:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    5243:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    5249:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    524d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5252:	48 8b 01             	mov    (%rcx),%rax
    5255:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    5259:	49 83 c0 18          	add    $0x18,%r8
    525d:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    5263:	8b 51 50             	mov    0x50(%rcx),%edx
    5266:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    526c:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    5271:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    5278:	01 00 00 
    527b:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    527f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    5284:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    5289:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    528e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    5293:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    5299:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
    529e:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    52a3:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    52a8:	c4 e2 65 90 04 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm0
    52ae:	48 8b 41 08          	mov    0x8(%rcx),%rax
    52b2:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    52b8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    52bc:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
    52c2:	48 8b 41 10          	mov    0x10(%rcx),%rax
    52c6:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    52ca:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    52cf:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 52f7 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xab7>
    52d6:	00 
    52d7:	c4 a2 65 90 24 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm4
    52dd:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    52e2:	48 8b 41 48          	mov    0x48(%rcx),%rax
    52e6:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 530e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xace>
    52ed:	00 
    52ee:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    52f3:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    52f8:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    52fd:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 5325 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xae5>
    5304:	00 
    5305:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    530a:	c4 62 3d 3d f4       	vpmaxsd %ymm4,%ymm8,%ymm14
    530f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5313:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5317:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    531b:	c4 62 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm12
    5321:	c5 f9 6e da          	vmovd  %edx,%xmm3
    5325:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    532a:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    532e:	c4 e2 2d 90 2c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm5
    5334:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    5339:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    5340:	00 00 
    5342:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    5347:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    534e:	00 00 
    5350:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    5354:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    5359:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    535d:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    5363:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm5,%ymm5        # 536c <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb2c>
    536a:	ff ff a0 
    536d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5372:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    5376:	c4 62 2d 90 34 a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm14
    537c:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    5380:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5384:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    538a:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm5,%ymm5        # 5393 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb53>
    5391:	ff ff 80 
    5394:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5399:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    539d:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    53a3:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    53a9:	c4 c1 0d db ed       	vpand  %ymm13,%ymm14,%ymm5
    53ae:	c5 35 fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm14
    53b5:	00 00 
    53b7:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    53bc:	c5 15 db 64 24 60    	vpand  0x60(%rsp),%ymm13,%ymm12
    53c2:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    53c6:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    53cb:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    53d1:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    53d5:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    53d9:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
    53df:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    53e4:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    53e9:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    53ee:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    53f5:	00 00 00 
    53f8:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    53fd:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    5401:	c5 95 db a4 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm4
    5408:	00 00 
    540a:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    540f:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    5414:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    5419:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    541d:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    5421:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    5427:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    542c:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    5433:	00 00 
    5435:	c4 a2 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm5
    543b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    543f:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5467 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc27>
    5446:	00 
    5447:	c4 62 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm8
    544d:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    5451:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    5456:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 547e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc3e>
    545d:	00 
    545e:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    5464:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 548c <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc4c>
    546b:	00 
    546c:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    5471:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    5475:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    5479:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    547e:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    5483:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    5489:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm4,%ymm4        # 5492 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc52>
    5490:	ff ff a0 
    5493:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
    5498:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    549f:	00 00 
    54a1:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    54a5:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    54a9:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    54ae:	c4 62 2d 90 24 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm12
    54b4:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    54b9:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    54be:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    54c3:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    54c8:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    54ce:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm4,%ymm4        # 54d7 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc97>
    54d5:	ff ff 60 
    54d8:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    54dc:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    54e2:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    54e8:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    54ef:	00 00 
    54f1:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    54f6:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    54fb:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    5501:	c4 41 5d db f5       	vpand  %ymm13,%ymm4,%ymm14
    5506:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    550c:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    5513:	00 00 
    5515:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    551c:	00 00 
    551e:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    5523:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
    5528:	c4 41 1d fe e1       	vpaddd %ymm9,%ymm12,%ymm12
    552d:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    5533:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    5538:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    553c:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    5540:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    5545:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    554a:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    554f:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    5554:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    5558:	c5 95 db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm13,%ymm0
    555f:	00 00 
    5561:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    5565:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    556b:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    5570:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    5577:	00 00 00 
    557a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    557e:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    5584:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    5588:	c4 a2 3d 90 04 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm0
    558e:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    5592:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5597:	c5 9d 72 d5 10       	vpsrld $0x10,%ymm5,%ymm12
    559c:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 55c4 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd84>
    55a3:	00 
    55a4:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    55a9:	c4 e2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm4,4),%ymm5
    55af:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    55b3:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    55b8:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 55e0 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xda0>
    55bf:	00 
    55c0:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    55c6:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 55ee <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdae>
    55cd:	00 
    55ce:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    55d3:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    55d7:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    55dc:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    55e1:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    55e7:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 55f0 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdb0>
    55ee:	ff ff 90 
    55f1:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    55f6:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    55fa:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    55ff:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    5603:	c4 e2 25 90 14 b0    	vpgatherdd %ymm11,(%rax,%ymm6,4),%ymm2
    5609:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    560d:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    5611:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    5617:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    561b:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 5624 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde4>
    5622:	ff ff 90 
    5625:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    562a:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    562e:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    5633:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    5638:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    563e:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5643:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    5649:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    564d:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    5652:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    5659:	00 00 
    565b:	48 8b 41 60          	mov    0x60(%rcx),%rax
    565f:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    5664:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5669:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    566d:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    5672:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    5677:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    567c:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    5681:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    5685:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    568a:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    568f:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5693:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5697:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    569c:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    56a3:	00 00 
    56a5:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    56a9:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    56ad:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    56b2:	c4 e2 65 90 24 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm4
    56b8:	48 8b 41 68          	mov    0x68(%rcx),%rax
    56bc:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    56c0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    56c4:	c4 a2 4d 90 2c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm5
    56ca:	48 8b 41 70          	mov    0x70(%rcx),%rax
    56ce:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    56d5:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    56db:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    56e0:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    56e4:	c5 79 6e ca          	vmovd  %edx,%xmm9
    56e8:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    56ed:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    56f1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    56f6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    56fb:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    5702:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5707:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    570c:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5734 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xef4>
    5713:	00 
    5714:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    571a:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    571f:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    5726:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 574e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf0e>
    572d:	00 
    572e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5733:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    5738:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    573d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5765 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf25>
    5744:	00 
    5745:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    574a:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    574f:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5753:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5758:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    575c:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    5760:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5764:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5768:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    576e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5772:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    5777:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    577b:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5781:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    5785:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    578b:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    578f:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5794:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    5798:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    579d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    57a1:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    57a7:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 57b0 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf70>
    57ae:	ff ff 70 
    57b1:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    57b6:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    57ba:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    57be:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    57c4:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    57c9:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    57ce:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    57d4:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    57da:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    57df:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    57e4:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    57e9:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    57ee:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 57f7 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb7>
    57f5:	ff ff b0 
    57f8:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    57fc:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5801:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5806:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    580c:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    5811:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5815:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    581c:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    5821:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5826:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    582b:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    582f:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5834:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5839:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    583e:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5843:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    5847:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    584c:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    5851:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    5855:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    585a:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    585f:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    5864:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5869:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    586e:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5874:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    5879:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    587e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    5882:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    5887:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    588c:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5891:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    5896:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    589b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    58a0:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    58a5:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    58aa:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    58af:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    58b4:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    58b9:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    58be:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    58c2:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    58c7:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    58cc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    58d1:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    58d6:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    58db:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    58e0:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    58e4:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    58e8:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    58ed:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    58f1:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    58f6:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    58fb:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    58ff:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5904:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    5908:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    590c:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    5912:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    5919:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    591d:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5921:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5925:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5929:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    592f:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    5936:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    593b:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    5940:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    5946:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    594c:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    5951:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    5958:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    595d:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5962:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 598a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x114a>
    5969:	00 
    596a:	c5 79 6e ca          	vmovd  %edx,%xmm9
    596e:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5973:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 599b <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x115b>
    597a:	00 
    597b:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    5982:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5987:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 59af <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x116f>
    598e:	00 
    598f:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5994:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5999:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    599e:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    59a3:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    59a7:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    59ab:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    59af:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    59b3:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    59b7:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    59bd:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    59c1:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    59c7:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    59cc:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    59d0:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    59d6:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    59da:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    59e0:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    59e4:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    59e9:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    59ed:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    59f2:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    59f6:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    59fc:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5a05 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11c5>
    5a03:	ff ff 70 
    5a06:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5a0b:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    5a0f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5a13:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5a19:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5a1e:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    5a23:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5a29:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    5a2f:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5a34:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5a39:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5a3e:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    5a43:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5a4c <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120c>
    5a4a:	ff ff b0 
    5a4d:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    5a51:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5a56:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5a5b:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    5a61:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    5a66:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5a6a:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    5a71:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    5a76:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5a7b:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    5a80:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    5a84:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5a89:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5a8e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    5a93:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5a98:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    5a9c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5aa1:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    5aa6:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    5aaa:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    5aaf:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    5ab4:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    5ab9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5abe:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5ac3:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5ac9:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    5ace:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5ad3:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    5ad7:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    5adc:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5ae1:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5ae6:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    5aeb:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5af0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5af5:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    5afa:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    5aff:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    5b04:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    5b09:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    5b0e:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5b13:	c5 79 6e ca          	vmovd  %edx,%xmm9
    5b17:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    5b1b:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5b20:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5b25:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    5b2a:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    5b2f:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5b34:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    5b39:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5b3e:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    5b42:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5b46:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5b4b:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    5b4f:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5b54:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5b59:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5b5d:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5b62:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5b67:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    5b6b:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    5b6f:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    5b75:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    5b7c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5b80:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5b84:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5b88:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5b8c:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5b92:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    5b99:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5b9e:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    5ba3:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5bcb <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138b>
    5baa:	00 
    5bab:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    5bb1:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    5bb6:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 5bde <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x139e>
    5bbd:	00 
    5bbe:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5bc3:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    5bc8:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5bcd:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5bf5 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13b5>
    5bd4:	00 
    5bd5:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    5bdc:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5be1:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    5be6:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5bea:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5bef:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    5bf3:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    5bf7:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5bfb:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5bff:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    5c05:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5c09:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    5c0e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5c12:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5c18:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    5c1c:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    5c22:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    5c26:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5c2b:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    5c2f:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    5c34:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    5c3a:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5c43 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1403>
    5c41:	ff ff 70 
    5c44:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5c49:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    5c4d:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5c51:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5c57:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5c5c:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    5c61:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5c67:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    5c6d:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5c72:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5c77:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5c7c:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    5c81:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5c8a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x144a>
    5c88:	ff ff b0 
    5c8b:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    5c8f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5c93:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5c98:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5c9e:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    5ca3:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5ca7:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    5cac:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5cb1:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5cb6:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5cba:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5cbf:	c4 41 15 db e4       	vpand  %ymm12,%ymm13,%ymm12
    5cc4:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5cc9:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5cce:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5cd3:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5cd8:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    5cdc:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    5ce1:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    5ce5:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    5cea:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5cef:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    5cf4:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5cfa:	c5 95 db f6          	vpand  %ymm6,%ymm13,%ymm6
    5cfe:	c5 95 db d2          	vpand  %ymm2,%ymm13,%ymm2
    5d02:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5d07:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5d0c:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5d11:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5d16:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5d1a:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5d1f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5d24:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    5d29:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5d2e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    5d33:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    5d38:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    5d3d:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    5d42:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    5d46:	c4 c1 75 db f5       	vpand  %ymm13,%ymm1,%ymm6
    5d4b:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    5d50:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5d55:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    5d5a:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    5d5f:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5d64:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    5d68:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5d6c:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    5d70:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    5d75:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5d7a:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5d7f:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5d84:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    5d89:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5d8d:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5d91:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5d95:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5d9a:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    5d9f:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    5da3:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    5da7:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    5dae:	02 00 00 
    5db1:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    5db5:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    5dbb:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    5dc0:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    5dc5:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    5dc9:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    5dcf:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    5dd5:	4d 39 c2             	cmp    %r8,%r10
    5dd8:	0f 85 60 f4 ff ff    	jne    523e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9fe>
    5dde:	e9 4e f3 ff ff       	jmp    5131 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    5de3:	4d 85 c9             	test   %r9,%r9
    5de6:	0f 84 48 f3 ff ff    	je     5134 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    5dec:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 5e54 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1614>
    5df3:	00 
    5df4:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    5df8:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5dfd:	48 c1 e8 03          	shr    $0x3,%rax
    5e01:	c4 c1 35 72 d7 18    	vpsrld $0x18,%ymm15,%ymm9
    5e07:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5e0b:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    5e12:	00 00 
    5e14:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 5e9c <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x165c>
    5e1b:	00 
    5e1c:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    5e21:	b8 00 80 00 00       	mov    $0x8000,%eax
    5e26:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    5e2d:	00 00 
    5e2f:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    5e33:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5e38:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    5e3d:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    5e42:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    5e48:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5e4c:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5e51:	48 8b 01             	mov    (%rcx),%rax
    5e54:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    5e58:	49 83 c0 18          	add    $0x18,%r8
    5e5c:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    5e62:	8b 51 50             	mov    0x50(%rcx),%edx
    5e65:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    5e6b:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    5e70:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    5e77:	01 00 00 
    5e7a:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    5e7e:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    5e83:	c4 c1 7d db d9       	vpand  %ymm9,%ymm0,%ymm3
    5e88:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    5e8d:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    5e92:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    5e98:	48 8b 41 08          	mov    0x8(%rcx),%rax
    5e9c:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5ea1:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5ea5:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    5eaa:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5eaf:	c4 a2 4d 90 14 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm2
    5eb5:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5eb9:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5ebd:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
    5ec2:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 5eea <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16aa>
    5ec9:	00 
    5eca:	c4 e2 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm0
    5ed0:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    5ed5:	48 8b 41 48          	mov    0x48(%rcx),%rax
    5ed9:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 5f01 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16c1>
    5ee0:	00 
    5ee1:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
    5ee6:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    5eeb:	c5 ad 72 d0 11       	vpsrld $0x11,%ymm0,%ymm10
    5ef0:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 5f18 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16d8>
    5ef7:	00 
    5ef8:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    5efc:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5f00:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    5f05:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5f0a:	c4 62 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm12
    5f10:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    5f14:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    5f18:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5f1d:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    5f23:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    5f27:	c4 62 15 90 24 b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm12
    5f2d:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5f32:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    5f38:	c4 62 15 90 34 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm14
    5f3e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5f42:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5f46:	c4 22 65 90 2c 82    	vpgatherdd %ymm3,(%rdx,%ymm8,4),%ymm13
    5f4c:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    5f50:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    5f57:	00 00 
    5f59:	c4 e2 2d 90 1c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm3
    5f5f:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
    5f63:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    5f6a:	00 00 
    5f6c:	c4 e2 45 3d da       	vpmaxsd %ymm2,%ymm7,%ymm3
    5f71:	c5 7d 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm8
    5f75:	c4 62 65 3d e8       	vpmaxsd %ymm0,%ymm3,%ymm13
    5f7a:	c4 e2 45 39 da       	vpminsd %ymm2,%ymm7,%ymm3
    5f7f:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5f85:	c4 62 65 39 d0       	vpminsd %ymm0,%ymm3,%ymm10
    5f8a:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    5f8e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm1,%ymm1        # 5f97 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1757>
    5f95:	ff ff 80 
    5f98:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5f9d:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    5fa1:	c4 62 3d 90 24 88    	vpgatherdd %ymm8,(%rax,%ymm1,4),%ymm12
    5fa7:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
    5fab:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    5fb1:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5fb7:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm1,%ymm1        # 5fc0 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1780>
    5fbe:	ff ff 30 
    5fc1:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5fc5:	c5 cd fa c9          	vpsubd %ymm1,%ymm6,%ymm1
    5fc9:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    5fcd:	c4 62 65 90 04 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm8
    5fd3:	c5 b5 db 4c 24 20    	vpand  0x20(%rsp),%ymm9,%ymm1
    5fd9:	c4 c1 1d db d9       	vpand  %ymm9,%ymm12,%ymm3
    5fde:	c4 41 2d fe e5       	vpaddd %ymm13,%ymm10,%ymm12
    5fe3:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5fe8:	c5 45 fe ea          	vpaddd %ymm2,%ymm7,%ymm13
    5fec:	c4 41 7d fa e4       	vpsubd %ymm12,%ymm0,%ymm12
    5ff1:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
    5ff8:	00 00 
    5ffa:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
    5fff:	c5 3d fa e3          	vpsubd %ymm3,%ymm8,%ymm12
    6003:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    600a:	00 00 
    600c:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
    6011:	c5 e5 fa 9c 24 80 00 	vpsubd 0x80(%rsp),%ymm3,%ymm3
    6018:	00 00 
    601a:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    6021:	00 00 
    6023:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    6028:	c5 f5 fe 0c 24       	vpaddd (%rsp),%ymm1,%ymm1
    602d:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    6032:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6036:	c5 9d fe c9          	vpaddd %ymm1,%ymm12,%ymm1
    603a:	c5 35 db 64 24 60    	vpand  0x60(%rsp),%ymm9,%ymm12
    6040:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    6045:	c4 c1 1d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm12
    604b:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    6050:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    6054:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    6058:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    605f:	00 00 
    6061:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    6066:	c4 c1 3d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm8
    606c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6071:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    6075:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    607c:	00 00 
    607e:	c5 f5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm1
    6083:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    6088:	c4 41 3d fe d4       	vpaddd %ymm12,%ymm8,%ymm10
    608d:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    6092:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    6096:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    609d:	00 00 
    609f:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    60a3:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    60a9:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    60ae:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    60b2:	c5 e5 fe d0          	vpaddd %ymm0,%ymm3,%ymm2
    60b6:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    60bd:	00 00 
    60bf:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
    60c5:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    60ca:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    60ce:	c4 62 6d 3d e8       	vpmaxsd %ymm0,%ymm2,%ymm13
    60d3:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
    60d7:	c4 41 65 66 f5       	vpcmpgtd %ymm13,%ymm3,%ymm14
    60dc:	c4 62 15 3d d3       	vpmaxsd %ymm3,%ymm13,%ymm10
    60e1:	c4 62 6d 39 e8       	vpminsd %ymm0,%ymm2,%ymm13
    60e6:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    60ea:	c4 c3 5d 4c fb 70    	vpblendvb %ymm7,%ymm11,%ymm4,%ymm7
    60f0:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm7,%ymm7        # 60f9 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18b9>
    60f7:	ff ff e0 
    60fa:	c4 62 15 39 f3       	vpminsd %ymm3,%ymm13,%ymm14
    60ff:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    6103:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    610a:	00 00 
    610c:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    6110:	c4 c3 5d 4c c3 00    	vpblendvb %ymm0,%ymm11,%ymm4,%ymm0
    6116:	c4 62 4d 90 34 b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm14
    611c:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6122:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    6126:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 612f <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18ef>
    612d:	ff ff d0 
    6130:	c5 cd fa d8          	vpsubd %ymm0,%ymm6,%ymm3
    6134:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6138:	c4 e2 4d 90 04 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm0
    613e:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    6144:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    6149:	c4 41 7d db e9       	vpand  %ymm9,%ymm0,%ymm13
    614e:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    6155:	00 00 
    6157:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    615c:	c4 41 65 db f1       	vpand  %ymm9,%ymm3,%ymm14
    6161:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    6166:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    616c:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
    6171:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    6176:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    617a:	c5 95 fa d3          	vpsubd %ymm3,%ymm13,%ymm2
    617e:	c5 cd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm6
    6183:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
    618a:	00 00 
    618c:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    6191:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
    6197:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    619e:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    61a3:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    61a9:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    61ae:	c5 c5 fe 14 24       	vpaddd (%rsp),%ymm7,%ymm2
    61b3:	c4 c2 3d 39 fc       	vpminsd %ymm12,%ymm8,%ymm7
    61b8:	c5 79 6e d2          	vmovd  %edx,%xmm10
    61bc:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    61c1:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    61c6:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    61ca:	c5 b5 db c6          	vpand  %ymm6,%ymm9,%ymm0
    61ce:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    61d2:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    61d7:	c4 62 45 39 e9       	vpminsd %ymm1,%ymm7,%ymm13
    61dc:	c5 c5 66 f9          	vpcmpgtd %ymm1,%ymm7,%ymm7
    61e0:	c4 e2 7d 40 84 24 80 	vpmulld 0x80(%rsp),%ymm0,%ymm0
    61e7:	00 00 00 
    61ea:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    61ee:	c4 c2 3d 3d dc       	vpmaxsd %ymm12,%ymm8,%ymm3
    61f3:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    61f7:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
    61fb:	c4 e2 65 3d d9       	vpmaxsd %ymm1,%ymm3,%ymm3
    6200:	c5 8d 72 d2 10       	vpsrld $0x10,%ymm2,%ymm14
    6205:	c4 c1 1d 66 d0       	vpcmpgtd %ymm8,%ymm12,%ymm2
    620a:	c4 41 3d 66 c4       	vpcmpgtd %ymm12,%ymm8,%ymm8
    620f:	c4 c3 5d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm4,%ymm2
    6215:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 621e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19de>
    621c:	ff ff 00 
    621f:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    6223:	c4 e2 4d 90 04 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm0
    6229:	c4 c3 5d 4c d3 80    	vpblendvb %ymm8,%ymm11,%ymm4,%ymm2
    622f:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6235:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 623e <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19fe>
    623c:	ff ff 70 
    623f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6244:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    624a:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    624e:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    6252:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    6258:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    625d:	c4 c1 65 fe c5       	vpaddd %ymm13,%ymm3,%ymm0
    6262:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6268:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    626c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    6271:	48 8b 41 60          	mov    0x60(%rcx),%rax
    6275:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    627a:	c5 dd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm4
    627f:	c5 fd fe 84 24 e0 00 	vpaddd 0xe0(%rsp),%ymm0,%ymm0
    6286:	00 00 
    6288:	c5 d5 fa ca          	vpsubd %ymm2,%ymm5,%ymm1
    628c:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    6291:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6296:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    629b:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    62a0:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    62a4:	c5 c5 fe 0c 24       	vpaddd (%rsp),%ymm7,%ymm1
    62a9:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    62ae:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    62b2:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    62b6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    62ba:	c4 c1 4d db c9       	vpand  %ymm9,%ymm6,%ymm1
    62bf:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    62c3:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    62c7:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    62cc:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    62d1:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    62d6:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    62da:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    62de:	c5 fe 6f 8c 24 00 01 	vmovdqu 0x100(%rsp),%ymm1
    62e5:	00 00 
    62e7:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    62ec:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    62f2:	48 8b 41 68          	mov    0x68(%rcx),%rax
    62f6:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    62fa:	c4 a2 4d 90 2c b0    	vpgatherdd %ymm6,(%rax,%ymm14,4),%ymm5
    6300:	48 8b 41 70          	mov    0x70(%rcx),%rax
    6304:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6309:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 6331 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1af1>
    6310:	00 
    6311:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6317:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    631c:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    6323:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 634b <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b0b>
    632a:	00 
    632b:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    6330:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6335:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    633a:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6362 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b22>
    6341:	00 
    6342:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6347:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    634c:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    6350:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    6355:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    6359:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    635d:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    6361:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6365:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    636b:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    636f:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6374:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6378:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    637c:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    6382:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    6389:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    638f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6395:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    6399:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    639e:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    63a2:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    63a7:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    63ab:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    63b1:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 63ba <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b7a>
    63b8:	ff ff 70 
    63bb:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    63c0:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    63c4:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    63c8:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    63ce:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    63d3:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    63d8:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    63de:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    63e4:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    63e9:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    63ee:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    63f3:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    63f8:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6401 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1bc1>
    63ff:	ff ff c0 
    6402:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    6406:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    640b:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6410:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    6416:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    641b:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    641f:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    6426:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    642b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6430:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    6435:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    6439:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    643e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    6443:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    6448:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    644d:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    6451:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6456:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    645b:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    645f:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    6464:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6469:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    646e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6473:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6478:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    647e:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    6483:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    6488:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    648c:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    6491:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    6496:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    649b:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    64a0:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    64a5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    64aa:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    64af:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    64b4:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    64b9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    64be:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    64c3:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    64c8:	c5 79 6e d2          	vmovd  %edx,%xmm10
    64cc:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    64d0:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    64d5:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    64da:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    64df:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    64e4:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    64e9:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    64ee:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    64f3:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    64f7:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    64fb:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6500:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    6504:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    6509:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    650e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6512:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    6517:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    651c:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    6520:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6524:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    652a:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    6531:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6535:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6539:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    653d:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    6541:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    6547:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    654e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6553:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6558:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 6580 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d40>
    655f:	00 
    6560:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6566:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    656b:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    6572:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 659a <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d5a>
    6579:	00 
    657a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    657f:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6584:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    6589:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 65b1 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d71>
    6590:	00 
    6591:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6596:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    659b:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    659f:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    65a4:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    65a8:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    65ac:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    65b0:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    65b4:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    65ba:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    65be:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    65c3:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    65c7:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    65cd:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    65d1:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    65d7:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    65db:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    65e0:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    65e4:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    65e9:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    65ed:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    65f3:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 65fc <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1dbc>
    65fa:	ff ff 70 
    65fd:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    6602:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    6606:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    660a:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    660f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6614:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    661a:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6620:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6626:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    662b:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6634 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1df4>
    6632:	ff ff c0 
    6635:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    663a:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    663f:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    6646:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    664b:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    664f:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    6653:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    6659:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    665f:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    6664:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6669:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    6670:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6675:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    667a:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    667f:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    6683:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    6688:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    668d:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    6692:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6697:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    669c:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    66a1:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    66a5:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    66aa:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    66ae:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    66b3:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    66b8:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    66bd:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    66c3:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    66c8:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    66cd:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    66d2:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    66d7:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    66dc:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    66e1:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    66e5:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    66ea:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    66ef:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    66f4:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    66f9:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    66fe:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6703:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    6708:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    670d:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6712:	c5 79 6e d2          	vmovd  %edx,%xmm10
    6716:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    671b:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    6720:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    6725:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    6729:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    672e:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    6733:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    6738:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    673d:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    6742:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    6747:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    674b:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    674f:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6754:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    6758:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    675d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    6762:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6766:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    676b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    676f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6773:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    6779:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    6780:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6784:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6788:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    678c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    6790:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    6796:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    679d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    67a2:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    67a7:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 67cf <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f8f>
    67ae:	00 
    67af:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    67b5:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    67ba:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    67c1:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 67e9 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fa9>
    67c8:	00 
    67c9:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    67ce:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    67d3:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    67d8:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6800 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fc0>
    67df:	00 
    67e0:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    67e5:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    67ea:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    67ee:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    67f3:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    67f7:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    67fb:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    67ff:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6803:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    6809:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    680d:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6812:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6816:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    681c:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    6820:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6826:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    682a:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    682f:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6833:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6838:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    683e:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 6847 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2007>
    6845:	ff ff 70 
    6848:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    684d:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    6851:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    6855:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    685b:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    6860:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6865:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    686b:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6871:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6876:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    687b:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    6880:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6889 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2049>
    6887:	ff ff c0 
    688a:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    688e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6892:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    6897:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    689d:	c4 c1 7d db f1       	vpand  %ymm9,%ymm0,%ymm6
    68a2:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    68a6:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    68ab:	c4 c1 55 db d1       	vpand  %ymm9,%ymm5,%ymm2
    68b0:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    68b5:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    68ba:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    68be:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    68c3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    68c8:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    68cd:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    68d2:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    68d7:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    68dc:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    68e0:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    68e5:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    68e9:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    68ee:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    68f3:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    68f8:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    68fe:	c5 b5 db f6          	vpand  %ymm6,%ymm9,%ymm6
    6902:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    6907:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    690c:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6911:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    6916:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    691b:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    691f:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    6924:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6929:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    692e:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6933:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    6938:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    693d:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    6942:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    6947:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    694b:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    6950:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    6955:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    695a:	c4 c1 65 db e9       	vpand  %ymm9,%ymm3,%ymm5
    695f:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    6964:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    6969:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    696d:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    6971:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    6975:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    697a:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    697f:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    6984:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    6989:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    698e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6992:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    6996:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    699a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    699f:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    69a4:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    69a8:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    69ac:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    69b3:	02 00 00 
    69b6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    69ba:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    69c0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    69c5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    69ca:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    69ce:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    69d4:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    69da:	4d 39 c2             	cmp    %r8,%r10
    69dd:	0f 85 5a f4 ff ff    	jne    5e3d <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15fd>
    69e3:	e9 49 e7 ff ff       	jmp    5131 <jshc_delta16_cache::avx2_chain(jshc_delta16_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    69e8:	90                   	nop
    69e9:	90                   	nop
    69ea:	90                   	nop
    69eb:	90                   	nop
    69ec:	90                   	nop
    69ed:	90                   	nop
    69ee:	90                   	nop
    69ef:	90                   	nop
