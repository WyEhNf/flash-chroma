
artifacts\skylake-packed-store-build-v1\CMakeFiles\jshc_skylake_packed_store.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>:
       0:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
       7:	c5 f8 29 34 24       	vmovaps %xmm6,(%rsp)
       c:	c5 f8 29 7c 24 10    	vmovaps %xmm7,0x10(%rsp)
      12:	c5 78 29 44 24 20    	vmovaps %xmm8,0x20(%rsp)
      18:	c5 78 29 4c 24 30    	vmovaps %xmm9,0x30(%rsp)
      1e:	c5 78 29 54 24 40    	vmovaps %xmm10,0x40(%rsp)
      24:	c5 78 29 5c 24 50    	vmovaps %xmm11,0x50(%rsp)
      2a:	c5 78 29 64 24 60    	vmovaps %xmm12,0x60(%rsp)
      30:	c5 78 29 6c 24 70    	vmovaps %xmm13,0x70(%rsp)
      36:	c5 78 29 b4 24 80 00 	vmovaps %xmm14,0x80(%rsp)
      3d:	00 00 
      3f:	c5 78 29 bc 24 90 00 	vmovaps %xmm15,0x90(%rsp)
      46:	00 00 
      48:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
      4c:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
      50:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
      54:	48 8b 01             	mov    (%rcx),%rax
      57:	c5 fd 6f 2a          	vmovdqa (%rdx),%ymm5
      5b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
      5f:	44 8b 41 50          	mov    0x50(%rcx),%r8d
      63:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
      69:	48 8b 41 08          	mov    0x8(%rcx),%rax
      6d:	c5 fd 6f 52 20       	vmovdqa 0x20(%rdx),%ymm2
      72:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      76:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
      7b:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
      80:	c4 41 79 6e d8       	vmovd  %r8d,%xmm11
      85:	c4 e2 75 90 3c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm7
      8b:	48 8b 41 10          	mov    0x10(%rcx),%rax
      8f:	c5 fd 6f 4a 40       	vmovdqa 0x40(%rdx),%ymm1
      94:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
      99:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
      9e:	c4 62 55 90 04 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm8
      a4:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
      a9:	48 8b 41 48          	mov    0x48(%rcx),%rax
      ad:	43 8d 4c 01 01       	lea    0x1(%r9,%r8,1),%ecx
      b2:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
      b7:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
      bc:	c5 f9 6e f1          	vmovd  %ecx,%xmm6
      c0:	c4 c1 6d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm2
      c6:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      ca:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
      cf:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
      d3:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
      d8:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
      dc:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
      e0:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
      e4:	c4 e2 55 90 14 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
      ea:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
      ee:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
      f2:	c5 3d db c1          	vpand  %ymm1,%ymm8,%ymm8
      f6:	c4 62 5d 3d d7       	vpmaxsd %ymm7,%ymm4,%ymm10
      fb:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
     101:	c5 c5 66 ec          	vpcmpgtd %ymm4,%ymm7,%ymm5
     105:	c4 41 3d 66 ca       	vpcmpgtd %ymm10,%ymm8,%ymm9
     10a:	c4 62 5d 39 ef       	vpminsd %ymm7,%ymm4,%ymm13
     10f:	c5 5d fe ff          	vpaddd %ymm7,%ymm4,%ymm15
     113:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
     117:	c4 42 15 39 e0       	vpminsd %ymm8,%ymm13,%ymm12
     11c:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
     121:	c4 42 2d 3d d0       	vpmaxsd %ymm8,%ymm10,%ymm10
     126:	c4 c3 25 4c ee 50    	vpblendvb %ymm5,%ymm14,%ymm11,%ymm5
     12c:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm5,%ymm5        # 135 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x135>
     133:	ff ff 90 
     136:	c4 43 25 4c de 40    	vpblendvb %ymm4,%ymm14,%ymm11,%ymm11
     13c:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
     141:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm11,%ymm11        # 14a <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x14a>
     148:	ff ff d0 
     14b:	c4 41 3d fa c9       	vpsubd %ymm9,%ymm8,%ymm9
     150:	c5 fd 6f e0          	vmovdqa %ymm0,%ymm4
     154:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     159:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
     15e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     162:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     166:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
     16c:	c4 e2 5d 90 1c b0    	vpgatherdd %ymm4,(%rax,%ymm6,4),%ymm3
     172:	b8 00 80 00 00       	mov    $0x8000,%eax
     177:	c5 cd 72 d0 18       	vpsrld $0x18,%ymm0,%ymm6
     17c:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     181:	c5 55 db de          	vpand  %ymm6,%ymm5,%ymm11
     185:	c5 ed db e6          	vpand  %ymm6,%ymm2,%ymm4
     189:	c5 e5 db c6          	vpand  %ymm6,%ymm3,%ymm0
     18d:	c5 f5 db fe          	vpand  %ymm6,%ymm1,%ymm7
     191:	c5 bd 72 f4 10       	vpslld $0x10,%ymm4,%ymm8
     196:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
     19a:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     19e:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     1a3:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     1a8:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     1ad:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     1b2:	c5 15 db ee          	vpand  %ymm6,%ymm13,%ymm13
     1b6:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
     1bb:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     1c0:	c5 25 db de          	vpand  %ymm6,%ymm11,%ymm11
     1c4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     1c9:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
     1cd:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
     1d1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     1d5:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     1d9:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     1de:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1e2:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     1e7:	c4 c1 3d 72 f3 10    	vpslld $0x10,%ymm11,%ymm8
     1ed:	c4 41 15 fa db       	vpsubd %ymm11,%ymm13,%ymm11
     1f2:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     1f6:	c5 c5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm7
     1fb:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     1ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     204:	c4 42 25 40 da       	vpmulld %ymm10,%ymm11,%ymm11
     209:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     20d:	c5 fd 7f 02          	vmovdqa %ymm0,(%rdx)
     211:	c5 fd 72 d3 08       	vpsrld $0x8,%ymm3,%ymm0
     216:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     21b:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     21f:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     223:	c5 c5 fa f8          	vpsubd %ymm0,%ymm7,%ymm7
     227:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
     22c:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     231:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     236:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
     23b:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     240:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
     244:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
     249:	c5 f5 72 f2 10       	vpslld $0x10,%ymm2,%ymm1
     24e:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     252:	c5 d5 fa d2          	vpsubd %ymm2,%ymm5,%ymm2
     256:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     25a:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     25e:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     263:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     268:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
     26d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     271:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     276:	c5 fd 7f 7a 20       	vmovdqa %ymm7,0x20(%rdx)
     27b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     27f:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     283:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     287:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     28c:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     291:	c5 f8 77             	vzeroupper
     294:	c5 f8 28 34 24       	vmovaps (%rsp),%xmm6
     299:	c5 f8 28 7c 24 10    	vmovaps 0x10(%rsp),%xmm7
     29f:	c5 78 28 44 24 20    	vmovaps 0x20(%rsp),%xmm8
     2a5:	c5 78 28 4c 24 30    	vmovaps 0x30(%rsp),%xmm9
     2ab:	c5 78 28 54 24 40    	vmovaps 0x40(%rsp),%xmm10
     2b1:	c5 78 28 5c 24 50    	vmovaps 0x50(%rsp),%xmm11
     2b7:	c5 78 28 64 24 60    	vmovaps 0x60(%rsp),%xmm12
     2bd:	c5 78 28 6c 24 70    	vmovaps 0x70(%rsp),%xmm13
     2c3:	c5 78 28 b4 24 80 00 	vmovaps 0x80(%rsp),%xmm14
     2ca:	00 00 
     2cc:	c5 78 28 bc 24 90 00 	vmovaps 0x90(%rsp),%xmm15
     2d3:	00 00 
     2d5:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
     2dc:	c3                   	ret
     2dd:	0f 1f 00             	nopl   (%rax)

00000000000002e0 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>:
     2e0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
     2e7:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
     2ee:	00 00 
     2f0:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
     2f7:	00 00 
     2f9:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
     300:	00 00 
     302:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
     309:	00 00 
     30b:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
     312:	00 00 
     314:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
     31b:	00 00 
     31d:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
     324:	00 00 
     326:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
     32d:	00 00 
     32f:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
     336:	00 00 
     338:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
     33f:	00 00 
     341:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     345:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     349:	48 8b 01             	mov    (%rcx),%rax
     34c:	c5 fd 6f 3a          	vmovdqa (%rdx),%ymm7
     350:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     354:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     358:	c4 e2 65 90 24 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm4
     35e:	48 8b 41 08          	mov    0x8(%rcx),%rax
     362:	c5 fd 6f 7a 20       	vmovdqa 0x20(%rdx),%ymm7
     367:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     36b:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
     370:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     375:	c5 7d 6f 32          	vmovdqa (%rdx),%ymm14
     379:	c5 7d 6f 52 20       	vmovdqa 0x20(%rdx),%ymm10
     37e:	c4 e2 65 90 2c b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm5
     384:	c5 fd 6f 7a 40       	vmovdqa 0x40(%rdx),%ymm7
     389:	48 8b 41 10          	mov    0x10(%rcx),%rax
     38d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
     391:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     396:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     39b:	c4 e2 65 90 34 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm6
     3a1:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     3a6:	c4 c1 79 6e d8       	vmovd  %r8d,%xmm3
     3ab:	48 8b 41 48          	mov    0x48(%rcx),%rax
     3af:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     3b4:	c5 b5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm9
     3b9:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     3be:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     3c3:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     3c7:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     3cb:	c4 41 75 fe d9       	vpaddd %ymm9,%ymm1,%ymm11
     3d0:	c5 f5 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm1
     3d5:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     3d9:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     3dd:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     3e1:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     3e6:	c4 22 6d 90 24 98    	vpgatherdd %ymm2,(%rax,%ymm11,4),%ymm12
     3ec:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     3f0:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     3f5:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     3fa:	c4 41 75 fe eb       	vpaddd %ymm11,%ymm1,%ymm13
     3ff:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     403:	c4 a2 75 90 14 a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm2
     409:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     40d:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
     413:	c4 02 75 90 3c b0    	vpgatherdd %ymm1,(%r8,%ymm14,4),%ymm15
     419:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     41d:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     421:	48 8b 49 28          	mov    0x28(%rcx),%rcx
     425:	c4 02 75 90 34 90    	vpgatherdd %ymm1,(%r8,%ymm10,4),%ymm14
     42b:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     42f:	c4 62 5d 3d d5       	vpmaxsd %ymm5,%ymm4,%ymm10
     434:	c4 e2 75 90 14 b9    	vpgatherdd %ymm1,(%rcx,%ymm7,4),%ymm2
     43a:	c5 d5 66 cc          	vpcmpgtd %ymm4,%ymm5,%ymm1
     43e:	b9 00 80 00 00       	mov    $0x8000,%ecx
     443:	c4 c1 4d 66 fa       	vpcmpgtd %ymm10,%ymm6,%ymm7
     448:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     44e:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm1,%ymm1        # 457 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x177>
     455:	ff ff 70 
     458:	c4 e2 2d 3d fe       	vpmaxsd %ymm6,%ymm10,%ymm7
     45d:	c4 62 35 39 d6       	vpminsd %ymm6,%ymm9,%ymm10
     462:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     469:	00 00 
     46b:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     470:	c5 35 66 ce          	vpcmpgtd %ymm6,%ymm9,%ymm9
     474:	c5 7e 7f 94 24 c0 00 	vmovdqu %ymm10,0xc0(%rsp)
     47b:	00 00 
     47d:	c5 7d 6f d0          	vmovdqa %ymm0,%ymm10
     481:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     487:	c4 e2 2d 90 3c 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm7
     48d:	c5 dd 66 cd          	vpcmpgtd %ymm5,%ymm4,%ymm1
     491:	c5 7e 7f 2c 24       	vmovdqu %ymm13,(%rsp)
     496:	c4 c3 65 4c c8 10    	vpblendvb %ymm1,%ymm8,%ymm3,%ymm1
     49c:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 4a5 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x1c5>
     4a3:	ff ff 90 
     4a6:	c5 7d 6f c8          	vmovdqa %ymm0,%ymm9
     4aa:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
     4ae:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
     4b5:	00 00 
     4b7:	c4 62 35 90 1c 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm11
     4bd:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     4c3:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     4c8:	c5 15 fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm13,%ymm12
     4cf:	00 00 
     4d1:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     4d5:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     4d9:	c5 5d fe ed          	vpaddd %ymm5,%ymm4,%ymm13
     4dd:	c5 75 db 54 24 40    	vpand  0x40(%rsp),%ymm1,%ymm10
     4e3:	c4 41 4d fa e4       	vpsubd %ymm12,%ymm6,%ymm12
     4e8:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
     4ed:	c5 25 fa e7          	vpsubd %ymm7,%ymm11,%ymm12
     4f1:	c4 c1 35 72 f2 10    	vpslld $0x10,%ymm10,%ymm9
     4f7:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
     4fc:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     500:	c4 c1 45 fa fa       	vpsubd %ymm10,%ymm7,%ymm7
     505:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     50a:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     511:	00 00 00 
     514:	c4 c1 2d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm10
     51a:	c4 41 35 fe cd       	vpaddd %ymm13,%ymm9,%ymm9
     51f:	c5 2d fe d5          	vpaddd %ymm5,%ymm10,%ymm10
     523:	c5 7e 7f ac 24 80 00 	vmovdqu %ymm13,0x80(%rsp)
     52a:	00 00 
     52c:	c4 41 1d fe c9       	vpaddd %ymm9,%ymm12,%ymm9
     531:	c5 75 db 64 24 60    	vpand  0x60(%rsp),%ymm1,%ymm12
     537:	c4 41 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm12
     53c:	c4 62 1d 40 a4 24 c0 	vpmulld 0xc0(%rsp),%ymm12,%ymm12
     543:	00 00 00 
     546:	c5 1d fe e7          	vpaddd %ymm7,%ymm12,%ymm12
     54a:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
     54f:	c4 c1 45 72 d1 10    	vpsrld $0x10,%ymm9,%ymm7
     555:	c4 c1 35 72 e7 10    	vpsrad $0x10,%ymm15,%ymm9
     55b:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     562:	00 00 
     564:	c5 c5 72 e2 10       	vpsrad $0x10,%ymm2,%ymm7
     569:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     56e:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
     572:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
     577:	c5 c5 fe fe          	vpaddd %ymm6,%ymm7,%ymm7
     57b:	c4 41 2d fe e1       	vpaddd %ymm9,%ymm10,%ymm12
     580:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     584:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
     58a:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
     591:	00 00 
     593:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     598:	c5 cd fe ed          	vpaddd %ymm5,%ymm6,%ymm5
     59c:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
     5a2:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     5a6:	c5 cd 72 e6 10       	vpsrad $0x10,%ymm6,%ymm6
     5ab:	c5 6d fe f5          	vpaddd %ymm5,%ymm2,%ymm14
     5af:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
     5b3:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
     5ba:	00 00 
     5bc:	c4 62 5d 3d dd       	vpmaxsd %ymm5,%ymm4,%ymm11
     5c1:	c5 55 66 ec          	vpcmpgtd %ymm4,%ymm5,%ymm13
     5c5:	c4 62 5d 39 f5       	vpminsd %ymm5,%ymm4,%ymm14
     5ca:	c4 c1 6d 66 f3       	vpcmpgtd %ymm11,%ymm2,%ymm6
     5cf:	c5 dd 66 ed          	vpcmpgtd %ymm5,%ymm4,%ymm5
     5d3:	c4 62 0d 39 e2       	vpminsd %ymm2,%ymm14,%ymm12
     5d8:	c5 0d 66 f2          	vpcmpgtd %ymm2,%ymm14,%ymm14
     5dc:	c4 62 25 3d da       	vpmaxsd %ymm2,%ymm11,%ymm11
     5e1:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
     5e5:	c4 43 65 4c e8 d0    	vpblendvb %ymm13,%ymm8,%ymm3,%ymm13
     5eb:	c4 63 15 4c 2d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm13,%ymm13        # 5f4 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x314>
     5f2:	ff ff 60 
     5f5:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     5fb:	c5 15 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm13,%ymm13
     601:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm5,%ymm5        # 60a <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x32a>
     608:	ff ff e0 
     60b:	c4 a2 05 90 34 a8    	vpgatherdd %ymm15,(%rax,%ymm13,4),%ymm6
     611:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     616:	c4 41 25 fe fc       	vpaddd %ymm12,%ymm11,%ymm15
     61b:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     620:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     625:	c5 95 fa ed          	vpsubd %ymm5,%ymm13,%ymm5
     629:	c5 dd fe a4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm4,%ymm4
     630:	00 00 
     632:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     636:	c4 62 6d 90 2c a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm13
     63c:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     642:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     648:	c4 c1 15 72 d5 08    	vpsrld $0x8,%ymm13,%ymm13
     64e:	c5 8d 72 d2 08       	vpsrld $0x8,%ymm2,%ymm14
     653:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
     658:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     65c:	c5 0d db f1          	vpand  %ymm1,%ymm14,%ymm14
     660:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     664:	c5 15 fa fe          	vpsubd %ymm6,%ymm13,%ymm15
     668:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     66d:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     672:	c4 42 5d 40 ff       	vpmulld %ymm15,%ymm4,%ymm15
     677:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
     67c:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
     681:	c4 42 35 39 da       	vpminsd %ymm10,%ymm9,%ymm11
     686:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
     68c:	c4 62 25 39 e7       	vpminsd %ymm7,%ymm11,%ymm12
     691:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
     695:	c5 ed fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm2,%ymm2
     69c:	00 00 
     69e:	c5 25 66 df          	vpcmpgtd %ymm7,%ymm11,%ymm11
     6a2:	c5 85 fe d2          	vpaddd %ymm2,%ymm15,%ymm2
     6a6:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     6aa:	c4 c2 35 3d f2       	vpmaxsd %ymm10,%ymm9,%ymm6
     6af:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     6b3:	c4 c1 2d 66 e9       	vpcmpgtd %ymm9,%ymm10,%ymm5
     6b8:	c5 c5 66 e6          	vpcmpgtd %ymm6,%ymm7,%ymm4
     6bc:	c4 41 35 66 ca       	vpcmpgtd %ymm10,%ymm9,%ymm9
     6c1:	c4 e2 4d 3d f7       	vpmaxsd %ymm7,%ymm6,%ymm6
     6c6:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6cb:	c4 c3 65 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm3,%ymm5
     6d1:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm5,%ymm5        # 6da <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x3fa>
     6d8:	ff ff 40 
     6db:	c4 c3 65 4c d8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm3
     6e1:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     6e7:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     6ec:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm3,%ymm3        # 6f5 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)+0x415>
     6f3:	ff ff b0 
     6f6:	c5 95 fa db          	vpsubd %ymm3,%ymm13,%ymm3
     6fa:	c4 e2 0d 90 24 a8    	vpgatherdd %ymm14,(%rax,%ymm5,4),%ymm4
     700:	c4 e2 7d 90 2c 98    	vpgatherdd %ymm0,(%rax,%ymm3,4),%ymm5
     706:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     70c:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     712:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     717:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     71c:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     720:	c5 fd 7f 52 20       	vmovdqa %ymm2,0x20(%rdx)
     725:	c5 bd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm8
     72a:	c4 c1 4d fe c4       	vpaddd %ymm12,%ymm6,%ymm0
     72f:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     733:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
     737:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     73c:	c5 d5 fa fc          	vpsubd %ymm4,%ymm5,%ymm7
     740:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
     744:	c5 fd fe 84 24 c0 00 	vpaddd 0xc0(%rsp),%ymm0,%ymm0
     74b:	00 00 
     74d:	c5 bd db c9          	vpand  %ymm1,%ymm8,%ymm1
     751:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     755:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     759:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
     75e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     763:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
     768:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
     76d:	c5 b5 fe bc 24 80 00 	vpaddd 0x80(%rsp),%ymm9,%ymm7
     774:	00 00 
     776:	c5 f5 fe e4          	vpaddd %ymm4,%ymm1,%ymm4
     77a:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     77e:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     785:	00 00 
     787:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     78b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     790:	c5 fd 7f 3a          	vmovdqa %ymm7,(%rdx)
     794:	c5 fd 7f 42 40       	vmovdqa %ymm0,0x40(%rdx)
     799:	c5 f8 77             	vzeroupper
     79c:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
     7a3:	00 00 
     7a5:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
     7ac:	00 00 
     7ae:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
     7b5:	00 00 
     7b7:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
     7be:	00 00 
     7c0:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
     7c7:	00 00 
     7c9:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
     7d0:	00 00 
     7d2:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
     7d9:	00 00 
     7db:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
     7e2:	00 00 
     7e4:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
     7eb:	00 00 
     7ed:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
     7f4:	00 00 
     7f6:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
     7fd:	c3                   	ret
     7fe:	66 90                	xchg   %ax,%ax

0000000000000800 <void jshc_packed_store::(anonymous namespace)::transform<false, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>:
     800:	48 81 ec 88 01 00 00 	sub    $0x188,%rsp
     807:	c5 f8 29 b4 24 e0 00 	vmovaps %xmm6,0xe0(%rsp)
     80e:	00 00 
     810:	c5 f8 29 bc 24 f0 00 	vmovaps %xmm7,0xf0(%rsp)
     817:	00 00 
     819:	c5 78 29 84 24 00 01 	vmovaps %xmm8,0x100(%rsp)
     820:	00 00 
     822:	c5 78 29 8c 24 10 01 	vmovaps %xmm9,0x110(%rsp)
     829:	00 00 
     82b:	c5 78 29 94 24 20 01 	vmovaps %xmm10,0x120(%rsp)
     832:	00 00 
     834:	c5 78 29 9c 24 30 01 	vmovaps %xmm11,0x130(%rsp)
     83b:	00 00 
     83d:	c5 78 29 a4 24 40 01 	vmovaps %xmm12,0x140(%rsp)
     844:	00 00 
     846:	c5 78 29 ac 24 50 01 	vmovaps %xmm13,0x150(%rsp)
     84d:	00 00 
     84f:	c5 78 29 b4 24 60 01 	vmovaps %xmm14,0x160(%rsp)
     856:	00 00 
     858:	c5 78 29 bc 24 70 01 	vmovaps %xmm15,0x170(%rsp)
     85f:	00 00 
     861:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
     865:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     869:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     86d:	48 89 d0             	mov    %rdx,%rax
     870:	48 8b 11             	mov    (%rcx),%rdx
     873:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     877:	c5 fd 6f 10          	vmovdqa (%rax),%ymm2
     87b:	44 8b 41 50          	mov    0x50(%rcx),%r8d
     87f:	c4 41 79 6e c9       	vmovd  %r9d,%xmm9
     884:	c4 e2 4d 90 1c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm3
     88a:	48 8b 51 08          	mov    0x8(%rcx),%rdx
     88e:	c5 fd 6f 50 20       	vmovdqa 0x20(%rax),%ymm2
     893:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     897:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     89c:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     8a1:	c4 e2 4d 90 3c 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm7
     8a7:	48 8b 51 10          	mov    0x10(%rcx),%rdx
     8ab:	c5 fd 6f 50 40       	vmovdqa 0x40(%rax),%ymm2
     8b0:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
     8b4:	c5 d5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm5
     8b9:	c4 e2 4d 90 24 92    	vpgatherdd %ymm6,(%rdx,%ymm2,4),%ymm4
     8bf:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     8c4:	c4 c1 79 6e d0       	vmovd  %r8d,%xmm2
     8c9:	48 8b 51 48          	mov    0x48(%rcx),%rdx
     8cd:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     8d2:	c5 cd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm6
     8d7:	47 8d 44 01 01       	lea    0x1(%r9,%r8,1),%r8d
     8dc:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
     8e1:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     8e5:	c5 fd 6f e8          	vmovdqa %ymm0,%ymm5
     8e9:	c5 75 fe de          	vpaddd %ymm6,%ymm1,%ymm11
     8ed:	c5 cd 72 d0 0f       	vpsrld $0xf,%ymm0,%ymm6
     8f2:	c4 a2 55 90 0c 9a    	vpgatherdd %ymm5,(%rdx,%ymm11,4),%ymm1
     8f8:	c5 c5 db fe          	vpand  %ymm6,%ymm7,%ymm7
     8fc:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     900:	c5 7d 6f f9          	vmovdqa %ymm1,%ymm15
     904:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
     909:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     90d:	41 b8 00 80 00 00    	mov    $0x8000,%r8d
     913:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     918:	c4 62 65 3d d7       	vpmaxsd %ymm7,%ymm3,%ymm10
     91d:	c4 62 65 39 c7       	vpminsd %ymm7,%ymm3,%ymm8
     922:	c4 41 75 fe e3       	vpaddd %ymm11,%ymm1,%ymm12
     927:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
     92b:	c4 c1 5d 66 ea       	vpcmpgtd %ymm10,%ymm4,%ymm5
     930:	c4 22 15 90 34 a2    	vpgatherdd %ymm13,(%rdx,%ymm12,4),%ymm14
     936:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     93c:	c4 62 3d 39 ec       	vpminsd %ymm4,%ymm8,%ymm13
     941:	c5 7e 7f 74 24 60    	vmovdqu %ymm14,0x60(%rsp)
     947:	c5 8d 72 d0 1f       	vpsrld $0x1f,%ymm0,%ymm14
     94c:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
     950:	c4 62 2d 3d d4       	vpmaxsd %ymm4,%ymm10,%ymm10
     955:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     95b:	c4 c3 75 4c ce 50    	vpblendvb %ymm5,%ymm14,%ymm1,%ymm1
     961:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
     966:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     96a:	c4 e2 25 90 2c 8a    	vpgatherdd %ymm11,(%rdx,%ymm1,4),%ymm5
     970:	c5 e5 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm1
     974:	c5 7e 7f 24 24       	vmovdqu %ymm12,(%rsp)
     979:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
     97d:	c4 c3 6d 4c c9 10    	vpblendvb %ymm1,%ymm9,%ymm2,%ymm1
     983:	c4 c3 75 4c ce 80    	vpblendvb %ymm8,%ymm14,%ymm1,%ymm1
     989:	c5 7d 6f c0          	vmovdqa %ymm0,%ymm8
     98d:	c5 9d fa c9          	vpsubd %ymm1,%ymm12,%ymm1
     991:	c4 62 3d 90 1c 8a    	vpgatherdd %ymm8,(%rdx,%ymm1,4),%ymm11
     997:	c5 f5 72 d0 18       	vpsrld $0x18,%ymm0,%ymm1
     99c:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
     9a2:	c4 41 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm15
     9a7:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     9ab:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     9af:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     9b4:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
     9b8:	c5 a5 fa e5          	vpsubd %ymm5,%ymm11,%ymm4
     9bc:	c5 75 db 64 24 40    	vpand  0x40(%rsp),%ymm1,%ymm12
     9c2:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
     9c7:	c4 c1 79 6e e0       	vmovd  %r8d,%xmm4
     9cc:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     9d0:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9d5:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
     9db:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     9e0:	c5 3d fe c4          	vpaddd %ymm4,%ymm8,%ymm8
     9e4:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     9e9:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     9f0:	00 00 
     9f2:	c4 41 65 fe c0       	vpaddd %ymm8,%ymm3,%ymm8
     9f7:	c5 f5 db 5c 24 60    	vpand  0x60(%rsp),%ymm1,%ymm3
     9fd:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     a02:	c4 c2 65 40 dd       	vpmulld %ymm13,%ymm3,%ymm3
     a07:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a0b:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     a0f:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
     a13:	c4 c1 05 72 d0 10    	vpsrld $0x10,%ymm8,%ymm15
     a19:	c5 7e 7f bc 24 c0 00 	vmovdqu %ymm15,0xc0(%rsp)
     a20:	00 00 
     a22:	c5 7d 6f 50 40       	vmovdqa 0x40(%rax),%ymm10
     a27:	c5 7d 6f 58 20       	vmovdqa 0x20(%rax),%ymm11
     a2c:	c4 02 15 90 04 90    	vpgatherdd %ymm13,(%r8,%ymm10,4),%ymm8
     a32:	4c 8b 41 20          	mov    0x20(%rcx),%r8
     a36:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a3a:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     a3e:	c4 02 15 90 14 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm10
     a44:	4c 8b 41 18          	mov    0x18(%rcx),%r8
     a48:	c5 7d 6f 18          	vmovdqa (%rax),%ymm11
     a4c:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a50:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     a54:	c4 82 15 90 1c 98    	vpgatherdd %ymm13,(%r8,%ymm11,4),%ymm3
     a5a:	c5 7d 6f d8          	vmovdqa %ymm0,%ymm11
     a5e:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
     a62:	4c 8b 41 40          	mov    0x40(%rcx),%r8
     a66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     a6a:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
     a6f:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
     a73:	c4 c2 65 39 fa       	vpminsd %ymm10,%ymm3,%ymm7
     a78:	c4 c1 3d 66 e4       	vpcmpgtd %ymm12,%ymm8,%ymm4
     a7d:	c4 42 45 39 f8       	vpminsd %ymm8,%ymm7,%ymm15
     a82:	c4 42 1d 3d e0       	vpmaxsd %ymm8,%ymm12,%ymm12
     a87:	c4 c1 45 66 f8       	vpcmpgtd %ymm8,%ymm7,%ymm7
     a8c:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     a92:	c4 c3 55 4c ee 40    	vpblendvb %ymm4,%ymm14,%ymm5,%ymm5
     a98:	c5 d5 fe 6c 24 20    	vpaddd 0x20(%rsp),%ymm5,%ymm5
     a9e:	c4 e2 25 90 24 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm4
     aa4:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
     aa9:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
     aae:	c5 7d 6f 10          	vmovdqa (%rax),%ymm10
     ab2:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     ab7:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     abb:	c4 c3 6d 4c e9 50    	vpblendvb %ymm5,%ymm9,%ymm2,%ymm5
     ac1:	c4 c3 55 4c ee 70    	vpblendvb %ymm7,%ymm14,%ymm5,%ymm5
     ac7:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     acc:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     ad0:	c4 62 15 90 1c aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm11
     ad6:	c5 fe 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm5
     adc:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
     ae3:	00 00 
     ae5:	c4 41 1d fe ff       	vpaddd %ymm15,%ymm12,%ymm15
     aea:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
     af0:	c4 41 3d fa c7       	vpsubd %ymm15,%ymm8,%ymm8
     af5:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     af9:	c5 25 db d9          	vpand  %ymm1,%ymm11,%ymm11
     afd:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
     b02:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
     b06:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     b0c:	c5 15 db e9          	vpand  %ymm1,%ymm13,%ymm13
     b10:	c5 25 fa c4          	vpsubd %ymm4,%ymm11,%ymm8
     b14:	c4 42 65 40 c0       	vpmulld %ymm8,%ymm3,%ymm8
     b19:	c5 c5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm7
     b1e:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
     b23:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
     b28:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
     b2e:	c5 7d 6f 68 40       	vmovdqa 0x40(%rax),%ymm13
     b33:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     b37:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
     b3e:	00 00 
     b40:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     b45:	c4 82 05 90 1c a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm3
     b4b:	c5 7d 6f 68 20       	vmovdqa 0x20(%rax),%ymm13
     b50:	4c 8b 41 38          	mov    0x38(%rcx),%r8
     b54:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b58:	48 8b 49 30          	mov    0x30(%rcx),%rcx
     b5c:	c4 e2 45 40 bc 24 a0 	vpmulld 0xa0(%rsp),%ymm7,%ymm7
     b63:	00 00 00 
     b66:	c5 e5 db de          	vpand  %ymm6,%ymm3,%ymm3
     b6a:	c5 bd fe ed          	vpaddd %ymm5,%ymm8,%ymm5
     b6e:	c4 02 05 90 04 a8    	vpgatherdd %ymm15,(%r8,%ymm13,4),%ymm8
     b74:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b78:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     b7c:	c4 a2 05 90 24 91    	vpgatherdd %ymm15,(%rcx,%ymm10,4),%ymm4
     b82:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     b86:	c5 dd db f6          	vpand  %ymm6,%ymm4,%ymm6
     b8a:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     b8e:	c5 7d 6f f8          	vmovdqa %ymm0,%ymm15
     b92:	c4 42 4d 3d d0       	vpmaxsd %ymm8,%ymm6,%ymm10
     b97:	c5 bd 66 fe          	vpcmpgtd %ymm6,%ymm8,%ymm7
     b9b:	c4 42 4d 39 d8       	vpminsd %ymm8,%ymm6,%ymm11
     ba0:	c4 c1 65 66 e2       	vpcmpgtd %ymm10,%ymm3,%ymm4
     ba5:	c4 62 25 39 e3       	vpminsd %ymm3,%ymm11,%ymm12
     baa:	c4 62 2d 3d d3       	vpmaxsd %ymm3,%ymm10,%ymm10
     baf:	c5 25 66 db          	vpcmpgtd %ymm3,%ymm11,%ymm11
     bb3:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     bb8:	c4 c3 6d 4c f9 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm7
     bbe:	c4 c3 45 4c fe 40    	vpblendvb %ymm4,%ymm14,%ymm7,%ymm7
     bc4:	c5 c5 fe 7c 24 20    	vpaddd 0x20(%rsp),%ymm7,%ymm7
     bca:	c4 e2 05 90 24 ba    	vpgatherdd %ymm15,(%rdx,%ymm7,4),%ymm4
     bd0:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     bd5:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
     bda:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
     be1:	00 00 
     be3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     be8:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
     bec:	c4 c3 6d 4c d1 70    	vpblendvb %ymm7,%ymm9,%ymm2,%ymm2
     bf2:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     bf7:	c4 c3 6d 4c d6 b0    	vpblendvb %ymm11,%ymm14,%ymm2,%ymm2
     bfd:	c5 7e 6f 74 24 60    	vmovdqu 0x60(%rsp),%ymm14
     c03:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
     c07:	c4 62 7d 90 0c 92    	vpgatherdd %ymm0,(%rdx,%ymm2,4),%ymm9
     c0d:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
     c13:	c4 c1 2d fe c4       	vpaddd %ymm12,%ymm10,%ymm0
     c18:	c5 7d 7f 38          	vmovdqa %ymm15,(%rax)
     c1c:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
     c22:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     c28:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
     c2c:	c5 fd 7f 68 20       	vmovdqa %ymm5,0x20(%rax)
     c31:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     c36:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
     c3a:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     c3e:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     c42:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
     c46:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     c4a:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     c4f:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
     c53:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     c58:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     c5d:	c4 c2 45 40 fc       	vpmulld %ymm12,%ymm7,%ymm7
     c62:	c5 a5 72 f2 10       	vpslld $0x10,%ymm2,%ymm11
     c67:	c5 25 fe 9c 24 80 00 	vpaddd 0x80(%rsp),%ymm11,%ymm11
     c6e:	00 00 
     c70:	c4 c1 7d fe c3       	vpaddd %ymm11,%ymm0,%ymm0
     c75:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     c79:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     c7d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     c82:	c5 fd 7f 40 40       	vmovdqa %ymm0,0x40(%rax)
     c87:	c5 f8 77             	vzeroupper
     c8a:	c5 f8 28 b4 24 e0 00 	vmovaps 0xe0(%rsp),%xmm6
     c91:	00 00 
     c93:	c5 f8 28 bc 24 f0 00 	vmovaps 0xf0(%rsp),%xmm7
     c9a:	00 00 
     c9c:	c5 78 28 84 24 00 01 	vmovaps 0x100(%rsp),%xmm8
     ca3:	00 00 
     ca5:	c5 78 28 8c 24 10 01 	vmovaps 0x110(%rsp),%xmm9
     cac:	00 00 
     cae:	c5 78 28 94 24 20 01 	vmovaps 0x120(%rsp),%xmm10
     cb5:	00 00 
     cb7:	c5 78 28 9c 24 30 01 	vmovaps 0x130(%rsp),%xmm11
     cbe:	00 00 
     cc0:	c5 78 28 a4 24 40 01 	vmovaps 0x140(%rsp),%xmm12
     cc7:	00 00 
     cc9:	c5 78 28 ac 24 50 01 	vmovaps 0x150(%rsp),%xmm13
     cd0:	00 00 
     cd2:	c5 78 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm14
     cd9:	00 00 
     cdb:	c5 78 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm15
     ce2:	00 00 
     ce4:	48 81 c4 88 01 00 00 	add    $0x188,%rsp
     ceb:	c3                   	ret
     cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000000cf0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     cf0:	41 56                	push   %r14
     cf2:	41 55                	push   %r13
     cf4:	41 54                	push   %r12
     cf6:	55                   	push   %rbp
     cf7:	57                   	push   %rdi
     cf8:	56                   	push   %rsi
     cf9:	53                   	push   %rbx
     cfa:	48 81 ec 70 04 00 00 	sub    $0x470,%rsp
     d01:	c5 f8 29 b4 24 d0 03 	vmovaps %xmm6,0x3d0(%rsp)
     d08:	00 00 
     d0a:	c5 f8 29 bc 24 e0 03 	vmovaps %xmm7,0x3e0(%rsp)
     d11:	00 00 
     d13:	c5 78 29 84 24 f0 03 	vmovaps %xmm8,0x3f0(%rsp)
     d1a:	00 00 
     d1c:	c5 78 29 8c 24 00 04 	vmovaps %xmm9,0x400(%rsp)
     d23:	00 00 
     d25:	c5 78 29 94 24 10 04 	vmovaps %xmm10,0x410(%rsp)
     d2c:	00 00 
     d2e:	c5 78 29 9c 24 20 04 	vmovaps %xmm11,0x420(%rsp)
     d35:	00 00 
     d37:	c5 78 29 a4 24 30 04 	vmovaps %xmm12,0x430(%rsp)
     d3e:	00 00 
     d40:	c5 78 29 ac 24 40 04 	vmovaps %xmm13,0x440(%rsp)
     d47:	00 00 
     d49:	c5 78 29 b4 24 50 04 	vmovaps %xmm14,0x450(%rsp)
     d50:	00 00 
     d52:	c5 78 29 bc 24 60 04 	vmovaps %xmm15,0x460(%rsp)
     d59:	00 00 
     d5b:	c4 e2 7d 58 62 08    	vpbroadcastd 0x8(%rdx),%ymm4
     d61:	c4 e2 7d 58 7a 14    	vpbroadcastd 0x14(%rdx),%ymm7
     d67:	48 8d 9c 24 5f 02 00 	lea    0x25f(%rsp),%rbx
     d6e:	00 
     d6f:	49 89 ca             	mov    %rcx,%r10
     d72:	48 83 e3 e0          	and    $0xffffffffffffffe0,%rbx
     d76:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     d7d:	0f b6 41 58          	movzbl 0x58(%rcx),%eax
     d81:	48 89 d7             	mov    %rdx,%rdi
     d84:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     d8a:	c4 e2 7d 58 62 0c    	vpbroadcastd 0xc(%rdx),%ymm4
     d90:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     d97:	00 00 
     d99:	c4 e2 7d 58 7a 1c    	vpbroadcastd 0x1c(%rdx),%ymm7
     d9f:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     da5:	c4 e2 7d 58 62 10    	vpbroadcastd 0x10(%rdx),%ymm4
     dab:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     db2:	00 00 
     db4:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     dbb:	00 00 
     dbd:	c4 e2 7d 58 62 18    	vpbroadcastd 0x18(%rdx),%ymm4
     dc3:	c5 fe 7f a4 24 c0 00 	vmovdqu %ymm4,0xc0(%rsp)
     dca:	00 00 
     dcc:	0f 84 0e 06 00 00    	je     13e0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6f0>
     dd2:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     dd9:	0f 84 01 06 00 00    	je     13e0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6f0>
     ddf:	0f b6 91 78 01 00 00 	movzbl 0x178(%rcx),%edx
     de6:	84 c0                	test   %al,%al
     de8:	0f 85 2a 24 00 00    	jne    3218 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2528>
     dee:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
     df2:	0f 84 c8 10 00 00    	je     1ec0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x11d0>
     df8:	84 d2                	test   %dl,%dl
     dfa:	0f 84 43 0a 00 00    	je     1843 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb53>
     e00:	4d 85 c9             	test   %r9,%r9
     e03:	0f 84 8a 16 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
     e09:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # e71 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x181>
     e10:	00 
     e11:	b8 00 80 00 00       	mov    $0x8000,%eax
     e16:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # e9e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ae>
     e1d:	00 
     e1e:	49 8d 71 ff          	lea    -0x1(%r9),%rsi
     e22:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
     e27:	4d 89 c3             	mov    %r8,%r11
     e2a:	48 c1 ee 03          	shr    $0x3,%rsi
     e2e:	31 ed                	xor    %ebp,%ebp
     e30:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     e37:	00 00 
     e39:	c5 f9 6e f8          	vmovd  %eax,%xmm7
     e3d:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
     e43:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     e48:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
     e4f:	00 00 
     e51:	c5 fe 7f bc 24 e0 01 	vmovdqu %ymm7,0x1e0(%rsp)
     e58:	00 00 
     e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     e60:	c4 c1 7a 6f 0b       	vmovdqu (%r11),%xmm1
     e65:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
     e6b:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     e6f:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
     e73:	49 8b 02             	mov    (%r10),%rax
     e76:	41 8b 4a 54          	mov    0x54(%r10),%ecx
     e7a:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     e7f:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     e84:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
     e8a:	41 8b 52 50          	mov    0x50(%r10),%edx
     e8e:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
     e93:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     e99:	c5 79 6e e9          	vmovd  %ecx,%xmm13
     e9d:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
     ea4:	01 00 00 
     ea7:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     eac:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
     eb1:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
     eb6:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     ebb:	c4 e2 5d 90 2c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm5
     ec1:	49 8b 42 08          	mov    0x8(%r10),%rax
     ec5:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     eca:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     ece:	c5 bd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm8
     ed3:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # efb <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20b>
     eda:	00 
     edb:	c4 e2 45 90 14 b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm2
     ee1:	49 8b 42 10          	mov    0x10(%r10),%rax
     ee5:	c5 c5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm7
     eea:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # f12 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x222>
     ef1:	00 
     ef2:	c4 e2 5d 90 04 98    	vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm0
     ef8:	c4 c2 45 40 fd       	vpmulld %ymm13,%ymm7,%ymm7
     efd:	c5 f9 6e e2          	vmovd  %edx,%xmm4
     f01:	49 8b 42 48          	mov    0x48(%r10),%rax
     f05:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     f0a:	c5 b5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm9
     f0f:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
     f13:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
     f18:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # f40 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x250>
     f1f:	00 
     f20:	c4 c1 45 fe f8       	vpaddd %ymm8,%ymm7,%ymm7
     f25:	c4 41 45 fe c9       	vpaddd %ymm9,%ymm7,%ymm9
     f2a:	c4 a2 25 90 3c 88    	vpgatherdd %ymm11,(%rax,%ymm9,4),%ymm7
     f30:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
     f37:	00 00 
     f39:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     f3d:	49 8b 52 18          	mov    0x18(%r10),%rdx
     f41:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     f46:	c4 41 45 fe c1       	vpaddd %ymm9,%ymm7,%ymm8
     f4b:	c4 e2 55 39 fa       	vpminsd %ymm2,%ymm5,%ymm7
     f50:	c4 22 2d 90 1c 80    	vpgatherdd %ymm10,(%rax,%ymm8,4),%ymm11
     f56:	c5 7e 7f 9c 24 a0 01 	vmovdqu %ymm11,0x1a0(%rsp)
     f5d:	00 00 
     f5f:	c4 62 1d 90 1c 8a    	vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm11
     f65:	49 8b 52 20          	mov    0x20(%r10),%rdx
     f69:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     f6d:	c4 62 75 90 14 b2    	vpgatherdd %ymm1,(%rdx,%ymm6,4),%ymm10
     f73:	49 8b 52 28          	mov    0x28(%r10),%rdx
     f77:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     f7b:	c4 62 4d 90 24 9a    	vpgatherdd %ymm6,(%rdx,%ymm3,4),%ymm12
     f81:	c5 ed 66 dd          	vpcmpgtd %ymm5,%ymm2,%ymm3
     f85:	c4 e2 55 3d f2       	vpmaxsd %ymm2,%ymm5,%ymm6
     f8a:	c5 7e 7f 6c 24 20    	vmovdqu %ymm13,0x20(%rsp)
     f90:	c5 fd 66 ce          	vpcmpgtd %ymm6,%ymm0,%ymm1
     f94:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
     f99:	c5 7e 7f 8c 24 40 01 	vmovdqu %ymm9,0x140(%rsp)
     fa0:	00 00 
     fa2:	c4 62 45 39 e8       	vpminsd %ymm0,%ymm7,%ymm13
     fa7:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
     fae:	00 00 
     fb0:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     fb4:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
     fb8:	c4 e3 5d 4c 5c 24 20 	vpblendvb %ymm3,0x20(%rsp),%ymm4,%ymm3
     fbf:	30 
     fc0:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm1,-0x1(%rip),%ymm3,%ymm3        # fc9 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d9>
     fc7:	ff ff 10 
     fca:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
     fcf:	c5 55 fe ca          	vpaddd %ymm2,%ymm5,%ymm9
     fd3:	c4 e2 4d 90 0c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm1
     fd9:	c5 d5 66 da          	vpcmpgtd %ymm2,%ymm5,%ymm3
     fdd:	c5 7e 7f 84 24 80 01 	vmovdqu %ymm8,0x180(%rsp)
     fe4:	00 00 
     fe6:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     fea:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     fef:	c4 e3 5d 4c 5c 24 20 	vpblendvb %ymm3,0x20(%rsp),%ymm4,%ymm3
     ff6:	30 
     ff7:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 1000 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x310>
     ffe:	ff ff 70 
    1001:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
    1005:	c4 41 7d 6f c5       	vmovdqa %ymm13,%ymm8
    100a:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    1010:	c5 7e 7f ac 24 c0 01 	vmovdqu %ymm13,0x1c0(%rsp)
    1017:	00 00 
    1019:	c5 7e 6f ac 24 00 02 	vmovdqu 0x200(%rsp),%ymm13
    1020:	00 00 
    1022:	c5 85 db b4 24 60 01 	vpand  0x160(%rsp),%ymm15,%ymm6
    1029:	00 00 
    102b:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    1030:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    1035:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    103a:	c4 41 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm8
    103f:	c5 e5 fe 9c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm3,%ymm3
    1046:	00 00 
    1048:	c4 41 3d fe c9       	vpaddd %ymm9,%ymm8,%ymm9
    104d:	c5 45 fa c1          	vpsubd %ymm1,%ymm7,%ymm8
    1051:	c4 42 35 40 c0       	vpmulld %ymm8,%ymm9,%ymm8
    1056:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    105a:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    105f:	c4 c1 4d 72 e3 10    	vpsrad $0x10,%ymm11,%ymm6
    1065:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    106a:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    106e:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    1072:	c5 05 db 84 24 a0 01 	vpand  0x1a0(%rsp),%ymm15,%ymm8
    1079:	00 00 
    107b:	c5 3d fa c7          	vpsubd %ymm7,%ymm8,%ymm8
    107f:	c4 62 3d 40 84 24 c0 	vpmulld 0x1c0(%rsp),%ymm8,%ymm8
    1086:	01 00 00 
    1089:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    108d:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1092:	c5 c5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm7
    1097:	c4 c1 65 72 f4 10    	vpslld $0x10,%ymm12,%ymm3
    109d:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    10a4:	00 00 
    10a6:	c4 c1 45 72 e2 10    	vpsrad $0x10,%ymm10,%ymm7
    10ac:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    10b1:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
    10b5:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    10b9:	c5 cd fe cf          	vpaddd %ymm7,%ymm6,%ymm1
    10bd:	c5 fe 7f 8c 24 00 02 	vmovdqu %ymm1,0x200(%rsp)
    10c4:	00 00 
    10c6:	c4 c1 75 72 e4 10    	vpsrad $0x10,%ymm12,%ymm1
    10cc:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    10d0:	c4 c1 7d 72 f2 10    	vpslld $0x10,%ymm10,%ymm0
    10d6:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    10db:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    10df:	c4 c1 6d 72 f3 10    	vpslld $0x10,%ymm11,%ymm2
    10e5:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    10ea:	c5 65 fe d0          	vpaddd %ymm0,%ymm3,%ymm10
    10ee:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    10f2:	c4 62 6d 3d c0       	vpmaxsd %ymm0,%ymm2,%ymm8
    10f7:	c5 7d 66 da          	vpcmpgtd %ymm2,%ymm0,%ymm11
    10fb:	c4 62 6d 39 e0       	vpminsd %ymm0,%ymm2,%ymm12
    1100:	c4 c1 65 66 e8       	vpcmpgtd %ymm8,%ymm3,%ymm5
    1105:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    1109:	c4 62 1d 39 cb       	vpminsd %ymm3,%ymm12,%ymm9
    110e:	c5 1d 66 e3          	vpcmpgtd %ymm3,%ymm12,%ymm12
    1112:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    1117:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    111e:	00 00 
    1120:	c4 63 5d 4c 5c 24 20 	vpblendvb %ymm11,0x20(%rsp),%ymm4,%ymm11
    1127:	b0 
    1128:	c4 63 25 4c 1d ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm11,%ymm11        # 1131 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x441>
    112f:	ff ff 50 
    1132:	c4 e3 5d 4c 44 24 20 	vpblendvb %ymm0,0x20(%rsp),%ymm4,%ymm0
    1139:	00 
    113a:	c5 25 fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm11,%ymm11
    1141:	00 00 
    1143:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm0,%ymm0        # 114c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x45c>
    114a:	ff ff c0 
    114d:	c5 e5 fa c0          	vpsubd %ymm0,%ymm3,%ymm0
    1151:	c4 a2 15 90 2c 98    	vpgatherdd %ymm13,(%rax,%ymm11,4),%ymm5
    1157:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    115c:	c4 62 15 90 1c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm11
    1162:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    1169:	00 00 
    116b:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    1170:	c4 41 3d fe e9       	vpaddd %ymm9,%ymm8,%ymm13
    1175:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    117b:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1180:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    1185:	c5 9d 72 d0 08       	vpsrld $0x8,%ymm0,%ymm12
    118a:	c5 fe 6f 84 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm0
    1191:	00 00 
    1193:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1198:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    119d:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
    11a2:	c5 25 fa d5          	vpsubd %ymm5,%ymm11,%ymm10
    11a6:	c5 7e 6f ac 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm13
    11ad:	00 00 
    11af:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    11b4:	c4 42 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm10
    11b9:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    11be:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    11c3:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    11c8:	c4 62 4d 39 c7       	vpminsd %ymm7,%ymm6,%ymm8
    11cd:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    11d2:	c4 c1 7d 72 f4 10    	vpslld $0x10,%ymm12,%ymm0
    11d8:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
    11de:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    11e3:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    11e8:	c4 c1 7d fe c5       	vpaddd %ymm13,%ymm0,%ymm0
    11ed:	c4 62 3d 39 c9       	vpminsd %ymm1,%ymm8,%ymm9
    11f2:	c5 3d 66 c1          	vpcmpgtd %ymm1,%ymm8,%ymm8
    11f6:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    11fa:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    11fe:	c4 e2 4d 3d ef       	vpmaxsd %ymm7,%ymm6,%ymm5
    1203:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1207:	c5 c5 66 de          	vpcmpgtd %ymm6,%ymm7,%ymm3
    120b:	c5 f5 66 d5          	vpcmpgtd %ymm5,%ymm1,%ymm2
    120f:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    1213:	c4 e2 55 3d e9       	vpmaxsd %ymm1,%ymm5,%ymm5
    1218:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    121d:	c4 c3 5d 4c db 30    	vpblendvb %ymm3,%ymm11,%ymm4,%ymm3
    1223:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm3        # 122c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x53c>
    122a:	ff ff 20 
    122d:	c4 c3 5d 4c e3 60    	vpblendvb %ymm6,%ymm11,%ymm4,%ymm4
    1233:	c5 7e 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm11
    123a:	00 00 
    123c:	c5 e5 fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm3,%ymm3
    1243:	00 00 
    1245:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm4,%ymm4        # 124e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x55e>
    124c:	ff ff 80 
    124f:	c4 41 55 fe c1       	vpaddd %ymm9,%ymm5,%ymm8
    1254:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    1259:	c4 e2 1d 90 14 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm2
    125f:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    1266:	00 00 
    1268:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    126d:	c5 f5 fe 8c 24 00 02 	vpaddd 0x200(%rsp),%ymm1,%ymm1
    1274:	00 00 
    1276:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    127b:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    127f:	c5 fe 6f a4 24 60 01 	vmovdqu 0x160(%rsp),%ymm4
    1286:	00 00 
    1288:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    128d:	c4 e2 1d 90 34 98    	vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm6
    1293:	c4 c1 65 72 d3 10    	vpsrld $0x10,%ymm11,%ymm3
    1299:	c5 7e 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm12
    12a0:	00 00 
    12a2:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
    12a9:	00 00 
    12ab:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    12b0:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    12b5:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    12ba:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    12bf:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    12c4:	c5 4d fa c2          	vpsubd %ymm2,%ymm6,%ymm8
    12c8:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    12cc:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    12d1:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    12d5:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    12da:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    12df:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
    12e5:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    12ea:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    12ef:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
    12f3:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    12fa:	00 00 
    12fc:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1300:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1304:	c5 fd fa df          	vpsubd %ymm7,%ymm0,%ymm3
    1308:	c5 c5 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm7,%ymm6
    130e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1313:	c5 a5 66 d3          	vpcmpgtd %ymm3,%ymm11,%ymm2
    1317:	c5 f5 fa e7          	vpsubd %ymm7,%ymm1,%ymm4
    131b:	c5 9d 66 ec          	vpcmpgtd %ymm4,%ymm12,%ymm5
    131f:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    1323:	c5 dd 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm4,%ymm5
    132a:	00 00 
    132c:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    1330:	c5 95 66 ef          	vpcmpgtd %ymm7,%ymm13,%ymm5
    1334:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    1338:	c5 e5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm6
    133f:	00 00 
    1341:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    1345:	c5 ed eb d5          	vpor   %ymm5,%ymm2,%ymm2
    1349:	c5 fd d7 c2          	vpmovmskb %ymm2,%eax
    134d:	85 c0                	test   %eax,%eax
    134f:	0f 85 5b 29 00 00    	jne    3cb0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fc0>
    1355:	8b 47 24             	mov    0x24(%rdi),%eax
    1358:	8b 57 20             	mov    0x20(%rdi),%edx
    135b:	c4 c1 65 fa c3       	vpsubd %ymm11,%ymm3,%ymm0
    1360:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    1365:	0f af d0             	imul   %eax,%edx
    1368:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    136c:	48 8b 07             	mov    (%rdi),%rax
    136f:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1374:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    1379:	c4 c1 45 fa cd       	vpsubd %ymm13,%ymm7,%ymm1
    137e:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1382:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1387:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    138c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1390:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1394:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    1398:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
    139e:	c4 e2 75 00 84 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm0
    13a5:	01 00 00 
    13a8:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    13ac:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    13b2:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    13b7:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    13bc:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    13c0:	c4 c1 79 d6 43 10    	vmovq  %xmm0,0x10(%r11)
    13c6:	c4 c1 7a 7f 0b       	vmovdqu %xmm1,(%r11)
    13cb:	48 39 ee             	cmp    %rbp,%rsi
    13ce:	0f 84 bf 10 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    13d4:	48 ff c5             	inc    %rbp
    13d7:	49 83 c3 18          	add    $0x18,%r11
    13db:	e9 80 fa ff ff       	jmp    e60 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x170>
    13e0:	84 c0                	test   %al,%al
    13e2:	0f 84 50 04 00 00    	je     1838 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb48>
    13e8:	4d 85 c9             	test   %r9,%r9
    13eb:	0f 84 a2 10 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    13f1:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # 1459 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x769>
    13f8:	00 
    13f9:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 1481 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x791>
    1400:	00 
    1401:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    1405:	4d 89 c3             	mov    %r8,%r11
    1408:	48 c1 ed 03          	shr    $0x3,%rbp
    140c:	45 31 e4             	xor    %r12d,%r12d
    140f:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    1414:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    141b:	00 00 
    141d:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
    1424:	00 00 
    1426:	e9 8c 00 00 00       	jmp    14b7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c7>
    142b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1430:	8b 47 24             	mov    0x24(%rdi),%eax
    1433:	8b 57 20             	mov    0x20(%rdi),%edx
    1436:	c4 c1 5d fa c6       	vpsubd %ymm14,%ymm4,%ymm0
    143b:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    1440:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    1445:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1449:	0f af d0             	imul   %eax,%edx
    144c:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    1450:	48 8b 07             	mov    (%rdi),%rax
    1453:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1458:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    145d:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    1461:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1466:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
    146b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    146f:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1473:	c4 e2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm1
    1479:	c4 e2 75 00 84 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm0
    1480:	01 00 00 
    1483:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1487:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    148d:	49 83 c3 18          	add    $0x18,%r11
    1491:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1496:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    149b:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    149f:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    14a5:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    14ab:	4c 39 e5             	cmp    %r12,%rbp
    14ae:	0f 84 df 0f 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    14b4:	49 ff c4             	inc    %r12
    14b7:	c4 c1 7a 6f 0b       	vmovdqu (%r11),%xmm1
    14bc:	c4 c1 7a 7e 43 10    	vmovq  0x10(%r11),%xmm0
    14c2:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    14c6:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    14ca:	49 8b 02             	mov    (%r10),%rax
    14cd:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    14d1:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
    14d7:	41 8b 52 50          	mov    0x50(%r10),%edx
    14db:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
    14e1:	c4 c1 7d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm0
    14e7:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    14eb:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
    14f2:	01 00 00 
    14f5:	c5 79 6e d2          	vmovd  %edx,%xmm10
    14f9:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    14fe:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    1503:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    1508:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    150c:	c4 e2 45 90 24 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm4
    1512:	49 8b 42 08          	mov    0x8(%r10),%rax
    1516:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
    151a:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    151e:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1523:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1527:	c4 e2 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm6
    152d:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    1532:	49 8b 42 10          	mov    0x10(%r10),%rax
    1536:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 155e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x86e>
    153d:	00 
    153e:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1543:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1548:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 1570 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x880>
    154f:	00 
    1550:	c4 c2 6d 40 d6       	vpmulld %ymm14,%ymm2,%ymm2
    1555:	c4 e2 55 90 3c 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm7
    155b:	49 8b 42 48          	mov    0x48(%r10),%rax
    155f:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    1563:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    1568:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 1590 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8a0>
    156f:	00 
    1570:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    1575:	c4 62 5d 39 ee       	vpminsd %ymm6,%ymm4,%ymm13
    157a:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    157f:	c4 62 15 39 e7       	vpminsd %ymm7,%ymm13,%ymm12
    1584:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    1589:	c5 15 66 ef          	vpcmpgtd %ymm7,%ymm13,%ymm13
    158d:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1591:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1595:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1599:	c4 62 55 90 3c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm15
    159f:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    15a3:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    15a8:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    15ac:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    15b2:	c4 e2 65 90 0c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm1
    15b8:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    15bc:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
    15c0:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    15c4:	c4 c3 2d 4c de 30    	vpblendvb %ymm3,%ymm14,%ymm10,%ymm3
    15ca:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 15d3 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8e3>
    15d1:	ff ff 80 
    15d4:	c4 41 35 fe c4       	vpaddd %ymm12,%ymm9,%ymm8
    15d9:	c4 43 2d 4c d6 40    	vpblendvb %ymm4,%ymm14,%ymm10,%ymm10
    15df:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    15e4:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    15ea:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm10,%ymm10        # 15f3 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x903>
    15f1:	ff ff d0 
    15f4:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    15f8:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    15fc:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    1600:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
    1606:	c4 c1 45 fa ea       	vpsubd %ymm10,%ymm7,%ymm5
    160b:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    160f:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    1615:	c5 85 db d0          	vpand  %ymm0,%ymm15,%ymm2
    1619:	c5 e5 db f8          	vpand  %ymm0,%ymm3,%ymm7
    161d:	b8 00 80 00 00       	mov    $0x8000,%eax
    1622:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
    1626:	c5 cd 72 f2 10       	vpslld $0x10,%ymm2,%ymm6
    162b:	c5 75 db d0          	vpand  %ymm0,%ymm1,%ymm10
    162f:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
    1633:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    1637:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    163c:	c4 42 2d 40 d4       	vpmulld %ymm12,%ymm10,%ymm10
    1641:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    1646:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
    164a:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    164f:	c4 c1 45 72 d7 08    	vpsrld $0x8,%ymm15,%ymm7
    1655:	c5 15 db e8          	vpand  %ymm0,%ymm13,%ymm13
    1659:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    165d:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1662:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1667:	c5 95 fa ff          	vpsubd %ymm7,%ymm13,%ymm7
    166b:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    166f:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1674:	c5 ad fe d2          	vpaddd %ymm2,%ymm10,%ymm2
    1678:	c5 79 6e d0          	vmovd  %eax,%xmm10
    167c:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1681:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    1686:	c4 41 0d fe f2       	vpaddd %ymm10,%ymm14,%ymm14
    168b:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    168f:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    1694:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1698:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    169d:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    16a1:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    16a6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    16ab:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    16af:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    16b3:	c4 c1 4d fa f5       	vpsubd %ymm13,%ymm6,%ymm6
    16b8:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    16bc:	c4 c2 55 40 ec       	vpmulld %ymm12,%ymm5,%ymm5
    16c1:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    16c6:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    16ca:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    16ce:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    16d2:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    16d7:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    16dc:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    16e1:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    16e6:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    16ea:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    16f1:	00 00 
    16f3:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    16f7:	c4 c1 4d 72 d7 10    	vpsrld $0x10,%ymm15,%ymm6
    16fd:	c5 7e 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm15
    1704:	00 00 
    1706:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    170a:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    170f:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    1714:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    1718:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    171d:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
    1722:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1726:	c5 f5 fe c6          	vpaddd %ymm6,%ymm1,%ymm0
    172a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    172e:	c5 d5 fa e2          	vpsubd %ymm2,%ymm5,%ymm4
    1732:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1737:	c5 8d 66 cc          	vpcmpgtd %ymm4,%ymm14,%ymm1
    173b:	c5 fd fa da          	vpsubd %ymm2,%ymm0,%ymm3
    173f:	c5 85 66 f3          	vpcmpgtd %ymm3,%ymm15,%ymm6
    1743:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    1747:	c5 e5 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm3,%ymm6
    174e:	00 00 
    1750:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    1756:	c5 ed 66 7c 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm7
    175c:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    1760:	c5 9d 66 f2          	vpcmpgtd %ymm2,%ymm12,%ymm6
    1764:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    1768:	c5 dd 66 bc 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm4,%ymm7
    176f:	00 00 
    1771:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    1775:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    1779:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
    177d:	85 c0                	test   %eax,%eax
    177f:	0f 84 ab fc ff ff    	je     1430 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x740>
    1785:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    178b:	c5 7d 6f f5          	vmovdqa %ymm5,%ymm14
    178f:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    1793:	49 8d 72 60          	lea    0x60(%r10),%rsi
    1797:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    179e:	80 7e 58 00          	cmpb   $0x0,0x58(%rsi)
    17a2:	0f 85 c8 11 00 00    	jne    2970 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c80>
    17a8:	80 7e 59 00          	cmpb   $0x0,0x59(%rsi)
    17ac:	0f 84 56 0d 00 00    	je     2508 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1818>
    17b2:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    17b8:	c5 7d 7f b3 40 01 00 	vmovdqa %ymm14,0x140(%rbx)
    17bf:	00 
    17c0:	48 8d 93 20 01 00 00 	lea    0x120(%rbx),%rdx
    17c7:	48 89 f1             	mov    %rsi,%rcx
    17ca:	c5 7d 7f ab 60 01 00 	vmovdqa %ymm13,0x160(%rbx)
    17d1:	00 
    17d2:	c5 fd 7f a3 20 01 00 	vmovdqa %ymm4,0x120(%rbx)
    17d9:	00 
    17da:	c5 f8 77             	vzeroupper
    17dd:	e8 fe ea ff ff       	call   2e0 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    17e2:	c5 fd 6f bb 20 01 00 	vmovdqa 0x120(%rbx),%ymm7
    17e9:	00 
    17ea:	c5 7d 6f b3 40 01 00 	vmovdqa 0x140(%rbx),%ymm14
    17f1:	00 
    17f2:	c5 7d 6f ab 60 01 00 	vmovdqa 0x160(%rbx),%ymm13
    17f9:	00 
    17fa:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    17ff:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    1805:	48 83 c6 60          	add    $0x60,%rsi
    1809:	49 39 f5             	cmp    %rsi,%r13
    180c:	75 90                	jne    179e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xaae>
    180e:	c4 c1 75 72 f5 10    	vpslld $0x10,%ymm13,%ymm1
    1814:	c4 c1 7d 72 f6 08    	vpslld $0x8,%ymm14,%ymm0
    181a:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    181e:	c5 fd eb 44 24 20    	vpor   0x20(%rsp),%ymm0,%ymm0
    1824:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    182b:	01 00 00 
    182e:	e9 50 fc ff ff       	jmp    1483 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x793>
    1833:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1838:	41 80 7a 59 00       	cmpb   $0x0,0x59(%r10)
    183d:	0f 84 75 13 00 00    	je     2bb8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ec8>
    1843:	4d 85 c9             	test   %r9,%r9
    1846:	0f 84 47 0c 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    184c:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 18b4 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbc4>
    1853:	00 
    1854:	b8 00 80 00 00       	mov    $0x8000,%eax
    1859:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 18e1 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbf1>
    1860:	00 
    1861:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    1865:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    186a:	4d 89 c3             	mov    %r8,%r11
    186d:	48 c1 ed 03          	shr    $0x3,%rbp
    1871:	45 31 e4             	xor    %r12d,%r12d
    1874:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    187b:	00 00 
    187d:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    1881:	c4 c1 05 72 d4 18    	vpsrld $0x18,%ymm12,%ymm15
    1887:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    188c:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    1893:	00 00 
    1895:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
    189c:	00 00 
    189e:	e9 8c 00 00 00       	jmp    192f <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc3f>
    18a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    18a8:	8b 47 24             	mov    0x24(%rdi),%eax
    18ab:	8b 57 20             	mov    0x20(%rdi),%edx
    18ae:	c4 c1 6d fa c6       	vpsubd %ymm14,%ymm2,%ymm0
    18b3:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    18b8:	0f af d0             	imul   %eax,%edx
    18bb:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    18bf:	48 8b 07             	mov    (%rdi),%rax
    18c2:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    18c7:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    18cc:	c4 c1 45 fa cd       	vpsubd %ymm13,%ymm7,%ymm1
    18d1:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    18d5:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    18da:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    18df:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    18e3:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    18e7:	c5 7d 7f e4          	vmovdqa %ymm12,%ymm4
    18eb:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
    18f1:	c4 e2 75 00 84 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm0
    18f8:	01 00 00 
    18fb:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    18ff:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1905:	49 83 c3 18          	add    $0x18,%r11
    1909:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    190e:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1913:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1917:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    191d:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    1923:	4c 39 e5             	cmp    %r12,%rbp
    1926:	0f 84 67 0b 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    192c:	49 ff c4             	inc    %r12
    192f:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    1934:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    193a:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    193e:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
    1943:	49 8b 02             	mov    (%r10),%rax
    1946:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    194a:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    194f:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1955:	41 8b 52 50          	mov    0x50(%r10),%edx
    1959:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    195f:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    1963:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    196a:	01 00 00 
    196d:	c5 79 6e f2          	vmovd  %edx,%xmm14
    1971:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    1976:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
    197b:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
    1980:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1985:	c4 e2 45 90 24 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
    198b:	49 8b 42 08          	mov    0x8(%r10),%rax
    198f:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1994:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    1998:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    199d:	c5 bd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm8
    19a2:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    19a6:	c4 e2 45 90 14 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm2
    19ac:	c4 42 3d 40 c6       	vpmulld %ymm14,%ymm8,%ymm8
    19b1:	49 8b 42 10          	mov    0x10(%r10),%rax
    19b5:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
    19b9:	c5 cd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm6
    19be:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    19c3:	c4 e2 45 90 0c 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm1
    19c9:	49 8b 42 48          	mov    0x48(%r10),%rax
    19cd:	c5 c5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm7
    19d2:	c4 c1 4d fe f0       	vpaddd %ymm8,%ymm6,%ymm6
    19d7:	c5 4d fe c7          	vpaddd %ymm7,%ymm6,%ymm8
    19db:	c4 c1 4d 72 d4 0f    	vpsrld $0xf,%ymm12,%ymm6
    19e1:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
    19e5:	c5 ed db d6          	vpand  %ymm6,%ymm2,%ymm2
    19e9:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
    19ed:	c5 7d 7f e6          	vmovdqa %ymm12,%ymm6
    19f1:	c4 a2 4d 90 3c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
    19f7:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    19fb:	49 8b 52 18          	mov    0x18(%r10),%rdx
    19ff:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    1a04:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    1a0b:	00 00 
    1a0d:	c4 c1 4d fe f8       	vpaddd %ymm8,%ymm6,%ymm7
    1a12:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    1a18:	c4 e2 25 90 34 b8    	vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm6
    1a1e:	c4 c1 45 72 d4 1f    	vpsrld $0x1f,%ymm12,%ymm7
    1a24:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    1a2b:	00 00 
    1a2d:	c4 e2 5d 39 f2       	vpminsd %ymm2,%ymm4,%ymm6
    1a32:	c4 62 2d 90 1c 82    	vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm11
    1a38:	49 8b 52 20          	mov    0x20(%r10),%rdx
    1a3c:	c5 7d 7f e0          	vmovdqa %ymm12,%ymm0
    1a40:	c4 62 7d 90 14 aa    	vpgatherdd %ymm0,(%rdx,%ymm5,4),%ymm10
    1a46:	49 8b 52 28          	mov    0x28(%r10),%rdx
    1a4a:	c5 7d 7f e0          	vmovdqa %ymm12,%ymm0
    1a4e:	c4 e2 5d 3d ea       	vpmaxsd %ymm2,%ymm4,%ymm5
    1a53:	c4 62 7d 90 2c 9a    	vpgatherdd %ymm0,(%rdx,%ymm3,4),%ymm13
    1a59:	c5 ed 66 dc          	vpcmpgtd %ymm4,%ymm2,%ymm3
    1a5d:	c5 f5 66 c5          	vpcmpgtd %ymm5,%ymm1,%ymm0
    1a61:	c4 c3 0d 4c d9 30    	vpblendvb %ymm3,%ymm9,%ymm14,%ymm3
    1a67:	c4 e3 65 4c df 00    	vpblendvb %ymm0,%ymm7,%ymm3,%ymm3
    1a6d:	c4 e2 55 3d c1       	vpmaxsd %ymm1,%ymm5,%ymm0
    1a72:	c4 e2 4d 39 e9       	vpminsd %ymm1,%ymm6,%ymm5
    1a77:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1a7c:	c5 fe 7f 84 24 e0 01 	vmovdqu %ymm0,0x1e0(%rsp)
    1a83:	00 00 
    1a85:	c5 cd 66 f1          	vpcmpgtd %ymm1,%ymm6,%ymm6
    1a89:	c5 fe 7f ac 24 00 02 	vmovdqu %ymm5,0x200(%rsp)
    1a90:	00 00 
    1a92:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
    1a96:	c5 7e 7f 84 24 60 01 	vmovdqu %ymm8,0x160(%rsp)
    1a9d:	00 00 
    1a9f:	c5 7e 6f 84 24 00 02 	vmovdqu 0x200(%rsp),%ymm8
    1aa6:	00 00 
    1aa8:	c4 e2 55 90 04 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm0
    1aae:	c5 dd 66 da          	vpcmpgtd %ymm2,%ymm4,%ymm3
    1ab2:	c5 7e 7f 8c 24 40 01 	vmovdqu %ymm9,0x140(%rsp)
    1ab9:	00 00 
    1abb:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    1ac1:	c5 3d fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm8,%ymm8
    1ac8:	00 00 
    1aca:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
    1acf:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    1ad4:	c4 e3 0d 4c 9c 24 40 	vpblendvb %ymm3,0x140(%rsp),%ymm14,%ymm3
    1adb:	01 00 00 30 
    1adf:	c4 41 75 fa c0       	vpsubd %ymm8,%ymm1,%ymm8
    1ae4:	c4 e3 65 4c df 60    	vpblendvb %ymm6,%ymm7,%ymm3,%ymm3
    1aea:	c5 d5 fa db          	vpsubd %ymm3,%ymm5,%ymm3
    1aee:	c5 85 db ac 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm5
    1af5:	00 00 
    1af7:	c4 e2 35 90 34 98    	vpgatherdd %ymm9,(%rax,%ymm3,4),%ymm6
    1afd:	c5 5d fe ca          	vpaddd %ymm2,%ymm4,%ymm9
    1b01:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1b06:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    1b0b:	c4 41 3d fe c9       	vpaddd %ymm9,%ymm8,%ymm9
    1b10:	c5 4d fa c0          	vpsubd %ymm0,%ymm6,%ymm8
    1b14:	c5 e5 fe 9c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm3,%ymm3
    1b1b:	00 00 
    1b1d:	c4 42 35 40 c0       	vpmulld %ymm8,%ymm9,%ymm8
    1b22:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    1b26:	c4 e2 7d 40 84 24 e0 	vpmulld 0x1e0(%rsp),%ymm0,%ymm0
    1b2d:	01 00 00 
    1b30:	c5 bd fe db          	vpaddd %ymm3,%ymm8,%ymm3
    1b34:	c5 05 db 84 24 a0 01 	vpand  0x1a0(%rsp),%ymm15,%ymm8
    1b3b:	00 00 
    1b3d:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
    1b41:	c4 c1 4d 72 e2 10    	vpsrad $0x10,%ymm10,%ymm6
    1b47:	c4 62 3d 40 84 24 00 	vpmulld 0x200(%rsp),%ymm8,%ymm8
    1b4e:	02 00 00 
    1b51:	c5 3d fe c0          	vpaddd %ymm0,%ymm8,%ymm8
    1b55:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
    1b59:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    1b5e:	c5 d5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm5
    1b63:	c4 c1 65 72 f5 10    	vpslld $0x10,%ymm13,%ymm3
    1b69:	c5 fe 7f ac 24 e0 01 	vmovdqu %ymm5,0x1e0(%rsp)
    1b70:	00 00 
    1b72:	c4 c1 55 72 e3 10    	vpsrad $0x10,%ymm11,%ymm5
    1b78:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    1b7d:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1b81:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    1b85:	c5 d5 fe c6          	vpaddd %ymm6,%ymm5,%ymm0
    1b89:	c5 fe 7f 84 24 20 02 	vmovdqu %ymm0,0x220(%rsp)
    1b90:	00 00 
    1b92:	c4 c1 7d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm0
    1b98:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1b9c:	c4 c1 75 72 f2 10    	vpslld $0x10,%ymm10,%ymm1
    1ba2:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
    1ba7:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    1bac:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1bb0:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    1bb4:	c5 fe 7f 94 24 00 02 	vmovdqu %ymm2,0x200(%rsp)
    1bbb:	00 00 
    1bbd:	c4 c1 6d 72 f3 10    	vpslld $0x10,%ymm11,%ymm2
    1bc3:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    1bc8:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1bcc:	c4 62 6d 3d c1       	vpmaxsd %ymm1,%ymm2,%ymm8
    1bd1:	c5 75 66 da          	vpcmpgtd %ymm2,%ymm1,%ymm11
    1bd5:	c4 62 6d 39 e9       	vpminsd %ymm1,%ymm2,%ymm13
    1bda:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
    1bdf:	c5 ed 66 c9          	vpcmpgtd %ymm1,%ymm2,%ymm1
    1be3:	c4 62 15 39 cb       	vpminsd %ymm3,%ymm13,%ymm9
    1be8:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    1bec:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    1bf1:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    1bf7:	c4 63 0d 4c 9c 24 40 	vpblendvb %ymm11,0x140(%rsp),%ymm14,%ymm11
    1bfe:	01 00 00 b0 
    1c02:	c4 63 25 4c df 40    	vpblendvb %ymm4,%ymm7,%ymm11,%ymm11
    1c08:	c4 e3 0d 4c 8c 24 40 	vpblendvb %ymm1,0x140(%rsp),%ymm14,%ymm1
    1c0f:	01 00 00 10 
    1c13:	c5 25 fe 9c 24 60 01 	vpaddd 0x160(%rsp),%ymm11,%ymm11
    1c1a:	00 00 
    1c1c:	c4 e3 75 4c cf d0    	vpblendvb %ymm13,%ymm7,%ymm1,%ymm1
    1c22:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1c27:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    1c2b:	c4 a2 2d 90 24 98    	vpgatherdd %ymm10,(%rax,%ymm11,4),%ymm4
    1c31:	c4 62 15 90 1c 88    	vpgatherdd %ymm13,(%rax,%ymm1,4),%ymm11
    1c37:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    1c3e:	00 00 
    1c40:	c4 41 3d fe d1       	vpaddd %ymm9,%ymm8,%ymm10
    1c45:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    1c4a:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    1c50:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
    1c55:	c5 95 72 d1 08       	vpsrld $0x8,%ymm1,%ymm13
    1c5a:	c5 fe 6f 8c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm1
    1c61:	00 00 
    1c63:	c5 ed fe 94 24 00 02 	vpaddd 0x200(%rsp),%ymm2,%ymm2
    1c6a:	00 00 
    1c6c:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    1c71:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    1c76:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    1c7b:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    1c80:	c4 c1 75 72 f5 10    	vpslld $0x10,%ymm13,%ymm1
    1c86:	c5 25 fa d4          	vpsubd %ymm4,%ymm11,%ymm10
    1c8a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1c8f:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    1c94:	c5 f5 fe 8c 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm1,%ymm1
    1c9b:	00 00 
    1c9d:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    1ca2:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1ca7:	c5 7e 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm11
    1cae:	00 00 
    1cb0:	c4 62 55 39 c6       	vpminsd %ymm6,%ymm5,%ymm8
    1cb5:	c4 42 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm10
    1cba:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1cbf:	c4 62 3d 39 c8       	vpminsd %ymm0,%ymm8,%ymm9
    1cc4:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
    1cc8:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1ccd:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    1cd1:	c5 ad fe c9          	vpaddd %ymm1,%ymm10,%ymm1
    1cd5:	c4 e2 55 3d e6       	vpmaxsd %ymm6,%ymm5,%ymm4
    1cda:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1cde:	c5 cd 66 dd          	vpcmpgtd %ymm5,%ymm6,%ymm3
    1ce2:	c5 fd 66 d4          	vpcmpgtd %ymm4,%ymm0,%ymm2
    1ce6:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    1cea:	c4 e2 5d 3d e0       	vpmaxsd %ymm0,%ymm4,%ymm4
    1cef:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1cf4:	c4 c3 0d 4c db 30    	vpblendvb %ymm3,%ymm11,%ymm14,%ymm3
    1cfa:	c4 e3 65 4c df 20    	vpblendvb %ymm2,%ymm7,%ymm3,%ymm3
    1d00:	c5 e5 fe 9c 24 60 01 	vpaddd 0x160(%rsp),%ymm3,%ymm3
    1d07:	00 00 
    1d09:	c4 e2 15 90 14 98    	vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm2
    1d0f:	c4 c3 0d 4c db 50    	vpblendvb %ymm5,%ymm11,%ymm14,%ymm3
    1d15:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    1d1b:	c4 41 7d 6f ec       	vmovdqa %ymm12,%ymm13
    1d20:	c4 e3 65 4c df 80    	vpblendvb %ymm8,%ymm7,%ymm3,%ymm3
    1d26:	c4 41 5d fe c1       	vpaddd %ymm9,%ymm4,%ymm8
    1d2b:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    1d32:	00 00 
    1d34:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    1d3b:	00 00 
    1d3d:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    1d41:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
    1d46:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1d4b:	c4 e2 15 90 34 98    	vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm6
    1d51:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    1d58:	00 00 
    1d5a:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    1d5f:	c5 fd fe 84 24 20 02 	vpaddd 0x220(%rsp),%ymm0,%ymm0
    1d66:	00 00 
    1d68:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1d6d:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
    1d73:	c5 d5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm5
    1d78:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    1d7f:	00 00 
    1d81:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    1d86:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    1d8b:	c5 4d fa c2          	vpsubd %ymm2,%ymm6,%ymm8
    1d8f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1d94:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    1d99:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1d9d:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    1da2:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    1da7:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    1dac:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    1db0:	c5 c5 fe bc 24 c0 01 	vpaddd 0x1c0(%rsp),%ymm7,%ymm7
    1db7:	00 00 
    1db9:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1dbe:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    1dc2:	c5 fe 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm7
    1dc9:	00 00 
    1dcb:	c5 c5 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm7,%ymm6
    1dd1:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    1dd5:	c5 f5 fa d7          	vpsubd %ymm7,%ymm1,%ymm2
    1dd9:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1ddd:	c5 8d 66 da          	vpcmpgtd %ymm2,%ymm14,%ymm3
    1de1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1de6:	c5 fd fa e7          	vpsubd %ymm7,%ymm0,%ymm4
    1dea:	c5 a5 66 ec          	vpcmpgtd %ymm4,%ymm11,%ymm5
    1dee:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    1df2:	c5 dd 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm4,%ymm5
    1df9:	00 00 
    1dfb:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    1dff:	c5 95 66 ef          	vpcmpgtd %ymm7,%ymm13,%ymm5
    1e03:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    1e07:	c5 ed 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm2,%ymm6
    1e0e:	00 00 
    1e10:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    1e14:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    1e18:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    1e1c:	85 c0                	test   %eax,%eax
    1e1e:	0f 84 84 fa ff ff    	je     18a8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbb8>
    1e24:	c5 fe 6f 94 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm2
    1e2b:	00 00 
    1e2d:	49 8d 72 60          	lea    0x60(%r10),%rsi
    1e31:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    1e38:	4c 8d 73 60          	lea    0x60(%rbx),%r14
    1e3c:	80 7e 58 00          	cmpb   $0x0,0x58(%rsi)
    1e40:	0f 85 f2 21 00 00    	jne    4038 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3348>
    1e46:	80 7e 59 00          	cmpb   $0x0,0x59(%rsi)
    1e4a:	c5 fd 7f 53 60       	vmovdqa %ymm2,0x60(%rbx)
    1e4f:	4c 89 f2             	mov    %r14,%rdx
    1e52:	48 89 f1             	mov    %rsi,%rcx
    1e55:	c5 fd 7f 8b 80 00 00 	vmovdqa %ymm1,0x80(%rbx)
    1e5c:	00 
    1e5d:	c5 fd 7f 83 a0 00 00 	vmovdqa %ymm0,0xa0(%rbx)
    1e64:	00 
    1e65:	0f 84 45 21 00 00    	je     3fb0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32c0>
    1e6b:	c5 f8 77             	vzeroupper
    1e6e:	e8 6d e4 ff ff       	call   2e0 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    1e73:	c5 fd 6f 53 60       	vmovdqa 0x60(%rbx),%ymm2
    1e78:	c5 fd 6f 8b 80 00 00 	vmovdqa 0x80(%rbx),%ymm1
    1e7f:	00 
    1e80:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    1e85:	c5 fd 6f 83 a0 00 00 	vmovdqa 0xa0(%rbx),%ymm0
    1e8c:	00 
    1e8d:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 1ed5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x11e5>
    1e94:	00 
    1e95:	48 83 c6 60          	add    $0x60,%rsi
    1e99:	49 39 f5             	cmp    %rsi,%r13
    1e9c:	75 9e                	jne    1e3c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x114c>
    1e9e:	c5 e5 72 f0 10       	vpslld $0x10,%ymm0,%ymm3
    1ea3:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    1ea8:	c5 fd eb c3          	vpor   %ymm3,%ymm0,%ymm0
    1eac:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    1eb0:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    1eb7:	01 00 00 
    1eba:	e9 3c fa ff ff       	jmp    18fb <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc0b>
    1ebf:	90                   	nop
    1ec0:	84 d2                	test   %dl,%dl
    1ec2:	0f 84 f0 0c 00 00    	je     2bb8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ec8>
    1ec8:	4d 85 c9             	test   %r9,%r9
    1ecb:	0f 84 c2 05 00 00    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    1ed1:	49 ff c9             	dec    %r9
    1ed4:	c5 fd 6f 3d 60 00 00 	vmovdqa 0x60(%rip),%ymm7        # 1f3c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x124c>
    1edb:	00 
    1edc:	c5 fd 6f 25 80 00 00 	vmovdqa 0x80(%rip),%ymm4        # 1f64 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1274>
    1ee3:	00 
    1ee4:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    1ee9:	49 c1 e9 03          	shr    $0x3,%r9
    1eed:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    1ef3:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    1ef7:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    1efe:	00 00 
    1f00:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    1f05:	b8 00 80 00 00       	mov    $0x8000,%eax
    1f0a:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
    1f11:	00 00 
    1f13:	c5 f9 6e f8          	vmovd  %eax,%xmm7
    1f17:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1f1c:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    1f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1f28:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    1f2d:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    1f33:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    1f37:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    1f3b:	49 8b 02             	mov    (%r10),%rax
    1f3e:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    1f42:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    1f47:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    1f4c:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1f52:	41 8b 52 50          	mov    0x50(%r10),%edx
    1f56:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1f5c:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    1f63:	01 00 00 
    1f66:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    1f6b:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    1f70:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    1f75:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    1f7c:	00 00 
    1f7e:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
    1f83:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    1f87:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    1f8b:	c4 e2 55 90 14 a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm2
    1f91:	49 8b 42 08          	mov    0x8(%r10),%rax
    1f95:	c5 fe 7f 84 24 60 01 	vmovdqu %ymm0,0x160(%rsp)
    1f9c:	00 00 
    1f9e:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1fa3:	c4 e2 4d 90 2c 80    	vpgatherdd %ymm6,(%rax,%ymm0,4),%ymm5
    1fa9:	49 8b 42 10          	mov    0x10(%r10),%rax
    1fad:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    1fb4:	00 00 
    1fb6:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    1fba:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    1fbf:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 1fe7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x12f7>
    1fc6:	00 
    1fc7:	c4 e2 4d 90 1c b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm3
    1fcd:	c5 cd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm6
    1fd2:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    1fd6:	49 8b 42 48          	mov    0x48(%r10),%rax
    1fda:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    1fdf:	c4 e2 4d 40 f1       	vpmulld %ymm1,%ymm6,%ymm6
    1fe4:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 200c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x131c>
    1feb:	00 
    1fec:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    1ff1:	c5 dd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm4
    1ff6:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 201e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x132e>
    1ffd:	00 
    1ffe:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    2003:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    2007:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    200b:	c5 7d fe e4          	vpaddd %ymm4,%ymm0,%ymm12
    200f:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    2013:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    2018:	c4 22 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm11
    201e:	c4 41 7d fe ec       	vpaddd %ymm12,%ymm0,%ymm13
    2023:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    2027:	c4 a2 2d 90 34 a8    	vpgatherdd %ymm10,(%rax,%ymm13,4),%ymm6
    202d:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    2032:	c5 fe 7f b4 24 a0 01 	vmovdqu %ymm6,0x1a0(%rsp)
    2039:	00 00 
    203b:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    2040:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    2044:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    2048:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    204e:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    2053:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm0,%ymm0        # 205c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x136c>
    205a:	ff ff 40 
    205d:	c5 9d fe c0          	vpaddd %ymm0,%ymm12,%ymm0
    2061:	c4 e2 35 90 24 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm4
    2067:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    206b:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2070:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2075:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2079:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    207f:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm0,%ymm0        # 2088 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1398>
    2086:	ff ff 80 
    2089:	c5 95 fa c0          	vpsubd %ymm0,%ymm13,%ymm0
    208d:	c4 62 35 90 04 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm8
    2093:	c5 7e 7f 9c 24 80 01 	vmovdqu %ymm11,0x180(%rsp)
    209a:	00 00 
    209c:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    20a1:	c5 05 db 8c 24 80 01 	vpand  0x180(%rsp),%ymm15,%ymm9
    20a8:	00 00 
    20aa:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    20af:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    20b4:	49 8b 52 28          	mov    0x28(%r10),%rdx
    20b8:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    20bd:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    20c1:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    20c5:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    20cb:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    20d0:	c5 85 db 94 24 a0 01 	vpand  0x1a0(%rsp),%ymm15,%ymm2
    20d7:	00 00 
    20d9:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    20de:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    20e3:	c5 fd fe 44 24 20    	vpaddd 0x20(%rsp),%ymm0,%ymm0
    20e9:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    20ee:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    20f3:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    20f8:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    20fc:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    2103:	00 00 
    2105:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    2109:	c5 fe 6f a4 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm4
    2110:	00 00 
    2112:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    2116:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
    211d:	00 00 
    211f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2124:	c5 fe 7f 84 24 00 02 	vmovdqu %ymm0,0x200(%rsp)
    212b:	00 00 
    212d:	c4 e2 2d 90 34 a2    	vpgatherdd %ymm10,(%rdx,%ymm4,4),%ymm6
    2133:	49 8b 52 20          	mov    0x20(%r10),%rdx
    2137:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    213c:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 2164 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1474>
    2143:	00 
    2144:	c4 62 2d 90 04 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm8
    214a:	49 8b 52 18          	mov    0x18(%r10),%rdx
    214e:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    2153:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 217b <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x148b>
    215a:	00 
    215b:	c4 e2 2d 90 14 9a    	vpgatherdd %ymm10,(%rdx,%ymm3,4),%ymm2
    2161:	49 8b 52 40          	mov    0x40(%r10),%rdx
    2165:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 218d <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x149d>
    216c:	00 
    216d:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    2172:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    2176:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    217b:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    2180:	c4 e2 55 39 c6       	vpminsd %ymm6,%ymm5,%ymm0
    2185:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    218a:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    218e:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    2194:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm4,%ymm4        # 219d <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14ad>
    219b:	ff ff 30 
    219e:	c5 9d fe e4          	vpaddd %ymm4,%ymm12,%ymm4
    21a2:	c4 e2 25 90 1c a0    	vpgatherdd %ymm11,(%rax,%ymm4,4),%ymm3
    21a8:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    21ad:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    21b2:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    21b7:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    21bc:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    21c1:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    21c7:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm4,%ymm4        # 21d0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x14e0>
    21ce:	ff ff 50 
    21d1:	c5 95 fa e4          	vpsubd %ymm4,%ymm13,%ymm4
    21d5:	c4 62 25 90 0c a0    	vpgatherdd %ymm11,(%rax,%ymm4,4),%ymm9
    21db:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
    21e2:	00 00 
    21e4:	c5 fe 7f 84 24 e0 01 	vmovdqu %ymm0,0x1e0(%rsp)
    21eb:	00 00 
    21ed:	c5 ad fe c0          	vpaddd %ymm0,%ymm10,%ymm0
    21f1:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    21f7:	c5 cd fa f0          	vpsubd %ymm0,%ymm6,%ymm6
    21fb:	c5 fe 6f a4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm4
    2202:	00 00 
    2204:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2208:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    220e:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2213:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    2217:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    221c:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
    2221:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2225:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    222a:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    222f:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2234:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2239:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    223f:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2244:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    224a:	c4 e2 55 40 ac 24 e0 	vpmulld 0x1e0(%rsp),%ymm5,%ymm5
    2251:	01 00 00 
    2254:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    2258:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    225c:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2260:	c5 fe 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm5
    2267:	00 00 
    2269:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    226e:	c4 e2 7d 90 14 aa    	vpgatherdd %ymm0,(%rdx,%ymm5,4),%ymm2
    2274:	49 8b 52 38          	mov    0x38(%r10),%rdx
    2278:	c5 fe 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm5
    227f:	00 00 
    2281:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2285:	c5 fe 6f 9c 24 40 01 	vmovdqu 0x140(%rsp),%ymm3
    228c:	00 00 
    228e:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 22b6 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15c6>
    2295:	00 
    2296:	c4 e2 7d 90 34 aa    	vpgatherdd %ymm0,(%rdx,%ymm5,4),%ymm6
    229c:	49 8b 52 30          	mov    0x30(%r10),%rdx
    22a0:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    22a4:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 22cc <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15dc>
    22ab:	00 
    22ac:	c4 e2 7d 90 2c 9a    	vpgatherdd %ymm0,(%rdx,%ymm3,4),%ymm5
    22b2:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    22b6:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 22de <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15ee>
    22bd:	00 
    22be:	c4 62 55 3d ce       	vpmaxsd %ymm6,%ymm5,%ymm9
    22c3:	c5 4d 66 c5          	vpcmpgtd %ymm5,%ymm6,%ymm8
    22c7:	c4 62 55 39 d6       	vpminsd %ymm6,%ymm5,%ymm10
    22cc:	c4 c1 6d 66 d9       	vpcmpgtd %ymm9,%ymm2,%ymm3
    22d1:	c4 62 2d 39 da       	vpminsd %ymm2,%ymm10,%ymm11
    22d6:	c4 62 35 3d ca       	vpmaxsd %ymm2,%ymm9,%ymm9
    22db:	c5 2d 66 d2          	vpcmpgtd %ymm2,%ymm10,%ymm10
    22df:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    22e5:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm8,%ymm8        # 22ee <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15fe>
    22ec:	ff ff 30 
    22ef:	c4 41 1d fe c0       	vpaddd %ymm8,%ymm12,%ymm8
    22f4:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    22f9:	c4 a2 7d 90 1c 80    	vpgatherdd %ymm0,(%rax,%ymm8,4),%ymm3
    22ff:	c5 55 66 c6          	vpcmpgtd %ymm6,%ymm5,%ymm8
    2303:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2307:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    230c:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    2310:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    2315:	c5 7e 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm12
    231c:	00 00 
    231e:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2323:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2327:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    232d:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm1,%ymm1        # 2336 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1646>
    2334:	ff ff a0 
    2337:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    233b:	c5 7e 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm13
    2342:	00 00 
    2344:	c4 e2 7d 90 3c 88    	vpgatherdd %ymm0,(%rax,%ymm1,4),%ymm7
    234a:	c5 fe 6f 8c 24 80 01 	vmovdqu 0x180(%rsp),%ymm1
    2351:	00 00 
    2353:	c5 fe 6f 84 24 00 02 	vmovdqu 0x200(%rsp),%ymm0
    235a:	00 00 
    235c:	c4 c1 3d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm8
    2362:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2367:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
    236d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2372:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    2377:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    237c:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2381:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    2385:	c5 3d fa c7          	vpsubd %ymm7,%ymm8,%ymm8
    2389:	c4 e2 6d 40 d5       	vpmulld %ymm5,%ymm2,%ymm2
    238e:	c4 42 3d 40 c3       	vpmulld %ymm11,%ymm8,%ymm8
    2393:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2397:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
    239e:	00 00 
    23a0:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    23a5:	c5 ad 72 f1 10       	vpslld $0x10,%ymm1,%ymm10
    23aa:	c5 2d fe 54 24 20    	vpaddd 0x20(%rsp),%ymm10,%ymm10
    23b0:	c5 fd 66 7c 24 60    	vpcmpgtd 0x60(%rsp),%ymm0,%ymm7
    23b6:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    23bb:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    23bf:	c5 dd fa d8          	vpsubd %ymm0,%ymm4,%ymm3
    23c3:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    23c8:	c5 a5 66 cb          	vpcmpgtd %ymm3,%ymm11,%ymm1
    23cc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    23d1:	c5 ed fa e8          	vpsubd %ymm0,%ymm2,%ymm5
    23d5:	c5 9d 66 f5          	vpcmpgtd %ymm5,%ymm12,%ymm6
    23d9:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    23dd:	c5 d5 66 b4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm5,%ymm6
    23e4:	00 00 
    23e6:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    23ea:	c5 95 66 f0          	vpcmpgtd %ymm0,%ymm13,%ymm6
    23ee:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    23f2:	c5 e5 66 bc 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm3,%ymm7
    23f9:	00 00 
    23fb:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    23ff:	c5 f5 eb ce          	vpor   %ymm6,%ymm1,%ymm1
    2403:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
    2407:	85 c0                	test   %eax,%eax
    2409:	0f 85 51 1c 00 00    	jne    4060 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3370>
    240f:	8b 47 24             	mov    0x24(%rdi),%eax
    2412:	8b 57 20             	mov    0x20(%rdi),%edx
    2415:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    241a:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    241f:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    2424:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    2428:	49 83 c0 18          	add    $0x18,%r8
    242c:	0f af d0             	imul   %eax,%edx
    242f:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    2433:	48 8b 07             	mov    (%rdi),%rax
    2436:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    243b:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    2440:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2444:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2449:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    244e:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    2452:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2456:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
    245c:	c4 e2 75 00 84 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm0
    2463:	01 00 00 
    2466:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    246a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2470:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2475:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    247a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    247e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2484:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    248a:	4d 39 c8             	cmp    %r9,%r8
    248d:	0f 85 95 fa ff ff    	jne    1f28 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1238>
    2493:	c5 f8 77             	vzeroupper
    2496:	c5 f8 28 b4 24 d0 03 	vmovaps 0x3d0(%rsp),%xmm6
    249d:	00 00 
    249f:	c5 f8 28 bc 24 e0 03 	vmovaps 0x3e0(%rsp),%xmm7
    24a6:	00 00 
    24a8:	c5 78 28 84 24 f0 03 	vmovaps 0x3f0(%rsp),%xmm8
    24af:	00 00 
    24b1:	c5 78 28 8c 24 00 04 	vmovaps 0x400(%rsp),%xmm9
    24b8:	00 00 
    24ba:	c5 78 28 94 24 10 04 	vmovaps 0x410(%rsp),%xmm10
    24c1:	00 00 
    24c3:	c5 78 28 9c 24 20 04 	vmovaps 0x420(%rsp),%xmm11
    24ca:	00 00 
    24cc:	c5 78 28 a4 24 30 04 	vmovaps 0x430(%rsp),%xmm12
    24d3:	00 00 
    24d5:	c5 78 28 ac 24 40 04 	vmovaps 0x440(%rsp),%xmm13
    24dc:	00 00 
    24de:	c5 78 28 b4 24 50 04 	vmovaps 0x450(%rsp),%xmm14
    24e5:	00 00 
    24e7:	c5 78 28 bc 24 60 04 	vmovaps 0x460(%rsp),%xmm15
    24ee:	00 00 
    24f0:	48 81 c4 70 04 00 00 	add    $0x470,%rsp
    24f7:	5b                   	pop    %rbx
    24f8:	5e                   	pop    %rsi
    24f9:	5f                   	pop    %rdi
    24fa:	5d                   	pop    %rbp
    24fb:	41 5c                	pop    %r12
    24fd:	41 5d                	pop    %r13
    24ff:	41 5e                	pop    %r14
    2501:	c3                   	ret
    2502:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2508:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    250e:	48 8b 06             	mov    (%rsi),%rax
    2511:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    2515:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    2519:	8b 4e 54             	mov    0x54(%rsi),%ecx
    251c:	8b 56 50             	mov    0x50(%rsi),%edx
    251f:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    2523:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    2528:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    252f:	00 00 
    2531:	c4 e2 55 90 04 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm0
    2537:	48 8b 46 08          	mov    0x8(%rsi),%rax
    253b:	c5 7e 7f b4 24 60 01 	vmovdqu %ymm14,0x160(%rsp)
    2542:	00 00 
    2544:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    2548:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
    254c:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2551:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2555:	c4 a2 65 90 2c b0    	vpgatherdd %ymm3,(%rax,%ymm14,4),%ymm5
    255b:	48 8b 46 10          	mov    0x10(%rsi),%rax
    255f:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    2564:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2569:	c4 e2 5d 40 e2       	vpmulld %ymm2,%ymm4,%ymm4
    256e:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2596 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18a6>
    2575:	00 
    2576:	c4 a2 75 90 1c a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm3
    257c:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2581:	48 8b 46 48          	mov    0x48(%rsi),%rax
    2585:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 25ad <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18bd>
    258c:	00 
    258d:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2592:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    2597:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 25bf <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x18cf>
    259e:	00 
    259f:	c4 62 7d 3d c5       	vpmaxsd %ymm5,%ymm0,%ymm8
    25a4:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    25a8:	c4 c1 65 66 e0       	vpcmpgtd %ymm8,%ymm3,%ymm4
    25ad:	c4 62 3d 3d c3       	vpmaxsd %ymm3,%ymm8,%ymm8
    25b2:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    25b6:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    25ba:	c4 22 75 90 14 b8    	vpgatherdd %ymm1,(%rax,%ymm15,4),%ymm10
    25c0:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    25c4:	ba 00 80 00 00       	mov    $0x8000,%edx
    25c9:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    25ce:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    25d3:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    25d7:	c4 a2 75 90 34 b0    	vpgatherdd %ymm1,(%rax,%ymm14,4),%ymm6
    25dd:	c5 d5 66 c8          	vpcmpgtd %ymm0,%ymm5,%ymm1
    25e1:	c5 fe 7f b4 24 c0 01 	vmovdqu %ymm6,0x1c0(%rsp)
    25e8:	00 00 
    25ea:	c4 e2 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm6
    25ef:	c4 62 4d 39 e3       	vpminsd %ymm3,%ymm6,%ymm12
    25f4:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
    25f8:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    25fe:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 2607 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1917>
    2605:	ff ff 40 
    2608:	c5 85 fe c9          	vpaddd %ymm1,%ymm15,%ymm1
    260c:	c4 e2 35 90 24 88    	vpgatherdd %ymm9,(%rax,%ymm1,4),%ymm4
    2612:	c5 fd 66 cd          	vpcmpgtd %ymm5,%ymm0,%ymm1
    2616:	c5 7e 7f b4 24 a0 01 	vmovdqu %ymm14,0x1a0(%rsp)
    261d:	00 00 
    261f:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2623:	c4 e3 6d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm2,%ymm1
    2629:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm1,%ymm1        # 2632 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1942>
    2630:	ff ff 60 
    2633:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    2637:	c5 8d fa c9          	vpsubd %ymm1,%ymm14,%ymm1
    263b:	c4 41 3d fe f4       	vpaddd %ymm12,%ymm8,%ymm14
    2640:	c4 62 4d 90 0c 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm9
    2646:	c4 c1 75 72 d3 18    	vpsrld $0x18,%ymm11,%ymm1
    264c:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    2651:	c5 7e 7f 94 24 80 01 	vmovdqu %ymm10,0x180(%rsp)
    2658:	00 00 
    265a:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    265e:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    2662:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    2666:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
    266a:	c5 75 db 94 24 80 01 	vpand  0x180(%rsp),%ymm1,%ymm10
    2671:	00 00 
    2673:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
    2678:	c5 f9 6e da          	vmovd  %edx,%xmm3
    267c:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2681:	c4 c1 4d 72 f2 10    	vpslld $0x10,%ymm10,%ymm6
    2687:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    268c:	c5 cd fe f3          	vpaddd %ymm3,%ymm6,%ymm6
    2690:	c5 fe 7f 9c 24 e0 01 	vmovdqu %ymm3,0x1e0(%rsp)
    2697:	00 00 
    2699:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    269e:	48 8b 56 28          	mov    0x28(%rsi),%rdx
    26a2:	c5 fd fe f6          	vpaddd %ymm6,%ymm0,%ymm6
    26a6:	c5 f5 db 84 24 c0 01 	vpand  0x1c0(%rsp),%ymm1,%ymm0
    26ad:	00 00 
    26af:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    26b4:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    26b9:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    26be:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    26c2:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    26c9:	00 00 
    26cb:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    26cf:	c5 fe 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm0
    26d6:	00 00 
    26d8:	c5 b5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm9
    26dd:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
    26e3:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    26e8:	c4 a2 35 90 34 aa    	vpgatherdd %ymm9,(%rdx,%ymm13,4),%ymm6
    26ee:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    26f2:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    26f7:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 271f <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a2f>
    26fe:	00 
    26ff:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    2705:	48 8b 56 18          	mov    0x18(%rsi),%rdx
    2709:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    270e:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 2736 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a46>
    2715:	00 
    2716:	c4 e2 35 90 1c a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm3
    271c:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    2721:	48 8b 56 40          	mov    0x40(%rsi),%rdx
    2725:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 274d <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a5d>
    272c:	00 
    272d:	c4 42 65 3d d0       	vpmaxsd %ymm8,%ymm3,%ymm10
    2732:	c5 bd 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm0
    2736:	c4 c2 65 39 e8       	vpminsd %ymm8,%ymm3,%ymm5
    273b:	c4 c1 4d 66 e2       	vpcmpgtd %ymm10,%ymm6,%ymm4
    2740:	c4 62 55 39 f6       	vpminsd %ymm6,%ymm5,%ymm14
    2745:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    274a:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    274e:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    2754:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm0,%ymm0        # 275d <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a6d>
    275b:	ff ff 40 
    275e:	c5 85 fe c0          	vpaddd %ymm0,%ymm15,%ymm0
    2762:	c4 e2 35 90 24 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm4
    2768:	c4 c1 65 66 c0       	vpcmpgtd %ymm8,%ymm3,%ymm0
    276d:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    2772:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    2777:	c5 dd db e1          	vpand  %ymm1,%ymm4,%ymm4
    277b:	c4 e3 6d 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm2,%ymm0
    2781:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 278a <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a9a>
    2788:	ff ff 50 
    278b:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    2792:	00 00 
    2794:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2798:	c5 fe 6f ac 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm5
    279f:	00 00 
    27a1:	c4 62 1d 90 0c 80    	vpgatherdd %ymm12,(%rax,%ymm0,4),%ymm9
    27a7:	c5 7e 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm12
    27ae:	00 00 
    27b0:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    27b6:	c5 d5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm5
    27bb:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
    27bf:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    27c5:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
    27c9:	c5 7e 7f 8c 24 00 02 	vmovdqu %ymm9,0x200(%rsp)
    27d0:	00 00 
    27d2:	c4 41 2d fe ce       	vpaddd %ymm14,%ymm10,%ymm9
    27d7:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
    27db:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    27e0:	c5 7e 6f 8c 24 00 02 	vmovdqu 0x200(%rsp),%ymm9
    27e7:	00 00 
    27e9:	c4 c1 7d 72 f4 10    	vpslld $0x10,%ymm12,%ymm0
    27ef:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    27f3:	c5 fd fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm0
    27fa:	00 00 
    27fc:	c5 b5 fa f4          	vpsubd %ymm4,%ymm9,%ymm6
    2800:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2805:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    280a:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    280f:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
    2814:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    2819:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    281e:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    2822:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    2826:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    282a:	c5 8d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm14
    282f:	c4 a2 35 90 04 aa    	vpgatherdd %ymm9,(%rdx,%ymm13,4),%ymm0
    2835:	c4 41 7d 6f eb       	vmovdqa %ymm11,%ymm13
    283a:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 2862 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b72>
    2841:	00 
    2842:	48 8b 56 38          	mov    0x38(%rsi),%rdx
    2846:	c5 fe 6f 9c 24 60 01 	vmovdqu 0x160(%rsp),%ymm3
    284d:	00 00 
    284f:	c5 fe 6f b4 24 40 01 	vmovdqu 0x140(%rsp),%ymm6
    2856:	00 00 
    2858:	c5 7e 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm12
    285f:	00 00 
    2861:	c4 e2 15 90 2c 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm5
    2867:	48 8b 56 30          	mov    0x30(%rsi),%rdx
    286b:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    286f:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 2897 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ba7>
    2876:	00 
    2877:	c4 e2 65 90 24 b2    	vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm4
    287d:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 28a5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bb5>
    2884:	00 
    2885:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    288a:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    288e:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    2893:	c4 c1 7d 66 d8       	vpcmpgtd %ymm8,%ymm0,%ymm3
    2898:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    289d:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    28a2:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    28a6:	c4 e3 6d 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm6
    28ac:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 28b5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bc5>
    28b3:	ff ff 30 
    28b6:	c5 85 fe f6          	vpaddd %ymm6,%ymm15,%ymm6
    28ba:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    28bf:	c4 e2 05 90 1c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm3
    28c5:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    28c9:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    28cd:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    28d2:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
    28d6:	c4 e3 6d 4c d7 60    	vpblendvb %ymm6,%ymm7,%ymm2,%ymm2
    28dc:	c5 fe 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm7
    28e3:	00 00 
    28e5:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    28e9:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm2,%ymm2        # 28f2 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c02>
    28f0:	ff ff 90 
    28f3:	c5 c5 fa d2          	vpsubd %ymm2,%ymm7,%ymm2
    28f7:	c4 e2 4d 90 3c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm7
    28fd:	c5 fe 6f 94 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm2
    2904:	00 00 
    2906:	c4 c1 4d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm6
    290c:	c4 41 3d fe e2       	vpaddd %ymm10,%ymm8,%ymm12
    2911:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2916:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
    291a:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    291f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2924:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
    2928:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    292c:	c5 ed db c9          	vpand  %ymm1,%ymm2,%ymm1
    2930:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    2935:	c5 c5 fa e3          	vpsubd %ymm3,%ymm7,%ymm4
    2939:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    293d:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    2941:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    2946:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    294b:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    2950:	c5 35 fe 8c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm9,%ymm9
    2957:	00 00 
    2959:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    295e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2962:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2966:	c5 95 72 d0 10       	vpsrld $0x10,%ymm0,%ymm13
    296b:	e9 95 ee ff ff       	jmp    1805 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb15>
    2970:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    2976:	48 8b 06             	mov    (%rsi),%rax
    2979:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    297d:	8b 4e 54             	mov    0x54(%rsi),%ecx
    2980:	8b 56 50             	mov    0x50(%rsi),%edx
    2983:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    2989:	48 8b 46 08          	mov    0x8(%rsi),%rax
    298d:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    2991:	c5 79 6e ca          	vmovd  %edx,%xmm9
    2995:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    299a:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    299e:	c4 a2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm14,4),%ymm5
    29a4:	48 8b 46 10          	mov    0x10(%rsi),%rax
    29a8:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    29ac:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    29b1:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    29b6:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    29bb:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 29e3 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1cf3>
    29c2:	00 
    29c3:	c4 a2 45 90 34 a8    	vpgatherdd %ymm7,(%rax,%ymm13,4),%ymm6
    29c9:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    29cd:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 29f5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d05>
    29d4:	00 
    29d5:	48 8b 46 48          	mov    0x48(%rsi),%rax
    29d9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    29de:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    29e3:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    29e7:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    29ec:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 2a14 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d24>
    29f3:	00 
    29f4:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    29f9:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    29fd:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    2a02:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    2a06:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    2a0a:	c4 c1 55 72 d3 18    	vpsrld $0x18,%ymm11,%ymm5
    2a10:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    2a15:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    2a19:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    2a1f:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    2a23:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    2a27:	c4 43 35 4c cd 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm9
    2a2d:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    2a31:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    2a36:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm9,%ymm9        # 2a3f <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d4f>
    2a3d:	ff ff c0 
    2a40:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    2a46:	c5 7d fe f2          	vpaddd %ymm2,%ymm0,%ymm14
    2a4a:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    2a4e:	c4 a2 45 90 04 b0    	vpgatherdd %ymm7,(%rax,%ymm14,4),%ymm0
    2a54:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2a59:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2a5e:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    2a62:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 2a6b <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d7b>
    2a69:	ff ff 70 
    2a6c:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2a71:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2a75:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    2a79:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    2a7e:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    2a83:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    2a89:	c4 c1 0d fa d1       	vpsubd %ymm9,%ymm14,%ymm2
    2a8e:	c5 75 db cd          	vpand  %ymm5,%ymm1,%ymm9
    2a92:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    2a98:	c5 65 db ed          	vpand  %ymm5,%ymm3,%ymm13
    2a9c:	c5 fd db e5          	vpand  %ymm5,%ymm0,%ymm4
    2aa0:	b8 00 80 00 00       	mov    $0x8000,%eax
    2aa5:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    2aab:	c5 cd db d5          	vpand  %ymm5,%ymm6,%ymm2
    2aaf:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    2ab4:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    2ab9:	c5 8d 72 d0 08       	vpsrld $0x8,%ymm0,%ymm14
    2abe:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    2ac2:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2ac7:	c5 0d db f5          	vpand  %ymm5,%ymm14,%ymm14
    2acb:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2ad0:	c4 41 6d fa cd       	vpsubd %ymm13,%ymm2,%ymm9
    2ad5:	c5 f9 6e d0          	vmovd  %eax,%xmm2
    2ad9:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
    2ade:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    2ae3:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2ae8:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    2aec:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2af1:	c5 15 db ed          	vpand  %ymm5,%ymm13,%ymm13
    2af5:	c5 e5 db dd          	vpand  %ymm5,%ymm3,%ymm3
    2af9:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    2afe:	c5 9d 72 d1 08       	vpsrld $0x8,%ymm1,%ymm12
    2b03:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2b08:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b0d:	c5 1d db e5          	vpand  %ymm5,%ymm12,%ymm12
    2b11:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2b16:	c4 c1 35 72 f4 10    	vpslld $0x10,%ymm12,%ymm9
    2b1c:	c4 41 15 fa e4       	vpsubd %ymm12,%ymm13,%ymm12
    2b21:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    2b27:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    2b2c:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    2b31:	c5 35 fe ca          	vpaddd %ymm2,%ymm9,%ymm9
    2b35:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
    2b39:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    2b3e:	c5 f5 db cd          	vpand  %ymm5,%ymm1,%ymm1
    2b42:	c5 0d fa f4          	vpsubd %ymm4,%ymm14,%ymm14
    2b46:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    2b4b:	c5 95 72 d0 10       	vpsrld $0x10,%ymm0,%ymm13
    2b50:	c4 42 0d 40 f2       	vpmulld %ymm10,%ymm14,%ymm14
    2b55:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    2b5a:	c5 cd db c5          	vpand  %ymm5,%ymm6,%ymm0
    2b5e:	c5 15 db ed          	vpand  %ymm5,%ymm13,%ymm13
    2b62:	c5 15 fa e8          	vpsubd %ymm0,%ymm13,%ymm13
    2b66:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    2b6a:	c4 42 15 40 ea       	vpmulld %ymm10,%ymm13,%ymm13
    2b6f:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    2b74:	c4 c1 5d fe e1       	vpaddd %ymm9,%ymm4,%ymm4
    2b79:	c4 41 0d fe f4       	vpaddd %ymm12,%ymm14,%ymm14
    2b7e:	c5 0d fe f4          	vpaddd %ymm4,%ymm14,%ymm14
    2b82:	c5 dd 72 f1 10       	vpslld $0x10,%ymm1,%ymm4
    2b87:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    2b8b:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    2b90:	c4 c1 0d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm14
    2b96:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    2b9a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2b9e:	c5 15 fe e9          	vpaddd %ymm1,%ymm13,%ymm13
    2ba2:	c5 15 fe e8          	vpaddd %ymm0,%ymm13,%ymm13
    2ba6:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    2bac:	e9 54 ec ff ff       	jmp    1805 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb15>
    2bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2bb8:	4d 85 c9             	test   %r9,%r9
    2bbb:	0f 84 d2 f8 ff ff    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    2bc1:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 2c29 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f39>
    2bc8:	00 
    2bc9:	b8 00 80 00 00       	mov    $0x8000,%eax
    2bce:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 2c56 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f66>
    2bd5:	00 
    2bd6:	49 8d 69 ff          	lea    -0x1(%r9),%rbp
    2bda:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    2bdf:	4d 89 c3             	mov    %r8,%r11
    2be2:	48 c1 ed 03          	shr    $0x3,%rbp
    2be6:	45 31 e4             	xor    %r12d,%r12d
    2be9:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    2bf0:	00 00 
    2bf2:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    2bf6:	c4 c1 25 72 d2 18    	vpsrld $0x18,%ymm10,%ymm11
    2bfc:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2c01:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    2c08:	00 00 
    2c0a:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
    2c11:	00 00 
    2c13:	e9 8e 00 00 00       	jmp    2ca6 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1fb6>
    2c18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2c1f:	00 
    2c20:	8b 47 24             	mov    0x24(%rdi),%eax
    2c23:	8b 57 20             	mov    0x20(%rdi),%edx
    2c26:	c5 f5 fa c7          	vpsubd %ymm7,%ymm1,%ymm0
    2c2a:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    2c2f:	0f af d0             	imul   %eax,%edx
    2c32:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    2c36:	48 8b 07             	mov    (%rdi),%rax
    2c39:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2c3e:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    2c43:	c4 c1 05 fa cd       	vpsubd %ymm13,%ymm15,%ymm1
    2c48:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    2c4c:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2c51:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    2c56:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2c5a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    2c5e:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    2c62:	c4 e2 5d 90 0c 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
    2c68:	c4 e2 75 00 84 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm0
    2c6f:	01 00 00 
    2c72:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2c76:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2c7c:	49 83 c3 18          	add    $0x18,%r11
    2c80:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2c85:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2c8a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2c8e:	c4 c1 79 d6 43 f8    	vmovq  %xmm0,-0x8(%r11)
    2c94:	c4 c1 7a 7f 4b e8    	vmovdqu %xmm1,-0x18(%r11)
    2c9a:	4c 39 e5             	cmp    %r12,%rbp
    2c9d:	0f 84 f0 f7 ff ff    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    2ca3:	49 ff c4             	inc    %r12
    2ca6:	c4 c1 7a 6f 03       	vmovdqu (%r11),%xmm0
    2cab:	c4 c1 7a 7e 4b 10    	vmovq  0x10(%r11),%xmm1
    2cb1:	c5 7d 7f d5          	vmovdqa %ymm10,%ymm5
    2cb5:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    2cb9:	49 8b 02             	mov    (%r10),%rax
    2cbc:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    2cc0:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2cc5:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    2ccb:	41 8b 52 50          	mov    0x50(%r10),%edx
    2ccf:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2cd5:	c5 79 6e f1          	vmovd  %ecx,%xmm14
    2cd9:	c4 e2 7d 00 84 24 00 	vpshufb 0x100(%rsp),%ymm0,%ymm0
    2ce0:	01 00 00 
    2ce3:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    2ce8:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2ced:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    2cf2:	c4 c1 7d db e3       	vpand  %ymm11,%ymm0,%ymm4
    2cf7:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    2cfd:	c4 c1 75 db d3       	vpand  %ymm11,%ymm1,%ymm2
    2d02:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    2d06:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    2d0a:	c4 e2 55 90 04 a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm0
    2d10:	49 8b 42 08          	mov    0x8(%r10),%rax
    2d14:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    2d1b:	00 00 
    2d1d:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    2d22:	c5 cd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm6
    2d27:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    2d2d:	49 8b 42 10          	mov    0x10(%r10),%rax
    2d31:	c5 fe 7f bc 24 c0 01 	vmovdqu %ymm7,0x1c0(%rsp)
    2d38:	00 00 
    2d3a:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    2d3e:	c4 e2 4d 40 f1       	vpmulld %ymm1,%ymm6,%ymm6
    2d43:	c4 e2 65 90 14 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm2
    2d49:	c5 e5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm3
    2d4e:	49 8b 42 48          	mov    0x48(%r10),%rax
    2d52:	c4 c2 65 40 de       	vpmulld %ymm14,%ymm3,%ymm3
    2d57:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    2d5c:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2d60:	c5 65 fe fc          	vpaddd %ymm4,%ymm3,%ymm15
    2d64:	c4 c1 5d 72 d2 0f    	vpsrld $0xf,%ymm10,%ymm4
    2d6a:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
    2d6e:	c4 a2 65 90 34 b8    	vpgatherdd %ymm3,(%rax,%ymm15,4),%ymm6
    2d74:	c5 f9 6e da          	vmovd  %edx,%xmm3
    2d78:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    2d7c:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    2d81:	c5 fd db c4          	vpand  %ymm4,%ymm0,%ymm0
    2d85:	c5 fe 7f b4 24 80 01 	vmovdqu %ymm6,0x180(%rsp)
    2d8c:	00 00 
    2d8e:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2d92:	c4 41 65 fe e7       	vpaddd %ymm15,%ymm3,%ymm12
    2d97:	c4 e2 7d 3d fd       	vpmaxsd %ymm5,%ymm0,%ymm7
    2d9c:	c5 d5 66 f0          	vpcmpgtd %ymm0,%ymm5,%ymm6
    2da0:	c4 a2 35 90 1c a0    	vpgatherdd %ymm9,(%rax,%ymm12,4),%ymm3
    2da6:	c5 7e 7f bc 24 60 01 	vmovdqu %ymm15,0x160(%rsp)
    2dad:	00 00 
    2daf:	c4 62 7d 39 cd       	vpminsd %ymm5,%ymm0,%ymm9
    2db4:	c5 7d 6f c3          	vmovdqa %ymm3,%ymm8
    2db8:	c5 ed 66 df          	vpcmpgtd %ymm7,%ymm2,%ymm3
    2dbc:	c4 62 35 39 ea       	vpminsd %ymm2,%ymm9,%ymm13
    2dc1:	c4 c3 75 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm6
    2dc7:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
    2dcb:	c4 e2 45 3d fa       	vpmaxsd %ymm2,%ymm7,%ymm7
    2dd0:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 2dd9 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20e9>
    2dd7:	ff ff 30 
    2dda:	c4 c1 4d fe f7       	vpaddd %ymm15,%ymm6,%ymm6
    2ddf:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    2de4:	c4 e2 05 90 1c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm3
    2dea:	c5 fd 66 f5          	vpcmpgtd %ymm5,%ymm0,%ymm6
    2dee:	c5 7e 7f a4 24 a0 01 	vmovdqu %ymm12,0x1a0(%rsp)
    2df5:	00 00 
    2df7:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    2dfc:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2e01:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    2e05:	c4 c3 75 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm6
    2e0b:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 2e14 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2124>
    2e12:	ff ff 90 
    2e15:	c5 9d fa f6          	vpsubd %ymm6,%ymm12,%ymm6
    2e19:	c5 25 db a4 24 80 01 	vpand  0x180(%rsp),%ymm11,%ymm12
    2e20:	00 00 
    2e22:	c4 62 05 90 0c b0    	vpgatherdd %ymm15,(%rax,%ymm6,4),%ymm9
    2e28:	c4 41 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm15
    2e2d:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2e32:	c4 c1 4d 72 f4 10    	vpslld $0x10,%ymm12,%ymm6
    2e38:	c4 c1 6d fa d7       	vpsubd %ymm15,%ymm2,%ymm2
    2e3d:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
    2e41:	c5 b5 fa d3          	vpsubd %ymm3,%ymm9,%ymm2
    2e45:	c4 e2 7d 40 d2       	vpmulld %ymm2,%ymm0,%ymm2
    2e4a:	c4 c1 25 db c0       	vpand  %ymm8,%ymm11,%ymm0
    2e4f:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
    2e54:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    2e59:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2e5e:	c5 cd fe b4 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm6,%ymm6
    2e65:	00 00 
    2e67:	49 8b 52 28          	mov    0x28(%r10),%rdx
    2e6b:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    2e70:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    2e77:	00 00 
    2e79:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2e7e:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    2e83:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    2e87:	c5 fe 6f 94 24 40 01 	vmovdqu 0x140(%rsp),%ymm2
    2e8e:	00 00 
    2e90:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2e94:	c5 cd fe f0          	vpaddd %ymm0,%ymm6,%ymm6
    2e98:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
    2e9e:	c5 85 72 d6 10       	vpsrld $0x10,%ymm6,%ymm15
    2ea3:	c4 e2 35 90 34 ba    	vpgatherdd %ymm9,(%rdx,%ymm7,4),%ymm6
    2ea9:	49 8b 52 20          	mov    0x20(%r10),%rdx
    2ead:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2eb2:	c5 cd db f4          	vpand  %ymm4,%ymm6,%ymm6
    2eb6:	c4 e2 35 90 3c 92    	vpgatherdd %ymm9,(%rdx,%ymm2,4),%ymm7
    2ebc:	49 8b 52 18          	mov    0x18(%r10),%rdx
    2ec0:	c4 41 7d 6f ca       	vmovdqa %ymm10,%ymm9
    2ec5:	c5 c5 db fc          	vpand  %ymm4,%ymm7,%ymm7
    2ec9:	c4 e2 35 90 14 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm2
    2ecf:	49 8b 52 40          	mov    0x40(%r10),%rdx
    2ed3:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2ed7:	c4 62 6d 3d e7       	vpmaxsd %ymm7,%ymm2,%ymm12
    2edc:	c5 c5 66 c2          	vpcmpgtd %ymm2,%ymm7,%ymm0
    2ee0:	c4 e2 6d 39 ef       	vpminsd %ymm7,%ymm2,%ymm5
    2ee5:	c4 c1 4d 66 dc       	vpcmpgtd %ymm12,%ymm6,%ymm3
    2eea:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    2eef:	c4 62 1d 3d e6       	vpmaxsd %ymm6,%ymm12,%ymm12
    2ef4:	c5 7e 7f 8c 24 20 02 	vmovdqu %ymm9,0x220(%rsp)
    2efb:	00 00 
    2efd:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    2f01:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2f07:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm0,%ymm0        # 2f10 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2220>
    2f0e:	ff ff 30 
    2f11:	c5 fd fe 84 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm0
    2f18:	00 00 
    2f1a:	c4 e2 15 90 1c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm3
    2f20:	c5 ed 66 c7          	vpcmpgtd %ymm7,%ymm2,%ymm0
    2f24:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    2f29:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    2f2e:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    2f32:	c5 fe 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm7
    2f39:	00 00 
    2f3b:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    2f40:	c4 c3 75 4c c6 00    	vpblendvb %ymm0,%ymm14,%ymm1,%ymm0
    2f46:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm5,-0x1(%rip),%ymm0,%ymm0        # 2f4f <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x225f>
    2f4d:	ff ff 50 
    2f50:	c5 fe 6f ac 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm5
    2f57:	00 00 
    2f59:	c5 d5 fa c0          	vpsubd %ymm0,%ymm5,%ymm0
    2f5d:	c5 fe 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm5
    2f64:	00 00 
    2f66:	c4 62 15 90 0c 80    	vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm9
    2f6c:	c5 7e 7f 84 24 00 02 	vmovdqu %ymm8,0x200(%rsp)
    2f73:	00 00 
    2f75:	c5 95 72 d5 08       	vpsrld $0x8,%ymm5,%ymm13
    2f7a:	c4 c1 55 72 d0 08    	vpsrld $0x8,%ymm8,%ymm5
    2f80:	c5 1d fe 84 24 20 02 	vpaddd 0x220(%rsp),%ymm12,%ymm8
    2f87:	00 00 
    2f89:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    2f8f:	c4 41 15 db eb       	vpand  %ymm11,%ymm13,%ymm13
    2f94:	c4 c1 55 db eb       	vpand  %ymm11,%ymm5,%ymm5
    2f99:	c4 41 35 db cb       	vpand  %ymm11,%ymm9,%ymm9
    2f9e:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    2fa4:	c4 c1 4d fa f0       	vpsubd %ymm8,%ymm6,%ymm6
    2fa9:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    2fad:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2fb1:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
    2fb6:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    2fbb:	c5 fd fe 84 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm0,%ymm0
    2fc2:	00 00 
    2fc4:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    2fc9:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2fce:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    2fd3:	c4 e2 1d 90 14 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm2
    2fd9:	c4 e2 55 40 ac 24 20 	vpmulld 0x220(%rsp),%ymm5,%ymm5
    2fe0:	02 00 00 
    2fe3:	49 8b 52 38          	mov    0x38(%r10),%rdx
    2fe7:	c5 7e 6f ac 24 40 01 	vmovdqu 0x140(%rsp),%ymm13
    2fee:	00 00 
    2ff0:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    2ff5:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    2ffb:	c5 ed db d4          	vpand  %ymm4,%ymm2,%ymm2
    2fff:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
    3003:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    3007:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    300b:	c4 a2 1d 90 2c aa    	vpgatherdd %ymm12,(%rdx,%ymm13,4),%ymm5
    3011:	49 8b 52 30          	mov    0x30(%r10),%rdx
    3015:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
    301a:	c5 d5 db ec          	vpand  %ymm4,%ymm5,%ymm5
    301e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3023:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    3028:	c4 e2 1d 90 1c ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm3
    302e:	c5 e5 db e4          	vpand  %ymm4,%ymm3,%ymm4
    3032:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
    3037:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    303b:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    3040:	c5 ed 66 df          	vpcmpgtd %ymm7,%ymm2,%ymm3
    3044:	c4 62 35 39 e2       	vpminsd %ymm2,%ymm9,%ymm12
    3049:	c4 e2 45 3d fa       	vpmaxsd %ymm2,%ymm7,%ymm7
    304e:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
    3052:	c4 c3 75 4c f6 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm6
    3058:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm6,%ymm6        # 3061 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2371>
    305f:	ff ff 30 
    3062:	c5 cd fe b4 24 60 01 	vpaddd 0x160(%rsp),%ymm6,%ymm6
    3069:	00 00 
    306b:	c4 e2 15 90 1c b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm3
    3071:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    3075:	c4 41 45 fe ec       	vpaddd %ymm12,%ymm7,%ymm13
    307a:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    307f:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    3083:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    3088:	c5 7e 6f 6c 24 40    	vmovdqu 0x40(%rsp),%ymm13
    308e:	c4 c1 65 db db       	vpand  %ymm11,%ymm3,%ymm3
    3093:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3097:	c4 c3 75 4c ce 60    	vpblendvb %ymm6,%ymm14,%ymm1,%ymm1
    309d:	c5 fe 6f b4 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm6
    30a4:	00 00 
    30a6:	c4 41 7d 6f f2       	vmovdqa %ymm10,%ymm14
    30ab:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 30b4 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x23c4>
    30b2:	ff ff 90 
    30b5:	c5 cd fa c9          	vpsubd %ymm1,%ymm6,%ymm1
    30b9:	c5 fe 6f b4 24 80 01 	vmovdqu 0x180(%rsp),%ymm6
    30c0:	00 00 
    30c2:	c4 62 0d 90 04 88    	vpgatherdd %ymm14,(%rax,%ymm1,4),%ymm8
    30c8:	c5 fe 6f 8c 24 00 02 	vmovdqu 0x200(%rsp),%ymm1
    30cf:	00 00 
    30d1:	c5 7e 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm14
    30d8:	00 00 
    30da:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    30df:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    30e5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    30ea:	c4 c1 4d db f3       	vpand  %ymm11,%ymm6,%ymm6
    30ef:	c4 41 3d db c3       	vpand  %ymm11,%ymm8,%ymm8
    30f4:	c4 c1 75 db cb       	vpand  %ymm11,%ymm1,%ymm1
    30f9:	c5 b5 72 f6 10       	vpslld $0x10,%ymm6,%ymm9
    30fe:	c5 bd fa e3          	vpsubd %ymm3,%ymm8,%ymm4
    3102:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    3107:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    310b:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    3110:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    3115:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    311a:	c5 35 fe 8c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm9,%ymm9
    3121:	00 00 
    3123:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
    312a:	00 00 
    312c:	c5 85 66 74 24 60    	vpcmpgtd 0x60(%rsp),%ymm15,%ymm6
    3132:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    3137:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    313b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    313f:	c4 c1 7d fa cf       	vpsubd %ymm15,%ymm0,%ymm1
    3144:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3149:	c5 c5 66 d9          	vpcmpgtd %ymm1,%ymm7,%ymm3
    314d:	c4 c1 6d fa e7       	vpsubd %ymm15,%ymm2,%ymm4
    3152:	c5 8d 66 ec          	vpcmpgtd %ymm4,%ymm14,%ymm5
    3156:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    315a:	c5 dd 66 ac 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm4,%ymm5
    3161:	00 00 
    3163:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    3167:	c4 c1 15 66 ef       	vpcmpgtd %ymm15,%ymm13,%ymm5
    316c:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    3170:	c5 f5 66 b4 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm1,%ymm6
    3177:	00 00 
    3179:	c5 d5 eb ee          	vpor   %ymm6,%ymm5,%ymm5
    317d:	c5 e5 eb dd          	vpor   %ymm5,%ymm3,%ymm3
    3181:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    3185:	85 c0                	test   %eax,%eax
    3187:	0f 84 93 fa ff ff    	je     2c20 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f30>
    318d:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
    3191:	49 8d 72 60          	lea    0x60(%r10),%rsi
    3195:	4d 8d aa 80 01 00 00 	lea    0x180(%r10),%r13
    319c:	80 7e 58 00          	cmpb   $0x0,0x58(%rsi)
    31a0:	0f 85 6a 0e 00 00    	jne    4010 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3320>
    31a6:	80 7e 59 00          	cmpb   $0x0,0x59(%rsi)
    31aa:	c5 fd 7f 0b          	vmovdqa %ymm1,(%rbx)
    31ae:	48 89 da             	mov    %rbx,%rdx
    31b1:	48 89 f1             	mov    %rsi,%rcx
    31b4:	c5 fd 7f 43 20       	vmovdqa %ymm0,0x20(%rbx)
    31b9:	c5 fd 7f 53 40       	vmovdqa %ymm2,0x40(%rbx)
    31be:	0f 84 1c 0e 00 00    	je     3fe0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32f0>
    31c4:	c5 f8 77             	vzeroupper
    31c7:	e8 14 d1 ff ff       	call   2e0 <void jshc_packed_store::(anonymous namespace)::transform<false, true>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    31cc:	c5 fd 6f 0b          	vmovdqa (%rbx),%ymm1
    31d0:	c5 fd 6f 43 20       	vmovdqa 0x20(%rbx),%ymm0
    31d5:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    31da:	c5 fd 6f 53 40       	vmovdqa 0x40(%rbx),%ymm2
    31df:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 3227 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2537>
    31e6:	00 
    31e7:	48 83 c6 60          	add    $0x60,%rsi
    31eb:	49 39 f5             	cmp    %rsi,%r13
    31ee:	75 ac                	jne    319c <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24ac>
    31f0:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    31f5:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    31fa:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    31fe:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    3202:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    3209:	01 00 00 
    320c:	e9 61 fa ff ff       	jmp    2c72 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1f82>
    3211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3218:	84 d2                	test   %dl,%dl
    321a:	0f 84 c8 e1 ff ff    	je     13e8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6f8>
    3220:	4d 85 c9             	test   %r9,%r9
    3223:	0f 84 6a f2 ff ff    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    3229:	49 ff c9             	dec    %r9
    322c:	c5 fd 6f 25 60 00 00 	vmovdqa 0x60(%rip),%ymm4        # 3294 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25a4>
    3233:	00 
    3234:	c5 fd 6f 3d 80 00 00 	vmovdqa 0x80(%rip),%ymm7        # 32bc <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25cc>
    323b:	00 
    323c:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3241:	49 c1 e9 03          	shr    $0x3,%r9
    3245:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
    324b:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    324f:	c5 fe 7f a4 24 00 01 	vmovdqu %ymm4,0x100(%rsp)
    3256:	00 00 
    3258:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    325d:	b8 00 80 00 00       	mov    $0x8000,%eax
    3262:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    3269:	00 00 
    326b:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    326f:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    3274:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    327a:	e9 85 00 00 00       	jmp    3304 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2614>
    327f:	90                   	nop
    3280:	8b 47 24             	mov    0x24(%rdi),%eax
    3283:	8b 57 20             	mov    0x20(%rdi),%edx
    3286:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    328b:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    3290:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    3295:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3299:	0f af d0             	imul   %eax,%edx
    329c:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    32a0:	48 8b 07             	mov    (%rdi),%rax
    32a3:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    32a8:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    32ad:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    32b1:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    32b6:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
    32bb:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    32bf:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    32c3:	c4 e2 45 90 0c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm1
    32c9:	c4 e2 75 00 8c 24 20 	vpshufb 0x120(%rsp),%ymm1,%ymm1
    32d0:	01 00 00 
    32d3:	49 83 c0 18          	add    $0x18,%r8
    32d7:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
    32db:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
    32e1:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
    32e6:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
    32eb:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
    32ef:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
    32f5:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    32fb:	4d 39 c8             	cmp    %r9,%r8
    32fe:	0f 84 8f f1 ff ff    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    3304:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    3309:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
    330f:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3313:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3317:	49 8b 02             	mov    (%r10),%rax
    331a:	41 8b 4a 54          	mov    0x54(%r10),%ecx
    331e:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
    3324:	41 8b 52 50          	mov    0x50(%r10),%edx
    3328:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
    332e:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3332:	c4 e2 75 00 8c 24 00 	vpshufb 0x100(%rsp),%ymm1,%ymm1
    3339:	01 00 00 
    333c:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3340:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3345:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    334a:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    334f:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3353:	c4 e2 45 90 24 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm4
    3359:	49 8b 42 08          	mov    0x8(%r10),%rax
    335d:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
    3361:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3365:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    336a:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    336e:	c4 e2 45 90 34 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm6
    3374:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3379:	49 8b 42 10          	mov    0x10(%r10),%rax
    337d:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 33a5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26b5>
    3384:	00 
    3385:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    338a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    338f:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 33b7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26c7>
    3396:	00 
    3397:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    339c:	c4 e2 55 90 3c 98    	vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm7
    33a2:	49 8b 42 48          	mov    0x48(%r10),%rax
    33a6:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    33aa:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    33af:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 33d7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x26e7>
    33b6:	00 
    33b7:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    33bc:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    33c1:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    33c6:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    33cb:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    33d0:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    33d4:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    33d8:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    33dc:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    33e0:	c4 62 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm14
    33e6:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    33ea:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    33ef:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    33f3:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    33fa:	00 00 
    33fc:	c4 e2 65 90 0c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm1
    3402:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3406:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
    340a:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    340e:	c5 f5 db f0          	vpand  %ymm0,%ymm1,%ymm6
    3412:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    3418:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 3421 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2731>
    341f:	ff ff 80 
    3422:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3427:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
    342d:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    3433:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3438:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    343f:	00 00 
    3441:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm10,%ymm10        # 344a <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x275a>
    3448:	ff ff c0 
    344b:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    344f:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    3453:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3457:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
    345d:	c4 c1 45 fa ea       	vpsubd %ymm10,%ymm7,%ymm5
    3462:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3466:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    346c:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    3470:	c5 8d db d0          	vpand  %ymm0,%ymm14,%ymm2
    3474:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
    3478:	c5 c5 72 f2 10       	vpslld $0x10,%ymm2,%ymm7
    347d:	c5 ad fa d2          	vpsubd %ymm2,%ymm10,%ymm2
    3481:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    3485:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    348a:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    348f:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    3494:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    3499:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    349e:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    34a3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    34a8:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    34ac:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    34b0:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    34b4:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    34b8:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    34be:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    34c2:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    34c7:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    34cb:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    34d0:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    34d5:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    34d9:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
    34dd:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    34e1:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    34e6:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    34eb:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    34f0:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
    34f4:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    34f9:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    34fe:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3502:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3507:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    350c:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3510:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3515:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    3519:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    351d:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3522:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3527:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    352b:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3530:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3534:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    353a:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    3541:	00 00 
    3543:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
    354a:	00 00 
    354c:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3551:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    3557:	c5 6d 66 44 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm8
    355d:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3561:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    3566:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    356a:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    356f:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    3574:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3578:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    357c:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3580:	c5 d5 fa e2          	vpsubd %ymm2,%ymm5,%ymm4
    3584:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3589:	c5 8d 66 dc          	vpcmpgtd %ymm4,%ymm14,%ymm3
    358d:	c5 f5 fa f2          	vpsubd %ymm2,%ymm1,%ymm6
    3591:	c5 a5 66 fe          	vpcmpgtd %ymm6,%ymm11,%ymm7
    3595:	c5 e5 eb df          	vpor   %ymm7,%ymm3,%ymm3
    3599:	c5 cd 66 bc 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm6,%ymm7
    35a0:	00 00 
    35a2:	c5 e5 eb df          	vpor   %ymm7,%ymm3,%ymm3
    35a6:	c5 9d 66 fa          	vpcmpgtd %ymm2,%ymm12,%ymm7
    35aa:	c4 c1 45 eb f8       	vpor   %ymm8,%ymm7,%ymm7
    35af:	c5 5d 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm4,%ymm8
    35b6:	00 00 
    35b8:	c4 c1 45 eb f8       	vpor   %ymm8,%ymm7,%ymm7
    35bd:	c5 e5 eb df          	vpor   %ymm7,%ymm3,%ymm3
    35c1:	c5 fd d7 c3          	vpmovmskb %ymm3,%eax
    35c5:	85 c0                	test   %eax,%eax
    35c7:	0f 84 b3 fc ff ff    	je     3280 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2590>
    35cd:	49 8b 42 60          	mov    0x60(%r10),%rax
    35d1:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    35d5:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    35dc:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    35e3:	c4 e2 45 90 24 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm4
    35e9:	49 8b 42 68          	mov    0x68(%r10),%rax
    35ed:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    35f1:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    35f5:	c5 79 6e d2          	vmovd  %edx,%xmm10
    35f9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    35fe:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3602:	c4 e2 45 90 34 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm6
    3608:	49 8b 42 70          	mov    0x70(%r10),%rax
    360c:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3610:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3615:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    361a:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3642 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2952>
    3621:	00 
    3622:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    3628:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    362d:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    3634:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3638:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    363d:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3642:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 366a <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x297a>
    3649:	00 
    364a:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    364f:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 3677 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2987>
    3656:	00 
    3657:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    365c:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3661:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    3666:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    366b:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3670:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3674:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3678:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    367c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3680:	c4 62 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm14
    3686:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    368a:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    368f:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3693:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    369a:	00 00 
    369c:	c4 e2 65 90 0c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm1
    36a2:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    36a6:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
    36aa:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    36ae:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    36b4:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 36bd <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x29cd>
    36bb:	ff ff 80 
    36be:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    36c3:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
    36c9:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    36cf:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    36d4:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    36db:	00 00 
    36dd:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm10,%ymm10        # 36e6 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x29f6>
    36e4:	ff ff c0 
    36e7:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    36eb:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    36ef:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    36f3:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    36f7:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
    36fd:	c4 c1 45 fa ea       	vpsubd %ymm10,%ymm7,%ymm5
    3702:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    3706:	c4 e2 5d 90 14 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm2
    370c:	c5 65 db e0          	vpand  %ymm0,%ymm3,%ymm12
    3710:	c5 8d db e0          	vpand  %ymm0,%ymm14,%ymm4
    3714:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    371b:	c5 ed db f0          	vpand  %ymm0,%ymm2,%ymm6
    371f:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    3724:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    3728:	c5 c5 fa fe          	vpsubd %ymm6,%ymm7,%ymm7
    372c:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    3731:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3736:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    373b:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3740:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    3745:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    374a:	c5 c5 fe e4          	vpaddd %ymm4,%ymm7,%ymm4
    374e:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3753:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    3757:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    375d:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3761:	c5 d5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm5
    3766:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    376b:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    376f:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    3774:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3779:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    377d:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3781:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3785:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    378a:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    378f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3794:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    3798:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    379d:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    37a2:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    37a6:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    37ab:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    37b0:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    37b5:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    37b9:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    37bd:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    37c1:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    37c5:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    37ca:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    37cf:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    37d3:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    37d8:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    37dc:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    37e1:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    37e7:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    37eb:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    37f0:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    37f4:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    37f9:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    37fe:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3802:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3806:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    380a:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    380e:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
    3814:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    381b:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3820:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3824:	c4 e2 55 90 34 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm6
    382a:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    3831:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    3838:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    383c:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    3843:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3848:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3870 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2b80>
    384f:	00 
    3850:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3854:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3858:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    385c:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    3862:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3867:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    386c:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    3873:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3878:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    387d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3881:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3886:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    388b:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 38b3 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2bc3>
    3892:	00 
    3893:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 38bb <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2bcb>
    389a:	00 
    389b:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    38a0:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    38a5:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    38aa:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    38af:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    38b4:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    38b8:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    38bc:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    38c0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    38c4:	c4 62 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm14
    38ca:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    38ce:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    38d3:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    38d7:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    38de:	00 00 
    38e0:	c4 e2 65 90 0c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm1
    38e6:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    38ea:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
    38ee:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    38f2:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    38f8:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 3901 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2c11>
    38ff:	ff ff 80 
    3902:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3907:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
    390d:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    3914:	00 00 
    3916:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    391b:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm10,%ymm10        # 3924 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2c34>
    3922:	ff ff c0 
    3925:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3929:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    392f:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    3933:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3937:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    393b:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
    3941:	c4 c1 5d fa ea       	vpsubd %ymm10,%ymm4,%ymm5
    3946:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
    394a:	c4 e2 5d 90 14 a8    	vpgatherdd %ymm4,(%rax,%ymm5,4),%ymm2
    3950:	c5 65 db e0          	vpand  %ymm0,%ymm3,%ymm12
    3954:	c5 8d db e0          	vpand  %ymm0,%ymm14,%ymm4
    3958:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    395f:	c5 ed db f0          	vpand  %ymm0,%ymm2,%ymm6
    3963:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    3968:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    396c:	c5 c5 fa fe          	vpsubd %ymm6,%ymm7,%ymm7
    3970:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    3975:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    397a:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    397f:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3984:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    3989:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    398e:	c5 c5 fe e4          	vpaddd %ymm4,%ymm7,%ymm4
    3992:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3997:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    399b:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    39a1:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    39a5:	c5 d5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm5
    39aa:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    39af:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    39b3:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    39b8:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    39bd:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    39c1:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    39c5:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    39c9:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    39ce:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    39d3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    39d8:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    39dc:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    39e1:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    39e6:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    39ea:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    39ef:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    39f4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    39f9:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    39fd:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    3a01:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    3a05:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    3a09:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    3a0e:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    3a13:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    3a17:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3a1c:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    3a20:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    3a25:	c4 c1 5d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm4
    3a2b:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3a2f:	c5 cd 72 f4 10       	vpslld $0x10,%ymm4,%ymm6
    3a34:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    3a38:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    3a3d:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    3a42:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3a46:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3a4a:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3a4e:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    3a52:	c4 e2 6d 90 24 a8    	vpgatherdd %ymm2,(%rax,%ymm5,4),%ymm4
    3a58:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    3a5f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3a64:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3a68:	c4 e2 55 90 34 b8    	vpgatherdd %ymm5,(%rax,%ymm7,4),%ymm6
    3a6e:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    3a75:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3a79:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    3a7e:	c4 e2 55 90 3c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm7
    3a84:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    3a8b:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    3a92:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3a97:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    3a9e:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
    3aa3:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3aa7:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 3acf <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ddf>
    3aae:	00 
    3aaf:	c5 79 6e d2          	vmovd  %edx,%xmm10
    3ab3:	c5 79 6e e9          	vmovd  %ecx,%xmm13
    3ab7:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3abb:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    3ac0:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3ac5:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 3aed <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2dfd>
    3acc:	00 
    3acd:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3ad2:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3ad7:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 3aff <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e0f>
    3ade:	00 
    3adf:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    3ae4:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    3ae9:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    3aee:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    3af3:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    3af8:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    3afc:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3b00:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3b04:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    3b08:	c4 62 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm14
    3b0e:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    3b12:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3b17:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    3b1b:	c5 fe 7f ac 24 40 01 	vmovdqu %ymm5,0x140(%rsp)
    3b22:	00 00 
    3b24:	c4 e2 65 90 0c a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm1
    3b2a:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    3b2e:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
    3b32:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    3b36:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    3b3c:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm3,%ymm3        # 3b45 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e55>
    3b43:	ff ff 80 
    3b46:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    3b4b:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
    3b51:	c5 7e 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm13
    3b57:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    3b5c:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    3b63:	00 00 
    3b65:	c4 63 2d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm10,%ymm10        # 3b6e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e7e>
    3b6c:	ff ff c0 
    3b6f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    3b73:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
    3b77:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    3b7b:	c4 e2 55 90 1c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm3
    3b81:	c4 c1 45 fa ea       	vpsubd %ymm10,%ymm7,%ymm5
    3b86:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    3b8a:	c4 e2 45 90 24 a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm4
    3b90:	c5 65 db e0          	vpand  %ymm0,%ymm3,%ymm12
    3b94:	c5 8d db d0          	vpand  %ymm0,%ymm14,%ymm2
    3b98:	c5 dd db f0          	vpand  %ymm0,%ymm4,%ymm6
    3b9c:	c5 ad 72 f2 10       	vpslld $0x10,%ymm2,%ymm10
    3ba1:	c5 f5 db f8          	vpand  %ymm0,%ymm1,%ymm7
    3ba5:	c5 c5 fa fe          	vpsubd %ymm6,%ymm7,%ymm7
    3ba9:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
    3bad:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    3bb2:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
    3bb7:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    3bbc:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    3bc1:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3bc6:	c5 c5 fe d2          	vpaddd %ymm2,%ymm7,%ymm2
    3bca:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    3bcf:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    3bd5:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3bd9:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    3bde:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3be2:	c5 d5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm5
    3be7:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    3bec:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    3bf0:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    3bf5:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    3bfa:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3bfe:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    3c02:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    3c06:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    3c0b:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    3c10:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3c15:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    3c19:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    3c1e:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    3c23:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    3c27:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    3c2c:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    3c30:	c5 c5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm7
    3c35:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3c3a:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    3c3f:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    3c43:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    3c47:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    3c4d:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    3c51:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    3c55:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3c5a:	c5 e5 fa dc          	vpsubd %ymm4,%ymm3,%ymm3
    3c5e:	c5 ad 72 f6 10       	vpslld $0x10,%ymm6,%ymm10
    3c63:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    3c67:	c5 c5 fa f6          	vpsubd %ymm6,%ymm7,%ymm6
    3c6b:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    3c70:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    3c75:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
    3c7a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    3c7f:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
    3c84:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    3c88:	c4 c1 5d fe e2       	vpaddd %ymm10,%ymm4,%ymm4
    3c8d:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    3c91:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3c96:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    3c9b:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
    3c9f:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
    3ca3:	e9 21 f6 ff ff       	jmp    32c9 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x25d9>
    3ca8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3caf:	00 
    3cb0:	49 8b 42 60          	mov    0x60(%r10),%rax
    3cb4:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    3cb8:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    3cbf:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    3cc6:	c4 e2 5d 90 1c b8    	vpgatherdd %ymm4,(%rax,%ymm7,4),%ymm3
    3ccc:	49 8b 42 68          	mov    0x68(%r10),%rax
    3cd0:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    3cd4:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    3cd8:	c5 79 6e c2          	vmovd  %edx,%xmm8
    3cdc:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    3ce1:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    3ce5:	c4 e2 45 90 24 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
    3ceb:	49 8b 42 70          	mov    0x70(%r10),%rax
    3cef:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    3cf3:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    3cf8:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    3cfd:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 3d25 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3035>
    3d04:	00 
    3d05:	49 8d 8a c0 00 00 00 	lea    0xc0(%r10),%rcx
    3d0c:	c4 e2 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm5
    3d12:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
    3d17:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    3d1e:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    3d22:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    3d27:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3d2c:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 3d54 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3064>
    3d33:	00 
    3d34:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    3d39:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 3d61 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3071>
    3d40:	00 
    3d41:	c4 62 65 39 dc       	vpminsd %ymm4,%ymm3,%ymm11
    3d46:	c5 65 fe e4          	vpaddd %ymm4,%ymm3,%ymm12
    3d4a:	c4 62 25 39 cd       	vpminsd %ymm5,%ymm11,%ymm9
    3d4f:	c5 25 66 dd          	vpcmpgtd %ymm5,%ymm11,%ymm11
    3d53:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    3d57:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    3d5b:	48 8d 93 c0 00 00 00 	lea    0xc0(%rbx),%rdx
    3d62:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3d66:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    3d6b:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    3d6f:	c4 62 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm13
    3d75:	c5 fd fe f9          	vpaddd %ymm1,%ymm0,%ymm7
    3d79:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    3d7f:	c4 e2 6d 90 04 b8    	vpgatherdd %ymm2,(%rax,%ymm7,4),%ymm0
    3d85:	c5 dd 66 d3          	vpcmpgtd %ymm3,%ymm4,%ymm2
    3d89:	c4 e2 65 3d fc       	vpmaxsd %ymm4,%ymm3,%ymm7
    3d8e:	c5 d5 66 f7          	vpcmpgtd %ymm7,%ymm5,%ymm6
    3d92:	c5 e5 66 dc          	vpcmpgtd %ymm4,%ymm3,%ymm3
    3d96:	c4 e2 45 3d fd       	vpmaxsd %ymm5,%ymm7,%ymm7
    3d9b:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3da1:	c4 c3 3d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm8,%ymm2
    3da7:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm2,%ymm2        # 3db0 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x30c0>
    3dae:	ff ff 60 
    3db1:	c4 c1 45 fe f1       	vpaddd %ymm9,%ymm7,%ymm6
    3db6:	c4 43 3d 4c c2 30    	vpblendvb %ymm3,%ymm10,%ymm8,%ymm8
    3dbc:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    3dc0:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm8,%ymm8        # 3dc9 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x30d9>
    3dc7:	ff ff b0 
    3dca:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    3dce:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    3dd3:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    3dd8:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    3ddc:	c5 7e 6f b4 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm14
    3de3:	00 00 
    3de5:	c4 e2 1d 90 14 88    	vpgatherdd %ymm12,(%rax,%ymm1,4),%ymm2
    3deb:	c4 c1 5d fa c8       	vpsubd %ymm8,%ymm4,%ymm1
    3df0:	c4 c1 7d db df       	vpand  %ymm15,%ymm0,%ymm3
    3df5:	c4 e2 55 90 24 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm4
    3dfb:	c4 41 6d db d7       	vpand  %ymm15,%ymm2,%ymm10
    3e00:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    3e05:	c5 bd 72 f5 10       	vpslld $0x10,%ymm5,%ymm8
    3e0a:	c4 c1 5d db cf       	vpand  %ymm15,%ymm4,%ymm1
    3e0f:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
    3e13:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    3e17:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
    3e1c:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    3e21:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    3e26:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    3e2b:	c4 41 3d fe c6       	vpaddd %ymm14,%ymm8,%ymm8
    3e30:	c5 a5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm11
    3e35:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3e3a:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    3e3f:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    3e44:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    3e49:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    3e4d:	c4 c1 3d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm8
    3e53:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
    3e57:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
    3e5c:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    3e61:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    3e66:	c4 c1 2d 72 f0 10    	vpslld $0x10,%ymm8,%ymm10
    3e6c:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    3e71:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    3e76:	c4 41 25 fa c0       	vpsubd %ymm8,%ymm11,%ymm8
    3e7b:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    3e80:	c4 62 3d 40 c7       	vpmulld %ymm7,%ymm8,%ymm8
    3e85:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    3e8b:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    3e8f:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    3e94:	c4 c2 75 40 c9       	vpmulld %ymm9,%ymm1,%ymm1
    3e99:	c4 41 15 db ef       	vpand  %ymm15,%ymm13,%ymm13
    3e9e:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
    3ea3:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3ea8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3ead:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    3eb2:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    3eb7:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    3ebc:	c5 fd 7f 9b c0 00 00 	vmovdqa %ymm3,0xc0(%rbx)
    3ec3:	00 
    3ec4:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    3ec8:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    3ecc:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    3ed1:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    3ed6:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    3edb:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    3ee0:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    3ee4:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
    3eea:	c4 41 6d fa ed       	vpsubd %ymm13,%ymm2,%ymm13
    3eef:	c4 62 15 40 ef       	vpmulld %ymm7,%ymm13,%ymm13
    3ef4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3ef9:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    3efe:	c5 fd 7f 8b e0 00 00 	vmovdqa %ymm1,0xe0(%rbx)
    3f05:	00 
    3f06:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    3f0a:	c4 c1 7d fe c5       	vpaddd %ymm13,%ymm0,%ymm0
    3f0f:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    3f13:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3f18:	c5 fd 7f 83 00 01 00 	vmovdqa %ymm0,0x100(%rbx)
    3f1f:	00 
    3f20:	c5 f8 77             	vzeroupper
    3f23:	e8 d8 c0 ff ff       	call   0 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    3f28:	49 8d 8a 20 01 00 00 	lea    0x120(%r10),%rcx
    3f2f:	e8 cc c0 ff ff       	call   0 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    3f34:	c5 fd 6f 8b 00 01 00 	vmovdqa 0x100(%rbx),%ymm1
    3f3b:	00 
    3f3c:	c5 fd 6f 83 e0 00 00 	vmovdqa 0xe0(%rbx),%ymm0
    3f43:	00 
    3f44:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    3f49:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    3f4e:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    3f52:	c5 fd eb 83 c0 00 00 	vpor   0xc0(%rbx),%ymm0,%ymm0
    3f59:	00 
    3f5a:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    3f61:	01 00 00 
    3f64:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    3f68:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    3f6e:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    3f73:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    3f78:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    3f7c:	c4 c1 79 d6 43 10    	vmovq  %xmm0,0x10(%r11)
    3f82:	c4 c1 7a 7f 0b       	vmovdqu %xmm1,(%r11)
    3f87:	48 39 ee             	cmp    %rbp,%rsi
    3f8a:	0f 84 03 e5 ff ff    	je     2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    3f90:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 3fd8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x32e8>
    3f97:	00 
    3f98:	48 ff c5             	inc    %rbp
    3f9b:	49 83 c3 18          	add    $0x18,%r11
    3f9f:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    3fa4:	e9 b7 ce ff ff       	jmp    e60 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x170>
    3fa9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3fb0:	c5 f8 77             	vzeroupper
    3fb3:	e8 48 c8 ff ff       	call   800 <void jshc_packed_store::(anonymous namespace)::transform<false, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    3fb8:	c5 fd 6f 53 60       	vmovdqa 0x60(%rbx),%ymm2
    3fbd:	c5 fd 6f 8b 80 00 00 	vmovdqa 0x80(%rbx),%ymm1
    3fc4:	00 
    3fc5:	c5 fd 6f 83 a0 00 00 	vmovdqa 0xa0(%rbx),%ymm0
    3fcc:	00 
    3fcd:	c5 7d 6f 3d 40 00 00 	vmovdqa 0x40(%rip),%ymm15        # 4015 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3325>
    3fd4:	00 
    3fd5:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3fda:	e9 b6 de ff ff       	jmp    1e95 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x11a5>
    3fdf:	90                   	nop
    3fe0:	c5 f8 77             	vzeroupper
    3fe3:	e8 18 c8 ff ff       	call   800 <void jshc_packed_store::(anonymous namespace)::transform<false, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    3fe8:	c5 fd 6f 0b          	vmovdqa (%rbx),%ymm1
    3fec:	c5 fd 6f 43 20       	vmovdqa 0x20(%rbx),%ymm0
    3ff1:	c5 fd 6f 53 40       	vmovdqa 0x40(%rbx),%ymm2
    3ff6:	c5 7d 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm11        # 403e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x334e>
    3ffd:	00 
    3ffe:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    4003:	e9 df f1 ff ff       	jmp    31e7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24f7>
    4008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    400f:	00 
    4010:	c5 fd 7f 0b          	vmovdqa %ymm1,(%rbx)
    4014:	48 89 da             	mov    %rbx,%rdx
    4017:	48 89 f1             	mov    %rsi,%rcx
    401a:	c5 fd 7f 43 20       	vmovdqa %ymm0,0x20(%rbx)
    401f:	c5 fd 7f 53 40       	vmovdqa %ymm2,0x40(%rbx)
    4024:	c5 f8 77             	vzeroupper
    4027:	e8 d4 bf ff ff       	call   0 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    402c:	e9 9b f1 ff ff       	jmp    31cc <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x24dc>
    4031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4038:	c5 fd 7f 53 60       	vmovdqa %ymm2,0x60(%rbx)
    403d:	4c 89 f2             	mov    %r14,%rdx
    4040:	48 89 f1             	mov    %rsi,%rcx
    4043:	c5 fd 7f 8b 80 00 00 	vmovdqa %ymm1,0x80(%rbx)
    404a:	00 
    404b:	c5 fd 7f 83 a0 00 00 	vmovdqa %ymm0,0xa0(%rbx)
    4052:	00 
    4053:	c5 f8 77             	vzeroupper
    4056:	e8 a5 bf ff ff       	call   0 <void jshc_packed_store::(anonymous namespace)::transform<true, false>(jshc_packed_store::View const&, jshc_packed_store::(anonymous namespace)::Rgb&)>
    405b:	e9 13 de ff ff       	jmp    1e73 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1183>
    4060:	49 8b 42 60          	mov    0x60(%r10),%rax
    4064:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4068:	41 8b 8a b4 00 00 00 	mov    0xb4(%r10),%ecx
    406f:	49 83 c0 18          	add    $0x18,%r8
    4073:	41 8b 92 b0 00 00 00 	mov    0xb0(%r10),%edx
    407a:	c4 e2 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm3
    4080:	49 8b 42 68          	mov    0x68(%r10),%rax
    4084:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4088:	c5 79 6e e1          	vmovd  %ecx,%xmm12
    408c:	c5 79 6e ca          	vmovd  %edx,%xmm9
    4090:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    4095:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4099:	c4 e2 45 90 2c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm5
    409f:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    40a4:	49 8b 42 70          	mov    0x70(%r10),%rax
    40a8:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    40ac:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    40b1:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    40b6:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 40de <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x33ee>
    40bd:	00 
    40be:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    40c3:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    40c8:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    40ce:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
    40d5:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    40da:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    40de:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4106 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3416>
    40e5:	00 
    40e6:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 410e <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x341e>
    40ed:	00 
    40ee:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    40f2:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    40f7:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    40fc:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    4101:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    4105:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4109:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    410d:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    4111:	c4 62 5d 90 2c 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm13
    4117:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    411b:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    4120:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    4124:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
    412a:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    4131:	00 00 
    4133:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    4139:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    413e:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4143:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    4147:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    414b:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    414f:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 4158 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3468>
    4156:	ff ff 70 
    4159:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    415e:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    4162:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4166:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
    416c:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
    4172:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    4176:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    417a:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm9,%ymm9        # 4183 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3493>
    4181:	ff ff b0 
    4184:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
    418a:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    4191:	00 00 
    4193:	c4 c1 15 db df       	vpand  %ymm15,%ymm13,%ymm3
    4198:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    419d:	c4 41 6d db df       	vpand  %ymm15,%ymm2,%ymm11
    41a2:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    41a7:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
    41ac:	c5 a5 fa db          	vpsubd %ymm3,%ymm11,%ymm3
    41b0:	c4 e2 55 90 0c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm1
    41b6:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    41bb:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    41c0:	49 8b 82 c0 00 00 00 	mov    0xc0(%r10),%rax
    41c7:	c4 c1 75 db ef       	vpand  %ymm15,%ymm1,%ymm5
    41cc:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    41d0:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    41d5:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    41da:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    41df:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    41e3:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    41e8:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    41ee:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    41f2:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    41f7:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    41fc:	c5 dd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm4
    4201:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    4206:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    420b:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    4210:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    4215:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    421a:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    421f:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    4223:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    4228:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    422d:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4232:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    4236:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    423b:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    4240:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    4245:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    424a:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    424f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4254:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    4259:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    425e:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    4262:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    4266:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    426b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4270:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    4274:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    4279:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    427d:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4281:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    4286:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    428c:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    4291:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    4296:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    429a:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    429f:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    42a4:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    42a8:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    42ac:	c4 e2 45 90 1c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm3
    42b2:	49 8b 82 c8 00 00 00 	mov    0xc8(%r10),%rax
    42b9:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    42bd:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    42c1:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    42c5:	c4 e2 5d 90 2c b0    	vpgatherdd %ymm4,(%rax,%ymm6,4),%ymm5
    42cb:	41 8b 8a 14 01 00 00 	mov    0x114(%r10),%ecx
    42d2:	41 8b 92 10 01 00 00 	mov    0x110(%r10),%edx
    42d9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    42de:	49 8b 82 d0 00 00 00 	mov    0xd0(%r10),%rax
    42e5:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    42e9:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    42ee:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 4316 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3626>
    42f5:	00 
    42f6:	c5 79 6e e1          	vmovd  %ecx,%xmm12
    42fa:	c5 79 6e ca          	vmovd  %edx,%xmm9
    42fe:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4302:	c4 e2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm6
    4308:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    430d:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4312:	49 8b 82 08 01 00 00 	mov    0x108(%r10),%rax
    4319:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    431e:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    4323:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    4327:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    432c:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    4331:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4359 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3669>
    4338:	00 
    4339:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    433e:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 4366 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3676>
    4345:	00 
    4346:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    434b:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    4350:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    4355:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    4359:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    435d:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4361:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    4365:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    4369:	c4 62 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm13
    436f:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    4373:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    437a:	00 00 
    437c:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    4382:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4387:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
    438d:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4392:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    4396:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    439a:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    439e:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 43a7 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36b7>
    43a5:	ff ff 70 
    43a8:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    43ad:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    43b1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    43b5:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
    43bb:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
    43c1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    43c5:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    43c9:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm9,%ymm9        # 43d2 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36e2>
    43d0:	ff ff b0 
    43d3:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
    43d9:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    43e0:	00 00 
    43e2:	c4 c1 15 db df       	vpand  %ymm15,%ymm13,%ymm3
    43e7:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    43ec:	c4 41 6d db df       	vpand  %ymm15,%ymm2,%ymm11
    43f1:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    43f6:	c5 b5 72 f3 10       	vpslld $0x10,%ymm3,%ymm9
    43fb:	c5 a5 fa db          	vpsubd %ymm3,%ymm11,%ymm3
    43ff:	c4 e2 55 90 0c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm1
    4405:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    440a:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    440f:	49 8b 82 20 01 00 00 	mov    0x120(%r10),%rax
    4416:	c4 c1 75 db ef       	vpand  %ymm15,%ymm1,%ymm5
    441b:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    441f:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    4424:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    4429:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    442e:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    4432:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    4437:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    443d:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4441:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    4446:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    444b:	c5 dd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm4
    4450:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    4455:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    445a:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    445f:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    4464:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    4469:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    446e:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    4472:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    4477:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    447c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4481:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    4485:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    448a:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    448f:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    4494:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    4499:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    449e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    44a3:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    44a8:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    44ad:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    44b1:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    44b5:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    44ba:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    44bf:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    44c3:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    44c8:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    44cc:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    44d0:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    44d5:	c4 c1 65 72 d5 10    	vpsrld $0x10,%ymm13,%ymm3
    44db:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    44e0:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    44e5:	c5 ed fa db          	vpsubd %ymm3,%ymm2,%ymm3
    44e9:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
    44ee:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
    44f3:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    44f7:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    44fb:	c4 e2 45 90 1c a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm3
    4501:	49 8b 82 28 01 00 00 	mov    0x128(%r10),%rax
    4508:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    450c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4510:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    4514:	c4 e2 45 90 2c b0    	vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm5
    451a:	49 8b 82 30 01 00 00 	mov    0x130(%r10),%rax
    4521:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4526:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    452a:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    452f:	c4 e2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm6
    4535:	41 8b 8a 74 01 00 00 	mov    0x174(%r10),%ecx
    453c:	41 8b 92 70 01 00 00 	mov    0x170(%r10),%edx
    4543:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    4548:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    454d:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 4575 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3885>
    4554:	00 
    4555:	49 8b 82 68 01 00 00 	mov    0x168(%r10),%rax
    455c:	c5 79 6e ca          	vmovd  %edx,%xmm9
    4560:	c5 79 6e e1          	vmovd  %ecx,%xmm12
    4564:	8d 54 11 01          	lea    0x1(%rcx,%rdx,1),%edx
    4568:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    456d:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4572:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    4576:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    457b:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    4580:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 45a8 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x38b8>
    4587:	00 
    4588:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    458d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 45b5 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x38c5>
    4594:	00 
    4595:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    459a:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    459f:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    45a4:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    45a8:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    45ac:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    45b0:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    45b4:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    45b8:	c4 62 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm13
    45be:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    45c2:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    45c9:	00 00 
    45cb:	c4 e2 45 90 04 a0    	vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
    45d1:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    45d6:	c4 c3 35 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm9,%ymm2
    45dc:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    45e1:	c5 e5 fe e5          	vpaddd %ymm5,%ymm3,%ymm4
    45e5:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    45e9:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    45ed:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 45f6 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3906>
    45f4:	ff ff 70 
    45f7:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    45fc:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    4600:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4604:	c4 43 35 4c cc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm9
    460a:	c5 7e 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm12
    4610:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
    4614:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    4618:	c4 63 35 4c 0d ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm9,%ymm9        # 4621 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3931>
    461f:	ff ff b0 
    4622:	c4 e2 5d 90 14 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm2
    4628:	c5 fe 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm4
    462f:	00 00 
    4631:	c4 c1 15 db cf       	vpand  %ymm15,%ymm13,%ymm1
    4636:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    463b:	c4 41 6d db df       	vpand  %ymm15,%ymm2,%ymm11
    4640:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    4645:	c5 b5 72 f1 10       	vpslld $0x10,%ymm1,%ymm9
    464a:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    464e:	c4 e2 55 90 1c a0    	vpgatherdd %ymm5,(%rax,%ymm4,4),%ymm3
    4654:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    4659:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    465e:	c4 c1 65 db ef       	vpand  %ymm15,%ymm3,%ymm5
    4663:	c5 cd fa f5          	vpsubd %ymm5,%ymm6,%ymm6
    4667:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    466c:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    4671:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    4676:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    467a:	c4 c1 55 fe e9       	vpaddd %ymm9,%ymm5,%ymm5
    467f:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    4685:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    4689:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    468e:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    4693:	c5 dd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm4
    4698:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    469d:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    46a2:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    46a7:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    46ac:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    46b1:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    46b6:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    46ba:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    46bf:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    46c4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    46c9:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    46cd:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    46d2:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    46d7:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    46dc:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    46e1:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    46e5:	c5 cd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm6
    46ea:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    46ef:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    46f4:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    46f9:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    46fd:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
    4703:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    4708:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    470d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4712:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    4716:	c5 b5 72 f5 10       	vpslld $0x10,%ymm5,%ymm9
    471b:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    471f:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    4723:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    4728:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    472d:	c4 41 35 fe cc       	vpaddd %ymm12,%ymm9,%ymm9
    4732:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    4737:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    473c:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    4740:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
    4745:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4749:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    474e:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    4753:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    4757:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    475b:	c4 e2 7d 00 84 24 20 	vpshufb 0x120(%rsp),%ymm0,%ymm0
    4762:	01 00 00 
    4765:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    4769:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    476f:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    4774:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    4779:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    477d:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    4783:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    4789:	4d 39 c1             	cmp    %r8,%r9
    478c:	0f 85 96 d7 ff ff    	jne    1f28 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1238>
    4792:	e9 fc dc ff ff       	jmp    2493 <jshc_packed_store::avx2_chain_cached(jshc_packed_store::View const*, jshc_packed_store::SuffixCacheView const&, unsigned char*, unsigned long long)+0x17a3>
    4797:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    479e:	00 00 

00000000000047a0 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    47a0:	57                   	push   %rdi
    47a1:	56                   	push   %rsi
    47a2:	53                   	push   %rbx
    47a3:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
    47aa:	c5 f8 29 b4 24 20 02 	vmovaps %xmm6,0x220(%rsp)
    47b1:	00 00 
    47b3:	c5 f8 29 bc 24 30 02 	vmovaps %xmm7,0x230(%rsp)
    47ba:	00 00 
    47bc:	c5 78 29 84 24 40 02 	vmovaps %xmm8,0x240(%rsp)
    47c3:	00 00 
    47c5:	c5 78 29 8c 24 50 02 	vmovaps %xmm9,0x250(%rsp)
    47cc:	00 00 
    47ce:	c5 78 29 94 24 60 02 	vmovaps %xmm10,0x260(%rsp)
    47d5:	00 00 
    47d7:	c5 78 29 9c 24 70 02 	vmovaps %xmm11,0x270(%rsp)
    47de:	00 00 
    47e0:	c5 78 29 a4 24 80 02 	vmovaps %xmm12,0x280(%rsp)
    47e7:	00 00 
    47e9:	c5 78 29 ac 24 90 02 	vmovaps %xmm13,0x290(%rsp)
    47f0:	00 00 
    47f2:	c5 78 29 b4 24 a0 02 	vmovaps %xmm14,0x2a0(%rsp)
    47f9:	00 00 
    47fb:	c5 78 29 bc 24 b0 02 	vmovaps %xmm15,0x2b0(%rsp)
    4802:	00 00 
    4804:	49 89 d3             	mov    %rdx,%r11
    4807:	48 83 fa 04          	cmp    $0x4,%rdx
    480b:	0f 84 f8 08 00 00    	je     5109 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x969>
    4811:	4d 85 c9             	test   %r9,%r9
    4814:	0f 84 7a 08 00 00    	je     5094 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    481a:	49 ff c9             	dec    %r9
    481d:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 4885 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe5>
    4824:	00 
    4825:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
    4829:	49 c1 e9 03          	shr    $0x3,%r9
    482d:	49 c1 e2 05          	shl    $0x5,%r10
    4831:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    4835:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    483c:	00 00 
    483e:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 48c6 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x126>
    4845:	00 
    4846:	49 01 ca             	add    %rcx,%r10
    4849:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
    484e:	b8 00 80 00 00       	mov    $0x8000,%eax
    4853:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    4857:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    485e:	00 00 
    4860:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    4864:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4869:	c5 95 72 d6 18       	vpsrld $0x18,%ymm6,%ymm13
    486e:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    4873:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4878:	c4 c1 7a 6f 10       	vmovdqu (%r8),%xmm2
    487d:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    4883:	c4 e3 79 0f c2 0c    	vpalignr $0xc,%xmm2,%xmm0,%xmm0
    4889:	c4 e3 6d 38 d0 01    	vinserti128 $0x1,%xmm0,%ymm2,%ymm2
    488f:	c4 e2 6d 00 94 24 e0 	vpshufb 0x1e0(%rsp),%ymm2,%ymm2
    4896:	01 00 00 
    4899:	c5 dd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm4
    489e:	c4 c1 6d db c5       	vpand  %ymm13,%ymm2,%ymm0
    48a3:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    48a8:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    48ad:	4d 85 db             	test   %r11,%r11
    48b0:	0f 84 4a 08 00 00    	je     5100 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x960>
    48b6:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
    48bd:	00 00 
    48bf:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    48c3:	48 89 c8             	mov    %rcx,%rax
    48c6:	c5 fd 6f cc          	vmovdqa %ymm4,%ymm1
    48ca:	e9 22 02 00 00       	jmp    4af1 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    48cf:	90                   	nop
    48d0:	c4 c1 5d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm4
    48d6:	c5 c5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm7
    48db:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    48df:	c5 c5 fe fa          	vpaddd %ymm2,%ymm7,%ymm7
    48e3:	c5 dd fe e0          	vpaddd %ymm0,%ymm4,%ymm4
    48e7:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    48ec:	c4 c1 3d 72 f0 10    	vpslld $0x10,%ymm8,%ymm8
    48f2:	c5 f5 72 e1 10       	vpsrad $0x10,%ymm1,%ymm1
    48f7:	c5 dd fe ef          	vpaddd %ymm7,%ymm4,%ymm5
    48fb:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4902:	00 00 
    4904:	c4 c1 55 72 e1 10    	vpsrad $0x10,%ymm9,%ymm5
    490a:	c4 c1 35 72 f1 10    	vpslld $0x10,%ymm9,%ymm9
    4910:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    4914:	c4 c1 35 72 e1 10    	vpsrad $0x10,%ymm9,%ymm9
    491a:	c4 c1 3d 72 e0 10    	vpsrad $0x10,%ymm8,%ymm8
    4920:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    4924:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
    4928:	c5 b5 fe db          	vpaddd %ymm3,%ymm9,%ymm3
    492c:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    4930:	c4 62 7d 3d c9       	vpmaxsd %ymm1,%ymm0,%ymm9
    4935:	c5 75 66 c0          	vpcmpgtd %ymm0,%ymm1,%ymm8
    4939:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    4940:	00 00 
    4942:	c4 c1 65 66 d1       	vpcmpgtd %ymm9,%ymm3,%ymm2
    4947:	c4 62 7d 39 d1       	vpminsd %ymm1,%ymm0,%ymm10
    494c:	c4 62 35 3d cb       	vpmaxsd %ymm3,%ymm9,%ymm9
    4951:	c5 fd 66 c9          	vpcmpgtd %ymm1,%ymm0,%ymm1
    4955:	c4 62 2d 39 db       	vpminsd %ymm3,%ymm10,%ymm11
    495a:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    495f:	c5 2d 66 d3          	vpcmpgtd %ymm3,%ymm10,%ymm10
    4963:	c4 63 1d 4c 44 24 60 	vpblendvb %ymm8,0x60(%rsp),%ymm12,%ymm8
    496a:	80 
    496b:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    4971:	c4 63 3d 4c 05 ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm8,%ymm8        # 497a <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1da>
    4978:	ff ff 20 
    497b:	c5 3d fe 44 24 20    	vpaddd 0x20(%rsp),%ymm8,%ymm8
    4981:	c4 e3 1d 4c 4c 24 60 	vpblendvb %ymm1,0x60(%rsp),%ymm12,%ymm1
    4988:	10 
    4989:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm1,%ymm1        # 4992 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f2>
    4990:	ff ff a0 
    4993:	c4 a2 0d 90 14 82    	vpgatherdd %ymm14,(%rdx,%ymm8,4),%ymm2
    4999:	c5 e5 fa c9          	vpsubd %ymm1,%ymm3,%ymm1
    499d:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    49a1:	c4 e2 0d 90 1c 8a    	vpgatherdd %ymm14,(%rdx,%ymm1,4),%ymm3
    49a7:	c5 fe 6f 8c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm1
    49ae:	00 00 
    49b0:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
    49b5:	c4 62 5d 3d c7       	vpmaxsd %ymm7,%ymm4,%ymm8
    49ba:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    49bf:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    49c4:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    49c8:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    49cd:	c4 c1 75 fa cb       	vpsubd %ymm11,%ymm1,%ymm1
    49d2:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
    49d6:	c5 e5 fa ca          	vpsubd %ymm2,%ymm3,%ymm1
    49da:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
    49e1:	00 00 
    49e3:	c5 85 fa db          	vpsubd %ymm3,%ymm15,%ymm3
    49e7:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    49ec:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
    49f2:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    49f7:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
    49fc:	c4 62 5d 39 cf       	vpminsd %ymm7,%ymm4,%ymm9
    4a01:	c4 62 35 39 d5       	vpminsd %ymm5,%ymm9,%ymm10
    4a06:	c5 35 66 cd          	vpcmpgtd %ymm5,%ymm9,%ymm9
    4a0a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    4a0e:	c5 c5 66 dc          	vpcmpgtd %ymm4,%ymm7,%ymm3
    4a12:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
    4a19:	00 00 
    4a1b:	c5 dd 66 e7          	vpcmpgtd %ymm7,%ymm4,%ymm4
    4a1f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
    4a26:	00 00 
    4a28:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4a2c:	c4 c1 55 66 d0       	vpcmpgtd %ymm8,%ymm5,%ymm2
    4a31:	c4 c3 1d 4c df 30    	vpblendvb %ymm3,%ymm15,%ymm12,%ymm3
    4a37:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    4a3d:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4a41:	c4 62 3d 3d c5       	vpmaxsd %ymm5,%ymm8,%ymm8
    4a46:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 4a4f <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2af>
    4a4d:	ff ff 90 
    4a50:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4a55:	c4 c1 55 fa e8       	vpsubd %ymm8,%ymm5,%ymm5
    4a5a:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm3        # 4a63 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2c3>
    4a61:	ff ff 20 
    4a64:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4a68:	c5 e5 fe 5c 24 20    	vpaddd 0x20(%rsp),%ymm3,%ymm3
    4a6e:	c4 e2 0d 90 14 9a    	vpgatherdd %ymm14,(%rdx,%ymm3,4),%ymm2
    4a74:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    4a7a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4a7f:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    4a83:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4a88:	c4 e2 1d 90 1c a2    	vpgatherdd %ymm12,(%rdx,%ymm4,4),%ymm3
    4a8e:	c4 c1 45 fa e2       	vpsubd %ymm10,%ymm7,%ymm4
    4a93:	c5 fe 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm7
    4a9a:	00 00 
    4a9c:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4aa1:	c5 dd fe ed          	vpaddd %ymm5,%ymm4,%ymm5
    4aa5:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    4aaa:	c5 e5 fa e2          	vpsubd %ymm2,%ymm3,%ymm4
    4aae:	c5 c5 fa db          	vpsubd %ymm3,%ymm7,%ymm3
    4ab2:	c4 e2 55 40 e4       	vpmulld %ymm4,%ymm5,%ymm4
    4ab7:	c5 ed fa 94 24 40 01 	vpsubd 0x140(%rsp),%ymm2,%ymm2
    4abe:	00 00 
    4ac0:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    4ac5:	48 83 c0 60          	add    $0x60,%rax
    4ac9:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    4ace:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    4ad2:	c5 ed fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm2,%ymm2
    4ad9:	00 00 
    4adb:	c5 dd fe d2          	vpaddd %ymm2,%ymm4,%ymm2
    4adf:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4ae4:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    4ae8:	49 39 c2             	cmp    %rax,%r10
    4aeb:	0f 84 46 05 00 00    	je     5037 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x897>
    4af1:	8b 58 54             	mov    0x54(%rax),%ebx
    4af4:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4af8:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
    4aff:	00 00 
    4b01:	c5 fd 6f c6          	vmovdqa %ymm6,%ymm0
    4b05:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
    4b0c:	00 00 
    4b0e:	8b 70 50             	mov    0x50(%rax),%esi
    4b11:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4b15:	c5 7d 6f d6          	vmovdqa %ymm6,%ymm10
    4b19:	c5 f9 6e fb          	vmovd  %ebx,%xmm7
    4b1d:	c4 e2 7d 90 14 8a    	vpgatherdd %ymm0,(%rdx,%ymm1,4),%ymm2
    4b23:	48 8b 10             	mov    (%rax),%rdx
    4b26:	48 8b 78 10          	mov    0x10(%rax),%rdi
    4b2a:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    4b2f:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    4b36:	00 00 
    4b38:	c5 79 6e e6          	vmovd  %esi,%xmm12
    4b3c:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    4b41:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    4b47:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    4b4c:	c5 f5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm1
    4b51:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    4b55:	c4 e2 65 90 04 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm0
    4b5b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4b60:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
    4b67:	00 00 
    4b69:	48 8b 50 48          	mov    0x48(%rax),%rdx
    4b6d:	c5 dd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm4
    4b72:	c4 a2 2d 90 1c 9f    	vpgatherdd %ymm10,(%rdi,%ymm11,4),%ymm3
    4b78:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 4ba0 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x400>
    4b7f:	00 
    4b80:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    4b85:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
    4b8a:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 4bb2 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x412>
    4b91:	00 
    4b92:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4bba <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x41a>
    4b99:	00 
    4b9a:	c5 7d 6f ce          	vmovdqa %ymm6,%ymm9
    4b9e:	c5 7d 6f ff          	vmovdqa %ymm7,%ymm15
    4ba2:	c4 62 6d 39 c0       	vpminsd %ymm0,%ymm2,%ymm8
    4ba7:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4bab:	c5 f5 fe e5          	vpaddd %ymm5,%ymm1,%ymm4
    4baf:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4bb3:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    4bb9:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    4bbf:	c5 f5 72 d5 08       	vpsrld $0x8,%ymm5,%ymm1
    4bc4:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4bc9:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    4bd0:	00 00 
    4bd2:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4bd7:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4bdc:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
    4be3:	00 00 
    4be5:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4bea:	c4 c1 55 db ed       	vpand  %ymm13,%ymm5,%ymm5
    4bef:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4bf4:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    4bfb:	00 00 
    4bfd:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    4c02:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4c07:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
    4c0c:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    4c13:	00 00 
    4c15:	c5 f9 6e ce          	vmovd  %esi,%xmm1
    4c19:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4c1e:	c5 75 fe dc          	vpaddd %ymm4,%ymm1,%ymm11
    4c22:	c5 bd 66 e3          	vpcmpgtd %ymm3,%ymm8,%ymm4
    4c26:	c5 fd 6f ce          	vmovdqa %ymm6,%ymm1
    4c2a:	c5 7e 7f 5c 24 40    	vmovdqu %ymm11,0x40(%rsp)
    4c30:	c4 62 3d 39 c3       	vpminsd %ymm3,%ymm8,%ymm8
    4c35:	c4 22 75 90 14 9a    	vpgatherdd %ymm1,(%rdx,%ymm11,4),%ymm10
    4c3b:	c5 fd 66 ca          	vpcmpgtd %ymm2,%ymm0,%ymm1
    4c3f:	c4 e3 1d 4c cf 10    	vpblendvb %ymm1,%ymm7,%ymm12,%ymm1
    4c45:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm1,%ymm1        # 4c4e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ae>
    4c4c:	ff ff 40 
    4c4f:	c5 ed 66 e0          	vpcmpgtd %ymm0,%ymm2,%ymm4
    4c53:	c5 a5 fa c9          	vpsubd %ymm1,%ymm11,%ymm1
    4c57:	c4 41 2d db dd       	vpand  %ymm13,%ymm10,%ymm11
    4c5c:	c4 e2 35 90 3c 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm7
    4c62:	c5 0d fe 34 24       	vpaddd (%rsp),%ymm14,%ymm14
    4c67:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    4c6b:	c5 95 db cf          	vpand  %ymm7,%ymm13,%ymm1
    4c6f:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    4c76:	00 00 
    4c78:	c4 c3 1d 4c e7 40    	vpblendvb %ymm4,%ymm15,%ymm12,%ymm4
    4c7e:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    4c82:	c4 c2 25 40 f8       	vpmulld %ymm8,%ymm11,%ymm7
    4c87:	c5 7d 6f de          	vmovdqa %ymm6,%ymm11
    4c8b:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
    4c92:	00 00 
    4c94:	c4 e2 6d 3d f8       	vpmaxsd %ymm0,%ymm2,%ymm7
    4c99:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
    4c9d:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
    4ca2:	c5 3d fe ff          	vpaddd %ymm7,%ymm8,%ymm15
    4ca6:	c4 41 65 fa ff       	vpsubd %ymm15,%ymm3,%ymm15
    4cab:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm4,%ymm4        # 4cb4 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
    4cb2:	ff ff 90 
    4cb5:	c5 dd fe 64 24 20    	vpaddd 0x20(%rsp),%ymm4,%ymm4
    4cbb:	c4 62 25 90 0c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm9
    4cc1:	c5 6d fe d8          	vpaddd %ymm0,%ymm2,%ymm11
    4cc5:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    4cca:	c4 41 05 fe db       	vpaddd %ymm11,%ymm15,%ymm11
    4ccf:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    4cd3:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    4cd7:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4cdc:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    4ce1:	c5 dd fe a4 24 80 00 	vpaddd 0x80(%rsp),%ymm4,%ymm4
    4ce8:	00 00 
    4cea:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    4cef:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    4cf3:	c5 d5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm5
    4cf8:	c4 c1 75 72 d2 08    	vpsrld $0x8,%ymm10,%ymm1
    4cfe:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    4d04:	c5 fe 7f ac 24 c0 01 	vmovdqu %ymm5,0x1c0(%rsp)
    4d0b:	00 00 
    4d0d:	c4 41 75 db fd       	vpand  %ymm13,%ymm1,%ymm15
    4d12:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    4d19:	00 00 
    4d1b:	c4 c1 2d db ed       	vpand  %ymm13,%ymm10,%ymm5
    4d20:	c5 fe 7f ac 24 80 01 	vmovdqu %ymm5,0x180(%rsp)
    4d27:	00 00 
    4d29:	0f 85 49 02 00 00    	jne    4f78 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d8>
    4d2f:	48 8b 58 28          	mov    0x28(%rax),%rbx
    4d33:	c5 fe 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm5
    4d3a:	00 00 
    4d3c:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4d40:	48 8b 78 18          	mov    0x18(%rax),%rdi
    4d44:	80 78 59 00          	cmpb   $0x0,0x59(%rax)
    4d48:	c4 62 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm9
    4d4e:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    4d55:	00 00 
    4d57:	48 8b 58 20          	mov    0x20(%rax),%rbx
    4d5b:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4d5f:	c4 e2 45 90 0c ab    	vpgatherdd %ymm7,(%rbx,%ymm5,4),%ymm1
    4d65:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
    4d6c:	00 00 
    4d6e:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4d72:	c4 62 45 90 04 af    	vpgatherdd %ymm7,(%rdi,%ymm5,4),%ymm8
    4d78:	0f 85 52 fb ff ff    	jne    48d0 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x130>
    4d7e:	c5 f5 db 0d 20 00 00 	vpand  0x20(%rip),%ymm1,%ymm1        # 4da6 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x606>
    4d85:	00 
    4d86:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 4dae <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x60e>
    4d8d:	00 
    4d8e:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4d92:	c5 b5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm9,%ymm3        # 4dba <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x61a>
    4d99:	00 
    4d9a:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
    4da0:	c4 e2 3d 3d e9       	vpmaxsd %ymm1,%ymm8,%ymm5
    4da5:	c4 c1 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm2
    4daa:	c5 7e 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm11
    4db0:	c4 e2 3d 39 e1       	vpminsd %ymm1,%ymm8,%ymm4
    4db5:	c5 e5 66 c5          	vpcmpgtd %ymm5,%ymm3,%ymm0
    4db9:	c4 e2 5d 39 fb       	vpminsd %ymm3,%ymm4,%ymm7
    4dbe:	c4 e2 55 3d eb       	vpmaxsd %ymm3,%ymm5,%ymm5
    4dc3:	48 8b 58 40          	mov    0x40(%rax),%rbx
    4dc7:	c5 dd 66 e3          	vpcmpgtd %ymm3,%ymm4,%ymm4
    4dcb:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4dd1:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 4dda <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
    4dd8:	ff ff 00 
    4ddb:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    4de0:	c4 e2 0d 90 04 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm0
    4de6:	c5 bd 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm2
    4dea:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4dee:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    4df2:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    4df7:	c5 d5 fe cf          	vpaddd %ymm7,%ymm5,%ymm1
    4dfb:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    4dff:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    4e04:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4e08:	c4 c3 1d 4c d2 20    	vpblendvb %ymm2,%ymm10,%ymm12,%ymm2
    4e0e:	c5 bd fa c9          	vpsubd %ymm1,%ymm8,%ymm1
    4e12:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm4,-0x1(%rip),%ymm2,%ymm2        # 4e1b <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x67b>
    4e19:	ff ff 40 
    4e1c:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    4e22:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    4e26:	c4 e2 0d 90 24 92    	vpgatherdd %ymm14,(%rdx,%ymm2,4),%ymm4
    4e2c:	c5 7d 6f f6          	vmovdqa %ymm6,%ymm14
    4e30:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    4e35:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    4e3a:	c5 05 fa fc          	vpsubd %ymm4,%ymm15,%ymm15
    4e3e:	c5 dd fa d0          	vpsubd %ymm0,%ymm4,%ymm2
    4e42:	c4 62 05 40 ff       	vpmulld %ymm7,%ymm15,%ymm15
    4e47:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    4e4e:	00 00 
    4e50:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    4e55:	c5 fd fa 84 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm0
    4e5c:	00 00 
    4e5e:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    4e65:	00 00 
    4e67:	c4 e2 65 90 24 bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm4
    4e6d:	48 8b 58 38          	mov    0x38(%rax),%rbx
    4e71:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
    4e78:	00 00 
    4e7a:	c5 fd 6f de          	vmovdqa %ymm6,%ymm3
    4e7e:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    4e83:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 4eab <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70b>
    4e8a:	00 
    4e8b:	c4 e2 65 90 2c bb    	vpgatherdd %ymm3,(%rbx,%ymm7,4),%ymm5
    4e91:	48 8b 58 30          	mov    0x30(%rax),%rbx
    4e95:	c5 fd 6f fe          	vmovdqa %ymm6,%ymm7
    4e99:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 4ec1 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x721>
    4ea0:	00 
    4ea1:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    4ea6:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    4eab:	c4 e2 45 90 1c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm3
    4eb1:	c5 e5 db 1d 20 00 00 	vpand  0x20(%rip),%ymm3,%ymm3        # 4ed9 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x739>
    4eb8:	00 
    4eb9:	c5 fd fe 84 24 20 01 	vpaddd 0x120(%rsp),%ymm0,%ymm0
    4ec0:	00 00 
    4ec2:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    4ec7:	c5 d5 66 fb          	vpcmpgtd %ymm3,%ymm5,%ymm7
    4ecb:	c4 62 65 39 cd       	vpminsd %ymm5,%ymm3,%ymm9
    4ed0:	c4 c1 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm2
    4ed5:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
    4eda:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    4ede:	c5 fd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm0
    4ee3:	c4 c3 1d 4c fa 70    	vpblendvb %ymm7,%ymm10,%ymm12,%ymm7
    4ee9:	c4 62 35 39 d4       	vpminsd %ymm4,%ymm9,%ymm10
    4eee:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    4ef2:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm2,-0x1(%rip),%ymm7,%ymm7        # 4efb <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x75b>
    4ef9:	ff ff 20 
    4efc:	c5 35 66 cc          	vpcmpgtd %ymm4,%ymm9,%ymm9
    4f00:	c4 c1 45 fe fb       	vpaddd %ymm11,%ymm7,%ymm7
    4f05:	c4 e2 0d 90 14 ba    	vpgatherdd %ymm14,(%rdx,%ymm7,4),%ymm2
    4f0b:	c5 e5 66 fd          	vpcmpgtd %ymm5,%ymm3,%ymm7
    4f0f:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    4f13:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4f18:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4f1d:	c4 c3 1d 4c ff 70    	vpblendvb %ymm7,%ymm15,%ymm12,%ymm7
    4f23:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm7,%ymm7        # 4f2c <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x78c>
    4f2a:	ff ff 90 
    4f2d:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
    4f33:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
    4f37:	c5 7d 6f e6          	vmovdqa %ymm6,%ymm12
    4f3b:	c4 62 1d 90 0c ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm9
    4f41:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4f46:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    4f4c:	c5 dd fa e7          	vpsubd %ymm7,%ymm4,%ymm4
    4f50:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    4f55:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    4f59:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
    4f5d:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    4f62:	c5 fe 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm3
    4f69:	00 00 
    4f6b:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    4f70:	e9 42 fb ff ff       	jmp    4ab7 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x317>
    4f75:	0f 1f 00             	nopl   (%rax)
    4f78:	c5 fe 6f 9c 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm3
    4f7f:	00 00 
    4f81:	c4 c1 75 72 d1 08    	vpsrld $0x8,%ymm9,%ymm1
    4f87:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    4f8d:	48 83 c0 60          	add    $0x60,%rax
    4f91:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    4f96:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    4f9b:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
    4fa0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4fa5:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    4faa:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    4faf:	c5 85 fa c2          	vpsubd %ymm2,%ymm15,%ymm0
    4fb3:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    4fb7:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    4fbc:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    4fc1:	c5 f5 fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm1,%ymm1
    4fc8:	00 00 
    4fca:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4fcf:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4fd3:	c5 fe 6f 94 24 80 01 	vmovdqu 0x180(%rsp),%ymm2
    4fda:	00 00 
    4fdc:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    4fe0:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    4fe5:	c5 35 fa 8c 24 40 01 	vpsubd 0x140(%rsp),%ymm9,%ymm9
    4fec:	00 00 
    4fee:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
    4ff3:	c5 f5 fe 8c 24 20 01 	vpaddd 0x120(%rsp),%ymm1,%ymm1
    4ffa:	00 00 
    4ffc:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    5001:	c4 62 35 40 cf       	vpmulld %ymm7,%ymm9,%ymm9
    5006:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    500a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    500f:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    5013:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5017:	c5 35 fe 8c 24 60 01 	vpaddd 0x160(%rsp),%ymm9,%ymm9
    501e:	00 00 
    5020:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5025:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    502a:	c5 7d 6f da          	vmovdqa %ymm2,%ymm11
    502e:	49 39 c2             	cmp    %rax,%r10
    5031:	0f 85 ba fa ff ff    	jne    4af1 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x351>
    5037:	c5 fd 6f f8          	vmovdqa %ymm0,%ymm7
    503b:	c5 fe 6f 84 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm0
    5042:	00 00 
    5044:	c5 dd 72 f7 08       	vpslld $0x8,%ymm7,%ymm4
    5049:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    504e:	49 83 c0 18          	add    $0x18,%r8
    5052:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
    5056:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    505a:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    5061:	02 00 00 
    5064:	c5 f9 6f e0          	vmovdqa %xmm0,%xmm4
    5068:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    506e:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
    5073:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    5078:	c5 e9 eb d4          	vpor   %xmm4,%xmm2,%xmm2
    507c:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    5082:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
    5088:	4d 39 c1             	cmp    %r8,%r9
    508b:	0f 85 e7 f7 ff ff    	jne    4878 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
    5091:	c5 f8 77             	vzeroupper
    5094:	c5 f8 28 b4 24 20 02 	vmovaps 0x220(%rsp),%xmm6
    509b:	00 00 
    509d:	c5 f8 28 bc 24 30 02 	vmovaps 0x230(%rsp),%xmm7
    50a4:	00 00 
    50a6:	c5 78 28 84 24 40 02 	vmovaps 0x240(%rsp),%xmm8
    50ad:	00 00 
    50af:	c5 78 28 8c 24 50 02 	vmovaps 0x250(%rsp),%xmm9
    50b6:	00 00 
    50b8:	c5 78 28 94 24 60 02 	vmovaps 0x260(%rsp),%xmm10
    50bf:	00 00 
    50c1:	c5 78 28 9c 24 70 02 	vmovaps 0x270(%rsp),%xmm11
    50c8:	00 00 
    50ca:	c5 78 28 a4 24 80 02 	vmovaps 0x280(%rsp),%xmm12
    50d1:	00 00 
    50d3:	c5 78 28 ac 24 90 02 	vmovaps 0x290(%rsp),%xmm13
    50da:	00 00 
    50dc:	c5 78 28 b4 24 a0 02 	vmovaps 0x2a0(%rsp),%xmm14
    50e3:	00 00 
    50e5:	c5 78 28 bc 24 b0 02 	vmovaps 0x2b0(%rsp),%xmm15
    50ec:	00 00 
    50ee:	48 81 c4 c0 02 00 00 	add    $0x2c0,%rsp
    50f5:	5b                   	pop    %rbx
    50f6:	5e                   	pop    %rsi
    50f7:	5f                   	pop    %rdi
    50f8:	c3                   	ret
    50f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5100:	c5 fd 6f fc          	vmovdqa %ymm4,%ymm7
    5104:	e9 3b ff ff ff       	jmp    5044 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8a4>
    5109:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    510d:	0f 85 fe f6 ff ff    	jne    4811 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    5113:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    511a:	0f 84 f1 f6 ff ff    	je     4811 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    5120:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    5127:	0f 84 e4 f6 ff ff    	je     4811 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    512d:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    5134:	0f 84 d7 f6 ff ff    	je     4811 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
    513a:	80 79 59 00          	cmpb   $0x0,0x59(%rcx)
    513e:	0f 85 ff 0b 00 00    	jne    5d43 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15a3>
    5144:	4d 85 c9             	test   %r9,%r9
    5147:	0f 84 47 ff ff ff    	je     5094 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    514d:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 51b5 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa15>
    5154:	00 
    5155:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    5159:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    515e:	48 c1 e8 03          	shr    $0x3,%rax
    5162:	c4 c1 15 72 d7 18    	vpsrld $0x18,%ymm15,%ymm13
    5168:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    516c:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    5173:	00 00 
    5175:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 51fd <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa5d>
    517c:	00 
    517d:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    5182:	b8 00 80 00 00       	mov    $0x8000,%eax
    5187:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    518e:	00 00 
    5190:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    5194:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5199:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    519e:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    51a3:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    51a9:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    51ad:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    51b2:	48 8b 01             	mov    (%rcx),%rax
    51b5:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    51b9:	49 83 c0 18          	add    $0x18,%r8
    51bd:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    51c3:	8b 51 50             	mov    0x50(%rcx),%edx
    51c6:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    51cc:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    51d1:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    51d8:	01 00 00 
    51db:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    51df:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    51e4:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    51e9:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    51ee:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    51f3:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    51f9:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
    51fe:	c4 c1 35 db e5       	vpand  %ymm13,%ymm9,%ymm4
    5203:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5208:	c4 e2 65 90 04 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm0
    520e:	48 8b 41 08          	mov    0x8(%rcx),%rax
    5212:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    5218:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    521c:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
    5222:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5226:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    522a:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    522f:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5257 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xab7>
    5236:	00 
    5237:	c4 a2 65 90 24 98    	vpgatherdd %ymm3,(%rax,%ymm11,4),%ymm4
    523d:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    5242:	48 8b 41 48          	mov    0x48(%rcx),%rax
    5246:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 526e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xace>
    524d:	00 
    524e:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    5253:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5258:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    525d:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 5285 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xae5>
    5264:	00 
    5265:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    526a:	c4 62 3d 3d f4       	vpmaxsd %ymm4,%ymm8,%ymm14
    526f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5273:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5277:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    527b:	c4 62 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm12
    5281:	c5 f9 6e da          	vmovd  %edx,%xmm3
    5285:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    528a:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    528e:	c4 e2 2d 90 2c 98    	vpgatherdd %ymm10,(%rax,%ymm3,4),%ymm5
    5294:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    5299:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    52a0:	00 00 
    52a2:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    52a7:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    52ae:	00 00 
    52b0:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    52b4:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    52b9:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    52bd:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    52c3:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm5,%ymm5        # 52cc <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb2c>
    52ca:	ff ff a0 
    52cd:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    52d2:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    52d6:	c4 62 2d 90 34 a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm14
    52dc:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    52e0:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    52e4:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    52ea:	c4 e3 55 4c 2d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm5,%ymm5        # 52f3 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb53>
    52f1:	ff ff 80 
    52f4:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    52f9:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    52fd:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    5303:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    5309:	c4 c1 0d db ed       	vpand  %ymm13,%ymm14,%ymm5
    530e:	c5 35 fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm14
    5315:	00 00 
    5317:	c4 41 2d db d5       	vpand  %ymm13,%ymm10,%ymm10
    531c:	c5 15 db 64 24 60    	vpand  0x60(%rsp),%ymm13,%ymm12
    5322:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    5326:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    532b:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5331:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    5335:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    5339:	c4 c1 3d 72 f4 10    	vpslld $0x10,%ymm12,%ymm8
    533f:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    5344:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    5349:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    534e:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    5355:	00 00 00 
    5358:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    535d:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    5361:	c5 95 db a4 24 80 00 	vpand  0x80(%rsp),%ymm13,%ymm4
    5368:	00 00 
    536a:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    536f:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    5374:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    5379:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    537d:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    5381:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    5387:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    538c:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    5393:	00 00 
    5395:	c4 a2 3d 90 2c 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm5
    539b:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    539f:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 53c7 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc27>
    53a6:	00 
    53a7:	c4 62 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm8
    53ad:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    53b1:	c4 41 7d 6f cf       	vmovdqa %ymm15,%ymm9
    53b6:	c5 3d db 05 20 00 00 	vpand  0x20(%rip),%ymm8,%ymm8        # 53de <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc3e>
    53bd:	00 
    53be:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    53c4:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 53ec <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc4c>
    53cb:	00 
    53cc:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    53d1:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    53d5:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    53d9:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    53de:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    53e3:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    53e9:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm10,-0x1(%rip),%ymm4,%ymm4        # 53f2 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc52>
    53f0:	ff ff a0 
    53f3:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
    53f8:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    53ff:	00 00 
    5401:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    5405:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    5409:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    540e:	c4 62 2d 90 24 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm12
    5414:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    5419:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    541e:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    5423:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5428:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    542e:	c4 e3 5d 4c 25 ff ff 	vpblendvb %ymm6,-0x1(%rip),%ymm4,%ymm4        # 5437 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc97>
    5435:	ff ff 60 
    5438:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    543c:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    5442:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    5448:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    544f:	00 00 
    5451:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    5456:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    545b:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    5461:	c4 41 5d db f5       	vpand  %ymm13,%ymm4,%ymm14
    5466:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    546c:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    5473:	00 00 
    5475:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    547c:	00 00 
    547e:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    5483:	c4 41 4d db d5       	vpand  %ymm13,%ymm6,%ymm10
    5488:	c4 41 1d fe e1       	vpaddd %ymm9,%ymm12,%ymm12
    548d:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    5493:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    5498:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    549c:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    54a0:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    54a5:	c4 c1 5d fa e6       	vpsubd %ymm14,%ymm4,%ymm4
    54aa:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    54af:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    54b4:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    54b8:	c5 95 db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm13,%ymm0
    54bf:	00 00 
    54c1:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    54c5:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    54cb:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    54d0:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    54d7:	00 00 00 
    54da:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    54de:	c5 fe 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm4
    54e4:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    54e8:	c4 a2 3d 90 04 9a    	vpgatherdd %ymm8,(%rdx,%ymm11,4),%ymm0
    54ee:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    54f2:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    54f7:	c5 9d 72 d5 10       	vpsrld $0x10,%ymm5,%ymm12
    54fc:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 5524 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd84>
    5503:	00 
    5504:	c4 41 7d 6f df       	vmovdqa %ymm15,%ymm11
    5509:	c4 e2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm4,4),%ymm5
    550f:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    5513:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5518:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5540 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xda0>
    551f:	00 
    5520:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    5526:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 554e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdae>
    552d:	00 
    552e:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5533:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    5537:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    553c:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    5541:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    5547:	c4 e3 4d 4c 35 ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm6,%ymm6        # 5550 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdb0>
    554e:	ff ff 90 
    5551:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    5556:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    555a:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    555f:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    5563:	c4 e2 25 90 14 b0    	vpgatherdd %ymm11,(%rax,%ymm6,4),%ymm2
    5569:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    556d:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    5571:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    5577:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    557b:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm9,-0x1(%rip),%ymm1,%ymm1        # 5584 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xde4>
    5582:	ff ff 90 
    5585:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    558a:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    558e:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    5593:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    5598:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    559e:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    55a3:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
    55a9:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    55ad:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    55b2:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    55b9:	00 00 
    55bb:	48 8b 41 60          	mov    0x60(%rcx),%rax
    55bf:	c4 c1 45 db fd       	vpand  %ymm13,%ymm7,%ymm7
    55c4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    55c9:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    55cd:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    55d2:	c4 c1 65 db dd       	vpand  %ymm13,%ymm3,%ymm3
    55d7:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    55dc:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    55e1:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    55e5:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    55ea:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    55ef:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    55f3:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    55f7:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    55fc:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
    5603:	00 00 
    5605:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    5609:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    560d:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5612:	c4 e2 65 90 24 b0    	vpgatherdd %ymm3,(%rax,%ymm6,4),%ymm4
    5618:	48 8b 41 68          	mov    0x68(%rcx),%rax
    561c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5620:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5624:	c4 a2 4d 90 2c a0    	vpgatherdd %ymm6,(%rax,%ymm12,4),%ymm5
    562a:	48 8b 41 70          	mov    0x70(%rcx),%rax
    562e:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    5635:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    563b:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    5640:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    5644:	c5 79 6e ca          	vmovd  %edx,%xmm9
    5648:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    564d:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5651:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5656:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    565b:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    5662:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5667:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    566c:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5694 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xef4>
    5673:	00 
    5674:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    567a:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    567f:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    5686:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 56ae <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf0e>
    568d:	00 
    568e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5693:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    5698:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    569d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 56c5 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf25>
    56a4:	00 
    56a5:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    56aa:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    56af:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    56b3:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    56b8:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    56bc:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    56c0:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    56c4:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    56c8:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    56ce:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    56d2:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    56d7:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    56db:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    56e1:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    56e5:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    56eb:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    56ef:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    56f4:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    56f8:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    56fd:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    5701:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    5707:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5710 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf70>
    570e:	ff ff 70 
    5711:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5716:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    571a:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    571e:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5724:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5729:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    572e:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5734:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    573a:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    573f:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5744:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5749:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    574e:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5757 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb7>
    5755:	ff ff b0 
    5758:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    575c:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5761:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5766:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    576c:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    5771:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5775:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    577c:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    5781:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5786:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    578b:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    578f:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5794:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5799:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    579e:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    57a3:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    57a7:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    57ac:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    57b1:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    57b5:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    57ba:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    57bf:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    57c4:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    57c9:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    57ce:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    57d4:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    57d9:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    57de:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    57e2:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    57e7:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    57ec:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    57f1:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    57f6:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    57fb:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5800:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    5805:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    580a:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    580f:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    5814:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    5819:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    581e:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    5822:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5827:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    582c:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5831:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    5836:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    583b:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    5840:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    5844:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5848:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    584d:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    5851:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5856:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    585b:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    585f:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5864:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    5868:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    586c:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    5872:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    5879:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    587d:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5881:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5885:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5889:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    588f:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    5896:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    589b:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    58a0:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    58a6:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    58ac:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    58b1:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    58b8:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    58bd:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    58c2:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 58ea <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x114a>
    58c9:	00 
    58ca:	c5 79 6e ca          	vmovd  %edx,%xmm9
    58ce:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    58d3:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 58fb <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x115b>
    58da:	00 
    58db:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    58e2:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    58e7:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 590f <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x116f>
    58ee:	00 
    58ef:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    58f4:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    58f9:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    58fe:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5903:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5907:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    590b:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    590f:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5913:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5917:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    591d:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5921:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    5927:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    592c:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5930:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5936:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    593a:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    5940:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    5944:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5949:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    594d:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    5952:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    5956:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    595c:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5965 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11c5>
    5963:	ff ff 70 
    5966:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    596b:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    596f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5973:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5979:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    597e:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    5983:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5989:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    598f:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5994:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5999:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    599e:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    59a3:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 59ac <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120c>
    59aa:	ff ff b0 
    59ad:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    59b1:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    59b6:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    59bb:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    59c1:	c4 c1 7d db ed       	vpand  %ymm13,%ymm0,%ymm5
    59c6:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    59ca:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    59d1:	c4 c1 4d db d5       	vpand  %ymm13,%ymm6,%ymm2
    59d6:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    59db:	c4 41 1d db e5       	vpand  %ymm13,%ymm12,%ymm12
    59e0:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    59e4:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    59e9:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    59ee:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    59f3:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    59f8:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    59fc:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5a01:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    5a06:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    5a0a:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    5a0f:	c4 c1 5d db e5       	vpand  %ymm13,%ymm4,%ymm4
    5a14:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    5a19:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5a1e:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5a23:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5a29:	c4 c1 6d db d5       	vpand  %ymm13,%ymm2,%ymm2
    5a2e:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5a33:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    5a37:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
    5a3c:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5a41:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    5a46:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    5a4b:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5a50:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5a55:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    5a5a:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    5a5f:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    5a64:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    5a69:	c4 c1 5d fe e3       	vpaddd %ymm11,%ymm4,%ymm4
    5a6e:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5a73:	c5 79 6e ca          	vmovd  %edx,%xmm9
    5a77:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    5a7b:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5a80:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    5a85:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    5a8a:	c4 c1 65 db f5       	vpand  %ymm13,%ymm3,%ymm6
    5a8f:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5a94:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    5a99:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5a9e:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    5aa2:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5aa6:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5aab:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    5aaf:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5ab4:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5ab9:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5abd:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5ac2:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5ac7:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    5acb:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    5acf:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    5ad5:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    5adc:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5ae0:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5ae4:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5ae8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5aec:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5af2:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    5af9:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5afe:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    5b03:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 5b2b <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x138b>
    5b0a:	00 
    5b0b:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    5b11:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    5b16:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 5b3e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x139e>
    5b1d:	00 
    5b1e:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    5b23:	c4 c2 6d 40 d4       	vpmulld %ymm12,%ymm2,%ymm2
    5b28:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    5b2d:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 5b55 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13b5>
    5b34:	00 
    5b35:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    5b3c:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    5b41:	c4 62 5d 39 dd       	vpminsd %ymm5,%ymm4,%ymm11
    5b46:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    5b4a:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    5b4f:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    5b53:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    5b57:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    5b5b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    5b5f:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    5b65:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    5b69:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    5b6e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    5b72:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    5b78:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    5b7c:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    5b82:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    5b86:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    5b8b:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    5b8f:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    5b94:	c4 c3 35 4c dc 30    	vpblendvb %ymm3,%ymm12,%ymm9,%ymm3
    5b9a:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 5ba3 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1403>
    5ba1:	ff ff 70 
    5ba4:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    5ba9:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    5bad:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    5bb1:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    5bb7:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    5bbc:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    5bc1:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    5bc7:	c4 c3 35 4c d4 40    	vpblendvb %ymm4,%ymm12,%ymm9,%ymm2
    5bcd:	c4 c1 75 db e5       	vpand  %ymm13,%ymm1,%ymm4
    5bd2:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    5bd7:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    5bdc:	c5 9d 72 d3 08       	vpsrld $0x8,%ymm3,%ymm12
    5be1:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm11,-0x1(%rip),%ymm2,%ymm2        # 5bea <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x144a>
    5be8:	ff ff b0 
    5beb:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    5bef:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5bf3:	c4 41 65 db dd       	vpand  %ymm13,%ymm3,%ymm11
    5bf8:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    5bfe:	c4 c1 7d db f5       	vpand  %ymm13,%ymm0,%ymm6
    5c03:	c5 a5 fa e4          	vpsubd %ymm4,%ymm11,%ymm4
    5c07:	c4 c1 55 db d5       	vpand  %ymm13,%ymm5,%ymm2
    5c0c:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    5c11:	c4 41 35 fe ce       	vpaddd %ymm14,%ymm9,%ymm9
    5c16:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5c1a:	c4 c1 6d fa d3       	vpsubd %ymm11,%ymm2,%ymm2
    5c1f:	c4 41 15 db e4       	vpand  %ymm12,%ymm13,%ymm12
    5c24:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5c29:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5c2e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    5c33:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    5c38:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    5c3c:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    5c41:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    5c45:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    5c4a:	c4 41 35 db cd       	vpand  %ymm13,%ymm9,%ymm9
    5c4f:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    5c54:	c4 c1 25 72 f1 10    	vpslld $0x10,%ymm9,%ymm11
    5c5a:	c5 95 db f6          	vpand  %ymm6,%ymm13,%ymm6
    5c5e:	c5 95 db d2          	vpand  %ymm2,%ymm13,%ymm2
    5c62:	c4 41 1d fa c9       	vpsubd %ymm9,%ymm12,%ymm9
    5c67:	c4 41 25 fe de       	vpaddd %ymm14,%ymm11,%ymm11
    5c6c:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    5c71:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5c76:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    5c7a:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    5c7f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5c84:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    5c89:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    5c8e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    5c93:	c4 c1 7d db c5       	vpand  %ymm13,%ymm0,%ymm0
    5c98:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    5c9d:	c4 c1 6d fe d3       	vpaddd %ymm11,%ymm2,%ymm2
    5ca2:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    5ca6:	c4 c1 75 db f5       	vpand  %ymm13,%ymm1,%ymm6
    5cab:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    5cb0:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    5cb5:	c4 c1 65 db ed       	vpand  %ymm13,%ymm3,%ymm5
    5cba:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    5cbf:	c4 c1 75 db cd       	vpand  %ymm13,%ymm1,%ymm1
    5cc4:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    5cc8:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    5ccc:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    5cd0:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    5cd5:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    5cda:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    5cdf:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    5ce4:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    5ce9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    5ced:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    5cf1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    5cf5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    5cfa:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    5cff:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    5d03:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    5d07:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    5d0e:	02 00 00 
    5d11:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    5d15:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    5d1b:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    5d20:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    5d25:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    5d29:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    5d2f:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    5d35:	4d 39 c2             	cmp    %r8,%r10
    5d38:	0f 85 60 f4 ff ff    	jne    519e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x9fe>
    5d3e:	e9 4e f3 ff ff       	jmp    5091 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    5d43:	4d 85 c9             	test   %r9,%r9
    5d46:	0f 84 48 f3 ff ff    	je     5094 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f4>
    5d4c:	c5 fd 6f 35 60 00 00 	vmovdqa 0x60(%rip),%ymm6        # 5db4 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1614>
    5d53:	00 
    5d54:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    5d58:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    5d5d:	48 c1 e8 03          	shr    $0x3,%rax
    5d61:	c4 c1 35 72 d7 18    	vpsrld $0x18,%ymm15,%ymm9
    5d67:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5d6b:	c5 fe 7f b4 24 e0 01 	vmovdqu %ymm6,0x1e0(%rsp)
    5d72:	00 00 
    5d74:	c5 fd 6f 35 80 00 00 	vmovdqa 0x80(%rip),%ymm6        # 5dfc <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x165c>
    5d7b:	00 
    5d7c:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    5d81:	b8 00 80 00 00       	mov    $0x8000,%eax
    5d86:	c5 fe 7f b4 24 00 02 	vmovdqu %ymm6,0x200(%rsp)
    5d8d:	00 00 
    5d8f:	c5 f9 6e f0          	vmovd  %eax,%xmm6
    5d93:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5d98:	c5 fe 7f 34 24       	vmovdqu %ymm6,(%rsp)
    5d9d:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    5da2:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    5da8:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5dac:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5db1:	48 8b 01             	mov    (%rcx),%rax
    5db4:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    5db8:	49 83 c0 18          	add    $0x18,%r8
    5dbc:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    5dc2:	8b 51 50             	mov    0x50(%rcx),%edx
    5dc5:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    5dcb:	c4 41 79 6e d9       	vmovd  %r9d,%xmm11
    5dd0:	c4 e2 7d 00 84 24 e0 	vpshufb 0x1e0(%rsp),%ymm0,%ymm0
    5dd7:	01 00 00 
    5dda:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    5dde:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
    5de3:	c4 c1 7d db d9       	vpand  %ymm9,%ymm0,%ymm3
    5de8:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
    5ded:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    5df2:	c4 e2 4d 90 3c 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
    5df8:	48 8b 41 08          	mov    0x8(%rcx),%rax
    5dfc:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5e01:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5e05:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    5e0a:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    5e0f:	c4 a2 4d 90 14 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm2
    5e15:	48 8b 41 10          	mov    0x10(%rcx),%rax
    5e19:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5e1d:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
    5e22:	c5 ed db 15 20 00 00 	vpand  0x20(%rip),%ymm2,%ymm2        # 5e4a <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16aa>
    5e29:	00 
    5e2a:	c4 e2 4d 90 04 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm0
    5e30:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    5e35:	48 8b 41 48          	mov    0x48(%rcx),%rax
    5e39:	c5 c5 db 3d 20 00 00 	vpand  0x20(%rip),%ymm7,%ymm7        # 5e61 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16c1>
    5e40:	00 
    5e41:	c4 e2 4d 40 f4       	vpmulld %ymm4,%ymm6,%ymm6
    5e46:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    5e4b:	c5 ad 72 d0 11       	vpsrld $0x11,%ymm0,%ymm10
    5e50:	c5 fd db 05 20 00 00 	vpand  0x20(%rip),%ymm0,%ymm0        # 5e78 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x16d8>
    5e57:	00 
    5e58:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    5e5c:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5e60:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
    5e65:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    5e6a:	c4 62 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm12
    5e70:	c5 f9 6e f2          	vmovd  %edx,%xmm6
    5e74:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    5e78:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
    5e7d:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    5e83:	c5 cd fe f5          	vpaddd %ymm5,%ymm6,%ymm6
    5e87:	c4 62 15 90 24 b0    	vpgatherdd %ymm13,(%rax,%ymm6,4),%ymm12
    5e8d:	c4 41 7d 6f ef       	vmovdqa %ymm15,%ymm13
    5e92:	c5 7e 7f 64 24 60    	vmovdqu %ymm12,0x60(%rsp)
    5e98:	c4 62 15 90 34 9a    	vpgatherdd %ymm13,(%rdx,%ymm3,4),%ymm14
    5e9e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    5ea2:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5ea6:	c4 22 65 90 2c 82    	vpgatherdd %ymm3,(%rdx,%ymm8,4),%ymm13
    5eac:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    5eb0:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
    5eb7:	00 00 
    5eb9:	c4 e2 2d 90 1c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm3
    5ebf:	c5 ed 66 cf          	vpcmpgtd %ymm7,%ymm2,%ymm1
    5ec3:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
    5eca:	00 00 
    5ecc:	c4 e2 45 3d da       	vpmaxsd %ymm2,%ymm7,%ymm3
    5ed1:	c5 7d 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm8
    5ed5:	c4 62 65 3d e8       	vpmaxsd %ymm0,%ymm3,%ymm13
    5eda:	c4 e2 45 39 da       	vpminsd %ymm2,%ymm7,%ymm3
    5edf:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5ee5:	c4 62 65 39 d0       	vpminsd %ymm0,%ymm3,%ymm10
    5eea:	c5 e5 66 d8          	vpcmpgtd %ymm0,%ymm3,%ymm3
    5eee:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm8,-0x1(%rip),%ymm1,%ymm1        # 5ef7 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1757>
    5ef5:	ff ff 80 
    5ef8:	c4 41 7d 6f c7       	vmovdqa %ymm15,%ymm8
    5efd:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
    5f01:	c4 62 3d 90 24 88    	vpgatherdd %ymm8,(%rax,%ymm1,4),%ymm12
    5f07:	c5 c5 66 ca          	vpcmpgtd %ymm2,%ymm7,%ymm1
    5f0b:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    5f11:	c4 c3 5d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm4,%ymm1
    5f17:	c4 e3 75 4c 0d ff ff 	vpblendvb %ymm3,-0x1(%rip),%ymm1,%ymm1        # 5f20 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1780>
    5f1e:	ff ff 30 
    5f21:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    5f25:	c5 cd fa c9          	vpsubd %ymm1,%ymm6,%ymm1
    5f29:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
    5f2d:	c4 62 65 90 04 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm8
    5f33:	c5 b5 db 4c 24 20    	vpand  0x20(%rsp),%ymm9,%ymm1
    5f39:	c4 c1 1d db d9       	vpand  %ymm9,%ymm12,%ymm3
    5f3e:	c4 41 2d fe e5       	vpaddd %ymm13,%ymm10,%ymm12
    5f43:	c4 41 3d db c1       	vpand  %ymm9,%ymm8,%ymm8
    5f48:	c5 45 fe ea          	vpaddd %ymm2,%ymm7,%ymm13
    5f4c:	c4 41 7d fa e4       	vpsubd %ymm12,%ymm0,%ymm12
    5f51:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
    5f58:	00 00 
    5f5a:	c4 41 1d fe ed       	vpaddd %ymm13,%ymm12,%ymm13
    5f5f:	c5 3d fa e3          	vpsubd %ymm3,%ymm8,%ymm12
    5f63:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    5f6a:	00 00 
    5f6c:	c4 42 15 40 e4       	vpmulld %ymm12,%ymm13,%ymm12
    5f71:	c5 e5 fa 9c 24 80 00 	vpsubd 0x80(%rsp),%ymm3,%ymm3
    5f78:	00 00 
    5f7a:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    5f81:	00 00 
    5f83:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    5f88:	c5 f5 fe 0c 24       	vpaddd (%rsp),%ymm1,%ymm1
    5f8d:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    5f92:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    5f96:	c5 9d fe c9          	vpaddd %ymm1,%ymm12,%ymm1
    5f9a:	c5 35 db 64 24 60    	vpand  0x60(%rsp),%ymm9,%ymm12
    5fa0:	c4 41 1d fa c0       	vpsubd %ymm8,%ymm12,%ymm8
    5fa5:	c4 c1 1d 72 e5 10    	vpsrad $0x10,%ymm13,%ymm12
    5fab:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
    5fb0:	c5 1d fe e2          	vpaddd %ymm2,%ymm12,%ymm12
    5fb4:	c5 3d fe c3          	vpaddd %ymm3,%ymm8,%ymm8
    5fb8:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
    5fbf:	00 00 
    5fc1:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    5fc6:	c4 c1 3d 72 e6 10    	vpsrad $0x10,%ymm14,%ymm8
    5fcc:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    5fd1:	c5 3d fe c7          	vpaddd %ymm7,%ymm8,%ymm8
    5fd5:	c5 fe 7f 8c 24 00 01 	vmovdqu %ymm1,0x100(%rsp)
    5fdc:	00 00 
    5fde:	c5 f5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm1
    5fe3:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
    5fe8:	c4 41 3d fe d4       	vpaddd %ymm12,%ymm8,%ymm10
    5fed:	c5 e5 72 e3 10       	vpsrad $0x10,%ymm3,%ymm3
    5ff2:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    5ff6:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    5ffd:	00 00 
    5fff:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    6003:	c4 c1 7d 72 f5 10    	vpslld $0x10,%ymm13,%ymm0
    6009:	c5 fd 72 e0 10       	vpsrad $0x10,%ymm0,%ymm0
    600e:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6012:	c5 e5 fe d0          	vpaddd %ymm0,%ymm3,%ymm2
    6016:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
    601d:	00 00 
    601f:	c4 c1 6d 72 f6 10    	vpslld $0x10,%ymm14,%ymm2
    6025:	c5 ed 72 e2 10       	vpsrad $0x10,%ymm2,%ymm2
    602a:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    602e:	c4 62 6d 3d e8       	vpmaxsd %ymm0,%ymm2,%ymm13
    6033:	c5 fd 66 fa          	vpcmpgtd %ymm2,%ymm0,%ymm7
    6037:	c4 41 65 66 f5       	vpcmpgtd %ymm13,%ymm3,%ymm14
    603c:	c4 62 15 3d d3       	vpmaxsd %ymm3,%ymm13,%ymm10
    6041:	c4 62 6d 39 e8       	vpminsd %ymm0,%ymm2,%ymm13
    6046:	c5 ed 66 c0          	vpcmpgtd %ymm0,%ymm2,%ymm0
    604a:	c4 c3 5d 4c fb 70    	vpblendvb %ymm7,%ymm11,%ymm4,%ymm7
    6050:	c4 e3 45 4c 3d ff ff 	vpblendvb %ymm14,-0x1(%rip),%ymm7,%ymm7        # 6059 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18b9>
    6057:	ff ff e0 
    605a:	c4 62 15 39 f3       	vpminsd %ymm3,%ymm13,%ymm14
    605f:	c5 15 66 eb          	vpcmpgtd %ymm3,%ymm13,%ymm13
    6063:	c5 7e 7f b4 24 80 00 	vmovdqu %ymm14,0x80(%rsp)
    606a:	00 00 
    606c:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    6070:	c4 c3 5d 4c c3 00    	vpblendvb %ymm0,%ymm11,%ymm4,%ymm0
    6076:	c4 62 4d 90 34 b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm14
    607c:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6082:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    6086:	c4 e3 7d 4c 05 ff ff 	vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0        # 608f <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x18ef>
    608d:	ff ff d0 
    6090:	c5 cd fa d8          	vpsubd %ymm0,%ymm6,%ymm3
    6094:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6098:	c4 e2 4d 90 04 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm0
    609e:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    60a4:	c5 fd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm0
    60a9:	c4 41 7d db e9       	vpand  %ymm9,%ymm0,%ymm13
    60ae:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
    60b5:	00 00 
    60b7:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    60bc:	c4 41 65 db f1       	vpand  %ymm9,%ymm3,%ymm14
    60c1:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
    60c6:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    60cc:	c4 c1 7d fe c2       	vpaddd %ymm10,%ymm0,%ymm0
    60d1:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    60d6:	c5 ed fa c0          	vpsubd %ymm0,%ymm2,%ymm0
    60da:	c5 95 fa d3          	vpsubd %ymm3,%ymm13,%ymm2
    60de:	c5 cd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm6
    60e3:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
    60ea:	00 00 
    60ec:	c4 c1 65 fa de       	vpsubd %ymm14,%ymm3,%ymm3
    60f1:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
    60f7:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    60fe:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    6103:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    6109:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    610e:	c5 c5 fe 14 24       	vpaddd (%rsp),%ymm7,%ymm2
    6113:	c4 c2 3d 39 fc       	vpminsd %ymm12,%ymm8,%ymm7
    6118:	c5 79 6e d2          	vmovd  %edx,%xmm10
    611c:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6121:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    6126:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
    612a:	c5 b5 db c6          	vpand  %ymm6,%ymm9,%ymm0
    612e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6132:	c4 c1 7d fa c5       	vpsubd %ymm13,%ymm0,%ymm0
    6137:	c4 62 45 39 e9       	vpminsd %ymm1,%ymm7,%ymm13
    613c:	c5 c5 66 f9          	vpcmpgtd %ymm1,%ymm7,%ymm7
    6140:	c4 e2 7d 40 84 24 80 	vpmulld 0x80(%rsp),%ymm0,%ymm0
    6147:	00 00 00 
    614a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    614e:	c4 c2 3d 3d dc       	vpmaxsd %ymm12,%ymm8,%ymm3
    6153:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    6157:	c5 f5 66 c3          	vpcmpgtd %ymm3,%ymm1,%ymm0
    615b:	c4 e2 65 3d d9       	vpmaxsd %ymm1,%ymm3,%ymm3
    6160:	c5 8d 72 d2 10       	vpsrld $0x10,%ymm2,%ymm14
    6165:	c4 c1 1d 66 d0       	vpcmpgtd %ymm8,%ymm12,%ymm2
    616a:	c4 41 3d 66 c4       	vpcmpgtd %ymm12,%ymm8,%ymm8
    616f:	c4 c3 5d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm4,%ymm2
    6175:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm0,-0x1(%rip),%ymm2,%ymm2        # 617e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19de>
    617c:	ff ff 00 
    617f:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    6183:	c4 e2 4d 90 04 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm0
    6189:	c4 c3 5d 4c d3 80    	vpblendvb %ymm8,%ymm11,%ymm4,%ymm2
    618f:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    6195:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm2,%ymm2        # 619e <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x19fe>
    619c:	ff ff 70 
    619f:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    61a4:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    61aa:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    61ae:	c5 7d 7f fa          	vmovdqa %ymm15,%ymm2
    61b2:	c4 e2 6d 90 2c b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm5
    61b8:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    61bd:	c4 c1 65 fe c5       	vpaddd %ymm13,%ymm3,%ymm0
    61c2:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    61c8:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    61cc:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    61d1:	48 8b 41 60          	mov    0x60(%rcx),%rax
    61d5:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    61da:	c5 dd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm4
    61df:	c5 fd fe 84 24 e0 00 	vpaddd 0xe0(%rsp),%ymm0,%ymm0
    61e6:	00 00 
    61e8:	c5 d5 fa ca          	vpsubd %ymm2,%ymm5,%ymm1
    61ec:	c5 cd 72 d7 10       	vpsrld $0x10,%ymm7,%ymm6
    61f1:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    61f6:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    61fb:	c5 c5 72 f4 10       	vpslld $0x10,%ymm4,%ymm7
    6200:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    6204:	c5 c5 fe 0c 24       	vpaddd (%rsp),%ymm7,%ymm1
    6209:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    620e:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    6212:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    6216:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    621a:	c4 c1 4d db c9       	vpand  %ymm9,%ymm6,%ymm1
    621f:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6223:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    6227:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    622c:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6231:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    6236:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    623a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    623e:	c5 fe 6f 8c 24 00 01 	vmovdqu 0x100(%rsp),%ymm1
    6245:	00 00 
    6247:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    624c:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    6252:	48 8b 41 68          	mov    0x68(%rcx),%rax
    6256:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    625a:	c4 a2 4d 90 2c b0    	vpgatherdd %ymm6,(%rax,%ymm14,4),%ymm5
    6260:	48 8b 41 70          	mov    0x70(%rcx),%rax
    6264:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6269:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 6291 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1af1>
    6270:	00 
    6271:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6277:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    627c:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    6283:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 62ab <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b0b>
    628a:	00 
    628b:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    6290:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6295:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    629a:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 62c2 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b22>
    62a1:	00 
    62a2:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    62a7:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    62ac:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    62b0:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    62b5:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    62b9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    62bd:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    62c1:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    62c5:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    62cb:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    62cf:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    62d4:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    62d8:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    62dc:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    62e2:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    62e9:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    62ef:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    62f5:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    62f9:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    62fe:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6302:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6307:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    630b:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    6311:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 631a <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1b7a>
    6318:	ff ff 70 
    631b:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    6320:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    6324:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    6328:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    632e:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    6333:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6338:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    633e:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6344:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6349:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    634e:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    6353:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    6358:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6361 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1bc1>
    635f:	ff ff c0 
    6362:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    6366:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    636b:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6370:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    6376:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    637b:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    637f:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    6386:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    638b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6390:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    6395:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    6399:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    639e:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    63a3:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    63a8:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    63ad:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    63b1:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    63b6:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    63bb:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    63bf:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    63c4:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    63c9:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    63ce:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    63d3:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    63d8:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    63de:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    63e3:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    63e8:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    63ec:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    63f1:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    63f6:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    63fb:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    6400:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6405:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    640a:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    640f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6414:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    6419:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    641e:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    6423:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6428:	c5 79 6e d2          	vmovd  %edx,%xmm10
    642c:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    6430:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    6435:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    643a:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    643f:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    6444:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    6449:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    644e:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    6453:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    6457:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    645b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6460:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    6464:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    6469:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    646e:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6472:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    6477:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    647c:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    6480:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    6484:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    648a:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    6491:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    6495:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    6499:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    649d:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    64a1:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    64a7:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    64ae:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    64b3:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    64b8:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 64e0 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d40>
    64bf:	00 
    64c0:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    64c6:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    64cb:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    64d2:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 64fa <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d5a>
    64d9:	00 
    64da:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    64df:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    64e4:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    64e9:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6511 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d71>
    64f0:	00 
    64f1:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    64f6:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    64fb:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    64ff:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    6504:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    6508:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    650c:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    6510:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6514:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    651a:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    651e:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6523:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6527:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    652d:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    6531:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6537:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    653b:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    6540:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6544:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6549:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
    654d:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    6553:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 655c <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1dbc>
    655a:	ff ff 70 
    655d:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    6562:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    6566:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    656a:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    656f:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    6574:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    657a:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    6580:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    6586:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    658b:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 6594 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1df4>
    6592:	ff ff c0 
    6595:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    659a:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    659f:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    65a6:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    65ab:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    65af:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    65b3:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    65b9:	c4 e2 55 90 34 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm6
    65bf:	c4 c1 7d db e9       	vpand  %ymm9,%ymm0,%ymm5
    65c4:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    65c9:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    65d0:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    65d5:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    65da:	c4 c1 4d db d1       	vpand  %ymm9,%ymm6,%ymm2
    65df:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    65e3:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    65e8:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    65ed:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    65f2:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    65f7:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    65fc:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6601:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    6605:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    660a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    660e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    6613:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6618:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    661d:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    6623:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    6628:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    662d:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    6632:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6637:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    663c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    6641:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    6645:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    664a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    664f:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    6654:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    6659:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    665e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    6663:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    6668:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    666d:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    6672:	c5 79 6e d2          	vmovd  %edx,%xmm10
    6676:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    667b:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    6680:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    6685:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    6689:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    668e:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    6693:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    6698:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    669d:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    66a2:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    66a7:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    66ab:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    66af:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    66b4:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    66b8:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    66bd:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    66c2:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    66c6:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    66cb:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    66cf:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    66d3:	c4 e2 4d 90 24 a8    	vpgatherdd %ymm6,(%rax,%ymm5,4),%ymm4
    66d9:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    66e0:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    66e4:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    66e8:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    66ec:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    66f0:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    66f6:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    66fd:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6702:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    6707:	c5 d5 db 2d 20 00 00 	vpand  0x20(%rip),%ymm5,%ymm5        # 672f <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1f8f>
    670e:	00 
    670f:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    6715:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    671a:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    6721:	c5 dd db 25 20 00 00 	vpand  0x20(%rip),%ymm4,%ymm4        # 6749 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fa9>
    6728:	00 
    6729:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    672e:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    6733:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    6738:	c5 cd db 35 20 00 00 	vpand  0x20(%rip),%ymm6,%ymm6        # 6760 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fc0>
    673f:	00 
    6740:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    6745:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    674a:	c5 5d fe f5          	vpaddd %ymm5,%ymm4,%ymm14
    674e:	c4 62 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm11
    6753:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    6757:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    675b:	c5 7d 7f f8          	vmovdqa %ymm15,%ymm0
    675f:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    6763:	c4 e2 7d 90 0c 90    	vpgatherdd %ymm0,(%rax,%ymm2,4),%ymm1
    6769:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    676d:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    6772:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    6776:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    677c:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
    6780:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    6786:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    678a:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    678f:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    6793:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    6798:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
    679e:	c4 e3 65 4c 1d ff ff 	vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3        # 67a7 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2007>
    67a5:	ff ff 70 
    67a8:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
    67ad:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    67b1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    67b5:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    67bb:	c4 c1 45 fe fe       	vpaddd %ymm14,%ymm7,%ymm7
    67c0:	c4 41 7d 6f f7       	vmovdqa %ymm15,%ymm14
    67c5:	c4 e2 0d 90 1c 90    	vpgatherdd %ymm14,(%rax,%ymm2,4),%ymm3
    67cb:	c4 c3 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm2
    67d1:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
    67d6:	c5 ad 72 f4 10       	vpslld $0x10,%ymm4,%ymm10
    67db:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    67e0:	c4 e3 6d 4c 15 ff ff 	vpblendvb %ymm12,-0x1(%rip),%ymm2,%ymm2        # 67e9 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2049>
    67e7:	ff ff c0 
    67ea:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    67ee:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
    67f2:	c4 41 65 db e1       	vpand  %ymm9,%ymm3,%ymm12
    67f7:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    67fd:	c4 c1 7d db f1       	vpand  %ymm9,%ymm0,%ymm6
    6802:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    6806:	c5 7e 6f 34 24       	vmovdqu (%rsp),%ymm14
    680b:	c4 c1 55 db d1       	vpand  %ymm9,%ymm5,%ymm2
    6810:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    6815:	c4 41 15 db e9       	vpand  %ymm9,%ymm13,%ymm13
    681a:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    681e:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    6823:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    6828:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    682d:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6832:	c4 41 2d fe d6       	vpaddd %ymm14,%ymm10,%ymm10
    6837:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
    683c:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    6840:	c5 ad 72 d1 08       	vpsrld $0x8,%ymm1,%ymm10
    6845:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    6849:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    684e:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    6853:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    6858:	c4 c1 1d 72 f2 10    	vpslld $0x10,%ymm10,%ymm12
    685e:	c5 b5 db f6          	vpand  %ymm6,%ymm9,%ymm6
    6862:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    6867:	c4 41 15 fa d2       	vpsubd %ymm10,%ymm13,%ymm10
    686c:	c4 41 1d fe e6       	vpaddd %ymm14,%ymm12,%ymm12
    6871:	c4 42 2d 40 d0       	vpmulld %ymm8,%ymm10,%ymm10
    6876:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    687b:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    687f:	c4 c2 4d 40 f3       	vpmulld %ymm11,%ymm6,%ymm6
    6884:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    6889:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    688e:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    6893:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    6898:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    689d:	c4 c1 4d fe f2       	vpaddd %ymm10,%ymm6,%ymm6
    68a2:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    68a7:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    68ab:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
    68b0:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    68b5:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    68ba:	c4 c1 65 db e9       	vpand  %ymm9,%ymm3,%ymm5
    68bf:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    68c4:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    68c9:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    68cd:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    68d1:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    68d5:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    68da:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
    68df:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    68e4:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    68e9:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    68ee:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    68f2:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    68f6:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    68fa:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    68ff:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    6904:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    6908:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    690c:	c4 e2 7d 00 84 24 00 	vpshufb 0x200(%rsp),%ymm0,%ymm0
    6913:	02 00 00 
    6916:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    691a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    6920:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    6925:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    692a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    692e:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    6934:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    693a:	4d 39 c2             	cmp    %r8,%r10
    693d:	0f 85 5a f4 ff ff    	jne    5d9d <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x15fd>
    6943:	e9 49 e7 ff ff       	jmp    5091 <jshc_packed_store::avx2_chain(jshc_packed_store::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8f1>
    6948:	90                   	nop
    6949:	90                   	nop
    694a:	90                   	nop
    694b:	90                   	nop
    694c:	90                   	nop
    694d:	90                   	nop
    694e:	90                   	nop
    694f:	90                   	nop
