.text
.Lloop:
.Li0:
mov 0x24(%rbx),%eax
.Li1:
mov 0x20(%rbx),%edx
.Li2:
vpsubd %ymm14,%ymm1,%ymm1
.Li3:
vpsubd %ymm11,%ymm4,%ymm4
.Li4:
vmovdqa %ymm12,%ymm5
.Li5:
imul %eax,%edx
.Li6:
vmovd %eax,%xmm0
.Li7:
mov (%rbx),%rax
.Li8:
vpbroadcastd %xmm0,%ymm0
.Li9:
vpmulld %ymm0,%ymm1,%ymm1
.Li10:
vpsubd %ymm13,%ymm7,%ymm0
.Li11:
vmovd %edx,%xmm2
.Li12:
vpbroadcastd %xmm2,%ymm2
.Li13:
vpmulld %ymm2,%ymm0,%ymm0
.Li14:
vpaddd %ymm0,%ymm1,%ymm1
.Li15:
vpaddd %ymm4,%ymm1,%ymm1
.Li16:
vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm0
.Li17:
vpsrld $0x8,%ymm0,%ymm1
.Li18:
vpand %ymm15,%ymm0,%ymm3
.Li19:
vpand %ymm15,%ymm1,%ymm1
.Li20:
vpsrld $0x10,%ymm0,%ymm0
.Li21:
vpslld $0x10,%ymm0,%ymm2
.Li22:
vpslld $0x8,%ymm1,%ymm0
.Li23:
add $0x18,%r11
.Li24:
vpor %ymm2,%ymm0,%ymm0
.Li25:
vpor %ymm3,%ymm0,%ymm0
.Li26:
vpshufb 0x100(%rsp),%ymm0,%ymm0
.Li27:
vmovdqa %xmm0,%xmm2
.Li28:
vextracti128 $0x1,%ymm0,%xmm0
.Li29:
vpslldq $0xc,%xmm0,%xmm1
.Li30:
vpsrldq $0x4,%xmm0,%xmm0
.Li31:
vpor %xmm2,%xmm1,%xmm1
.Li32:
vmovq %xmm0,-0x8(%r11)
.Li33:
vmovdqu %xmm1,-0x18(%r11)
.Li34:
cmp %rbp,%rdi
.Li35:
je .Loutside
.Li36:
inc %rbp
.Li37:
vmovdqu (%r11),%xmm3
.Li38:
vmovq 0x10(%r11),%xmm0
.Li39:
vmovdqa %ymm12,%ymm7
.Li40:
vmovdqa %ymm12,%ymm11
.Li41:
mov (%r10),%rax
.Li42:
mov 0x54(%r10),%ecx
.Li43:
vmovdqa %ymm12,%ymm13
.Li44:
vpalignr $0xc,%xmm3,%xmm0,%xmm0
.Li45:
mov 0x50(%r10),%edx
.Li46:
vinserti128 $0x1,%xmm0,%ymm3,%ymm3
.Li47:
vmovd %ecx,%xmm14
.Li48:
vpshufb 0xe0(%rsp),%ymm3,%ymm3
.Li49:
vmovd %edx,%xmm2
.Li50:
vpbroadcastd %xmm14,%ymm14
.Li51:
vpsrld $0x10,%ymm3,%ymm4
.Li52:
vpsrld $0x8,%ymm3,%ymm6
.Li53:
vpand %ymm15,%ymm3,%ymm3
.Li54:
vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm5
.Li55:
mov 0x8(%r10),%rax
.Li56:
vpand %ymm15,%ymm6,%ymm6
.Li57:
vmovdqa %ymm12,%ymm7
.Li58:
vpbroadcastd %xmm2,%ymm2
.Li59:
vpsrld $0x11,%ymm5,%ymm8
.Li60:
lea 0x1(%rcx,%rdx,1),%edx
.Li61:
vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm1
.Li62:
mov 0x10(%r10),%rax
.Li63:
vmovdqa %ymm12,%ymm7
.Li64:
vpand 0x20(%rip),%ymm5,%ymm5
.Li65:
vpmulld %ymm2,%ymm8,%ymm8
.Li66:
vpgatherdd %ymm7,(%rax,%ymm4,4),%ymm0
.Li67:
vpsrld $0x11,%ymm1,%ymm7
.Li68:
mov 0x48(%r10),%rax
.Li69:
vpand 0x20(%rip),%ymm1,%ymm1
.Li70:
vpmulld %ymm14,%ymm7,%ymm7
.Li71:
vpsrld $0x11,%ymm0,%ymm9
.Li72:
vpand 0x20(%rip),%ymm0,%ymm0
.Li73:
vpaddd %ymm8,%ymm7,%ymm7
.Li74:
vmovdqa %ymm12,%ymm8
.Li75:
vpaddd %ymm9,%ymm7,%ymm10
.Li76:
vpgatherdd %ymm11,(%rax,%ymm10,4),%ymm7
.Li77:
vmovdqu %ymm7,0x160(%rsp)
.Li78:
vmovd %edx,%xmm7
.Li79:
mov 0x18(%r10),%rdx
.Li80:
vpbroadcastd %xmm7,%ymm7
.Li81:
vpaddd %ymm10,%ymm7,%ymm9
.Li82:
vpmaxsd %ymm1,%ymm5,%ymm7
.Li83:
vpgatherdd %ymm13,(%rax,%ymm9,4),%ymm11
.Li84:
vmovdqu %ymm11,0x1a0(%rsp)
.Li85:
vpgatherdd %ymm8,(%rdx,%ymm3,4),%ymm13
.Li86:
mov 0x20(%r10),%rdx
.Li87:
vmovdqa %ymm12,%ymm3
.Li88:
vpminsd %ymm1,%ymm5,%ymm8
.Li89:
vpgatherdd %ymm3,(%rdx,%ymm6,4),%ymm11
.Li90:
mov 0x28(%r10),%rdx
.Li91:
vmovdqa %ymm12,%ymm6
.Li92:
vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
.Li93:
vpcmpgtd %ymm5,%ymm1,%ymm6
.Li94:
vmovdqu %ymm10,0x140(%rsp)
.Li95:
vpcmpgtd %ymm7,%ymm0,%ymm4
.Li96:
vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
.Li97:
vpblendvb %ymm4,-0x1(%rip),%ymm6,%ymm6
.Li98:
vpmaxsd %ymm0,%ymm7,%ymm4
.Li99:
vpminsd %ymm0,%ymm8,%ymm7
.Li100:
vmovdqu %ymm4,0x1c0(%rsp)
.Li101:
vpaddd %ymm10,%ymm6,%ymm6
.Li102:
vpcmpgtd %ymm0,%ymm8,%ymm8
.Li103:
vmovdqu %ymm7,0x1e0(%rsp)
.Li104:
vmovdqa %ymm12,%ymm7
.Li105:
vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm4
.Li106:
vpcmpgtd %ymm1,%ymm5,%ymm6
.Li107:
vmovdqu 0x1e0(%rsp),%ymm10
.Li108:
vmovdqu %ymm9,0x180(%rsp)
.Li109:
vmovdqa %ymm12,%ymm7
.Li110:
vpand %ymm15,%ymm4,%ymm4
.Li111:
vpblendvb %ymm6,%ymm14,%ymm2,%ymm6
.Li112:
vpblendvb %ymm8,-0x1(%rip),%ymm6,%ymm6
.Li113:
vpsubd %ymm6,%ymm9,%ymm6
.Li114:
vpaddd 0x1c0(%rsp),%ymm10,%ymm9
.Li115:
vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm8
.Li116:
vpaddd %ymm1,%ymm5,%ymm10
.Li117:
vpand 0x160(%rsp),%ymm15,%ymm7
.Li118:
vpand %ymm15,%ymm8,%ymm8
.Li119:
vpsubd %ymm9,%ymm0,%ymm9
.Li120:
vpaddd %ymm10,%ymm9,%ymm10
.Li121:
vpsubd %ymm4,%ymm8,%ymm9
.Li122:
vpslld $0x10,%ymm7,%ymm6
.Li123:
vpmulld %ymm9,%ymm10,%ymm9
.Li124:
vpaddd 0x120(%rsp),%ymm6,%ymm6
.Li125:
vpsubd %ymm7,%ymm4,%ymm4
.Li126:
vpmulld 0x1c0(%rsp),%ymm4,%ymm4
.Li127:
vpaddd %ymm6,%ymm9,%ymm6
.Li128:
vpand 0x1a0(%rsp),%ymm15,%ymm9
.Li129:
vpsubd %ymm8,%ymm9,%ymm9
.Li130:
vpmulld 0x1e0(%rsp),%ymm9,%ymm9
.Li131:
vpaddd %ymm4,%ymm9,%ymm9
.Li132:
vpaddd %ymm9,%ymm6,%ymm6
.Li133:
vpsrld $0x10,%ymm6,%ymm7
.Li134:
vpsrad $0x10,%ymm13,%ymm6
.Li135:
vmovdqu %ymm7,0x1e0(%rsp)
.Li136:
vpsrad $0x10,%ymm11,%ymm7
.Li137:
vpaddd %ymm5,%ymm6,%ymm6
.Li138:
vpaddd %ymm1,%ymm7,%ymm7
.Li139:
vpaddd %ymm7,%ymm6,%ymm4
.Li140:
vmovdqu %ymm4,0x200(%rsp)
.Li141:
vpsrad $0x10,%ymm3,%ymm4
.Li142:
vpslld $0x10,%ymm3,%ymm3
.Li143:
vpsrad $0x10,%ymm3,%ymm3
.Li144:
vpaddd %ymm0,%ymm4,%ymm4
.Li145:
vpaddd %ymm0,%ymm3,%ymm3
.Li146:
vpslld $0x10,%ymm11,%ymm0
.Li147:
vpsrad $0x10,%ymm0,%ymm0
.Li148:
vpaddd %ymm1,%ymm0,%ymm0
.Li149:
vpslld $0x10,%ymm13,%ymm1
.Li150:
vpsrad $0x10,%ymm1,%ymm1
.Li151:
vpaddd %ymm0,%ymm3,%ymm10
.Li152:
vpaddd %ymm5,%ymm1,%ymm1
.Li153:
vpmaxsd %ymm0,%ymm1,%ymm8
.Li154:
vpcmpgtd %ymm1,%ymm0,%ymm11
.Li155:
vpmaxsd %ymm3,%ymm8,%ymm13
.Li156:
vpcmpgtd %ymm8,%ymm3,%ymm5
.Li157:
vmovdqa %ymm12,%ymm8
.Li158:
vmovdqu %ymm13,0x1c0(%rsp)
.Li159:
vpminsd %ymm0,%ymm1,%ymm13
.Li160:
vpcmpgtd %ymm0,%ymm1,%ymm0
.Li161:
vpminsd %ymm3,%ymm13,%ymm9
.Li162:
vpcmpgtd %ymm3,%ymm13,%ymm13
.Li163:
vpblendvb %ymm11,%ymm14,%ymm2,%ymm11
.Li164:
vmovdqu 0x180(%rsp),%ymm3
.Li165:
vpblendvb %ymm5,-0x1(%rip),%ymm11,%ymm11
.Li166:
vpblendvb %ymm0,%ymm14,%ymm2,%ymm0
.Li167:
vpaddd 0x140(%rsp),%ymm11,%ymm11
.Li168:
vpblendvb %ymm13,-0x1(%rip),%ymm0,%ymm0
.Li169:
vmovdqa %ymm12,%ymm13
.Li170:
vpsubd %ymm0,%ymm3,%ymm0
.Li171:
vpgatherdd %ymm8,(%rax,%ymm11,4),%ymm5
.Li172:
vpaddd 0x1c0(%rsp),%ymm9,%ymm8
.Li173:
vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm11
.Li174:
vmovdqu 0x160(%rsp),%ymm0
.Li175:
vpsrld $0x8,%ymm5,%ymm5
.Li176:
vpsrld $0x8,%ymm11,%ymm11
.Li177:
vpand %ymm15,%ymm5,%ymm5
.Li178:
vpsubd %ymm8,%ymm1,%ymm1
.Li179:
vpsrld $0x8,%ymm0,%ymm13
.Li180:
vmovdqu 0x1a0(%rsp),%ymm0
.Li181:
vpand %ymm15,%ymm11,%ymm11
.Li182:
vpaddd %ymm10,%ymm1,%ymm1
.Li183:
vpsubd %ymm5,%ymm11,%ymm10
.Li184:
vpand %ymm15,%ymm13,%ymm13
.Li185:
vpminsd %ymm7,%ymm6,%ymm8
.Li186:
vpsrld $0x8,%ymm0,%ymm3
.Li187:
vpmulld %ymm10,%ymm1,%ymm10
.Li188:
vpsubd %ymm13,%ymm5,%ymm5
.Li189:
vpand %ymm15,%ymm3,%ymm3
.Li190:
vpslld $0x10,%ymm13,%ymm0
.Li191:
vmovdqa %ymm12,%ymm13
.Li192:
vpsubd %ymm11,%ymm3,%ymm3
.Li193:
vpaddd 0x120(%rsp),%ymm0,%ymm0
.Li194:
vpmulld 0x1c0(%rsp),%ymm5,%ymm5
.Li195:
vmovdqu 0x1a0(%rsp),%ymm11
.Li196:
vpmulld %ymm9,%ymm3,%ymm3
.Li197:
vpminsd %ymm4,%ymm8,%ymm9
.Li198:
vpcmpgtd %ymm4,%ymm8,%ymm8
.Li199:
vpaddd %ymm0,%ymm10,%ymm0
.Li200:
vpaddd %ymm5,%ymm3,%ymm3
.Li201:
vpmaxsd %ymm7,%ymm6,%ymm5
.Li202:
vpaddd %ymm3,%ymm0,%ymm0
.Li203:
vpcmpgtd %ymm6,%ymm7,%ymm3
.Li204:
vpcmpgtd %ymm5,%ymm4,%ymm1
.Li205:
vpcmpgtd %ymm7,%ymm6,%ymm6
.Li206:
vpmaxsd %ymm4,%ymm5,%ymm5
.Li207:
vpsrld $0x10,%ymm11,%ymm7
.Li208:
vpsrld $0x10,%ymm0,%ymm0
.Li209:
vmovdqu 0xa0(%rsp),%ymm11
.Li210:
vpblendvb %ymm3,%ymm14,%ymm2,%ymm3
.Li211:
vpand %ymm15,%ymm7,%ymm7
.Li212:
vpblendvb %ymm1,-0x1(%rip),%ymm3,%ymm3
.Li213:
vpblendvb %ymm6,%ymm14,%ymm2,%ymm2
.Li214:
vmovdqu 0x160(%rsp),%ymm6
.Li215:
vmovdqu 0x60(%rsp),%ymm14
.Li216:
vpaddd 0x140(%rsp),%ymm3,%ymm3
.Li217:
vpblendvb %ymm8,-0x1(%rip),%ymm2,%ymm2
.Li218:
vpaddd %ymm9,%ymm5,%ymm8
.Li219:
vpsubd %ymm8,%ymm4,%ymm4
.Li220:
vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm1
.Li221:
vmovdqu 0x180(%rsp),%ymm3
.Li222:
vmovdqa %ymm12,%ymm13
.Li223:
vpaddd 0x200(%rsp),%ymm4,%ymm4
.Li224:
vpsrld $0x10,%ymm1,%ymm1
.Li225:
vpsubd %ymm2,%ymm3,%ymm2
.Li226:
vpand %ymm15,%ymm1,%ymm1
.Li227:
vpgatherdd %ymm13,(%rax,%ymm2,4),%ymm3
.Li228:
vpsrld $0x10,%ymm6,%ymm2
.Li229:
vmovdqu 0x20(%rsp),%ymm13
.Li230:
vpsrld $0x10,%ymm3,%ymm3
.Li231:
vpand %ymm15,%ymm2,%ymm2
.Li232:
vpand %ymm15,%ymm3,%ymm3
.Li233:
vpslld $0x10,%ymm2,%ymm6
.Li234:
vpsubd %ymm1,%ymm3,%ymm8
.Li235:
vpsubd %ymm3,%ymm7,%ymm7
.Li236:
vpsubd %ymm2,%ymm1,%ymm1
.Li237:
vpmulld %ymm8,%ymm4,%ymm8
.Li238:
vpaddd 0x120(%rsp),%ymm6,%ymm6
.Li239:
vpmulld %ymm5,%ymm1,%ymm1
.Li240:
vpmulld %ymm9,%ymm7,%ymm7
.Li241:
vpaddd %ymm6,%ymm8,%ymm6
.Li242:
vpaddd %ymm1,%ymm7,%ymm7
.Li243:
vpaddd %ymm7,%ymm6,%ymm6
.Li244:
vmovdqu 0x1e0(%rsp),%ymm7
.Li245:
vpsrld $0x10,%ymm6,%ymm6
.Li246:
vpsubd %ymm7,%ymm0,%ymm1
.Li247:
vpsubd %ymm7,%ymm6,%ymm4
.Li248:
vpcmpgtd %ymm7,%ymm13,%ymm5
.Li249:
vpcmpgtd %ymm1,%ymm14,%ymm3
.Li250:
vpcmpgtd %ymm4,%ymm11,%ymm2
.Li251:
vpor %ymm2,%ymm3,%ymm2
.Li252:
vpcmpgtd 0xc0(%rsp),%ymm4,%ymm3
.Li253:
vpor %ymm3,%ymm2,%ymm2
.Li254:
vpcmpgtd 0x40(%rsp),%ymm7,%ymm3
.Li255:
vpor %ymm3,%ymm5,%ymm3
.Li256:
vpcmpgtd 0x80(%rsp),%ymm1,%ymm5
.Li257:
vpor %ymm5,%ymm3,%ymm3
.Li258:
vpor %ymm3,%ymm2,%ymm2
.Li259:
vpmovmskb %ymm2,%eax
.Li260:
test %eax,%eax
.Li261:
je .Lloop
.Loutside:
