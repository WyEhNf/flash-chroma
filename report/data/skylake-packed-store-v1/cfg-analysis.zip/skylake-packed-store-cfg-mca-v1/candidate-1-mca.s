.text
.Lloop:
.Li0:
mov 0x24(%rdi),%eax
.Li1:
mov 0x20(%rdi),%edx
.Li2:
vpsubd %ymm14,%ymm2,%ymm0
.Li3:
vpsubd %ymm11,%ymm4,%ymm4
.Li4:
imul %eax,%edx
.Li5:
vmovd %eax,%xmm1
.Li6:
mov (%rdi),%rax
.Li7:
vpbroadcastd %xmm1,%ymm1
.Li8:
vpmulld %ymm1,%ymm0,%ymm0
.Li9:
vpsubd %ymm13,%ymm7,%ymm1
.Li10:
vmovd %edx,%xmm2
.Li11:
vpbroadcastd %xmm2,%ymm2
.Li12:
vpmulld %ymm2,%ymm1,%ymm1
.Li13:
vpaddd %ymm1,%ymm0,%ymm0
.Li14:
vpaddd %ymm4,%ymm0,%ymm0
.Li15:
vmovdqa %ymm12,%ymm4
.Li16:
vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
.Li17:
vpshufb 0x120(%rsp),%ymm1,%ymm0
.Li18:
vmovdqa %xmm0,%xmm2
.Li19:
vextracti128 $0x1,%ymm0,%xmm0
.Li20:
add $0x18,%r11
.Li21:
vpslldq $0xc,%xmm0,%xmm1
.Li22:
vpsrldq $0x4,%xmm0,%xmm0
.Li23:
vpor %xmm2,%xmm1,%xmm1
.Li24:
vmovq %xmm0,-0x8(%r11)
.Li25:
vmovdqu %xmm1,-0x18(%r11)
.Li26:
cmp %r12,%rbp
.Li27:
je .Loutside
.Li28:
inc %r12
.Li29:
vmovdqu (%r11),%xmm0
.Li30:
vmovq 0x10(%r11),%xmm1
.Li31:
vmovdqa %ymm12,%ymm7
.Li32:
vmovdqa %ymm12,%ymm11
.Li33:
mov (%r10),%rax
.Li34:
mov 0x54(%r10),%ecx
.Li35:
vmovdqa %ymm12,%ymm10
.Li36:
vpalignr $0xc,%xmm0,%xmm1,%xmm1
.Li37:
mov 0x50(%r10),%edx
.Li38:
vinserti128 $0x1,%xmm1,%ymm0,%ymm0
.Li39:
vmovd %ecx,%xmm9
.Li40:
vpshufb 0x100(%rsp),%ymm0,%ymm0
.Li41:
vmovd %edx,%xmm14
.Li42:
vpbroadcastd %xmm9,%ymm9
.Li43:
vpsrld $0x10,%ymm0,%ymm3
.Li44:
vpsrld $0x8,%ymm0,%ymm5
.Li45:
vpand %ymm15,%ymm0,%ymm0
.Li46:
vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm4
.Li47:
mov 0x8(%r10),%rax
.Li48:
vpand %ymm15,%ymm5,%ymm5
.Li49:
vmovdqa %ymm12,%ymm7
.Li50:
vpbroadcastd %xmm14,%ymm14
.Li51:
vpsrld $0x11,%ymm4,%ymm8
.Li52:
lea 0x1(%rcx,%rdx,1),%edx
.Li53:
vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm2
.Li54:
vpmulld %ymm14,%ymm8,%ymm8
.Li55:
mov 0x10(%r10),%rax
.Li56:
vmovdqa %ymm12,%ymm7
.Li57:
vpsrld $0x11,%ymm2,%ymm6
.Li58:
vpmulld %ymm9,%ymm6,%ymm6
.Li59:
vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm1
.Li60:
mov 0x48(%r10),%rax
.Li61:
vpsrld $0x11,%ymm1,%ymm7
.Li62:
vpaddd %ymm8,%ymm6,%ymm6
.Li63:
vpaddd %ymm7,%ymm6,%ymm8
.Li64:
vpsrld $0xf,%ymm12,%ymm6
.Li65:
vpand %ymm6,%ymm4,%ymm4
.Li66:
vpand %ymm6,%ymm2,%ymm2
.Li67:
vpand %ymm6,%ymm1,%ymm1
.Li68:
vmovdqa %ymm12,%ymm6
.Li69:
vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
.Li70:
vmovd %edx,%xmm6
.Li71:
mov 0x18(%r10),%rdx
.Li72:
vpbroadcastd %xmm6,%ymm6
.Li73:
vmovdqu %ymm7,0x180(%rsp)
.Li74:
vpaddd %ymm8,%ymm6,%ymm7
.Li75:
vmovdqu %ymm7,0x20(%rsp)
.Li76:
vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm6
.Li77:
vpsrld $0x1f,%ymm12,%ymm7
.Li78:
vmovdqu %ymm6,0x1a0(%rsp)
.Li79:
vpminsd %ymm2,%ymm4,%ymm6
.Li80:
vpgatherdd %ymm10,(%rdx,%ymm0,4),%ymm11
.Li81:
mov 0x20(%r10),%rdx
.Li82:
vmovdqa %ymm12,%ymm0
.Li83:
vpgatherdd %ymm0,(%rdx,%ymm5,4),%ymm10
.Li84:
mov 0x28(%r10),%rdx
.Li85:
vmovdqa %ymm12,%ymm0
.Li86:
vpmaxsd %ymm2,%ymm4,%ymm5
.Li87:
vpgatherdd %ymm0,(%rdx,%ymm3,4),%ymm13
.Li88:
vpcmpgtd %ymm4,%ymm2,%ymm3
.Li89:
vpcmpgtd %ymm5,%ymm1,%ymm0
.Li90:
vpblendvb %ymm3,%ymm9,%ymm14,%ymm3
.Li91:
vpblendvb %ymm0,%ymm7,%ymm3,%ymm3
.Li92:
vpmaxsd %ymm1,%ymm5,%ymm0
.Li93:
vpminsd %ymm1,%ymm6,%ymm5
.Li94:
vpaddd %ymm8,%ymm3,%ymm3
.Li95:
vmovdqu %ymm0,0x1e0(%rsp)
.Li96:
vpcmpgtd %ymm1,%ymm6,%ymm6
.Li97:
vmovdqu %ymm5,0x200(%rsp)
.Li98:
vmovdqa %ymm12,%ymm5
.Li99:
vmovdqu %ymm8,0x160(%rsp)
.Li100:
vmovdqu 0x200(%rsp),%ymm8
.Li101:
vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm0
.Li102:
vpcmpgtd %ymm2,%ymm4,%ymm3
.Li103:
vmovdqu %ymm9,0x140(%rsp)
.Li104:
vmovdqu 0x20(%rsp),%ymm5
.Li105:
vpaddd 0x1e0(%rsp),%ymm8,%ymm8
.Li106:
vmovdqa %ymm12,%ymm9
.Li107:
vpand %ymm15,%ymm0,%ymm0
.Li108:
vpblendvb %ymm3,0x140(%rsp),%ymm14,%ymm3
.Li109:
vpsubd %ymm8,%ymm1,%ymm8
.Li110:
vpblendvb %ymm6,%ymm7,%ymm3,%ymm3
.Li111:
vpsubd %ymm3,%ymm5,%ymm3
.Li112:
vpand 0x180(%rsp),%ymm15,%ymm5
.Li113:
vpgatherdd %ymm9,(%rax,%ymm3,4),%ymm6
.Li114:
vpaddd %ymm2,%ymm4,%ymm9
.Li115:
vpand %ymm15,%ymm6,%ymm6
.Li116:
vpslld $0x10,%ymm5,%ymm3
.Li117:
vpaddd %ymm9,%ymm8,%ymm9
.Li118:
vpsubd %ymm0,%ymm6,%ymm8
.Li119:
vpaddd 0x1c0(%rsp),%ymm3,%ymm3
.Li120:
vpmulld %ymm8,%ymm9,%ymm8
.Li121:
vpsubd %ymm5,%ymm0,%ymm0
.Li122:
vpmulld 0x1e0(%rsp),%ymm0,%ymm0
.Li123:
vpaddd %ymm3,%ymm8,%ymm3
.Li124:
vpand 0x1a0(%rsp),%ymm15,%ymm8
.Li125:
vpsubd %ymm6,%ymm8,%ymm8
.Li126:
vpsrad $0x10,%ymm10,%ymm6
.Li127:
vpmulld 0x200(%rsp),%ymm8,%ymm8
.Li128:
vpaddd %ymm0,%ymm8,%ymm8
.Li129:
vpaddd %ymm2,%ymm6,%ymm6
.Li130:
vpaddd %ymm8,%ymm3,%ymm3
.Li131:
vpsrld $0x10,%ymm3,%ymm5
.Li132:
vpslld $0x10,%ymm13,%ymm3
.Li133:
vmovdqu %ymm5,0x1e0(%rsp)
.Li134:
vpsrad $0x10,%ymm11,%ymm5
.Li135:
vpsrad $0x10,%ymm3,%ymm3
.Li136:
vpaddd %ymm4,%ymm5,%ymm5
.Li137:
vpaddd %ymm1,%ymm3,%ymm3
.Li138:
vpaddd %ymm6,%ymm5,%ymm0
.Li139:
vmovdqu %ymm0,0x220(%rsp)
.Li140:
vpsrad $0x10,%ymm13,%ymm0
.Li141:
vpaddd %ymm1,%ymm0,%ymm0
.Li142:
vpslld $0x10,%ymm10,%ymm1
.Li143:
vmovdqa %ymm12,%ymm10
.Li144:
vpsrad $0x10,%ymm1,%ymm1
.Li145:
vpaddd %ymm2,%ymm1,%ymm1
.Li146:
vpaddd %ymm1,%ymm3,%ymm2
.Li147:
vmovdqu %ymm2,0x200(%rsp)
.Li148:
vpslld $0x10,%ymm11,%ymm2
.Li149:
vpsrad $0x10,%ymm2,%ymm2
.Li150:
vpaddd %ymm4,%ymm2,%ymm2
.Li151:
vpmaxsd %ymm1,%ymm2,%ymm8
.Li152:
vpcmpgtd %ymm2,%ymm1,%ymm11
.Li153:
vpminsd %ymm1,%ymm2,%ymm13
.Li154:
vpcmpgtd %ymm8,%ymm3,%ymm4
.Li155:
vpcmpgtd %ymm1,%ymm2,%ymm1
.Li156:
vpminsd %ymm3,%ymm13,%ymm9
.Li157:
vpcmpgtd %ymm3,%ymm13,%ymm13
.Li158:
vpmaxsd %ymm3,%ymm8,%ymm8
.Li159:
vmovdqu 0x20(%rsp),%ymm3
.Li160:
vpblendvb %ymm11,0x140(%rsp),%ymm14,%ymm11
.Li161:
vpblendvb %ymm4,%ymm7,%ymm11,%ymm11
.Li162:
vpblendvb %ymm1,0x140(%rsp),%ymm14,%ymm1
.Li163:
vpaddd 0x160(%rsp),%ymm11,%ymm11
.Li164:
vpblendvb %ymm13,%ymm7,%ymm1,%ymm1
.Li165:
vmovdqa %ymm12,%ymm13
.Li166:
vpsubd %ymm1,%ymm3,%ymm1
.Li167:
vpgatherdd %ymm10,(%rax,%ymm11,4),%ymm4
.Li168:
vpgatherdd %ymm13,(%rax,%ymm1,4),%ymm11
.Li169:
vmovdqu 0x180(%rsp),%ymm1
.Li170:
vpaddd %ymm9,%ymm8,%ymm10
.Li171:
vpsrld $0x8,%ymm4,%ymm4
.Li172:
vpsrld $0x8,%ymm11,%ymm11
.Li173:
vpsubd %ymm10,%ymm2,%ymm2
.Li174:
vpsrld $0x8,%ymm1,%ymm13
.Li175:
vmovdqu 0x1a0(%rsp),%ymm1
.Li176:
vpaddd 0x200(%rsp),%ymm2,%ymm2
.Li177:
vpand %ymm15,%ymm11,%ymm11
.Li178:
vpand %ymm15,%ymm13,%ymm13
.Li179:
vpand %ymm15,%ymm4,%ymm4
.Li180:
vpsrld $0x8,%ymm1,%ymm3
.Li181:
vpslld $0x10,%ymm13,%ymm1
.Li182:
vpsubd %ymm4,%ymm11,%ymm10
.Li183:
vpand %ymm15,%ymm3,%ymm3
.Li184:
vpsubd %ymm13,%ymm4,%ymm4
.Li185:
vpaddd 0x1c0(%rsp),%ymm1,%ymm1
.Li186:
vpsubd %ymm11,%ymm3,%ymm3
.Li187:
vpmulld %ymm8,%ymm4,%ymm4
.Li188:
vmovdqu 0x140(%rsp),%ymm11
.Li189:
vpminsd %ymm6,%ymm5,%ymm8
.Li190:
vpmulld %ymm10,%ymm2,%ymm10
.Li191:
vpmulld %ymm9,%ymm3,%ymm3
.Li192:
vpminsd %ymm0,%ymm8,%ymm9
.Li193:
vpcmpgtd %ymm0,%ymm8,%ymm8
.Li194:
vmovdqa %ymm12,%ymm13
.Li195:
vpaddd %ymm4,%ymm3,%ymm3
.Li196:
vpaddd %ymm1,%ymm10,%ymm1
.Li197:
vpmaxsd %ymm6,%ymm5,%ymm4
.Li198:
vpaddd %ymm3,%ymm1,%ymm1
.Li199:
vpcmpgtd %ymm5,%ymm6,%ymm3
.Li200:
vpcmpgtd %ymm4,%ymm0,%ymm2
.Li201:
vpcmpgtd %ymm6,%ymm5,%ymm5
.Li202:
vpmaxsd %ymm0,%ymm4,%ymm4
.Li203:
vpsrld $0x10,%ymm1,%ymm1
.Li204:
vpblendvb %ymm3,%ymm11,%ymm14,%ymm3
.Li205:
vpblendvb %ymm2,%ymm7,%ymm3,%ymm3
.Li206:
vpaddd 0x160(%rsp),%ymm3,%ymm3
.Li207:
vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm2
.Li208:
vpblendvb %ymm5,%ymm11,%ymm14,%ymm3
.Li209:
vmovdqu 0x20(%rsp),%ymm6
.Li210:
vmovdqa %ymm12,%ymm13
.Li211:
vpblendvb %ymm8,%ymm7,%ymm3,%ymm3
.Li212:
vpaddd %ymm9,%ymm4,%ymm8
.Li213:
vmovdqu 0x80(%rsp),%ymm14
.Li214:
vmovdqu 0xc0(%rsp),%ymm11
.Li215:
vpsubd %ymm3,%ymm6,%ymm3
.Li216:
vpsubd %ymm8,%ymm0,%ymm0
.Li217:
vpsrld $0x10,%ymm2,%ymm2
.Li218:
vpgatherdd %ymm13,(%rax,%ymm3,4),%ymm6
.Li219:
vmovdqu 0x180(%rsp),%ymm3
.Li220:
vpand %ymm15,%ymm2,%ymm2
.Li221:
vpaddd 0x220(%rsp),%ymm0,%ymm0
.Li222:
vpsrld $0x10,%ymm6,%ymm6
.Li223:
vmovdqu 0x40(%rsp),%ymm13
.Li224:
vpsrld $0x10,%ymm3,%ymm5
.Li225:
vmovdqu 0x1a0(%rsp),%ymm3
.Li226:
vpand %ymm15,%ymm6,%ymm6
.Li227:
vpand %ymm15,%ymm5,%ymm5
.Li228:
vpsubd %ymm2,%ymm6,%ymm8
.Li229:
vpsrld $0x10,%ymm3,%ymm3
.Li230:
vpmulld %ymm8,%ymm0,%ymm0
.Li231:
vpsubd %ymm5,%ymm2,%ymm2
.Li232:
vpmulld %ymm4,%ymm2,%ymm2
.Li233:
vpslld $0x10,%ymm5,%ymm7
.Li234:
vpand %ymm15,%ymm3,%ymm3
.Li235:
vpsubd %ymm6,%ymm3,%ymm3
.Li236:
vpaddd 0x1c0(%rsp),%ymm7,%ymm7
.Li237:
vpmulld %ymm9,%ymm3,%ymm3
.Li238:
vpaddd %ymm7,%ymm0,%ymm0
.Li239:
vmovdqu 0x1e0(%rsp),%ymm7
.Li240:
vpcmpgtd 0x60(%rsp),%ymm7,%ymm6
.Li241:
vpaddd %ymm2,%ymm3,%ymm3
.Li242:
vpsubd %ymm7,%ymm1,%ymm2
.Li243:
vpaddd %ymm3,%ymm0,%ymm0
.Li244:
vpcmpgtd %ymm2,%ymm14,%ymm3
.Li245:
vpsrld $0x10,%ymm0,%ymm0
.Li246:
vpsubd %ymm7,%ymm0,%ymm4
.Li247:
vpcmpgtd %ymm4,%ymm11,%ymm5
.Li248:
vpor %ymm5,%ymm3,%ymm3
.Li249:
vpcmpgtd 0xe0(%rsp),%ymm4,%ymm5
.Li250:
vpor %ymm5,%ymm3,%ymm3
.Li251:
vpcmpgtd %ymm7,%ymm13,%ymm5
.Li252:
vpor %ymm6,%ymm5,%ymm5
.Li253:
vpcmpgtd 0xa0(%rsp),%ymm2,%ymm6
.Li254:
vpor %ymm6,%ymm5,%ymm5
.Li255:
vpor %ymm5,%ymm3,%ymm3
.Li256:
vpmovmskb %ymm3,%eax
.Li257:
test %eax,%eax
.Li258:
je .Lloop
.Loutside:
