.text
.Lloop:
.Li0:
mov 0x24(%rbx),%eax
.Li1:
mov 0x20(%rbx),%edx
.Li2:
vpsubd %ymm14,%ymm1,%ymm1
.Li3:
vpsubd %ymm11,%ymm5,%ymm5
.Li4:
imul %eax,%edx
.Li5:
vmovd %eax,%xmm0
.Li6:
mov (%rbx),%rax
.Li7:
vpbroadcastd %xmm0,%ymm0
.Li8:
vpmulld %ymm0,%ymm1,%ymm1
.Li9:
vpsubd %ymm13,%ymm7,%ymm0
.Li10:
vmovdqa %ymm12,%ymm7
.Li11:
vmovd %edx,%xmm2
.Li12:
vpbroadcastd %xmm2,%ymm2
.Li13:
vpmulld %ymm2,%ymm0,%ymm0
.Li14:
vpaddd %ymm0,%ymm1,%ymm1
.Li15:
vpaddd %ymm5,%ymm1,%ymm1
.Li16:
vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm2
.Li17:
vpsrld $0x8,%ymm2,%ymm0
.Li18:
vpand %ymm15,%ymm2,%ymm1
.Li19:
vpand %ymm15,%ymm0,%ymm0
.Li20:
vpsrld $0x10,%ymm2,%ymm2
.Li21:
vpslld $0x10,%ymm2,%ymm2
.Li22:
vpslld $0x8,%ymm0,%ymm0
.Li23:
add $0x18,%r11
.Li24:
vpor %ymm2,%ymm0,%ymm0
.Li25:
vpor %ymm1,%ymm0,%ymm0
.Li26:
vpshufb 0x100(%rsp),%ymm0,%ymm0
.Li27:
vmovdqa %xmm0,%xmm2
.Li28:
vextracti128 $0x1,%ymm0,%xmm0
.Li29:
vpslldq $0xc,%xmm0,%xmm1
.Li30:
vpsrldq $0x4,%xmm0,%xmm0
.Li31:
vpor %xmm2,%xmm1,%xmm1
.Li32:
vmovq %xmm0,-0x8(%r11)
.Li33:
vmovdqu %xmm1,-0x18(%r11)
.Li34:
cmp %r12,%r8
.Li35:
je .Loutside
.Li36:
inc %r12
.Li37:
vmovdqu (%r11),%xmm2
.Li38:
vmovq 0x10(%r11),%xmm0
.Li39:
vmovdqa %ymm12,%ymm7
.Li40:
vmovdqa %ymm12,%ymm11
.Li41:
mov (%r10),%rax
.Li42:
mov 0x54(%r10),%ecx
.Li43:
vmovdqa %ymm12,%ymm10
.Li44:
vmovdqa %ymm12,%ymm13
.Li45:
vpalignr $0xc,%xmm2,%xmm0,%xmm0
.Li46:
mov 0x50(%r10),%edx
.Li47:
vinserti128 $0x1,%xmm0,%ymm2,%ymm2
.Li48:
vmovd %ecx,%xmm9
.Li49:
vpshufb 0xe0(%rsp),%ymm2,%ymm2
.Li50:
vmovd %edx,%xmm14
.Li51:
vpbroadcastd %xmm9,%ymm9
.Li52:
vpsrld $0x10,%ymm2,%ymm3
.Li53:
vpsrld $0x8,%ymm2,%ymm5
.Li54:
vpand %ymm15,%ymm2,%ymm2
.Li55:
vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm4
.Li56:
mov 0x8(%r10),%rax
.Li57:
vpand %ymm15,%ymm5,%ymm5
.Li58:
vmovdqa %ymm12,%ymm7
.Li59:
vpbroadcastd %xmm14,%ymm14
.Li60:
lea 0x1(%rcx,%rdx,1),%edx
.Li61:
vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm1
.Li62:
mov 0x10(%r10),%rax
.Li63:
vmovdqa %ymm12,%ymm7
.Li64:
vpsrld $0x11,%ymm1,%ymm6
.Li65:
vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
.Li66:
vpsrld $0x11,%ymm4,%ymm7
.Li67:
mov 0x48(%r10),%rax
.Li68:
vpmulld %ymm14,%ymm7,%ymm7
.Li69:
vpmulld %ymm9,%ymm6,%ymm6
.Li70:
vpsrld $0x11,%ymm0,%ymm8
.Li71:
vpaddd %ymm7,%ymm6,%ymm6
.Li72:
vpaddd %ymm8,%ymm6,%ymm8
.Li73:
vpsrld $0xf,%ymm12,%ymm6
.Li74:
vpand %ymm6,%ymm4,%ymm4
.Li75:
vpand %ymm6,%ymm1,%ymm1
.Li76:
vpand %ymm6,%ymm0,%ymm0
.Li77:
vmovdqa %ymm12,%ymm6
.Li78:
vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm7
.Li79:
vmovd %edx,%xmm6
.Li80:
mov 0x18(%r10),%rdx
.Li81:
vpbroadcastd %xmm6,%ymm6
.Li82:
vmovdqu %ymm7,0x180(%rsp)
.Li83:
vpaddd %ymm8,%ymm6,%ymm7
.Li84:
vmovdqu %ymm7,0x120(%rsp)
.Li85:
vpgatherdd %ymm11,(%rax,%ymm7,4),%ymm6
.Li86:
vpsrld $0x1f,%ymm12,%ymm7
.Li87:
vmovdqu %ymm6,0x1a0(%rsp)
.Li88:
vpminsd %ymm1,%ymm4,%ymm6
.Li89:
vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm11
.Li90:
mov 0x20(%r10),%rdx
.Li91:
vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm10
.Li92:
mov 0x28(%r10),%rdx
.Li93:
vmovdqa %ymm12,%ymm5
.Li94:
vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm13
.Li95:
vpcmpgtd %ymm4,%ymm1,%ymm3
.Li96:
vpmaxsd %ymm1,%ymm4,%ymm5
.Li97:
vpcmpgtd %ymm5,%ymm0,%ymm2
.Li98:
vpmaxsd %ymm0,%ymm5,%ymm5
.Li99:
vmovdqu %ymm5,0x1e0(%rsp)
.Li100:
vmovdqa %ymm12,%ymm5
.Li101:
vpblendvb %ymm3,%ymm9,%ymm14,%ymm3
.Li102:
vpblendvb %ymm2,%ymm7,%ymm3,%ymm3
.Li103:
vpminsd %ymm0,%ymm6,%ymm2
.Li104:
vmovdqu %ymm2,0x200(%rsp)
.Li105:
vpaddd %ymm8,%ymm3,%ymm3
.Li106:
vpcmpgtd %ymm0,%ymm6,%ymm6
.Li107:
vmovdqu %ymm8,0x160(%rsp)
.Li108:
vmovdqu 0x200(%rsp),%ymm8
.Li109:
vpgatherdd %ymm5,(%rax,%ymm3,4),%ymm2
.Li110:
vpcmpgtd %ymm1,%ymm4,%ymm3
.Li111:
vmovdqu %ymm9,0x140(%rsp)
.Li112:
vmovdqu 0x120(%rsp),%ymm5
.Li113:
vpaddd 0x1e0(%rsp),%ymm8,%ymm8
.Li114:
vmovdqa %ymm12,%ymm9
.Li115:
vpand %ymm15,%ymm2,%ymm2
.Li116:
vpblendvb %ymm3,0x140(%rsp),%ymm14,%ymm3
.Li117:
vpsubd %ymm8,%ymm0,%ymm8
.Li118:
vpblendvb %ymm6,%ymm7,%ymm3,%ymm3
.Li119:
vpsubd %ymm3,%ymm5,%ymm3
.Li120:
vpand 0x180(%rsp),%ymm15,%ymm5
.Li121:
vpgatherdd %ymm9,(%rax,%ymm3,4),%ymm6
.Li122:
vpaddd %ymm1,%ymm4,%ymm9
.Li123:
vpand %ymm15,%ymm6,%ymm6
.Li124:
vpslld $0x10,%ymm5,%ymm3
.Li125:
vpaddd %ymm9,%ymm8,%ymm9
.Li126:
vpsubd %ymm2,%ymm6,%ymm8
.Li127:
vpaddd 0x1c0(%rsp),%ymm3,%ymm3
.Li128:
vpmulld %ymm8,%ymm9,%ymm8
.Li129:
vpsubd %ymm5,%ymm2,%ymm2
.Li130:
vpmulld 0x1e0(%rsp),%ymm2,%ymm2
.Li131:
vpaddd %ymm3,%ymm8,%ymm3
.Li132:
vpand 0x1a0(%rsp),%ymm15,%ymm8
.Li133:
vpsubd %ymm6,%ymm8,%ymm8
.Li134:
vpsrad $0x10,%ymm10,%ymm6
.Li135:
vpmulld 0x200(%rsp),%ymm8,%ymm8
.Li136:
vpaddd %ymm2,%ymm8,%ymm8
.Li137:
vpaddd %ymm1,%ymm6,%ymm6
.Li138:
vpslld $0x10,%ymm13,%ymm2
.Li139:
vpaddd %ymm8,%ymm3,%ymm3
.Li140:
vpsrad $0x10,%ymm2,%ymm2
.Li141:
vpsrld $0x10,%ymm3,%ymm5
.Li142:
vpaddd %ymm0,%ymm2,%ymm2
.Li143:
vmovdqu %ymm5,0x1e0(%rsp)
.Li144:
vpsrad $0x10,%ymm11,%ymm5
.Li145:
vpaddd %ymm4,%ymm5,%ymm5
.Li146:
vpaddd %ymm6,%ymm5,%ymm3
.Li147:
vmovdqu %ymm3,0x220(%rsp)
.Li148:
vpsrad $0x10,%ymm13,%ymm3
.Li149:
vpaddd %ymm0,%ymm3,%ymm3
.Li150:
vpslld $0x10,%ymm10,%ymm0
.Li151:
vmovdqa %ymm12,%ymm10
.Li152:
vpsrad $0x10,%ymm0,%ymm0
.Li153:
vpaddd %ymm1,%ymm0,%ymm0
.Li154:
vpaddd %ymm0,%ymm2,%ymm1
.Li155:
vmovdqu %ymm1,0x200(%rsp)
.Li156:
vpslld $0x10,%ymm11,%ymm1
.Li157:
vpsrad $0x10,%ymm1,%ymm1
.Li158:
vpaddd %ymm4,%ymm1,%ymm1
.Li159:
vpmaxsd %ymm0,%ymm1,%ymm8
.Li160:
vpcmpgtd %ymm1,%ymm0,%ymm11
.Li161:
vpminsd %ymm0,%ymm1,%ymm13
.Li162:
vpcmpgtd %ymm8,%ymm2,%ymm4
.Li163:
vpcmpgtd %ymm0,%ymm1,%ymm0
.Li164:
vpminsd %ymm2,%ymm13,%ymm9
.Li165:
vpcmpgtd %ymm2,%ymm13,%ymm13
.Li166:
vpmaxsd %ymm2,%ymm8,%ymm8
.Li167:
vmovdqu 0x120(%rsp),%ymm2
.Li168:
vpblendvb %ymm11,0x140(%rsp),%ymm14,%ymm11
.Li169:
vpblendvb %ymm4,%ymm7,%ymm11,%ymm11
.Li170:
vpblendvb %ymm0,0x140(%rsp),%ymm14,%ymm0
.Li171:
vpaddd 0x160(%rsp),%ymm11,%ymm11
.Li172:
vpblendvb %ymm13,%ymm7,%ymm0,%ymm0
.Li173:
vpsubd %ymm0,%ymm2,%ymm0
.Li174:
vmovdqu 0x1a0(%rsp),%ymm2
.Li175:
vpgatherdd %ymm10,(%rax,%ymm11,4),%ymm4
.Li176:
vmovdqa %ymm12,%ymm10
.Li177:
vpsrld $0x8,%ymm4,%ymm4
.Li178:
vpsrld $0x8,%ymm2,%ymm2
.Li179:
vpgatherdd %ymm10,(%rax,%ymm0,4),%ymm11
.Li180:
vmovdqu 0x180(%rsp),%ymm0
.Li181:
vpaddd %ymm9,%ymm8,%ymm10
.Li182:
vpsrld $0x8,%ymm11,%ymm11
.Li183:
vpand %ymm15,%ymm4,%ymm4
.Li184:
vpsrld $0x8,%ymm0,%ymm13
.Li185:
vpsubd %ymm10,%ymm1,%ymm1
.Li186:
vpand %ymm15,%ymm11,%ymm11
.Li187:
vpaddd 0x200(%rsp),%ymm1,%ymm1
.Li188:
vpand %ymm15,%ymm13,%ymm13
.Li189:
vpand %ymm15,%ymm2,%ymm2
.Li190:
vpsubd %ymm4,%ymm11,%ymm10
.Li191:
vpsubd %ymm11,%ymm2,%ymm2
.Li192:
vpslld $0x10,%ymm13,%ymm0
.Li193:
vmovdqu 0x140(%rsp),%ymm11
.Li194:
vpsubd %ymm13,%ymm4,%ymm4
.Li195:
vpmulld %ymm10,%ymm1,%ymm10
.Li196:
vpaddd 0x1c0(%rsp),%ymm0,%ymm0
.Li197:
vpmulld %ymm8,%ymm4,%ymm4
.Li198:
vpmulld %ymm9,%ymm2,%ymm2
.Li199:
vpminsd %ymm6,%ymm5,%ymm8
.Li200:
vpminsd %ymm3,%ymm8,%ymm9
.Li201:
vpcmpgtd %ymm3,%ymm8,%ymm8
.Li202:
vmovdqa %ymm12,%ymm13
.Li203:
vpaddd %ymm0,%ymm10,%ymm0
.Li204:
vpaddd %ymm4,%ymm2,%ymm2
.Li205:
vpmaxsd %ymm6,%ymm5,%ymm4
.Li206:
vpaddd %ymm2,%ymm0,%ymm0
.Li207:
vpcmpgtd %ymm5,%ymm6,%ymm2
.Li208:
vpcmpgtd %ymm4,%ymm3,%ymm1
.Li209:
vpcmpgtd %ymm6,%ymm5,%ymm5
.Li210:
vpmaxsd %ymm3,%ymm4,%ymm4
.Li211:
vpsrld $0x10,%ymm0,%ymm0
.Li212:
vpblendvb %ymm2,%ymm11,%ymm14,%ymm2
.Li213:
vpblendvb %ymm1,%ymm7,%ymm2,%ymm2
.Li214:
vpaddd 0x160(%rsp),%ymm2,%ymm2
.Li215:
vpgatherdd %ymm13,(%rax,%ymm2,4),%ymm1
.Li216:
vpblendvb %ymm5,%ymm11,%ymm14,%ymm2
.Li217:
vmovdqu 0x120(%rsp),%ymm6
.Li218:
vmovdqa %ymm12,%ymm11
.Li219:
vpblendvb %ymm8,%ymm7,%ymm2,%ymm2
.Li220:
vpaddd %ymm9,%ymm4,%ymm8
.Li221:
vmovdqu 0x60(%rsp),%ymm14
.Li222:
vmovdqu 0x20(%rsp),%ymm13
.Li223:
vpsubd %ymm2,%ymm6,%ymm2
.Li224:
vmovdqu 0x180(%rsp),%ymm6
.Li225:
vpsubd %ymm8,%ymm3,%ymm3
.Li226:
vpsrld $0x10,%ymm1,%ymm1
.Li227:
vpgatherdd %ymm11,(%rax,%ymm2,4),%ymm7
.Li228:
vmovdqu 0x1a0(%rsp),%ymm2
.Li229:
vpaddd 0x220(%rsp),%ymm3,%ymm3
.Li230:
vpand %ymm15,%ymm1,%ymm1
.Li231:
vpsrld $0x10,%ymm6,%ymm5
.Li232:
vpsrld $0x10,%ymm7,%ymm7
.Li233:
vmovdqu 0xa0(%rsp),%ymm11
.Li234:
vpsrld $0x10,%ymm2,%ymm6
.Li235:
vpand %ymm15,%ymm5,%ymm5
.Li236:
vpand %ymm15,%ymm7,%ymm7
.Li237:
vpand %ymm15,%ymm6,%ymm6
.Li238:
vpslld $0x10,%ymm5,%ymm2
.Li239:
vpsubd %ymm1,%ymm7,%ymm8
.Li240:
vpsubd %ymm7,%ymm6,%ymm6
.Li241:
vpsubd %ymm5,%ymm1,%ymm1
.Li242:
vpmulld %ymm8,%ymm3,%ymm8
.Li243:
vmovdqu 0x1e0(%rsp),%ymm7
.Li244:
vpmulld %ymm4,%ymm1,%ymm1
.Li245:
vpmulld %ymm9,%ymm6,%ymm6
.Li246:
vpaddd 0x1c0(%rsp),%ymm2,%ymm2
.Li247:
vpaddd %ymm2,%ymm8,%ymm2
.Li248:
vpaddd %ymm1,%ymm6,%ymm6
.Li249:
vpsubd %ymm7,%ymm0,%ymm1
.Li250:
vpaddd %ymm6,%ymm2,%ymm2
.Li251:
vpcmpgtd %ymm1,%ymm14,%ymm4
.Li252:
vpsrld $0x10,%ymm2,%ymm2
.Li253:
vpcmpgtd %ymm7,%ymm13,%ymm6
.Li254:
vpsubd %ymm7,%ymm2,%ymm5
.Li255:
vpcmpgtd %ymm5,%ymm11,%ymm3
.Li256:
vpor %ymm3,%ymm4,%ymm3
.Li257:
vpcmpgtd 0xc0(%rsp),%ymm5,%ymm4
.Li258:
vpor %ymm4,%ymm3,%ymm3
.Li259:
vpcmpgtd 0x40(%rsp),%ymm7,%ymm4
.Li260:
vpor %ymm4,%ymm6,%ymm4
.Li261:
vpcmpgtd 0x80(%rsp),%ymm1,%ymm6
.Li262:
vpor %ymm6,%ymm4,%ymm4
.Li263:
vpor %ymm4,%ymm3,%ymm3
.Li264:
vpmovmskb %ymm3,%eax
.Li265:
test %eax,%eax
.Li266:
je .Lloop
.Loutside:
