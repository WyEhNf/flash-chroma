import sys,re,json,collections
from pathlib import Path
sys.path.insert(0,'scripts')
from inspect_skylake_avx2 import functions,loops
sys.setrecursionlimit(10000)
root=Path.cwd();out=Path(__file__).resolve().parent;source=root/'artifacts/skylake-packed-store-static-v1';records={}
for role in ('reference','candidate'):
 fs=functions((source/(role+'.asm')).read_text());found={};attempts=0
 for f in fs:
  if '::avx2_chain_cached(' not in f['function']:continue
  ins=f['instructions'];by={x[0]:x for x in ins};callees={g['instructions'][0][0]:g for g in fs if g['instructions']};nexts={a[0]:b[0] for a,b in zip(ins,ins[1:])}
  starts={int(m[1],16) for address,op,operands in ins if op.startswith('j') for m in [re.match(r'([0-9a-f]+)\s+<',operands)] if m and int(m[1],16)<address}
  def walk(start,at,path,seen,gathers):
   global attempts
   attempts+=1
   if attempts>2000000:raise ValueError('静态路径枚举预算超限，不自动扩大')
   if at==start and path:
    if gathers==15:
     key=tuple(sorted(seen));found.setdefault(key,path)
    return
   if at not in by or at in seen or len(path)>700 or gathers>15:return
   address,op,operands=by[at]
   if op.startswith('ret'):return
   extra=0
   if op.startswith('call'):
    cm=re.match(r'([0-9a-f]+)',operands);cf=callees.get(int(cm[1],16)) if cm else None
    if not cf or any(q.startswith(('j','call')) for _,q,_ in cf['instructions']):return
    extra=sum(q.startswith('vpgather') for _,q,_ in cf['instructions'])
   ng=gathers+op.startswith('vpgather')+extra;branches=[]
   if op.startswith('j'):
    m=re.match(r'([0-9a-f]+)\s+<',operands)
    if m:branches.append(int(m[1],16))
    if op!='jmp' and at in nexts:branches.append(nexts[at])
   elif at in nexts:branches=[nexts[at]]
   for target in branches:walk(start,target,path+[by[at]],seen|{at},ng)
  for start in sorted(starts):walk(start,start,[],set(),0)
 cases=[]
 for i,seq in enumerate(found.values()):
  ops=collections.Counter(x[1] for x in seq);body=['.text','.Lloop:'];expanded=[]
  for _,op,operands in seq:
   if op.startswith('call'):
    cf=callees[int(re.match(r'([0-9a-f]+)',operands)[1],16)];expanded.append({'function':cf['function'],'instructions':len(cf['instructions']),'gathers':sum(q.startswith('vpgather') for _,q,_ in cf['instructions'])})
  for address,op,operands in seq:
   # 轨迹已明确控制流，省略转移但保留等量无条件跳转仅作分离成本说明；不喂给MCA。
   body.append(hex(address)+': '+op+' '+operands)
  (out/(role+'-'+str(i)+'-path.txt')).write_text('\n'.join(body)+'\n',encoding='utf-8')
  cases.append({'first_address':hex(seq[0][0]),'last_address':hex(seq[-1][0]),'instructions':len(seq),'expanded_calls':expanded,'instruction_budget_with_calls':len(seq)+sum(c['instructions'] for c in expanded),'gathers':sum(v for k,v in ops.items() if k.startswith('vpgather')),'rsp_operands':sum('%rsp' in x[2] for x in seq),'branches':sum(x[1].startswith('j') for x in seq),'unconditional_jumps':ops['jmp'],'address_set':[hex(x) for x in sorted(a[0] for a in seq)]})
 records[role]={'unique_simple_cycles_with_15_effective_gathers':cases,'enumeration_steps':attempts}
 print(role,[(x['instructions'],x['gathers'],x['rsp_operands'],x['branches'],x['unconditional_jumps'],x['expanded_calls'],x['instruction_budget_with_calls']) for x in cases], 'steps',attempts)
(out/'results.json').write_text(json.dumps({'purpose':'通用检查拒绝后，枚举CFG的15有效gather简单环；只展开无分支无嵌套调用的内部transform；无源码重编译、无像素或性能调用','variants':records,'limits':{'max_steps':2000000,'max_path_instructions':700},'scope':'只按控制流图枚举，不证明数据谓词可达或动态耗时；路径不连续不能直接使用旧线性区间MCA','native_calls':0,'performance_calls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

import subprocess,hashlib
mca='C:/Program Files/LLVM/bin/llvm-mca.exe';modeled={}
for role in ('reference','candidate'):
 paths=sorted(out.glob(role+'-*-path.txt'))
 if len(paths)!=2:raise ValueError('必须同时覆盖两处全命中循环')
 modeled[role]=[]
 for i,path in enumerate(paths):
  seq=[]
  for line in path.read_text().splitlines():
   match=re.match(r'^(0x[0-9a-f]+): ([^ ]+)(?: (.*))?$',line)
   if match:seq.append((int(match[1],16),match[2],match[3] or ''))
  addresses={x[0] for x in seq};body=['.text','.Lloop:']
  for k,(at,op,operands) in enumerate(seq):
   body.append('.Li'+str(k)+':')
   if op.startswith('j'):
    match=re.match(r'([0-9a-f]+)',operands);target=int(match[1],16)
    if target==seq[0][0]:label='.Lloop'
    elif target in addresses:
     if k+1>=len(seq) or target!=seq[k+1][0]:raise ValueError('内部边不是当前轨迹的下一指令')
     label='.Li'+str(k+1)
    else:label='.Loutside'
    body.append(op+' '+label)
   else:body.append(op+' '+operands.split('#')[0].strip())
  body.append('.Loutside:');asm=out/(role+'-'+str(i)+'-mca.s');asm.write_text('\n'.join(body)+'\n',encoding='ascii')
  command=[mca,'-mcpu=skylake','-iterations=100','-resource-pressure',str(asm)];proc=subprocess.run(command,capture_output=True)
  (out/(role+'-'+str(i)+'-mca.stdout.log')).write_bytes(proc.stdout);(out/(role+'-'+str(i)+'-mca.stderr.log')).write_bytes(proc.stderr)
  if proc.returncode:raise ValueError('MCA解析拒绝，保留原始日志')
  text=proc.stdout.decode();metrics={key:float(re.search(r'^'+re.escape(key)+r':\s*([0-9.]+)',text,re.M)[1]) for key in ('Total Cycles','Total uOps','Block RThroughput')}
  modeled[role].append({'path_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'instructions':len(seq),'command':command,'mca':metrics})
  print('MCA',role,i,len(seq),metrics)
(out/'mca-results.json').write_text(json.dumps({'purpose':'完整CFG的全部两处命中路径MCA；保留新增无条件回跳，不剔除或择优','variants':modeled,'source_controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mca_sha256':hashlib.sha256(Path(mca).read_bytes()).hexdigest(),'native_calls':0,'performance_calls':0,'scope':'静态模型不包含真实缓存/GDS/分支预测或系统噪声，不代表Skylake实测'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
