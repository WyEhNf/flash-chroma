.text
.Lloop:
.Li0:
vmovdqu (%r11),%xmm1
.Li1:
vmovq 0x10(%r11),%xmm0
.Li2:
vmovdqa %ymm14,%ymm4
.Li3:
vmovdqa %ymm14,%ymm7
.Li4:
mov (%r10),%rax
.Li5:
mov 0x54(%r10),%ecx
.Li6:
vmovdqa %ymm14,%ymm11
.Li7:
vmovdqa %ymm14,%ymm10
.Li8:
vpalignr $0xc,%xmm1,%xmm0,%xmm0
.Li9:
mov 0x50(%r10),%edx
.Li10:
vmovdqa %ymm14,%ymm12
.Li11:
vinserti128 $0x1,%xmm0,%ymm1,%ymm1
.Li12:
vmovd %ecx,%xmm13
.Li13:
vpshufb 0x100(%rsp),%ymm1,%ymm1
.Li14:
vpbroadcastd %xmm13,%ymm13
.Li15:
vpsrld $0x10,%ymm1,%ymm3
.Li16:
vpsrld $0x8,%ymm1,%ymm6
.Li17:
vpand %ymm15,%ymm1,%ymm1
.Li18:
vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm5
.Li19:
mov 0x8(%r10),%rax
.Li20:
vpand %ymm15,%ymm6,%ymm6
.Li21:
vmovdqa %ymm14,%ymm4
.Li22:
vpsrld $0x11,%ymm5,%ymm8
.Li23:
vpand 0x20(%rip),%ymm5,%ymm5
.Li24:
vpgatherdd %ymm7,(%rax,%ymm6,4),%ymm2
.Li25:
mov 0x10(%r10),%rax
.Li26:
vpsrld $0x11,%ymm2,%ymm7
.Li27:
vpand 0x20(%rip),%ymm2,%ymm2
.Li28:
vpgatherdd %ymm4,(%rax,%ymm3,4),%ymm0
.Li29:
vpmulld %ymm13,%ymm7,%ymm7
.Li30:
vmovd %edx,%xmm4
.Li31:
mov 0x48(%r10),%rax
.Li32:
vpbroadcastd %xmm4,%ymm4
.Li33:
vpsrld $0x11,%ymm0,%ymm9
.Li34:
lea 0x1(%rcx,%rdx,1),%edx
.Li35:
vpmulld %ymm4,%ymm8,%ymm8
.Li36:
vpand 0x20(%rip),%ymm0,%ymm0
.Li37:
vpaddd %ymm8,%ymm7,%ymm7
.Li38:
vpaddd %ymm9,%ymm7,%ymm9
.Li39:
vpgatherdd %ymm11,(%rax,%ymm9,4),%ymm7
.Li40:
vmovdqu %ymm7,0x160(%rsp)
.Li41:
vmovd %edx,%xmm7
.Li42:
mov 0x18(%r10),%rdx
.Li43:
vpbroadcastd %xmm7,%ymm7
.Li44:
vpaddd %ymm9,%ymm7,%ymm8
.Li45:
vpminsd %ymm2,%ymm5,%ymm7
.Li46:
vpgatherdd %ymm10,(%rax,%ymm8,4),%ymm11
.Li47:
vmovdqu %ymm11,0x1a0(%rsp)
.Li48:
vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm11
.Li49:
mov 0x20(%r10),%rdx
.Li50:
vmovdqa %ymm14,%ymm1
.Li51:
vpgatherdd %ymm1,(%rdx,%ymm6,4),%ymm10
.Li52:
mov 0x28(%r10),%rdx
.Li53:
vmovdqa %ymm14,%ymm6
.Li54:
vpgatherdd %ymm6,(%rdx,%ymm3,4),%ymm12
.Li55:
vpcmpgtd %ymm5,%ymm2,%ymm3
.Li56:
vpmaxsd %ymm2,%ymm5,%ymm6
.Li57:
vmovdqu %ymm13,0x20(%rsp)
.Li58:
vpcmpgtd %ymm6,%ymm0,%ymm1
.Li59:
vpmaxsd %ymm0,%ymm6,%ymm6
.Li60:
vmovdqu %ymm9,0x140(%rsp)
.Li61:
vpminsd %ymm0,%ymm7,%ymm13
.Li62:
vmovdqu %ymm6,0x200(%rsp)
.Li63:
vmovdqa %ymm14,%ymm6
.Li64:
vpcmpgtd %ymm0,%ymm7,%ymm7
.Li65:
vpblendvb %ymm3,0x20(%rsp),%ymm4,%ymm3
.Li66:
vpblendvb %ymm1,-0x1(%rip),%ymm3,%ymm3
.Li67:
vpaddd %ymm9,%ymm3,%ymm3
.Li68:
vpaddd %ymm2,%ymm5,%ymm9
.Li69:
vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm1
.Li70:
vpcmpgtd %ymm2,%ymm5,%ymm3
.Li71:
vmovdqu %ymm8,0x180(%rsp)
.Li72:
vmovdqa %ymm14,%ymm6
.Li73:
vpand %ymm15,%ymm1,%ymm1
.Li74:
vpblendvb %ymm3,0x20(%rsp),%ymm4,%ymm3
.Li75:
vpblendvb %ymm7,-0x1(%rip),%ymm3,%ymm3
.Li76:
vpsubd %ymm3,%ymm8,%ymm3
.Li77:
vmovdqa %ymm13,%ymm8
.Li78:
vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm7
.Li79:
vmovdqu %ymm13,0x1c0(%rsp)
.Li80:
vmovdqu 0x200(%rsp),%ymm13
.Li81:
vpand 0x160(%rsp),%ymm15,%ymm6
.Li82:
vpand %ymm15,%ymm7,%ymm7
.Li83:
vpaddd %ymm13,%ymm8,%ymm8
.Li84:
vpslld $0x10,%ymm6,%ymm3
.Li85:
vpsubd %ymm8,%ymm0,%ymm8
.Li86:
vpaddd 0x1e0(%rsp),%ymm3,%ymm3
.Li87:
vpaddd %ymm9,%ymm8,%ymm9
.Li88:
vpsubd %ymm1,%ymm7,%ymm8
.Li89:
vpmulld %ymm8,%ymm9,%ymm8
.Li90:
vpsubd %ymm6,%ymm1,%ymm1
.Li91:
vpmulld %ymm13,%ymm1,%ymm1
.Li92:
vpsrad $0x10,%ymm11,%ymm6
.Li93:
vmovdqa %ymm14,%ymm13
.Li94:
vpaddd %ymm5,%ymm6,%ymm6
.Li95:
vpaddd %ymm3,%ymm8,%ymm3
.Li96:
vpand 0x1a0(%rsp),%ymm15,%ymm8
.Li97:
vpsubd %ymm7,%ymm8,%ymm8
.Li98:
vpmulld 0x1c0(%rsp),%ymm8,%ymm8
.Li99:
vpaddd %ymm1,%ymm8,%ymm8
.Li100:
vpaddd %ymm8,%ymm3,%ymm3
.Li101:
vpsrld $0x10,%ymm3,%ymm7
.Li102:
vpslld $0x10,%ymm12,%ymm3
.Li103:
vmovdqu %ymm7,0x1c0(%rsp)
.Li104:
vpsrad $0x10,%ymm10,%ymm7
.Li105:
vpsrad $0x10,%ymm3,%ymm3
.Li106:
vpaddd %ymm2,%ymm7,%ymm7
.Li107:
vpaddd %ymm0,%ymm3,%ymm3
.Li108:
vpaddd %ymm7,%ymm6,%ymm1
.Li109:
vmovdqu %ymm1,0x200(%rsp)
.Li110:
vpsrad $0x10,%ymm12,%ymm1
.Li111:
vpaddd %ymm0,%ymm1,%ymm1
.Li112:
vpslld $0x10,%ymm10,%ymm0
.Li113:
vpsrad $0x10,%ymm0,%ymm0
.Li114:
vpaddd %ymm2,%ymm0,%ymm0
.Li115:
vpslld $0x10,%ymm11,%ymm2
.Li116:
vpsrad $0x10,%ymm2,%ymm2
.Li117:
vpaddd %ymm0,%ymm3,%ymm10
.Li118:
vpaddd %ymm5,%ymm2,%ymm2
.Li119:
vpmaxsd %ymm0,%ymm2,%ymm8
.Li120:
vpcmpgtd %ymm2,%ymm0,%ymm11
.Li121:
vpminsd %ymm0,%ymm2,%ymm12
.Li122:
vpcmpgtd %ymm8,%ymm3,%ymm5
.Li123:
vpcmpgtd %ymm0,%ymm2,%ymm0
.Li124:
vpminsd %ymm3,%ymm12,%ymm9
.Li125:
vpcmpgtd %ymm3,%ymm12,%ymm12
.Li126:
vpmaxsd %ymm3,%ymm8,%ymm8
.Li127:
vmovdqu 0x180(%rsp),%ymm3
.Li128:
vpblendvb %ymm11,0x20(%rsp),%ymm4,%ymm11
.Li129:
vpblendvb %ymm5,-0x1(%rip),%ymm11,%ymm11
.Li130:
vpblendvb %ymm0,0x20(%rsp),%ymm4,%ymm0
.Li131:
vpaddd 0x140(%rsp),%ymm11,%ymm11
.Li132:
vpblendvb %ymm12,-0x1(%rip),%ymm0,%ymm0
.Li133:
vpsubd %ymm0,%ymm3,%ymm0
.Li134:
vpgatherdd %ymm13,(%rax,%ymm11,4),%ymm5
.Li135:
vmovdqa %ymm14,%ymm13
.Li136:
vpgatherdd %ymm13,(%rax,%ymm0,4),%ymm11
.Li137:
vmovdqu 0x160(%rsp),%ymm0
.Li138:
vpsrld $0x8,%ymm5,%ymm5
.Li139:
vpaddd %ymm9,%ymm8,%ymm13
.Li140:
vpsrld $0x8,%ymm11,%ymm11
.Li141:
vpand %ymm15,%ymm5,%ymm5
.Li142:
vpsubd %ymm13,%ymm2,%ymm2
.Li143:
vpsrld $0x8,%ymm0,%ymm12
.Li144:
vmovdqu 0x1a0(%rsp),%ymm0
.Li145:
vpand %ymm15,%ymm11,%ymm11
.Li146:
vpaddd %ymm10,%ymm2,%ymm2
.Li147:
vpand %ymm15,%ymm12,%ymm12
.Li148:
vpsubd %ymm5,%ymm11,%ymm10
.Li149:
vmovdqu 0x1e0(%rsp),%ymm13
.Li150:
vpsrld $0x8,%ymm0,%ymm3
.Li151:
vpmulld %ymm10,%ymm2,%ymm10
.Li152:
vpsubd %ymm12,%ymm5,%ymm5
.Li153:
vpmulld %ymm8,%ymm5,%ymm5
.Li154:
vpand %ymm15,%ymm3,%ymm3
.Li155:
vpminsd %ymm7,%ymm6,%ymm8
.Li156:
vpsubd %ymm11,%ymm3,%ymm3
.Li157:
vpslld $0x10,%ymm12,%ymm0
.Li158:
vmovdqu 0x20(%rsp),%ymm11
.Li159:
vmovdqa %ymm14,%ymm12
.Li160:
vpmulld %ymm9,%ymm3,%ymm3
.Li161:
vpaddd %ymm13,%ymm0,%ymm0
.Li162:
vpminsd %ymm1,%ymm8,%ymm9
.Li163:
vpcmpgtd %ymm1,%ymm8,%ymm8
.Li164:
vpaddd %ymm0,%ymm10,%ymm0
.Li165:
vpaddd %ymm5,%ymm3,%ymm3
.Li166:
vpmaxsd %ymm7,%ymm6,%ymm5
.Li167:
vpaddd %ymm3,%ymm0,%ymm0
.Li168:
vpcmpgtd %ymm6,%ymm7,%ymm3
.Li169:
vpcmpgtd %ymm5,%ymm1,%ymm2
.Li170:
vpcmpgtd %ymm7,%ymm6,%ymm6
.Li171:
vpmaxsd %ymm1,%ymm5,%ymm5
.Li172:
vpsrld $0x10,%ymm0,%ymm0
.Li173:
vpblendvb %ymm3,%ymm11,%ymm4,%ymm3
.Li174:
vpblendvb %ymm2,-0x1(%rip),%ymm3,%ymm3
.Li175:
vpblendvb %ymm6,%ymm11,%ymm4,%ymm4
.Li176:
vmovdqu 0x1a0(%rsp),%ymm11
.Li177:
vpaddd 0x140(%rsp),%ymm3,%ymm3
.Li178:
vpblendvb %ymm8,-0x1(%rip),%ymm4,%ymm4
.Li179:
vpaddd %ymm9,%ymm5,%ymm8
.Li180:
vpsubd %ymm8,%ymm1,%ymm1
.Li181:
vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm2
.Li182:
vmovdqu 0x180(%rsp),%ymm3
.Li183:
vmovdqa %ymm14,%ymm12
.Li184:
vpaddd 0x200(%rsp),%ymm1,%ymm1
.Li185:
vpsrld $0x10,%ymm2,%ymm2
.Li186:
vpsubd %ymm4,%ymm3,%ymm3
.Li187:
vmovdqu 0x160(%rsp),%ymm4
.Li188:
vpand %ymm15,%ymm2,%ymm2
.Li189:
vpgatherdd %ymm12,(%rax,%ymm3,4),%ymm6
.Li190:
vpsrld $0x10,%ymm11,%ymm3
.Li191:
vmovdqu 0xc0(%rsp),%ymm12
.Li192:
vmovdqu 0x80(%rsp),%ymm11
.Li193:
vpsrld $0x10,%ymm4,%ymm4
.Li194:
vpsrld $0x10,%ymm6,%ymm6
.Li195:
vpand %ymm15,%ymm3,%ymm3
.Li196:
vpand %ymm15,%ymm4,%ymm4
.Li197:
vpand %ymm15,%ymm6,%ymm6
.Li198:
vpsubd %ymm2,%ymm6,%ymm8
.Li199:
vpsubd %ymm6,%ymm3,%ymm3
.Li200:
vpslld $0x10,%ymm4,%ymm7
.Li201:
vpsubd %ymm4,%ymm2,%ymm2
.Li202:
vpmulld %ymm8,%ymm1,%ymm1
.Li203:
vpaddd %ymm13,%ymm7,%ymm7
.Li204:
vmovdqu 0x40(%rsp),%ymm13
.Li205:
vpmulld %ymm5,%ymm2,%ymm2
.Li206:
vpmulld %ymm9,%ymm3,%ymm3
.Li207:
vpaddd %ymm7,%ymm1,%ymm1
.Li208:
vmovdqu 0x1c0(%rsp),%ymm7
.Li209:
vpaddd %ymm2,%ymm3,%ymm3
.Li210:
vpaddd %ymm3,%ymm1,%ymm1
.Li211:
vpsubd %ymm7,%ymm0,%ymm3
.Li212:
vpcmpgtd 0x60(%rsp),%ymm7,%ymm6
.Li213:
vpsrld $0x10,%ymm1,%ymm1
.Li214:
vpcmpgtd %ymm3,%ymm11,%ymm2
.Li215:
vpsubd %ymm7,%ymm1,%ymm4
.Li216:
vpcmpgtd %ymm4,%ymm12,%ymm5
.Li217:
vpor %ymm5,%ymm2,%ymm2
.Li218:
vpcmpgtd 0xe0(%rsp),%ymm4,%ymm5
.Li219:
vpor %ymm5,%ymm2,%ymm2
.Li220:
vpcmpgtd %ymm7,%ymm13,%ymm5
.Li221:
vpor %ymm6,%ymm5,%ymm5
.Li222:
vpcmpgtd 0xa0(%rsp),%ymm3,%ymm6
.Li223:
vpor %ymm6,%ymm5,%ymm5
.Li224:
vpor %ymm5,%ymm2,%ymm2
.Li225:
vpmovmskb %ymm2,%eax
.Li226:
test %eax,%eax
.Li227:
jne .Loutside
.Li228:
mov 0x24(%rdi),%eax
.Li229:
mov 0x20(%rdi),%edx
.Li230:
vpsubd %ymm11,%ymm3,%ymm0
.Li231:
vpsubd %ymm12,%ymm4,%ymm4
.Li232:
imul %eax,%edx
.Li233:
vmovd %eax,%xmm1
.Li234:
mov (%rdi),%rax
.Li235:
vpbroadcastd %xmm1,%ymm1
.Li236:
vpmulld %ymm1,%ymm0,%ymm0
.Li237:
vpsubd %ymm13,%ymm7,%ymm1
.Li238:
vmovd %edx,%xmm2
.Li239:
vpbroadcastd %xmm2,%ymm2
.Li240:
vpmulld %ymm2,%ymm1,%ymm1
.Li241:
vpaddd %ymm1,%ymm0,%ymm0
.Li242:
vpaddd %ymm4,%ymm0,%ymm0
.Li243:
vmovdqa %ymm14,%ymm4
.Li244:
vpgatherdd %ymm4,(%rax,%ymm0,4),%ymm1
.Li245:
vpshufb 0x120(%rsp),%ymm1,%ymm0
.Li246:
vmovdqa %xmm0,%xmm2
.Li247:
vextracti128 $0x1,%ymm0,%xmm0
.Li248:
vpslldq $0xc,%xmm0,%xmm1
.Li249:
vpsrldq $0x4,%xmm0,%xmm0
.Li250:
vpor %xmm2,%xmm1,%xmm1
.Li251:
vmovq %xmm0,0x10(%r11)
.Li252:
vmovdqu %xmm1,(%r11)
.Li253:
cmp %rbp,%rsi
.Li254:
je .Loutside
.Li255:
inc %rbp
.Li256:
add $0x18,%r11
.Li257:
jmp .Lloop
.Loutside:
