import subprocess,os,json,sys
from pathlib import Path
ROOT=Path.cwd();here=Path(__file__).resolve().parent;plan='experiments/skylake-packed-store-v1.json';build='artifacts/skylake-packed-store-build-v1'
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OMP_DYNAMIC='FALSE',OMP_PROC_BIND='FALSE',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
base='artifacts/skylake-packed-store-contract-v1';layout='artifacts/skylake-packed-store-layout-contract-v1'
cache='artifacts/skylake-packed-store-cache-contract-v1';combo='artifacts/skylake-packed-store-interaction-v1';full='artifacts/skylake-packed-store-full-v1'
common=['--plan',plan,'--build',build]
commands=[['scripts/verify_skylake_packed.py',*common,'--output',base],
 ['scripts/verify_skylake_delta16.py',*common,'--contract',base+'/results.json','--output',layout],
 ['scripts/verify_skylake_suffix_cache.py',*common,'--contract',base+'/results.json','--output',cache],
 ['scripts/verify_skylake_delta_cache.py',*common,'--contract',base+'/results.json','--cache-contract',cache+'/results.json','--layout-contract',layout+'/results.json','--output',combo],
 ['scripts/accept_skylake_runtime.py',*common,'--contract',base+'/results.json','--cache-contract',combo+'/results.json','--layout-contract',layout+'/results.json','--output',full]]
for index,args in enumerate(commands):
 command=[sys.executable,'-X','utf8',*args]
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (here/f'validation{index}.stdout.log').write_text(result.stdout,encoding='utf-8')
 (here/f'validation{index}.stderr.log').write_text(result.stderr,encoding='utf-8')
 (here/f'validation{index}.command.json').write_text(json.dumps({'command':command,'returncode':result.returncode},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(index,result.returncode,result.stdout[-1500:],flush=True)
 if result.returncode:raise RuntimeError(result.stderr)
