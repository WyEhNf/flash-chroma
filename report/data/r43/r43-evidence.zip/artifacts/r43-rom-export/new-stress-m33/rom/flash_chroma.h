/* Generated ROM model. Keep portable-model.json as host-side provenance. */
#ifndef FLASH_CHROMA_PORTABLE_MODEL_H
#define FLASH_CHROMA_PORTABLE_MODEL_H
#include "jshc_portable.h"
#if JSHC_P_ABI_VERSION != 1u
#error "This ROM bundle requires portable ABI 1"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern const uint8_t flash_chroma_stage1[112063];
extern const uint8_t flash_chroma_stage2[112063];
extern const uint8_t flash_chroma_stage3[112063];
extern const uint8_t flash_chroma_stage4[112063];
extern const uint8_t *const flash_chroma_blobs[JSHC_P_STAGES];
extern const size_t flash_chroma_blob_bytes[JSHC_P_STAGES];
/* Caller owns models/chain and keeps them alive. Preparation may initialize a
 * prefix of models before reporting an error; it never modifies ROM bytes. */
jshc_p_status flash_chroma_prepare(jshc_p_model models[JSHC_P_STAGES],
                             jshc_p_chain *chain, uint32_t options);
#ifdef __cplusplus
}
#endif
#endif
