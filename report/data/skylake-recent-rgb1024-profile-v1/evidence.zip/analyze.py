"""固定1024项精确输入色备忘的唯一离线筛查；不执行候选、编译或性能计时。"""
from __future__ import annotations
import datetime
import hashlib
import json
import os
import platform
import sys
import traceback
from collections import Counter
from pathlib import Path

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SLOTS = 1024
BLOCK_PIXELS = 65536
HASH_MULTIPLIER = 0x9e3779b1
HASH_SHIFT = 22
IMAGES = 100
PIXELS_PER_IMAGE = 1024 * 768
LONG_RUN_LENGTHS = (8, 16, 32, 64, 128, 256, 1024)
GATE = dict(total_hit_fraction_min=0.65, any_image_hit_fraction_min=0.35,
            block_internal_transition_fraction_max=0.02)
FLAGS = ('hit', 'cold', 'collision', 'repeat_collision', 'first_seen_collision')


def digest(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(name, value):
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def classify_codes(codes, block_ids):
    """按块/槽稳定排序恢复真实最后tag；不查模型或大输出表。"""
    assert codes.dtype == np.uint32 and block_ids.dtype == np.uint32
    assert codes.shape == block_ids.shape and codes.ndim == 1
    assert len(codes) and int(codes.max()) <= 0xffffff
    assert np.all(block_ids[1:] >= block_ids[:-1])
    slot = np.multiply(codes, np.uint32(HASH_MULTIPLIER), dtype=np.uint32) >> np.uint32(HASH_SHIFT)
    assert int(slot.max()) < SLOTS
    key = (block_ids << np.uint32(10)) | slot
    order = np.argsort(key, kind='stable')
    sorted_key, sorted_codes = key[order], codes[order]
    same_slot = np.zeros(len(codes), dtype=bool)
    same_slot[1:] = sorted_key[1:] == sorted_key[:-1]
    same_code = np.zeros(len(codes), dtype=bool)
    same_code[1:] = sorted_codes[1:] == sorted_codes[:-1]
    result = {}
    for name, sorted_flags in (('hit', same_slot & same_code), ('cold', ~same_slot),
                               ('collision', same_slot & ~same_code)):
        values = np.empty(len(codes), dtype=bool)
        values[order] = sorted_flags
        result[name] = values
    # 第二个固定排序只判断同一完整输入在本块是否曾出现，不能混为tag命中。
    color_key = (block_ids.astype(np.uint64) << np.uint64(24)) | codes.astype(np.uint64)
    color_order = np.argsort(color_key, kind='stable')
    sorted_colors = color_key[color_order]
    duplicate_sorted = np.zeros(len(codes), dtype=bool)
    duplicate_sorted[1:] = sorted_colors[1:] == sorted_colors[:-1]
    seen_before = np.empty(len(codes), dtype=bool)
    seen_before[color_order] = duplicate_sorted
    result['repeat_collision'] = result['collision'] & seen_before
    result['first_seen_collision'] = result['collision'] & ~seen_before
    assert np.all(result['hit'] | result['cold'] | result['collision'])
    assert not np.any((result['hit'] & result['cold']) | (result['hit'] & result['collision']) | (result['cold'] & result['collision']))
    assert np.array_equal(seen_before, result['hit'] | result['repeat_collision'])
    return result


def reference_cache(codes, block_ids):
    """小合成序列用标准库真实direct-cache逐访问对照，不用于大照片。"""
    result = {name: [] for name in FLAGS}
    previous_block = None
    tags, seen = [], set()
    for code, block in zip(codes, block_ids):
        code, block = int(code), int(block)
        if block != previous_block:
            tags, seen = [None] * SLOTS, set()
            previous_block = block
        slot = ((code * HASH_MULTIPLIER) & 0xffffffff) >> HASH_SHIFT
        cold = tags[slot] is None
        hit = not cold and tags[slot] == code
        collision = not cold and not hit
        result['hit'].append(hit)
        result['cold'].append(cold)
        result['collision'].append(collision)
        result['repeat_collision'].append(collision and code in seen)
        result['first_seen_collision'].append(collision and code not in seen)
        tags[slot] = code
        seen.add(code)
    return result


def run_histogram(hit):
    changes = np.flatnonzero(hit[1:] != hit[:-1]) + 1
    starts = np.concatenate((np.array([0], dtype=np.intp), changes))
    ends = np.concatenate((changes, np.array([len(hit)], dtype=np.intp)))
    lengths = ends - starts
    counters = []
    for desired in (True, False):
        values, counts = np.unique(lengths[hit[starts] == desired], return_counts=True)
        counters.append(Counter({int(length): int(count) for length, count in zip(values, counts)}))
    assert sum(sum(counter.values()) for counter in counters) == len(changes) + 1
    assert sum(length * count for length, count in counters[0].items()) == int(hit.sum())
    assert sum(length * count for length, count in counters[1].items()) == len(hit) - int(hit.sum())
    return int(len(changes)), counters[0], counters[1]


def histogram_summary(counter):
    count = sum(counter.values())
    pixels = sum(length * frequency for length, frequency in counter.items())
    quantiles = {}
    for numerator, denominator, label in ((1, 2, 'p50'), (9, 10, 'p90'), (99, 100, 'p99')):
        rank = (count * numerator + denominator - 1) // denominator
        cumulative, value = 0, 0
        for length, frequency in sorted(counter.items()):
            cumulative += frequency
            if cumulative >= rank:
                value = length
                break
        quantiles[label] = value if count else 0
    return dict(runs=count, pixels=pixels, maximum=max(counter, default=0), nearest_rank=quantiles,
                length_histogram={str(key): value for key, value in sorted(counter.items())},
                runs_at_least={str(bound): sum(value for key, value in counter.items() if key >= bound) for bound in LONG_RUN_LENGTHS})


def self_test():
    # 只生成小合成fixture的碰撞码，不扫描照片，也不选择缓存参数。
    groups = {}
    colliders = None
    for code in range(4096):
        slot = ((code * HASH_MULTIPLIER) & 0xffffffff) >> HASH_SHIFT
        group = groups.setdefault(slot, [])
        group.append(code)
        if len(group) == 3:
            colliders = group[:]
            break
    assert colliders is not None
    a, b, c = colliders
    cases = [
        ('unique', list(range(24)), [0] * 24),
        ('same', [0xffffff] * 24, [0] * 24),
        ('alternating_collision', [a, b] * 12, [0] * 24),
        ('clustered_collision', [a] * 6 + [b] * 6 + [a] * 6 + [c] * 6, [0] * 24),
        ('explicit_reset_labels', [a, a, b, a, b, b, a, a] * 3, [0] * 8 + [1] * 8 + [2] * 8),
        ('rgb_boundaries_and_wrap', [0, 0xffffff, 0xff0000, 0x00ff00, 0x0000ff, 0x800000, 0x010101, 0x010101] * 3, [0] * 16 + [1] * 8),
    ]
    rows = []
    for name, values, labels in cases:
        expected = reference_cache(values, labels)
        actual = classify_codes(np.array(values, dtype=np.uint32), np.array(labels, dtype=np.uint32))
        for flag in FLAGS:
            assert actual[flag].tolist() == expected[flag], (name, flag)
        # 独立标准库run循环对照小序列的NumPy长run统计，不能跨块拼run。
        expected_runs, previous_label = [Counter(), Counter()], None
        current_hit, current_length = None, 0
        for hit, label in zip(expected['hit'], labels):
            if label != previous_label or hit != current_hit:
                if current_length:
                    expected_runs[0 if current_hit else 1][current_length] += 1
                current_hit, current_length = hit, 1
            else:
                current_length += 1
            previous_label = label
        expected_runs[0 if current_hit else 1][current_length] += 1
        actual_runs = [Counter(), Counter()]
        for label in sorted(set(labels)):
            _, hit_runs, miss_runs = run_histogram(actual['hit'][np.array(labels) == label])
            actual_runs[0].update(hit_runs)
            actual_runs[1].update(miss_runs)
        assert actual_runs == expected_runs, name
        rows.append(dict(case=name, pixels=len(values), explicit_synthetic_blocks=len(set(labels)),
                         flags_equal=True, run_histograms_equal=True,
                         counts={flag: sum(expected[flag]) for flag in FLAGS}))
    return dict(passed=True, cases=rows, collision_fixture=colliders,
                scope='仅小合成序列；显式小块标签验证重置，不改变照片固定65536像素块')


def analyze(protocol):
    assert protocol['script_sha256'] == digest(__file__)
    assert protocol['gate'] == GATE
    assert protocol['cache']['entries'] == SLOTS and protocol['cache']['entry_bytes'] == 8
    assert protocol['cache']['hash_multiplier'] == HASH_MULTIPLIER and protocol['cache']['hash_shift'] == HASH_SHIFT
    assert protocol['cache']['reset_pixels'] == BLOCK_PIXELS
    assert protocol['attempt_policy']['maximum_analysis_executions'] == 1
    small_test = self_test()
    for spec in protocol['inputs'].values():
        path = ROOT / spec['path']
        assert path.stat().st_size == spec['bytes'] and digest(path) == spec['sha256']
    manifest = read(ROOT / protocol['inputs']['manifest']['path'])
    assert len(manifest['images']) == IMAGES
    photos = np.memmap(ROOT / protocol['inputs']['photos']['path'], dtype=np.uint8, mode='r',
                       shape=(IMAGES, PIXELS_PER_IMAGE, 3))
    rows, all_blocks = [], []
    global_counts = Counter()
    global_transitions = Counter()
    global_hit_runs, global_miss_runs = Counter(), Counter()
    blocks_per_image = PIXELS_PER_IMAGE // BLOCK_PIXELS
    assert blocks_per_image == 12 and PIXELS_PER_IMAGE % BLOCK_PIXELS == 0
    block_ids = np.arange(PIXELS_PER_IMAGE, dtype=np.uint32) >> np.uint32(16)
    for image_index, pixels in enumerate(photos):
        metadata = manifest['images'][image_index]
        input_sha = hashlib.sha256(pixels).hexdigest()
        assert input_sha == metadata['evaluation']['pixel_sha256']
        assert metadata['evaluation']['size'] == [1024, 768] and metadata['evaluation']['mode'] == 'RGB'
        wide = pixels.astype(np.uint32)
        codes = wide[:, 0] | (wide[:, 1] << np.uint32(8)) | (wide[:, 2] << np.uint32(16))
        flags = classify_codes(codes, block_ids)
        block_rows, counts = [], Counter()
        transition_histogram, hit_runs, miss_runs = Counter(), Counter(), Counter()
        for block_index in range(blocks_per_image):
            first = block_index * BLOCK_PIXELS
            last = first + BLOCK_PIXELS
            local = {flag: flags[flag][first:last] for flag in FLAGS}
            block_counts = {flag: int(local[flag].sum()) for flag in FLAGS}
            assert block_counts['hit'] + block_counts['cold'] + block_counts['collision'] == BLOCK_PIXELS
            assert block_counts['collision'] == block_counts['repeat_collision'] + block_counts['first_seen_collision']
            transitions, hit_histogram, miss_histogram = run_histogram(local['hit'])
            transition_histogram[transitions] += 1
            hit_runs.update(hit_histogram)
            miss_runs.update(miss_histogram)
            block = dict(image_index=image_index, block_index=block_index, first_pixel=first,
                pixels=BLOCK_PIXELS, hits=block_counts['hit'], misses=BLOCK_PIXELS - block_counts['hit'],
                cold=block_counts['cold'], collision=block_counts['collision'],
                repeat_collision=block_counts['repeat_collision'], first_seen_collision=block_counts['first_seen_collision'],
                hit_fraction=block_counts['hit'] / BLOCK_PIXELS, transition_count=transitions,
                transition_edges=BLOCK_PIXELS - 1, transition_fraction=transitions / (BLOCK_PIXELS - 1),
                longest_hit_run=max(hit_histogram, default=0), longest_miss_run=max(miss_histogram, default=0),
                hit_runs=sum(hit_histogram.values()), miss_runs=sum(miss_histogram.values()))
            block_rows.append(block)
            all_blocks.append(block)
            counts.update(block_counts)
        transitions = sum(key * value for key, value in transition_histogram.items())
        edges = blocks_per_image * (BLOCK_PIXELS - 1)
        assert hit_runs.total() + miss_runs.total() == transitions + blocks_per_image
        row = dict(image_index=image_index, image_id=metadata['id'], input_sha256=input_sha,
            pixels=PIXELS_PER_IMAGE, blocks=blocks_per_image, hits=counts['hit'],
            misses=PIXELS_PER_IMAGE - counts['hit'], cold=counts['cold'], collision=counts['collision'],
            repeat_collision=counts['repeat_collision'], first_seen_collision=counts['first_seen_collision'],
            hit_fraction=counts['hit'] / PIXELS_PER_IMAGE, transition_count=transitions,
            transition_edges=edges, transition_fraction=transitions / edges,
            block_transition_count_histogram={str(key): value for key, value in sorted(transition_histogram.items())},
            hit_runs=histogram_summary(hit_runs), miss_runs=histogram_summary(miss_runs), per_block=block_rows)
        rows.append(row)
        global_counts.update(counts)
        global_transitions.update(transition_histogram)
        global_hit_runs.update(hit_runs)
        global_miss_runs.update(miss_runs)
    pixels_total = IMAGES * PIXELS_PER_IMAGE
    edges_total = IMAGES * blocks_per_image * (BLOCK_PIXELS - 1)
    transition_count = sum(key * value for key, value in global_transitions.items())
    assert sum(global_transitions.values()) == len(all_blocks) == 1200
    assert global_counts['hit'] + global_counts['cold'] + global_counts['collision'] == pixels_total
    assert global_hit_runs.total() + global_miss_runs.total() == transition_count + len(all_blocks)
    total_hit_fraction = global_counts['hit'] / pixels_total
    transition_fraction = transition_count / edges_total
    worst_image = min(rows, key=lambda row: row['hit_fraction'])
    gate = dict(total_hit_fraction=total_hit_fraction, total_hit_fraction_min=GATE['total_hit_fraction_min'],
        total_hit_pass=total_hit_fraction >= GATE['total_hit_fraction_min'],
        any_image_hit_fraction=worst_image['hit_fraction'], any_image_hit_fraction_min=GATE['any_image_hit_fraction_min'],
        per_image_pass=worst_image['hit_fraction'] >= GATE['any_image_hit_fraction_min'],
        block_internal_transition_fraction=transition_fraction,
        block_internal_transition_fraction_max=GATE['block_internal_transition_fraction_max'],
        transition_pass=transition_fraction <= GATE['block_internal_transition_fraction_max'])
    gate['passed'] = all(gate[key] for key in ('total_hit_pass', 'per_image_pass', 'transition_pass'))
    result = dict(purpose=__doc__, analysis_completed=True, script_sha256=digest(__file__),
        protocol_sha256=digest(OUT / 'protocol.json'), environment=dict(platform=platform.platform(),
            python=sys.version, executable=sys.executable, machine=platform.machine(), processor=platform.processor(),
            numpy=np.__version__, byteorder=sys.byteorder), inputs=protocol['inputs'], cache=protocol['cache'],
        classification=protocol['classification'], small_synthetic_reference=small_test,
        total=dict(images=IMAGES, pixels=pixels_total, blocks=len(all_blocks), hits=global_counts['hit'],
            misses=pixels_total - global_counts['hit'], cold=global_counts['cold'], collision=global_counts['collision'],
            repeat_collision=global_counts['repeat_collision'], first_seen_collision=global_counts['first_seen_collision'],
            hit_fraction=total_hit_fraction, transition_count=transition_count, transition_edges=edges_total,
            transition_fraction=transition_fraction,
            block_transition_count_histogram={str(key): value for key, value in sorted(global_transitions.items())},
            hit_runs=histogram_summary(global_hit_runs), miss_runs=histogram_summary(global_miss_runs),
            worst_hit_image_index=worst_image['image_index'], worst_hit_image_id=worst_image['image_id'],
            worst_hit_image_fraction=worst_image['hit_fraction'],
            max_image_transition_fraction=max(row['transition_fraction'] for row in rows),
            max_block_transition_fraction=max(row['transition_fraction'] for row in all_blocks)),
        per_image=rows, gate=gate,
        decision='筛查通过，仅允许考虑实现；不是性能预测或精度执行证据' if gate['passed'] else '唯一固定筛查失败；停止，不改门槛、容量、hash或清空窗口重跑',
        limitations=['离线只模拟精确输入tag的历史命中，不执行模型，也不读取或核验缓存RGB值。',
            '同块/槽按原序稳定排序等价最后tag；小合成序列用标准库真实缓存逐访问对照，未对全部照片第二次逐访问循环。',
            '每65536像素块无条件清空；不跨API、块、图记忆；这不是每线程跨块长期cache的统计。',
            '长run及转移均在块内计算，不跨块连接；转移率不是硬件分支错判率。',
            '0.65/0.35/0.02仅决定是否值得继续，不预测20%收益或证明整体三倍目标。',
            '未验证原生载荷/分支/寄存器/初始化成本，未做候选完整RGB8或Skylake实机验证。'],
        native_calls=0, candidate_native_calls=0, performance_calls=0, compiler_calls=0,
        model_calls=0, new_fits=0)
    save('analysis.json', result)
    return result


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    protocol = read(OUT / 'protocol.json')
    assert protocol['script_sha256'] == digest(__file__)
    save('execution-start.json', dict(started_utc=now(), pid=os.getpid(), argv=sys.argv,
        script_sha256=digest(__file__), protocol_sha256=digest(OUT / 'protocol.json'),
        maximum_analysis_executions=1, native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0))
    try:
        result = analyze(protocol)
    except BaseException as error:
        save('failure.json', dict(analysis_completed=False, error_type=type(error).__name__,
             error=str(error), traceback=traceback.format_exc()))
        save('exit.json', dict(ended_utc=now(), exit_code=1, analysis_completed=False,
            failure_sha256=digest(OUT / 'failure.json'), script_sha256=digest(__file__),
            protocol_sha256=digest(OUT / 'protocol.json'), native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0))
        raise
    save('exit.json', dict(ended_utc=now(), exit_code=0, analysis_completed=True,
        gate_passed=result['gate']['passed'], analysis_sha256=digest(OUT / 'analysis.json'),
        script_sha256=digest(__file__), protocol_sha256=digest(OUT / 'protocol.json'),
        native_calls=0, performance_calls=0, compiler_calls=0, model_calls=0))
    print(json.dumps(dict(gate=result['gate'], analysis_sha256=digest(OUT / 'analysis.json'),
                         exit_sha256=digest(OUT / 'exit.json')), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
