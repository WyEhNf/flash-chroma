"""冻结52：从40仅将小调色板读取改为AVX2 gather，大16MiB表仍GPR加载。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-palettegather-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_palettegather').replace('avx2_chain_batchspan','avx2_chain_palettegather')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 52;')
    if p.name=='channel_avx2.cpp':
        a=s.index('inline __attribute__((always_inline)) __m256i read(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        part=s[a:b]
        part=part.replace('return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code]]);','return int32_t(reinterpret_cast<const uint8_t*>(table)[code]);')
        part=part.replace('return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[code&0xffffff]]);','return int32_t(reinterpret_cast<const uint8_t*>(table)[code&0xffffff]);')
        part=part.replace('return _mm256_setr_epi32(', 'const __m256i ids=_mm256_setr_epi32(')
        assert part.count('const __m256i ids=')==2 and 'palette[' not in part
        part=part.replace('\n}', '\n  return _mm256_i32gather_epi32(reinterpret_cast<const int*>(palette),ids,4);\n}')
        s=s[:a]+part+s[b:]
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='52研究两层查表中仅小调色板的AVX2 gather；16MiB字节表继续GPR，精度不变',candidate='从40单独改变palette读取：8个u8 ID先组为向量，再gather RGB32；不叠加50/51输入更改或47/49分块',base_commit='ee529bedec7537da5843080c2f1f07bab4e8e7d6',revisions={'reference':23,'candidate':52},cmake_project='experiments/skylake-palettegather-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_palettegather'])
plan['palettegather_policy']={'format':9,'table_bytes':2**24,'palette_capacity_bytes':1024,'gather_scope':'仅256项RGB32 palette；16MiB ID表保持普通GPR字节加载','choice':'只更改两层查表第二层，避免把整张大表的gather失败直接推及小palette','hypothesis':'少8个标量RGB32 load，增加gather和掩码指令；cache、依赖和GDS缓解影响待测','skylake_limitation':'Intel GDS缓解可能影响gather消费延迟；未修改任何缓解，本机AMD结果不能承诺Skylake同幅收益','source':'https://www.intel.com/content/www/us/en/developer/articles/technical/software-security-guidance/technical-documentation/gather-data-sampling.html','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'on_failure':'停止本版，不重复画像或整轮性能择优','goal_gate_unchanged':True}}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-palettegather-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结52仅小palette gather及同一5%增量筛查，未构建或执行像素')
