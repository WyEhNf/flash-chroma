"""额外逐项比较本阶段两次全量快照，包含新PR51，避免只与上一阶段比较漏掉新增意见。"""
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];before=HERE/'audit-before';after=HERE/'pre-create'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
changes=[]
for filename in ('prs.json','issues.json'):
    old={x['number']:x for x in read(before/filename)['items']};new={x['number']:x for x in read(after/filename)['items']}
    if set(old)!=set(new):changes.append(filename+':记录集合')
    for number in set(old)&set(new):
        for field in ('title','body','state','draft'):
            if old[number].get(field)!=new[number].get(field):changes.append(f'{filename}:{number}:{field}')
        if filename=='prs.json':
            for field in ('head','base'):
                if old[number][field]['sha']!=new[number][field]['sha']:changes.append(f'{filename}:{number}:{field}.sha')
files=sorted({p.name for p in before.glob('*-comments.json')}|{p.name for p in before.glob('*-reviews.json')})
for filename in files:
    if read(before/filename)['items']!=read(after/filename)['items']:changes.append(filename)
if read(before/'graphql.json')!=read(after/'graphql.json'):changes.append('graphql.json')
assert not changes,changes
check=read(after/'check.json');check['refresh_vs_first_snapshot']={'pass':True,'changes':changes,'scope':'两次45PR全部正文/状态/头与base、独立issue、137组REST意见及全部GraphQL；包含新增51'}
for key in ('issues-51-comments.json','pulls-51-reviews.json','pulls-51-comments.json'):assert not read(after/key)['items']
assert not read(after/'graphql.json')['data']['repository']['p51']['reviewThreads']['nodes']
target=ROOT/'report/data/skylake-input-path-v1/pre-create-remote-check.json';target.write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('操作前两快照全量比较通过，包含51的正文/头/全部意见，没有变化')
