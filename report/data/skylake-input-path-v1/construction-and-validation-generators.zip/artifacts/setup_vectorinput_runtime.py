"""冻结50：原40线性布局不变，只以AVX2解包8个RGB24输入再GPR查表。"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1];old=ROOT/'experiments/skylake-batchspan-runtime';out=ROOT/'experiments/skylake-vectorinput-runtime';out.mkdir(exist_ok=False)
for p in old.iterdir():
    s=p.read_text(encoding='utf-8').replace('skylake_batchspan','skylake_vectorinput').replace('avx2_chain_batchspan','avx2_chain_vectorinput')
    if p.name=='channel_runtime.cpp':s=s.replace('jshc_cc_revision(void) {return 40;','jshc_cc_revision(void) {return 50;')
    if p.name=='channel_avx2.cpp':
        a=s.index('inline __attribute__((always_inline)) __m256i read(');b=s.index('inline __attribute__((always_inline)) void output(',a)
        s=s[:a]+'''inline __attribute__((always_inline)) __m256i input(const uint8_t* p) {
  const __m128i lo=_mm_loadu_si128(reinterpret_cast<const __m128i*>(p));
  const __m128i last=_mm_loadl_epi64(reinterpret_cast<const __m128i*>(p+16));
  const __m128i hi=_mm_alignr_epi8(last,lo,12);
  return _mm256_shuffle_epi8(_mm256_inserti128_si256(_mm256_castsi128_si256(lo),hi,1),
    _mm256_setr_epi8(0,1,2,-1,3,4,5,-1,6,7,8,-1,9,10,11,-1,0,1,2,-1,3,4,5,-1,6,7,8,-1,9,10,11,-1));
}
// 精确读取24字节，以向量解包减少输入load；表和palette继续普通GPR加载。
inline __attribute__((always_inline)) __m256i read(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  const __m256i code=input(p);
  const auto value=[table,palette](uint32_t i) {return int32_t(palette[reinterpret_cast<const uint8_t*>(table)[i]]);};
  return _mm256_setr_epi32(value(_mm256_extract_epi32(code,0)),value(_mm256_extract_epi32(code,1)),
    value(_mm256_extract_epi32(code,2)),value(_mm256_extract_epi32(code,3)),value(_mm256_extract_epi32(code,4)),
    value(_mm256_extract_epi32(code,5)),value(_mm256_extract_epi32(code,6)),value(_mm256_extract_epi32(code,7)));
}
inline __attribute__((always_inline)) __m256i read_wide(const uint32_t* table,const uint32_t* palette,const uint8_t* p) {
  return read(table,palette,p);
}
'''+s[b:]
    (out/p.name).write_bytes(s.encode('utf-8'))
plan=json.loads((ROOT/'experiments/skylake-batchspan-v1.json').read_text(encoding='utf-8'))
plan.update(purpose='50研究原40线性索引的RGB24向量输入解包，保持16MiB表及输出路径；按通用AVX2',candidate='每8像素用16+8字节合法加载、align/shuffle形成8个24位索引，再提取lane GPR查表；不做颜色分块或BMI2',base_commit='ee529bedec7537da5843080c2f1f07bab4e8e7d6',revisions={'reference':23,'candidate':50},cmake_project='experiments/skylake-vectorinput-runtime',cmake_targets=['jshc_skylake_reference','jshc_skylake_vectorinput'])
plan['vectorinput_policy']={'format':9,'table_bytes':2**24,'input_loads_per_eight_pixels':2,'exact_input_bytes':24,'index_layout_unchanged':True,'choice':'从40仅改输入读取；47/49失败分块不叠加，不扫描展开数','hypothesis':'减少输入load和掩码，新增lane提取；是否降低端口压力和周期待测','pmu_screen':{'same_session_reference':40,'one_thread_cycle_ratio_max':.95,'four_thread_cycle_ratio_max':1.05,'repetitions':1,'reason':'本版研究增量输入加载收益；至少5%周期改善才考虑完整墙钟，整体3倍验收门槛不变','on_failure':'停止本版，不重复画像或完整性能择优'}}
plan['source_sha256']={k:v for k,v in plan['source_sha256'].items() if not k.startswith('experiments/skylake-batchspan-runtime/')}
for p in out.iterdir():plan['source_sha256'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'experiments/skylake-vectorinput-v1.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('冻结50线性布局向量输入及5%增量筛查，整体3倍验收未改变')
