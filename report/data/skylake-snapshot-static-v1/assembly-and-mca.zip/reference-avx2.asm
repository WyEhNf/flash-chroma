
artifacts\skylake-snapshot-build-v1\CMakeFiles\jshc_skylake_reference.dir\F_\Hackathon\projects\16-lut-color\experiments\channel-runtime-specialized\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	57                   	push   %rdi
       1:	56                   	push   %rsi
       2:	53                   	push   %rbx
       3:	48 81 ec 80 02 00 00 	sub    $0x280,%rsp
       a:	c5 f8 29 b4 24 e0 01 	vmovaps %xmm6,0x1e0(%rsp)
      11:	00 00 
      13:	c5 f8 29 bc 24 f0 01 	vmovaps %xmm7,0x1f0(%rsp)
      1a:	00 00 
      1c:	c5 78 29 84 24 00 02 	vmovaps %xmm8,0x200(%rsp)
      23:	00 00 
      25:	c5 78 29 8c 24 10 02 	vmovaps %xmm9,0x210(%rsp)
      2c:	00 00 
      2e:	c5 78 29 94 24 20 02 	vmovaps %xmm10,0x220(%rsp)
      35:	00 00 
      37:	c5 78 29 9c 24 30 02 	vmovaps %xmm11,0x230(%rsp)
      3e:	00 00 
      40:	c5 78 29 a4 24 40 02 	vmovaps %xmm12,0x240(%rsp)
      47:	00 00 
      49:	c5 78 29 ac 24 50 02 	vmovaps %xmm13,0x250(%rsp)
      50:	00 00 
      52:	c5 78 29 b4 24 60 02 	vmovaps %xmm14,0x260(%rsp)
      59:	00 00 
      5b:	c5 78 29 bc 24 70 02 	vmovaps %xmm15,0x270(%rsp)
      62:	00 00 
      64:	49 89 d3             	mov    %rdx,%r11
      67:	48 83 fa 04          	cmp    $0x4,%rdx
      6b:	0f 84 0a 07 00 00    	je     77b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x77b>
      71:	4d 85 c9             	test   %r9,%r9
      74:	0f 84 8c 06 00 00    	je     706 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
      7a:	c5 fd 6f 1d 00 00 00 	vmovdqa 0x0(%rip),%ymm3        # 82 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x82>
      81:	00 
      82:	49 ff c9             	dec    %r9
      85:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
      89:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
      8e:	49 c1 e9 03          	shr    $0x3,%r9
      92:	49 c1 e2 05          	shl    $0x5,%r10
      96:	c4 c1 35 72 d2 18    	vpsrld $0x18,%ymm10,%ymm9
      9c:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
      a0:	c5 fe 7f 9c 24 a0 01 	vmovdqu %ymm3,0x1a0(%rsp)
      a7:	00 00 
      a9:	c5 fd 6f 1d 40 00 00 	vmovdqa 0x40(%rip),%ymm3        # f1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf1>
      b0:	00 
      b1:	49 01 ca             	add    %rcx,%r10
      b4:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
      b9:	b8 00 80 00 00       	mov    $0x8000,%eax
      be:	c5 fe 7f 9c 24 c0 01 	vmovdqu %ymm3,0x1c0(%rsp)
      c5:	00 00 
      c7:	c5 f9 6e d8          	vmovd  %eax,%xmm3
      cb:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      d0:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
      d5:	0f 1f 00             	nopl   (%rax)
      d8:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
      dd:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
      e3:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
      e9:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
      ef:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
      f6:	01 00 00 
      f9:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
      fe:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
     103:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     108:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     10d:	4d 85 db             	test   %r11,%r11
     110:	0f 84 5a 06 00 00    	je     770 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x770>
     116:	c5 fe 7f 8c 24 c0 00 	vmovdqu %ymm1,0xc0(%rsp)
     11d:	00 00 
     11f:	48 89 c8             	mov    %rcx,%rax
     122:	c5 fe 7f 94 24 a0 00 	vmovdqu %ymm2,0xa0(%rsp)
     129:	00 00 
     12b:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
     132:	00 00 
     134:	e9 d6 00 00 00       	jmp    20f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x20f>
     139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     140:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     147:	00 00 
     149:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
     14e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     153:	48 83 c0 60          	add    $0x60,%rax
     157:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     15c:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
     161:	c5 e5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm3
     166:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
     16b:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
     16f:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     173:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
     178:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     17d:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
     183:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     188:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     18c:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
     193:	00 00 
     195:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     199:	c5 ed 72 d7 10       	vpsrld $0x10,%ymm7,%ymm2
     19e:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     1a3:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     1a8:	c5 9d fa da          	vpsubd %ymm2,%ymm12,%ymm3
     1ac:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     1b0:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     1b6:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     1bb:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     1c0:	c5 dd fa 64 24 60    	vpsubd 0x60(%rsp),%ymm4,%ymm4
     1c6:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     1cb:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     1cf:	c5 dd fe a4 24 40 01 	vpaddd 0x140(%rsp),%ymm4,%ymm4
     1d6:	00 00 
     1d8:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     1dc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     1e1:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
     1e5:	4c 39 d0             	cmp    %r10,%rax
     1e8:	0f 84 bc 04 00 00    	je     6aa <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6aa>
     1ee:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
     1f4:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     1fb:	00 00 
     1fd:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
     204:	00 00 
     206:	c5 fe 7f 9c 24 c0 00 	vmovdqu %ymm3,0xc0(%rsp)
     20d:	00 00 
     20f:	48 8b 70 08          	mov    0x8(%rax),%rsi
     213:	c5 fe 6f bc 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm7
     21a:	00 00 
     21c:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
     220:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
     225:	8b 58 54             	mov    0x54(%rax),%ebx
     228:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     22f:	00 00 
     231:	c4 e2 5d 90 1c be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm3
     237:	48 8b 30             	mov    (%rax),%rsi
     23a:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     241:	00 00 
     243:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
     247:	c5 79 6e eb          	vmovd  %ebx,%xmm13
     24b:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
     250:	48 8b 78 10          	mov    0x10(%rax),%rdi
     254:	48 8b 50 48          	mov    0x48(%rax),%rdx
     258:	c4 e2 5d 90 04 be    	vpgatherdd %ymm4,(%rsi,%ymm7,4),%ymm0
     25e:	8b 70 50             	mov    0x50(%rax),%esi
     261:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     266:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
     26a:	c5 d5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm5
     26f:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
     274:	c4 e2 5d 90 14 b7    	vpgatherdd %ymm4,(%rdi,%ymm6,4),%ymm2
     27a:	c5 79 6e f6          	vmovd  %esi,%xmm14
     27e:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
     283:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
     287:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
     28c:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 2f4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f4>
     293:	00 
     294:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 2fc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2fc>
     29b:	00 
     29c:	c4 c2 55 40 ee       	vpmulld %ymm14,%ymm5,%ymm5
     2a1:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 309 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x309>
     2a8:	00 
     2a9:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
     2ad:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     2b1:	c4 e2 65 39 e8       	vpminsd %ymm0,%ymm3,%ymm5
     2b6:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
     2ba:	c4 62 55 39 da       	vpminsd %ymm2,%ymm5,%ymm11
     2bf:	c5 d5 66 ea          	vpcmpgtd %ymm2,%ymm5,%ymm5
     2c3:	c4 a2 45 90 0c ba    	vpgatherdd %ymm7,(%rdx,%ymm15,4),%ymm1
     2c9:	c4 c1 75 db e1       	vpand  %ymm9,%ymm1,%ymm4
     2ce:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     2d4:	c4 e2 65 3d e0       	vpmaxsd %ymm0,%ymm3,%ymm4
     2d9:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     2df:	c4 62 5d 3d c2       	vpmaxsd %ymm2,%ymm4,%ymm8
     2e4:	c5 ed 66 e4          	vpcmpgtd %ymm4,%ymm2,%ymm4
     2e8:	c4 c1 3d fe fb       	vpaddd %ymm11,%ymm8,%ymm7
     2ed:	c5 cd 72 f6 10       	vpslld $0x10,%ymm6,%ymm6
     2f2:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     2f9:	00 00 
     2fb:	c5 fe 7f b4 24 60 01 	vmovdqu %ymm6,0x160(%rsp)
     302:	00 00 
     304:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
     309:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     30e:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
     313:	c5 fe 7f 7c 24 40    	vmovdqu %ymm7,0x40(%rsp)
     319:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
     31f:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
     324:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
     329:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     32d:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
     334:	00 00 
     336:	c4 c1 75 db f1       	vpand  %ymm9,%ymm1,%ymm6
     33b:	c5 fe 7f 74 24 60    	vmovdqu %ymm6,0x60(%rsp)
     341:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
     347:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     34c:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     350:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
     357:	00 00 
     359:	c5 f9 6e ce          	vmovd  %esi,%xmm1
     35d:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     362:	c4 c1 75 fe ff       	vpaddd %ymm15,%ymm1,%ymm7
     367:	c5 fd 66 cb          	vpcmpgtd %ymm3,%ymm0,%ymm1
     36b:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
     372:	00 00 
     374:	c4 e2 1d 90 34 ba    	vpgatherdd %ymm12,(%rdx,%ymm7,4),%ymm6
     37a:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
     37f:	c5 ed fa 94 24 00 01 	vpsubd 0x100(%rsp),%ymm2,%ymm2
     386:	00 00 
     388:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     38c:	c4 c3 0d 4c cd 10    	vpblendvb %ymm1,%ymm13,%ymm14,%ymm1
     392:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm1,%ymm1        # 3bb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3bb>
     399:	00 00 50 
     39c:	c5 c5 fa c9          	vpsubd %ymm1,%ymm7,%ymm1
     3a0:	c4 c1 4d db f9       	vpand  %ymm9,%ymm6,%ymm7
     3a5:	c4 e2 1d 90 2c 8a    	vpgatherdd %ymm12,(%rdx,%ymm1,4),%ymm5
     3ab:	c4 41 7d 6f e2       	vmovdqa %ymm10,%ymm12
     3b0:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
     3b7:	00 00 
     3b9:	c5 e5 66 e8          	vpcmpgtd %ymm0,%ymm3,%ymm5
     3bd:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     3c1:	c5 b5 db 8c 24 e0 00 	vpand  0xe0(%rsp),%ymm9,%ymm1
     3c8:	00 00 
     3ca:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     3ce:	c5 fe 6f 94 24 60 01 	vmovdqu 0x160(%rsp),%ymm2
     3d5:	00 00 
     3d7:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
     3dd:	c5 c5 fa f9          	vpsubd %ymm1,%ymm7,%ymm7
     3e1:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 40a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x40a>
     3e8:	00 00 40 
     3eb:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
     3f0:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
     3f4:	c4 e2 1d 90 24 aa    	vpgatherdd %ymm12,(%rdx,%ymm5,4),%ymm4
     3fa:	c5 6d fe 24 24       	vpaddd (%rsp),%ymm2,%ymm12
     3ff:	c4 c1 5d db e9       	vpand  %ymm9,%ymm4,%ymm5
     404:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     408:	c5 d5 fa 6c 24 20    	vpsubd 0x20(%rsp),%ymm5,%ymm5
     40e:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
     413:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     418:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
     41d:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     421:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     425:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
     42a:	c5 f5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm1
     42f:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     434:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
     43a:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
     43f:	c4 41 4d db e1       	vpand  %ymm9,%ymm6,%ymm12
     444:	0f 85 f6 fc ff ff    	jne    140 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
     44a:	48 8b 58 28          	mov    0x28(%rax),%rbx
     44e:	c5 fe 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm0
     455:	00 00 
     457:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
     45b:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
     45f:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     466:	00 00 
     468:	c4 41 7d 6f da       	vmovdqa %ymm10,%ymm11
     46d:	48 83 c0 60          	add    $0x60,%rax
     471:	c4 e2 5d 90 1c 83    	vpgatherdd %ymm4,(%rbx,%ymm0,4),%ymm3
     477:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
     47b:	c5 fe 6f 84 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm0
     482:	00 00 
     484:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 4ec <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ec>
     48b:	00 
     48c:	c4 e2 4d 90 24 83    	vpgatherdd %ymm6,(%rbx,%ymm0,4),%ymm4
     492:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
     496:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
     49a:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 502 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x502>
     4a1:	00 
     4a2:	c4 e2 4d 90 04 bb    	vpgatherdd %ymm6,(%rbx,%ymm7,4),%ymm0
     4a8:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
     4ac:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 514 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x514>
     4b3:	00 
     4b4:	c4 e2 7d 3d fc       	vpmaxsd %ymm4,%ymm0,%ymm7
     4b9:	c5 dd 66 e8          	vpcmpgtd %ymm0,%ymm4,%ymm5
     4bd:	c4 e2 7d 39 f4       	vpminsd %ymm4,%ymm0,%ymm6
     4c2:	c5 e5 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm2
     4c6:	c4 62 4d 39 c3       	vpminsd %ymm3,%ymm6,%ymm8
     4cb:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
     4d0:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
     4d4:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
     4da:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 503 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x503>
     4e1:	00 00 20 
     4e4:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
     4e8:	c4 e2 25 90 14 aa    	vpgatherdd %ymm11,(%rdx,%ymm5,4),%ymm2
     4ee:	c5 fd 66 ec          	vpcmpgtd %ymm4,%ymm0,%ymm5
     4f2:	c5 7e 6f 9c 24 80 01 	vmovdqu 0x180(%rsp),%ymm11
     4f9:	00 00 
     4fb:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     4ff:	c5 fe 7f 94 24 e0 00 	vmovdqu %ymm2,0xe0(%rsp)
     506:	00 00 
     508:	c5 7d 7f d2          	vmovdqa %ymm10,%ymm2
     50c:	c5 fe 6f a4 24 80 00 	vmovdqu 0x80(%rsp),%ymm4
     513:	00 00 
     515:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
     51b:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 544 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x544>
     522:	00 00 60 
     525:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
     529:	c4 e2 6d 90 34 aa    	vpgatherdd %ymm2,(%rdx,%ymm5,4),%ymm6
     52f:	c5 fe 6f 94 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm2
     536:	00 00 
     538:	c4 c1 45 fe e8       	vpaddd %ymm8,%ymm7,%ymm5
     53d:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     542:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
     546:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     54b:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
     550:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     554:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     559:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     55d:	c5 cd fa da          	vpsubd %ymm2,%ymm6,%ymm3
     561:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
     567:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     56c:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     571:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
     575:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     57a:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     57e:	c5 ed fe 94 24 20 01 	vpaddd 0x120(%rsp),%ymm2,%ymm2
     585:	00 00 
     587:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     58b:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
     590:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     596:	c4 e2 65 90 04 a3    	vpgatherdd %ymm3,(%rbx,%ymm4,4),%ymm0
     59c:	c5 7d 7f d3          	vmovdqa %ymm10,%ymm3
     5a0:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 608 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x608>
     5a7:	00 
     5a8:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
     5ac:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
     5b3:	00 00 
     5b5:	c5 fe 6f bc 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm7
     5bc:	00 00 
     5be:	48 8b 78 d0          	mov    -0x30(%rax),%rdi
     5c2:	c4 e2 65 90 24 b3    	vpgatherdd %ymm3,(%rbx,%ymm6,4),%ymm4
     5c8:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
     5cc:	c4 e2 4d 90 1c bf    	vpgatherdd %ymm6,(%rdi,%ymm7,4),%ymm3
     5d2:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 63a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63a>
     5d9:	00 
     5da:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 642 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x642>
     5e1:	00 
     5e2:	c4 e2 65 3d f4       	vpmaxsd %ymm4,%ymm3,%ymm6
     5e7:	c5 dd 66 eb          	vpcmpgtd %ymm3,%ymm4,%ymm5
     5eb:	c4 e2 65 39 fc       	vpminsd %ymm4,%ymm3,%ymm7
     5f0:	c5 fd 66 d6          	vpcmpgtd %ymm6,%ymm0,%ymm2
     5f4:	c4 62 45 39 c0       	vpminsd %ymm0,%ymm7,%ymm8
     5f9:	c4 e2 4d 3d f0       	vpmaxsd %ymm0,%ymm6,%ymm6
     5fe:	c5 c5 66 f8          	vpcmpgtd %ymm0,%ymm7,%ymm7
     602:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
     608:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm5,%ymm5        # 631 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x631>
     60f:	00 00 20 
     612:	c5 85 fe ed          	vpaddd %ymm5,%ymm15,%ymm5
     616:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
     61b:	c4 e2 05 90 14 aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm2
     621:	c5 e5 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm5
     625:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
     62a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     62f:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     633:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
     638:	c4 c3 0d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm14,%ymm5
     63e:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 667 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x667>
     645:	00 00 70 
     648:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
     64c:	c4 e2 05 90 3c aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm7
     652:	c4 c1 4d fe e8       	vpaddd %ymm8,%ymm6,%ymm5
     657:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     65c:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
     660:	c4 c1 45 db f9       	vpand  %ymm9,%ymm7,%ymm7
     665:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     669:	c5 c5 fa da          	vpsubd %ymm2,%ymm7,%ymm3
     66d:	c5 ed fa 54 24 60    	vpsubd 0x60(%rsp),%ymm2,%ymm2
     673:	c5 1d fa e7          	vpsubd %ymm7,%ymm12,%ymm12
     677:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     67c:	c4 e2 6d 40 d6       	vpmulld %ymm6,%ymm2,%ymm2
     681:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
     686:	c5 ed fe 94 24 40 01 	vpaddd 0x140(%rsp),%ymm2,%ymm2
     68d:	00 00 
     68f:	c4 c1 7d fe c4       	vpaddd %ymm12,%ymm0,%ymm0
     694:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
     698:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     69d:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
     6a1:	49 39 c2             	cmp    %rax,%r10
     6a4:	0f 85 44 fb ff ff    	jne    1ee <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ee>
     6aa:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
     6b0:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     6b6:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     6bb:	49 83 c0 18          	add    $0x18,%r8
     6bf:	c5 ed 72 f3 08       	vpslld $0x8,%ymm3,%ymm2
     6c4:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
     6c8:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     6cc:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
     6d3:	01 00 00 
     6d6:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     6da:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     6e0:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     6e5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     6ea:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     6ee:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     6f4:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     6fa:	4d 39 c1             	cmp    %r8,%r9
     6fd:	0f 85 d5 f9 ff ff    	jne    d8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd8>
     703:	c5 f8 77             	vzeroupper
     706:	c5 f8 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm6
     70d:	00 00 
     70f:	c5 f8 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm7
     716:	00 00 
     718:	c5 78 28 84 24 00 02 	vmovaps 0x200(%rsp),%xmm8
     71f:	00 00 
     721:	c5 78 28 8c 24 10 02 	vmovaps 0x210(%rsp),%xmm9
     728:	00 00 
     72a:	c5 78 28 94 24 20 02 	vmovaps 0x220(%rsp),%xmm10
     731:	00 00 
     733:	c5 78 28 9c 24 30 02 	vmovaps 0x230(%rsp),%xmm11
     73a:	00 00 
     73c:	c5 78 28 a4 24 40 02 	vmovaps 0x240(%rsp),%xmm12
     743:	00 00 
     745:	c5 78 28 ac 24 50 02 	vmovaps 0x250(%rsp),%xmm13
     74c:	00 00 
     74e:	c5 78 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm14
     755:	00 00 
     757:	c5 78 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm15
     75e:	00 00 
     760:	48 81 c4 80 02 00 00 	add    $0x280,%rsp
     767:	5b                   	pop    %rbx
     768:	5e                   	pop    %rsi
     769:	5f                   	pop    %rdi
     76a:	c3                   	ret
     76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     770:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
     776:	e9 35 ff ff ff       	jmp    6b0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6b0>
     77b:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     77f:	0f 85 ec f8 ff ff    	jne    71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     785:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     78c:	0f 84 df f8 ff ff    	je     71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     792:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     799:	0f 84 d2 f8 ff ff    	je     71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     79f:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     7a6:	0f 84 c5 f8 ff ff    	je     71 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71>
     7ac:	4d 85 c9             	test   %r9,%r9
     7af:	0f 84 51 ff ff ff    	je     706 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x706>
     7b5:	c5 fd 6f 25 00 00 00 	vmovdqa 0x0(%rip),%ymm4        # 7bd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7bd>
     7bc:	00 
     7bd:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     7c1:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
     7c6:	48 c1 e8 03          	shr    $0x3,%rax
     7ca:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
     7d0:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
     7d4:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
     7db:	00 00 
     7dd:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # 825 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x825>
     7e4:	00 
     7e5:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
     7ea:	b8 00 80 00 00       	mov    $0x8000,%eax
     7ef:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
     7f6:	00 00 
     7f8:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     7fc:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     801:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
     806:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     80b:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     811:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     815:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
     81a:	48 8b 01             	mov    (%rcx),%rax
     81d:	44 8b 49 54          	mov    0x54(%rcx),%r9d
     821:	49 83 c0 18          	add    $0x18,%r8
     825:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     82b:	8b 51 50             	mov    0x50(%rcx),%edx
     82e:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     834:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
     839:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
     840:	01 00 00 
     843:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     847:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     84c:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
     851:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
     856:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     85b:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     861:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
     866:	c4 c1 35 db f6       	vpand  %ymm14,%ymm9,%ymm6
     86b:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     870:	c4 e2 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm0
     876:	48 8b 41 08          	mov    0x8(%rcx),%rax
     87a:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
     880:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     884:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
     888:	c4 e2 65 90 34 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm6
     88e:	48 8b 41 10          	mov    0x10(%rcx),%rax
     892:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     896:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     89b:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 903 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x903>
     8a2:	00 
     8a3:	c4 a2 65 90 24 a0    	vpgatherdd %ymm3,(%rax,%ymm12,4),%ymm4
     8a9:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
     8ae:	48 8b 41 48          	mov    0x48(%rcx),%rax
     8b2:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 91a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x91a>
     8b9:	00 
     8ba:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
     8bf:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     8c4:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
     8c9:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 931 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x931>
     8d0:	00 
     8d1:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
     8d6:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
     8db:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     8df:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     8e3:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     8e7:	c4 62 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm13
     8ed:	c5 f9 6e da          	vmovd  %edx,%xmm3
     8f1:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     8f6:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     8fa:	c4 e2 05 90 2c 98    	vpgatherdd %ymm15,(%rax,%ymm3,4),%ymm5
     900:	c4 62 3d 3d fc       	vpmaxsd %ymm4,%ymm8,%ymm15
     905:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
     90a:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
     911:	00 00 
     913:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
     917:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
     91c:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
     923:	00 00 
     925:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
     929:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
     92f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # 958 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x958>
     936:	00 00 a0 
     939:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
     93e:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     942:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
     948:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
     94c:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     950:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
     956:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # 97f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x97f>
     95d:	00 00 80 
     960:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
     965:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     969:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
     96f:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
     975:	c4 c1 05 db ee       	vpand  %ymm14,%ymm15,%ymm5
     97a:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
     981:	00 00 
     983:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
     988:	c5 0d db 6c 24 60    	vpand  0x60(%rsp),%ymm14,%ymm13
     98e:	48 8b 51 28          	mov    0x28(%rcx),%rdx
     992:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     997:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
     99d:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     9a1:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
     9a5:	c4 c1 3d 72 f5 10    	vpslld $0x10,%ymm13,%ymm8
     9ab:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
     9b0:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
     9b5:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     9ba:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
     9c1:	00 00 00 
     9c4:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
     9c9:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
     9cd:	c5 8d db a4 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm4
     9d4:	00 00 
     9d6:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     9db:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     9e0:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
     9e5:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     9e9:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     9ed:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     9f3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     9f8:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     9ff:	00 00 
     a01:	c4 a2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm5
     a07:	48 8b 51 20          	mov    0x20(%rcx),%rdx
     a0b:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # a73 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa73>
     a12:	00 
     a13:	c4 62 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm8
     a19:	48 8b 51 18          	mov    0x18(%rcx),%rdx
     a1d:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
     a22:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # a8a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa8a>
     a29:	00 
     a2a:	c4 e2 35 90 04 a2    	vpgatherdd %ymm9,(%rdx,%ymm4,4),%ymm0
     a30:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # a98 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa98>
     a37:	00 
     a38:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
     a3d:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
     a41:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
     a45:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
     a4a:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
     a4f:	c4 62 4d 39 ed       	vpminsd %ymm5,%ymm6,%ymm13
     a54:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
     a58:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
     a5e:	c5 7e 7f ac 24 a0 00 	vmovdqu %ymm13,0xa0(%rsp)
     a65:	00 00 
     a67:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # a90 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa90>
     a6e:	00 00 a0 
     a71:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
     a76:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
     a7a:	c4 62 2d 90 2c a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm13
     a80:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
     a85:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
     a8a:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     a8f:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
     a94:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
     a9a:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # ac3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xac3>
     aa1:	00 00 60 
     aa4:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
     aa8:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
     aae:	c5 7e 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm10
     ab4:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     ab9:	c4 c1 5d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm4
     abf:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
     ac6:	00 00 
     ac8:	c4 41 5d db fe       	vpand  %ymm14,%ymm4,%ymm15
     acd:	c4 c1 5d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm4
     ad3:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
     ada:	00 00 
     adc:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     ae2:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     ae7:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
     aec:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
     af3:	00 00 
     af5:	c4 41 4d db d6       	vpand  %ymm14,%ymm6,%ymm10
     afa:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     aff:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
     b05:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     b09:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
     b0d:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
     b12:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
     b17:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
     b1c:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
     b21:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
     b25:	c5 8d db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm14,%ymm0
     b2c:	00 00 
     b2e:	48 8b 51 40          	mov    0x40(%rcx),%rdx
     b32:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
     b38:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
     b3d:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
     b44:	00 00 00 
     b47:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     b4b:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
     b4f:	c4 a2 3d 90 04 a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm0
     b55:	48 8b 51 38          	mov    0x38(%rcx),%rdx
     b59:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
     b5e:	c5 95 72 d5 10       	vpsrld $0x10,%ymm5,%ymm13
     b63:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # bcb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbcb>
     b6a:	00 
     b6b:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
     b70:	c4 e2 3d 90 2c b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm5
     b76:	48 8b 51 30          	mov    0x30(%rcx),%rdx
     b7a:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     b80:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
     b85:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # bed <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbed>
     b8c:	00 
     b8d:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
     b93:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # bfb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbfb>
     b9a:	00 
     b9b:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
     ba0:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
     ba4:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
     ba9:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
     bae:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
     bb4:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # bdd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbdd>
     bbb:	00 00 90 
     bbe:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     bc3:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
     bc7:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
     bcc:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
     bd0:	c4 e2 1d 90 14 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm2
     bd6:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
     bda:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     bde:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
     be4:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     be8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # c11 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc11>
     bef:	00 00 90 
     bf2:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
     bf7:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
     bfb:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
     c00:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     c05:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
     c0b:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     c10:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
     c16:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     c1a:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
     c1f:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     c26:	00 00 
     c28:	48 8b 41 60          	mov    0x60(%rcx),%rax
     c2c:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
     c31:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     c36:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
     c3a:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     c3f:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     c44:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
     c49:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
     c4e:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
     c52:	c5 fe 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm3
     c59:	00 00 
     c5b:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
     c60:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
     c65:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     c69:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
     c6e:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
     c72:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
     c76:	c4 e2 4d 90 24 98    	vpgatherdd %ymm6,(%rax,%ymm3,4),%ymm4
     c7c:	48 8b 41 68          	mov    0x68(%rcx),%rax
     c80:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     c84:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     c89:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     c8d:	c4 a2 65 90 2c a8    	vpgatherdd %ymm3,(%rax,%ymm13,4),%ymm5
     c93:	48 8b 41 70          	mov    0x70(%rcx),%rax
     c97:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
     c9e:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     ca2:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
     ca8:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     cad:	c5 79 6e ca          	vmovd  %edx,%xmm9
     cb1:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     cb6:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     cbb:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
     cc2:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
     cc6:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     ccb:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     cd0:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     cd4:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     cd9:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # d41 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd41>
     ce0:	00 
     ce1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ce6:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
     cec:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
     cf1:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
     cf8:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     cfc:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     d01:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     d06:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # d6e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd6e>
     d0d:	00 
     d0e:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # d76 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd76>
     d15:	00 
     d16:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
     d1b:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
     d20:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
     d25:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
     d29:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
     d2d:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     d31:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     d35:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     d39:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     d3e:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
     d44:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
     d48:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
     d4e:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
     d54:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
     d58:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     d5d:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     d61:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     d66:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
     d6b:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
     d71:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # d9a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd9a>
     d78:	00 00 70 
     d7b:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     d80:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     d84:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     d88:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
     d8d:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
     d92:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
     d98:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
     d9e:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     da4:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
     da9:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # dd2 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xdd2>
     db0:	00 00 c0 
     db3:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
     db8:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
     dbd:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
     dc1:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     dc5:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
     dca:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
     dd0:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     dd5:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
     dda:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
     de1:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
     de6:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
     deb:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
     def:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
     df3:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
     df8:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     dfd:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     e02:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     e07:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     e0c:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     e11:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     e15:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
     e1a:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     e1e:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
     e23:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     e28:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     e2d:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
     e33:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     e38:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     e3d:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
     e42:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
     e47:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
     e4c:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     e51:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     e55:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     e5a:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     e5f:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
     e64:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     e69:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
     e6e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     e73:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     e78:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     e7d:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
     e82:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
     e87:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     e8b:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
     e90:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
     e95:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e9a:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
     e9f:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     ea4:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
     ea9:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
     ead:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
     eb1:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
     eb5:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     eba:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     ebf:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     ec4:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
     ec9:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     ecd:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     ed1:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     ed5:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     ed9:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
     edf:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
     ee6:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     eea:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     eee:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     ef3:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
     ef9:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
     f00:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     f04:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     f09:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
     f0f:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
     f15:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
     f1a:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
     f21:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     f26:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
     f2b:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
     f2f:	c5 79 6e ca          	vmovd  %edx,%xmm9
     f33:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
     f38:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # fa0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfa0>
     f3f:	00 
     f40:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
     f47:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
     f4c:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # fb4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfb4>
     f53:	00 
     f54:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # fbc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfbc>
     f5b:	00 
     f5c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
     f61:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
     f66:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
     f6b:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
     f70:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
     f74:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
     f78:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     f7c:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     f80:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
     f86:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     f8a:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     f8f:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
     f95:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
     f99:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
     f9f:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
     fa5:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
     fa9:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
     fae:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     fb2:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
     fb7:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
     fbc:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
     fc2:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # feb <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfeb>
     fc9:	00 00 70 
     fcc:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
     fd1:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
     fd5:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     fd9:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
     fde:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
     fe3:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
     fe9:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
     fef:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     ff5:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
     ffa:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1023 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1023>
    1001:	00 00 c0 
    1004:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    1009:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    100e:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    1012:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1016:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    101b:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    1021:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1026:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    102b:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    1032:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    1037:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    103c:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    1040:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    1044:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    1049:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    104e:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    1053:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    1058:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    105d:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1062:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    1066:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    106b:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    106f:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    1074:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    1079:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    107e:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    1084:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    1089:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    108e:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    1093:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    1098:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    109d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    10a2:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    10a6:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    10ab:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    10b0:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    10b5:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    10ba:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    10bf:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    10c4:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    10c9:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    10ce:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    10d3:	c5 79 6e ca          	vmovd  %edx,%xmm9
    10d7:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    10dc:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    10e1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    10e6:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    10ea:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    10ef:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    10f4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    10f9:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    10fe:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1103:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    1108:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    110c:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    1110:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    1114:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1119:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    111e:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1123:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    1128:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    112c:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1130:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1134:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1138:	c4 e2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm5,4),%ymm4
    113e:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    1145:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1149:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    114d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1152:	c4 e2 65 90 2c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm5
    1158:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    115f:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1163:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    1168:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 11d0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d0>
    116f:	00 
    1170:	c4 e2 65 90 34 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm6
    1176:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    117b:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 11e3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11e3>
    1182:	00 
    1183:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    1188:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    118d:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1191:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    1196:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 11fe <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11fe>
    119d:	00 
    119e:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    11a5:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    11aa:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    11af:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    11b3:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    11b8:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    11bc:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    11c0:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    11c4:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    11c8:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    11cd:	c4 e2 65 90 0c 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm1
    11d3:	c5 fd fe da          	vpaddd %ymm2,%ymm0,%ymm3
    11d7:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
    11dd:	c4 e2 45 90 04 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm0
    11e3:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    11e7:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    11ec:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    11f0:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    11f5:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    11fb:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 1224 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1224>
    1202:	00 00 70 
    1205:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    120a:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    120e:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1212:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    1217:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    121c:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1221:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    1227:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    122d:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    1233:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    1238:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1261 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1261>
    123f:	00 00 c0 
    1242:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    1247:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    124c:	c5 dd fa d2          	vpsubd %ymm2,%ymm4,%ymm2
    1250:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1254:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
    1259:	c4 e2 5d 90 2c 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm5
    125f:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1264:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    1269:	c4 c1 55 db d6       	vpand  %ymm14,%ymm5,%ymm2
    126e:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    1273:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    1277:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    127b:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    1280:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1285:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    128a:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    128f:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    1294:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    1299:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    129d:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    12a2:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    12a6:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    12ab:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    12b0:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    12b5:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    12bb:	c5 8d db f6          	vpand  %ymm6,%ymm14,%ymm6
    12bf:	c5 8d db d2          	vpand  %ymm2,%ymm14,%ymm2
    12c3:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    12c8:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    12cd:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    12d2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    12d7:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    12db:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    12e0:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12e5:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    12ea:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    12ef:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    12f4:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    12f9:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    12fe:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    1303:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    1307:	c4 c1 75 db f6       	vpand  %ymm14,%ymm1,%ymm6
    130c:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    1311:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1316:	c4 c1 65 db ee       	vpand  %ymm14,%ymm3,%ymm5
    131b:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    1320:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    1325:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    1329:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    132d:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    1331:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1336:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    133b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    1340:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    1345:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    134a:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    134e:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    1352:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1356:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    135b:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    1360:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    1364:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    1368:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    136f:	01 00 00 
    1372:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1376:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    137c:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    1381:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1386:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    138a:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    1390:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1396:	4d 39 c2             	cmp    %r8,%r10
    1399:	0f 85 67 f4 ff ff    	jne    806 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x806>
    139f:	e9 5f f3 ff ff       	jmp    703 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x703>
    13a4:	90                   	nop
    13a5:	90                   	nop
    13a6:	90                   	nop
    13a7:	90                   	nop
    13a8:	90                   	nop
    13a9:	90                   	nop
    13aa:	90                   	nop
    13ab:	90                   	nop
    13ac:	90                   	nop
    13ad:	90                   	nop
    13ae:	90                   	nop
    13af:	90                   	nop
