
artifacts\skylake-snapshot-build-v1\CMakeFiles\jshc_skylake_snapshot.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
       0:	41 57                	push   %r15
       2:	41 56                	push   %r14
       4:	41 55                	push   %r13
       6:	41 54                	push   %r12
       8:	55                   	push   %rbp
       9:	57                   	push   %rdi
       a:	56                   	push   %rsi
       b:	53                   	push   %rbx
       c:	48 81 ec b8 03 00 00 	sub    $0x3b8,%rsp
      13:	c5 f8 29 b4 24 10 03 	vmovaps %xmm6,0x310(%rsp)
      1a:	00 00 
      1c:	c5 f8 29 bc 24 20 03 	vmovaps %xmm7,0x320(%rsp)
      23:	00 00 
      25:	c5 78 29 84 24 30 03 	vmovaps %xmm8,0x330(%rsp)
      2c:	00 00 
      2e:	c5 78 29 8c 24 40 03 	vmovaps %xmm9,0x340(%rsp)
      35:	00 00 
      37:	c5 78 29 94 24 50 03 	vmovaps %xmm10,0x350(%rsp)
      3e:	00 00 
      40:	c5 78 29 9c 24 60 03 	vmovaps %xmm11,0x360(%rsp)
      47:	00 00 
      49:	c5 78 29 a4 24 70 03 	vmovaps %xmm12,0x370(%rsp)
      50:	00 00 
      52:	c5 78 29 ac 24 80 03 	vmovaps %xmm13,0x380(%rsp)
      59:	00 00 
      5b:	c5 78 29 b4 24 90 03 	vmovaps %xmm14,0x390(%rsp)
      62:	00 00 
      64:	c5 78 29 bc 24 a0 03 	vmovaps %xmm15,0x3a0(%rsp)
      6b:	00 00 
      6d:	48 89 c8             	mov    %rcx,%rax
      70:	49 89 d2             	mov    %rdx,%r10
      73:	48 83 fa 04          	cmp    $0x4,%rdx
      77:	0f 84 1c 07 00 00    	je     799 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x799>
      7d:	4d 85 c9             	test   %r9,%r9
      80:	0f 84 97 06 00 00    	je     71d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71d>
      86:	c5 fd 6f 25 00 00 00 	vmovdqa 0x0(%rip),%ymm4        # 8e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8e>
      8d:	00 
      8e:	49 ff c9             	dec    %r9
      91:	4f 8d 1c 52          	lea    (%r10,%r10,2),%r11
      95:	c4 41 35 76 c9       	vpcmpeqd %ymm9,%ymm9,%ymm9
      9a:	49 c1 e9 03          	shr    $0x3,%r9
      9e:	49 c1 e3 05          	shl    $0x5,%r11
      a2:	c4 c1 0d 72 d1 18    	vpsrld $0x18,%ymm9,%ymm14
      a8:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
      ac:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
      b3:	00 00 
      b5:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # fd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfd>
      bc:	00 
      bd:	49 01 c3             	add    %rax,%r11
      c0:	4d 8d 4c d0 18       	lea    0x18(%r8,%rdx,8),%r9
      c5:	ba 00 80 00 00       	mov    $0x8000,%edx
      ca:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
      d1:	00 00 
      d3:	c5 f9 6e e2          	vmovd  %edx,%xmm4
      d7:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
      dc:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
      e3:	00 00 
      e5:	0f 1f 00             	nopl   (%rax)
      e8:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
      ed:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
      f3:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
      f9:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
      ff:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
     106:	01 00 00 
     109:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     10e:	c4 c1 7d db ce       	vpand  %ymm14,%ymm0,%ymm1
     113:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     118:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     11d:	4d 85 d2             	test   %r10,%r10
     120:	0f 84 6a 06 00 00    	je     790 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x790>
     126:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     12d:	00 00 
     12f:	48 89 c2             	mov    %rax,%rdx
     132:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
     139:	00 00 
     13b:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     141:	e9 d5 00 00 00       	jmp    21b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x21b>
     146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     14d:	00 00 00 
     150:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     157:	00 00 
     159:	c4 c1 6d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm2
     15f:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
     165:	48 83 c2 60          	add    $0x60,%rdx
     169:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     16e:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
     173:	c5 e5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm3
     178:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     17d:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     181:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
     185:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
     18a:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     18f:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     193:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     198:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     19c:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
     1a1:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     1a5:	c5 ed 72 d6 10       	vpsrld $0x10,%ymm6,%ymm2
     1aa:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     1af:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     1b4:	c5 a5 fa c2          	vpsubd %ymm2,%ymm11,%ymm0
     1b8:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
     1bd:	c5 7d 6f fb          	vmovdqa %ymm3,%ymm15
     1c1:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
     1c6:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
     1cb:	c5 15 fa 6c 24 40    	vpsubd 0x40(%rsp),%ymm13,%ymm13
     1d1:	c4 62 15 40 ef       	vpmulld %ymm7,%ymm13,%ymm13
     1d6:	c5 fd fe ca          	vpaddd %ymm2,%ymm0,%ymm1
     1da:	c5 15 fe ac 24 40 01 	vpaddd 0x140(%rsp),%ymm13,%ymm13
     1e1:	00 00 
     1e3:	c4 c1 75 fe cd       	vpaddd %ymm13,%ymm1,%ymm1
     1e8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     1ed:	c5 fd 6f c1          	vmovdqa %ymm1,%ymm0
     1f1:	4c 39 da             	cmp    %r11,%rdx
     1f4:	0f 84 c6 04 00 00    	je     6c0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c0>
     1fa:	c5 fe 7f 9c 24 80 00 	vmovdqu %ymm3,0x80(%rsp)
     201:	00 00 
     203:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
     209:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
     210:	00 00 
     212:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
     219:	00 00 
     21b:	48 8b 0a             	mov    (%rdx),%rcx
     21e:	c5 fe 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm3
     225:	00 00 
     227:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     22b:	c4 41 7d 6f d1       	vmovdqa %ymm9,%ymm10
     230:	8b 7a 54             	mov    0x54(%rdx),%edi
     233:	8b 5a 50             	mov    0x50(%rdx),%ebx
     236:	c4 e2 45 90 24 99    	vpgatherdd %ymm7,(%rcx,%ymm3,4),%ymm4
     23c:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
     240:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
     247:	00 00 
     249:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     24d:	c5 5d db 2d 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm13        # 2b5 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2b5>
     254:	00 
     255:	c5 dd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm4
     25a:	c4 e2 45 90 14 99    	vpgatherdd %ymm7,(%rcx,%ymm3,4),%ymm2
     260:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     264:	c5 fe 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm3
     26a:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     26e:	c5 ed db 05 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm0        # 2d6 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d6>
     275:	00 
     276:	c5 ed 72 d2 11       	vpsrld $0x11,%ymm2,%ymm2
     27b:	c4 e2 45 90 2c 99    	vpgatherdd %ymm7,(%rcx,%ymm3,4),%ymm5
     281:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
     285:	c5 d5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm1        # 2ed <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ed>
     28c:	00 
     28d:	c4 42 7d 3d fd       	vpmaxsd %ymm13,%ymm0,%ymm15
     292:	c4 c2 7d 39 f5       	vpminsd %ymm13,%ymm0,%ymm6
     297:	c5 15 fe d8          	vpaddd %ymm0,%ymm13,%ymm11
     29b:	c5 d5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm5
     2a0:	c4 e2 05 3d f9       	vpmaxsd %ymm1,%ymm15,%ymm7
     2a5:	c4 62 4d 39 c1       	vpminsd %ymm1,%ymm6,%ymm8
     2aa:	c5 7e 7f 9c 24 00 01 	vmovdqu %ymm11,0x100(%rsp)
     2b1:	00 00 
     2b3:	c5 79 6e df          	vmovd  %edi,%xmm11
     2b7:	c4 c1 45 fe d8       	vpaddd %ymm8,%ymm7,%ymm3
     2bc:	c5 cd 66 f1          	vpcmpgtd %ymm1,%ymm6,%ymm6
     2c0:	c4 42 7d 58 db       	vpbroadcastd %xmm11,%ymm11
     2c5:	c5 fe 7f 9c 24 e0 00 	vmovdqu %ymm3,0xe0(%rsp)
     2cc:	00 00 
     2ce:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     2d3:	c4 41 75 66 ff       	vpcmpgtd %ymm15,%ymm1,%ymm15
     2d8:	c5 f9 6e db          	vmovd  %ebx,%xmm3
     2dc:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     2e1:	c5 7e 7f 1c 24       	vmovdqu %ymm11,(%rsp)
     2e6:	8d 5c 1f 01          	lea    0x1(%rdi,%rbx,1),%ebx
     2ea:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
     2ef:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     2f3:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     2f7:	c5 7d 7f ca          	vmovdqa %ymm9,%ymm2
     2fb:	c4 e2 6d 90 24 a9    	vpgatherdd %ymm2,(%rcx,%ymm5,4),%ymm4
     301:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
     307:	c4 41 5d db de       	vpand  %ymm14,%ymm4,%ymm11
     30c:	c4 c1 6d 72 f3 10    	vpslld $0x10,%ymm11,%ymm2
     312:	c5 fe 7f 94 24 60 01 	vmovdqu %ymm2,0x160(%rsp)
     319:	00 00 
     31b:	c5 f9 6e d3          	vmovd  %ebx,%xmm2
     31f:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     324:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     328:	c5 fe 7f 94 24 20 01 	vmovdqu %ymm2,0x120(%rsp)
     32f:	00 00 
     331:	c5 7d 6f e2          	vmovdqa %ymm2,%ymm12
     335:	c4 e2 2d 90 2c 91    	vpgatherdd %ymm10,(%rcx,%ymm2,4),%ymm5
     33b:	c5 95 66 d0          	vpcmpgtd %ymm0,%ymm13,%ymm2
     33f:	c4 41 7d 6f d1       	vmovdqa %ymm9,%ymm10
     344:	c4 c1 7d 66 c5       	vpcmpgtd %ymm13,%ymm0,%ymm0
     349:	c4 e3 65 4c 14 24 20 	vpblendvb %ymm2,(%rsp),%ymm3,%ymm2
     350:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm2,%ymm2        # 379 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x379>
     357:	00 00 60 
     35a:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
     35e:	c4 e2 2d 90 34 91    	vpgatherdd %ymm10,(%rcx,%ymm2,4),%ymm6
     364:	c4 41 7d 6f d1       	vmovdqa %ymm9,%ymm10
     369:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
     370:	00 00 
     372:	c4 e3 65 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm3,%ymm0
     379:	c5 f5 fa 8c 24 e0 00 	vpsubd 0xe0(%rsp),%ymm1,%ymm1
     380:	00 00 
     382:	c5 8d db 94 24 c0 00 	vpand  0xc0(%rsp),%ymm14,%ymm2
     389:	00 00 
     38b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm15,0x1f(%rip),%ymm0,%ymm0        # 3b4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x3b4>
     392:	00 00 f0 
     395:	c5 85 72 d4 10       	vpsrld $0x10,%ymm4,%ymm15
     39a:	c4 c1 55 db f6       	vpand  %ymm14,%ymm5,%ymm6
     39f:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
     3a3:	c5 fd fe 44 24 20    	vpaddd 0x20(%rsp),%ymm0,%ymm0
     3a9:	c5 f5 fe 8c 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm1
     3b0:	00 00 
     3b2:	c4 41 05 db e6       	vpand  %ymm14,%ymm15,%ymm12
     3b7:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
     3bb:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     3c0:	c4 62 2d 90 2c 81    	vpgatherdd %ymm10,(%rcx,%ymm0,4),%ymm13
     3c6:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     3cb:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     3d1:	c5 7e 6f a4 24 80 01 	vmovdqu 0x180(%rsp),%ymm12
     3d8:	00 00 
     3da:	c4 c1 15 db c6       	vpand  %ymm14,%ymm13,%ymm0
     3df:	c5 7e 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm10
     3e5:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     3ea:	c5 ed fa d0          	vpsubd %ymm0,%ymm2,%ymm2
     3ee:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
     3f3:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
     3f8:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
     3fd:	c4 c1 05 72 f2 10    	vpslld $0x10,%ymm10,%ymm15
     403:	c5 1d fe 94 24 60 01 	vpaddd 0x160(%rsp),%ymm12,%ymm10
     40a:	00 00 
     40c:	c4 41 05 fe fc       	vpaddd %ymm12,%ymm15,%ymm15
     411:	c5 7e 7f bc 24 40 01 	vmovdqu %ymm15,0x140(%rsp)
     418:	00 00 
     41a:	c5 85 72 f4 10       	vpslld $0x10,%ymm4,%ymm15
     41f:	c4 41 05 fe fc       	vpaddd %ymm12,%ymm15,%ymm15
     424:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     428:	c4 c1 6d fe d2       	vpaddd %ymm10,%ymm2,%ymm2
     42d:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     431:	c5 fd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm0
     436:	c5 fe 7f 84 24 e0 00 	vmovdqu %ymm0,0xe0(%rsp)
     43d:	00 00 
     43f:	c5 fd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm0
     444:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     449:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
     44e:	c4 41 55 db de       	vpand  %ymm14,%ymm5,%ymm11
     453:	0f 85 f7 fc ff ff    	jne    150 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x150>
     459:	48 8b 5a 28          	mov    0x28(%rdx),%rbx
     45d:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
     463:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     467:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
     46c:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
     473:	00 00 
     475:	48 83 c2 60          	add    $0x60,%rdx
     479:	c4 e2 45 90 2c 8b    	vpgatherdd %ymm7,(%rbx,%ymm1,4),%ymm5
     47f:	48 8b 5a c0          	mov    -0x40(%rdx),%rbx
     483:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
     48a:	00 00 
     48c:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     490:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 4f8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4f8>
     497:	00 
     498:	c4 e2 45 90 34 8b    	vpgatherdd %ymm7,(%rbx,%ymm1,4),%ymm6
     49e:	48 8b 5a b8          	mov    -0x48(%rdx),%rbx
     4a2:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     4a6:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 50e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x50e>
     4ad:	00 
     4ae:	c4 e2 45 90 0c 93    	vpgatherdd %ymm7,(%rbx,%ymm2,4),%ymm1
     4b4:	48 8b 5a e0          	mov    -0x20(%rdx),%rbx
     4b8:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 520 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x520>
     4bf:	00 
     4c0:	c4 62 75 3d d6       	vpmaxsd %ymm6,%ymm1,%ymm10
     4c5:	c5 cd 66 f9          	vpcmpgtd %ymm1,%ymm6,%ymm7
     4c9:	c4 62 75 39 c6       	vpminsd %ymm6,%ymm1,%ymm8
     4ce:	c4 c1 55 66 d2       	vpcmpgtd %ymm10,%ymm5,%ymm2
     4d3:	c4 62 3d 39 ed       	vpminsd %ymm5,%ymm8,%ymm13
     4d8:	c4 62 2d 3d d5       	vpmaxsd %ymm5,%ymm10,%ymm10
     4dd:	c5 3d 66 c5          	vpcmpgtd %ymm5,%ymm8,%ymm8
     4e1:	c4 e3 65 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm3,%ymm7
     4e8:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm7,%ymm7        # 511 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x511>
     4ef:	00 00 20 
     4f2:	c5 c5 fe 7c 24 20    	vpaddd 0x20(%rsp),%ymm7,%ymm7
     4f8:	c4 e2 1d 90 14 b9    	vpgatherdd %ymm12,(%rcx,%ymm7,4),%ymm2
     4fe:	c5 f5 66 fe          	vpcmpgtd %ymm6,%ymm1,%ymm7
     502:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
     507:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     50c:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     510:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     515:	c4 e3 65 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm3,%ymm7
     51c:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm7,%ymm7        # 545 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x545>
     523:	00 00 80 
     526:	c5 7e 6f 84 24 20 01 	vmovdqu 0x120(%rsp),%ymm8
     52d:	00 00 
     52f:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
     533:	c4 62 1d 90 04 b9    	vpgatherdd %ymm12,(%rcx,%ymm7,4),%ymm8
     539:	c4 c1 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm7
     53e:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
     543:	c4 c1 3d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm8
     549:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
     54d:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
     553:	c4 41 3d db c6       	vpand  %ymm14,%ymm8,%ymm8
     558:	c5 d5 fe c9          	vpaddd %ymm1,%ymm5,%ymm1
     55c:	c4 c1 7d fa c0       	vpsubd %ymm8,%ymm0,%ymm0
     561:	c5 bd fa ea          	vpsubd %ymm2,%ymm8,%ymm5
     565:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
     56a:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
     56f:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     573:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
     577:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
     57c:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     580:	c4 e2 5d 90 04 bb    	vpgatherdd %ymm4,(%rbx,%ymm7,4),%ymm0
     586:	48 8b 5a d8          	mov    -0x28(%rdx),%rbx
     58a:	c5 fe 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm7
     591:	00 00 
     593:	c5 7d 7f cc          	vmovdqa %ymm9,%ymm4
     597:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 5ff <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5ff>
     59e:	00 
     59f:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
     5a4:	c4 e2 5d 90 2c bb    	vpgatherdd %ymm4,(%rbx,%ymm7,4),%ymm5
     5aa:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
     5b1:	00 00 
     5b3:	48 8b 5a d0          	mov    -0x30(%rdx),%rbx
     5b7:	c5 7d 7f cf          	vmovdqa %ymm9,%ymm7
     5bb:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 623 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x623>
     5c2:	00 
     5c3:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     5c8:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     5cc:	c4 e2 45 90 24 b3    	vpgatherdd %ymm7,(%rbx,%ymm6,4),%ymm4
     5d2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     5d7:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 63f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x63f>
     5de:	00 
     5df:	c5 7d 6f f9          	vmovdqa %ymm1,%ymm15
     5e3:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
     5e8:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
     5ec:	c4 62 5d 39 c5       	vpminsd %ymm5,%ymm4,%ymm8
     5f1:	c5 fd 66 d7          	vpcmpgtd %ymm7,%ymm0,%ymm2
     5f5:	c4 62 3d 39 d0       	vpminsd %ymm0,%ymm8,%ymm10
     5fa:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
     5ff:	c5 3d 66 c0          	vpcmpgtd %ymm0,%ymm8,%ymm8
     603:	c4 c3 65 4c f5 60    	vpblendvb %ymm6,%ymm13,%ymm3,%ymm6
     609:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm6,%ymm6        # 632 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x632>
     610:	00 00 20 
     613:	c5 cd fe 74 24 20    	vpaddd 0x20(%rsp),%ymm6,%ymm6
     619:	c4 e2 1d 90 14 b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm2
     61f:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
     623:	c4 41 7d 6f e1       	vmovdqa %ymm9,%ymm12
     628:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     62d:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     631:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
     636:	c4 c3 65 4c dd 60    	vpblendvb %ymm6,%ymm13,%ymm3,%ymm3
     63c:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 665 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x665>
     643:	00 00 80 
     646:	c5 7e 6f 84 24 20 01 	vmovdqu 0x120(%rsp),%ymm8
     64d:	00 00 
     64f:	c5 bd fa db          	vpsubd %ymm3,%ymm8,%ymm3
     653:	c4 e2 1d 90 34 99    	vpgatherdd %ymm12,(%rcx,%ymm3,4),%ymm6
     659:	c4 c1 45 fe da       	vpaddd %ymm10,%ymm7,%ymm3
     65e:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     663:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     667:	c4 c1 4d db f6       	vpand  %ymm14,%ymm6,%ymm6
     66c:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     670:	c5 cd fa da          	vpsubd %ymm2,%ymm6,%ymm3
     674:	c5 ed fa 54 24 40    	vpsubd 0x40(%rsp),%ymm2,%ymm2
     67a:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     67f:	c5 a5 fa de          	vpsubd %ymm6,%ymm11,%ymm3
     683:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
     688:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     68d:	c5 ed fe 94 24 40 01 	vpaddd 0x140(%rsp),%ymm2,%ymm2
     694:	00 00 
     696:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     69a:	c5 fd fe d2          	vpaddd %ymm2,%ymm0,%ymm2
     69e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     6a3:	c5 fd 6f c2          	vmovdqa %ymm2,%ymm0
     6a7:	49 39 d3             	cmp    %rdx,%r11
     6aa:	74 14                	je     6c0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c0>
     6ac:	c5 fe 7f 8c 24 80 00 	vmovdqu %ymm1,0x80(%rsp)
     6b3:	00 00 
     6b5:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
     6bb:	e9 49 fb ff ff       	jmp    209 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x209>
     6c0:	c5 fe 6f 8c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm1
     6c7:	00 00 
     6c9:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     6cd:	c5 ed 72 f4 08       	vpslld $0x8,%ymm4,%ymm2
     6d2:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
     6d7:	49 83 c0 18          	add    $0x18,%r8
     6db:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
     6df:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     6e3:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
     6ea:	01 00 00 
     6ed:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     6f1:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     6f7:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     6fc:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     701:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     705:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     70b:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     711:	4d 39 c1             	cmp    %r8,%r9
     714:	0f 85 ce f9 ff ff    	jne    e8 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe8>
     71a:	c5 f8 77             	vzeroupper
     71d:	c5 f8 28 b4 24 10 03 	vmovaps 0x310(%rsp),%xmm6
     724:	00 00 
     726:	c5 f8 28 bc 24 20 03 	vmovaps 0x320(%rsp),%xmm7
     72d:	00 00 
     72f:	c5 78 28 84 24 30 03 	vmovaps 0x330(%rsp),%xmm8
     736:	00 00 
     738:	c5 78 28 8c 24 40 03 	vmovaps 0x340(%rsp),%xmm9
     73f:	00 00 
     741:	c5 78 28 94 24 50 03 	vmovaps 0x350(%rsp),%xmm10
     748:	00 00 
     74a:	c5 78 28 9c 24 60 03 	vmovaps 0x360(%rsp),%xmm11
     751:	00 00 
     753:	c5 78 28 a4 24 70 03 	vmovaps 0x370(%rsp),%xmm12
     75a:	00 00 
     75c:	c5 78 28 ac 24 80 03 	vmovaps 0x380(%rsp),%xmm13
     763:	00 00 
     765:	c5 78 28 b4 24 90 03 	vmovaps 0x390(%rsp),%xmm14
     76c:	00 00 
     76e:	c5 78 28 bc 24 a0 03 	vmovaps 0x3a0(%rsp),%xmm15
     775:	00 00 
     777:	48 81 c4 b8 03 00 00 	add    $0x3b8,%rsp
     77e:	5b                   	pop    %rbx
     77f:	5e                   	pop    %rsi
     780:	5f                   	pop    %rdi
     781:	5d                   	pop    %rbp
     782:	41 5c                	pop    %r12
     784:	41 5d                	pop    %r13
     786:	41 5e                	pop    %r14
     788:	41 5f                	pop    %r15
     78a:	c3                   	ret
     78b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     790:	c5 fd 6f e2          	vmovdqa %ymm2,%ymm4
     794:	e9 34 ff ff ff       	jmp    6cd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6cd>
     799:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
     79d:	0f 85 da f8 ff ff    	jne    7d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     7a3:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
     7aa:	0f 84 cd f8 ff ff    	je     7d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     7b0:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
     7b7:	0f 84 c0 f8 ff ff    	je     7d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     7bd:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
     7c4:	0f 84 b3 f8 ff ff    	je     7d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d>
     7ca:	4d 85 c9             	test   %r9,%r9
     7cd:	0f 84 4a ff ff ff    	je     71d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71d>
     7d3:	48 8b 31             	mov    (%rcx),%rsi
     7d6:	48 8b 79 08          	mov    0x8(%rcx),%rdi
     7da:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
     7df:	48 8b 59 60          	mov    0x60(%rcx),%rbx
     7e3:	44 8b b1 b0 00 00 00 	mov    0xb0(%rcx),%r14d
     7ea:	c4 c1 1d 72 d6 18    	vpsrld $0x18,%ymm14,%ymm12
     7f0:	44 8b b9 b4 00 00 00 	mov    0xb4(%rcx),%r15d
     7f7:	48 8b 51 48          	mov    0x48(%rcx),%rdx
     7fb:	48 89 b4 24 58 02 00 	mov    %rsi,0x258(%rsp)
     802:	00 
     803:	48 8b 71 10          	mov    0x10(%rcx),%rsi
     807:	4c 8b 99 a8 00 00 00 	mov    0xa8(%rcx),%r11
     80e:	48 89 bc 24 60 02 00 	mov    %rdi,0x260(%rsp)
     815:	00 
     816:	48 89 9c 24 78 02 00 	mov    %rbx,0x278(%rsp)
     81d:	00 
     81e:	48 8b 79 18          	mov    0x18(%rcx),%rdi
     822:	48 8b 59 68          	mov    0x68(%rcx),%rbx
     826:	48 89 b4 24 68 02 00 	mov    %rsi,0x268(%rsp)
     82d:	00 
     82e:	48 8b 71 20          	mov    0x20(%rcx),%rsi
     832:	48 89 bc 24 a8 02 00 	mov    %rdi,0x2a8(%rsp)
     839:	00 
     83a:	48 89 9c 24 70 02 00 	mov    %rbx,0x270(%rsp)
     841:	00 
     842:	48 8b 79 28          	mov    0x28(%rcx),%rdi
     846:	48 8b 59 70          	mov    0x70(%rcx),%rbx
     84a:	48 89 b4 24 a0 02 00 	mov    %rsi,0x2a0(%rsp)
     851:	00 
     852:	48 8b 71 30          	mov    0x30(%rcx),%rsi
     856:	48 89 bc 24 98 02 00 	mov    %rdi,0x298(%rsp)
     85d:	00 
     85e:	48 89 9c 24 b0 02 00 	mov    %rbx,0x2b0(%rsp)
     865:	00 
     866:	48 8b 79 38          	mov    0x38(%rcx),%rdi
     86a:	48 8b 99 c0 00 00 00 	mov    0xc0(%rcx),%rbx
     871:	48 89 b4 24 90 02 00 	mov    %rsi,0x290(%rsp)
     878:	00 
     879:	48 8b 71 40          	mov    0x40(%rcx),%rsi
     87d:	48 89 bc 24 88 02 00 	mov    %rdi,0x288(%rsp)
     884:	00 
     885:	48 89 9c 24 b8 02 00 	mov    %rbx,0x2b8(%rsp)
     88c:	00 
     88d:	8b 79 54             	mov    0x54(%rcx),%edi
     890:	48 89 b4 24 80 02 00 	mov    %rsi,0x280(%rsp)
     897:	00 
     898:	8b 71 50             	mov    0x50(%rcx),%esi
     89b:	48 8b 99 c8 00 00 00 	mov    0xc8(%rcx),%rbx
     8a2:	44 8b a8 74 01 00 00 	mov    0x174(%rax),%r13d
     8a9:	8b a9 10 01 00 00    	mov    0x110(%rcx),%ebp
     8af:	44 8b a1 14 01 00 00 	mov    0x114(%rcx),%r12d
     8b6:	48 89 9c 24 c0 02 00 	mov    %rbx,0x2c0(%rsp)
     8bd:	00 
     8be:	48 8b 99 d0 00 00 00 	mov    0xd0(%rcx),%rbx
     8c5:	4c 8b 91 08 01 00 00 	mov    0x108(%rcx),%r10
     8cc:	48 89 9c 24 c8 02 00 	mov    %rbx,0x2c8(%rsp)
     8d3:	00 
     8d4:	48 8b 99 20 01 00 00 	mov    0x120(%rcx),%rbx
     8db:	48 89 9c 24 40 02 00 	mov    %rbx,0x240(%rsp)
     8e2:	00 
     8e3:	48 8b 99 28 01 00 00 	mov    0x128(%rcx),%rbx
     8ea:	48 89 9c 24 48 02 00 	mov    %rbx,0x248(%rsp)
     8f1:	00 
     8f2:	48 8b 99 30 01 00 00 	mov    0x130(%rcx),%rbx
     8f9:	48 8b 89 68 01 00 00 	mov    0x168(%rcx),%rcx
     900:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
     907:	00 
     908:	8b 98 70 01 00 00    	mov    0x170(%rax),%ebx
     90e:	8d 44 37 01          	lea    0x1(%rdi,%rsi,1),%eax
     912:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     916:	43 8d 44 3e 01       	lea    0x1(%r14,%r15,1),%eax
     91b:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     920:	c5 fe 7f a4 24 20 02 	vmovdqu %ymm4,0x220(%rsp)
     927:	00 00 
     929:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     92d:	41 8d 44 2c 01       	lea    0x1(%r12,%rbp,1),%eax
     932:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     937:	c5 fe 7f a4 24 00 02 	vmovdqu %ymm4,0x200(%rsp)
     93e:	00 00 
     940:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     944:	42 8d 44 2b 01       	lea    0x1(%rbx,%r13,1),%eax
     949:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     94e:	c5 fe 7f a4 24 e0 01 	vmovdqu %ymm4,0x1e0(%rsp)
     955:	00 00 
     957:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     95b:	49 8d 41 ff          	lea    -0x1(%r9),%rax
     95f:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     964:	48 c1 e8 03          	shr    $0x3,%rax
     968:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
     96f:	00 00 
     971:	c5 f9 6e e7          	vmovd  %edi,%xmm4
     975:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
     979:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     97e:	4d 8d 4c c0 18       	lea    0x18(%r8,%rax,8),%r9
     983:	b8 00 80 00 00       	mov    $0x8000,%eax
     988:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
     98d:	c5 f9 6e e6          	vmovd  %esi,%xmm4
     991:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     996:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     99c:	c4 c1 79 6e e7       	vmovd  %r15d,%xmm4
     9a1:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9a6:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
     9ac:	c4 c1 79 6e e6       	vmovd  %r14d,%xmm4
     9b1:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9b6:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
     9bc:	c4 c1 79 6e e4       	vmovd  %r12d,%xmm4
     9c1:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9c6:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
     9cd:	00 00 
     9cf:	c5 f9 6e e5          	vmovd  %ebp,%xmm4
     9d3:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9d8:	c5 fe 7f a4 24 a0 00 	vmovdqu %ymm4,0xa0(%rsp)
     9df:	00 00 
     9e1:	c4 c1 79 6e e5       	vmovd  %r13d,%xmm4
     9e6:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9eb:	c5 fe 7f a4 24 c0 00 	vmovdqu %ymm4,0xc0(%rsp)
     9f2:	00 00 
     9f4:	c5 f9 6e e3          	vmovd  %ebx,%xmm4
     9f8:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     9fd:	c5 fe 7f a4 24 e0 00 	vmovdqu %ymm4,0xe0(%rsp)
     a04:	00 00 
     a06:	c5 fd 6f 25 00 00 00 	vmovdqa 0x0(%rip),%ymm4        # a0e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa0e>
     a0d:	00 
     a0e:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
     a15:	00 00 
     a17:	c5 fd 6f 25 40 00 00 	vmovdqa 0x40(%rip),%ymm4        # a5f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa5f>
     a1e:	00 
     a1f:	c5 fe 7f a4 24 c0 01 	vmovdqu %ymm4,0x1c0(%rsp)
     a26:	00 00 
     a28:	c5 f9 6e e0          	vmovd  %eax,%xmm4
     a2c:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     a31:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
     a38:	00 00 
     a3a:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     a3f:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     a45:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     a49:	49 83 c0 18          	add    $0x18,%r8
     a4d:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
     a54:	00 
     a55:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     a5a:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     a60:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     a66:	c4 e2 7d 00 84 24 a0 	vpshufb 0x1a0(%rsp),%ymm0,%ymm0
     a6d:	01 00 00 
     a70:	c5 bd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm8
     a75:	c5 a5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm11
     a7a:	c4 c1 7d db fc       	vpand  %ymm12,%ymm0,%ymm7
     a7f:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
     a85:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     a8c:	00 00 
     a8e:	c4 41 3d db c4       	vpand  %ymm12,%ymm8,%ymm8
     a93:	c4 e2 5d 90 0c b8    	vpgatherdd %ymm4,(%rax,%ymm7,4),%ymm1
     a99:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
     aa0:	00 
     aa1:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     aa5:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
     aa9:	c4 a2 5d 90 34 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm6
     aaf:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
     ab6:	00 
     ab7:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     abb:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     ac0:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # b28 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb28>
     ac7:	00 
     ac8:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     acd:	c4 a2 5d 90 1c 98    	vpgatherdd %ymm4,(%rax,%ymm11,4),%ymm3
     ad3:	c5 dd 72 d1 11       	vpsrld $0x11,%ymm1,%ymm4
     ad8:	c5 d5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm5
     add:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # b45 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb45>
     ae4:	00 
     ae5:	c4 e2 5d 40 64 24 20 	vpmulld 0x20(%rsp),%ymm4,%ymm4
     aec:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # b54 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb54>
     af3:	00 
     af4:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     af8:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     afc:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     b00:	c5 6d fe 8c 24 20 02 	vpaddd 0x220(%rsp),%ymm2,%ymm9
     b07:	00 00 
     b09:	c4 e2 45 90 24 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm4
     b0f:	c4 a2 55 90 3c 8a    	vpgatherdd %ymm5,(%rdx,%ymm9,4),%ymm7
     b15:	c5 cd 66 e9          	vpcmpgtd %ymm1,%ymm6,%ymm5
     b19:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
     b20:	00 00 
     b22:	c4 e2 75 3d fe       	vpmaxsd %ymm6,%ymm1,%ymm7
     b27:	c5 65 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm10
     b2b:	c4 62 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm15
     b30:	c4 e2 75 39 fe       	vpminsd %ymm6,%ymm1,%ymm7
     b35:	c4 c3 7d 4c ed 50    	vpblendvb %ymm5,%ymm13,%ymm0,%ymm5
     b3b:	c5 7e 7f bc 24 60 01 	vmovdqu %ymm15,0x160(%rsp)
     b42:	00 00 
     b44:	c4 e2 45 39 c3       	vpminsd %ymm3,%ymm7,%ymm0
     b49:	c4 41 5d db ec       	vpand  %ymm12,%ymm4,%ymm13
     b4e:	c5 c5 66 fb          	vpcmpgtd %ymm3,%ymm7,%ymm7
     b52:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # b7b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb7b>
     b59:	00 00 a0 
     b5c:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     b61:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     b65:	c4 62 2d 90 3c aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm15
     b6b:	c5 f5 66 ee          	vpcmpgtd %ymm6,%ymm1,%ymm5
     b6f:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     b75:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     b79:	c4 e3 2d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm10,%ymm5
     b80:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # ba9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xba9>
     b87:	00 00 70 
     b8a:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
     b8e:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     b92:	c4 62 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm10
     b98:	c4 c1 05 db ec       	vpand  %ymm12,%ymm15,%ymm5
     b9d:	c5 7d fe bc 24 60 01 	vpaddd 0x160(%rsp),%ymm0,%ymm15
     ba4:	00 00 
     ba6:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
     bad:	00 
     bae:	c4 41 2d db d4       	vpand  %ymm12,%ymm10,%ymm10
     bb3:	c4 c1 45 72 f5 10    	vpslld $0x10,%ymm13,%ymm7
     bb9:	c5 fe 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm6
     bc0:	00 00 
     bc2:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
     bc7:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     bcb:	c5 ad fa dd          	vpsubd %ymm5,%ymm10,%ymm3
     bcf:	c4 e2 75 40 db       	vpmulld %ymm3,%ymm1,%ymm3
     bd4:	c5 c5 fe 8c 24 40 01 	vpaddd 0x140(%rsp),%ymm7,%ymm1
     bdb:	00 00 
     bdd:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
     be2:	c4 e2 55 40 ac 24 60 	vpmulld 0x160(%rsp),%ymm5,%ymm5
     be9:	01 00 00 
     bec:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     bf0:	c5 9d db 9c 24 20 01 	vpand  0x120(%rsp),%ymm12,%ymm3
     bf7:	00 00 
     bf9:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     bfe:	c4 e2 65 40 d8       	vpmulld %ymm0,%ymm3,%ymm3
     c03:	c5 fe 6f 44 24 20    	vmovdqu 0x20(%rsp),%ymm0
     c09:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     c0d:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     c11:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     c15:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     c1a:	c5 fe 7f 8c 24 d0 02 	vmovdqu %ymm1,0x2d0(%rsp)
     c21:	00 00 
     c23:	c4 a2 55 90 1c 98    	vpgatherdd %ymm5,(%rax,%ymm11,4),%ymm3
     c29:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
     c30:	00 
     c31:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     c35:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # c9d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc9d>
     c3c:	00 
     c3d:	c4 a2 55 90 3c 80    	vpgatherdd %ymm5,(%rax,%ymm8,4),%ymm7
     c43:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
     c4a:	00 
     c4b:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     c4f:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # cb7 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcb7>
     c56:	00 
     c57:	c4 e2 55 90 0c b0    	vpgatherdd %ymm5,(%rax,%ymm6,4),%ymm1
     c5d:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # cc5 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcc5>
     c64:	00 
     c65:	c4 e2 75 3d f7       	vpmaxsd %ymm7,%ymm1,%ymm6
     c6a:	c5 c5 66 e9          	vpcmpgtd %ymm1,%ymm7,%ymm5
     c6e:	c5 65 66 d6          	vpcmpgtd %ymm6,%ymm3,%ymm10
     c72:	c4 e3 7d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm0,%ymm5
     c79:	c4 e2 4d 3d c3       	vpmaxsd %ymm3,%ymm6,%ymm0
     c7e:	c4 e2 75 39 f7       	vpminsd %ymm7,%ymm1,%ymm6
     c83:	c4 62 4d 39 eb       	vpminsd %ymm3,%ymm6,%ymm13
     c88:	c5 cd 66 f3          	vpcmpgtd %ymm3,%ymm6,%ymm6
     c8c:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # cb5 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcb5>
     c93:	00 00 a0 
     c96:	c5 7e 7f ac 24 60 01 	vmovdqu %ymm13,0x160(%rsp)
     c9d:	00 00 
     c9f:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     ca3:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     ca8:	c4 62 2d 90 2c aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm13
     cae:	c5 f5 66 ef          	vpcmpgtd %ymm7,%ymm1,%ymm5
     cb2:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     cb8:	c5 f5 fe cf          	vpaddd %ymm7,%ymm1,%ymm1
     cbc:	c4 e3 2d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm10,%ymm5
     cc3:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     cc8:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # cf1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcf1>
     ccf:	00 00 60 
     cd2:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
     cd6:	c4 e2 2d 90 34 aa    	vpgatherdd %ymm10,(%rdx,%ymm5,4),%ymm6
     cdc:	c5 7e 6f 94 24 20 01 	vmovdqu 0x120(%rsp),%ymm10
     ce3:	00 00 
     ce5:	c5 d5 72 d4 08       	vpsrld $0x8,%ymm4,%ymm5
     cea:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
     cef:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     cf4:	c4 41 55 db fc       	vpand  %ymm12,%ymm5,%ymm15
     cf9:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     cff:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
     d05:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
     d0a:	c5 7e 7f 94 24 f0 02 	vmovdqu %ymm10,0x2f0(%rsp)
     d11:	00 00 
     d13:	c5 7e 6f ac 24 60 01 	vmovdqu 0x160(%rsp),%ymm13
     d1a:	00 00 
     d1c:	c4 41 4d db d4       	vpand  %ymm12,%ymm6,%ymm10
     d21:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
     d26:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
     d2c:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
     d33:	00 
     d34:	c5 fe 6f bc 24 00 01 	vmovdqu 0x100(%rsp),%ymm7
     d3b:	00 00 
     d3d:	c5 15 fe e8          	vpaddd %ymm0,%ymm13,%ymm13
     d41:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
     d46:	c5 e5 fe c9          	vpaddd %ymm1,%ymm3,%ymm1
     d4a:	c5 ad fa dd          	vpsubd %ymm5,%ymm10,%ymm3
     d4e:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
     d53:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
     d58:	c5 cd fe 9c 24 40 01 	vpaddd 0x140(%rsp),%ymm6,%ymm3
     d5f:	00 00 
     d61:	c4 e2 55 40 e8       	vpmulld %ymm0,%ymm5,%ymm5
     d66:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     d6a:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
     d6f:	c5 f5 fe db          	vpaddd %ymm3,%ymm1,%ymm3
     d73:	c5 9d db 8c 24 f0 02 	vpand  0x2f0(%rsp),%ymm12,%ymm1
     d7a:	00 00 
     d7c:	c4 c1 75 fa ca       	vpsubd %ymm10,%ymm1,%ymm1
     d81:	c5 7e 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm10
     d87:	c4 e2 75 40 8c 24 60 	vpmulld 0x160(%rsp),%ymm1,%ymm1
     d8e:	01 00 00 
     d91:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     d95:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     d99:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     d9d:	c5 95 72 d3 10       	vpsrld $0x10,%ymm3,%ymm13
     da2:	c4 a2 55 90 1c 98    	vpgatherdd %ymm5,(%rax,%ymm11,4),%ymm3
     da8:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
     daf:	00 
     db0:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
     db5:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # e1d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe1d>
     dbc:	00 
     dbd:	c4 a2 4d 90 2c 80    	vpgatherdd %ymm6,(%rax,%ymm8,4),%ymm5
     dc3:	48 8b 84 24 90 02 00 	mov    0x290(%rsp),%rax
     dca:	00 
     dcb:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
     dcf:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # e37 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe37>
     dd6:	00 
     dd7:	c4 e2 4d 90 0c b8    	vpgatherdd %ymm6,(%rax,%ymm7,4),%ymm1
     ddd:	48 8b 84 24 78 02 00 	mov    0x278(%rsp),%rax
     de4:	00 
     de5:	c5 f5 db 05 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm0        # e4d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe4d>
     dec:	00 
     ded:	c4 e2 7d 3d f5       	vpmaxsd %ymm5,%ymm0,%ymm6
     df2:	c5 d5 66 c8          	vpcmpgtd %ymm0,%ymm5,%ymm1
     df6:	c5 e5 66 fe          	vpcmpgtd %ymm6,%ymm3,%ymm7
     dfa:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
     dff:	c4 c3 2d 4c cb 10    	vpblendvb %ymm1,%ymm11,%ymm10,%ymm1
     e05:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # e2e <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe2e>
     e0c:	00 00 70 
     e0f:	c4 e2 7d 39 fd       	vpminsd %ymm5,%ymm0,%ymm7
     e14:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     e18:	c4 62 45 39 c3       	vpminsd %ymm3,%ymm7,%ymm8
     e1d:	c5 c5 66 fb          	vpcmpgtd %ymm3,%ymm7,%ymm7
     e21:	c4 e2 05 90 0c 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm1
     e27:	c5 fd 66 d5          	vpcmpgtd %ymm5,%ymm0,%ymm2
     e2b:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     e2f:	c5 7e 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm15
     e36:	00 00 
     e38:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     e3d:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
     e42:	c4 c3 2d 4c d3 20    	vpblendvb %ymm2,%ymm11,%ymm10,%ymm2
     e48:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     e4d:	c4 41 4d fe d0       	vpaddd %ymm8,%ymm6,%ymm10
     e52:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # e7b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe7b>
     e59:	00 00 70 
     e5c:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     e61:	c5 b5 fa fa          	vpsubd %ymm2,%ymm9,%ymm7
     e65:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     e69:	c4 e2 25 90 14 ba    	vpgatherdd %ymm11,(%rdx,%ymm7,4),%ymm2
     e6f:	c5 fe 6f bc 24 20 01 	vmovdqu 0x120(%rsp),%ymm7
     e76:	00 00 
     e78:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e7d:	c4 41 6d db cc       	vpand  %ymm12,%ymm2,%ymm9
     e82:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     e87:	c5 b5 fa d9          	vpsubd %ymm1,%ymm9,%ymm3
     e8b:	c5 ed 72 f4 10       	vpslld $0x10,%ymm4,%ymm2
     e90:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
     e95:	c4 e2 7d 40 db       	vpmulld %ymm3,%ymm0,%ymm3
     e9a:	c4 c1 45 fa f9       	vpsubd %ymm9,%ymm7,%ymm7
     e9f:	c5 f5 fa c4          	vpsubd %ymm4,%ymm1,%ymm0
     ea3:	c5 fe 6f a4 24 d0 02 	vmovdqu 0x2d0(%rsp),%ymm4
     eaa:	00 00 
     eac:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     eb1:	c4 c2 45 40 f8       	vpmulld %ymm8,%ymm7,%ymm7
     eb6:	c4 c1 6d fe d7       	vpaddd %ymm15,%ymm2,%ymm2
     ebb:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     ebf:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     ec3:	c4 e2 65 90 0c a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm1
     ec9:	48 8b 84 24 70 02 00 	mov    0x270(%rsp),%rax
     ed0:	00 
     ed1:	c5 c5 fe f8          	vpaddd %ymm0,%ymm7,%ymm7
     ed5:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     ed9:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     edd:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
     ee1:	c4 a2 65 90 24 a8    	vpgatherdd %ymm3,(%rax,%ymm13,4),%ymm4
     ee7:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
     eee:	00 
     eef:	c5 fd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm0
     ef4:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
     ef8:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
     efd:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # f65 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf65>
     f04:	00 
     f05:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
     f0b:	c4 e2 65 90 2c 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm5
     f11:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
     f16:	c4 e2 6d 40 54 24 40 	vpmulld 0x40(%rsp),%ymm2,%ymm2
     f1d:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # f85 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf85>
     f24:	00 
     f25:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
     f2a:	c4 e2 65 40 5c 24 60 	vpmulld 0x60(%rsp),%ymm3,%ymm3
     f31:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     f35:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # f9d <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf9d>
     f3c:	00 
     f3d:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     f41:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
     f46:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
     f4a:	48 8b 84 24 b8 02 00 	mov    0x2b8(%rsp),%rax
     f51:	00 
     f52:	c5 6d fe 9c 24 00 02 	vpaddd 0x200(%rsp),%ymm2,%ymm11
     f59:	00 00 
     f5b:	c4 c2 45 90 1c 93    	vpgatherdd %ymm7,(%r11,%ymm2,4),%ymm3
     f61:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
     f65:	c4 82 45 90 04 9b    	vpgatherdd %ymm7,(%r11,%ymm11,4),%ymm0
     f6b:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
     f70:	c4 e3 15 4c 74 24 40 	vpblendvb %ymm6,0x40(%rsp),%ymm13,%ymm6
     f77:	60 
     f78:	c5 75 fe ec          	vpaddd %ymm4,%ymm1,%ymm13
     f7c:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
     f81:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # faa <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfaa>
     f88:	00 00 70 
     f8b:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
     f90:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
     f94:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
     f99:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
     f9f:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     fa3:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
     fa7:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
     fac:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
     fb1:	c4 c1 65 db ec       	vpand  %ymm12,%ymm3,%ymm5
     fb6:	c4 e3 5d 4c 4c 24 40 	vpblendvb %ymm1,0x40(%rsp),%ymm4,%ymm1
     fbd:	10 
     fbe:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
     fc3:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
     fc8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # ff1 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xff1>
     fcf:	00 00 70 
     fd2:	c4 c2 15 90 34 93    	vpgatherdd %ymm13,(%r11,%ymm2,4),%ymm6
     fd8:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
     fdc:	c5 a5 fa d1          	vpsubd %ymm1,%ymm11,%ymm2
     fe0:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     fe5:	c4 41 4d db dc       	vpand  %ymm12,%ymm6,%ymm11
     fea:	c4 c2 5d 90 0c 93    	vpgatherdd %ymm4,(%r11,%ymm2,4),%ymm1
     ff0:	c4 c1 7d db d4       	vpand  %ymm12,%ymm0,%ymm2
     ff5:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
     ff9:	c4 c1 75 db e4       	vpand  %ymm12,%ymm1,%ymm4
     ffe:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    1003:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1008:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    100c:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    1011:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    1016:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    101b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1020:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    1025:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    102a:	c4 c1 4d db f4       	vpand  %ymm12,%ymm6,%ymm6
    102f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1033:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1037:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    103c:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1040:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1045:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
    104a:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    104f:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1054:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    1059:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    105e:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    1063:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    1067:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    106b:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    1070:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1075:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    107a:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    107f:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    1084:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1089:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    108e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1093:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    1098:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    109d:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    10a2:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    10a6:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    10aa:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    10af:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    10b3:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    10b8:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    10bc:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    10c1:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    10c5:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    10ca:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    10cf:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    10d4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    10d9:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    10dd:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    10e1:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    10e5:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    10e9:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    10ed:	c4 e2 65 90 0c a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm1
    10f3:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
    10fa:	00 
    10fb:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    10ff:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1104:	c4 e2 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm4
    110a:	48 8b 84 24 c8 02 00 	mov    0x2c8(%rsp),%rax
    1111:	00 
    1112:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1116:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    111b:	c4 e2 65 90 2c 80    	vpgatherdd %ymm3,(%rax,%ymm0,4),%ymm5
    1121:	c5 e5 72 d1 11       	vpsrld $0x11,%ymm1,%ymm3
    1126:	c4 e2 6d 40 94 24 80 	vpmulld 0x80(%rsp),%ymm2,%ymm2
    112d:	00 00 00 
    1130:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1198 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1198>
    1137:	00 
    1138:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    113d:	c4 e2 65 40 9c 24 a0 	vpmulld 0xa0(%rsp),%ymm3,%ymm3
    1144:	00 00 00 
    1147:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    114b:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 11b3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11b3>
    1152:	00 
    1153:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    1157:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 11bf <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11bf>
    115e:	00 
    115f:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    1166:	00 00 
    1168:	c5 6d fe 9c 24 e0 01 	vpaddd 0x1e0(%rsp),%ymm2,%ymm11
    116f:	00 00 
    1171:	c4 c2 45 90 1c 92    	vpgatherdd %ymm7,(%r10,%ymm2,4),%ymm3
    1177:	c4 62 75 3d cc       	vpmaxsd %ymm4,%ymm1,%ymm9
    117c:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
    1183:	00 
    1184:	c5 dd 66 f1          	vpcmpgtd %ymm1,%ymm4,%ymm6
    1188:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    118c:	c4 82 45 90 04 9a    	vpgatherdd %ymm7,(%r10,%ymm11,4),%ymm0
    1192:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    1197:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    119c:	c4 e3 15 4c b4 24 80 	vpblendvb %ymm6,0x80(%rsp),%ymm13,%ymm6
    11a3:	00 00 00 60 
    11a7:	c5 75 fe ec          	vpaddd %ymm4,%ymm1,%ymm13
    11ab:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 11d4 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d4>
    11b2:	00 00 70 
    11b5:	c4 e2 75 39 fc       	vpminsd %ymm4,%ymm1,%ymm7
    11ba:	c5 f5 66 cc          	vpcmpgtd %ymm4,%ymm1,%ymm1
    11be:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
    11c3:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
    11ca:	00 00 
    11cc:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    11d0:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    11d4:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
    11d9:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    11de:	c4 c1 65 db ec       	vpand  %ymm12,%ymm3,%ymm5
    11e3:	c4 e3 5d 4c 8c 24 80 	vpblendvb %ymm1,0x80(%rsp),%ymm4,%ymm1
    11ea:	00 00 00 10 
    11ee:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    11f3:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    11f8:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm1,%ymm1        # 1221 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1221>
    11ff:	00 00 70 
    1202:	c4 c2 15 90 34 92    	vpgatherdd %ymm13,(%r10,%ymm2,4),%ymm6
    1208:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    120c:	c5 a5 fa d1          	vpsubd %ymm1,%ymm11,%ymm2
    1210:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    1215:	c4 41 4d db dc       	vpand  %ymm12,%ymm6,%ymm11
    121a:	c4 c2 5d 90 0c 92    	vpgatherdd %ymm4,(%r10,%ymm2,4),%ymm1
    1220:	c4 c1 7d db d4       	vpand  %ymm12,%ymm0,%ymm2
    1225:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    1229:	c4 c1 75 db e4       	vpand  %ymm12,%ymm1,%ymm4
    122e:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    1233:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1238:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    123c:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    1241:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    1246:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    124b:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1250:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    1255:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    125a:	c4 c1 4d db f4       	vpand  %ymm12,%ymm6,%ymm6
    125f:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1263:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1267:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    126c:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    1270:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    1275:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
    127a:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
    127f:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    1284:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    1289:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    128e:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    1293:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    1297:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    129b:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    12a0:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    12a5:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    12aa:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    12af:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    12b4:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    12b9:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    12be:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    12c3:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    12c8:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    12cd:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    12d2:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    12d6:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    12da:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    12df:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    12e3:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    12e8:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    12ec:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    12f1:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    12f5:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    12fa:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    12ff:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    1304:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1309:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    130d:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    1311:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    1315:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1319:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    131d:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1322:	c4 e2 65 90 04 a0    	vpgatherdd %ymm3,(%rax,%ymm4,4),%ymm0
    1328:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
    132f:	00 
    1330:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1334:	c4 e2 65 90 24 90    	vpgatherdd %ymm3,(%rax,%ymm2,4),%ymm4
    133a:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
    1341:	00 
    1342:	c5 7d 7f f3          	vmovdqa %ymm14,%ymm3
    1346:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
    134b:	c4 e2 65 90 2c 88    	vpgatherdd %ymm3,(%rax,%ymm1,4),%ymm5
    1351:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    1356:	c4 e2 6d 40 94 24 c0 	vpmulld 0xc0(%rsp),%ymm2,%ymm2
    135d:	00 00 00 
    1360:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    1365:	c4 e2 65 40 9c 24 e0 	vpmulld 0xe0(%rsp),%ymm3,%ymm3
    136c:	00 00 00 
    136f:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1373:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 13db <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13db>
    137a:	00 
    137b:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 13e3 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13e3>
    1382:	00 
    1383:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1387:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 13ef <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13ef>
    138e:	00 
    138f:	c5 6d fe 9c 24 80 01 	vpaddd 0x180(%rsp),%ymm2,%ymm11
    1396:	00 00 
    1398:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    139c:	c5 7e 6f ac 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm13
    13a3:	00 00 
    13a5:	c4 62 7d 3d cc       	vpmaxsd %ymm4,%ymm0,%ymm9
    13aa:	c5 dd 66 f0          	vpcmpgtd %ymm0,%ymm4,%ymm6
    13ae:	c4 e2 75 90 1c 91    	vpgatherdd %ymm1,(%rcx,%ymm2,4),%ymm3
    13b4:	c4 a2 45 90 0c 99    	vpgatherdd %ymm7,(%rcx,%ymm11,4),%ymm1
    13ba:	c4 c1 55 66 f9       	vpcmpgtd %ymm9,%ymm5,%ymm7
    13bf:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    13c4:	c4 e3 15 4c b4 24 c0 	vpblendvb %ymm6,0xc0(%rsp),%ymm13,%ymm6
    13cb:	00 00 00 60 
    13cf:	c5 7d fe ec          	vpaddd %ymm4,%ymm0,%ymm13
    13d3:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm6,%ymm6        # 13fc <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x13fc>
    13da:	00 00 70 
    13dd:	c4 e2 7d 39 fc       	vpminsd %ymm4,%ymm0,%ymm7
    13e2:	c5 fd 66 c4          	vpcmpgtd %ymm4,%ymm0,%ymm0
    13e6:	c4 62 45 39 d5       	vpminsd %ymm5,%ymm7,%ymm10
    13eb:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    13f2:	00 00 
    13f4:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    13f8:	c5 c5 66 fd          	vpcmpgtd %ymm5,%ymm7,%ymm7
    13fc:	c4 41 35 fe c2       	vpaddd %ymm10,%ymm9,%ymm8
    1401:	c4 41 55 fa c0       	vpsubd %ymm8,%ymm5,%ymm8
    1406:	c4 c1 65 db ec       	vpand  %ymm12,%ymm3,%ymm5
    140b:	c4 e3 5d 4c 84 24 c0 	vpblendvb %ymm0,0xc0(%rsp),%ymm4,%ymm0
    1412:	00 00 00 00 
    1416:	c4 41 3d fe c5       	vpaddd %ymm13,%ymm8,%ymm8
    141b:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    141f:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm0,%ymm0        # 1448 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1448>
    1426:	00 00 70 
    1429:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    142e:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
    1433:	c5 a5 fa c0          	vpsubd %ymm0,%ymm11,%ymm0
    1437:	c4 e2 15 90 34 91    	vpgatherdd %ymm13,(%rcx,%ymm2,4),%ymm6
    143d:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1442:	c4 e2 5d 90 14 81    	vpgatherdd %ymm4,(%rcx,%ymm0,4),%ymm2
    1448:	c4 41 4d db dc       	vpand  %ymm12,%ymm6,%ymm11
    144d:	c4 c1 75 db c4       	vpand  %ymm12,%ymm1,%ymm0
    1452:	c4 c1 6d db e4       	vpand  %ymm12,%ymm2,%ymm4
    1457:	c5 a5 fa ed          	vpsubd %ymm5,%ymm11,%ymm5
    145b:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    145f:	c4 c1 5d fa e3       	vpsubd %ymm11,%ymm4,%ymm4
    1464:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
    1469:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    146e:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1473:	c5 a5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm11
    1478:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    147d:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    1482:	c4 c1 4d db f4       	vpand  %ymm12,%ymm6,%ymm6
    1487:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    148b:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    148f:	c5 c5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm7
    1494:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1498:	c5 d5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm5
    149d:	c4 c1 45 db fc       	vpand  %ymm12,%ymm7,%ymm7
    14a2:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
    14a7:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    14ac:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    14b1:	c5 95 72 f7 10       	vpslld $0x10,%ymm7,%ymm13
    14b6:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    14bb:	c5 a5 fa ff          	vpsubd %ymm7,%ymm11,%ymm7
    14bf:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    14c3:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    14c8:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    14cd:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    14d2:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    14d7:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    14dc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    14e1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    14e6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    14eb:	c4 c1 65 db dc       	vpand  %ymm12,%ymm3,%ymm3
    14f0:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    14f5:	c5 9d db c9          	vpand  %ymm1,%ymm12,%ymm1
    14f9:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    14fd:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    1501:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    1506:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    150a:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    150f:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1513:	c5 d5 72 f3 10       	vpslld $0x10,%ymm3,%ymm5
    1518:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
    151c:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    1521:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    1526:	c4 c1 55 fe ef       	vpaddd %ymm15,%ymm5,%ymm5
    152b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1530:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
    1535:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    1539:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    153d:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1541:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1546:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    154b:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    154f:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    1553:	c4 e2 7d 00 84 24 c0 	vpshufb 0x1c0(%rsp),%ymm0,%ymm0
    155a:	01 00 00 
    155d:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1561:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1567:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    156c:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1571:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1575:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    157b:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1581:	4d 39 c1             	cmp    %r8,%r9
    1584:	0f 85 b0 f4 ff ff    	jne    a3a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa3a>
    158a:	e9 8b f1 ff ff       	jmp    71a <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x71a>
    158f:	90                   	nop
