file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_andn_zext.dir/link.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/andn/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/andn/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_andn_zext.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_andn_zext.dir/outplace_bench.cpp.o.d"
  "libjshc_skylake_andn_zext.pdb"
  "libjshc_skylake_andn_zext.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_andn_zext.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
