# Empty dependencies file for jshc_skylake_andn_split.
# This may be replaced when dependencies are built.
