
artifacts\skylake-stage-major-build-v1\CMakeFiles\jshc_skylake_stage_major.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)>:
       0:	56                   	push   %rsi
       1:	53                   	push   %rbx
       2:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
       9:	c5 f8 29 74 24 60    	vmovaps %xmm6,0x60(%rsp)
       f:	c5 f8 29 7c 24 70    	vmovaps %xmm7,0x70(%rsp)
      15:	c5 78 29 84 24 80 00 	vmovaps %xmm8,0x80(%rsp)
      1c:	00 00 
      1e:	c5 78 29 8c 24 90 00 	vmovaps %xmm9,0x90(%rsp)
      25:	00 00 
      27:	c5 78 29 94 24 a0 00 	vmovaps %xmm10,0xa0(%rsp)
      2e:	00 00 
      30:	c5 78 29 9c 24 b0 00 	vmovaps %xmm11,0xb0(%rsp)
      37:	00 00 
      39:	c5 78 29 a4 24 c0 00 	vmovaps %xmm12,0xc0(%rsp)
      40:	00 00 
      42:	c5 78 29 ac 24 d0 00 	vmovaps %xmm13,0xd0(%rsp)
      49:	00 00 
      4b:	c5 78 29 b4 24 e0 00 	vmovaps %xmm14,0xe0(%rsp)
      52:	00 00 
      54:	c5 78 29 bc 24 f0 00 	vmovaps %xmm15,0xf0(%rsp)
      5b:	00 00 
      5d:	4d 85 c0             	test   %r8,%r8
      60:	0f 84 e8 02 00 00    	je     34e <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x34e>
      66:	8b 59 50             	mov    0x50(%rcx),%ebx
      69:	4c 8b 19             	mov    (%rcx),%r11
      6c:	49 ff c8             	dec    %r8
      6f:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
      74:	4c 8b 51 08          	mov    0x8(%rcx),%r10
      78:	4c 8b 49 10          	mov    0x10(%rcx),%r9
      7c:	49 c1 e8 03          	shr    $0x3,%r8
      80:	48 8b 41 48          	mov    0x48(%rcx),%rax
      84:	8b 49 54             	mov    0x54(%rcx),%ecx
      87:	c5 79 6e eb          	vmovd  %ebx,%xmm13
      8b:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
      90:	8d 74 0b 01          	lea    0x1(%rbx,%rcx,1),%esi
      94:	c5 f9 6e de          	vmovd  %esi,%xmm3
      98:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      9d:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
      a3:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
      a7:	4b 8d 0c 40          	lea    (%r8,%r8,2),%rcx
      ab:	41 b8 00 80 00 00    	mov    $0x8000,%r8d
      b1:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
      b6:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
      bb:	48 8d 4c ca 18       	lea    0x18(%rdx,%rcx,8),%rcx
      c0:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
      c5:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
      ca:	c4 c1 65 72 d3 18    	vpsrld $0x18,%ymm11,%ymm3
      d0:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
      d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
      dd:	00 00 00 
      e0:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
      e4:	c5 fa 7e 4a 10       	vmovq  0x10(%rdx),%xmm1
      e9:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
      ed:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
      f1:	48 83 c2 18          	add    $0x18,%rdx
      f5:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
      fb:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     101:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 10a <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x10a>
     108:	00 00 
     10a:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     10f:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     114:	c5 fd db c3          	vpand  %ymm3,%ymm0,%ymm0
     118:	c4 c2 5d 90 2c 83    	vpgatherdd %ymm4,(%r11,%ymm0,4),%ymm5
     11e:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
     122:	c4 c2 45 90 24 8a    	vpgatherdd %ymm7,(%r10,%ymm1,4),%ymm4
     128:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
     12d:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     131:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
     136:	c4 c2 45 90 34 91    	vpgatherdd %ymm7,(%r9,%ymm2,4),%ymm6
     13c:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     140:	c5 ed 72 d4 11       	vpsrld $0x11,%ymm4,%ymm2
     145:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
     14a:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 1b2 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1b2>
     151:	00 
     152:	c4 e2 6d 40 14 24    	vpmulld (%rsp),%ymm2,%ymm2
     158:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 1c0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1c0>
     15f:	00 
     160:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     164:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     168:	c5 d5 db 05 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm0        # 1d0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1d0>
     16f:	00 
     170:	c5 6d fe 44 24 40    	vpaddd 0x40(%rsp),%ymm2,%ymm8
     176:	c4 e2 45 90 2c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm5
     17c:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
     180:	c4 62 7d 3d d4       	vpmaxsd %ymm4,%ymm0,%ymm10
     185:	c4 62 7d 39 f4       	vpminsd %ymm4,%ymm0,%ymm14
     18a:	c4 a2 45 90 0c 80    	vpgatherdd %ymm7,(%rax,%ymm8,4),%ymm1
     190:	c5 dd 66 f8          	vpcmpgtd %ymm0,%ymm4,%ymm7
     194:	c5 7d fe fc          	vpaddd %ymm4,%ymm0,%ymm15
     198:	c4 41 4d 66 ca       	vpcmpgtd %ymm10,%ymm6,%ymm9
     19d:	c5 fd 66 c4          	vpcmpgtd %ymm4,%ymm0,%ymm0
     1a1:	c4 62 0d 39 e6       	vpminsd %ymm6,%ymm14,%ymm12
     1a6:	c5 0d 66 f6          	vpcmpgtd %ymm6,%ymm14,%ymm14
     1aa:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
     1af:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
     1b3:	c4 e3 15 4c 3c 24 70 	vpblendvb %ymm7,(%rsp),%ymm13,%ymm7
     1ba:	c4 e3 45 4c 3d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm7,%ymm7        # 1e3 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1e3>
     1c1:	00 00 90 
     1c4:	c4 e3 15 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm13,%ymm0
     1cb:	c4 41 2d fe cc       	vpaddd %ymm12,%ymm10,%ymm9
     1d0:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 1f9 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1f9>
     1d7:	00 00 e0 
     1da:	c4 41 4d fa c9       	vpsubd %ymm9,%ymm6,%ymm9
     1df:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     1e3:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
     1e8:	c5 3d fa c0          	vpsubd %ymm0,%ymm8,%ymm8
     1ec:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
     1f1:	c4 e2 05 90 3c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm7
     1f7:	c4 a2 5d 90 14 80    	vpgatherdd %ymm4,(%rax,%ymm8,4),%ymm2
     1fd:	c5 d5 db c3          	vpand  %ymm3,%ymm5,%ymm0
     201:	c5 45 db fb          	vpand  %ymm3,%ymm7,%ymm15
     205:	c5 ed db f3          	vpand  %ymm3,%ymm2,%ymm6
     209:	c5 75 db c3          	vpand  %ymm3,%ymm1,%ymm8
     20d:	c5 8d 72 f0 10       	vpslld $0x10,%ymm0,%ymm14
     212:	c5 3d fa c6          	vpsubd %ymm6,%ymm8,%ymm8
     216:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
     21a:	c4 c1 4d fa f7       	vpsubd %ymm15,%ymm6,%ymm6
     21f:	c4 42 3d 40 c4       	vpmulld %ymm12,%ymm8,%ymm8
     224:	c5 0d fe 74 24 20    	vpaddd 0x20(%rsp),%ymm14,%ymm14
     22a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     22f:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     234:	c5 bd fe c0          	vpaddd %ymm0,%ymm8,%ymm0
     238:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
     23d:	c5 bd 72 d5 08       	vpsrld $0x8,%ymm5,%ymm8
     242:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     246:	c5 8d 72 d7 08       	vpsrld $0x8,%ymm7,%ymm14
     24b:	c5 3d db c3          	vpand  %ymm3,%ymm8,%ymm8
     24f:	c5 dd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm4
     254:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
     259:	c5 0d db f3          	vpand  %ymm3,%ymm14,%ymm14
     25d:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
     262:	c4 c1 05 72 f0 10    	vpslld $0x10,%ymm8,%ymm15
     268:	c5 cd db f3          	vpand  %ymm3,%ymm6,%ymm6
     26c:	c5 fd db c3          	vpand  %ymm3,%ymm0,%ymm0
     270:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     275:	c4 41 0d fa c0       	vpsubd %ymm8,%ymm14,%ymm8
     27a:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
     27e:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     283:	c4 42 3d 40 c2       	vpmulld %ymm10,%ymm8,%ymm8
     288:	c5 7e 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm14
     28e:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
     293:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     298:	c5 d5 db eb          	vpand  %ymm3,%ymm5,%ymm5
     29c:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
     2a1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     2a6:	c4 41 05 fe fe       	vpaddd %ymm14,%ymm15,%ymm15
     2ab:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     2b0:	c5 ed db d3          	vpand  %ymm3,%ymm2,%ymm2
     2b4:	c5 c5 db fb          	vpand  %ymm3,%ymm7,%ymm7
     2b8:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
     2bc:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
     2c0:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
     2c4:	c4 c1 4d fe f7       	vpaddd %ymm15,%ymm6,%ymm6
     2c9:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
     2ce:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
     2d3:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     2d7:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
     2dc:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     2e0:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     2e5:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
     2ea:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
     2ef:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2f4:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
     2f9:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     2fd:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     301:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
     305:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     30a:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
     30f:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     313:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
     317:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 360 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x360>
     31e:	00 00 
     320:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     324:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     32a:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     32f:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     334:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     338:	c5 f9 d6 42 f8       	vmovq  %xmm0,-0x8(%rdx)
     33d:	c5 fa 7f 4a e8       	vmovdqu %xmm1,-0x18(%rdx)
     342:	48 39 d1             	cmp    %rdx,%rcx
     345:	0f 85 95 fd ff ff    	jne    e0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)+0xe0>
     34b:	c5 f8 77             	vzeroupper
     34e:	c5 f8 28 74 24 60    	vmovaps 0x60(%rsp),%xmm6
     354:	c5 f8 28 7c 24 70    	vmovaps 0x70(%rsp),%xmm7
     35a:	c5 78 28 84 24 80 00 	vmovaps 0x80(%rsp),%xmm8
     361:	00 00 
     363:	c5 78 28 8c 24 90 00 	vmovaps 0x90(%rsp),%xmm9
     36a:	00 00 
     36c:	c5 78 28 94 24 a0 00 	vmovaps 0xa0(%rsp),%xmm10
     373:	00 00 
     375:	c5 78 28 9c 24 b0 00 	vmovaps 0xb0(%rsp),%xmm11
     37c:	00 00 
     37e:	c5 78 28 a4 24 c0 00 	vmovaps 0xc0(%rsp),%xmm12
     385:	00 00 
     387:	c5 78 28 ac 24 d0 00 	vmovaps 0xd0(%rsp),%xmm13
     38e:	00 00 
     390:	c5 78 28 b4 24 e0 00 	vmovaps 0xe0(%rsp),%xmm14
     397:	00 00 
     399:	c5 78 28 bc 24 f0 00 	vmovaps 0xf0(%rsp),%xmm15
     3a0:	00 00 
     3a2:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
     3a9:	5b                   	pop    %rbx
     3aa:	5e                   	pop    %rsi
     3ab:	c3                   	ret
     3ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000003b0 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)>:
     3b0:	41 57                	push   %r15
     3b2:	41 56                	push   %r14
     3b4:	41 55                	push   %r13
     3b6:	41 54                	push   %r12
     3b8:	55                   	push   %rbp
     3b9:	57                   	push   %rdi
     3ba:	56                   	push   %rsi
     3bb:	53                   	push   %rbx
     3bc:	48 81 ec c8 01 00 00 	sub    $0x1c8,%rsp
     3c3:	c5 f8 29 b4 24 20 01 	vmovaps %xmm6,0x120(%rsp)
     3ca:	00 00 
     3cc:	c5 f8 29 bc 24 30 01 	vmovaps %xmm7,0x130(%rsp)
     3d3:	00 00 
     3d5:	c5 78 29 84 24 40 01 	vmovaps %xmm8,0x140(%rsp)
     3dc:	00 00 
     3de:	c5 78 29 8c 24 50 01 	vmovaps %xmm9,0x150(%rsp)
     3e5:	00 00 
     3e7:	c5 78 29 94 24 60 01 	vmovaps %xmm10,0x160(%rsp)
     3ee:	00 00 
     3f0:	c5 78 29 9c 24 70 01 	vmovaps %xmm11,0x170(%rsp)
     3f7:	00 00 
     3f9:	c5 78 29 a4 24 80 01 	vmovaps %xmm12,0x180(%rsp)
     400:	00 00 
     402:	c5 78 29 ac 24 90 01 	vmovaps %xmm13,0x190(%rsp)
     409:	00 00 
     40b:	c5 78 29 b4 24 a0 01 	vmovaps %xmm14,0x1a0(%rsp)
     412:	00 00 
     414:	c5 78 29 bc 24 b0 01 	vmovaps %xmm15,0x1b0(%rsp)
     41b:	00 00 
     41d:	49 89 d6             	mov    %rdx,%r14
     420:	4d 85 c0             	test   %r8,%r8
     423:	0f 84 f3 04 00 00    	je     91c <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x56c>
     429:	8b 51 50             	mov    0x50(%rcx),%edx
     42c:	4d 8d 68 ff          	lea    -0x1(%r8),%r13
     430:	4c 8b 21             	mov    (%rcx),%r12
     433:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
     438:	48 8b 69 08          	mov    0x8(%rcx),%rbp
     43c:	48 8b 79 10          	mov    0x10(%rcx),%rdi
     440:	49 c1 ed 03          	shr    $0x3,%r13
     444:	c4 c1 0d 72 d4 18    	vpsrld $0x18,%ymm12,%ymm14
     44a:	48 8b 71 18          	mov    0x18(%rcx),%rsi
     44e:	48 8b 59 20          	mov    0x20(%rcx),%rbx
     452:	c5 79 6e c2          	vmovd  %edx,%xmm8
     456:	4c 8b 41 28          	mov    0x28(%rcx),%r8
     45a:	4c 8b 59 30          	mov    0x30(%rcx),%r11
     45e:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     463:	4c 8b 51 38          	mov    0x38(%rcx),%r10
     467:	4c 8b 49 40          	mov    0x40(%rcx),%r9
     46b:	48 8b 41 48          	mov    0x48(%rcx),%rax
     46f:	8b 49 54             	mov    0x54(%rcx),%ecx
     472:	44 8d 7c 11 01       	lea    0x1(%rcx,%rdx,1),%r15d
     477:	4c 89 f2             	mov    %r14,%rdx
     47a:	c4 c1 79 6e ff       	vmovd  %r15d,%xmm7
     47f:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     484:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
     48b:	00 00 
     48d:	c5 f9 6e f9          	vmovd  %ecx,%xmm7
     491:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
     496:	41 bd 00 80 00 00    	mov    $0x8000,%r13d
     49c:	c4 c1 79 6e f5       	vmovd  %r13d,%xmm6
     4a1:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     4a6:	49 8d 4c ce 18       	lea    0x18(%r14,%rcx,8),%rcx
     4ab:	c4 e2 7d 58 f6       	vpbroadcastd %xmm6,%ymm6
     4b0:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
     4b5:	c5 fe 7f b4 24 a0 00 	vmovdqu %ymm6,0xa0(%rsp)
     4bc:	00 00 
     4be:	66 90                	xchg   %ax,%ax
     4c0:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
     4c4:	c5 fa 7e 4a 10       	vmovq  0x10(%rdx),%xmm1
     4c9:	c5 7d 7f e3          	vmovdqa %ymm12,%ymm3
     4cd:	c5 7d 7f e2          	vmovdqa %ymm12,%ymm2
     4d1:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     4d5:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     4da:	48 83 c2 18          	add    $0x18,%rdx
     4de:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     4e4:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     4ea:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 4f3 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x143>
     4f1:	00 00 
     4f3:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
     4f8:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     4fd:	c4 c1 7d db e6       	vpand  %ymm14,%ymm0,%ymm4
     502:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
     508:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     50d:	c4 c2 65 90 04 a4    	vpgatherdd %ymm3,(%r12,%ymm4,4),%ymm0
     513:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     519:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
     51e:	c4 e2 6d 90 64 8d 00 	vpgatherdd %ymm2,0x0(%rbp,%ymm1,4),%ymm4
     525:	c5 fe 7f b4 24 80 00 	vmovdqu %ymm6,0x80(%rsp)
     52c:	00 00 
     52e:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 596 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x1e6>
     535:	00 
     536:	c4 c2 65 40 d8       	vpmulld %ymm8,%ymm3,%ymm3
     53b:	c5 f5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm1
     540:	c4 e2 55 90 14 b7    	vpgatherdd %ymm5,(%rdi,%ymm6,4),%ymm2
     546:	c5 d5 72 d2 11       	vpsrld $0x11,%ymm2,%ymm5
     54b:	c4 e2 75 40 0c 24    	vpmulld (%rsp),%ymm1,%ymm1
     551:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 5b9 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x209>
     558:	00 
     559:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 5c1 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x211>
     560:	00 
     561:	c4 e2 7d 3d f4       	vpmaxsd %ymm4,%ymm0,%ymm6
     566:	c4 62 7d 39 cc       	vpminsd %ymm4,%ymm0,%ymm9
     56b:	c4 62 35 39 da       	vpminsd %ymm2,%ymm9,%ymm11
     570:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     574:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     578:	c5 ed 66 de          	vpcmpgtd %ymm6,%ymm2,%ymm3
     57c:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     581:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
     585:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     589:	c5 75 fe bc 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm15
     590:	00 00 
     592:	c4 62 55 90 2c 88    	vpgatherdd %ymm5,(%rax,%ymm1,4),%ymm13
     598:	c4 a2 2d 90 2c b8    	vpgatherdd %ymm10,(%rax,%ymm15,4),%ymm5
     59e:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     5a3:	c5 fd 6f fd          	vmovdqa %ymm5,%ymm7
     5a7:	c5 dd 66 e8          	vpcmpgtd %ymm0,%ymm4,%ymm5
     5ab:	c4 e3 3d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm8,%ymm5
     5b2:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm5,%ymm5        # 5db <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x22b>
     5b9:	00 00 30 
     5bc:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
     5c0:	c4 e2 2d 90 1c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm3
     5c6:	c5 fd 66 ec          	vpcmpgtd %ymm4,%ymm0,%ymm5
     5ca:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     5cf:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     5d4:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     5d8:	c4 e3 3d 4c 2c 24 50 	vpblendvb %ymm5,(%rsp),%ymm8,%ymm5
     5df:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm5        # 608 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x258>
     5e6:	00 00 90 
     5e9:	c5 85 fa ed          	vpsubd %ymm5,%ymm15,%ymm5
     5ed:	c4 62 2d 90 0c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm9
     5f3:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
     5f9:	c4 41 4d fe eb       	vpaddd %ymm11,%ymm6,%ymm13
     5fe:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     603:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
     608:	c5 0d db 54 24 60    	vpand  0x60(%rsp),%ymm14,%ymm10
     60e:	c5 ed fe c0          	vpaddd %ymm0,%ymm2,%ymm0
     612:	c5 b5 fa d3          	vpsubd %ymm3,%ymm9,%ymm2
     616:	c4 e2 7d 40 d2       	vpmulld %ymm2,%ymm0,%ymm2
     61b:	c5 8d db c7          	vpand  %ymm7,%ymm14,%ymm0
     61f:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
     624:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
     629:	c4 c1 55 72 f2 10    	vpslld $0x10,%ymm10,%ymm5
     62f:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     634:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     639:	c5 d5 fe ac 24 a0 00 	vpaddd 0xa0(%rsp),%ymm5,%ymm5
     640:	00 00 
     642:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     647:	c4 41 7d 6f cc       	vmovdqa %ymm12,%ymm9
     64c:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
     650:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     654:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
     658:	c5 a5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm11
     65d:	c5 7e 7f 9c 24 e0 00 	vmovdqu %ymm11,0xe0(%rsp)
     664:	00 00 
     666:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     66d:	00 00 
     66f:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     675:	c4 41 7d 6f dc       	vmovdqa %ymm12,%ymm11
     67a:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
     680:	c4 c2 2d 90 2c b0    	vpgatherdd %ymm10,(%r8,%ymm6,4),%ymm5
     686:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     68b:	c4 e2 2d 90 34 9b    	vpgatherdd %ymm10,(%rbx,%ymm3,4),%ymm6
     691:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     696:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 6fe <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x34e>
     69d:	00 
     69e:	c4 e2 2d 90 14 a6    	vpgatherdd %ymm10,(%rsi,%ymm4,4),%ymm2
     6a4:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 70c <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x35c>
     6ab:	00 
     6ac:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 714 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x364>
     6b3:	00 
     6b4:	c4 62 6d 3d d6       	vpmaxsd %ymm6,%ymm2,%ymm10
     6b9:	c5 cd 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm0
     6bd:	c4 e2 6d 39 e6       	vpminsd %ymm6,%ymm2,%ymm4
     6c2:	c4 c1 55 66 da       	vpcmpgtd %ymm10,%ymm5,%ymm3
     6c7:	c4 62 5d 39 ed       	vpminsd %ymm5,%ymm4,%ymm13
     6cc:	c4 62 2d 3d d5       	vpmaxsd %ymm5,%ymm10,%ymm10
     6d1:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
     6d5:	c4 e3 3d 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm8,%ymm0
     6dc:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm0,%ymm0        # 705 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x355>
     6e3:	00 00 30 
     6e6:	c5 f5 fe c0          	vpaddd %ymm0,%ymm1,%ymm0
     6ea:	c4 e2 35 90 1c 80    	vpgatherdd %ymm9,(%rax,%ymm0,4),%ymm3
     6f0:	c5 ed 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm0
     6f4:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     6f8:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
     6ff:	00 00 
     701:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
     706:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
     70b:	c4 e3 3d 4c 04 24 00 	vpblendvb %ymm0,(%rsp),%ymm8,%ymm0
     712:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 73b <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x38b>
     719:	00 00 40 
     71c:	c5 dd 72 d7 08       	vpsrld $0x8,%ymm7,%ymm4
     721:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
     725:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
     72a:	c4 62 25 90 0c 80    	vpgatherdd %ymm11,(%rax,%ymm0,4),%ymm9
     730:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     736:	c5 fe 7f bc 24 c0 00 	vmovdqu %ymm7,0xc0(%rsp)
     73d:	00 00 
     73f:	c4 c1 2d fe fd       	vpaddd %ymm13,%ymm10,%ymm7
     744:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
     74a:	c5 d5 fa ef          	vpsubd %ymm7,%ymm5,%ymm5
     74e:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     752:	c5 a5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm11
     757:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     75c:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
     760:	c4 41 25 db de       	vpand  %ymm14,%ymm11,%ymm11
     765:	c5 b5 fa eb          	vpsubd %ymm3,%ymm9,%ymm5
     769:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
     76e:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
     773:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
     778:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
     77d:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     782:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
     788:	c4 c2 45 90 14 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm2
     78e:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     794:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
     79b:	00 00 
     79d:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     7a1:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 809 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x459>
     7a8:	00 
     7a9:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
     7ad:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
     7b1:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
     7b7:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     7bb:	c4 c2 45 90 24 9a    	vpgatherdd %ymm7,(%r10,%ymm3,4),%ymm4
     7c1:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     7c6:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     7ca:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 832 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x482>
     7d1:	00 
     7d2:	c5 fd 72 f0 08       	vpslld $0x8,%ymm0,%ymm0
     7d7:	c4 c2 45 90 1c b3    	vpgatherdd %ymm7,(%r11,%ymm6,4),%ymm3
     7dd:	c5 7e 6f 1c 24       	vmovdqu (%rsp),%ymm11
     7e2:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 84a <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x49a>
     7e9:	00 
     7ea:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     7ee:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
     7f4:	c4 e2 65 3d f4       	vpmaxsd %ymm4,%ymm3,%ymm6
     7f9:	c5 dd 66 eb          	vpcmpgtd %ymm3,%ymm4,%ymm5
     7fd:	c5 6d 66 ce          	vpcmpgtd %ymm6,%ymm2,%ymm9
     801:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     806:	c4 c3 3d 4c eb 50    	vpblendvb %ymm5,%ymm11,%ymm8,%ymm5
     80c:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm5        # 835 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x485>
     813:	00 00 90 
     816:	c4 62 65 39 cc       	vpminsd %ymm4,%ymm3,%ymm9
     81b:	c5 f5 fe ed          	vpaddd %ymm5,%ymm1,%ymm5
     81f:	c4 62 35 39 d2       	vpminsd %ymm2,%ymm9,%ymm10
     824:	c5 35 66 ca          	vpcmpgtd %ymm2,%ymm9,%ymm9
     828:	c4 e2 45 90 0c a8    	vpgatherdd %ymm7,(%rax,%ymm5,4),%ymm1
     82e:	c5 e5 66 ec          	vpcmpgtd %ymm4,%ymm3,%ymm5
     832:	c5 7d 7f e7          	vmovdqa %ymm12,%ymm7
     836:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     83b:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
     83f:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
     844:	c4 c3 3d 4c eb 50    	vpblendvb %ymm5,%ymm11,%ymm8,%ymm5
     84a:	c4 63 55 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm5,%ymm9        # 873 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x4c3>
     851:	00 00 90 
     854:	c4 41 05 fa c9       	vpsubd %ymm9,%ymm15,%ymm9
     859:	c4 41 4d fe fa       	vpaddd %ymm10,%ymm6,%ymm15
     85e:	c4 a2 45 90 2c 88    	vpgatherdd %ymm7,(%rax,%ymm9,4),%ymm5
     864:	c4 c1 35 72 d5 10    	vpsrld $0x10,%ymm13,%ymm9
     86a:	c4 c1 6d fa d7       	vpsubd %ymm15,%ymm2,%ymm2
     86f:	c5 a5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm11
     874:	c5 fe 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm5
     87b:	00 00 
     87d:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
     882:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     886:	c4 41 25 db de       	vpand  %ymm14,%ymm11,%ymm11
     88b:	c4 c1 15 72 f1 10    	vpslld $0x10,%ymm9,%ymm13
     891:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     896:	c5 a5 fa d9          	vpsubd %ymm1,%ymm11,%ymm3
     89a:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
     89f:	c4 c1 55 db ee       	vpand  %ymm14,%ymm5,%ymm5
     8a4:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     8a9:	c5 15 fe ac 24 a0 00 	vpaddd 0xa0(%rsp),%ymm13,%ymm13
     8b0:	00 00 
     8b2:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
     8b7:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     8bc:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
     8c1:	c4 c1 6d fe d5       	vpaddd %ymm13,%ymm2,%ymm2
     8c6:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
     8ca:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     8ce:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     8d3:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     8d8:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     8dc:	c5 fd eb 84 24 e0 00 	vpor   0xe0(%rsp),%ymm0,%ymm0
     8e3:	00 00 
     8e5:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 92e <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x57e>
     8ec:	00 00 
     8ee:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     8f2:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     8f8:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     8fd:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     902:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     906:	c5 f9 d6 42 f8       	vmovq  %xmm0,-0x8(%rdx)
     90b:	c5 fa 7f 4a e8       	vmovdqu %xmm1,-0x18(%rdx)
     910:	48 39 d1             	cmp    %rdx,%rcx
     913:	0f 85 a7 fb ff ff    	jne    4c0 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)+0x110>
     919:	c5 f8 77             	vzeroupper
     91c:	c5 f8 28 b4 24 20 01 	vmovaps 0x120(%rsp),%xmm6
     923:	00 00 
     925:	c5 f8 28 bc 24 30 01 	vmovaps 0x130(%rsp),%xmm7
     92c:	00 00 
     92e:	c5 78 28 84 24 40 01 	vmovaps 0x140(%rsp),%xmm8
     935:	00 00 
     937:	c5 78 28 8c 24 50 01 	vmovaps 0x150(%rsp),%xmm9
     93e:	00 00 
     940:	c5 78 28 94 24 60 01 	vmovaps 0x160(%rsp),%xmm10
     947:	00 00 
     949:	c5 78 28 9c 24 70 01 	vmovaps 0x170(%rsp),%xmm11
     950:	00 00 
     952:	c5 78 28 a4 24 80 01 	vmovaps 0x180(%rsp),%xmm12
     959:	00 00 
     95b:	c5 78 28 ac 24 90 01 	vmovaps 0x190(%rsp),%xmm13
     962:	00 00 
     964:	c5 78 28 b4 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm14
     96b:	00 00 
     96d:	c5 78 28 bc 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm15
     974:	00 00 
     976:	48 81 c4 c8 01 00 00 	add    $0x1c8,%rsp
     97d:	5b                   	pop    %rbx
     97e:	5e                   	pop    %rsi
     97f:	5f                   	pop    %rdi
     980:	5d                   	pop    %rbp
     981:	41 5c                	pop    %r12
     983:	41 5d                	pop    %r13
     985:	41 5e                	pop    %r14
     987:	41 5f                	pop    %r15
     989:	c3                   	ret
     98a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000000990 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)>:
     990:	56                   	push   %rsi
     991:	53                   	push   %rbx
     992:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
     999:	c5 f8 29 b4 24 60 01 	vmovaps %xmm6,0x160(%rsp)
     9a0:	00 00 
     9a2:	c5 f8 29 bc 24 70 01 	vmovaps %xmm7,0x170(%rsp)
     9a9:	00 00 
     9ab:	c5 78 29 84 24 80 01 	vmovaps %xmm8,0x180(%rsp)
     9b2:	00 00 
     9b4:	c5 78 29 8c 24 90 01 	vmovaps %xmm9,0x190(%rsp)
     9bb:	00 00 
     9bd:	c5 78 29 94 24 a0 01 	vmovaps %xmm10,0x1a0(%rsp)
     9c4:	00 00 
     9c6:	c5 78 29 9c 24 b0 01 	vmovaps %xmm11,0x1b0(%rsp)
     9cd:	00 00 
     9cf:	c5 78 29 a4 24 c0 01 	vmovaps %xmm12,0x1c0(%rsp)
     9d6:	00 00 
     9d8:	c5 78 29 ac 24 d0 01 	vmovaps %xmm13,0x1d0(%rsp)
     9df:	00 00 
     9e1:	c5 78 29 b4 24 e0 01 	vmovaps %xmm14,0x1e0(%rsp)
     9e8:	00 00 
     9ea:	c5 78 29 bc 24 f0 01 	vmovaps %xmm15,0x1f0(%rsp)
     9f1:	00 00 
     9f3:	49 89 ca             	mov    %rcx,%r10
     9f6:	4c 89 c3             	mov    %r8,%rbx
     9f9:	48 83 fa 04          	cmp    $0x4,%rdx
     9fd:	0f 84 b6 06 00 00    	je     10b9 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x729>
     a03:	4d 85 c9             	test   %r9,%r9
     a06:	0f 84 40 06 00 00    	je     104c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6bc>
     a0c:	49 ff c9             	dec    %r9
     a0f:	4c 8d 1c 52          	lea    (%rdx,%rdx,2),%r11
     a13:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
     a18:	49 89 d8             	mov    %rbx,%r8
     a1b:	49 c1 e9 03          	shr    $0x3,%r9
     a1f:	49 c1 e3 05          	shl    $0x5,%r11
     a23:	c4 c1 05 72 d5 18    	vpsrld $0x18,%ymm13,%ymm15
     a29:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
     a2d:	4d 01 d3             	add    %r10,%r11
     a30:	4c 8d 4c c3 18       	lea    0x18(%rbx,%rax,8),%r9
     a35:	b8 00 80 00 00       	mov    $0x8000,%eax
     a3a:	c5 f9 6e d8          	vmovd  %eax,%xmm3
     a3e:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     a43:	c5 fe 7f 9c 24 40 01 	vmovdqu %ymm3,0x140(%rsp)
     a4a:	00 00 
     a4c:	0f 1f 40 00          	nopl   0x0(%rax)
     a50:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     a55:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
     a5b:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
     a61:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
     a67:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # a70 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
     a6e:	00 00 
     a70:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     a75:	c4 c1 75 db c7       	vpand  %ymm15,%ymm1,%ymm0
     a7a:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     a7f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     a84:	48 85 d2             	test   %rdx,%rdx
     a87:	0f 84 23 06 00 00    	je     10b0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x720>
     a8d:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     a93:	4c 89 d0             	mov    %r10,%rax
     a96:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     a9c:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
     aa2:	e9 cb 00 00 00       	jmp    b72 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1e2>
     aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     aae:	00 00 
     ab0:	c5 7e 6f 84 24 80 00 	vmovdqu 0x80(%rsp),%ymm8
     ab7:	00 00 
     ab9:	c5 fd 6f f9          	vmovdqa %ymm1,%ymm7
     abd:	c5 f5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm1
     ac2:	48 83 c0 60          	add    $0x60,%rax
     ac6:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     acb:	c4 c1 6d 72 d0 08    	vpsrld $0x8,%ymm8,%ymm2
     ad1:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     ad6:	c5 dd fa da          	vpsubd %ymm2,%ymm4,%ymm3
     ada:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     ade:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     ae3:	c4 c2 65 40 db       	vpmulld %ymm11,%ymm3,%ymm3
     ae8:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
     aec:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     af1:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
     af5:	c4 c1 6d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm2
     afb:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
     b00:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     b05:	c5 e5 fe d9          	vpaddd %ymm1,%ymm3,%ymm3
     b09:	c5 f5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm1
     b0e:	c5 b5 fa e2          	vpsubd %ymm2,%ymm9,%ymm4
     b12:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     b17:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     b1c:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     b21:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
     b25:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     b2a:	c5 7d 6f e3          	vmovdqa %ymm3,%ymm12
     b2e:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
     b33:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
     b38:	c5 dd fe c2          	vpaddd %ymm2,%ymm4,%ymm0
     b3c:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
     b41:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     b45:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     b4a:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     b4e:	4c 39 d8             	cmp    %r11,%rax
     b51:	0f 84 99 04 00 00    	je     ff0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x660>
     b57:	c5 fe 7f 5c 24 20    	vmovdqu %ymm3,0x20(%rsp)
     b5d:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     b63:	c5 fe 6f 9c 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm3
     b6a:	00 00 
     b6c:	c5 fe 7f 5c 24 60    	vmovdqu %ymm3,0x60(%rsp)
     b72:	48 8b 08             	mov    (%rax),%rcx
     b75:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
     b7b:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     b7f:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     b83:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
     b89:	8b 70 54             	mov    0x54(%rax),%esi
     b8c:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
     b91:	c4 e2 65 90 04 a9    	vpgatherdd %ymm3,(%rcx,%ymm5,4),%ymm0
     b97:	48 8b 48 08          	mov    0x8(%rax),%rcx
     b9b:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     b9f:	8b 58 50             	mov    0x50(%rax),%ebx
     ba2:	c5 79 6e c6          	vmovd  %esi,%xmm8
     ba6:	c5 f5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm1
     bab:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # c13 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x283>
     bb2:	00 
     bb3:	c4 e2 65 90 2c b1    	vpgatherdd %ymm3,(%rcx,%ymm6,4),%ymm5
     bb9:	48 8b 48 10          	mov    0x10(%rax),%rcx
     bbd:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
     bc3:	c5 7d 7f eb          	vmovdqa %ymm13,%ymm3
     bc7:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     bcc:	c5 dd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm4
     bd1:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
     bd5:	c4 e2 65 90 14 b1    	vpgatherdd %ymm3,(%rcx,%ymm6,4),%ymm2
     bdb:	c5 f9 6e db          	vmovd  %ebx,%xmm3
     bdf:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # c47 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2b7>
     be6:	00 
     be7:	48 8b 48 48          	mov    0x48(%rax),%rcx
     beb:	c4 e2 3d 40 e4       	vpmulld %ymm4,%ymm8,%ymm4
     bf0:	c5 cd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm6
     bf5:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     bfa:	c4 e2 65 40 c9       	vpmulld %ymm1,%ymm3,%ymm1
     bff:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # c67 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d7>
     c06:	00 
     c07:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
     c0b:	c5 f9 6e e6          	vmovd  %esi,%xmm4
     c0f:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
     c13:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
     c18:	c5 7d 7f ee          	vmovdqa %ymm13,%ymm6
     c1c:	c5 fe 7f 8c 24 a0 00 	vmovdqu %ymm1,0xa0(%rsp)
     c23:	00 00 
     c25:	c5 5d fe e1          	vpaddd %ymm1,%ymm4,%ymm12
     c29:	c5 d5 66 e0          	vpcmpgtd %ymm0,%ymm5,%ymm4
     c2d:	c4 62 4d 90 14 89    	vpgatherdd %ymm6,(%rcx,%ymm1,4),%ymm10
     c33:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
     c3a:	00 00 
     c3c:	c4 e2 55 3d f0       	vpmaxsd %ymm0,%ymm5,%ymm6
     c41:	c4 22 45 90 0c a1    	vpgatherdd %ymm7,(%rcx,%ymm12,4),%ymm9
     c47:	c5 ed 66 fe          	vpcmpgtd %ymm6,%ymm2,%ymm7
     c4b:	c4 e2 4d 3d f2       	vpmaxsd %ymm2,%ymm6,%ymm6
     c50:	c4 c3 65 4c e0 40    	vpblendvb %ymm4,%ymm8,%ymm3,%ymm4
     c56:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm4,%ymm4        # c7f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2ef>
     c5d:	00 00 70 
     c60:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
     c64:	c4 e2 0d 90 3c a1    	vpgatherdd %ymm14,(%rcx,%ymm4,4),%ymm7
     c6a:	c5 fd 66 e5          	vpcmpgtd %ymm5,%ymm0,%ymm4
     c6e:	c5 fd 6f cf          	vmovdqa %ymm7,%ymm1
     c72:	c4 e2 55 39 f8       	vpminsd %ymm0,%ymm5,%ymm7
     c77:	c4 62 45 39 da       	vpminsd %ymm2,%ymm7,%ymm11
     c7c:	c5 c5 66 fa          	vpcmpgtd %ymm2,%ymm7,%ymm7
     c80:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     c84:	c4 c3 65 4c e0 40    	vpblendvb %ymm4,%ymm8,%ymm3,%ymm4
     c8a:	c4 41 4d fe f3       	vpaddd %ymm11,%ymm6,%ymm14
     c8f:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
     c94:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm4,%ymm4        # cbd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x32d>
     c9b:	00 00 70 
     c9e:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     ca2:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     ca6:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
     caa:	c4 c1 35 db d7       	vpand  %ymm15,%ymm9,%ymm2
     caf:	c4 62 45 90 24 a1    	vpgatherdd %ymm7,(%rcx,%ymm4,4),%ymm12
     cb5:	c4 c1 2d db ff       	vpand  %ymm15,%ymm10,%ymm7
     cba:	c5 7e 7f a4 24 80 00 	vmovdqu %ymm12,0x80(%rsp)
     cc1:	00 00 
     cc3:	c5 05 db e1          	vpand  %ymm1,%ymm15,%ymm12
     cc7:	c5 d5 72 f7 10       	vpslld $0x10,%ymm7,%ymm5
     ccc:	c5 85 db a4 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm4
     cd3:	00 00 
     cd5:	c5 9d fa ff          	vpsubd %ymm7,%ymm12,%ymm7
     cd9:	c4 e2 45 40 fe       	vpmulld %ymm6,%ymm7,%ymm7
     cde:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     ce2:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
     ce7:	c5 7e 6f a4 24 40 01 	vmovdqu 0x140(%rsp),%ymm12
     cee:	00 00 
     cf0:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
     cf4:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     cf9:	c4 e2 5d 40 e0       	vpmulld %ymm0,%ymm4,%ymm4
     cfe:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     d03:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     d07:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     d0b:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
     d0f:	c4 c1 5d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm4
     d15:	c5 d5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm5
     d1a:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
     d20:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
     d25:	c5 fe 7f ac 24 e0 00 	vmovdqu %ymm5,0xe0(%rsp)
     d2c:	00 00 
     d2e:	c4 c1 55 72 d2 08    	vpsrld $0x8,%ymm10,%ymm5
     d34:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
     d3a:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
     d3f:	c4 41 2d db f7       	vpand  %ymm15,%ymm10,%ymm14
     d44:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
     d49:	c4 41 7d 6f d4       	vmovdqa %ymm12,%ymm10
     d4e:	c5 7e 7f 8c 24 20 01 	vmovdqu %ymm9,0x120(%rsp)
     d55:	00 00 
     d57:	c4 c1 45 72 f6 10    	vpslld $0x10,%ymm14,%ymm7
     d5d:	c5 ed 72 f5 10       	vpslld $0x10,%ymm5,%ymm2
     d62:	c4 41 45 fe d2       	vpaddd %ymm10,%ymm7,%ymm10
     d67:	c4 41 6d fe e4       	vpaddd %ymm12,%ymm2,%ymm12
     d6c:	c5 7e 7f 94 24 00 01 	vmovdqu %ymm10,0x100(%rsp)
     d73:	00 00 
     d75:	0f 85 35 fd ff ff    	jne    ab0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x120>
     d7b:	48 8b 58 28          	mov    0x28(%rax),%rbx
     d7f:	c5 fe 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm0
     d85:	c5 7d 7f ef          	vmovdqa %ymm13,%ymm7
     d89:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
     d8d:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
     d93:	c5 7e 6f 5c 24 60    	vmovdqu 0x60(%rsp),%ymm11
     d99:	48 83 c0 60          	add    $0x60,%rax
     d9d:	c4 e2 45 90 34 83    	vpgatherdd %ymm7,(%rbx,%ymm0,4),%ymm6
     da3:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
     da7:	c5 7d 7f e8          	vmovdqa %ymm13,%ymm0
     dab:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # e13 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x483>
     db2:	00 
     db3:	c4 e2 7d 90 3c 93    	vpgatherdd %ymm0,(%rbx,%ymm2,4),%ymm7
     db9:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
     dbd:	c5 7d 7f ea          	vmovdqa %ymm13,%ymm2
     dc1:	c5 c5 db 3d 60 00 00 	vpand  0x60(%rip),%ymm7,%ymm7        # e29 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x499>
     dc8:	00 
     dc9:	c4 a2 6d 90 04 9b    	vpgatherdd %ymm2,(%rbx,%ymm11,4),%ymm0
     dcf:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
     dd3:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # e3b <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ab>
     dda:	00 
     ddb:	c4 62 7d 3d df       	vpmaxsd %ymm7,%ymm0,%ymm11
     de0:	c5 45 66 c8          	vpcmpgtd %ymm0,%ymm7,%ymm9
     de4:	c4 62 7d 39 d7       	vpminsd %ymm7,%ymm0,%ymm10
     de9:	c4 c1 4d 66 d3       	vpcmpgtd %ymm11,%ymm6,%ymm2
     dee:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
     df3:	c4 43 65 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm9
     df9:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm2,0x1f(%rip),%ymm9,%ymm9        # e22 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x492>
     e00:	00 00 20 
     e03:	c4 e2 2d 39 d6       	vpminsd %ymm6,%ymm10,%ymm2
     e08:	c5 35 fe 8c 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm9
     e0f:	00 00 
     e11:	c5 fe 7f 94 24 80 00 	vmovdqu %ymm2,0x80(%rsp)
     e18:	00 00 
     e1a:	c5 2d 66 d6          	vpcmpgtd %ymm6,%ymm10,%ymm10
     e1e:	c4 a2 75 90 14 89    	vpgatherdd %ymm1,(%rcx,%ymm9,4),%ymm2
     e24:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
     e28:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
     e2c:	c5 ed 72 d2 08       	vpsrld $0x8,%ymm2,%ymm2
     e31:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
     e35:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     e3b:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
     e40:	c4 43 65 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm3,%ymm9
     e46:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm9,%ymm9        # e6f <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4df>
     e4d:	00 00 a0 
     e50:	c5 7e 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm10
     e57:	00 00 
     e59:	c4 41 2d fa c9       	vpsubd %ymm9,%ymm10,%ymm9
     e5e:	c4 22 75 90 14 89    	vpgatherdd %ymm1,(%rcx,%ymm9,4),%ymm10
     e64:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
     e6b:	00 00 
     e6d:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     e73:	c5 25 fe c9          	vpaddd %ymm1,%ymm11,%ymm9
     e77:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
     e7c:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
     e81:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     e86:	c5 cd fe c0          	vpaddd %ymm0,%ymm6,%ymm0
     e8a:	c5 ad fa f2          	vpsubd %ymm2,%ymm10,%ymm6
     e8e:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
     e93:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
     e99:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     e9d:	c4 e2 7d 40 c6       	vpmulld %ymm6,%ymm0,%ymm0
     ea2:	c5 7d 7f ed          	vmovdqa %ymm13,%ymm5
     ea6:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     eab:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     eb0:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     eb4:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
     eb9:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
     ebd:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     ec2:	c4 e2 55 90 04 8b    	vpgatherdd %ymm5,(%rbx,%ymm1,4),%ymm0
     ec8:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
     ecc:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
     ed0:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # f38 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5a8>
     ed7:	00 
     ed8:	c5 7d 6f e2          	vmovdqa %ymm2,%ymm12
     edc:	c4 e2 75 90 2c bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm5
     ee2:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
     ee8:	48 8b 70 d0          	mov    -0x30(%rax),%rsi
     eec:	c5 7d 7f e9          	vmovdqa %ymm13,%ymm1
     ef0:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # f58 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
     ef7:	00 
     ef8:	c4 e2 75 90 24 be    	vpgatherdd %ymm1,(%rsi,%ymm7,4),%ymm4
     efe:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # f66 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5d6>
     f05:	00 
     f06:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
     f0b:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
     f0f:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
     f13:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
     f18:	c4 c3 65 4c f0 60    	vpblendvb %ymm6,%ymm8,%ymm3,%ymm6
     f1e:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # f47 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5b7>
     f25:	00 00 90 
     f28:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
     f2d:	c5 cd fe b4 24 a0 00 	vpaddd 0xa0(%rsp),%ymm6,%ymm6
     f34:	00 00 
     f36:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
     f3b:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
     f3f:	c4 e2 25 90 0c b1    	vpgatherdd %ymm11,(%rcx,%ymm6,4),%ymm1
     f45:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
     f49:	c4 41 7d 6f dd       	vmovdqa %ymm13,%ymm11
     f4e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     f53:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
     f57:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
     f5c:	c4 c3 65 4c d8 60    	vpblendvb %ymm6,%ymm8,%ymm3,%ymm3
     f62:	c5 fe 6f b4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm6
     f69:	00 00 
     f6b:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm3,%ymm3        # f94 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x604>
     f72:	00 00 90 
     f75:	c5 cd fa db          	vpsubd %ymm3,%ymm6,%ymm3
     f79:	c4 e2 25 90 34 99    	vpgatherdd %ymm11,(%rcx,%ymm3,4),%ymm6
     f7f:	c4 c1 45 fe da       	vpaddd %ymm10,%ymm7,%ymm3
     f84:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     f89:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
     f8d:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
     f92:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     f96:	c5 cd fa d9          	vpsubd %ymm1,%ymm6,%ymm3
     f9a:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
     f9f:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     fa4:	c5 fe 6f 9c 24 20 01 	vmovdqu 0x120(%rsp),%ymm3
     fab:	00 00 
     fad:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
     fb2:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
     fb6:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
     fbb:	c5 f5 fe 8c 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm1
     fc2:	00 00 
     fc4:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
     fc8:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
     fcc:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     fd1:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
     fd5:	49 39 c3             	cmp    %rax,%r11
     fd8:	74 16                	je     ff0 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x660>
     fda:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     fe0:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     fe6:	e9 78 fb ff ff       	jmp    b63 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1d3>
     feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     ff0:	c5 fe 6f 84 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm0
     ff7:	00 00 
     ff9:	c5 7d 7f e5          	vmovdqa %ymm12,%ymm5
     ffd:	c5 ed 72 f5 08       	vpslld $0x8,%ymm5,%ymm2
    1002:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    1007:	49 83 c0 18          	add    $0x18,%r8
    100b:	c5 ed eb c9          	vpor   %ymm1,%ymm2,%ymm1
    100f:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    1013:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 105c <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6cc>
    101a:	00 00 
    101c:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    1020:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    1026:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    102b:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    1030:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    1034:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    103a:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    1040:	4d 39 c1             	cmp    %r8,%r9
    1043:	0f 85 07 fa ff ff    	jne    a50 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0xc0>
    1049:	c5 f8 77             	vzeroupper
    104c:	c5 f8 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm6
    1053:	00 00 
    1055:	c5 f8 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm7
    105c:	00 00 
    105e:	c5 78 28 84 24 80 01 	vmovaps 0x180(%rsp),%xmm8
    1065:	00 00 
    1067:	c5 78 28 8c 24 90 01 	vmovaps 0x190(%rsp),%xmm9
    106e:	00 00 
    1070:	c5 78 28 94 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm10
    1077:	00 00 
    1079:	c5 78 28 9c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm11
    1080:	00 00 
    1082:	c5 78 28 a4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm12
    1089:	00 00 
    108b:	c5 78 28 ac 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm13
    1092:	00 00 
    1094:	c5 78 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm14
    109b:	00 00 
    109d:	c5 78 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm15
    10a4:	00 00 
    10a6:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
    10ad:	5b                   	pop    %rbx
    10ae:	5e                   	pop    %rsi
    10af:	c3                   	ret
    10b0:	c5 fd 6f ea          	vmovdqa %ymm2,%ymm5
    10b4:	e9 44 ff ff ff       	jmp    ffd <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x66d>
    10b9:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    10bd:	0f 85 40 f9 ff ff    	jne    a03 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    10c3:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    10ca:	0f 84 33 f9 ff ff    	je     a03 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    10d0:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    10d7:	0f 84 26 f9 ff ff    	je     a03 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    10dd:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    10e4:	0f 84 19 f9 ff ff    	je     a03 <jshc_channel::avx2_chain(jshc_channel::View const*, unsigned long long, unsigned char*, unsigned long long)+0x73>
    10ea:	4d 89 c8             	mov    %r9,%r8
    10ed:	48 89 da             	mov    %rbx,%rdx
    10f0:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
    10f5:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    10fa:	e8 b1 f2 ff ff       	call   3b0 <void jshc_channel::(anonymous namespace)::stage<false>(jshc_channel::View const&, unsigned char*, unsigned long long)>
    10ff:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    1104:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
    1109:	48 89 da             	mov    %rbx,%rdx
    110c:	4d 89 c8             	mov    %r9,%r8
    110f:	49 8d 4a 60          	lea    0x60(%r10),%rcx
    1113:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    1118:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    111d:	e8 de ee ff ff       	call   0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)>
    1122:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    1127:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    112c:	48 89 da             	mov    %rbx,%rdx
    112f:	49 8d 8a c0 00 00 00 	lea    0xc0(%r10),%rcx
    1136:	e8 c5 ee ff ff       	call   0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)>
    113b:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    1140:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    1145:	48 89 da             	mov    %rbx,%rdx
    1148:	c5 f8 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm6
    114f:	00 00 
    1151:	c5 f8 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm7
    1158:	00 00 
    115a:	c5 78 28 84 24 80 01 	vmovaps 0x180(%rsp),%xmm8
    1161:	00 00 
    1163:	c5 78 28 8c 24 90 01 	vmovaps 0x190(%rsp),%xmm9
    116a:	00 00 
    116c:	49 8d 8a 20 01 00 00 	lea    0x120(%r10),%rcx
    1173:	c5 78 28 94 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm10
    117a:	00 00 
    117c:	c5 78 28 9c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm11
    1183:	00 00 
    1185:	c5 78 28 a4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm12
    118c:	00 00 
    118e:	c5 78 28 ac 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm13
    1195:	00 00 
    1197:	c5 78 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm14
    119e:	00 00 
    11a0:	c5 78 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm15
    11a7:	00 00 
    11a9:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
    11b0:	5b                   	pop    %rbx
    11b1:	5e                   	pop    %rsi
    11b2:	e9 49 ee ff ff       	jmp    0 <void jshc_channel::(anonymous namespace)::stage<true>(jshc_channel::View const&, unsigned char*, unsigned long long)>
    11b7:	90                   	nop
    11b8:	90                   	nop
    11b9:	90                   	nop
    11ba:	90                   	nop
    11bb:	90                   	nop
    11bc:	90                   	nop
    11bd:	90                   	nop
    11be:	90                   	nop
    11bf:	90                   	nop
