# Empty dependencies file for jshc_skylake_input256_ordered.
# This may be replaced when dependencies are built.
