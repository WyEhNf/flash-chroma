file(REMOVE_RECURSE
  "CMakeFiles/jshc_skylake_input256_deferred.dir/link.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/andn_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/andn_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/andn_outplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/andn_outplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/channel_runtime.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/channel_runtime.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/deferred_inplace/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/deferred_inplace/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-domain-isolated-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-exception-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/mnt/f/Hackathon/projects/16-lut-color/experiments/skylake-suffix-cache-runtime/channel_avx2.cpp.o.d"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/outplace_bench.cpp.o"
  "CMakeFiles/jshc_skylake_input256_deferred.dir/outplace_bench.cpp.o.d"
  "libjshc_skylake_input256_deferred.pdb"
  "libjshc_skylake_input256_deferred.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/jshc_skylake_input256_deferred.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
