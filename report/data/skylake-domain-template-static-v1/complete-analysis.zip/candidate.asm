
artifacts\skylake-domain-cache-build-v1\CMakeFiles\jshc_skylake_domain_cache.dir\channel_avx2.cpp.obj:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
       0:	48 81 ec 48 01 00 00 	sub    $0x148,%rsp
       7:	c5 f8 29 b4 24 a0 00 	vmovaps %xmm6,0xa0(%rsp)
       e:	00 00 
      10:	c5 f8 29 bc 24 b0 00 	vmovaps %xmm7,0xb0(%rsp)
      17:	00 00 
      19:	c5 78 29 84 24 c0 00 	vmovaps %xmm8,0xc0(%rsp)
      20:	00 00 
      22:	c5 78 29 8c 24 d0 00 	vmovaps %xmm9,0xd0(%rsp)
      29:	00 00 
      2b:	c5 78 29 94 24 e0 00 	vmovaps %xmm10,0xe0(%rsp)
      32:	00 00 
      34:	c5 78 29 9c 24 f0 00 	vmovaps %xmm11,0xf0(%rsp)
      3b:	00 00 
      3d:	c5 78 29 a4 24 00 01 	vmovaps %xmm12,0x100(%rsp)
      44:	00 00 
      46:	c5 78 29 ac 24 10 01 	vmovaps %xmm13,0x110(%rsp)
      4d:	00 00 
      4f:	c5 78 29 b4 24 20 01 	vmovaps %xmm14,0x120(%rsp)
      56:	00 00 
      58:	c5 78 29 bc 24 30 01 	vmovaps %xmm15,0x130(%rsp)
      5f:	00 00 
      61:	48 89 c8             	mov    %rcx,%rax
      64:	49 89 d2             	mov    %rdx,%r10
      67:	4d 85 c9             	test   %r9,%r9
      6a:	0f 84 76 03 00 00    	je     3e6 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3e6>
      70:	c4 e2 7d 58 4a 10    	vpbroadcastd 0x10(%rdx),%ymm1
      76:	49 ff c9             	dec    %r9
      79:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
      7e:	49 c1 e9 03          	shr    $0x3,%r9
      82:	c5 fe 7f 4c 24 20    	vmovdqu %ymm1,0x20(%rsp)
      88:	c4 e2 7d 58 4a 08    	vpbroadcastd 0x8(%rdx),%ymm1
      8e:	c5 fe 7f 4c 24 40    	vmovdqu %ymm1,0x40(%rsp)
      94:	c4 e2 7d 58 4a 18    	vpbroadcastd 0x18(%rdx),%ymm1
      9a:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
      9e:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
      a3:	ba 00 80 00 00       	mov    $0x8000,%edx
      a8:	c5 f9 6e e2          	vmovd  %edx,%xmm4
      ac:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
      b2:	c4 c1 75 72 d7 18    	vpsrld $0x18,%ymm15,%ymm1
      b8:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
      bd:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
      c4:	00 00 
      c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
      cd:	00 00 00 
      d0:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
      d5:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
      db:	c5 7d 7f fe          	vmovdqa %ymm15,%ymm6
      df:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
      e3:	48 8b 10             	mov    (%rax),%rdx
      e6:	44 8b 48 54          	mov    0x54(%rax),%r9d
      ea:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
      ee:	49 83 c0 18          	add    $0x18,%r8
      f2:	c4 e3 69 0f d0 0c    	vpalignr $0xc,%xmm0,%xmm2,%xmm2
      f8:	8b 48 50             	mov    0x50(%rax),%ecx
      fb:	c4 e3 7d 38 c2 01    	vinserti128 $0x1,%xmm2,%ymm0,%ymm0
     101:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     106:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 10f <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x10f>
     10d:	00 00 
     10f:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     113:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     118:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     11d:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     122:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
     126:	c4 e2 4d 90 24 82    	vpgatherdd %ymm6,(%rdx,%ymm0,4),%ymm4
     12c:	48 8b 50 08          	mov    0x8(%rax),%rdx
     130:	c5 ed db c1          	vpand  %ymm1,%ymm2,%ymm0
     134:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     139:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     13e:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
     144:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
     149:	48 8b 50 10          	mov    0x10(%rax),%rdx
     14d:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 1d5 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1d5>
     154:	00 
     155:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     15a:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
     15f:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1e7 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e7>
     166:	00 
     167:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     16c:	c4 e2 55 90 3c 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm7
     172:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     176:	48 8b 50 48          	mov    0x48(%rax),%rdx
     17a:	c5 e5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm3
     17f:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     184:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 20c <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x20c>
     18b:	00 
     18c:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     191:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     196:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     19b:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     1a0:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     1a5:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     1a9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     1ad:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     1b1:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     1b5:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
     1b9:	c4 e2 65 90 04 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm0
     1bf:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     1c3:	c5 fe 7f 2c 24       	vmovdqu %ymm5,(%rsp)
     1c8:	c4 62 65 90 34 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm14
     1ce:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     1d2:	c5 dd fe ee          	vpaddd %ymm6,%ymm4,%ymm5
     1d6:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     1da:	c4 c3 2d 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm10,%ymm3
     1e0:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 209 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x209>
     1e7:	00 00 80 
     1ea:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     1ef:	c4 43 2d 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm10,%ymm10
     1f5:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     1fa:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     1ff:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # 228 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x228>
     206:	00 00 c0 
     209:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     20d:	c5 7e 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm13
     214:	00 00 
     216:	c5 3d fe c5          	vpaddd %ymm5,%ymm8,%ymm8
     21a:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     21e:	c5 8d db f9          	vpand  %ymm1,%ymm14,%ymm7
     222:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
     228:	c4 c1 5d fa ea       	vpsubd %ymm10,%ymm4,%ymm5
     22d:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     231:	c4 e2 5d 90 34 aa    	vpgatherdd %ymm4,(%rdx,%ymm5,4),%ymm6
     237:	c5 65 db e1          	vpand  %ymm1,%ymm3,%ymm12
     23b:	c5 fd db d1          	vpand  %ymm1,%ymm0,%ymm2
     23f:	41 8b 52 24          	mov    0x24(%r10),%edx
     243:	c5 cd db e9          	vpand  %ymm1,%ymm6,%ymm5
     247:	c5 ad 72 f2 10       	vpslld $0x10,%ymm2,%ymm10
     24c:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
     250:	41 8b 4a 20          	mov    0x20(%r10),%ecx
     254:	c5 c5 fa fd          	vpsubd %ymm5,%ymm7,%ymm7
     258:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
     25d:	c4 c2 6d 40 d1       	vpmulld %ymm9,%ymm2,%ymm2
     262:	c4 c2 45 40 fb       	vpmulld %ymm11,%ymm7,%ymm7
     267:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     26c:	c4 41 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm10
     271:	0f af ca             	imul   %edx,%ecx
     274:	c4 c1 55 fe ea       	vpaddd %ymm10,%ymm5,%ymm5
     279:	c5 c5 fe d2          	vpaddd %ymm2,%ymm7,%ymm2
     27d:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     282:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     286:	c5 c5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm7
     28b:	c5 2d db d1          	vpand  %ymm1,%ymm10,%ymm10
     28f:	c5 dd 72 d2 10       	vpsrld $0x10,%ymm2,%ymm4
     294:	c5 d5 72 d6 08       	vpsrld $0x8,%ymm6,%ymm5
     299:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
     29d:	c4 c1 6d 72 d6 08    	vpsrld $0x8,%ymm14,%ymm2
     2a3:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     2a8:	c5 d5 db e9          	vpand  %ymm1,%ymm5,%ymm5
     2ac:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     2b0:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     2b4:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     2b9:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     2be:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     2c3:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     2c7:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     2cc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     2d1:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     2d6:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     2db:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
     2e0:	c5 e5 db d9          	vpand  %ymm1,%ymm3,%ymm3
     2e4:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
     2e8:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     2ec:	c4 c1 55 fe ec       	vpaddd %ymm12,%ymm5,%ymm5
     2f1:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     2f5:	c5 fd db e9          	vpand  %ymm1,%ymm0,%ymm5
     2f9:	c4 c1 7d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm0
     2ff:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
     304:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
     308:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
     30c:	c4 c2 55 40 e9       	vpmulld %ymm9,%ymm5,%ymm5
     311:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     316:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
     31a:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
     31e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     323:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     328:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     32d:	c5 ed fa 54 24 20    	vpsubd 0x20(%rsp),%ymm2,%ymm2
     333:	c5 f9 6e da          	vmovd  %edx,%xmm3
     337:	49 8b 12             	mov    (%r10),%rdx
     33a:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
     33e:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     343:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
     348:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
     34c:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     351:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     355:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
     359:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
     35d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     362:	c5 fd fa 44 24 60    	vpsubd 0x60(%rsp),%ymm0,%ymm0
     368:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     36c:	c5 dd fa 44 24 40    	vpsubd 0x40(%rsp),%ymm4,%ymm0
     372:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     377:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
     37b:	c5 7d 7f fc          	vmovdqa %ymm15,%ymm4
     37f:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     383:	c4 e2 5d 90 04 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm0
     389:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
     38e:	c5 e5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm3
     393:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
     397:	c5 ed db d1          	vpand  %ymm1,%ymm2,%ymm2
     39b:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
     3a0:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
     3a5:	c5 ed eb d3          	vpor   %ymm3,%ymm2,%ymm2
     3a9:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
     3ad:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 3f6 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3f6>
     3b4:	00 00 
     3b6:	c5 f9 6f d8          	vmovdqa %xmm0,%xmm3
     3ba:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     3c0:	c5 e9 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm2
     3c5:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     3ca:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     3ce:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     3d4:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     3da:	4d 39 c3             	cmp    %r8,%r11
     3dd:	0f 85 ed fc ff ff    	jne    d0 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd0>
     3e3:	c5 f8 77             	vzeroupper
     3e6:	c5 f8 28 b4 24 a0 00 	vmovaps 0xa0(%rsp),%xmm6
     3ed:	00 00 
     3ef:	c5 f8 28 bc 24 b0 00 	vmovaps 0xb0(%rsp),%xmm7
     3f6:	00 00 
     3f8:	c5 78 28 84 24 c0 00 	vmovaps 0xc0(%rsp),%xmm8
     3ff:	00 00 
     401:	c5 78 28 8c 24 d0 00 	vmovaps 0xd0(%rsp),%xmm9
     408:	00 00 
     40a:	c5 78 28 94 24 e0 00 	vmovaps 0xe0(%rsp),%xmm10
     411:	00 00 
     413:	c5 78 28 9c 24 f0 00 	vmovaps 0xf0(%rsp),%xmm11
     41a:	00 00 
     41c:	c5 78 28 a4 24 00 01 	vmovaps 0x100(%rsp),%xmm12
     423:	00 00 
     425:	c5 78 28 ac 24 10 01 	vmovaps 0x110(%rsp),%xmm13
     42c:	00 00 
     42e:	c5 78 28 b4 24 20 01 	vmovaps 0x120(%rsp),%xmm14
     435:	00 00 
     437:	c5 78 28 bc 24 30 01 	vmovaps 0x130(%rsp),%xmm15
     43e:	00 00 
     440:	48 81 c4 48 01 00 00 	add    $0x148,%rsp
     447:	c3                   	ret
     448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     44f:	00 

0000000000000450 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     450:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
     457:	c5 f8 29 b4 24 60 01 	vmovaps %xmm6,0x160(%rsp)
     45e:	00 00 
     460:	c5 f8 29 bc 24 70 01 	vmovaps %xmm7,0x170(%rsp)
     467:	00 00 
     469:	c5 78 29 84 24 80 01 	vmovaps %xmm8,0x180(%rsp)
     470:	00 00 
     472:	c5 78 29 8c 24 90 01 	vmovaps %xmm9,0x190(%rsp)
     479:	00 00 
     47b:	c5 78 29 94 24 a0 01 	vmovaps %xmm10,0x1a0(%rsp)
     482:	00 00 
     484:	c5 78 29 9c 24 b0 01 	vmovaps %xmm11,0x1b0(%rsp)
     48b:	00 00 
     48d:	c5 78 29 a4 24 c0 01 	vmovaps %xmm12,0x1c0(%rsp)
     494:	00 00 
     496:	c5 78 29 ac 24 d0 01 	vmovaps %xmm13,0x1d0(%rsp)
     49d:	00 00 
     49f:	c5 78 29 b4 24 e0 01 	vmovaps %xmm14,0x1e0(%rsp)
     4a6:	00 00 
     4a8:	c5 78 29 bc 24 f0 01 	vmovaps %xmm15,0x1f0(%rsp)
     4af:	00 00 
     4b1:	48 89 c8             	mov    %rcx,%rax
     4b4:	49 89 d2             	mov    %rdx,%r10
     4b7:	4d 85 c9             	test   %r9,%r9
     4ba:	0f 84 76 05 00 00    	je     a36 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5e6>
     4c0:	c4 e2 7d 58 72 10    	vpbroadcastd 0x10(%rdx),%ymm6
     4c6:	49 ff c9             	dec    %r9
     4c9:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
     4ce:	49 c1 e9 03          	shr    $0x3,%r9
     4d2:	c5 fe 7f b4 24 00 01 	vmovdqu %ymm6,0x100(%rsp)
     4d9:	00 00 
     4db:	c4 e2 7d 58 72 08    	vpbroadcastd 0x8(%rdx),%ymm6
     4e1:	c5 fe 7f b4 24 20 01 	vmovdqu %ymm6,0x120(%rsp)
     4e8:	00 00 
     4ea:	c4 e2 7d 58 72 18    	vpbroadcastd 0x18(%rdx),%ymm6
     4f0:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     4f4:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
     4f9:	ba 00 80 00 00       	mov    $0x8000,%edx
     4fe:	c5 f9 6e fa          	vmovd  %edx,%xmm7
     502:	c5 fe 7f b4 24 40 01 	vmovdqu %ymm6,0x140(%rsp)
     509:	00 00 
     50b:	c4 c1 4d 72 d6 18    	vpsrld $0x18,%ymm14,%ymm6
     511:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
     516:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
     51d:	00 00 
     51f:	90                   	nop
     520:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
     525:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
     52b:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     52f:	c4 41 7d 6f fe       	vmovdqa %ymm14,%ymm15
     534:	48 8b 10             	mov    (%rax),%rdx
     537:	44 8b 48 54          	mov    0x54(%rax),%r9d
     53b:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     540:	49 83 c0 18          	add    $0x18,%r8
     544:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
     54a:	8b 48 50             	mov    0x50(%rax),%ecx
     54d:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
     553:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
     558:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 561 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x111>
     55f:	00 00 
     561:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
     566:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     56b:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
     570:	c5 fd db e6          	vpand  %ymm6,%ymm0,%ymm4
     574:	c5 fe 7f 24 24       	vmovdqu %ymm4,(%rsp)
     579:	c5 f5 db d6          	vpand  %ymm6,%ymm1,%ymm2
     57d:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     581:	c4 e2 55 90 04 a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm0
     587:	48 8b 50 08          	mov    0x8(%rax),%rdx
     58b:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
     591:	c4 e2 75 90 2c 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm5
     597:	48 8b 50 10          	mov    0x10(%rax),%rdx
     59b:	c5 fe 7f bc 24 80 00 	vmovdqu %ymm7,0x80(%rsp)
     5a2:	00 00 
     5a4:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
     5a8:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
     5ad:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 635 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e5>
     5b4:	00 
     5b5:	c4 e2 75 90 1c ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm3
     5bb:	c5 c5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm7
     5c0:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
     5c4:	48 8b 50 48          	mov    0x48(%rax),%rdx
     5c8:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     5cd:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
     5d2:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     5d7:	c4 e2 45 40 f9       	vpmulld %ymm1,%ymm7,%ymm7
     5dc:	c5 dd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm4
     5e1:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 669 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x219>
     5e8:	00 
     5e9:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 671 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x221>
     5f0:	00 
     5f1:	c4 62 7d 39 cd       	vpminsd %ymm5,%ymm0,%ymm9
     5f6:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     5fa:	c4 e2 7d 3d fd       	vpmaxsd %ymm5,%ymm0,%ymm7
     5ff:	c5 6d fe ec          	vpaddd %ymm4,%ymm2,%ymm13
     603:	c5 e5 66 e7          	vpcmpgtd %ymm7,%ymm3,%ymm4
     607:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
     60b:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
     610:	c4 22 05 90 24 aa    	vpgatherdd %ymm15,(%rdx,%ymm13,4),%ymm12
     616:	c4 e2 45 3d fb       	vpmaxsd %ymm3,%ymm7,%ymm7
     61b:	c4 41 6d fe fd       	vpaddd %ymm13,%ymm2,%ymm15
     620:	c5 d5 66 d0          	vpcmpgtd %ymm0,%ymm5,%ymm2
     624:	c4 22 25 90 14 ba    	vpgatherdd %ymm11,(%rdx,%ymm15,4),%ymm10
     62a:	c4 62 35 39 db       	vpminsd %ymm3,%ymm9,%ymm11
     62f:	c5 7e 7f 54 24 60    	vmovdqu %ymm10,0x60(%rsp)
     635:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     63a:	c5 35 66 cb          	vpcmpgtd %ymm3,%ymm9,%ymm9
     63e:	c4 c3 75 4c d0 20    	vpblendvb %ymm2,%ymm8,%ymm1,%ymm2
     644:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm2,%ymm2        # 66d <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x21d>
     64b:	00 00 40 
     64e:	c5 95 fe d2          	vpaddd %ymm2,%ymm13,%ymm2
     652:	c4 e2 2d 90 24 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm4
     658:	c5 fd 66 d5          	vpcmpgtd %ymm5,%ymm0,%ymm2
     65c:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
     661:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     665:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     669:	c4 c3 75 4c d0 20    	vpblendvb %ymm2,%ymm8,%ymm1,%ymm2
     66f:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm2,%ymm2        # 698 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x248>
     676:	00 00 90 
     679:	c5 85 fa d2          	vpsubd %ymm2,%ymm15,%ymm2
     67d:	c4 62 2d 90 0c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm9
     683:	c5 7e 7f 64 24 40    	vmovdqu %ymm12,0x40(%rsp)
     689:	c4 41 45 fe e3       	vpaddd %ymm11,%ymm7,%ymm12
     68e:	c5 4d db 54 24 40    	vpand  0x40(%rsp),%ymm6,%ymm10
     694:	c5 35 db ce          	vpand  %ymm6,%ymm9,%ymm9
     698:	c4 c1 65 fa dc       	vpsubd %ymm12,%ymm3,%ymm3
     69d:	48 8b 48 28          	mov    0x28(%rax),%rcx
     6a1:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
     6a8:	00 00 
     6aa:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
     6ae:	c5 b5 fa dc          	vpsubd %ymm4,%ymm9,%ymm3
     6b2:	c4 c1 6d 72 f2 10    	vpslld $0x10,%ymm10,%ymm2
     6b8:	c4 e2 7d 40 db       	vpmulld %ymm3,%ymm0,%ymm3
     6bd:	c5 cd db 44 24 60    	vpand  0x60(%rsp),%ymm6,%ymm0
     6c3:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
     6c8:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
     6cd:	c5 ed fe 94 24 a0 00 	vpaddd 0xa0(%rsp),%ymm2,%ymm2
     6d4:	00 00 
     6d6:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
     6db:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
     6e0:	c4 c2 7d 40 c3       	vpmulld %ymm11,%ymm0,%ymm0
     6e5:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     6ea:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
     6ee:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
     6f4:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
     6f8:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     6fd:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
     701:	c5 c5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm7
     706:	c5 fe 7f bc 24 e0 00 	vmovdqu %ymm7,0xe0(%rsp)
     70d:	00 00 
     70f:	c4 e2 25 90 3c a9    	vpgatherdd %ymm11,(%rcx,%ymm5,4),%ymm7
     715:	48 8b 48 20          	mov    0x20(%rax),%rcx
     719:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     71e:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 7a6 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x356>
     725:	00 
     726:	c4 62 25 90 0c 99    	vpgatherdd %ymm11,(%rcx,%ymm3,4),%ymm9
     72c:	48 8b 48 18          	mov    0x18(%rax),%rcx
     730:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
     735:	c5 35 db 0d 80 00 00 	vpand  0x80(%rip),%ymm9,%ymm9        # 7bd <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x36d>
     73c:	00 
     73d:	c4 e2 25 90 1c a1    	vpgatherdd %ymm11,(%rcx,%ymm4,4),%ymm3
     743:	48 8b 48 40          	mov    0x40(%rax),%rcx
     747:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 7cf <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x37f>
     74e:	00 
     74f:	c4 42 65 3d d9       	vpmaxsd %ymm9,%ymm3,%ymm11
     754:	c5 b5 66 c3          	vpcmpgtd %ymm3,%ymm9,%ymm0
     758:	c4 c2 65 39 e9       	vpminsd %ymm9,%ymm3,%ymm5
     75d:	c4 c1 45 66 e3       	vpcmpgtd %ymm11,%ymm7,%ymm4
     762:	c4 e2 55 39 d7       	vpminsd %ymm7,%ymm5,%ymm2
     767:	c4 62 25 3d df       	vpmaxsd %ymm7,%ymm11,%ymm11
     76c:	c5 d5 66 ef          	vpcmpgtd %ymm7,%ymm5,%ymm5
     770:	c4 c3 75 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm1,%ymm0
     776:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 79f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x34f>
     77d:	00 00 40 
     780:	c5 95 fe c0          	vpaddd %ymm0,%ymm13,%ymm0
     784:	c4 e2 1d 90 24 82    	vpgatherdd %ymm12,(%rdx,%ymm0,4),%ymm4
     78a:	c4 c1 65 66 c1       	vpcmpgtd %ymm9,%ymm3,%ymm0
     78f:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
     794:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
     799:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
     79e:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     7a2:	c4 c3 75 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm1,%ymm0
     7a8:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm0,%ymm0        # 7d1 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x381>
     7af:	00 00 50 
     7b2:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
     7b6:	c4 62 1d 90 14 82    	vpgatherdd %ymm12,(%rdx,%ymm0,4),%ymm10
     7bc:	c5 7e 6f 64 24 40    	vmovdqu 0x40(%rsp),%ymm12
     7c2:	c5 fe 7f 94 24 c0 00 	vmovdqu %ymm2,0xc0(%rsp)
     7c9:	00 00 
     7cb:	c5 a5 fe d2          	vpaddd %ymm2,%ymm11,%ymm2
     7cf:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
     7d5:	c5 c5 fa fa          	vpsubd %ymm2,%ymm7,%ymm7
     7d9:	c5 fe 6f 44 24 60    	vmovdqu 0x60(%rsp),%ymm0
     7df:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
     7e3:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
     7e9:	c5 2d db d6          	vpand  %ymm6,%ymm10,%ymm10
     7ed:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
     7f1:	c5 1d db e6          	vpand  %ymm6,%ymm12,%ymm12
     7f5:	c5 d5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm5
     7fa:	c5 ad fa fc          	vpsubd %ymm4,%ymm10,%ymm7
     7fe:	c4 c1 5d fa e4       	vpsubd %ymm12,%ymm4,%ymm4
     803:	c4 e2 65 40 ff       	vpmulld %ymm7,%ymm3,%ymm7
     808:	c5 d5 db ee          	vpand  %ymm6,%ymm5,%ymm5
     80c:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
     811:	c4 c1 7d 72 f4 10    	vpslld $0x10,%ymm12,%ymm0
     817:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     81c:	c5 fd fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm0,%ymm0
     823:	00 00 
     825:	c4 e2 55 40 ac 24 c0 	vpmulld 0xc0(%rsp),%ymm5,%ymm5
     82c:	00 00 00 
     82f:	c5 c5 fe c0          	vpaddd %ymm0,%ymm7,%ymm0
     833:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
     837:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
     83b:	c5 fe 6f ac 24 80 00 	vmovdqu 0x80(%rsp),%ymm5
     842:	00 00 
     844:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
     849:	c4 e2 6d 90 1c a9    	vpgatherdd %ymm2,(%rcx,%ymm5,4),%ymm3
     84f:	48 8b 48 38          	mov    0x38(%rax),%rcx
     853:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
     859:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
     85d:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
     862:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 8ea <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x49a>
     869:	00 
     86a:	c4 e2 6d 90 3c a9    	vpgatherdd %ymm2,(%rcx,%ymm5,4),%ymm7
     870:	48 8b 48 30          	mov    0x30(%rax),%rcx
     874:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
     878:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 900 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4b0>
     87f:	00 
     880:	c4 e2 6d 90 2c a1    	vpgatherdd %ymm2,(%rcx,%ymm4,4),%ymm5
     886:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
     88a:	41 8b 4a 20          	mov    0x20(%r10),%ecx
     88e:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 916 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4c6>
     895:	00 
     896:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
     89b:	c5 45 66 cd          	vpcmpgtd %ymm5,%ymm7,%ymm9
     89f:	c4 62 55 39 df       	vpminsd %ymm7,%ymm5,%ymm11
     8a4:	c4 c1 65 66 e2       	vpcmpgtd %ymm10,%ymm3,%ymm4
     8a9:	c4 62 25 39 e3       	vpminsd %ymm3,%ymm11,%ymm12
     8ae:	c4 62 2d 3d d3       	vpmaxsd %ymm3,%ymm10,%ymm10
     8b3:	c5 25 66 db          	vpcmpgtd %ymm3,%ymm11,%ymm11
     8b7:	c4 43 75 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm1,%ymm9
     8bd:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm9,%ymm9        # 8e6 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x496>
     8c4:	00 00 40 
     8c7:	c4 41 15 fe c9       	vpaddd %ymm9,%ymm13,%ymm9
     8cc:	c4 41 2d fe ec       	vpaddd %ymm12,%ymm10,%ymm13
     8d1:	c4 a2 6d 90 24 8a    	vpgatherdd %ymm2,(%rdx,%ymm9,4),%ymm4
     8d7:	c5 55 66 cf          	vpcmpgtd %ymm7,%ymm5,%ymm9
     8db:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
     8df:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     8e4:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     8e8:	c4 c1 65 fa dd       	vpsubd %ymm13,%ymm3,%ymm3
     8ed:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
     8f4:	00 00 
     8f6:	c5 dd db e6          	vpand  %ymm6,%ymm4,%ymm4
     8fa:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
     8fe:	c4 c3 75 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm1,%ymm1
     904:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm1,%ymm1        # 92d <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4dd>
     90b:	00 00 b0 
     90e:	c5 85 fa c9          	vpsubd %ymm1,%ymm15,%ymm1
     912:	c5 7e 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm15
     918:	c4 62 6d 90 04 8a    	vpgatherdd %ymm2,(%rdx,%ymm1,4),%ymm8
     91e:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
     924:	41 8b 52 24          	mov    0x24(%r10),%edx
     928:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
     92e:	c4 c1 35 72 d7 10    	vpsrld $0x10,%ymm15,%ymm9
     934:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     939:	c5 3d db c6          	vpand  %ymm6,%ymm8,%ymm8
     93d:	c5 35 db ce          	vpand  %ymm6,%ymm9,%ymm9
     941:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
     945:	c5 bd fa ec          	vpsubd %ymm4,%ymm8,%ymm5
     949:	c4 41 35 fa c8       	vpsubd %ymm8,%ymm9,%ymm9
     94e:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
     953:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
     957:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
     95b:	c4 42 35 40 cc       	vpmulld %ymm12,%ymm9,%ymm9
     960:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
     965:	c5 a5 72 f1 10       	vpslld $0x10,%ymm1,%ymm11
     96a:	0f af ca             	imul   %edx,%ecx
     96d:	c5 fd fa 8c 24 00 01 	vpsubd 0x100(%rsp),%ymm0,%ymm1
     974:	00 00 
     976:	c5 25 fe 9c 24 a0 00 	vpaddd 0xa0(%rsp),%ymm11,%ymm11
     97d:	00 00 
     97f:	c5 f9 6e c2          	vmovd  %edx,%xmm0
     983:	49 8b 12             	mov    (%r10),%rdx
     986:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
     98b:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
     98f:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
     994:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
     999:	c5 c5 fa 84 24 20 01 	vpsubd 0x120(%rsp),%ymm7,%ymm0
     9a0:	00 00 
     9a2:	c5 35 fe cc          	vpaddd %ymm4,%ymm9,%ymm9
     9a6:	c4 c1 65 fe d9       	vpaddd %ymm9,%ymm3,%ymm3
     9ab:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     9b0:	c5 e5 fa 9c 24 40 01 	vpsubd 0x140(%rsp),%ymm3,%ymm3
     9b7:	00 00 
     9b9:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
     9bd:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
     9c1:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
     9c6:	c4 e2 7d 40 c3       	vpmulld %ymm3,%ymm0,%ymm0
     9cb:	c5 fd fa c7          	vpsubd %ymm7,%ymm0,%ymm0
     9cf:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
     9d3:	c4 e2 55 90 04 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm0
     9d9:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
     9de:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
     9e3:	c5 fd db c6          	vpand  %ymm6,%ymm0,%ymm0
     9e7:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
     9eb:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
     9f0:	c5 f5 72 f1 08       	vpslld $0x8,%ymm1,%ymm1
     9f5:	c5 f5 eb ca          	vpor   %ymm2,%ymm1,%ymm1
     9f9:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
     9fd:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # a46 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5f6>
     a04:	00 00 
     a06:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
     a0a:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
     a10:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
     a15:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
     a1a:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
     a1e:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
     a24:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
     a2a:	4d 39 c3             	cmp    %r8,%r11
     a2d:	0f 85 ed fa ff ff    	jne    520 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd0>
     a33:	c5 f8 77             	vzeroupper
     a36:	c5 f8 28 b4 24 60 01 	vmovaps 0x160(%rsp),%xmm6
     a3d:	00 00 
     a3f:	c5 f8 28 bc 24 70 01 	vmovaps 0x170(%rsp),%xmm7
     a46:	00 00 
     a48:	c5 78 28 84 24 80 01 	vmovaps 0x180(%rsp),%xmm8
     a4f:	00 00 
     a51:	c5 78 28 8c 24 90 01 	vmovaps 0x190(%rsp),%xmm9
     a58:	00 00 
     a5a:	c5 78 28 94 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm10
     a61:	00 00 
     a63:	c5 78 28 9c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm11
     a6a:	00 00 
     a6c:	c5 78 28 a4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm12
     a73:	00 00 
     a75:	c5 78 28 ac 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm13
     a7c:	00 00 
     a7e:	c5 78 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm14
     a85:	00 00 
     a87:	c5 78 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm15
     a8e:	00 00 
     a90:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
     a97:	c3                   	ret
     a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     a9f:	00 

0000000000000aa0 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
     aa0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
     aa7:	c5 f8 29 b4 24 00 01 	vmovaps %xmm6,0x100(%rsp)
     aae:	00 00 
     ab0:	c5 f8 29 bc 24 10 01 	vmovaps %xmm7,0x110(%rsp)
     ab7:	00 00 
     ab9:	c5 78 29 84 24 20 01 	vmovaps %xmm8,0x120(%rsp)
     ac0:	00 00 
     ac2:	c5 78 29 8c 24 30 01 	vmovaps %xmm9,0x130(%rsp)
     ac9:	00 00 
     acb:	c5 78 29 94 24 40 01 	vmovaps %xmm10,0x140(%rsp)
     ad2:	00 00 
     ad4:	c5 78 29 9c 24 50 01 	vmovaps %xmm11,0x150(%rsp)
     adb:	00 00 
     add:	c5 78 29 a4 24 60 01 	vmovaps %xmm12,0x160(%rsp)
     ae4:	00 00 
     ae6:	c5 78 29 ac 24 70 01 	vmovaps %xmm13,0x170(%rsp)
     aed:	00 00 
     aef:	c5 78 29 b4 24 80 01 	vmovaps %xmm14,0x180(%rsp)
     af6:	00 00 
     af8:	c5 78 29 bc 24 90 01 	vmovaps %xmm15,0x190(%rsp)
     aff:	00 00 
     b01:	48 89 c8             	mov    %rcx,%rax
     b04:	49 89 d2             	mov    %rdx,%r10
     b07:	4d 85 c9             	test   %r9,%r9
     b0a:	0f 84 bb 0a 00 00    	je     15cb <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb2b>
     b10:	c4 e2 7d 58 42 08    	vpbroadcastd 0x8(%rdx),%ymm0
     b16:	49 ff c9             	dec    %r9
     b19:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
     b1e:	49 c1 e9 03          	shr    $0x3,%r9
     b22:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
     b28:	c4 e2 7d 58 42 0c    	vpbroadcastd 0xc(%rdx),%ymm0
     b2e:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
     b34:	c4 e2 7d 58 42 10    	vpbroadcastd 0x10(%rdx),%ymm0
     b3a:	c5 fe 7f 84 24 80 00 	vmovdqu %ymm0,0x80(%rsp)
     b41:	00 00 
     b43:	c4 e2 7d 58 42 14    	vpbroadcastd 0x14(%rdx),%ymm0
     b49:	c5 fe 7f 84 24 a0 00 	vmovdqu %ymm0,0xa0(%rsp)
     b50:	00 00 
     b52:	c4 e2 7d 58 42 18    	vpbroadcastd 0x18(%rdx),%ymm0
     b58:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
     b5f:	00 00 
     b61:	c4 e2 7d 58 42 1c    	vpbroadcastd 0x1c(%rdx),%ymm0
     b67:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
     b6b:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
     b70:	ba 00 80 00 00       	mov    $0x8000,%edx
     b75:	c5 f9 6e ea          	vmovd  %edx,%xmm5
     b79:	c5 fe 7f 84 24 e0 00 	vmovdqu %ymm0,0xe0(%rsp)
     b80:	00 00 
     b82:	c4 c1 7d 72 d7 18    	vpsrld $0x18,%ymm15,%ymm0
     b88:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     b8d:	c5 fe 7f 2c 24       	vmovdqu %ymm5,(%rsp)
     b92:	e9 b2 00 00 00       	jmp    c49 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1a9>
     b97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     b9e:	00 00 
     ba0:	41 8b 52 24          	mov    0x24(%r10),%edx
     ba4:	41 8b 4a 20          	mov    0x20(%r10),%ecx
     ba8:	c4 c1 6d fa d1       	vpsubd %ymm9,%ymm2,%ymm2
     bad:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
     bb2:	c4 c1 45 fa fb       	vpsubd %ymm11,%ymm7,%ymm7
     bb7:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     bbb:	0f af ca             	imul   %edx,%ecx
     bbe:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
     bc2:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     bc7:	c4 e2 6d 40 d1       	vpmulld %ymm1,%ymm2,%ymm2
     bcc:	c5 f9 6e ca          	vmovd  %edx,%xmm1
     bd0:	49 8b 12             	mov    (%r10),%rdx
     bd3:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
     bd8:	c4 e2 4d 40 f1       	vpmulld %ymm1,%ymm6,%ymm6
     bdd:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     be1:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
     be5:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
     beb:	c5 ed 72 d3 08       	vpsrld $0x8,%ymm3,%ymm2
     bf0:	c5 e5 db e8          	vpand  %ymm0,%ymm3,%ymm5
     bf4:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
     bf8:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     bfd:	c5 e5 72 f3 10       	vpslld $0x10,%ymm3,%ymm3
     c02:	c5 f5 72 f2 08       	vpslld $0x8,%ymm2,%ymm1
     c07:	49 83 c0 18          	add    $0x18,%r8
     c0b:	c5 f5 eb cb          	vpor   %ymm3,%ymm1,%ymm1
     c0f:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
     c13:	c4 e2 75 00 0d 40 00 	vpshufb 0x40(%rip),%ymm1,%ymm1        # c5c <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bc>
     c1a:	00 00 
     c1c:	c5 f9 6f d9          	vmovdqa %xmm1,%xmm3
     c20:	c4 e3 7d 39 c9 01    	vextracti128 $0x1,%ymm1,%xmm1
     c26:	c5 e9 73 f9 0c       	vpslldq $0xc,%xmm1,%xmm2
     c2b:	c5 f1 73 d9 04       	vpsrldq $0x4,%xmm1,%xmm1
     c30:	c5 e9 eb d3          	vpor   %xmm3,%xmm2,%xmm2
     c34:	c4 c1 79 d6 48 f8    	vmovq  %xmm1,-0x8(%r8)
     c3a:	c4 c1 7a 7f 50 e8    	vmovdqu %xmm2,-0x18(%r8)
     c40:	4d 39 d8             	cmp    %r11,%r8
     c43:	0f 84 7f 09 00 00    	je     15c8 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb28>
     c49:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
     c4e:	c4 c1 7a 7e 50 10    	vmovq  0x10(%r8),%xmm2
     c54:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     c58:	48 8b 10             	mov    (%rax),%rdx
     c5b:	44 8b 48 54          	mov    0x54(%rax),%r9d
     c5f:	c4 e3 69 0f d1 0c    	vpalignr $0xc,%xmm1,%xmm2,%xmm2
     c65:	8b 48 50             	mov    0x50(%rax),%ecx
     c68:	c4 e3 75 38 ca 01    	vinserti128 $0x1,%xmm2,%ymm1,%ymm1
     c6e:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     c73:	c4 e2 75 00 0d 00 00 	vpshufb 0x0(%rip),%ymm1,%ymm1        # c7c <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dc>
     c7a:	00 00 
     c7c:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     c81:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
     c86:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
     c8b:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     c8f:	c4 e2 55 90 24 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm4
     c95:	48 8b 50 08          	mov    0x8(%rax),%rdx
     c99:	c5 ed db c8          	vpand  %ymm0,%ymm2,%ymm1
     c9d:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     ca1:	c4 e2 55 90 34 8a    	vpgatherdd %ymm5,(%rdx,%ymm1,4),%ymm6
     ca7:	48 8b 50 10          	mov    0x10(%rax),%rdx
     cab:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     caf:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     cb4:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # d3c <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x29c>
     cbb:	00 
     cbc:	c4 e2 55 90 3c 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm7
     cc2:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
     cc7:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     ccb:	48 8b 50 48          	mov    0x48(%rax),%rdx
     ccf:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     cd4:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     cd9:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     cde:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
     ce3:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
     ce8:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     cec:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     cf1:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # d79 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d9>
     cf8:	00 
     cf9:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # d81 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e1>
     d00:	00 
     d01:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     d06:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     d0b:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     d10:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     d15:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     d19:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     d1d:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     d21:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
     d25:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     d2b:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     d2f:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
     d35:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     d39:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
     d3f:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     d43:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     d48:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     d4c:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     d50:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     d54:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     d5a:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # d83 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e3>
     d61:	00 00 80 
     d64:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
     d69:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
     d6f:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
     d74:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
     d79:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
     d7f:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # da8 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x308>
     d86:	00 00 c0 
     d89:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     d8d:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
     d92:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
     d97:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
     d9b:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     d9f:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
     da5:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
     dab:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
     daf:	c5 f5 db d0          	vpand  %ymm0,%ymm1,%ymm2
     db3:	c5 dd db e8          	vpand  %ymm0,%ymm4,%ymm5
     db7:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
     dbc:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
     dc0:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
     dc4:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
     dc9:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
     dce:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
     dd3:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
     dd8:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
     ddd:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
     de2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
     de7:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
     deb:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
     def:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     df3:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
     df7:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
     dfd:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
     e01:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
     e06:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     e0a:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
     e0f:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
     e14:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
     e18:	c5 d5 db e8          	vpand  %ymm0,%ymm5,%ymm5
     e1c:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
     e20:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
     e25:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     e2a:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
     e2f:	c5 d5 fa ee          	vpsubd %ymm6,%ymm5,%ymm5
     e33:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
     e38:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
     e3d:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
     e41:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
     e46:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
     e4b:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
     e4f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
     e54:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
     e58:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
     e5c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
     e61:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
     e66:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
     e6a:	c4 c1 45 72 d6 10    	vpsrld $0x10,%ymm14,%ymm7
     e70:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
     e77:	00 00 
     e79:	c5 7e 6f 9c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm11
     e80:	00 00 
     e82:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
     e87:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
     e8b:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
     e8f:	c5 cd 72 f7 10       	vpslld $0x10,%ymm7,%ymm6
     e94:	c5 e5 fa ff          	vpsubd %ymm7,%ymm3,%ymm7
     e98:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
     e9d:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
     ea2:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
     ea7:	c5 7e 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm9
     ead:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
     eb1:	c5 d5 fa f2          	vpsubd %ymm2,%ymm5,%ymm6
     eb5:	c5 35 66 c2          	vpcmpgtd %ymm2,%ymm9,%ymm8
     eb9:	c5 f5 fe ff          	vpaddd %ymm7,%ymm1,%ymm7
     ebd:	c5 8d 66 ce          	vpcmpgtd %ymm6,%ymm14,%ymm1
     ec1:	c5 c5 fe fc          	vpaddd %ymm4,%ymm7,%ymm7
     ec5:	c5 e5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm3
     eca:	c5 e5 fa fa          	vpsubd %ymm2,%ymm3,%ymm7
     ece:	c5 a5 66 e7          	vpcmpgtd %ymm7,%ymm11,%ymm4
     ed2:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     ed6:	c5 c5 66 a4 24 e0 00 	vpcmpgtd 0xe0(%rsp),%ymm7,%ymm4
     edd:	00 00 
     edf:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     ee3:	c5 ed 66 64 24 60    	vpcmpgtd 0x60(%rsp),%ymm2,%ymm4
     ee9:	c4 c1 5d eb e0       	vpor   %ymm8,%ymm4,%ymm4
     eee:	c5 4d 66 84 24 a0 00 	vpcmpgtd 0xa0(%rsp),%ymm6,%ymm8
     ef5:	00 00 
     ef7:	c4 c1 5d eb e0       	vpor   %ymm8,%ymm4,%ymm4
     efc:	c5 f5 eb cc          	vpor   %ymm4,%ymm1,%ymm1
     f00:	c5 fd d7 d1          	vpmovmskb %ymm1,%edx
     f04:	85 d2                	test   %edx,%edx
     f06:	0f 84 94 fc ff ff    	je     ba0 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x100>
     f0c:	48 8b 50 60          	mov    0x60(%rax),%rdx
     f10:	c5 7d 7f f9          	vmovdqa %ymm15,%ymm1
     f14:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
     f18:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
     f1f:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
     f25:	c4 e2 75 90 24 92    	vpgatherdd %ymm1,(%rdx,%ymm2,4),%ymm4
     f2b:	48 8b 50 68          	mov    0x68(%rax),%rdx
     f2f:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
     f34:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
     f39:	c4 e2 45 90 34 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm6
     f3f:	48 8b 50 70          	mov    0x70(%rax),%rdx
     f43:	c5 7d 7f fd          	vmovdqa %ymm15,%ymm5
     f47:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
     f4c:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # fd4 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x534>
     f53:	00 
     f54:	c4 e2 55 90 3c 9a    	vpgatherdd %ymm5,(%rdx,%ymm3,4),%ymm7
     f5a:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
     f5f:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
     f63:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
     f6a:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
     f6f:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
     f74:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
     f79:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
     f7e:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
     f83:	c5 79 6e d1          	vmovd  %ecx,%xmm10
     f87:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
     f8c:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 1014 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x574>
     f93:	00 
     f94:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 101c <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x57c>
     f9b:	00 
     f9c:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
     fa1:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
     fa6:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
     faa:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
     fae:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     fb2:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
     fb6:	c5 2d fe ca          	vpaddd %ymm2,%ymm10,%ymm9
     fba:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
     fc0:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
     fc4:	c5 7e 7f 4c 24 20    	vmovdqu %ymm9,0x20(%rsp)
     fca:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
     fce:	c4 a2 65 90 0c 8a    	vpgatherdd %ymm3,(%rdx,%ymm9,4),%ymm1
     fd4:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
     fd8:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
     fdd:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
     fe2:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
     fe6:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
     feb:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
     fef:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
     ff5:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 101e <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x57e>
     ffc:	00 00 80 
     fff:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1004:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    100a:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    100f:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1014:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    101a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 1043 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5a3>
    1021:	00 00 c0 
    1024:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1028:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    102d:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    1032:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    1036:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    103a:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    1040:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
    1046:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    104a:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    104e:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    1055:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    1059:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    105e:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    1062:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    1066:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    106b:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1070:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    1075:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    107a:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    107f:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    1084:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    1089:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    108d:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    1091:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    1095:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    1099:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    109f:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    10a3:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    10a8:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    10ac:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    10b1:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    10b6:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    10ba:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    10be:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    10c2:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    10c7:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    10cc:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    10d1:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    10d5:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    10da:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    10df:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    10e3:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    10e8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    10ed:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    10f1:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    10f6:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    10fa:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    10fe:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1103:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    1108:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    110c:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1111:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    1115:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    111b:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    111f:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    1124:	c5 dd 72 f6 10       	vpslld $0x10,%ymm6,%ymm4
    1129:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    112d:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1131:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1136:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
    113b:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    113f:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
    1145:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    114c:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1150:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
    1154:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
    1158:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    115d:	c4 e2 65 90 34 ba    	vpgatherdd %ymm3,(%rdx,%ymm7,4),%ymm6
    1163:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
    116a:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
    1170:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    1177:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    117b:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    1180:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1208 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x768>
    1187:	00 
    1188:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    118d:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    1191:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    1196:	c4 e2 65 90 3c 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm7
    119c:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    11a1:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    11a6:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    11ad:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
    11b2:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    11b7:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    11bb:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    11c0:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
    11c5:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    11ca:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 1252 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7b2>
    11d1:	00 
    11d2:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 125a <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ba>
    11d9:	00 
    11da:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    11df:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    11e4:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    11e9:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    11ed:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    11f1:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    11f5:	c5 2d fe e2          	vpaddd %ymm2,%ymm10,%ymm12
    11f9:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    11ff:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1203:	c5 7e 7f 64 24 20    	vmovdqu %ymm12,0x20(%rsp)
    1209:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    120d:	c4 a2 65 90 0c a2    	vpgatherdd %ymm3,(%rdx,%ymm12,4),%ymm1
    1213:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    1217:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    121c:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    1220:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    1225:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    1229:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    122d:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    1233:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 125c <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7bc>
    123a:	00 00 80 
    123d:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1242:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    1248:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    124d:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1252:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    1258:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 1281 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7e1>
    125f:	00 00 c0 
    1262:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1266:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    126b:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    1270:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    1274:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    1278:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    127e:	c4 e2 45 90 14 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm2
    1284:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    1288:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    128c:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    1293:	c5 ed db e0          	vpand  %ymm0,%ymm2,%ymm4
    1297:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    129c:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    12a0:	c5 d5 fa ec          	vpsubd %ymm4,%ymm5,%ymm5
    12a4:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    12a9:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    12ae:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    12b3:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    12b8:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    12bd:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    12c2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    12c7:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    12cb:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    12cf:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    12d3:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    12d7:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    12dd:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    12e1:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    12e6:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    12ea:	c5 dd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm4
    12ef:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    12f4:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    12f8:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    12fc:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    1300:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    1305:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    130a:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    130f:	c5 dd fa e6          	vpsubd %ymm6,%ymm4,%ymm4
    1313:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    1318:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    131d:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    1321:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    1326:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    132b:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    132f:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1334:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    1338:	c5 ed fa d3          	vpsubd %ymm3,%ymm2,%ymm2
    133c:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1341:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    1346:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    134a:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    134f:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    1353:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    1359:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    135d:	c5 c5 72 d4 10       	vpsrld $0x10,%ymm4,%ymm7
    1362:	c5 dd 72 f6 10       	vpslld $0x10,%ymm6,%ymm4
    1367:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    136b:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    136f:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    1374:	c4 c1 5d fe e5       	vpaddd %ymm13,%ymm4,%ymm4
    1379:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    137d:	c4 e2 65 90 24 aa    	vpgatherdd %ymm3,(%rdx,%ymm5,4),%ymm4
    1383:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    138a:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    138e:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
    1392:	c5 cd fe f2          	vpaddd %ymm2,%ymm6,%ymm6
    1396:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    139b:	c4 e2 65 90 34 ba    	vpgatherdd %ymm3,(%rdx,%ymm7,4),%ymm6
    13a1:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    13a8:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    13ac:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    13b1:	c4 e2 65 90 3c 8a    	vpgatherdd %ymm3,(%rdx,%ymm1,4),%ymm7
    13b7:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
    13be:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
    13c4:	c5 e5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm3
    13c9:	c5 f5 72 d7 11       	vpsrld $0x11,%ymm7,%ymm1
    13ce:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    13d5:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 145d <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9bd>
    13dc:	00 
    13dd:	c5 f9 6e e9          	vmovd  %ecx,%xmm5
    13e1:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    13e6:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    13eb:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    13f0:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    13f5:	c5 79 6e d1          	vmovd  %ecx,%xmm10
    13f9:	c4 e2 65 40 dd       	vpmulld %ymm5,%ymm3,%ymm3
    13fe:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1403:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1408:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 1490 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f0>
    140f:	00 
    1410:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 1498 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f8>
    1417:	00 
    1418:	c4 62 5d 3d ce       	vpmaxsd %ymm6,%ymm4,%ymm9
    141d:	c4 62 5d 39 e6       	vpminsd %ymm6,%ymm4,%ymm12
    1422:	c4 41 45 66 c1       	vpcmpgtd %ymm9,%ymm7,%ymm8
    1427:	c4 62 35 3d cf       	vpmaxsd %ymm7,%ymm9,%ymm9
    142c:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    1430:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1434:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1438:	c5 2d fe da          	vpaddd %ymm2,%ymm10,%ymm11
    143c:	c4 62 65 90 34 92    	vpgatherdd %ymm3,(%rdx,%ymm2,4),%ymm14
    1442:	c5 7d 7f fb          	vmovdqa %ymm15,%ymm3
    1446:	c5 7e 7f 5c 24 20    	vmovdqu %ymm11,0x20(%rsp)
    144c:	c5 5d fe d6          	vpaddd %ymm6,%ymm4,%ymm10
    1450:	c4 a2 65 90 0c 9a    	vpgatherdd %ymm3,(%rdx,%ymm11,4),%ymm1
    1456:	c5 cd 66 dc          	vpcmpgtd %ymm4,%ymm6,%ymm3
    145a:	c4 62 1d 39 df       	vpminsd %ymm7,%ymm12,%ymm11
    145f:	c5 dd 66 e6          	vpcmpgtd %ymm6,%ymm4,%ymm4
    1463:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    1467:	c5 8d db f0          	vpand  %ymm0,%ymm14,%ymm6
    146b:	c4 c3 55 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm5,%ymm3
    1471:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm3,%ymm3        # 149a <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9fa>
    1478:	00 00 80 
    147b:	c4 41 35 fe c3       	vpaddd %ymm11,%ymm9,%ymm8
    1480:	c4 c3 55 4c ed 40    	vpblendvb %ymm4,%ymm13,%ymm5,%ymm5
    1486:	c5 7e 6f 2c 24       	vmovdqu (%rsp),%ymm13
    148b:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1490:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    1496:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm5,%ymm5        # 14bf <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa1f>
    149d:	00 00 c0 
    14a0:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    14a4:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    14a9:	c4 41 7d 6f d7       	vmovdqa %ymm15,%ymm10
    14ae:	c5 c5 fa ed          	vpsubd %ymm5,%ymm7,%ymm5
    14b2:	c5 7d 7f ff          	vmovdqa %ymm15,%ymm7
    14b6:	c4 e2 2d 90 1c 92    	vpgatherdd %ymm10,(%rdx,%ymm2,4),%ymm3
    14bc:	c4 e2 45 90 24 aa    	vpgatherdd %ymm7,(%rdx,%ymm5,4),%ymm4
    14c2:	c5 65 db d0          	vpand  %ymm0,%ymm3,%ymm10
    14c6:	c5 f5 db e8          	vpand  %ymm0,%ymm1,%ymm5
    14ca:	c5 dd db d0          	vpand  %ymm0,%ymm4,%ymm2
    14ce:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    14d3:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    14d7:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    14db:	c4 c1 6d fa d2       	vpsubd %ymm10,%ymm2,%ymm2
    14e0:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    14e5:	c4 c2 55 40 eb       	vpmulld %ymm11,%ymm5,%ymm5
    14ea:	c4 c2 6d 40 d0       	vpmulld %ymm8,%ymm2,%ymm2
    14ef:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    14f4:	c5 ad 72 d3 08       	vpsrld $0x8,%ymm3,%ymm10
    14f9:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    14fe:	c5 2d db d0          	vpand  %ymm0,%ymm10,%ymm10
    1502:	c5 e5 db d8          	vpand  %ymm0,%ymm3,%ymm3
    1506:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    150a:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    150e:	c4 c1 45 72 d6 08    	vpsrld $0x8,%ymm14,%ymm7
    1514:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    1518:	c5 cd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm6
    151d:	c5 c5 db f8          	vpand  %ymm0,%ymm7,%ymm7
    1521:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    1526:	c5 9d 72 f7 10       	vpslld $0x10,%ymm7,%ymm12
    152b:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    152f:	c5 ed db d0          	vpand  %ymm0,%ymm2,%ymm2
    1533:	c5 ad fa ff          	vpsubd %ymm7,%ymm10,%ymm7
    1537:	c4 41 1d fe e5       	vpaddd %ymm13,%ymm12,%ymm12
    153c:	c4 c2 45 40 f9       	vpmulld %ymm9,%ymm7,%ymm7
    1541:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1546:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    154a:	c4 c1 4d fa f2       	vpsubd %ymm10,%ymm6,%ymm6
    154f:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    1554:	c5 dd db e0          	vpand  %ymm0,%ymm4,%ymm4
    1558:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    155d:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1562:	c5 f5 db c8          	vpand  %ymm0,%ymm1,%ymm1
    1566:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    156b:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    156f:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    1573:	c4 c2 75 40 cb       	vpmulld %ymm11,%ymm1,%ymm1
    1578:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    157d:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1581:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    1586:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    158a:	c4 c1 4d 72 d6 10    	vpsrld $0x10,%ymm14,%ymm6
    1590:	c5 cd db f0          	vpand  %ymm0,%ymm6,%ymm6
    1594:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1599:	c5 c5 72 f6 10       	vpslld $0x10,%ymm6,%ymm7
    159e:	c5 e5 fa f6          	vpsubd %ymm6,%ymm3,%ymm6
    15a2:	c4 c2 4d 40 f1       	vpmulld %ymm9,%ymm6,%ymm6
    15a7:	c4 c1 45 fe fd       	vpaddd %ymm13,%ymm7,%ymm7
    15ac:	c5 dd fe e7          	vpaddd %ymm7,%ymm4,%ymm4
    15b0:	c5 f5 fe f6          	vpaddd %ymm6,%ymm1,%ymm6
    15b4:	c5 cd fe dc          	vpaddd %ymm4,%ymm6,%ymm3
    15b8:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    15bd:	e9 3b f6 ff ff       	jmp    bfd <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15d>
    15c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    15c8:	c5 f8 77             	vzeroupper
    15cb:	c5 f8 28 b4 24 00 01 	vmovaps 0x100(%rsp),%xmm6
    15d2:	00 00 
    15d4:	c5 f8 28 bc 24 10 01 	vmovaps 0x110(%rsp),%xmm7
    15db:	00 00 
    15dd:	c5 78 28 84 24 20 01 	vmovaps 0x120(%rsp),%xmm8
    15e4:	00 00 
    15e6:	c5 78 28 8c 24 30 01 	vmovaps 0x130(%rsp),%xmm9
    15ed:	00 00 
    15ef:	c5 78 28 94 24 40 01 	vmovaps 0x140(%rsp),%xmm10
    15f6:	00 00 
    15f8:	c5 78 28 9c 24 50 01 	vmovaps 0x150(%rsp),%xmm11
    15ff:	00 00 
    1601:	c5 78 28 a4 24 60 01 	vmovaps 0x160(%rsp),%xmm12
    1608:	00 00 
    160a:	c5 78 28 ac 24 70 01 	vmovaps 0x170(%rsp),%xmm13
    1611:	00 00 
    1613:	c5 78 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm14
    161a:	00 00 
    161c:	c5 78 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm15
    1623:	00 00 
    1625:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
    162c:	c3                   	ret
    162d:	0f 1f 00             	nopl   (%rax)

0000000000001630 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    1630:	56                   	push   %rsi
    1631:	53                   	push   %rbx
    1632:	48 81 ec a8 02 00 00 	sub    $0x2a8,%rsp
    1639:	c5 f8 29 b4 24 00 02 	vmovaps %xmm6,0x200(%rsp)
    1640:	00 00 
    1642:	c5 f8 29 bc 24 10 02 	vmovaps %xmm7,0x210(%rsp)
    1649:	00 00 
    164b:	c5 78 29 84 24 20 02 	vmovaps %xmm8,0x220(%rsp)
    1652:	00 00 
    1654:	c5 78 29 8c 24 30 02 	vmovaps %xmm9,0x230(%rsp)
    165b:	00 00 
    165d:	c5 78 29 94 24 40 02 	vmovaps %xmm10,0x240(%rsp)
    1664:	00 00 
    1666:	c5 78 29 9c 24 50 02 	vmovaps %xmm11,0x250(%rsp)
    166d:	00 00 
    166f:	c5 78 29 a4 24 60 02 	vmovaps %xmm12,0x260(%rsp)
    1676:	00 00 
    1678:	c5 78 29 ac 24 70 02 	vmovaps %xmm13,0x270(%rsp)
    167f:	00 00 
    1681:	c5 78 29 b4 24 80 02 	vmovaps %xmm14,0x280(%rsp)
    1688:	00 00 
    168a:	c5 78 29 bc 24 90 02 	vmovaps %xmm15,0x290(%rsp)
    1691:	00 00 
    1693:	49 89 d2             	mov    %rdx,%r10
    1696:	4d 85 c9             	test   %r9,%r9
    1699:	0f 84 84 09 00 00    	je     2023 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f3>
    169f:	c4 e2 7d 58 62 08    	vpbroadcastd 0x8(%rdx),%ymm4
    16a5:	49 ff c9             	dec    %r9
    16a8:	c4 e2 7d 58 52 1c    	vpbroadcastd 0x1c(%rdx),%ymm2
    16ae:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    16b3:	49 c1 e9 03          	shr    $0x3,%r9
    16b7:	c4 c1 35 72 d3 18    	vpsrld $0x18,%ymm11,%ymm9
    16bd:	48 8d 99 80 01 00 00 	lea    0x180(%rcx),%rbx
    16c4:	c5 fe 7f a4 24 20 01 	vmovdqu %ymm4,0x120(%rsp)
    16cb:	00 00 
    16cd:	c4 e2 7d 58 62 0c    	vpbroadcastd 0xc(%rdx),%ymm4
    16d3:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    16d7:	4d 8d 5c c0 18       	lea    0x18(%r8,%rax,8),%r11
    16dc:	b8 00 80 00 00       	mov    $0x8000,%eax
    16e1:	c5 fe 7f 94 24 c0 01 	vmovdqu %ymm2,0x1c0(%rsp)
    16e8:	00 00 
    16ea:	c5 fe 7f a4 24 40 01 	vmovdqu %ymm4,0x140(%rsp)
    16f1:	00 00 
    16f3:	c4 e2 7d 58 62 10    	vpbroadcastd 0x10(%rdx),%ymm4
    16f9:	c5 fe 7f a4 24 60 01 	vmovdqu %ymm4,0x160(%rsp)
    1700:	00 00 
    1702:	c4 e2 7d 58 62 14    	vpbroadcastd 0x14(%rdx),%ymm4
    1708:	c5 fe 7f a4 24 80 01 	vmovdqu %ymm4,0x180(%rsp)
    170f:	00 00 
    1711:	c4 e2 7d 58 62 18    	vpbroadcastd 0x18(%rdx),%ymm4
    1717:	c5 fe 7f a4 24 a0 01 	vmovdqu %ymm4,0x1a0(%rsp)
    171e:	00 00 
    1720:	c5 f9 6e e0          	vmovd  %eax,%xmm4
    1724:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1729:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    1730:	00 00 
    1732:	e9 b4 00 00 00       	jmp    17eb <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bb>
    1737:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    173e:	00 00 
    1740:	41 8b 42 24          	mov    0x24(%r10),%eax
    1744:	41 8b 52 20          	mov    0x20(%r10),%edx
    1748:	c4 c1 75 fa cd       	vpsubd %ymm13,%ymm1,%ymm1
    174d:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    1752:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    1757:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    175b:	0f af d0             	imul   %eax,%edx
    175e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    1762:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1767:	c4 e2 75 40 c8       	vpmulld %ymm0,%ymm1,%ymm1
    176c:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    1770:	49 8b 02             	mov    (%r10),%rax
    1773:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    1778:	c4 e2 6d 40 d0       	vpmulld %ymm0,%ymm2,%ymm2
    177d:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1781:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1785:	c4 e2 5d 90 04 88    	vpgatherdd %ymm4,(%rax,%ymm1,4),%ymm0
    178b:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    1790:	c5 f5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm1
    1795:	c4 c1 7d db d1       	vpand  %ymm9,%ymm0,%ymm2
    179a:	c4 c1 65 db f1       	vpand  %ymm9,%ymm3,%ymm6
    179f:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    17a4:	c5 fd 72 f6 08       	vpslld $0x8,%ymm6,%ymm0
    17a9:	49 83 c0 18          	add    $0x18,%r8
    17ad:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    17b1:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    17b5:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 17fe <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ce>
    17bc:	00 00 
    17be:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    17c2:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    17c8:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    17cd:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    17d2:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    17d6:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    17dc:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    17e2:	4d 39 c3             	cmp    %r8,%r11
    17e5:	0f 84 35 08 00 00    	je     2020 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9f0>
    17eb:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    17f0:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    17f6:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    17fa:	48 8b 01             	mov    (%rcx),%rax
    17fd:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    1801:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    1807:	8b 51 50             	mov    0x50(%rcx),%edx
    180a:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    1810:	c4 41 79 6e f1       	vmovd  %r9d,%xmm14
    1815:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 181e <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1ee>
    181c:	00 00 
    181e:	c5 f9 6e e2          	vmovd  %edx,%xmm4
    1822:	c4 42 7d 58 f6       	vpbroadcastd %xmm14,%ymm14
    1827:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    182c:	c5 ed 72 d0 10       	vpsrld $0x10,%ymm0,%ymm2
    1831:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    1836:	c4 e2 45 90 1c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm3
    183c:	48 8b 41 08          	mov    0x8(%rcx),%rax
    1840:	c4 c1 75 db c1       	vpand  %ymm9,%ymm1,%ymm0
    1845:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1849:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    184e:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    1853:	c4 e2 45 90 2c 80    	vpgatherdd %ymm7,(%rax,%ymm0,4),%ymm5
    1859:	c5 fd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm0
    185e:	48 8b 41 10          	mov    0x10(%rcx),%rax
    1862:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1866:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    186b:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    1870:	c5 79 6e d2          	vmovd  %edx,%xmm10
    1874:	c4 c2 75 40 ce       	vpmulld %ymm14,%ymm1,%ymm1
    1879:	c4 e2 45 90 34 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm6
    187f:	c4 42 7d 58 d2       	vpbroadcastd %xmm10,%ymm10
    1884:	48 8b 41 48          	mov    0x48(%rcx),%rax
    1888:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    188d:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1915 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e5>
    1894:	00 
    1895:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 191d <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2ed>
    189c:	00 
    189d:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    18a1:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1929 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f9>
    18a8:	00 
    18a9:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    18ae:	c4 62 65 39 ed       	vpminsd %ymm5,%ymm3,%ymm13
    18b3:	c4 62 15 39 e6       	vpminsd %ymm6,%ymm13,%ymm12
    18b8:	c5 15 66 ee          	vpcmpgtd %ymm6,%ymm13,%ymm13
    18bc:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    18c0:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    18c4:	c5 ad fe d1          	vpaddd %ymm1,%ymm10,%ymm2
    18c8:	c4 62 45 90 3c 88    	vpgatherdd %ymm7,(%rax,%ymm1,4),%ymm15
    18ce:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    18d2:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    18d7:	c5 65 fe d5          	vpaddd %ymm5,%ymm3,%ymm10
    18db:	c4 e2 45 90 04 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm0
    18e1:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    18e5:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    18ea:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    18ee:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    18f3:	c4 c1 05 db e9       	vpand  %ymm9,%ymm15,%ymm5
    18f8:	c4 c3 5d 4c d6 20    	vpblendvb %ymm2,%ymm14,%ymm4,%ymm2
    18fe:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 1927 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f7>
    1905:	00 00 70 
    1908:	c4 c1 3d fe fc       	vpaddd %ymm12,%ymm8,%ymm7
    190d:	c4 c3 5d 4c e6 30    	vpblendvb %ymm3,%ymm14,%ymm4,%ymm4
    1913:	c5 7e 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm14
    191a:	00 00 
    191c:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    1920:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    1925:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm4,%ymm4        # 194e <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x31e>
    192c:	00 00 d0 
    192f:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    1933:	c4 c1 45 fe fa       	vpaddd %ymm10,%ymm7,%ymm7
    1938:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    193d:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    1941:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    1945:	c4 e2 2d 90 14 88    	vpgatherdd %ymm10,(%rax,%ymm1,4),%ymm2
    194b:	c4 e2 4d 90 1c a0    	vpgatherdd %ymm6,(%rax,%ymm4,4),%ymm3
    1951:	c4 41 6d db d1       	vpand  %ymm9,%ymm2,%ymm10
    1956:	c4 c1 7d db c9       	vpand  %ymm9,%ymm0,%ymm1
    195b:	c4 c1 65 db e1       	vpand  %ymm9,%ymm3,%ymm4
    1960:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    1965:	c5 ad fa ed          	vpsubd %ymm5,%ymm10,%ymm5
    1969:	c5 f5 fa cc          	vpsubd %ymm4,%ymm1,%ymm1
    196d:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    1972:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1977:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    197c:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    1981:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1986:	c5 ad 72 d2 08       	vpsrld $0x8,%ymm2,%ymm10
    198b:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1990:	c4 41 2d db d1       	vpand  %ymm9,%ymm10,%ymm10
    1995:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    199a:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    199e:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    19a2:	c4 c1 4d 72 d7 08    	vpsrld $0x8,%ymm15,%ymm6
    19a8:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    19ac:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    19b1:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    19b6:	c5 dd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm4
    19bb:	c5 95 72 f6 10       	vpslld $0x10,%ymm6,%ymm13
    19c0:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    19c5:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    19ca:	c5 ad fa f6          	vpsubd %ymm6,%ymm10,%ymm6
    19ce:	c4 41 15 fe ee       	vpaddd %ymm14,%ymm13,%ymm13
    19d3:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    19d8:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    19dd:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    19e1:	c4 c1 55 fa ea       	vpsubd %ymm10,%ymm5,%ymm5
    19e6:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    19eb:	c4 c1 65 db d9       	vpand  %ymm9,%ymm3,%ymm3
    19f0:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    19f5:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    19fa:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    19ff:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1a04:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    1a08:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    1a0c:	c4 c2 7d 40 c4       	vpmulld %ymm12,%ymm0,%ymm0
    1a11:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    1a16:	c5 dd fe e6          	vpaddd %ymm6,%ymm4,%ymm4
    1a1a:	c4 c1 55 fe ed       	vpaddd %ymm13,%ymm5,%ymm5
    1a1f:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    1a23:	c4 c1 55 72 d7 10    	vpsrld $0x10,%ymm15,%ymm5
    1a29:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    1a2e:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1a33:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    1a38:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    1a3c:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
    1a40:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1a45:	c4 c1 4d fe f6       	vpaddd %ymm14,%ymm6,%ymm6
    1a4a:	c5 7e 6f 84 24 60 01 	vmovdqu 0x160(%rsp),%ymm8
    1a51:	00 00 
    1a53:	c5 7e 6f bc 24 a0 01 	vmovdqu 0x1a0(%rsp),%ymm15
    1a5a:	00 00 
    1a5c:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    1a60:	c5 7e 6f ac 24 20 01 	vmovdqu 0x120(%rsp),%ymm13
    1a67:	00 00 
    1a69:	c5 95 66 f9          	vpcmpgtd %ymm1,%ymm13,%ymm7
    1a6d:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    1a71:	c5 bd 66 c2          	vpcmpgtd %ymm2,%ymm8,%ymm0
    1a75:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    1a79:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    1a7e:	c5 d5 fa d9          	vpsubd %ymm1,%ymm5,%ymm3
    1a82:	c5 85 66 f3          	vpcmpgtd %ymm3,%ymm15,%ymm6
    1a86:	c5 fd eb c6          	vpor   %ymm6,%ymm0,%ymm0
    1a8a:	c5 e5 66 b4 24 c0 01 	vpcmpgtd 0x1c0(%rsp),%ymm3,%ymm6
    1a91:	00 00 
    1a93:	c5 fd eb c6          	vpor   %ymm6,%ymm0,%ymm0
    1a97:	c5 f5 66 b4 24 40 01 	vpcmpgtd 0x140(%rsp),%ymm1,%ymm6
    1a9e:	00 00 
    1aa0:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    1aa4:	c5 ed 66 bc 24 80 01 	vpcmpgtd 0x180(%rsp),%ymm2,%ymm7
    1aab:	00 00 
    1aad:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
    1ab1:	c5 fd eb c6          	vpor   %ymm6,%ymm0,%ymm0
    1ab5:	c5 fd d7 c0          	vpmovmskb %ymm0,%eax
    1ab9:	85 c0                	test   %eax,%eax
    1abb:	0f 84 7f fc ff ff    	je     1740 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x110>
    1ac1:	c5 fe 7f 4c 24 60    	vmovdqu %ymm1,0x60(%rsp)
    1ac7:	48 8d 41 60          	lea    0x60(%rcx),%rax
    1acb:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    1ad1:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    1ad7:	48 8b 10             	mov    (%rax),%rdx
    1ada:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    1ae0:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1ae4:	8b 70 54             	mov    0x54(%rax),%esi
    1ae7:	44 8b 48 50          	mov    0x50(%rax),%r9d
    1aeb:	c4 e2 5d 90 04 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm0
    1af1:	48 8b 50 08          	mov    0x8(%rax),%rdx
    1af5:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    1afb:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1aff:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    1b04:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 1b8c <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x55c>
    1b0b:	00 
    1b0c:	c4 e2 5d 90 2c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm5
    1b12:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1b16:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    1b1c:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    1b20:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    1b25:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1bad <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x57d>
    1b2c:	00 
    1b2d:	c4 e2 5d 90 3c 92    	vpgatherdd %ymm4,(%rdx,%ymm2,4),%ymm7
    1b33:	c4 c1 79 6e d1       	vmovd  %r9d,%xmm2
    1b38:	c5 f9 6e e6          	vmovd  %esi,%xmm4
    1b3c:	48 8b 50 48          	mov    0x48(%rax),%rdx
    1b40:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    1b45:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    1b4a:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    1b4f:	c4 e2 65 40 da       	vpmulld %ymm2,%ymm3,%ymm3
    1b54:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    1b59:	c4 62 7d 39 f5       	vpminsd %ymm5,%ymm0,%ymm14
    1b5e:	c5 cd 72 d7 11       	vpsrld $0x11,%ymm7,%ymm6
    1b63:	c5 55 66 e0          	vpcmpgtd %ymm0,%ymm5,%ymm12
    1b67:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 1bef <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5bf>
    1b6e:	00 
    1b6f:	c4 62 0d 39 d7       	vpminsd %ymm7,%ymm14,%ymm10
    1b74:	c5 0d 66 f7          	vpcmpgtd %ymm7,%ymm14,%ymm14
    1b78:	c4 63 6d 4c e4 c0    	vpblendvb %ymm12,%ymm4,%ymm2,%ymm12
    1b7e:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    1b82:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1b86:	c5 75 fe fe          	vpaddd %ymm6,%ymm1,%ymm15
    1b8a:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    1b8f:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    1b96:	00 00 
    1b98:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    1b9d:	c4 22 65 90 2c ba    	vpgatherdd %ymm3,(%rdx,%ymm15,4),%ymm13
    1ba3:	c4 c1 75 fe df       	vpaddd %ymm15,%ymm1,%ymm3
    1ba8:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    1bac:	c5 fe 7f 1c 24       	vmovdqu %ymm3,(%rsp)
    1bb1:	c4 e2 75 90 34 9a    	vpgatherdd %ymm1,(%rdx,%ymm3,4),%ymm6
    1bb7:	c4 e2 7d 3d dd       	vpmaxsd %ymm5,%ymm0,%ymm3
    1bbc:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
    1bc0:	c4 e2 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm3
    1bc5:	c4 41 65 fe c2       	vpaddd %ymm10,%ymm3,%ymm8
    1bca:	c4 41 45 fa c0       	vpsubd %ymm8,%ymm7,%ymm8
    1bcf:	c5 fe 6f 3c 24       	vmovdqu (%rsp),%ymm7
    1bd4:	c4 63 1d 4c 25 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm12,%ymm12        # 1bfd <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5cd>
    1bdb:	00 00 10 
    1bde:	c5 fd fe cd          	vpaddd %ymm5,%ymm0,%ymm1
    1be2:	c5 fd 66 c5          	vpcmpgtd %ymm5,%ymm0,%ymm0
    1be6:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    1beb:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1bf0:	c5 3d fe c1          	vpaddd %ymm1,%ymm8,%ymm8
    1bf4:	c4 a2 05 90 0c a2    	vpgatherdd %ymm15,(%rdx,%ymm12,4),%ymm1
    1bfa:	c4 41 75 db f9       	vpand  %ymm9,%ymm1,%ymm15
    1bff:	c4 e3 6d 4c c4 00    	vpblendvb %ymm0,%ymm4,%ymm2,%ymm0
    1c05:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 1c2e <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5fe>
    1c0c:	00 00 e0 
    1c0f:	c5 c5 fa c0          	vpsubd %ymm0,%ymm7,%ymm0
    1c13:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1c17:	c4 62 45 90 24 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm12
    1c1d:	c4 c1 15 db f9       	vpand  %ymm9,%ymm13,%ymm7
    1c22:	c4 c1 4d db c1       	vpand  %ymm9,%ymm6,%ymm0
    1c27:	c4 c1 1d db e9       	vpand  %ymm9,%ymm12,%ymm5
    1c2c:	c5 8d 72 f7 10       	vpslld $0x10,%ymm7,%ymm14
    1c31:	c5 85 fa ff          	vpsubd %ymm7,%ymm15,%ymm7
    1c35:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    1c39:	c4 c1 55 fa ef       	vpsubd %ymm15,%ymm5,%ymm5
    1c3e:	c4 e2 45 40 fb       	vpmulld %ymm3,%ymm7,%ymm7
    1c43:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    1c4a:	00 00 
    1c4c:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1c51:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    1c56:	c4 41 0d fe f7       	vpaddd %ymm15,%ymm14,%ymm14
    1c5b:	c4 c1 55 fe ee       	vpaddd %ymm14,%ymm5,%ymm5
    1c60:	c5 fd fe c7          	vpaddd %ymm7,%ymm0,%ymm0
    1c64:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1c68:	c5 d5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm5
    1c6d:	c5 fd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm0
    1c72:	c5 fe 7f ac 24 c0 00 	vmovdqu %ymm5,0xc0(%rsp)
    1c79:	00 00 
    1c7b:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    1c80:	c4 c1 55 72 d5 08    	vpsrld $0x8,%ymm13,%ymm5
    1c86:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    1c8a:	c4 c1 15 72 d5 10    	vpsrld $0x10,%ymm13,%ymm13
    1c90:	c4 c1 4d db f1       	vpand  %ymm9,%ymm6,%ymm6
    1c95:	c4 c1 55 db e9       	vpand  %ymm9,%ymm5,%ymm5
    1c9a:	c4 41 15 db f1       	vpand  %ymm9,%ymm13,%ymm14
    1c9f:	c5 c5 72 f5 10       	vpslld $0x10,%ymm5,%ymm7
    1ca4:	c5 fe 7f b4 24 e0 00 	vmovdqu %ymm6,0xe0(%rsp)
    1cab:	00 00 
    1cad:	c4 c1 7d db c1       	vpand  %ymm9,%ymm0,%ymm0
    1cb2:	c4 c1 4d 72 f6 10    	vpslld $0x10,%ymm14,%ymm6
    1cb8:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    1cbd:	c4 41 4d fe ff       	vpaddd %ymm15,%ymm6,%ymm15
    1cc2:	c5 7e 7f bc 24 00 01 	vmovdqu %ymm15,0x100(%rsp)
    1cc9:	00 00 
    1ccb:	0f 84 c7 00 00 00    	je     1d98 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x768>
    1cd1:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    1cd6:	c4 c1 5d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm4
    1cdc:	48 83 c0 60          	add    $0x60,%rax
    1ce0:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1ce5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1cea:	c4 c1 6d db d1       	vpand  %ymm9,%ymm2,%ymm2
    1cef:	c5 fd fa c4          	vpsubd %ymm4,%ymm0,%ymm0
    1cf3:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    1cf7:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    1cfd:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    1d02:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    1d07:	c5 ed fa d5          	vpsubd %ymm5,%ymm2,%ymm2
    1d0b:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    1d10:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    1d15:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1d1a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    1d1e:	c5 fe 6f a4 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm4
    1d25:	00 00 
    1d27:	c5 ed fe d7          	vpaddd %ymm7,%ymm2,%ymm2
    1d2b:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1d2f:	c4 c1 5d fa d4       	vpsubd %ymm12,%ymm4,%ymm2
    1d34:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    1d39:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1d3e:	c5 1d fa e1          	vpsubd %ymm1,%ymm12,%ymm12
    1d42:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    1d47:	c4 42 1d 40 e0       	vpmulld %ymm8,%ymm12,%ymm12
    1d4c:	c5 fd 6f f0          	vmovdqa %ymm0,%ymm6
    1d50:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    1d55:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    1d5a:	c4 c1 75 fe cf       	vpaddd %ymm15,%ymm1,%ymm1
    1d5f:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    1d63:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    1d68:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    1d6c:	48 39 d8             	cmp    %rbx,%rax
    1d6f:	0f 84 9b 02 00 00    	je     2010 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9e0>
    1d75:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    1d7b:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    1d81:	c5 fe 6f a4 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm4
    1d88:	00 00 
    1d8a:	c5 fe 7f 64 24 60    	vmovdqu %ymm4,0x60(%rsp)
    1d90:	e9 42 fd ff ff       	jmp    1ad7 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4a7>
    1d95:	0f 1f 00             	nopl   (%rax)
    1d98:	4c 8b 48 28          	mov    0x28(%rax),%r9
    1d9c:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    1da2:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1da6:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1dab:	c5 7e 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm12
    1db1:	48 83 c0 60          	add    $0x60,%rax
    1db5:	c4 c2 65 90 34 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm6
    1dbb:	4c 8b 48 c0          	mov    -0x40(%rax),%r9
    1dbf:	c5 fe 6f 4c 24 40    	vmovdqu 0x40(%rsp),%ymm1
    1dc5:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1dc9:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 1e51 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x821>
    1dd0:	00 
    1dd1:	c4 42 65 90 04 89    	vpgatherdd %ymm3,(%r9,%ymm1,4),%ymm8
    1dd7:	4c 8b 48 b8          	mov    -0x48(%rax),%r9
    1ddb:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    1ddf:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 1e67 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x837>
    1de6:	00 
    1de7:	c4 82 65 90 0c a1    	vpgatherdd %ymm3,(%r9,%ymm12,4),%ymm1
    1ded:	4c 8b 48 e0          	mov    -0x20(%rax),%r9
    1df1:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 1e79 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x849>
    1df8:	00 
    1df9:	c4 42 75 3d e8       	vpmaxsd %ymm8,%ymm1,%ymm13
    1dfe:	c5 3d 66 d1          	vpcmpgtd %ymm1,%ymm8,%ymm10
    1e02:	c4 42 75 39 e0       	vpminsd %ymm8,%ymm1,%ymm12
    1e07:	c4 c1 4d 66 dd       	vpcmpgtd %ymm13,%ymm6,%ymm3
    1e0c:	c4 62 15 3d ee       	vpmaxsd %ymm6,%ymm13,%ymm13
    1e11:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    1e17:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm10,%ymm10        # 1e40 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x810>
    1e1e:	00 00 30 
    1e21:	c4 e2 1d 39 de       	vpminsd %ymm6,%ymm12,%ymm3
    1e26:	c5 2d fe 94 24 a0 00 	vpaddd 0xa0(%rsp),%ymm10,%ymm10
    1e2d:	00 00 
    1e2f:	c5 fe 7f 9c 24 e0 01 	vmovdqu %ymm3,0x1e0(%rsp)
    1e36:	00 00 
    1e38:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    1e3c:	c4 a2 05 90 1c 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm3
    1e42:	c4 41 75 66 d0       	vpcmpgtd %ymm8,%ymm1,%ymm10
    1e47:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1e4c:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    1e51:	c4 c1 75 fe c8       	vpaddd %ymm8,%ymm1,%ymm1
    1e56:	c5 7e 6f 44 24 40    	vmovdqu 0x40(%rsp),%ymm8
    1e5c:	c4 63 6d 4c d4 a0    	vpblendvb %ymm10,%ymm4,%ymm2,%ymm10
    1e62:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm10,%ymm10        # 1e8b <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x85b>
    1e69:	00 00 c0 
    1e6c:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    1e71:	c4 41 1d fa d2       	vpsubd %ymm10,%ymm12,%ymm10
    1e76:	c4 22 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm12
    1e7c:	c5 7e 6f bc 24 e0 01 	vmovdqu 0x1e0(%rsp),%ymm15
    1e83:	00 00 
    1e85:	c4 41 65 db d1       	vpand  %ymm9,%ymm3,%ymm10
    1e8a:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    1e90:	c4 c1 15 fe df       	vpaddd %ymm15,%ymm13,%ymm3
    1e95:	c4 41 1d db e1       	vpand  %ymm9,%ymm12,%ymm12
    1e9a:	c5 cd fa f3          	vpsubd %ymm3,%ymm6,%ymm6
    1e9e:	c4 c1 1d fa da       	vpsubd %ymm10,%ymm12,%ymm3
    1ea3:	c5 2d fa d5          	vpsubd %ymm5,%ymm10,%ymm10
    1ea7:	c5 cd fe c9          	vpaddd %ymm1,%ymm6,%ymm1
    1eab:	c5 fe 6f 6c 24 20    	vmovdqu 0x20(%rsp),%ymm5
    1eb1:	c4 42 2d 40 d5       	vpmulld %ymm13,%ymm10,%ymm10
    1eb6:	c4 e2 75 40 cb       	vpmulld %ymm3,%ymm1,%ymm1
    1ebb:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    1ec0:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    1ec5:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    1eca:	c5 2d fe d7          	vpaddd %ymm7,%ymm10,%ymm10
    1ece:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    1ed2:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    1ed6:	c4 c2 45 90 04 a9    	vpgatherdd %ymm7,(%r9,%ymm5,4),%ymm0
    1edc:	4c 8b 48 d8          	mov    -0x28(%rax),%r9
    1ee0:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    1ee4:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 1f6c <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x93c>
    1eeb:	00 
    1eec:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    1ef1:	c4 82 55 90 3c 81    	vpgatherdd %ymm5,(%r9,%ymm8,4),%ymm7
    1ef7:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    1efd:	4c 8b 48 d0          	mov    -0x30(%rax),%r9
    1f01:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    1f06:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 1f8e <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x95e>
    1f0d:	00 
    1f0e:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    1f13:	c4 82 3d 90 2c a9    	vpgatherdd %ymm8,(%r9,%ymm13,4),%ymm5
    1f19:	c5 fd 6f f3          	vmovdqa %ymm3,%ymm6
    1f1d:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 1fa5 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x975>
    1f24:	00 
    1f25:	c4 62 55 3d d7       	vpmaxsd %ymm7,%ymm5,%ymm10
    1f2a:	c5 45 66 c5          	vpcmpgtd %ymm5,%ymm7,%ymm8
    1f2e:	c4 62 55 39 e7       	vpminsd %ymm7,%ymm5,%ymm12
    1f33:	c4 c1 7d 66 ca       	vpcmpgtd %ymm10,%ymm0,%ymm1
    1f38:	c4 62 1d 39 e8       	vpminsd %ymm0,%ymm12,%ymm13
    1f3d:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    1f42:	c5 1d 66 e0          	vpcmpgtd %ymm0,%ymm12,%ymm12
    1f46:	c4 63 6d 4c c4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm8
    1f4c:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # 1f75 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x945>
    1f53:	00 00 10 
    1f56:	c5 3d fe 84 24 a0 00 	vpaddd 0xa0(%rsp),%ymm8,%ymm8
    1f5d:	00 00 
    1f5f:	c4 a2 05 90 0c 82    	vpgatherdd %ymm15,(%rdx,%ymm8,4),%ymm1
    1f65:	c5 55 66 c7          	vpcmpgtd %ymm7,%ymm5,%ymm8
    1f69:	c5 d5 fe ef          	vpaddd %ymm7,%ymm5,%ymm5
    1f6d:	c5 fe 6f bc 24 e0 00 	vmovdqu 0xe0(%rsp),%ymm7
    1f74:	00 00 
    1f76:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    1f7b:	c4 c1 75 db c9       	vpand  %ymm9,%ymm1,%ymm1
    1f80:	c4 e3 6d 4c d4 80    	vpblendvb %ymm8,%ymm4,%ymm2,%ymm2
    1f86:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 1faf <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x97f>
    1f8d:	00 00 c0 
    1f90:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    1f95:	c5 9d fa d2          	vpsubd %ymm2,%ymm12,%ymm2
    1f99:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    1f9e:	c4 e2 1d 90 24 92    	vpgatherdd %ymm12,(%rdx,%ymm2,4),%ymm4
    1fa4:	c4 c1 2d fe d5       	vpaddd %ymm13,%ymm10,%ymm2
    1fa9:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    1fae:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    1fb2:	c4 c1 5d db e1       	vpand  %ymm9,%ymm4,%ymm4
    1fb7:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    1fbb:	c5 dd fa d1          	vpsubd %ymm1,%ymm4,%ymm2
    1fbf:	c4 c1 75 fa ce       	vpsubd %ymm14,%ymm1,%ymm1
    1fc4:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    1fc9:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    1fce:	c5 c5 fa d4          	vpsubd %ymm4,%ymm7,%ymm2
    1fd2:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    1fd7:	c5 f5 fe 8c 24 00 01 	vpaddd 0x100(%rsp),%ymm1,%ymm1
    1fde:	00 00 
    1fe0:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    1fe4:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    1fe8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    1fed:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    1ff1:	48 39 c3             	cmp    %rax,%rbx
    1ff4:	74 1a                	je     2010 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9e0>
    1ff6:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    1ffc:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    2002:	e9 7a fd ff ff       	jmp    1d81 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x751>
    2007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    200e:	00 00 
    2010:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    2017:	00 00 
    2019:	e9 81 f7 ff ff       	jmp    179f <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x16f>
    201e:	66 90                	xchg   %ax,%ax
    2020:	c5 f8 77             	vzeroupper
    2023:	c5 f8 28 b4 24 00 02 	vmovaps 0x200(%rsp),%xmm6
    202a:	00 00 
    202c:	c5 f8 28 bc 24 10 02 	vmovaps 0x210(%rsp),%xmm7
    2033:	00 00 
    2035:	c5 78 28 84 24 20 02 	vmovaps 0x220(%rsp),%xmm8
    203c:	00 00 
    203e:	c5 78 28 8c 24 30 02 	vmovaps 0x230(%rsp),%xmm9
    2045:	00 00 
    2047:	c5 78 28 94 24 40 02 	vmovaps 0x240(%rsp),%xmm10
    204e:	00 00 
    2050:	c5 78 28 9c 24 50 02 	vmovaps 0x250(%rsp),%xmm11
    2057:	00 00 
    2059:	c5 78 28 a4 24 60 02 	vmovaps 0x260(%rsp),%xmm12
    2060:	00 00 
    2062:	c5 78 28 ac 24 70 02 	vmovaps 0x270(%rsp),%xmm13
    2069:	00 00 
    206b:	c5 78 28 b4 24 80 02 	vmovaps 0x280(%rsp),%xmm14
    2072:	00 00 
    2074:	c5 78 28 bc 24 90 02 	vmovaps 0x290(%rsp),%xmm15
    207b:	00 00 
    207d:	48 81 c4 a8 02 00 00 	add    $0x2a8,%rsp
    2084:	5b                   	pop    %rbx
    2085:	5e                   	pop    %rsi
    2086:	c3                   	ret
    2087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    208e:	00 00 

0000000000002090 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    2090:	48 81 ec 68 02 00 00 	sub    $0x268,%rsp
    2097:	c5 f8 29 b4 24 c0 01 	vmovaps %xmm6,0x1c0(%rsp)
    209e:	00 00 
    20a0:	c5 f8 29 bc 24 d0 01 	vmovaps %xmm7,0x1d0(%rsp)
    20a7:	00 00 
    20a9:	c5 78 29 84 24 e0 01 	vmovaps %xmm8,0x1e0(%rsp)
    20b0:	00 00 
    20b2:	c5 78 29 8c 24 f0 01 	vmovaps %xmm9,0x1f0(%rsp)
    20b9:	00 00 
    20bb:	c5 78 29 94 24 00 02 	vmovaps %xmm10,0x200(%rsp)
    20c2:	00 00 
    20c4:	c5 78 29 9c 24 10 02 	vmovaps %xmm11,0x210(%rsp)
    20cb:	00 00 
    20cd:	c5 78 29 a4 24 20 02 	vmovaps %xmm12,0x220(%rsp)
    20d4:	00 00 
    20d6:	c5 78 29 ac 24 30 02 	vmovaps %xmm13,0x230(%rsp)
    20dd:	00 00 
    20df:	c5 78 29 b4 24 40 02 	vmovaps %xmm14,0x240(%rsp)
    20e6:	00 00 
    20e8:	c5 78 29 bc 24 50 02 	vmovaps %xmm15,0x250(%rsp)
    20ef:	00 00 
    20f1:	48 89 c8             	mov    %rcx,%rax
    20f4:	49 89 d2             	mov    %rdx,%r10
    20f7:	4d 85 c9             	test   %r9,%r9
    20fa:	0f 84 eb 0c 00 00    	je     2deb <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd5b>
    2100:	c4 e2 7d 58 7a 08    	vpbroadcastd 0x8(%rdx),%ymm7
    2106:	49 ff c9             	dec    %r9
    2109:	c4 41 0d 76 f6       	vpcmpeqd %ymm14,%ymm14,%ymm14
    210e:	49 c1 e9 03          	shr    $0x3,%r9
    2112:	c4 c1 05 72 d6 18    	vpsrld $0x18,%ymm14,%ymm15
    2118:	c5 fe 7f bc 24 00 01 	vmovdqu %ymm7,0x100(%rsp)
    211f:	00 00 
    2121:	c4 e2 7d 58 7a 0c    	vpbroadcastd 0xc(%rdx),%ymm7
    2127:	c5 fe 7f bc 24 20 01 	vmovdqu %ymm7,0x120(%rsp)
    212e:	00 00 
    2130:	c4 e2 7d 58 7a 10    	vpbroadcastd 0x10(%rdx),%ymm7
    2136:	c5 fe 7f bc 24 40 01 	vmovdqu %ymm7,0x140(%rsp)
    213d:	00 00 
    213f:	c4 e2 7d 58 7a 14    	vpbroadcastd 0x14(%rdx),%ymm7
    2145:	c5 fe 7f bc 24 60 01 	vmovdqu %ymm7,0x160(%rsp)
    214c:	00 00 
    214e:	c4 e2 7d 58 7a 18    	vpbroadcastd 0x18(%rdx),%ymm7
    2154:	c5 fe 7f bc 24 80 01 	vmovdqu %ymm7,0x180(%rsp)
    215b:	00 00 
    215d:	c4 e2 7d 58 7a 1c    	vpbroadcastd 0x1c(%rdx),%ymm7
    2163:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    2167:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
    216c:	ba 00 80 00 00       	mov    $0x8000,%edx
    2171:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    2178:	00 00 
    217a:	c5 f9 6e fa          	vmovd  %edx,%xmm7
    217e:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    2183:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    2188:	e9 ad 00 00 00       	jmp    223a <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1aa>
    218d:	0f 1f 00             	nopl   (%rax)
    2190:	41 8b 52 24          	mov    0x24(%r10),%edx
    2194:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    2198:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    219d:	c5 e5 fa df          	vpsubd %ymm7,%ymm3,%ymm3
    21a1:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    21a6:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    21aa:	0f af ca             	imul   %edx,%ecx
    21ad:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
    21b1:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    21b6:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    21bb:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    21bf:	49 8b 12             	mov    (%r10),%rdx
    21c2:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    21c7:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    21cc:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    21d0:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    21d4:	c4 e2 45 90 14 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm2
    21da:	c5 f5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm1
    21df:	c4 c1 6d db e7       	vpand  %ymm15,%ymm2,%ymm4
    21e4:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    21e9:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    21ee:	c5 ed 72 f2 10       	vpslld $0x10,%ymm2,%ymm2
    21f3:	c5 fd 72 f1 08       	vpslld $0x8,%ymm1,%ymm0
    21f8:	49 83 c0 18          	add    $0x18,%r8
    21fc:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2200:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    2204:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 224d <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bd>
    220b:	00 00 
    220d:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2211:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2217:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    221c:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2221:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2225:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    222b:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    2231:	4d 39 d8             	cmp    %r11,%r8
    2234:	0f 84 ae 0b 00 00    	je     2de8 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xd58>
    223a:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    223f:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    2245:	c5 7d 7f f4          	vmovdqa %ymm14,%ymm4
    2249:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    224e:	48 8b 10             	mov    (%rax),%rdx
    2251:	44 8b 48 54          	mov    0x54(%rax),%r9d
    2255:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    225b:	8b 48 50             	mov    0x50(%rax),%ecx
    225e:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    2264:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 226d <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1dd>
    226b:	00 00 
    226d:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2272:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    2277:	c4 c1 7d db f7       	vpand  %ymm15,%ymm0,%ymm6
    227c:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    2282:	c4 e2 5d 90 14 b2    	vpgatherdd %ymm4,(%rdx,%ymm6,4),%ymm2
    2288:	c4 c1 75 db e7       	vpand  %ymm15,%ymm1,%ymm4
    228d:	48 8b 50 08          	mov    0x8(%rax),%rdx
    2291:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    2295:	c5 fe 7f 64 24 40    	vmovdqu %ymm4,0x40(%rsp)
    229b:	c4 e2 75 90 2c a2    	vpgatherdd %ymm1,(%rdx,%ymm4,4),%ymm5
    22a1:	48 8b 50 10          	mov    0x10(%rax),%rdx
    22a5:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    22ac:	00 00 
    22ae:	c5 7d 7f f1          	vmovdqa %ymm14,%ymm1
    22b2:	c5 fd 72 d5 11       	vpsrld $0x11,%ymm5,%ymm0
    22b7:	c5 dd 72 d2 11       	vpsrld $0x11,%ymm2,%ymm4
    22bc:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 2344 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2b4>
    22c3:	00 
    22c4:	c4 e2 75 90 1c ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm3
    22ca:	c5 f9 6e c9          	vmovd  %ecx,%xmm1
    22ce:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    22d3:	48 8b 50 48          	mov    0x48(%rax),%rdx
    22d7:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    22dc:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    22e1:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    22e6:	c4 e2 5d 40 e1       	vpmulld %ymm1,%ymm4,%ymm4
    22eb:	c4 e2 7d 40 c7       	vpmulld %ymm7,%ymm0,%ymm0
    22f0:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 2378 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e8>
    22f7:	00 
    22f8:	c5 cd 72 d3 11       	vpsrld $0x11,%ymm3,%ymm6
    22fd:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2385 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f5>
    2304:	00 
    2305:	c4 62 6d 39 c5       	vpminsd %ymm5,%ymm2,%ymm8
    230a:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    230e:	c5 7d fe ce          	vpaddd %ymm6,%ymm0,%ymm9
    2312:	c5 7d 7f f0          	vmovdqa %ymm14,%ymm0
    2316:	c4 e2 6d 3d f5       	vpmaxsd %ymm5,%ymm2,%ymm6
    231b:	c4 22 7d 90 1c 8a    	vpgatherdd %ymm0,(%rdx,%ymm9,4),%ymm11
    2321:	c5 e5 66 e6          	vpcmpgtd %ymm6,%ymm3,%ymm4
    2325:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    2329:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    232e:	c4 e2 4d 3d f3       	vpmaxsd %ymm3,%ymm6,%ymm6
    2333:	c4 41 7d fe e9       	vpaddd %ymm9,%ymm0,%ymm13
    2338:	c4 a2 2d 90 04 aa    	vpgatherdd %ymm10,(%rdx,%ymm13,4),%ymm0
    233e:	c5 7e 7f 4c 24 60    	vmovdqu %ymm9,0x60(%rsp)
    2344:	c4 62 3d 39 d3       	vpminsd %ymm3,%ymm8,%ymm10
    2349:	c5 7d 6f e0          	vmovdqa %ymm0,%ymm12
    234d:	c5 d5 66 c2          	vpcmpgtd %ymm2,%ymm5,%ymm0
    2351:	c5 3d 66 c3          	vpcmpgtd %ymm3,%ymm8,%ymm8
    2355:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    235b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm0,%ymm0        # 2384 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f4>
    2362:	00 00 40 
    2365:	c4 c1 7d fe c1       	vpaddd %ymm9,%ymm0,%ymm0
    236a:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    236f:	c4 e2 35 90 24 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm4
    2375:	c5 ed 66 c5          	vpcmpgtd %ymm5,%ymm2,%ymm0
    2379:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    237e:	c4 c1 5d db e7       	vpand  %ymm15,%ymm4,%ymm4
    2383:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    2387:	c4 e3 75 4c c7 00    	vpblendvb %ymm0,%ymm7,%ymm1,%ymm0
    238d:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm0,%ymm0        # 23b6 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x326>
    2394:	00 00 80 
    2397:	c5 95 fa c0          	vpsubd %ymm0,%ymm13,%ymm0
    239b:	c4 62 35 90 04 82    	vpgatherdd %ymm9,(%rdx,%ymm0,4),%ymm8
    23a1:	c5 7e 7f 9c 24 80 00 	vmovdqu %ymm11,0x80(%rsp)
    23a8:	00 00 
    23aa:	c4 41 4d fe da       	vpaddd %ymm10,%ymm6,%ymm11
    23af:	c5 05 db 8c 24 80 00 	vpand  0x80(%rsp),%ymm15,%ymm9
    23b6:	00 00 
    23b8:	c4 41 3d db c7       	vpand  %ymm15,%ymm8,%ymm8
    23bd:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    23c2:	48 8b 48 28          	mov    0x28(%rax),%rcx
    23c6:	c4 41 7d 6f de       	vmovdqa %ymm14,%ymm11
    23cb:	c5 e5 fe d2          	vpaddd %ymm2,%ymm3,%ymm2
    23cf:	c5 bd fa dc          	vpsubd %ymm4,%ymm8,%ymm3
    23d3:	c4 c1 7d 72 f1 10    	vpslld $0x10,%ymm9,%ymm0
    23d9:	c4 e2 6d 40 db       	vpmulld %ymm3,%ymm2,%ymm3
    23de:	c4 c1 05 db d4       	vpand  %ymm12,%ymm15,%ymm2
    23e3:	c4 c1 5d fa e1       	vpsubd %ymm9,%ymm4,%ymm4
    23e8:	c4 c1 6d fa d0       	vpsubd %ymm8,%ymm2,%ymm2
    23ed:	c4 e2 5d 40 e6       	vpmulld %ymm6,%ymm4,%ymm4
    23f2:	c5 fd fe 04 24       	vpaddd (%rsp),%ymm0,%ymm0
    23f7:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    23fc:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    2401:	c5 e5 fe c0          	vpaddd %ymm0,%ymm3,%ymm0
    2405:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    240b:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    240f:	c5 fe 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm4
    2416:	00 00 
    2418:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    241c:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    2422:	c4 e2 2d 90 34 a1    	vpgatherdd %ymm10,(%rcx,%ymm4,4),%ymm6
    2428:	48 8b 48 20          	mov    0x20(%rax),%rcx
    242c:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2431:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    2436:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 24be <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x42e>
    243d:	00 
    243e:	c4 62 2d 90 04 91    	vpgatherdd %ymm10,(%rcx,%ymm2,4),%ymm8
    2444:	48 8b 48 18          	mov    0x18(%rax),%rcx
    2448:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    244d:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 24d5 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x445>
    2454:	00 
    2455:	c4 e2 2d 90 14 99    	vpgatherdd %ymm10,(%rcx,%ymm3,4),%ymm2
    245b:	48 8b 48 40          	mov    0x40(%rax),%rcx
    245f:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 24e7 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x457>
    2466:	00 
    2467:	c4 42 6d 3d d0       	vpmaxsd %ymm8,%ymm2,%ymm10
    246c:	c5 bd 66 e2          	vpcmpgtd %ymm2,%ymm8,%ymm4
    2470:	c4 c2 6d 39 e8       	vpminsd %ymm8,%ymm2,%ymm5
    2475:	c4 c1 4d 66 da       	vpcmpgtd %ymm10,%ymm6,%ymm3
    247a:	c4 62 55 39 ce       	vpminsd %ymm6,%ymm5,%ymm9
    247f:	c4 62 2d 3d d6       	vpmaxsd %ymm6,%ymm10,%ymm10
    2484:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    248b:	00 00 
    248d:	c5 d5 66 ee          	vpcmpgtd %ymm6,%ymm5,%ymm5
    2491:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    2497:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm4,%ymm4        # 24c0 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x430>
    249e:	00 00 30 
    24a1:	c5 dd fe 64 24 60    	vpaddd 0x60(%rsp),%ymm4,%ymm4
    24a7:	c4 e2 25 90 1c a2    	vpgatherdd %ymm11,(%rdx,%ymm4,4),%ymm3
    24ad:	c4 c1 6d 66 e0       	vpcmpgtd %ymm8,%ymm2,%ymm4
    24b2:	c5 7e 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm11
    24b9:	00 00 
    24bb:	c4 c1 6d fe d0       	vpaddd %ymm8,%ymm2,%ymm2
    24c0:	c5 e5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm3
    24c5:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    24ca:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    24d0:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    24d6:	c4 41 25 db df       	vpand  %ymm15,%ymm11,%ymm11
    24db:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm4,%ymm4        # 2504 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x474>
    24e2:	00 00 50 
    24e5:	c5 7d 7f f5          	vmovdqa %ymm14,%ymm5
    24e9:	c5 95 fa e4          	vpsubd %ymm4,%ymm13,%ymm4
    24ed:	c4 62 55 90 0c a2    	vpgatherdd %ymm5,(%rdx,%ymm4,4),%ymm9
    24f3:	c5 7e 7f a4 24 c0 00 	vmovdqu %ymm12,0xc0(%rsp)
    24fa:	00 00 
    24fc:	c4 c1 55 72 d4 08    	vpsrld $0x8,%ymm12,%ymm5
    2502:	c5 2d fe a4 24 e0 00 	vpaddd 0xe0(%rsp),%ymm10,%ymm12
    2509:	00 00 
    250b:	c4 c1 35 72 d1 08    	vpsrld $0x8,%ymm9,%ymm9
    2511:	c4 c1 5d 72 f3 10    	vpslld $0x10,%ymm11,%ymm4
    2517:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    251c:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2521:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    2526:	c5 dd fe 24 24       	vpaddd (%rsp),%ymm4,%ymm4
    252b:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    252f:	c5 b5 fa f3          	vpsubd %ymm3,%ymm9,%ymm6
    2533:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2538:	c4 e2 6d 40 f6       	vpmulld %ymm6,%ymm2,%ymm6
    253d:	c4 c1 65 fa db       	vpsubd %ymm11,%ymm3,%ymm3
    2542:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2547:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    254c:	c4 e2 55 40 ac 24 e0 	vpmulld 0xe0(%rsp),%ymm5,%ymm5
    2553:	00 00 00 
    2556:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    255a:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    2561:	00 00 
    2563:	c5 d5 fe eb          	vpaddd %ymm3,%ymm5,%ymm5
    2567:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    256b:	c4 e2 1d 90 2c b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm5
    2571:	48 8b 48 38          	mov    0x38(%rax),%rcx
    2575:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    257b:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    2580:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    2586:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    258b:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 2613 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x583>
    2592:	00 
    2593:	c4 e2 1d 90 34 91    	vpgatherdd %ymm12,(%rcx,%ymm2,4),%ymm6
    2599:	48 8b 48 30          	mov    0x30(%rax),%rcx
    259d:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    25a2:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 262a <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x59a>
    25a9:	00 
    25aa:	c4 e2 1d 90 14 99    	vpgatherdd %ymm12,(%rcx,%ymm3,4),%ymm2
    25b0:	c4 41 7d 6f e6       	vmovdqa %ymm14,%ymm12
    25b5:	c5 ed db 15 80 00 00 	vpand  0x80(%rip),%ymm2,%ymm2        # 263d <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ad>
    25bc:	00 
    25bd:	c4 62 6d 3d ce       	vpmaxsd %ymm6,%ymm2,%ymm9
    25c2:	c5 4d 66 c2          	vpcmpgtd %ymm2,%ymm6,%ymm8
    25c6:	c4 62 6d 39 d6       	vpminsd %ymm6,%ymm2,%ymm10
    25cb:	c4 c1 55 66 d9       	vpcmpgtd %ymm9,%ymm5,%ymm3
    25d0:	c4 62 2d 39 dd       	vpminsd %ymm5,%ymm10,%ymm11
    25d5:	c4 62 35 3d cd       	vpmaxsd %ymm5,%ymm9,%ymm9
    25da:	c5 2d 66 d5          	vpcmpgtd %ymm5,%ymm10,%ymm10
    25de:	c4 63 75 4c c7 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm8
    25e4:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm3,0x1f(%rip),%ymm8,%ymm8        # 260d <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x57d>
    25eb:	00 00 30 
    25ee:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    25f4:	c4 a2 1d 90 1c 82    	vpgatherdd %ymm12,(%rdx,%ymm8,4),%ymm3
    25fa:	c5 6d 66 c6          	vpcmpgtd %ymm6,%ymm2,%ymm8
    25fe:	c4 41 35 fe e3       	vpaddd %ymm11,%ymm9,%ymm12
    2603:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2608:	c4 c1 55 fa ec       	vpsubd %ymm12,%ymm5,%ymm5
    260d:	c5 ed fe d6          	vpaddd %ymm6,%ymm2,%ymm2
    2611:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2616:	c5 d5 fe d2          	vpaddd %ymm2,%ymm5,%ymm2
    261a:	c4 e3 75 4c cf 80    	vpblendvb %ymm8,%ymm7,%ymm1,%ymm1
    2620:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm1,%ymm1        # 2649 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5b9>
    2627:	00 00 a0 
    262a:	c4 41 7d 6f d6       	vmovdqa %ymm14,%ymm10
    262f:	c5 95 fa c9          	vpsubd %ymm1,%ymm13,%ymm1
    2633:	c5 7e 6f ac 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm13
    263a:	00 00 
    263c:	c4 e2 2d 90 3c 8a    	vpgatherdd %ymm10,(%rdx,%ymm1,4),%ymm7
    2642:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    2649:	00 00 
    264b:	c4 c1 2d 72 d5 10    	vpsrld $0x10,%ymm13,%ymm10
    2651:	c5 c5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm7
    2656:	c5 7e 6f ac 24 80 01 	vmovdqu 0x180(%rsp),%ymm13
    265d:	00 00 
    265f:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2664:	c4 c1 45 db ff       	vpand  %ymm15,%ymm7,%ymm7
    2669:	c4 41 2d db d7       	vpand  %ymm15,%ymm10,%ymm10
    266e:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2673:	c5 c5 fa eb          	vpsubd %ymm3,%ymm7,%ymm5
    2677:	c5 2d fa d7          	vpsubd %ymm7,%ymm10,%ymm10
    267b:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    2682:	00 00 
    2684:	c4 e2 6d 40 ed       	vpmulld %ymm5,%ymm2,%ymm5
    2689:	c4 42 2d 40 d3       	vpmulld %ymm11,%ymm10,%ymm10
    268e:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    2692:	c5 7e 6f 9c 24 00 01 	vmovdqu 0x100(%rsp),%ymm11
    2699:	00 00 
    269b:	c4 c2 65 40 d9       	vpmulld %ymm9,%ymm3,%ymm3
    26a0:	c5 bd 72 f1 10       	vpslld $0x10,%ymm1,%ymm8
    26a5:	c5 3d fe 04 24       	vpaddd (%rsp),%ymm8,%ymm8
    26aa:	c5 a5 66 f0          	vpcmpgtd %ymm0,%ymm11,%ymm6
    26ae:	c4 41 55 fe c0       	vpaddd %ymm8,%ymm5,%ymm8
    26b3:	c5 2d fe d3          	vpaddd %ymm3,%ymm10,%ymm10
    26b7:	c5 dd fa d8          	vpsubd %ymm0,%ymm4,%ymm3
    26bb:	c4 41 3d fe c2       	vpaddd %ymm10,%ymm8,%ymm8
    26c0:	c5 c5 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm1
    26c4:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    26ca:	c5 bd fa e8          	vpsubd %ymm0,%ymm8,%ymm5
    26ce:	c5 95 66 d5          	vpcmpgtd %ymm5,%ymm13,%ymm2
    26d2:	c5 f5 eb ca          	vpor   %ymm2,%ymm1,%ymm1
    26d6:	c5 d5 66 94 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm5,%ymm2
    26dd:	00 00 
    26df:	c5 f5 eb ca          	vpor   %ymm2,%ymm1,%ymm1
    26e3:	c5 fd 66 94 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm2
    26ea:	00 00 
    26ec:	c5 ed eb d6          	vpor   %ymm6,%ymm2,%ymm2
    26f0:	c5 e5 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm3,%ymm6
    26f7:	00 00 
    26f9:	c5 ed eb d6          	vpor   %ymm6,%ymm2,%ymm2
    26fd:	c5 f5 eb ca          	vpor   %ymm2,%ymm1,%ymm1
    2701:	c5 fd d7 d1          	vpmovmskb %ymm1,%edx
    2705:	85 d2                	test   %edx,%edx
    2707:	0f 84 83 fa ff ff    	je     2190 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x100>
    270d:	48 8b 50 60          	mov    0x60(%rax),%rdx
    2711:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2715:	44 8b 88 b4 00 00 00 	mov    0xb4(%rax),%r9d
    271c:	8b 88 b0 00 00 00    	mov    0xb0(%rax),%ecx
    2722:	c4 e2 45 90 1c 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm3
    2728:	48 8b 50 68          	mov    0x68(%rax),%rdx
    272c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2730:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    2735:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    273a:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    273f:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 27c7 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x737>
    2746:	00 
    2747:	c4 e2 45 90 2c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm5
    274d:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    2751:	48 8b 50 70          	mov    0x70(%rax),%rdx
    2755:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2759:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    275e:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2763:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    2768:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    276d:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2772:	c4 a2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm8,4),%ymm6
    2778:	48 8b 90 a8 00 00 00 	mov    0xa8(%rax),%rdx
    277f:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    2784:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    2788:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 2810 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x780>
    278f:	00 
    2790:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2795:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2799:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2821 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x791>
    27a0:	00 
    27a1:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    27a6:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    27ab:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    27b0:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    27b4:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    27b8:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    27bc:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    27c0:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    27c6:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    27ca:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    27d0:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    27d4:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    27da:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    27de:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    27e3:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    27e7:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    27ec:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    27f1:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    27f7:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2820 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x790>
    27fe:	00 00 70 
    2801:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2806:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    280c:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2811:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2815:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2819:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2842 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7b2>
    2820:	00 00 b0 
    2823:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2828:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    282d:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2831:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2837:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    283d:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2842:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    2846:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    284c:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2851:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2856:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
    285d:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    2862:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2866:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    286b:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    286f:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2874:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2879:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    287e:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2883:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2888:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    288d:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2892:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2897:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    289b:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    289f:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    28a5:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    28a9:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    28ae:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    28b3:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    28b8:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    28bd:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    28c2:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    28c7:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    28cb:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    28d0:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    28d5:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    28da:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    28de:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    28e3:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    28e8:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    28ed:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    28f2:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    28f7:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    28fc:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2901:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2905:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2909:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    290e:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2913:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2917:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    291b:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2920:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2924:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
    292a:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    292f:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    2934:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    2939:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    293d:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2942:	c4 c1 65 fe dc       	vpaddd %ymm12,%ymm3,%ymm3
    2947:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    294b:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    2951:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
    2958:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    295c:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    2961:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    2965:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    2969:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    296e:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2974:	44 8b 88 14 01 00 00 	mov    0x114(%rax),%r9d
    297b:	8b 88 10 01 00 00    	mov    0x110(%rax),%ecx
    2981:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2986:	48 8b 90 d0 00 00 00 	mov    0xd0(%rax),%rdx
    298d:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2991:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 2a19 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x989>
    2998:	00 
    2999:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    299e:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    29a2:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    29a7:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    29ac:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    29b1:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    29b7:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    29be:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    29c3:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    29c8:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    29cc:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    29d1:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    29d6:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2a5e <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9ce>
    29dd:	00 
    29de:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    29e2:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2a6a <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9da>
    29e9:	00 
    29ea:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    29ef:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    29f4:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    29f9:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    29fd:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2a01:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2a05:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2a09:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2a0f:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2a13:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2a19:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2a1d:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2a23:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2a27:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2a2c:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2a30:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2a35:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    2a3a:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2a40:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2a69 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9d9>
    2a47:	00 00 70 
    2a4a:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2a4f:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2a55:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2a5a:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2a5e:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    2a64:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2a8d <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x9fd>
    2a6b:	00 00 b0 
    2a6e:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2a72:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2a77:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2a7c:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    2a80:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2a84:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2a8a:	c4 e2 4d 90 0c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm1
    2a90:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2a95:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2a9a:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
    2aa1:	c4 c1 75 db df       	vpand  %ymm15,%ymm1,%ymm3
    2aa6:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2aab:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2aaf:	c5 dd fa e3          	vpsubd %ymm3,%ymm4,%ymm4
    2ab3:	c4 c1 65 fa d9       	vpsubd %ymm9,%ymm3,%ymm3
    2ab8:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2abd:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2ac2:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2ac7:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2acc:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2ad1:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2ad6:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2adb:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2ae0:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2ae4:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2ae8:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2aee:	c5 dd fe e3          	vpaddd %ymm3,%ymm4,%ymm4
    2af2:	c5 d5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm5
    2af7:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2afc:	c5 e5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm3
    2b01:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2b06:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2b0b:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2b10:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2b14:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2b19:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2b1e:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2b23:	c5 e5 fa dd          	vpsubd %ymm5,%ymm3,%ymm3
    2b27:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2b2c:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    2b31:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2b36:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2b3b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2b40:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2b45:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2b4a:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    2b4e:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    2b52:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2b57:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2b5c:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2b60:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2b64:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2b69:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    2b6d:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
    2b73:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2b78:	c5 cd 72 d3 10       	vpsrld $0x10,%ymm3,%ymm6
    2b7d:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    2b82:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    2b86:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2b8b:	c4 c1 65 fe dc       	vpaddd %ymm12,%ymm3,%ymm3
    2b90:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    2b94:	c4 e2 45 90 1c a2    	vpgatherdd %ymm7,(%rdx,%ymm4,4),%ymm3
    2b9a:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2ba1:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2ba5:	c5 ed 72 d3 11       	vpsrld $0x11,%ymm3,%ymm2
    2baa:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    2bae:	c5 d5 fe e9          	vpaddd %ymm1,%ymm5,%ymm5
    2bb2:	c5 fd 72 d5 10       	vpsrld $0x10,%ymm5,%ymm0
    2bb7:	c4 e2 45 90 2c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm5
    2bbd:	48 8b 90 30 01 00 00 	mov    0x130(%rax),%rdx
    2bc4:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2bc8:	c5 f5 72 d5 11       	vpsrld $0x11,%ymm5,%ymm1
    2bcd:	c4 e2 45 90 34 82    	vpgatherdd %ymm7,(%rdx,%ymm0,4),%ymm6
    2bd3:	44 8b 88 74 01 00 00 	mov    0x174(%rax),%r9d
    2bda:	8b 88 70 01 00 00    	mov    0x170(%rax),%ecx
    2be0:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2be4:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    2be9:	48 8b 90 68 01 00 00 	mov    0x168(%rax),%rdx
    2bf0:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 2c78 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbe8>
    2bf7:	00 
    2bf8:	c5 f9 6e e1          	vmovd  %ecx,%xmm4
    2bfc:	c4 41 79 6e e1       	vmovd  %r9d,%xmm12
    2c01:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    2c06:	c4 42 7d 58 e4       	vpbroadcastd %xmm12,%ymm12
    2c0b:	c4 e2 7d 58 e4       	vpbroadcastd %xmm4,%ymm4
    2c10:	c5 79 6e c9          	vmovd  %ecx,%xmm9
    2c14:	c4 e2 6d 40 d4       	vpmulld %ymm4,%ymm2,%ymm2
    2c19:	c4 c2 75 40 cc       	vpmulld %ymm12,%ymm1,%ymm1
    2c1e:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    2c23:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 2cab <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc1b>
    2c2a:	00 
    2c2b:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 2cb3 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc23>
    2c32:	00 
    2c33:	c4 62 65 3d c5       	vpmaxsd %ymm5,%ymm3,%ymm8
    2c38:	c4 62 65 39 dd       	vpminsd %ymm5,%ymm3,%ymm11
    2c3d:	c4 62 25 39 d6       	vpminsd %ymm6,%ymm11,%ymm10
    2c42:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    2c46:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2c4a:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    2c4e:	c5 b5 fe d1          	vpaddd %ymm1,%ymm9,%ymm2
    2c52:	c4 62 45 90 2c 8a    	vpgatherdd %ymm7,(%rdx,%ymm1,4),%ymm13
    2c58:	c5 7d 7f f7          	vmovdqa %ymm14,%ymm7
    2c5c:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    2c62:	c5 65 fe cd          	vpaddd %ymm5,%ymm3,%ymm9
    2c66:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    2c6c:	c5 d5 66 d3          	vpcmpgtd %ymm3,%ymm5,%ymm2
    2c70:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    2c75:	c5 e5 66 dd          	vpcmpgtd %ymm5,%ymm3,%ymm3
    2c79:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    2c7e:	c4 c1 15 db ef       	vpand  %ymm15,%ymm13,%ymm5
    2c83:	c4 c3 5d 4c d4 20    	vpblendvb %ymm2,%ymm12,%ymm4,%ymm2
    2c89:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm2,%ymm2        # 2cb2 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc22>
    2c90:	00 00 70 
    2c93:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    2c98:	c4 c3 5d 4c e4 30    	vpblendvb %ymm3,%ymm12,%ymm4,%ymm4
    2c9e:	c5 7e 6f 24 24       	vmovdqu (%rsp),%ymm12
    2ca3:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    2ca7:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    2cab:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm4,%ymm4        # 2cd4 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc44>
    2cb2:	00 00 b0 
    2cb5:	c4 c1 45 fe f9       	vpaddd %ymm9,%ymm7,%ymm7
    2cba:	c4 41 7d 6f ce       	vmovdqa %ymm14,%ymm9
    2cbf:	c5 7d 7f f6          	vmovdqa %ymm14,%ymm6
    2cc3:	c4 e2 35 90 14 8a    	vpgatherdd %ymm9,(%rdx,%ymm1,4),%ymm2
    2cc9:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    2ccf:	c4 41 6d db cf       	vpand  %ymm15,%ymm2,%ymm9
    2cd4:	c5 f5 fa e4          	vpsubd %ymm4,%ymm1,%ymm4
    2cd8:	c4 e2 4d 90 1c a2    	vpgatherdd %ymm6,(%rdx,%ymm4,4),%ymm3
    2cde:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2ce3:	c4 c1 7d db e7       	vpand  %ymm15,%ymm0,%ymm4
    2ce8:	c4 c1 65 db cf       	vpand  %ymm15,%ymm3,%ymm1
    2ced:	c5 b5 fa ed          	vpsubd %ymm5,%ymm9,%ymm5
    2cf1:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2cf6:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    2cfa:	c4 c1 75 fa c9       	vpsubd %ymm9,%ymm1,%ymm1
    2cff:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2d04:	c4 c2 5d 40 e2       	vpmulld %ymm10,%ymm4,%ymm4
    2d09:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    2d0e:	c5 b5 72 d2 08       	vpsrld $0x8,%ymm2,%ymm9
    2d13:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2d18:	c4 41 35 db cf       	vpand  %ymm15,%ymm9,%ymm9
    2d1d:	c4 c1 6d db d7       	vpand  %ymm15,%ymm2,%ymm2
    2d22:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2d26:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    2d2a:	c4 c1 4d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm6
    2d30:	c5 dd fe e1          	vpaddd %ymm1,%ymm4,%ymm4
    2d34:	c5 d5 72 d3 08       	vpsrld $0x8,%ymm3,%ymm5
    2d39:	c4 c1 4d db f7       	vpand  %ymm15,%ymm6,%ymm6
    2d3e:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    2d43:	c5 a5 72 f6 10       	vpslld $0x10,%ymm6,%ymm11
    2d48:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2d4d:	c4 c1 75 db cf       	vpand  %ymm15,%ymm1,%ymm1
    2d52:	c5 b5 fa f6          	vpsubd %ymm6,%ymm9,%ymm6
    2d56:	c4 41 25 fe dc       	vpaddd %ymm12,%ymm11,%ymm11
    2d5b:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    2d60:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    2d65:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    2d69:	c4 c1 55 fa e9       	vpsubd %ymm9,%ymm5,%ymm5
    2d6e:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    2d73:	c4 c1 65 db df       	vpand  %ymm15,%ymm3,%ymm3
    2d78:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    2d7d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    2d82:	c4 c1 7d db c7       	vpand  %ymm15,%ymm0,%ymm0
    2d87:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    2d8c:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    2d90:	c5 e5 fa da          	vpsubd %ymm2,%ymm3,%ymm3
    2d94:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    2d99:	c4 e2 65 40 df       	vpmulld %ymm7,%ymm3,%ymm3
    2d9e:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    2da2:	c4 c1 55 fe eb       	vpaddd %ymm11,%ymm5,%ymm5
    2da7:	c5 f5 fe cd          	vpaddd %ymm5,%ymm1,%ymm1
    2dab:	c4 c1 55 72 d5 10    	vpsrld $0x10,%ymm13,%ymm5
    2db1:	c4 c1 55 db ef       	vpand  %ymm15,%ymm5,%ymm5
    2db6:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2dbb:	c5 cd 72 f5 10       	vpslld $0x10,%ymm5,%ymm6
    2dc0:	c5 ed fa ed          	vpsubd %ymm5,%ymm2,%ymm5
    2dc4:	c4 c2 55 40 e8       	vpmulld %ymm8,%ymm5,%ymm5
    2dc9:	c4 c1 4d fe f4       	vpaddd %ymm12,%ymm6,%ymm6
    2dce:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    2dd2:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    2dd6:	c5 d5 fe d3          	vpaddd %ymm3,%ymm5,%ymm2
    2dda:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    2ddf:	e9 0a f4 ff ff       	jmp    21ee <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x15e>
    2de4:	0f 1f 40 00          	nopl   0x0(%rax)
    2de8:	c5 f8 77             	vzeroupper
    2deb:	c5 f8 28 b4 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm6
    2df2:	00 00 
    2df4:	c5 f8 28 bc 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm7
    2dfb:	00 00 
    2dfd:	c5 78 28 84 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm8
    2e04:	00 00 
    2e06:	c5 78 28 8c 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm9
    2e0d:	00 00 
    2e0f:	c5 78 28 94 24 00 02 	vmovaps 0x200(%rsp),%xmm10
    2e16:	00 00 
    2e18:	c5 78 28 9c 24 10 02 	vmovaps 0x210(%rsp),%xmm11
    2e1f:	00 00 
    2e21:	c5 78 28 a4 24 20 02 	vmovaps 0x220(%rsp),%xmm12
    2e28:	00 00 
    2e2a:	c5 78 28 ac 24 30 02 	vmovaps 0x230(%rsp),%xmm13
    2e31:	00 00 
    2e33:	c5 78 28 b4 24 40 02 	vmovaps 0x240(%rsp),%xmm14
    2e3a:	00 00 
    2e3c:	c5 78 28 bc 24 50 02 	vmovaps 0x250(%rsp),%xmm15
    2e43:	00 00 
    2e45:	48 81 c4 68 02 00 00 	add    $0x268,%rsp
    2e4c:	c3                   	ret
    2e4d:	0f 1f 00             	nopl   (%rax)

0000000000002e50 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>:
    2e50:	56                   	push   %rsi
    2e51:	53                   	push   %rbx
    2e52:	48 81 ec 88 02 00 00 	sub    $0x288,%rsp
    2e59:	c5 f8 29 b4 24 e0 01 	vmovaps %xmm6,0x1e0(%rsp)
    2e60:	00 00 
    2e62:	c5 f8 29 bc 24 f0 01 	vmovaps %xmm7,0x1f0(%rsp)
    2e69:	00 00 
    2e6b:	c5 78 29 84 24 00 02 	vmovaps %xmm8,0x200(%rsp)
    2e72:	00 00 
    2e74:	c5 78 29 8c 24 10 02 	vmovaps %xmm9,0x210(%rsp)
    2e7b:	00 00 
    2e7d:	c5 78 29 94 24 20 02 	vmovaps %xmm10,0x220(%rsp)
    2e84:	00 00 
    2e86:	c5 78 29 9c 24 30 02 	vmovaps %xmm11,0x230(%rsp)
    2e8d:	00 00 
    2e8f:	c5 78 29 a4 24 40 02 	vmovaps %xmm12,0x240(%rsp)
    2e96:	00 00 
    2e98:	c5 78 29 ac 24 50 02 	vmovaps %xmm13,0x250(%rsp)
    2e9f:	00 00 
    2ea1:	c5 78 29 b4 24 60 02 	vmovaps %xmm14,0x260(%rsp)
    2ea8:	00 00 
    2eaa:	c5 78 29 bc 24 70 02 	vmovaps %xmm15,0x270(%rsp)
    2eb1:	00 00 
    2eb3:	48 89 c8             	mov    %rcx,%rax
    2eb6:	49 89 d2             	mov    %rdx,%r10
    2eb9:	4d 85 c9             	test   %r9,%r9
    2ebc:	0f 84 91 0b 00 00    	je     3a53 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc03>
    2ec2:	c4 e2 7d 58 52 08    	vpbroadcastd 0x8(%rdx),%ymm2
    2ec8:	c4 e2 7d 58 6a 0c    	vpbroadcastd 0xc(%rdx),%ymm5
    2ece:	49 ff c9             	dec    %r9
    2ed1:	48 8d 99 80 01 00 00 	lea    0x180(%rcx),%rbx
    2ed8:	49 c1 e9 03          	shr    $0x3,%r9
    2edc:	c4 e2 7d 58 7a 1c    	vpbroadcastd 0x1c(%rdx),%ymm7
    2ee2:	c5 fe 7f 94 24 00 01 	vmovdqu %ymm2,0x100(%rsp)
    2ee9:	00 00 
    2eeb:	c4 e2 7d 58 52 10    	vpbroadcastd 0x10(%rdx),%ymm2
    2ef1:	c5 fe 7f ac 24 20 01 	vmovdqu %ymm5,0x120(%rsp)
    2ef8:	00 00 
    2efa:	c4 e2 7d 58 6a 14    	vpbroadcastd 0x14(%rdx),%ymm5
    2f00:	c5 fe 7f 94 24 40 01 	vmovdqu %ymm2,0x140(%rsp)
    2f07:	00 00 
    2f09:	c4 e2 7d 58 52 18    	vpbroadcastd 0x18(%rdx),%ymm2
    2f0f:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
    2f13:	4d 8d 5c d0 18       	lea    0x18(%r8,%rdx,8),%r11
    2f18:	ba 00 80 00 00       	mov    $0x8000,%edx
    2f1d:	c5 fe 7f ac 24 60 01 	vmovdqu %ymm5,0x160(%rsp)
    2f24:	00 00 
    2f26:	c5 f9 6e ea          	vmovd  %edx,%xmm5
    2f2a:	c5 fe 7f 94 24 80 01 	vmovdqu %ymm2,0x180(%rsp)
    2f31:	00 00 
    2f33:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    2f38:	c5 fe 7f bc 24 a0 01 	vmovdqu %ymm7,0x1a0(%rsp)
    2f3f:	00 00 
    2f41:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    2f48:	00 00 
    2f4a:	e9 b2 00 00 00       	jmp    3001 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b1>
    2f4f:	90                   	nop
    2f50:	41 8b 52 24          	mov    0x24(%r10),%edx
    2f54:	41 8b 4a 20          	mov    0x20(%r10),%ecx
    2f58:	c4 c1 7d fa c6       	vpsubd %ymm14,%ymm0,%ymm0
    2f5d:	c5 f5 fa cf          	vpsubd %ymm7,%ymm1,%ymm1
    2f61:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    2f66:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    2f6a:	0f af ca             	imul   %edx,%ecx
    2f6d:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    2f71:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2f76:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    2f7b:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    2f7f:	49 8b 12             	mov    (%r10),%rdx
    2f82:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    2f87:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    2f8c:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    2f90:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    2f94:	c4 e2 55 90 0c 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm1
    2f9a:	c5 fd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm0
    2f9f:	c5 f5 db 15 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm2        # 3007 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1b7>
    2fa6:	00 
    2fa7:	c5 7d db 2d 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm13        # 300f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1bf>
    2fae:	00 
    2faf:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    2fb4:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    2fb9:	c4 c1 7d 72 f5 08    	vpslld $0x8,%ymm13,%ymm0
    2fbf:	49 83 c0 18          	add    $0x18,%r8
    2fc3:	c5 fd eb c1          	vpor   %ymm1,%ymm0,%ymm0
    2fc7:	c5 fd eb c2          	vpor   %ymm2,%ymm0,%ymm0
    2fcb:	c4 e2 7d 00 05 40 00 	vpshufb 0x40(%rip),%ymm0,%ymm0        # 3014 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1c4>
    2fd2:	00 00 
    2fd4:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    2fd8:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    2fde:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    2fe3:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    2fe8:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    2fec:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    2ff2:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    2ff8:	4d 39 c3             	cmp    %r8,%r11
    2ffb:	0f 84 4f 0a 00 00    	je     3a50 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc00>
    3001:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    3006:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    300c:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
    3010:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    3015:	48 8b 10             	mov    (%rax),%rdx
    3018:	44 8b 48 54          	mov    0x54(%rax),%r9d
    301c:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    3022:	8b 48 50             	mov    0x50(%rax),%ecx
    3025:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    302b:	c4 41 79 6e c1       	vmovd  %r9d,%xmm8
    3030:	c4 e2 7d 00 05 00 00 	vpshufb 0x0(%rip),%ymm0,%ymm0        # 3039 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x1e9>
    3037:	00 00 
    3039:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    303e:	c5 f5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm1
    3043:	c5 c5 72 d0 10       	vpsrld $0x10,%ymm0,%ymm7
    3048:	c5 fd db 15 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm2        # 30b0 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x260>
    304f:	00 
    3050:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    3055:	c4 e2 55 90 1c 92    	vpgatherdd %ymm5,(%rdx,%ymm2,4),%ymm3
    305b:	c5 f5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm5        # 30c3 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x273>
    3062:	00 
    3063:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3067:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    306b:	c5 f9 6e d1          	vmovd  %ecx,%xmm2
    306f:	41 8d 4c 09 01       	lea    0x1(%r9,%rcx,1),%ecx
    3074:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    307a:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    307f:	c4 e2 75 90 34 aa    	vpgatherdd %ymm1,(%rdx,%ymm5,4),%ymm6
    3085:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3089:	c5 fe 7f 7c 24 60    	vmovdqu %ymm7,0x60(%rsp)
    308f:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    3093:	c5 fd 72 d6 11       	vpsrld $0x11,%ymm6,%ymm0
    3098:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 3120 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2d0>
    309f:	00 
    30a0:	c4 e2 75 90 24 ba    	vpgatherdd %ymm1,(%rdx,%ymm7,4),%ymm4
    30a6:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    30ab:	48 8b 50 48          	mov    0x48(%rax),%rdx
    30af:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 3137 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2e7>
    30b6:	00 
    30b7:	c4 e2 75 40 ca       	vpmulld %ymm2,%ymm1,%ymm1
    30bc:	c4 c2 7d 40 c0       	vpmulld %ymm8,%ymm0,%ymm0
    30c1:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    30c6:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 314e <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2fe>
    30cd:	00 
    30ce:	c4 e2 65 3d fe       	vpmaxsd %ymm6,%ymm3,%ymm7
    30d3:	c4 62 65 39 d6       	vpminsd %ymm6,%ymm3,%ymm10
    30d8:	c4 62 2d 39 e4       	vpminsd %ymm4,%ymm10,%ymm12
    30dd:	c5 2d 66 d4          	vpcmpgtd %ymm4,%ymm10,%ymm10
    30e1:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    30e5:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    30e9:	c5 7d fe f5          	vpaddd %ymm5,%ymm0,%ymm14
    30ed:	c5 dd 66 ef          	vpcmpgtd %ymm7,%ymm4,%ymm5
    30f1:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    30f5:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    30fa:	c4 22 75 90 2c b2    	vpgatherdd %ymm1,(%rdx,%ymm14,4),%ymm13
    3100:	c4 e2 45 3d fc       	vpmaxsd %ymm4,%ymm7,%ymm7
    3105:	c4 41 7d fe fe       	vpaddd %ymm14,%ymm0,%ymm15
    310a:	c5 fd 76 c0          	vpcmpeqd %ymm0,%ymm0,%ymm0
    310e:	c4 a2 7d 90 0c ba    	vpgatherdd %ymm0,(%rdx,%ymm15,4),%ymm1
    3114:	c5 cd 66 c3          	vpcmpgtd %ymm3,%ymm6,%ymm0
    3118:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    311e:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm5,0x1f(%rip),%ymm0,%ymm0        # 3147 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x2f7>
    3125:	00 00 50 
    3128:	c5 8d fe c0          	vpaddd %ymm0,%ymm14,%ymm0
    312c:	c4 e2 25 90 2c 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm5
    3132:	c5 e5 66 c6          	vpcmpgtd %ymm6,%ymm3,%ymm0
    3136:	c5 7e 7f 7c 24 40    	vmovdqu %ymm15,0x40(%rsp)
    313c:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    3141:	c5 e5 fe de          	vpaddd %ymm6,%ymm3,%ymm3
    3145:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    314b:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm0,%ymm0        # 3174 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x324>
    3152:	00 00 a0 
    3155:	c5 85 fa c0          	vpsubd %ymm0,%ymm15,%ymm0
    3159:	c4 41 7d 6f fd       	vmovdqa %ymm13,%ymm15
    315e:	c4 62 25 90 14 82    	vpgatherdd %ymm11,(%rdx,%ymm0,4),%ymm10
    3164:	c5 15 db 1d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm11        # 31cc <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x37c>
    316b:	00 
    316c:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 31d4 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x384>
    3173:	00 
    3174:	c5 2d db 15 60 00 00 	vpand  0x60(%rip),%ymm10,%ymm10        # 31dc <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x38c>
    317b:	00 
    317c:	c4 41 45 fe ec       	vpaddd %ymm12,%ymm7,%ymm13
    3181:	48 8b 48 28          	mov    0x28(%rax),%rcx
    3185:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    318a:	c4 c1 7d 72 f3 10    	vpslld $0x10,%ymm11,%ymm0
    3190:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    3196:	c4 41 15 76 ed       	vpcmpeqd %ymm13,%ymm13,%ymm13
    319b:	c5 dd fe db          	vpaddd %ymm3,%ymm4,%ymm3
    319f:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    31a3:	c4 e2 65 40 e4       	vpmulld %ymm4,%ymm3,%ymm4
    31a8:	c5 f5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm3        # 3210 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x3c0>
    31af:	00 
    31b0:	c4 c1 55 fa eb       	vpsubd %ymm11,%ymm5,%ymm5
    31b5:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    31ba:	c5 fd fe 84 24 80 00 	vpaddd 0x80(%rsp),%ymm0,%ymm0
    31c1:	00 00 
    31c3:	c4 c1 65 fa da       	vpsubd %ymm10,%ymm3,%ymm3
    31c8:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    31cd:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    31d2:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    31d6:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    31db:	c5 e5 fe dd          	vpaddd %ymm5,%ymm3,%ymm3
    31df:	c5 fe 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm5
    31e5:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    31e9:	c4 e2 1d 90 3c a9    	vpgatherdd %ymm12,(%rcx,%ymm5,4),%ymm7
    31ef:	48 8b 48 20          	mov    0x20(%rax),%rcx
    31f3:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    31f8:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    31fd:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 3285 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x435>
    3204:	00 
    3205:	c4 62 1d 90 14 b1    	vpgatherdd %ymm12,(%rcx,%ymm6,4),%ymm10
    320b:	48 8b 48 18          	mov    0x18(%rax),%rcx
    320f:	c4 41 1d 76 e4       	vpcmpeqd %ymm12,%ymm12,%ymm12
    3214:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 329c <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x44c>
    321b:	00 
    321c:	c4 e2 1d 90 1c a1    	vpgatherdd %ymm12,(%rcx,%ymm4,4),%ymm3
    3222:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 32aa <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x45a>
    3229:	00 
    322a:	c4 42 65 3d e2       	vpmaxsd %ymm10,%ymm3,%ymm12
    322f:	c5 ad 66 eb          	vpcmpgtd %ymm3,%ymm10,%ymm5
    3233:	c4 c2 65 39 f2       	vpminsd %ymm10,%ymm3,%ymm6
    3238:	c4 c1 45 66 e4       	vpcmpgtd %ymm12,%ymm7,%ymm4
    323d:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    3242:	c4 62 1d 3d e7       	vpmaxsd %ymm7,%ymm12,%ymm12
    3247:	c5 7e 7f 9c 24 c0 00 	vmovdqu %ymm11,0xc0(%rsp)
    324e:	00 00 
    3250:	c5 cd 66 f7          	vpcmpgtd %ymm7,%ymm6,%ymm6
    3254:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    325a:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm5,%ymm5        # 3283 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x433>
    3261:	00 00 40 
    3264:	c5 8d fe ed          	vpaddd %ymm5,%ymm14,%ymm5
    3268:	c4 e2 15 90 24 aa    	vpgatherdd %ymm13,(%rdx,%ymm5,4),%ymm4
    326e:	c4 c1 65 66 ea       	vpcmpgtd %ymm10,%ymm3,%ymm5
    3273:	c4 c1 65 fe da       	vpaddd %ymm10,%ymm3,%ymm3
    3278:	c4 c1 15 72 d7 08    	vpsrld $0x8,%ymm15,%ymm13
    327e:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    3283:	c5 15 db 2d 60 00 00 	vpand  0x60(%rip),%ymm13,%ymm13        # 32eb <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x49b>
    328a:	00 
    328b:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    3291:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm5,%ymm5        # 32ba <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x46a>
    3298:	00 00 60 
    329b:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    32a1:	c5 cd fa ed          	vpsubd %ymm5,%ymm6,%ymm5
    32a5:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    32a9:	c4 62 4d 90 1c aa    	vpgatherdd %ymm6,(%rdx,%ymm5,4),%ymm11
    32af:	c5 7e 7f bc 24 a0 00 	vmovdqu %ymm15,0xa0(%rsp)
    32b6:	00 00 
    32b8:	c5 cd 72 d1 08       	vpsrld $0x8,%ymm1,%ymm6
    32bd:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    32c3:	c4 c1 55 72 f5 10    	vpslld $0x10,%ymm13,%ymm5
    32c9:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 3331 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4e1>
    32d0:	00 
    32d1:	c5 1d fe bc 24 c0 00 	vpaddd 0xc0(%rsp),%ymm12,%ymm15
    32d8:	00 00 
    32da:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3342 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x4f2>
    32e1:	00 
    32e2:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    32e7:	c5 d5 fe ac 24 80 00 	vpaddd 0x80(%rsp),%ymm5,%ymm5
    32ee:	00 00 
    32f0:	c4 c1 45 fa ff       	vpsubd %ymm15,%ymm7,%ymm7
    32f5:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 335d <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x50d>
    32fc:	00 
    32fd:	48 8b 48 40          	mov    0x40(%rax),%rcx
    3301:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3306:	c5 c5 fe db          	vpaddd %ymm3,%ymm7,%ymm3
    330a:	c5 a5 fa fc          	vpsubd %ymm4,%ymm11,%ymm7
    330e:	c4 e2 65 40 ff       	vpmulld %ymm7,%ymm3,%ymm7
    3313:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    3318:	c4 c1 4d fa f3       	vpsubd %ymm11,%ymm6,%ymm6
    331d:	c5 fe 6f 5c 24 20    	vmovdqu 0x20(%rsp),%ymm3
    3323:	c4 c2 5d 40 e4       	vpmulld %ymm12,%ymm4,%ymm4
    3328:	c4 e2 4d 40 b4 24 c0 	vpmulld 0xc0(%rsp),%ymm6,%ymm6
    332f:	00 00 00 
    3332:	c5 c5 fe ed          	vpaddd %ymm5,%ymm7,%ymm5
    3336:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    333c:	c5 cd fe f4          	vpaddd %ymm4,%ymm6,%ymm6
    3340:	c5 fe 6f 24 24       	vmovdqu (%rsp),%ymm4
    3345:	c5 d5 fe ee          	vpaddd %ymm6,%ymm5,%ymm5
    3349:	c4 e2 05 90 34 b9    	vpgatherdd %ymm15,(%rcx,%ymm7,4),%ymm6
    334f:	48 8b 48 38          	mov    0x38(%rax),%rcx
    3353:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3358:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 33e0 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x590>
    335f:	00 
    3360:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    3365:	c4 e2 05 90 3c 99    	vpgatherdd %ymm15,(%rcx,%ymm3,4),%ymm7
    336b:	48 8b 48 30          	mov    0x30(%rax),%rcx
    336f:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3374:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 33fc <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5ac>
    337b:	00 
    337c:	c4 e2 05 90 1c a1    	vpgatherdd %ymm15,(%rcx,%ymm4,4),%ymm3
    3382:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3387:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 340f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5bf>
    338e:	00 
    338f:	c4 62 65 3d df       	vpmaxsd %ymm7,%ymm3,%ymm11
    3394:	c5 45 66 d3          	vpcmpgtd %ymm3,%ymm7,%ymm10
    3398:	c4 62 65 39 e7       	vpminsd %ymm7,%ymm3,%ymm12
    339d:	c4 c1 4d 66 e3       	vpcmpgtd %ymm11,%ymm6,%ymm4
    33a2:	c4 62 1d 39 ee       	vpminsd %ymm6,%ymm12,%ymm13
    33a7:	c4 62 25 3d de       	vpmaxsd %ymm6,%ymm11,%ymm11
    33ac:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    33b0:	c4 43 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm10
    33b6:	c4 63 2d 4c 15 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm10,%ymm10        # 33df <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x58f>
    33bd:	00 00 40 
    33c0:	c4 41 0d fe d2       	vpaddd %ymm10,%ymm14,%ymm10
    33c5:	c4 a2 05 90 24 92    	vpgatherdd %ymm15,(%rdx,%ymm10,4),%ymm4
    33cb:	c5 65 66 d7          	vpcmpgtd %ymm7,%ymm3,%ymm10
    33cf:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    33d5:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    33d9:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    33de:	c5 dd db 25 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm4        # 3446 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5f6>
    33e5:	00 
    33e6:	c4 c3 6d 4c d0 a0    	vpblendvb %ymm10,%ymm8,%ymm2,%ymm2
    33ec:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 3415 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x5c5>
    33f3:	00 00 c0 
    33f6:	c4 41 25 fe e5       	vpaddd %ymm13,%ymm11,%ymm12
    33fb:	c5 85 fa d2          	vpsubd %ymm2,%ymm15,%ymm2
    33ff:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3404:	c4 c1 4d fa f4       	vpsubd %ymm12,%ymm6,%ymm6
    3409:	c4 62 05 90 04 92    	vpgatherdd %ymm15,(%rdx,%ymm2,4),%ymm8
    340f:	c5 fe 6f 94 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm2
    3416:	00 00 
    3418:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    341c:	c4 c1 3d 72 d0 10    	vpsrld $0x10,%ymm8,%ymm8
    3422:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3427:	c5 3d db 05 60 00 00 	vpand  0x60(%rip),%ymm8,%ymm8        # 348f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x63f>
    342e:	00 
    342f:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 3497 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x647>
    3436:	00 
    3437:	c5 bd fa f4          	vpsubd %ymm4,%ymm8,%ymm6
    343b:	c5 ad 72 f2 10       	vpslld $0x10,%ymm2,%ymm10
    3440:	c4 e2 65 40 f6       	vpmulld %ymm6,%ymm3,%ymm6
    3445:	c5 dd fa e2          	vpsubd %ymm2,%ymm4,%ymm4
    3449:	c5 2d fe 94 24 80 00 	vpaddd 0x80(%rsp),%ymm10,%ymm10
    3450:	00 00 
    3452:	c4 c2 5d 40 e3       	vpmulld %ymm11,%ymm4,%ymm4
    3457:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 34bf <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x66f>
    345e:	00 
    345f:	c5 fe 6f bc 24 40 01 	vmovdqu 0x140(%rsp),%ymm7
    3466:	00 00 
    3468:	c5 7e 6f bc 24 80 01 	vmovdqu 0x180(%rsp),%ymm15
    346f:	00 00 
    3471:	c4 c1 75 fa c8       	vpsubd %ymm8,%ymm1,%ymm1
    3476:	c5 7e 6f b4 24 00 01 	vmovdqu 0x100(%rsp),%ymm14
    347d:	00 00 
    347f:	c4 c2 75 40 cd       	vpmulld %ymm13,%ymm1,%ymm1
    3484:	c4 41 4d fe d2       	vpaddd %ymm10,%ymm6,%ymm10
    3489:	c5 8d 66 f0          	vpcmpgtd %ymm0,%ymm14,%ymm6
    348d:	c5 f5 fe cc          	vpaddd %ymm4,%ymm1,%ymm1
    3491:	c5 2d fe d1          	vpaddd %ymm1,%ymm10,%ymm10
    3495:	c5 d5 fa c8          	vpsubd %ymm0,%ymm5,%ymm1
    3499:	c4 c1 2d 72 d2 10    	vpsrld $0x10,%ymm10,%ymm10
    349f:	c5 c5 66 d1          	vpcmpgtd %ymm1,%ymm7,%ymm2
    34a3:	c5 ad fa d8          	vpsubd %ymm0,%ymm10,%ymm3
    34a7:	c5 85 66 e3          	vpcmpgtd %ymm3,%ymm15,%ymm4
    34ab:	c5 ed eb d4          	vpor   %ymm4,%ymm2,%ymm2
    34af:	c5 e5 66 a4 24 a0 01 	vpcmpgtd 0x1a0(%rsp),%ymm3,%ymm4
    34b6:	00 00 
    34b8:	c5 ed eb e4          	vpor   %ymm4,%ymm2,%ymm4
    34bc:	c5 fd 66 94 24 20 01 	vpcmpgtd 0x120(%rsp),%ymm0,%ymm2
    34c3:	00 00 
    34c5:	c5 ed eb d6          	vpor   %ymm6,%ymm2,%ymm2
    34c9:	c5 f5 66 b4 24 60 01 	vpcmpgtd 0x160(%rsp),%ymm1,%ymm6
    34d0:	00 00 
    34d2:	c5 ed eb d6          	vpor   %ymm6,%ymm2,%ymm2
    34d6:	c5 dd eb d2          	vpor   %ymm2,%ymm4,%ymm2
    34da:	c5 fd d7 d2          	vpmovmskb %ymm2,%edx
    34de:	85 d2                	test   %edx,%edx
    34e0:	0f 84 6a fa ff ff    	je     2f50 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x100>
    34e6:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    34ec:	48 8d 50 60          	lea    0x60(%rax),%rdx
    34f0:	c5 fe 7f 6c 24 20    	vmovdqu %ymm5,0x20(%rsp)
    34f6:	c5 7e 7f 14 24       	vmovdqu %ymm10,(%rsp)
    34fb:	48 8b 0a             	mov    (%rdx),%rcx
    34fe:	c5 fe 6f 54 24 40    	vmovdqu 0x40(%rsp),%ymm2
    3504:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    3508:	8b 72 54             	mov    0x54(%rdx),%esi
    350b:	44 8b 4a 50          	mov    0x50(%rdx),%r9d
    350f:	c4 e2 45 90 04 91    	vpgatherdd %ymm7,(%rcx,%ymm2,4),%ymm0
    3515:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    3519:	c5 fe 6f 54 24 20    	vmovdqu 0x20(%rsp),%ymm2
    351f:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    3523:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
    3528:	c5 f9 6e ee          	vmovd  %esi,%xmm5
    352c:	46 8d 4c 0e 01       	lea    0x1(%rsi,%r9,1),%r9d
    3531:	c4 e2 45 90 34 91    	vpgatherdd %ymm7,(%rcx,%ymm2,4),%ymm6
    3537:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    353b:	c5 fe 6f 14 24       	vmovdqu (%rsp),%ymm2
    3540:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    3544:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3549:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    354e:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    3553:	c4 62 45 90 04 91    	vpgatherdd %ymm7,(%rcx,%ymm2,4),%ymm8
    3559:	c5 ed 72 d0 11       	vpsrld $0x11,%ymm0,%ymm2
    355e:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 35e6 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x796>
    3565:	00 
    3566:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
    356a:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    356f:	c4 e2 75 40 cd       	vpmulld %ymm5,%ymm1,%ymm1
    3574:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 35fc <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ac>
    357b:	00 
    357c:	c4 c1 5d 72 d0 11    	vpsrld $0x11,%ymm8,%ymm4
    3582:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 360a <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7ba>
    3589:	00 
    358a:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    358e:	c5 4d 66 d8          	vpcmpgtd %ymm0,%ymm6,%ymm11
    3592:	c4 62 7d 39 ee       	vpminsd %ymm6,%ymm0,%ymm13
    3597:	c4 42 15 39 d0       	vpminsd %ymm8,%ymm13,%ymm10
    359c:	c4 41 15 66 e8       	vpcmpgtd %ymm8,%ymm13,%ymm13
    35a1:	c5 f5 fe ca          	vpaddd %ymm2,%ymm1,%ymm1
    35a5:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    35ab:	c5 75 fe fc          	vpaddd %ymm4,%ymm1,%ymm15
    35af:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
    35b4:	c4 e2 7d 3d e6       	vpmaxsd %ymm6,%ymm0,%ymm4
    35b9:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    35be:	c5 7e 7f 7c 24 60    	vmovdqu %ymm15,0x60(%rsp)
    35c4:	c4 41 75 fe f7       	vpaddd %ymm15,%ymm1,%ymm14
    35c9:	c5 bd 66 cc          	vpcmpgtd %ymm4,%ymm8,%ymm1
    35cd:	c4 a2 45 90 14 b9    	vpgatherdd %ymm7,(%rcx,%ymm15,4),%ymm2
    35d3:	c4 c2 5d 3d e0       	vpmaxsd %ymm8,%ymm4,%ymm4
    35d8:	c5 7e 7f b4 24 a0 00 	vmovdqu %ymm14,0xa0(%rsp)
    35df:	00 00 
    35e1:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    35e5:	c4 22 45 90 24 b1    	vpgatherdd %ymm7,(%rcx,%ymm14,4),%ymm12
    35eb:	c4 c1 5d fe fa       	vpaddd %ymm10,%ymm4,%ymm7
    35f0:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm11,%ymm11        # 3619 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x7c9>
    35f7:	00 00 10 
    35fa:	c5 fd fe ce          	vpaddd %ymm6,%ymm0,%ymm1
    35fe:	c5 bd fa ff          	vpsubd %ymm7,%ymm8,%ymm7
    3602:	c5 fd 66 c6          	vpcmpgtd %ymm6,%ymm0,%ymm0
    3606:	c4 41 25 fe df       	vpaddd %ymm15,%ymm11,%ymm11
    360b:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    360f:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3614:	c5 c5 fe f9          	vpaddd %ymm1,%ymm7,%ymm7
    3618:	c5 6d db 05 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm8        # 3680 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x830>
    361f:	00 
    3620:	c4 a2 05 90 0c 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm1
    3626:	c4 e3 65 4c c5 00    	vpblendvb %ymm0,%ymm5,%ymm3,%ymm0
    362c:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm13,0x1f(%rip),%ymm0,%ymm0        # 3655 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x805>
    3633:	00 00 d0 
    3636:	c4 c1 15 72 f0 10    	vpslld $0x10,%ymm8,%ymm13
    363c:	c5 8d fa c0          	vpsubd %ymm0,%ymm14,%ymm0
    3640:	c4 62 4d 90 1c 81    	vpgatherdd %ymm6,(%rcx,%ymm0,4),%ymm11
    3646:	c5 a5 db 35 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm6        # 36ae <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x85e>
    364d:	00 
    364e:	c5 75 db 35 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm14        # 36b6 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x866>
    3655:	00 
    3656:	c5 9d db 05 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm0        # 36be <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x86e>
    365d:	00 
    365e:	c5 7e 6f bc 24 80 00 	vmovdqu 0x80(%rsp),%ymm15
    3665:	00 00 
    3667:	c4 41 0d fa c0       	vpsubd %ymm8,%ymm14,%ymm8
    366c:	80 7a 58 00          	cmpb   $0x0,0x58(%rdx)
    3670:	c5 fd fa c6          	vpsubd %ymm6,%ymm0,%ymm0
    3674:	c4 c1 4d fa f6       	vpsubd %ymm14,%ymm6,%ymm6
    3679:	c4 62 3d 40 c4       	vpmulld %ymm4,%ymm8,%ymm8
    367e:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3683:	c4 e2 4d 40 f7       	vpmulld %ymm7,%ymm6,%ymm6
    3688:	c4 41 15 fe ef       	vpaddd %ymm15,%ymm13,%ymm13
    368d:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    3692:	c4 c1 4d fe f5       	vpaddd %ymm13,%ymm6,%ymm6
    3697:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    369b:	c5 cd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm6
    36a0:	c4 c1 7d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm0
    36a6:	c5 fe 7f b4 24 c0 00 	vmovdqu %ymm6,0xc0(%rsp)
    36ad:	00 00 
    36af:	c5 cd 72 d2 08       	vpsrld $0x8,%ymm2,%ymm6
    36b4:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    36b9:	c5 fd db 05 60 00 00 	vpand  0x60(%rip),%ymm0,%ymm0        # 3721 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8d1>
    36c0:	00 
    36c1:	c5 ed db 15 60 00 00 	vpand  0x60(%rip),%ymm2,%ymm2        # 3729 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8d9>
    36c8:	00 
    36c9:	c4 c1 1d 72 d4 10    	vpsrld $0x10,%ymm12,%ymm12
    36cf:	c5 cd db 35 60 00 00 	vpand  0x60(%rip),%ymm6,%ymm6        # 3737 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8e7>
    36d6:	00 
    36d7:	c5 1d db 35 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm14        # 373f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x8ef>
    36de:	00 
    36df:	c5 9d 72 f2 10       	vpslld $0x10,%ymm2,%ymm12
    36e4:	c5 bd 72 f6 10       	vpslld $0x10,%ymm6,%ymm8
    36e9:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    36ee:	c4 41 3d fe c7       	vpaddd %ymm15,%ymm8,%ymm8
    36f3:	c5 7e 7f a4 24 e0 00 	vmovdqu %ymm12,0xe0(%rsp)
    36fa:	00 00 
    36fc:	0f 84 ce 00 00 00    	je     37d0 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x980>
    3702:	c5 e5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm3
    3707:	c4 c1 55 72 d3 08    	vpsrld $0x8,%ymm11,%ymm5
    370d:	48 83 c2 60          	add    $0x60,%rdx
    3711:	c5 d5 db 2d 60 00 00 	vpand  0x60(%rip),%ymm5,%ymm5        # 3779 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x929>
    3718:	00 
    3719:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    371e:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3786 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x936>
    3725:	00 
    3726:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    372c:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 3794 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x944>
    3733:	00 
    3734:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    3738:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    373c:	c5 25 db 1d 60 00 00 	vpand  0x60(%rip),%ymm11,%ymm11        # 37a4 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x954>
    3743:	00 
    3744:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    3749:	c4 e2 55 40 ef       	vpmulld %ymm7,%ymm5,%ymm5
    374e:	c5 e5 fa de          	vpsubd %ymm6,%ymm3,%ymm3
    3752:	c4 e2 65 40 dc       	vpmulld %ymm4,%ymm3,%ymm3
    3757:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    375b:	c4 c1 65 fe d8       	vpaddd %ymm8,%ymm3,%ymm3
    3760:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3764:	c4 c1 0d fa db       	vpsubd %ymm11,%ymm14,%ymm3
    3769:	c4 c2 65 40 da       	vpmulld %ymm10,%ymm3,%ymm3
    376e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3773:	c5 25 fa d9          	vpsubd %ymm1,%ymm11,%ymm11
    3777:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    377b:	c4 62 25 40 df       	vpmulld %ymm7,%ymm11,%ymm11
    3780:	c5 7d 6f e8          	vmovdqa %ymm0,%ymm13
    3784:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    3789:	c4 c1 65 fe db       	vpaddd %ymm11,%ymm3,%ymm3
    378e:	c4 c1 75 fe cc       	vpaddd %ymm12,%ymm1,%ymm1
    3793:	c5 e5 fe d1          	vpaddd %ymm1,%ymm3,%ymm2
    3797:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    379c:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    37a0:	48 39 da             	cmp    %rbx,%rdx
    37a3:	0f 84 97 02 00 00    	je     3a40 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbf0>
    37a9:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    37af:	c5 fe 7f 14 24       	vmovdqu %ymm2,(%rsp)
    37b4:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    37bb:	00 00 
    37bd:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    37c3:	e9 33 fd ff ff       	jmp    34fb <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x6ab>
    37c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    37cf:	00 
    37d0:	4c 8b 4a 28          	mov    0x28(%rdx),%r9
    37d4:	c5 fe 6f 0c 24       	vmovdqu (%rsp),%ymm1
    37d9:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    37dd:	48 83 c2 60          	add    $0x60,%rdx
    37e1:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    37e7:	c4 c2 5d 90 3c 89    	vpgatherdd %ymm4,(%r9,%ymm1,4),%ymm7
    37ed:	4c 8b 4a c0          	mov    -0x40(%rdx),%r9
    37f1:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    37f7:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    37fb:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 3883 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa33>
    3802:	00 
    3803:	c4 42 5d 90 14 89    	vpgatherdd %ymm4,(%r9,%ymm1,4),%ymm10
    3809:	4c 8b 4a b8          	mov    -0x48(%rdx),%r9
    380d:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
    3811:	c5 2d db 15 80 00 00 	vpand  0x80(%rip),%ymm10,%ymm10        # 3899 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa49>
    3818:	00 
    3819:	c4 82 5d 90 0c b9    	vpgatherdd %ymm4,(%r9,%ymm15,4),%ymm1
    381f:	4c 8b 4a e0          	mov    -0x20(%rdx),%r9
    3823:	c5 f5 db 0d 80 00 00 	vpand  0x80(%rip),%ymm1,%ymm1        # 38ab <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa5b>
    382a:	00 
    382b:	c4 42 75 3d ea       	vpmaxsd %ymm10,%ymm1,%ymm13
    3830:	c5 2d 66 d9          	vpcmpgtd %ymm1,%ymm10,%ymm11
    3834:	c4 42 75 39 e2       	vpminsd %ymm10,%ymm1,%ymm12
    3839:	c4 c1 45 66 e5       	vpcmpgtd %ymm13,%ymm7,%ymm4
    383e:	c4 62 1d 39 ff       	vpminsd %ymm7,%ymm12,%ymm15
    3843:	c4 62 15 3d ef       	vpmaxsd %ymm7,%ymm13,%ymm13
    3848:	c5 7e 7f bc 24 c0 01 	vmovdqu %ymm15,0x1c0(%rsp)
    384f:	00 00 
    3851:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3856:	c5 1d 66 e7          	vpcmpgtd %ymm7,%ymm12,%ymm12
    385a:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    3860:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm11,%ymm11        # 3889 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa39>
    3867:	00 00 40 
    386a:	c5 25 fe 5c 24 60    	vpaddd 0x60(%rsp),%ymm11,%ymm11
    3870:	c4 a2 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm4
    3876:	c4 41 75 66 da       	vpcmpgtd %ymm10,%ymm1,%ymm11
    387b:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    3880:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    3885:	c4 c1 75 fe ca       	vpaddd %ymm10,%ymm1,%ymm1
    388a:	c4 63 65 4c dd b0    	vpblendvb %ymm11,%ymm5,%ymm3,%ymm11
    3890:	c4 63 25 4c 1d 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm11,%ymm11        # 38b9 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xa69>
    3897:	00 00 c0 
    389a:	c5 7e 6f a4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm12
    38a1:	00 00 
    38a3:	c4 41 1d fa db       	vpsubd %ymm11,%ymm12,%ymm11
    38a8:	c4 22 05 90 24 99    	vpgatherdd %ymm15,(%rcx,%ymm11,4),%ymm12
    38ae:	c5 7e 6f bc 24 c0 01 	vmovdqu 0x1c0(%rsp),%ymm15
    38b5:	00 00 
    38b7:	c5 5d db 1d 60 00 00 	vpand  0x60(%rip),%ymm4,%ymm11        # 391f <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xacf>
    38be:	00 
    38bf:	c4 c1 1d 72 d4 08    	vpsrld $0x8,%ymm12,%ymm12
    38c5:	c5 1d db 25 60 00 00 	vpand  0x60(%rip),%ymm12,%ymm12        # 392d <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xadd>
    38cc:	00 
    38cd:	c4 c1 15 fe e7       	vpaddd %ymm15,%ymm13,%ymm4
    38d2:	c5 c5 fa fc          	vpsubd %ymm4,%ymm7,%ymm7
    38d6:	c5 c5 fe c9          	vpaddd %ymm1,%ymm7,%ymm1
    38da:	c4 c1 1d fa e3       	vpsubd %ymm11,%ymm12,%ymm4
    38df:	c5 c5 76 ff          	vpcmpeqd %ymm7,%ymm7,%ymm7
    38e3:	c4 c1 7d fa c4       	vpsubd %ymm12,%ymm0,%ymm0
    38e8:	c5 25 fa de          	vpsubd %ymm6,%ymm11,%ymm11
    38ec:	c4 e2 75 40 cc       	vpmulld %ymm4,%ymm1,%ymm1
    38f1:	c5 fe 6f 34 24       	vmovdqu (%rsp),%ymm6
    38f6:	c4 c2 7d 40 c7       	vpmulld %ymm15,%ymm0,%ymm0
    38fb:	c4 42 25 40 dd       	vpmulld %ymm13,%ymm11,%ymm11
    3900:	c5 f5 fe c8          	vpaddd %ymm0,%ymm1,%ymm1
    3904:	c4 41 25 fe d8       	vpaddd %ymm8,%ymm11,%ymm11
    3909:	c4 c2 45 90 04 b1    	vpgatherdd %ymm7,(%r9,%ymm6,4),%ymm0
    390f:	c4 c1 75 fe cb       	vpaddd %ymm11,%ymm1,%ymm1
    3914:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 399c <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb4c>
    391b:	00 
    391c:	4c 8b 4a d8          	mov    -0x28(%rdx),%r9
    3920:	c5 cd 76 f6          	vpcmpeqd %ymm6,%ymm6,%ymm6
    3924:	c5 dd 72 d1 10       	vpsrld $0x10,%ymm1,%ymm4
    3929:	c5 fe 6f 4c 24 20    	vmovdqu 0x20(%rsp),%ymm1
    392f:	c5 7e 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm15
    3935:	c5 7d 6f ec          	vmovdqa %ymm4,%ymm13
    3939:	c4 c2 4d 90 3c 89    	vpgatherdd %ymm6,(%r9,%ymm1,4),%ymm7
    393f:	4c 8b 4a d0          	mov    -0x30(%rdx),%r9
    3943:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
    3947:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 39cf <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb7f>
    394e:	00 
    394f:	c4 82 75 90 34 b9    	vpgatherdd %ymm1,(%r9,%ymm15,4),%ymm6
    3955:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    395a:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 39e2 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb92>
    3961:	00 
    3962:	c4 62 4d 3d d7       	vpmaxsd %ymm7,%ymm6,%ymm10
    3967:	c5 45 66 c6          	vpcmpgtd %ymm6,%ymm7,%ymm8
    396b:	c4 62 4d 39 df       	vpminsd %ymm7,%ymm6,%ymm11
    3970:	c4 c1 7d 66 ca       	vpcmpgtd %ymm10,%ymm0,%ymm1
    3975:	c4 62 25 39 e0       	vpminsd %ymm0,%ymm11,%ymm12
    397a:	c4 62 2d 3d d0       	vpmaxsd %ymm0,%ymm10,%ymm10
    397f:	c5 25 66 d8          	vpcmpgtd %ymm0,%ymm11,%ymm11
    3983:	c4 63 65 4c c5 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm8
    3989:	c4 63 3d 4c 05 1f 00 	vpblendvb %ymm1,0x1f(%rip),%ymm8,%ymm8        # 39b2 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xb62>
    3990:	00 00 10 
    3993:	c5 3d fe 44 24 60    	vpaddd 0x60(%rsp),%ymm8,%ymm8
    3999:	c4 a2 05 90 0c 81    	vpgatherdd %ymm15,(%rcx,%ymm8,4),%ymm1
    399f:	c5 4d 66 c7          	vpcmpgtd %ymm7,%ymm6,%ymm8
    39a3:	c4 41 05 76 ff       	vpcmpeqd %ymm15,%ymm15,%ymm15
    39a8:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    39ad:	c5 cd fe f7          	vpaddd %ymm7,%ymm6,%ymm6
    39b1:	c5 f5 db 0d 60 00 00 	vpand  0x60(%rip),%ymm1,%ymm1        # 3a19 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbc9>
    39b8:	00 
    39b9:	c4 e3 65 4c dd 80    	vpblendvb %ymm8,%ymm5,%ymm3,%ymm3
    39bf:	c5 fe 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm5
    39c6:	00 00 
    39c8:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm3,%ymm3        # 39f1 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xba1>
    39cf:	00 00 b0 
    39d2:	c5 d5 fa eb          	vpsubd %ymm3,%ymm5,%ymm5
    39d6:	c4 e2 05 90 1c a9    	vpgatherdd %ymm15,(%rcx,%ymm5,4),%ymm3
    39dc:	c4 c1 2d fe ec       	vpaddd %ymm12,%ymm10,%ymm5
    39e1:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    39e6:	c5 fd fa c5          	vpsubd %ymm5,%ymm0,%ymm0
    39ea:	c5 e5 db 1d 60 00 00 	vpand  0x60(%rip),%ymm3,%ymm3        # 3a52 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xc02>
    39f1:	00 
    39f2:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    39f6:	c5 e5 fa e9          	vpsubd %ymm1,%ymm3,%ymm5
    39fa:	c5 f5 fa ca          	vpsubd %ymm2,%ymm1,%ymm1
    39fe:	c4 c2 75 40 ca       	vpmulld %ymm10,%ymm1,%ymm1
    3a03:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    3a08:	c5 8d fa db          	vpsubd %ymm3,%ymm14,%ymm3
    3a0c:	c4 c2 65 40 dc       	vpmulld %ymm12,%ymm3,%ymm3
    3a11:	c5 f5 fe 8c 24 e0 00 	vpaddd 0xe0(%rsp),%ymm1,%ymm1
    3a18:	00 00 
    3a1a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3a1e:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3a22:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3a27:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    3a2b:	48 39 d3             	cmp    %rdx,%rbx
    3a2e:	74 10                	je     3a40 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0xbf0>
    3a30:	c5 fe 7f 64 24 20    	vmovdqu %ymm4,0x20(%rsp)
    3a36:	c5 fe 7f 04 24       	vmovdqu %ymm0,(%rsp)
    3a3b:	e9 74 fd ff ff       	jmp    37b4 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x964>
    3a40:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    3a47:	00 00 
    3a49:	e9 66 f5 ff ff       	jmp    2fb4 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)+0x164>
    3a4e:	66 90                	xchg   %ax,%ax
    3a50:	c5 f8 77             	vzeroupper
    3a53:	c5 f8 28 b4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm6
    3a5a:	00 00 
    3a5c:	c5 f8 28 bc 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm7
    3a63:	00 00 
    3a65:	c5 78 28 84 24 00 02 	vmovaps 0x200(%rsp),%xmm8
    3a6c:	00 00 
    3a6e:	c5 78 28 8c 24 10 02 	vmovaps 0x210(%rsp),%xmm9
    3a75:	00 00 
    3a77:	c5 78 28 94 24 20 02 	vmovaps 0x220(%rsp),%xmm10
    3a7e:	00 00 
    3a80:	c5 78 28 9c 24 30 02 	vmovaps 0x230(%rsp),%xmm11
    3a87:	00 00 
    3a89:	c5 78 28 a4 24 40 02 	vmovaps 0x240(%rsp),%xmm12
    3a90:	00 00 
    3a92:	c5 78 28 ac 24 50 02 	vmovaps 0x250(%rsp),%xmm13
    3a99:	00 00 
    3a9b:	c5 78 28 b4 24 60 02 	vmovaps 0x260(%rsp),%xmm14
    3aa2:	00 00 
    3aa4:	c5 78 28 bc 24 70 02 	vmovaps 0x270(%rsp),%xmm15
    3aab:	00 00 
    3aad:	48 81 c4 88 02 00 00 	add    $0x288,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5e                   	pop    %rsi
    3ab6:	c3                   	ret
    3ab7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3abe:	00 00 

0000000000003ac0 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)>:
    3ac0:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
    3ac5:	44 0f b6 91 b8 00 00 	movzbl 0xb8(%rcx),%r10d
    3acc:	00 
    3acd:	0f b6 41 58          	movzbl 0x58(%rcx),%eax
    3ad1:	74 2d                	je     3b00 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x40>
    3ad3:	45 84 d2             	test   %r10b,%r10b
    3ad6:	74 60                	je     3b38 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x78>
    3ad8:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    3adf:	74 57                	je     3b38 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x78>
    3ae1:	44 0f b6 91 78 01 00 	movzbl 0x178(%rcx),%r10d
    3ae8:	00 
    3ae9:	84 c0                	test   %al,%al
    3aeb:	74 6b                	je     3b58 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x98>
    3aed:	45 84 d2             	test   %r10b,%r10b
    3af0:	74 4a                	je     3b3c <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x7c>
    3af2:	e9 09 c5 ff ff       	jmp    0 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3af7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3afe:	00 00 
    3b00:	45 84 d2             	test   %r10b,%r10b
    3b03:	74 23                	je     3b28 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x68>
    3b05:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    3b0c:	74 1a                	je     3b28 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x68>
    3b0e:	44 0f b6 91 78 01 00 	movzbl 0x178(%rcx),%r10d
    3b15:	00 
    3b16:	84 c0                	test   %al,%al
    3b18:	74 4e                	je     3b68 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0xa8>
    3b1a:	45 84 d2             	test   %r10b,%r10b
    3b1d:	74 0d                	je     3b2c <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x6c>
    3b1f:	e9 7c cf ff ff       	jmp    aa0 <void jshc_domain_cache::(anonymous namespace)::cached<true, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b24:	0f 1f 40 00          	nopl   0x0(%rax)
    3b28:	84 c0                	test   %al,%al
    3b2a:	74 24                	je     3b50 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x90>
    3b2c:	e9 ff da ff ff       	jmp    1630 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b38:	84 c0                	test   %al,%al
    3b3a:	74 0c                	je     3b48 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x88>
    3b3c:	e9 bf c4 ff ff       	jmp    0 <void jshc_domain_cache::(anonymous namespace)::cached<true, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b48:	e9 03 c9 ff ff       	jmp    450 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b4d:	0f 1f 00             	nopl   (%rax)
    3b50:	e9 fb f2 ff ff       	jmp    2e50 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b55:	0f 1f 00             	nopl   (%rax)
    3b58:	45 84 d2             	test   %r10b,%r10b
    3b5b:	74 eb                	je     3b48 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x88>
    3b5d:	e9 ee c8 ff ff       	jmp    450 <void jshc_domain_cache::(anonymous namespace)::cached<false, false, true>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3b68:	45 84 d2             	test   %r10b,%r10b
    3b6b:	74 e3                	je     3b50 <jshc_domain_cache::avx2_chain_cached(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long, bool)+0x90>
    3b6d:	e9 1e e5 ff ff       	jmp    2090 <void jshc_domain_cache::(anonymous namespace)::cached<false, true, false>(jshc_domain_cache::View const*, jshc_domain_cache::SuffixCacheView const&, unsigned char*, unsigned long long)>
    3b72:	0f 1f 00             	nopl   (%rax)
    3b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3b7c:	00 00 00 00 

0000000000003b80 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)>:
    3b80:	56                   	push   %rsi
    3b81:	53                   	push   %rbx
    3b82:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
    3b89:	c5 f8 29 b4 24 80 01 	vmovaps %xmm6,0x180(%rsp)
    3b90:	00 00 
    3b92:	c5 f8 29 bc 24 90 01 	vmovaps %xmm7,0x190(%rsp)
    3b99:	00 00 
    3b9b:	c5 78 29 84 24 a0 01 	vmovaps %xmm8,0x1a0(%rsp)
    3ba2:	00 00 
    3ba4:	c5 78 29 8c 24 b0 01 	vmovaps %xmm9,0x1b0(%rsp)
    3bab:	00 00 
    3bad:	c5 78 29 94 24 c0 01 	vmovaps %xmm10,0x1c0(%rsp)
    3bb4:	00 00 
    3bb6:	c5 78 29 9c 24 d0 01 	vmovaps %xmm11,0x1d0(%rsp)
    3bbd:	00 00 
    3bbf:	c5 78 29 a4 24 e0 01 	vmovaps %xmm12,0x1e0(%rsp)
    3bc6:	00 00 
    3bc8:	c5 78 29 ac 24 f0 01 	vmovaps %xmm13,0x1f0(%rsp)
    3bcf:	00 00 
    3bd1:	c5 78 29 b4 24 00 02 	vmovaps %xmm14,0x200(%rsp)
    3bd8:	00 00 
    3bda:	c5 78 29 bc 24 10 02 	vmovaps %xmm15,0x210(%rsp)
    3be1:	00 00 
    3be3:	49 89 d2             	mov    %rdx,%r10
    3be6:	48 83 fa 04          	cmp    $0x4,%rdx
    3bea:	0f 84 b9 06 00 00    	je     42a9 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x729>
    3bf0:	4d 85 c9             	test   %r9,%r9
    3bf3:	0f 84 4c 06 00 00    	je     4245 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c5>
    3bf9:	c5 fd 6f 0d 00 00 00 	vmovdqa 0x0(%rip),%ymm1        # 3c01 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x81>
    3c00:	00 
    3c01:	49 ff c9             	dec    %r9
    3c04:	c4 41 2d 76 d2       	vpcmpeqd %ymm10,%ymm10,%ymm10
    3c09:	49 c1 e9 03          	shr    $0x3,%r9
    3c0d:	c4 c1 1d 72 d2 18    	vpsrld $0x18,%ymm10,%ymm12
    3c13:	4b 8d 04 49          	lea    (%r9,%r9,2),%rax
    3c17:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    3c1e:	00 00 
    3c20:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 3c68 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe8>
    3c27:	00 
    3c28:	4f 8d 0c 52          	lea    (%r10,%r10,2),%r9
    3c2c:	4d 8d 5c c0 18       	lea    0x18(%r8,%rax,8),%r11
    3c31:	b8 00 80 00 00       	mov    $0x8000,%eax
    3c36:	49 c1 e1 05          	shl    $0x5,%r9
    3c3a:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    3c41:	00 00 
    3c43:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    3c47:	49 01 c9             	add    %rcx,%r9
    3c4a:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    3c4f:	c5 fe 7f 8c 24 20 01 	vmovdqu %ymm1,0x120(%rsp)
    3c56:	00 00 
    3c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c5f:	00 
    3c60:	c4 c1 7a 6f 08       	vmovdqu (%r8),%xmm1
    3c65:	c4 c1 7a 7e 40 10    	vmovq  0x10(%r8),%xmm0
    3c6b:	c4 e3 79 0f c1 0c    	vpalignr $0xc,%xmm1,%xmm0,%xmm0
    3c71:	c4 e3 75 38 c8 01    	vinserti128 $0x1,%xmm0,%ymm1,%ymm1
    3c77:	c4 e2 75 00 8c 24 40 	vpshufb 0x140(%rsp),%ymm1,%ymm1
    3c7e:	01 00 00 
    3c81:	c5 ed 72 d1 08       	vpsrld $0x8,%ymm1,%ymm2
    3c86:	c4 c1 75 db c4       	vpand  %ymm12,%ymm1,%ymm0
    3c8b:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    3c90:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    3c95:	4d 85 d2             	test   %r10,%r10
    3c98:	0f 84 57 05 00 00    	je     41f5 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x675>
    3c9e:	c5 fe 7f 44 24 60    	vmovdqu %ymm0,0x60(%rsp)
    3ca4:	48 89 c8             	mov    %rcx,%rax
    3ca7:	c5 fe 7f 54 24 40    	vmovdqu %ymm2,0x40(%rsp)
    3cad:	c5 fe 7f 4c 24 20    	vmovdqu %ymm1,0x20(%rsp)
    3cb3:	e9 c4 00 00 00       	jmp    3d7c <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1fc>
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	c5 ed 72 d4 08       	vpsrld $0x8,%ymm4,%ymm2
    3cc5:	c5 f5 72 d7 08       	vpsrld $0x8,%ymm7,%ymm1
    3cca:	c5 fe 6f 9c 24 80 00 	vmovdqu 0x80(%rsp),%ymm3
    3cd1:	00 00 
    3cd3:	48 83 c0 60          	add    $0x60,%rax
    3cd7:	c4 c1 6d db d4       	vpand  %ymm12,%ymm2,%ymm2
    3cdc:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    3ce1:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    3ce6:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    3cea:	c5 ed fa d1          	vpsubd %ymm1,%ymm2,%ymm2
    3cee:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    3cf3:	c4 e2 6d 40 d3       	vpmulld %ymm3,%ymm2,%ymm2
    3cf8:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    3cfd:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    3d01:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    3d06:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    3d0a:	c5 a5 fa d4          	vpsubd %ymm4,%ymm11,%ymm2
    3d0e:	c4 c1 75 fe ce       	vpaddd %ymm14,%ymm1,%ymm1
    3d13:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    3d18:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    3d1c:	c5 f5 72 d7 10       	vpsrld $0x10,%ymm7,%ymm1
    3d21:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    3d26:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3d2b:	c5 dd fa e1          	vpsubd %ymm1,%ymm4,%ymm4
    3d2f:	c4 c1 75 fa cf       	vpsubd %ymm15,%ymm1,%ymm1
    3d34:	c5 7d 6f f0          	vmovdqa %ymm0,%ymm14
    3d38:	c4 e2 5d 40 e3       	vpmulld %ymm3,%ymm4,%ymm4
    3d3d:	c4 e2 75 40 ce       	vpmulld %ymm6,%ymm1,%ymm1
    3d42:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    3d46:	c4 c1 75 fe c9       	vpaddd %ymm9,%ymm1,%ymm1
    3d4b:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    3d4f:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    3d54:	c5 fd 6f ca          	vmovdqa %ymm2,%ymm1
    3d58:	4c 39 c8             	cmp    %r9,%rax
    3d5b:	0f 84 87 04 00 00    	je     41e8 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x668>
    3d61:	c5 fe 7f 44 24 40    	vmovdqu %ymm0,0x40(%rsp)
    3d67:	c5 fe 7f 54 24 20    	vmovdqu %ymm2,0x20(%rsp)
    3d6d:	c5 fe 6f 94 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm2
    3d74:	00 00 
    3d76:	c5 fe 7f 54 24 60    	vmovdqu %ymm2,0x60(%rsp)
    3d7c:	48 8b 10             	mov    (%rax),%rdx
    3d7f:	c5 fe 6f 54 24 60    	vmovdqu 0x60(%rsp),%ymm2
    3d85:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    3d89:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    3d8f:	8b 58 54             	mov    0x54(%rax),%ebx
    3d92:	c4 e2 45 90 04 92    	vpgatherdd %ymm7,(%rdx,%ymm2,4),%ymm0
    3d98:	48 8b 50 08          	mov    0x8(%rax),%rdx
    3d9c:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    3da0:	8b 70 50             	mov    0x50(%rax),%esi
    3da3:	c5 7d 7f d2          	vmovdqa %ymm10,%ymm2
    3da7:	c5 79 6e c3          	vmovd  %ebx,%xmm8
    3dab:	c4 e2 45 90 1c b2    	vpgatherdd %ymm7,(%rdx,%ymm6,4),%ymm3
    3db1:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3db5:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    3dbb:	c4 42 7d 58 c0       	vpbroadcastd %xmm8,%ymm8
    3dc0:	c5 f5 72 d3 11       	vpsrld $0x11,%ymm3,%ymm1
    3dc5:	c5 cd 72 d0 11       	vpsrld $0x11,%ymm0,%ymm6
    3dca:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 3e52 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2d2>
    3dd1:	00 
    3dd2:	c4 e2 6d 90 24 ba    	vpgatherdd %ymm2,(%rdx,%ymm7,4),%ymm4
    3dd8:	c5 f9 6e d6          	vmovd  %esi,%xmm2
    3ddc:	8d 74 33 01          	lea    0x1(%rbx,%rsi,1),%esi
    3de0:	48 8b 50 48          	mov    0x48(%rax),%rdx
    3de4:	c4 e2 7d 58 d2       	vpbroadcastd %xmm2,%ymm2
    3de9:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    3dee:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 3e76 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x2f6>
    3df5:	00 
    3df6:	c4 e2 4d 40 f2       	vpmulld %ymm2,%ymm6,%ymm6
    3dfb:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    3e00:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 3e88 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x308>
    3e07:	00 
    3e08:	c4 62 7d 39 f3       	vpminsd %ymm3,%ymm0,%ymm14
    3e0d:	c5 7d fe fb          	vpaddd %ymm3,%ymm0,%ymm15
    3e11:	c4 62 0d 39 ec       	vpminsd %ymm4,%ymm14,%ymm13
    3e16:	c5 0d 66 f4          	vpcmpgtd %ymm4,%ymm14,%ymm14
    3e1a:	c5 f5 fe ce          	vpaddd %ymm6,%ymm1,%ymm1
    3e1e:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    3e22:	c5 f5 fe fd          	vpaddd %ymm5,%ymm1,%ymm7
    3e26:	c5 f9 6e ee          	vmovd  %esi,%xmm5
    3e2a:	c4 e2 7d 58 ed       	vpbroadcastd %xmm5,%ymm5
    3e2f:	c4 62 4d 90 1c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm11
    3e35:	c5 fe 7f 3c 24       	vmovdqu %ymm7,(%rsp)
    3e3a:	c5 7d 7f d6          	vmovdqa %ymm10,%ymm6
    3e3e:	c5 d5 fe ff          	vpaddd %ymm7,%ymm5,%ymm7
    3e42:	c5 e5 66 e8          	vpcmpgtd %ymm0,%ymm3,%ymm5
    3e46:	c5 fe 7f bc 24 a0 00 	vmovdqu %ymm7,0xa0(%rsp)
    3e4d:	00 00 
    3e4f:	c5 fd 6f cf          	vmovdqa %ymm7,%ymm1
    3e53:	c4 62 4d 90 0c ba    	vpgatherdd %ymm6,(%rdx,%ymm7,4),%ymm9
    3e59:	c4 e2 7d 3d f3       	vpmaxsd %ymm3,%ymm0,%ymm6
    3e5e:	c5 dd 66 fe          	vpcmpgtd %ymm6,%ymm4,%ymm7
    3e62:	c5 fd 66 c3          	vpcmpgtd %ymm3,%ymm0,%ymm0
    3e66:	c4 e2 4d 3d f4       	vpmaxsd %ymm4,%ymm6,%ymm6
    3e6b:	c4 c3 6d 4c e8 50    	vpblendvb %ymm5,%ymm8,%ymm2,%ymm5
    3e71:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm5,%ymm5        # 3e9a <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x31a>
    3e78:	00 00 70 
    3e7b:	c4 c1 4d fe fd       	vpaddd %ymm13,%ymm6,%ymm7
    3e80:	c4 c3 6d 4c c0 00    	vpblendvb %ymm0,%ymm8,%ymm2,%ymm0
    3e86:	c5 dd fa ff          	vpsubd %ymm7,%ymm4,%ymm7
    3e8a:	c5 d5 fe 2c 24       	vpaddd (%rsp),%ymm5,%ymm5
    3e8f:	c4 e3 7d 4c 05 1f 00 	vpblendvb %ymm14,0x1f(%rip),%ymm0,%ymm0        # 3eb8 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x338>
    3e96:	00 00 e0 
    3e99:	c4 41 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm15
    3e9e:	c5 f5 fa c0          	vpsubd %ymm0,%ymm1,%ymm0
    3ea2:	c5 7e 7f bc 24 80 00 	vmovdqu %ymm15,0x80(%rsp)
    3ea9:	00 00 
    3eab:	c4 41 7d 6f fa       	vmovdqa %ymm10,%ymm15
    3eb0:	c4 e2 05 90 3c aa    	vpgatherdd %ymm15,(%rdx,%ymm5,4),%ymm7
    3eb6:	c5 7d 7f d5          	vmovdqa %ymm10,%ymm5
    3eba:	c4 e2 55 90 24 82    	vpgatherdd %ymm5,(%rdx,%ymm0,4),%ymm4
    3ec0:	c4 41 45 db fc       	vpand  %ymm12,%ymm7,%ymm15
    3ec5:	c4 c1 25 db ec       	vpand  %ymm12,%ymm11,%ymm5
    3eca:	c4 c1 5d db dc       	vpand  %ymm12,%ymm4,%ymm3
    3ecf:	c5 8d 72 f5 10       	vpslld $0x10,%ymm5,%ymm14
    3ed4:	c4 c1 35 db c4       	vpand  %ymm12,%ymm9,%ymm0
    3ed9:	c5 fd fa c3          	vpsubd %ymm3,%ymm0,%ymm0
    3edd:	c5 85 fa ed          	vpsubd %ymm5,%ymm15,%ymm5
    3ee1:	c4 e2 55 40 ee       	vpmulld %ymm6,%ymm5,%ymm5
    3ee6:	c4 c2 7d 40 c5       	vpmulld %ymm13,%ymm0,%ymm0
    3eeb:	c4 c1 65 fa df       	vpsubd %ymm15,%ymm3,%ymm3
    3ef0:	c4 e2 65 40 9c 24 80 	vpmulld 0x80(%rsp),%ymm3,%ymm3
    3ef7:	00 00 00 
    3efa:	c5 fe 6f 8c 24 20 01 	vmovdqu 0x120(%rsp),%ymm1
    3f01:	00 00 
    3f03:	80 78 58 00          	cmpb   $0x0,0x58(%rax)
    3f07:	c5 0d fe f1          	vpaddd %ymm1,%ymm14,%ymm14
    3f0b:	c4 c1 65 fe de       	vpaddd %ymm14,%ymm3,%ymm3
    3f10:	c5 fd fe c5          	vpaddd %ymm5,%ymm0,%ymm0
    3f14:	c4 c1 55 72 d3 08    	vpsrld $0x8,%ymm11,%ymm5
    3f1a:	c5 fd fe c3          	vpaddd %ymm3,%ymm0,%ymm0
    3f1e:	c4 c1 25 72 d3 10    	vpsrld $0x10,%ymm11,%ymm11
    3f24:	c4 c1 55 db ec       	vpand  %ymm12,%ymm5,%ymm5
    3f29:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    3f2e:	c5 e5 72 f5 10       	vpslld $0x10,%ymm5,%ymm3
    3f33:	c4 41 25 db fc       	vpand  %ymm12,%ymm11,%ymm15
    3f38:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    3f3f:	00 00 
    3f41:	c4 c1 7d 72 d1 08    	vpsrld $0x8,%ymm9,%ymm0
    3f47:	c4 c1 35 72 d1 10    	vpsrld $0x10,%ymm9,%ymm9
    3f4d:	c5 65 fe f1          	vpaddd %ymm1,%ymm3,%ymm14
    3f51:	c4 41 35 db dc       	vpand  %ymm12,%ymm9,%ymm11
    3f56:	c4 c1 35 72 f7 10    	vpslld $0x10,%ymm15,%ymm9
    3f5c:	c4 c1 7d db c4       	vpand  %ymm12,%ymm0,%ymm0
    3f61:	c5 35 fe c9          	vpaddd %ymm1,%ymm9,%ymm9
    3f65:	c5 7e 7f 9c 24 00 01 	vmovdqu %ymm11,0x100(%rsp)
    3f6c:	00 00 
    3f6e:	c5 7e 7f 8c 24 e0 00 	vmovdqu %ymm9,0xe0(%rsp)
    3f75:	00 00 
    3f77:	0f 85 43 fd ff ff    	jne    3cc0 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x140>
    3f7d:	48 8b 58 28          	mov    0x28(%rax),%rbx
    3f81:	c5 fe 6f 64 24 20    	vmovdqu 0x20(%rsp),%ymm4
    3f87:	c5 7d 7f d7          	vmovdqa %ymm10,%ymm7
    3f8b:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    3f8f:	c5 fe 6f 5c 24 40    	vmovdqu 0x40(%rsp),%ymm3
    3f95:	c5 7e 6f 6c 24 60    	vmovdqu 0x60(%rsp),%ymm13
    3f9b:	48 83 c0 60          	add    $0x60,%rax
    3f9f:	c4 e2 45 90 34 a3    	vpgatherdd %ymm7,(%rbx,%ymm4,4),%ymm6
    3fa5:	48 8b 58 c0          	mov    -0x40(%rax),%rbx
    3fa9:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3fad:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4035 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4b5>
    3fb4:	00 
    3fb5:	c4 e2 5d 90 3c 9b    	vpgatherdd %ymm4,(%rbx,%ymm3,4),%ymm7
    3fbb:	48 8b 58 b8          	mov    -0x48(%rax),%rbx
    3fbf:	c5 7d 7f d4          	vmovdqa %ymm10,%ymm4
    3fc3:	c5 c5 db 3d 80 00 00 	vpand  0x80(%rip),%ymm7,%ymm7        # 404b <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4cb>
    3fca:	00 
    3fcb:	c4 a2 5d 90 1c ab    	vpgatherdd %ymm4,(%rbx,%ymm13,4),%ymm3
    3fd1:	48 8b 58 e0          	mov    -0x20(%rax),%rbx
    3fd5:	c5 e5 db 1d 80 00 00 	vpand  0x80(%rip),%ymm3,%ymm3        # 405d <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4dd>
    3fdc:	00 
    3fdd:	c4 62 65 3d ef       	vpmaxsd %ymm7,%ymm3,%ymm13
    3fe2:	c5 45 66 cb          	vpcmpgtd %ymm3,%ymm7,%ymm9
    3fe6:	c4 62 65 39 df       	vpminsd %ymm7,%ymm3,%ymm11
    3feb:	c4 c1 4d 66 e5       	vpcmpgtd %ymm13,%ymm6,%ymm4
    3ff0:	c4 62 15 3d ee       	vpmaxsd %ymm6,%ymm13,%ymm13
    3ff5:	c4 43 6d 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm2,%ymm9
    3ffb:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm4,0x1f(%rip),%ymm9,%ymm9        # 4024 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4a4>
    4002:	00 00 40 
    4005:	c4 e2 25 39 e6       	vpminsd %ymm6,%ymm11,%ymm4
    400a:	c5 35 fe 0c 24       	vpaddd (%rsp),%ymm9,%ymm9
    400f:	c5 fe 7f a4 24 80 00 	vmovdqu %ymm4,0x80(%rsp)
    4016:	00 00 
    4018:	c5 25 66 de          	vpcmpgtd %ymm6,%ymm11,%ymm11
    401c:	c4 a2 75 90 24 8a    	vpgatherdd %ymm1,(%rdx,%ymm9,4),%ymm4
    4022:	c5 65 66 cf          	vpcmpgtd %ymm7,%ymm3,%ymm9
    4026:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    402a:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    402f:	c5 e5 fe df          	vpaddd %ymm7,%ymm3,%ymm3
    4033:	c5 fe 6f 7c 24 20    	vmovdqu 0x20(%rsp),%ymm7
    4039:	c4 c1 5d db e4       	vpand  %ymm12,%ymm4,%ymm4
    403e:	c4 43 6d 4c c8 90    	vpblendvb %ymm9,%ymm8,%ymm2,%ymm9
    4044:	c4 63 35 4c 0d 1f 00 	vpblendvb %ymm11,0x1f(%rip),%ymm9,%ymm9        # 406d <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x4ed>
    404b:	00 00 b0 
    404e:	c5 7e 6f 9c 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm11
    4055:	00 00 
    4057:	c4 41 25 fa c9       	vpsubd %ymm9,%ymm11,%ymm9
    405c:	c4 22 75 90 1c 8a    	vpgatherdd %ymm1,(%rdx,%ymm9,4),%ymm11
    4062:	c5 fe 6f 8c 24 80 00 	vmovdqu 0x80(%rsp),%ymm1
    4069:	00 00 
    406b:	c4 c1 25 72 d3 08    	vpsrld $0x8,%ymm11,%ymm11
    4071:	c5 15 fe c9          	vpaddd %ymm1,%ymm13,%ymm9
    4075:	c4 41 25 db dc       	vpand  %ymm12,%ymm11,%ymm11
    407a:	c4 c1 4d fa f1       	vpsubd %ymm9,%ymm6,%ymm6
    407f:	c4 c1 7d fa c3       	vpsubd %ymm11,%ymm0,%ymm0
    4084:	c5 cd fe db          	vpaddd %ymm3,%ymm6,%ymm3
    4088:	c5 a5 fa f4          	vpsubd %ymm4,%ymm11,%ymm6
    408c:	c4 e2 7d 40 c1       	vpmulld %ymm1,%ymm0,%ymm0
    4091:	c4 e2 65 40 de       	vpmulld %ymm6,%ymm3,%ymm3
    4096:	c5 dd fa e5          	vpsubd %ymm5,%ymm4,%ymm4
    409a:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    409e:	c4 c2 5d 40 e5       	vpmulld %ymm13,%ymm4,%ymm4
    40a3:	c4 41 7d 6f ea       	vmovdqa %ymm10,%ymm13
    40a8:	c5 e5 fe d8          	vpaddd %ymm0,%ymm3,%ymm3
    40ac:	c4 e2 75 90 04 bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm0
    40b2:	c5 fe 6f 7c 24 40    	vmovdqu 0x40(%rsp),%ymm7
    40b8:	48 8b 58 d8          	mov    -0x28(%rax),%rbx
    40bc:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    40c0:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 4148 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c8>
    40c7:	00 
    40c8:	c4 c1 5d fe e6       	vpaddd %ymm14,%ymm4,%ymm4
    40cd:	c4 e2 75 90 2c bb    	vpgatherdd %ymm1,(%rbx,%ymm7,4),%ymm5
    40d3:	c5 fe 6f 7c 24 60    	vmovdqu 0x60(%rsp),%ymm7
    40d9:	48 8b 70 d0          	mov    -0x30(%rax),%rsi
    40dd:	c5 7d 7f d1          	vmovdqa %ymm10,%ymm1
    40e1:	c5 e5 fe dc          	vpaddd %ymm4,%ymm3,%ymm3
    40e5:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 416d <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5ed>
    40ec:	00 
    40ed:	c4 e2 75 90 24 be    	vpgatherdd %ymm1,(%rsi,%ymm7,4),%ymm4
    40f3:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    40f8:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 4180 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x600>
    40ff:	00 
    4100:	c5 7d 6f f3          	vmovdqa %ymm3,%ymm14
    4104:	c4 e2 5d 3d fd       	vpmaxsd %ymm5,%ymm4,%ymm7
    4109:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    410d:	c5 7d 66 cf          	vpcmpgtd %ymm7,%ymm0,%ymm9
    4111:	c4 e2 45 3d f8       	vpmaxsd %ymm0,%ymm7,%ymm7
    4116:	c4 c3 6d 4c f0 60    	vpblendvb %ymm6,%ymm8,%ymm2,%ymm6
    411c:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 4145 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x5c5>
    4123:	00 00 90 
    4126:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    412b:	c5 cd fe 34 24       	vpaddd (%rsp),%ymm6,%ymm6
    4130:	c4 62 35 39 d8       	vpminsd %ymm0,%ymm9,%ymm11
    4135:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    4139:	c4 e2 15 90 0c b2    	vpgatherdd %ymm13,(%rdx,%ymm6,4),%ymm1
    413f:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    4143:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    4147:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    414c:	c4 c1 75 db cc       	vpand  %ymm12,%ymm1,%ymm1
    4151:	c4 c3 6d 4c d0 60    	vpblendvb %ymm6,%ymm8,%ymm2,%ymm2
    4157:	c5 fe 6f b4 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm6
    415e:	00 00 
    4160:	c4 41 7d 6f c2       	vmovdqa %ymm10,%ymm8
    4165:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm2,%ymm2        # 418e <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x60e>
    416c:	00 00 90 
    416f:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    4173:	c4 e2 3d 90 34 92    	vpgatherdd %ymm8,(%rdx,%ymm2,4),%ymm6
    4179:	c4 c1 45 fe d3       	vpaddd %ymm11,%ymm7,%ymm2
    417e:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    4183:	c5 fd fa c2          	vpsubd %ymm2,%ymm0,%ymm0
    4187:	c4 c1 4d db f4       	vpand  %ymm12,%ymm6,%ymm6
    418c:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    4190:	c5 cd fa d1          	vpsubd %ymm1,%ymm6,%ymm2
    4194:	c4 c1 75 fa cf       	vpsubd %ymm15,%ymm1,%ymm1
    4199:	c4 e2 7d 40 c2       	vpmulld %ymm2,%ymm0,%ymm0
    419e:	c5 fe 6f 94 24 00 01 	vmovdqu 0x100(%rsp),%ymm2
    41a5:	00 00 
    41a7:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    41ac:	c5 ed fa d6          	vpsubd %ymm6,%ymm2,%ymm2
    41b0:	c4 c2 6d 40 d3       	vpmulld %ymm11,%ymm2,%ymm2
    41b5:	c5 f5 fe 8c 24 e0 00 	vpaddd 0xe0(%rsp),%ymm1,%ymm1
    41bc:	00 00 
    41be:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    41c2:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    41c6:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    41cb:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
    41cf:	49 39 c1             	cmp    %rax,%r9
    41d2:	74 14                	je     41e8 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x668>
    41d4:	c5 fe 7f 5c 24 40    	vmovdqu %ymm3,0x40(%rsp)
    41da:	c5 fe 7f 44 24 20    	vmovdqu %ymm0,0x20(%rsp)
    41e0:	e9 88 fb ff ff       	jmp    3d6d <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1ed>
    41e5:	0f 1f 00             	nopl   (%rax)
    41e8:	c5 fe 6f 84 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm0
    41ef:	00 00 
    41f1:	c5 7d 7f f2          	vmovdqa %ymm14,%ymm2
    41f5:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    41fa:	c5 f5 72 f1 10       	vpslld $0x10,%ymm1,%ymm1
    41ff:	49 83 c0 18          	add    $0x18,%r8
    4203:	c5 ed eb c9          	vpor   %ymm1,%ymm2,%ymm1
    4207:	c5 f5 eb c0          	vpor   %ymm0,%ymm1,%ymm0
    420b:	c4 e2 7d 00 84 24 60 	vpshufb 0x160(%rsp),%ymm0,%ymm0
    4212:	01 00 00 
    4215:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    4219:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    421f:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    4224:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    4229:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    422d:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    4233:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    4239:	4d 39 c3             	cmp    %r8,%r11
    423c:	0f 85 1e fa ff ff    	jne    3c60 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xe0>
    4242:	c5 f8 77             	vzeroupper
    4245:	c5 f8 28 b4 24 80 01 	vmovaps 0x180(%rsp),%xmm6
    424c:	00 00 
    424e:	c5 f8 28 bc 24 90 01 	vmovaps 0x190(%rsp),%xmm7
    4255:	00 00 
    4257:	c5 78 28 84 24 a0 01 	vmovaps 0x1a0(%rsp),%xmm8
    425e:	00 00 
    4260:	c5 78 28 8c 24 b0 01 	vmovaps 0x1b0(%rsp),%xmm9
    4267:	00 00 
    4269:	c5 78 28 94 24 c0 01 	vmovaps 0x1c0(%rsp),%xmm10
    4270:	00 00 
    4272:	c5 78 28 9c 24 d0 01 	vmovaps 0x1d0(%rsp),%xmm11
    4279:	00 00 
    427b:	c5 78 28 a4 24 e0 01 	vmovaps 0x1e0(%rsp),%xmm12
    4282:	00 00 
    4284:	c5 78 28 ac 24 f0 01 	vmovaps 0x1f0(%rsp),%xmm13
    428b:	00 00 
    428d:	c5 78 28 b4 24 00 02 	vmovaps 0x200(%rsp),%xmm14
    4294:	00 00 
    4296:	c5 78 28 bc 24 10 02 	vmovaps 0x210(%rsp),%xmm15
    429d:	00 00 
    429f:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
    42a6:	5b                   	pop    %rbx
    42a7:	5e                   	pop    %rsi
    42a8:	c3                   	ret
    42a9:	80 79 58 00          	cmpb   $0x0,0x58(%rcx)
    42ad:	0f 85 3d f9 ff ff    	jne    3bf0 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    42b3:	80 b9 b8 00 00 00 00 	cmpb   $0x0,0xb8(%rcx)
    42ba:	0f 84 30 f9 ff ff    	je     3bf0 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    42c0:	80 b9 18 01 00 00 00 	cmpb   $0x0,0x118(%rcx)
    42c7:	0f 84 23 f9 ff ff    	je     3bf0 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    42cd:	80 b9 78 01 00 00 00 	cmpb   $0x0,0x178(%rcx)
    42d4:	0f 84 16 f9 ff ff    	je     3bf0 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x70>
    42da:	4d 85 c9             	test   %r9,%r9
    42dd:	0f 84 62 ff ff ff    	je     4245 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c5>
    42e3:	c5 fd 6f 0d 00 00 00 	vmovdqa 0x0(%rip),%ymm1        # 42eb <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x76b>
    42ea:	00 
    42eb:	49 8d 41 ff          	lea    -0x1(%r9),%rax
    42ef:	c4 41 25 76 db       	vpcmpeqd %ymm11,%ymm11,%ymm11
    42f4:	48 c1 e8 03          	shr    $0x3,%rax
    42f8:	c4 c1 0d 72 d3 18    	vpsrld $0x18,%ymm11,%ymm14
    42fe:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    4302:	c5 fe 7f 8c 24 40 01 	vmovdqu %ymm1,0x140(%rsp)
    4309:	00 00 
    430b:	c5 fd 6f 0d 40 00 00 	vmovdqa 0x40(%rip),%ymm1        # 4353 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7d3>
    4312:	00 
    4313:	4d 8d 54 c0 18       	lea    0x18(%r8,%rax,8),%r10
    4318:	b8 00 80 00 00       	mov    $0x8000,%eax
    431d:	c5 fe 7f 8c 24 60 01 	vmovdqu %ymm1,0x160(%rsp)
    4324:	00 00 
    4326:	c5 f9 6e c8          	vmovd  %eax,%xmm1
    432a:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    432f:	c5 fe 7f 0c 24       	vmovdqu %ymm1,(%rsp)
    4334:	c4 c1 7a 6f 00       	vmovdqu (%r8),%xmm0
    4339:	c4 c1 7a 7e 48 10    	vmovq  0x10(%r8),%xmm1
    433f:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    4343:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    4348:	48 8b 01             	mov    (%rcx),%rax
    434b:	44 8b 49 54          	mov    0x54(%rcx),%r9d
    434f:	49 83 c0 18          	add    $0x18,%r8
    4353:	c4 e3 71 0f c8 0c    	vpalignr $0xc,%xmm0,%xmm1,%xmm1
    4359:	8b 51 50             	mov    0x50(%rcx),%edx
    435c:	c4 e3 7d 38 c1 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
    4362:	c4 c1 79 6e f9       	vmovd  %r9d,%xmm7
    4367:	c4 e2 7d 00 84 24 40 	vpshufb 0x140(%rsp),%ymm0,%ymm0
    436e:	01 00 00 
    4371:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    4375:	c4 e2 7d 58 ff       	vpbroadcastd %xmm7,%ymm7
    437a:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    437f:	c5 b5 72 d0 08       	vpsrld $0x8,%ymm0,%ymm9
    4384:	c4 e2 7d 58 c9       	vpbroadcastd %xmm1,%ymm1
    4389:	c5 fe 7f 74 24 20    	vmovdqu %ymm6,0x20(%rsp)
    438f:	c5 9d 72 d0 10       	vpsrld $0x10,%ymm0,%ymm12
    4394:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    4399:	c4 e2 6d 90 04 b0    	vpgatherdd %ymm2,(%rax,%ymm6,4),%ymm0
    439f:	c4 c1 35 db f6       	vpand  %ymm14,%ymm9,%ymm6
    43a4:	48 8b 41 08          	mov    0x8(%rcx),%rax
    43a8:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    43ac:	c5 fe 7f 74 24 40    	vmovdqu %ymm6,0x40(%rsp)
    43b2:	c5 fd 6f e6          	vmovdqa %ymm6,%ymm4
    43b6:	c5 e5 72 d0 11       	vpsrld $0x11,%ymm0,%ymm3
    43bb:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 4443 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8c3>
    43c2:	00 
    43c3:	c4 e2 6d 90 34 a0    	vpgatherdd %ymm2,(%rax,%ymm4,4),%ymm6
    43c9:	48 8b 41 10          	mov    0x10(%rcx),%rax
    43cd:	c4 e2 65 40 d9       	vpmulld %ymm1,%ymm3,%ymm3
    43d2:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    43d6:	c4 a2 6d 90 24 a0    	vpgatherdd %ymm2,(%rax,%ymm12,4),%ymm4
    43dc:	c5 ed 72 d6 11       	vpsrld $0x11,%ymm6,%ymm2
    43e1:	48 8b 41 48          	mov    0x48(%rcx),%rax
    43e5:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 446d <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8ed>
    43ec:	00 
    43ed:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    43f2:	c5 d5 72 d4 11       	vpsrld $0x11,%ymm4,%ymm5
    43f7:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 447f <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x8ff>
    43fe:	00 
    43ff:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4403:	c5 f9 6e da          	vmovd  %edx,%xmm3
    4407:	c5 ed fe d5          	vpaddd %ymm5,%ymm2,%ymm2
    440b:	c4 e2 7d 58 db       	vpbroadcastd %xmm3,%ymm3
    4410:	c5 7d 7f dd          	vmovdqa %ymm11,%ymm5
    4414:	c5 e5 fe da          	vpaddd %ymm2,%ymm3,%ymm3
    4418:	c4 62 55 90 2c 90    	vpgatherdd %ymm5,(%rax,%ymm2,4),%ymm13
    441e:	c4 e2 3d 90 2c 98    	vpgatherdd %ymm8,(%rax,%ymm3,4),%ymm5
    4424:	c4 62 7d 3d c6       	vpmaxsd %ymm6,%ymm0,%ymm8
    4429:	c5 fe 7f ac 24 80 00 	vmovdqu %ymm5,0x80(%rsp)
    4430:	00 00 
    4432:	c5 cd 66 e8          	vpcmpgtd %ymm0,%ymm6,%ymm5
    4436:	c4 41 5d 66 d0       	vpcmpgtd %ymm8,%ymm4,%ymm10
    443b:	c4 62 3d 3d c4       	vpmaxsd %ymm4,%ymm8,%ymm8
    4440:	c5 7e 7f 84 24 a0 00 	vmovdqu %ymm8,0xa0(%rsp)
    4447:	00 00 
    4449:	c4 62 7d 39 c6       	vpminsd %ymm6,%ymm0,%ymm8
    444e:	c4 62 3d 39 cc       	vpminsd %ymm4,%ymm8,%ymm9
    4453:	c5 3d 66 c4          	vpcmpgtd %ymm4,%ymm8,%ymm8
    4457:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    445d:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm5,%ymm5        # 4486 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x906>
    4464:	00 00 a0 
    4467:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    446c:	c5 ed fe ed          	vpaddd %ymm5,%ymm2,%ymm5
    4470:	c4 62 2d 90 3c a8    	vpgatherdd %ymm10,(%rax,%ymm5,4),%ymm15
    4476:	c5 fd 66 ee          	vpcmpgtd %ymm6,%ymm0,%ymm5
    447a:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    447e:	c4 e3 75 4c ef 50    	vpblendvb %ymm5,%ymm7,%ymm1,%ymm5
    4484:	c4 e3 55 4c 2d 1f 00 	vpblendvb %ymm8,0x1f(%rip),%ymm5,%ymm5        # 44ad <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x92d>
    448b:	00 00 80 
    448e:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    4493:	c5 e5 fa ed          	vpsubd %ymm5,%ymm3,%ymm5
    4497:	c4 62 3d 90 14 a8    	vpgatherdd %ymm8,(%rax,%ymm5,4),%ymm10
    449d:	c5 7e 7f 6c 24 60    	vmovdqu %ymm13,0x60(%rsp)
    44a3:	c4 c1 05 db ee       	vpand  %ymm14,%ymm15,%ymm5
    44a8:	c5 35 fe bc 24 a0 00 	vpaddd 0xa0(%rsp),%ymm9,%ymm15
    44af:	00 00 
    44b1:	c4 41 2d db d6       	vpand  %ymm14,%ymm10,%ymm10
    44b6:	c5 0d db 6c 24 60    	vpand  0x60(%rsp),%ymm14,%ymm13
    44bc:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    44c0:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    44c5:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    44cb:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    44cf:	c5 ad fa e5          	vpsubd %ymm5,%ymm10,%ymm4
    44d3:	c4 c1 3d 72 f5 10    	vpslld $0x10,%ymm13,%ymm8
    44d9:	c4 e2 7d 40 e4       	vpmulld %ymm4,%ymm0,%ymm4
    44de:	c5 bd fe 04 24       	vpaddd (%rsp),%ymm8,%ymm0
    44e3:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    44e8:	c4 e2 55 40 ac 24 a0 	vpmulld 0xa0(%rsp),%ymm5,%ymm5
    44ef:	00 00 00 
    44f2:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    44f7:	c5 dd fe c0          	vpaddd %ymm0,%ymm4,%ymm0
    44fb:	c5 8d db a4 24 80 00 	vpand  0x80(%rsp),%ymm14,%ymm4
    4502:	00 00 
    4504:	c4 c1 5d fa e2       	vpsubd %ymm10,%ymm4,%ymm4
    4509:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    450e:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    4513:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    4517:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    451b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4520:	c5 fe 7f 84 24 c0 00 	vmovdqu %ymm0,0xc0(%rsp)
    4527:	00 00 
    4529:	c4 a2 3d 90 2c a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm5
    452f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    4533:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 45bb <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa3b>
    453a:	00 
    453b:	c4 62 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm8
    4541:	48 8b 51 18          	mov    0x18(%rcx),%rdx
    4545:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    454b:	c4 41 7d 6f cb       	vmovdqa %ymm11,%ymm9
    4550:	c5 3d db 05 80 00 00 	vpand  0x80(%rip),%ymm8,%ymm8        # 45d8 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa58>
    4557:	00 
    4558:	c4 e2 35 90 04 b2    	vpgatherdd %ymm9,(%rdx,%ymm6,4),%ymm0
    455e:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 45e6 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa66>
    4565:	00 
    4566:	c4 c2 7d 3d f0       	vpmaxsd %ymm8,%ymm0,%ymm6
    456b:	c5 bd 66 e0          	vpcmpgtd %ymm0,%ymm8,%ymm4
    456f:	c5 55 66 d6          	vpcmpgtd %ymm6,%ymm5,%ymm10
    4573:	c4 62 4d 3d cd       	vpmaxsd %ymm5,%ymm6,%ymm9
    4578:	c4 c2 7d 39 f0       	vpminsd %ymm8,%ymm0,%ymm6
    457d:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    4583:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm10,0x1f(%rip),%ymm4,%ymm4        # 45ac <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa2c>
    458a:	00 00 a0 
    458d:	c4 62 4d 39 d5       	vpminsd %ymm5,%ymm6,%ymm10
    4592:	c5 7e 7f 94 24 a0 00 	vmovdqu %ymm10,0xa0(%rsp)
    4599:	00 00 
    459b:	c5 ed fe e4          	vpaddd %ymm4,%ymm2,%ymm4
    459f:	c5 cd 66 f5          	vpcmpgtd %ymm5,%ymm6,%ymm6
    45a3:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    45a8:	c4 62 2d 90 2c a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm13
    45ae:	c4 c1 7d 66 e0       	vpcmpgtd %ymm8,%ymm0,%ymm4
    45b3:	c4 41 7d 6f d3       	vmovdqa %ymm11,%ymm10
    45b8:	c4 c1 7d fe c0       	vpaddd %ymm8,%ymm0,%ymm0
    45bd:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    45c2:	c4 e3 75 4c e7 40    	vpblendvb %ymm4,%ymm7,%ymm1,%ymm4
    45c8:	c4 e3 5d 4c 25 1f 00 	vpblendvb %ymm6,0x1f(%rip),%ymm4,%ymm4        # 45f1 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xa71>
    45cf:	00 00 60 
    45d2:	c5 e5 fa e4          	vpsubd %ymm4,%ymm3,%ymm4
    45d6:	c4 e2 2d 90 34 a0    	vpgatherdd %ymm10,(%rax,%ymm4,4),%ymm6
    45dc:	c5 fe 6f 64 24 60    	vmovdqu 0x60(%rsp),%ymm4
    45e2:	c5 7e 6f 94 24 80 00 	vmovdqu 0x80(%rsp),%ymm10
    45e9:	00 00 
    45eb:	c5 cd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm6
    45f0:	c5 dd 72 d4 08       	vpsrld $0x8,%ymm4,%ymm4
    45f5:	c4 c1 2d 72 d2 08    	vpsrld $0x8,%ymm10,%ymm10
    45fb:	c4 41 5d db fe       	vpand  %ymm14,%ymm4,%ymm15
    4600:	c4 c1 5d 72 d5 08    	vpsrld $0x8,%ymm13,%ymm4
    4606:	c5 7e 6f ac 24 a0 00 	vmovdqu 0xa0(%rsp),%ymm13
    460d:	00 00 
    460f:	c5 7e 7f 94 24 e0 00 	vmovdqu %ymm10,0xe0(%rsp)
    4616:	00 00 
    4618:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    461d:	c4 41 4d db d6       	vpand  %ymm14,%ymm6,%ymm10
    4622:	c4 41 15 fe e9       	vpaddd %ymm9,%ymm13,%ymm13
    4627:	c4 c1 4d 72 f7 10    	vpslld $0x10,%ymm15,%ymm6
    462d:	c4 c1 55 fa ed       	vpsubd %ymm13,%ymm5,%ymm5
    4632:	c5 d5 fe c0          	vpaddd %ymm0,%ymm5,%ymm0
    4636:	c5 ad fa ec          	vpsubd %ymm4,%ymm10,%ymm5
    463a:	c4 e2 7d 40 c5       	vpmulld %ymm5,%ymm0,%ymm0
    463f:	c4 c1 5d fa e7       	vpsubd %ymm15,%ymm4,%ymm4
    4644:	c5 cd fe 2c 24       	vpaddd (%rsp),%ymm6,%ymm5
    4649:	c4 c2 5d 40 e1       	vpmulld %ymm9,%ymm4,%ymm4
    464e:	c5 fd fe ed          	vpaddd %ymm5,%ymm0,%ymm5
    4652:	c5 8d db 84 24 e0 00 	vpand  0xe0(%rsp),%ymm14,%ymm0
    4659:	00 00 
    465b:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    465f:	c5 fe 6f 74 24 40    	vmovdqu 0x40(%rsp),%ymm6
    4665:	c4 c1 7d fa c2       	vpsubd %ymm10,%ymm0,%ymm0
    466a:	c4 e2 7d 40 84 24 a0 	vpmulld 0xa0(%rsp),%ymm0,%ymm0
    4671:	00 00 00 
    4674:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    4678:	c5 d5 fe e8          	vpaddd %ymm0,%ymm5,%ymm5
    467c:	c4 a2 3d 90 04 a2    	vpgatherdd %ymm8,(%rdx,%ymm12,4),%ymm0
    4682:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    4686:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    468b:	c5 95 72 d5 10       	vpsrld $0x10,%ymm5,%ymm13
    4690:	c5 fd db 05 80 00 00 	vpand  0x80(%rip),%ymm0,%ymm0        # 4718 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb98>
    4697:	00 
    4698:	c4 41 7d 6f e3       	vmovdqa %ymm11,%ymm12
    469d:	c4 e2 3d 90 2c b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm5
    46a3:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    46a7:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    46ad:	c4 41 7d 6f c3       	vmovdqa %ymm11,%ymm8
    46b2:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 473a <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbba>
    46b9:	00 
    46ba:	c4 e2 3d 90 24 b2    	vpgatherdd %ymm8,(%rdx,%ymm6,4),%ymm4
    46c0:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 4748 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbc8>
    46c7:	00 
    46c8:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    46cd:	c5 d5 66 f4          	vpcmpgtd %ymm4,%ymm5,%ymm6
    46d1:	c4 41 7d 66 c8       	vpcmpgtd %ymm8,%ymm0,%ymm9
    46d6:	c4 62 3d 3d c0       	vpmaxsd %ymm0,%ymm8,%ymm8
    46db:	c4 e3 75 4c f7 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm6
    46e1:	c4 e3 4d 4c 35 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm6,%ymm6        # 470a <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xb8a>
    46e8:	00 00 90 
    46eb:	c4 62 5d 39 cd       	vpminsd %ymm5,%ymm4,%ymm9
    46f0:	c5 ed fe f6          	vpaddd %ymm6,%ymm2,%ymm6
    46f4:	c4 62 35 39 d0       	vpminsd %ymm0,%ymm9,%ymm10
    46f9:	c5 35 66 c8          	vpcmpgtd %ymm0,%ymm9,%ymm9
    46fd:	c4 e2 1d 90 14 b0    	vpgatherdd %ymm12,(%rax,%ymm6,4),%ymm2
    4703:	c5 dd 66 f5          	vpcmpgtd %ymm5,%ymm4,%ymm6
    4707:	c5 dd fe e5          	vpaddd %ymm5,%ymm4,%ymm4
    470b:	c4 e3 75 4c cf 60    	vpblendvb %ymm6,%ymm7,%ymm1,%ymm1
    4711:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    4715:	c4 e3 75 4c 0d 1f 00 	vpblendvb %ymm9,0x1f(%rip),%ymm1,%ymm1        # 473e <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xbbe>
    471c:	00 00 90 
    471f:	c4 41 3d fe ca       	vpaddd %ymm10,%ymm8,%ymm9
    4724:	c5 e5 fa d9          	vpsubd %ymm1,%ymm3,%ymm3
    4728:	c5 fe 6f 4c 24 60    	vmovdqu 0x60(%rsp),%ymm1
    472e:	c4 c1 7d fa c1       	vpsubd %ymm9,%ymm0,%ymm0
    4733:	c4 e2 45 90 34 98    	vpgatherdd %ymm7,(%rax,%ymm3,4),%ymm6
    4739:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    473d:	48 8b 41 60          	mov    0x60(%rcx),%rax
    4741:	c5 e5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm3
    4746:	c5 c5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm7
    474b:	c5 fe 6f b4 24 80 00 	vmovdqu 0x80(%rsp),%ymm6
    4752:	00 00 
    4754:	c5 f5 72 d2 10       	vpsrld $0x10,%ymm2,%ymm1
    4759:	c4 c1 45 db fe       	vpand  %ymm14,%ymm7,%ymm7
    475e:	c4 c1 65 db de       	vpand  %ymm14,%ymm3,%ymm3
    4763:	c5 ed 72 f3 10       	vpslld $0x10,%ymm3,%ymm2
    4768:	c5 cd 72 d6 10       	vpsrld $0x10,%ymm6,%ymm6
    476d:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    4772:	c5 c5 fa e1          	vpsubd %ymm1,%ymm7,%ymm4
    4776:	c5 ed fe 14 24       	vpaddd (%rsp),%ymm2,%ymm2
    477b:	c4 e2 7d 40 c4       	vpmulld %ymm4,%ymm0,%ymm0
    4780:	c5 f5 fa cb          	vpsubd %ymm3,%ymm1,%ymm1
    4784:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    4788:	c4 c2 75 40 c8       	vpmulld %ymm8,%ymm1,%ymm1
    478d:	c5 fd fe c2          	vpaddd %ymm2,%ymm0,%ymm0
    4791:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    4796:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    479a:	c5 ed fa d7          	vpsubd %ymm7,%ymm2,%ymm2
    479e:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    47a2:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    47a7:	c5 ed fe c9          	vpaddd %ymm1,%ymm2,%ymm1
    47ab:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    47af:	c5 fe 6f 8c 24 c0 00 	vmovdqu 0xc0(%rsp),%ymm1
    47b6:	00 00 
    47b8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    47bd:	c4 e2 4d 90 24 88    	vpgatherdd %ymm6,(%rax,%ymm1,4),%ymm4
    47c3:	48 8b 41 68          	mov    0x68(%rcx),%rax
    47c7:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    47cb:	c4 a2 75 90 2c a8    	vpgatherdd %ymm1,(%rax,%ymm13,4),%ymm5
    47d1:	48 8b 41 70          	mov    0x70(%rcx),%rax
    47d5:	44 8b 89 b4 00 00 00 	mov    0xb4(%rcx),%r9d
    47dc:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    47e0:	8b 91 b0 00 00 00    	mov    0xb0(%rcx),%edx
    47e6:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    47eb:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4873 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xcf3>
    47f2:	00 
    47f3:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    47f8:	c4 e2 75 90 34 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm6
    47fe:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
    4805:	c5 79 6e ca          	vmovd  %edx,%xmm9
    4809:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    480e:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    4813:	44 8b 89 14 01 00 00 	mov    0x114(%rcx),%r9d
    481a:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    481f:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4824:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 48ac <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd2c>
    482b:	00 
    482c:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    4831:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    4836:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    483b:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 48c3 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd43>
    4842:	00 
    4843:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    4848:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    484d:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    4851:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    4856:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    485a:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    485e:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4862:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    4866:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    486b:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    4871:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    4875:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    487b:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    4881:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    4885:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    488a:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    488e:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4893:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    4898:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    489e:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 48c7 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd47>
    48a5:	00 00 70 
    48a8:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    48ad:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    48b1:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    48b5:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    48bb:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    48c0:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    48c5:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    48cb:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    48d1:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    48d5:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    48da:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 4903 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xd83>
    48e1:	00 00 c0 
    48e4:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    48e9:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    48ee:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    48f2:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    48f7:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    48fc:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    4902:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    4907:	48 8b 81 c0 00 00 00 	mov    0xc0(%rcx),%rax
    490e:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    4913:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    4918:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    491c:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    4920:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    4925:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    492a:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    492f:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    4934:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    4939:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    493e:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    4942:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    4947:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    494b:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    4950:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    4955:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    495a:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    4960:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    4965:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    496a:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    496f:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    4974:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    4979:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    497e:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    4982:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    4987:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    498c:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    4991:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4996:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    499b:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    49a0:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    49a5:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    49aa:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    49af:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    49b4:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    49b8:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    49bd:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    49c2:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    49c7:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    49cc:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    49d1:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    49d6:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    49da:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    49de:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    49e2:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    49e7:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    49ec:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    49f1:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    49f6:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    49fa:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    49fe:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    4a02:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    4a06:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4a0a:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    4a0e:	c4 e2 75 90 24 a8    	vpgatherdd %ymm1,(%rax,%ymm5,4),%ymm4
    4a14:	48 8b 81 c8 00 00 00 	mov    0xc8(%rcx),%rax
    4a1b:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4a20:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    4a24:	c4 e2 75 90 2c 90    	vpgatherdd %ymm1,(%rax,%ymm2,4),%ymm5
    4a2a:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
    4a31:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    4a35:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    4a3a:	c4 e2 75 90 34 80    	vpgatherdd %ymm1,(%rax,%ymm0,4),%ymm6
    4a40:	8b 91 10 01 00 00    	mov    0x110(%rcx),%edx
    4a46:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    4a4b:	48 8b 81 08 01 00 00 	mov    0x108(%rcx),%rax
    4a52:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    4a57:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    4a5c:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4ae4 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf64>
    4a63:	00 
    4a64:	c5 79 6e ca          	vmovd  %edx,%xmm9
    4a68:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    4a6d:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 4af5 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf75>
    4a74:	00 
    4a75:	44 8b 89 74 01 00 00 	mov    0x174(%rcx),%r9d
    4a7c:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4a81:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4b09 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf89>
    4a88:	00 
    4a89:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    4a8e:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    4a93:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    4a98:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    4a9d:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    4aa1:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    4aa5:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    4aa9:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4aad:	8b 91 70 01 00 00    	mov    0x170(%rcx),%edx
    4ab3:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    4ab7:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4abc:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    4ac2:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    4ac6:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    4acc:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    4ad2:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    4ad6:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4adb:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    4adf:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4ae4:	c4 c1 7d db ee       	vpand  %ymm14,%ymm0,%ymm5
    4ae9:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    4aef:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 4b18 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xf98>
    4af6:	00 00 70 
    4af9:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4afe:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    4b02:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4b06:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    4b0c:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    4b11:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    4b16:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    4b1c:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    4b22:	c5 7d 7f dc          	vmovdqa %ymm11,%ymm4
    4b26:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    4b2b:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 4b54 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0xfd4>
    4b32:	00 00 c0 
    4b35:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    4b3a:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    4b3f:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    4b43:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4b48:	c4 41 15 db ee       	vpand  %ymm14,%ymm13,%ymm13
    4b4d:	c4 e2 5d 90 34 90    	vpgatherdd %ymm4,(%rax,%ymm2,4),%ymm6
    4b53:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    4b58:	48 8b 81 20 01 00 00 	mov    0x120(%rcx),%rax
    4b5f:	c4 c1 4d db d6       	vpand  %ymm14,%ymm6,%ymm2
    4b64:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    4b69:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    4b6d:	c5 d5 fa ea          	vpsubd %ymm2,%ymm5,%ymm5
    4b71:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    4b76:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    4b7b:	c4 c2 55 40 ea       	vpmulld %ymm10,%ymm5,%ymm5
    4b80:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    4b85:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    4b8a:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    4b8f:	c5 d5 fe ec          	vpaddd %ymm4,%ymm5,%ymm5
    4b93:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    4b98:	c5 d5 fe ea          	vpaddd %ymm2,%ymm5,%ymm5
    4b9c:	c5 dd 72 d6 08       	vpsrld $0x8,%ymm6,%ymm4
    4ba1:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    4ba6:	c5 ed 72 d0 08       	vpsrld $0x8,%ymm0,%ymm2
    4bab:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    4bb1:	c4 c1 5d db e6       	vpand  %ymm14,%ymm4,%ymm4
    4bb6:	c4 c1 6d db d6       	vpand  %ymm14,%ymm2,%ymm2
    4bbb:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    4bc0:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    4bc5:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    4bca:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4bcf:	c5 ed fa d4          	vpsubd %ymm4,%ymm2,%ymm2
    4bd3:	c4 c2 6d 40 d2       	vpmulld %ymm10,%ymm2,%ymm2
    4bd8:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4bdd:	c4 c1 5d fa e5       	vpsubd %ymm13,%ymm4,%ymm4
    4be2:	c4 e2 5d 40 e7       	vpmulld %ymm7,%ymm4,%ymm4
    4be7:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    4bec:	c4 41 79 6e e9       	vmovd  %r9d,%xmm13
    4bf1:	c5 d5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm5
    4bf6:	c4 42 7d 58 ed       	vpbroadcastd %xmm13,%ymm13
    4bfb:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    4c00:	c5 79 6e ca          	vmovd  %edx,%xmm9
    4c04:	41 8d 54 11 01       	lea    0x1(%r9,%rdx,1),%edx
    4c09:	c4 c1 5d fe e4       	vpaddd %ymm12,%ymm4,%ymm4
    4c0e:	c4 42 7d 58 c9       	vpbroadcastd %xmm9,%ymm9
    4c13:	c5 ed fe d4          	vpaddd %ymm4,%ymm2,%ymm2
    4c17:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    4c1c:	c5 f5 72 d6 10       	vpsrld $0x10,%ymm6,%ymm1
    4c21:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4c26:	c4 c1 65 db f6       	vpand  %ymm14,%ymm3,%ymm6
    4c2b:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    4c30:	c5 e5 72 f4 10       	vpslld $0x10,%ymm4,%ymm3
    4c35:	c5 cd fa e4          	vpsubd %ymm4,%ymm6,%ymm4
    4c39:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    4c3d:	c5 f5 fa ce          	vpsubd %ymm6,%ymm1,%ymm1
    4c41:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    4c46:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    4c4b:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4c50:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    4c55:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    4c59:	c5 7d 7f df          	vmovdqa %ymm11,%ymm7
    4c5d:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    4c61:	c5 fd fe c4          	vpaddd %ymm4,%ymm0,%ymm0
    4c65:	c5 7d 7f db          	vmovdqa %ymm11,%ymm3
    4c69:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4c6d:	c5 7d 7f d9          	vmovdqa %ymm11,%ymm1
    4c71:	c4 e2 75 90 24 a8    	vpgatherdd %ymm1,(%rax,%ymm5,4),%ymm4
    4c77:	48 8b 81 28 01 00 00 	mov    0x128(%rcx),%rax
    4c7e:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4c83:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    4c89:	48 8b 81 30 01 00 00 	mov    0x130(%rcx),%rax
    4c90:	c5 7d 7f da          	vmovdqa %ymm11,%ymm2
    4c94:	c4 e2 6d 90 34 80    	vpgatherdd %ymm2,(%rax,%ymm0,4),%ymm6
    4c9a:	c5 ed 72 d5 11       	vpsrld $0x11,%ymm5,%ymm2
    4c9f:	c5 d5 db 2d 80 00 00 	vpand  0x80(%rip),%ymm5,%ymm5        # 4d27 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11a7>
    4ca6:	00 
    4ca7:	c5 fd 72 d4 11       	vpsrld $0x11,%ymm4,%ymm0
    4cac:	c4 c2 6d 40 d5       	vpmulld %ymm13,%ymm2,%ymm2
    4cb1:	c5 dd db 25 80 00 00 	vpand  0x80(%rip),%ymm4,%ymm4        # 4d39 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11b9>
    4cb8:	00 
    4cb9:	c4 c2 7d 40 c1       	vpmulld %ymm9,%ymm0,%ymm0
    4cbe:	c5 f5 72 d6 11       	vpsrld $0x11,%ymm6,%ymm1
    4cc3:	c5 cd db 35 80 00 00 	vpand  0x80(%rip),%ymm6,%ymm6        # 4d4b <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11cb>
    4cca:	00 
    4ccb:	48 8b 81 68 01 00 00 	mov    0x168(%rcx),%rax
    4cd2:	c4 62 5d 3d c5       	vpmaxsd %ymm5,%ymm4,%ymm8
    4cd7:	c4 62 5d 39 e5       	vpminsd %ymm5,%ymm4,%ymm12
    4cdc:	c4 62 1d 39 d6       	vpminsd %ymm6,%ymm12,%ymm10
    4ce1:	c5 5d fe fd          	vpaddd %ymm5,%ymm4,%ymm15
    4ce5:	c5 1d 66 e6          	vpcmpgtd %ymm6,%ymm12,%ymm12
    4ce9:	c5 ed fe d0          	vpaddd %ymm0,%ymm2,%ymm2
    4ced:	c5 f9 6e c2          	vmovd  %edx,%xmm0
    4cf1:	c5 ed fe d1          	vpaddd %ymm1,%ymm2,%ymm2
    4cf5:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
    4cfa:	c4 e2 45 90 0c 90    	vpgatherdd %ymm7,(%rax,%ymm2,4),%ymm1
    4d00:	c5 fd fe fa          	vpaddd %ymm2,%ymm0,%ymm7
    4d04:	c5 fe 7f 7c 24 20    	vmovdqu %ymm7,0x20(%rsp)
    4d0a:	c4 e2 65 90 04 b8    	vpgatherdd %ymm3,(%rax,%ymm7,4),%ymm0
    4d10:	c5 d5 66 dc          	vpcmpgtd %ymm4,%ymm5,%ymm3
    4d14:	c4 c1 4d 66 f8       	vpcmpgtd %ymm8,%ymm6,%ymm7
    4d19:	c5 dd 66 e5          	vpcmpgtd %ymm5,%ymm4,%ymm4
    4d1d:	c4 62 3d 3d c6       	vpmaxsd %ymm6,%ymm8,%ymm8
    4d22:	c4 c3 35 4c dd 30    	vpblendvb %ymm3,%ymm13,%ymm9,%ymm3
    4d28:	c4 e3 65 4c 1d 1f 00 	vpblendvb %ymm7,0x1f(%rip),%ymm3,%ymm3        # 4d51 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x11d1>
    4d2f:	00 00 70 
    4d32:	c4 c1 3d fe fa       	vpaddd %ymm10,%ymm8,%ymm7
    4d37:	c5 cd fa ff          	vpsubd %ymm7,%ymm6,%ymm7
    4d3b:	c5 ed fe d3          	vpaddd %ymm3,%ymm2,%ymm2
    4d3f:	c5 fe 6f 74 24 20    	vmovdqu 0x20(%rsp),%ymm6
    4d45:	c4 c1 45 fe ff       	vpaddd %ymm15,%ymm7,%ymm7
    4d4a:	c4 41 7d 6f fb       	vmovdqa %ymm11,%ymm15
    4d4f:	c4 e2 05 90 1c 90    	vpgatherdd %ymm15,(%rax,%ymm2,4),%ymm3
    4d55:	c4 c3 35 4c d5 40    	vpblendvb %ymm4,%ymm13,%ymm9,%ymm2
    4d5b:	c4 c1 75 db e6       	vpand  %ymm14,%ymm1,%ymm4
    4d60:	c5 7e 6f 3c 24       	vmovdqu (%rsp),%ymm15
    4d65:	c5 b5 72 f4 10       	vpslld $0x10,%ymm4,%ymm9
    4d6a:	c5 95 72 d3 08       	vpsrld $0x8,%ymm3,%ymm13
    4d6f:	c4 e3 6d 4c 15 1f 00 	vpblendvb %ymm12,0x1f(%rip),%ymm2,%ymm2        # 4d98 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x1218>
    4d76:	00 00 c0 
    4d79:	c5 cd fa d2          	vpsubd %ymm2,%ymm6,%ymm2
    4d7d:	c5 7d 7f de          	vmovdqa %ymm11,%ymm6
    4d81:	c4 41 65 db e6       	vpand  %ymm14,%ymm3,%ymm12
    4d86:	c4 e2 4d 90 2c 90    	vpgatherdd %ymm6,(%rax,%ymm2,4),%ymm5
    4d8c:	c4 c1 7d db f6       	vpand  %ymm14,%ymm0,%ymm6
    4d91:	c5 9d fa e4          	vpsubd %ymm4,%ymm12,%ymm4
    4d95:	c4 c1 55 db d6       	vpand  %ymm14,%ymm5,%ymm2
    4d9a:	c4 c2 5d 40 e0       	vpmulld %ymm8,%ymm4,%ymm4
    4d9f:	c4 41 35 fe cf       	vpaddd %ymm15,%ymm9,%ymm9
    4da4:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    4da8:	c4 c1 6d fa d4       	vpsubd %ymm12,%ymm2,%ymm2
    4dad:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
    4db2:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    4db7:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    4dbc:	c5 e5 72 d3 10       	vpsrld $0x10,%ymm3,%ymm3
    4dc1:	c4 c1 6d fe d1       	vpaddd %ymm9,%ymm2,%ymm2
    4dc6:	c5 cd fe e4          	vpaddd %ymm4,%ymm6,%ymm4
    4dca:	c5 b5 72 d1 08       	vpsrld $0x8,%ymm1,%ymm9
    4dcf:	c5 dd fe e2          	vpaddd %ymm2,%ymm4,%ymm4
    4dd3:	c5 cd 72 d0 08       	vpsrld $0x8,%ymm0,%ymm6
    4dd8:	c4 41 35 db ce       	vpand  %ymm14,%ymm9,%ymm9
    4ddd:	c5 ed 72 d5 08       	vpsrld $0x8,%ymm5,%ymm2
    4de2:	c4 c1 1d 72 f1 10    	vpslld $0x10,%ymm9,%ymm12
    4de8:	c5 8d db f6          	vpand  %ymm6,%ymm14,%ymm6
    4dec:	c5 8d db d2          	vpand  %ymm2,%ymm14,%ymm2
    4df0:	c4 41 15 fa c9       	vpsubd %ymm9,%ymm13,%ymm9
    4df5:	c4 41 1d fe e7       	vpaddd %ymm15,%ymm12,%ymm12
    4dfa:	c4 42 35 40 c8       	vpmulld %ymm8,%ymm9,%ymm9
    4dff:	c5 f5 72 d1 10       	vpsrld $0x10,%ymm1,%ymm1
    4e04:	c5 cd fa f2          	vpsubd %ymm2,%ymm6,%ymm6
    4e08:	c4 c2 4d 40 f2       	vpmulld %ymm10,%ymm6,%ymm6
    4e0d:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4e12:	c4 c1 6d fa d5       	vpsubd %ymm13,%ymm2,%ymm2
    4e17:	c4 e2 6d 40 d7       	vpmulld %ymm7,%ymm2,%ymm2
    4e1c:	c5 dd 72 d4 10       	vpsrld $0x10,%ymm4,%ymm4
    4e21:	c4 c1 7d db c6       	vpand  %ymm14,%ymm0,%ymm0
    4e26:	c4 c1 4d fe f1       	vpaddd %ymm9,%ymm6,%ymm6
    4e2b:	c4 c1 6d fe d4       	vpaddd %ymm12,%ymm2,%ymm2
    4e30:	c5 cd fe d2          	vpaddd %ymm2,%ymm6,%ymm2
    4e34:	c4 c1 75 db f6       	vpand  %ymm14,%ymm1,%ymm6
    4e39:	c5 f5 72 d5 10       	vpsrld $0x10,%ymm5,%ymm1
    4e3e:	c5 ed 72 d2 10       	vpsrld $0x10,%ymm2,%ymm2
    4e43:	c4 c1 65 db ee       	vpand  %ymm14,%ymm3,%ymm5
    4e48:	c5 e5 72 f6 10       	vpslld $0x10,%ymm6,%ymm3
    4e4d:	c4 c1 75 db ce       	vpand  %ymm14,%ymm1,%ymm1
    4e52:	c5 d5 fa f6          	vpsubd %ymm6,%ymm5,%ymm6
    4e56:	c5 fd fa c1          	vpsubd %ymm1,%ymm0,%ymm0
    4e5a:	c5 f5 fa cd          	vpsubd %ymm5,%ymm1,%ymm1
    4e5e:	c4 c2 4d 40 f0       	vpmulld %ymm8,%ymm6,%ymm6
    4e63:	c4 c2 7d 40 c2       	vpmulld %ymm10,%ymm0,%ymm0
    4e68:	c4 e2 75 40 cf       	vpmulld %ymm7,%ymm1,%ymm1
    4e6d:	c4 c1 65 fe df       	vpaddd %ymm15,%ymm3,%ymm3
    4e72:	c5 ed 72 f2 08       	vpslld $0x8,%ymm2,%ymm2
    4e77:	c5 f5 fe cb          	vpaddd %ymm3,%ymm1,%ymm1
    4e7b:	c5 fd fe c6          	vpaddd %ymm6,%ymm0,%ymm0
    4e7f:	c5 fd fe c1          	vpaddd %ymm1,%ymm0,%ymm0
    4e83:	c5 fd 72 d0 10       	vpsrld $0x10,%ymm0,%ymm0
    4e88:	c5 fd 72 f0 10       	vpslld $0x10,%ymm0,%ymm0
    4e8d:	c5 ed eb c0          	vpor   %ymm0,%ymm2,%ymm0
    4e91:	c5 fd eb c4          	vpor   %ymm4,%ymm0,%ymm0
    4e95:	c4 e2 7d 00 84 24 60 	vpshufb 0x160(%rsp),%ymm0,%ymm0
    4e9c:	01 00 00 
    4e9f:	c5 f9 6f d0          	vmovdqa %xmm0,%xmm2
    4ea3:	c4 e3 7d 39 c0 01    	vextracti128 $0x1,%ymm0,%xmm0
    4ea9:	c5 f1 73 f8 0c       	vpslldq $0xc,%xmm0,%xmm1
    4eae:	c5 f9 73 d8 04       	vpsrldq $0x4,%xmm0,%xmm0
    4eb3:	c5 f1 eb ca          	vpor   %xmm2,%xmm1,%xmm1
    4eb7:	c4 c1 79 d6 40 f8    	vmovq  %xmm0,-0x8(%r8)
    4ebd:	c4 c1 7a 7f 48 e8    	vmovdqu %xmm1,-0x18(%r8)
    4ec3:	4d 39 c2             	cmp    %r8,%r10
    4ec6:	0f 85 68 f4 ff ff    	jne    4334 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x7b4>
    4ecc:	e9 71 f3 ff ff       	jmp    4242 <jshc_domain_cache::avx2_chain(jshc_domain_cache::View const*, unsigned long long, unsigned char*, unsigned long long)+0x6c2>
    4ed1:	90                   	nop
    4ed2:	90                   	nop
    4ed3:	90                   	nop
    4ed4:	90                   	nop
    4ed5:	90                   	nop
    4ed6:	90                   	nop
    4ed7:	90                   	nop
    4ed8:	90                   	nop
    4ed9:	90                   	nop
    4eda:	90                   	nop
    4edb:	90                   	nop
    4edc:	90                   	nop
    4edd:	90                   	nop
    4ede:	90                   	nop
    4edf:	90                   	nop
